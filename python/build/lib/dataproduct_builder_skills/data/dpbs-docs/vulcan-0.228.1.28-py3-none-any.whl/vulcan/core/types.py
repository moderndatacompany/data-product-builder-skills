from __future__ import annotations
import re,typing as t
from pydantic import GetCoreSchemaHandler
from pydantic_core import core_schema
from typing_extensions import Self
class _ValidatedLowercaseStr(str):
	ALLOWED_CHARS:t.ClassVar[str];PATTERN:t.ClassVar[re.Pattern[str]];TYPE_LABEL:t.ClassVar[str];FORMAT_DESCRIPTION:t.ClassVar[str]
	def __new__(cls,value:t.Any)->Self:
		if isinstance(value,cls):return value
		if not isinstance(value,str):raise ValueError(f"{cls.TYPE_LABEL} must be a string, got {type(value)}")
		return super().__new__(cls,cls._parse(value))
	@classmethod
	def _parse(cls,value:str)->str:
		value=value.strip()
		if not value:raise ValueError(f"{cls.TYPE_LABEL} cannot be empty")
		if not cls.PATTERN.match(value):suggested=re.sub(f"[^{cls.ALLOWED_CHARS}]",'_',value);suggestion=f" (Hint: try '{suggested}')"if suggested!=value else'';raise ValueError(f"Invalid {cls.TYPE_LABEL.lower()} format: '{value}'. {cls.TYPE_LABEL}s must contain only {cls.FORMAT_DESCRIPTION}.{suggestion}")
		return value.casefold()
	@classmethod
	def __get_pydantic_core_schema__(cls,source_type:type,handler:GetCoreSchemaHandler)->core_schema.CoreSchema:return core_schema.no_info_wrap_validator_function(lambda value,nxt:cls(nxt(value)),core_schema.str_schema())
class Tag(_ValidatedLowercaseStr):
	ALLOWED_CHARS='a-zA-Z0-9.:_-';PATTERN=re.compile(f"^[{ALLOWED_CHARS}]+$");TYPE_LABEL='Tag';FORMAT_DESCRIPTION='alphanumeric characters, colons, hyphens, and underscores'
	def __new__(cls,value:t.Any)->Tag:return t.cast(Tag,super().__new__(cls,value))
class Term(_ValidatedLowercaseStr):
	ALLOWED_CHARS='a-zA-Z0-9._-';PATTERN=re.compile(f"^[{ALLOWED_CHARS}]+$");TYPE_LABEL='Term';FORMAT_DESCRIPTION='alphanumeric characters, dots, hyphens, and underscores'
	def __new__(cls,value:t.Any)->Term:return t.cast(Term,super().__new__(cls,value))
class RunDqCounts(t.NamedTuple):
	total:int;passed:int;failed:int;warned:int;not_evaluated:int
	@classmethod
	def empty(cls)->RunDqCounts:return cls(0,0,0,0,0)