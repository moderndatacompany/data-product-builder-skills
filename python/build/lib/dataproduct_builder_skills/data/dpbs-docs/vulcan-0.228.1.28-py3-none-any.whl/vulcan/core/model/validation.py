from __future__ import annotations
_F='number'
_E='segment'
_D='measure'
_C=True
_B=False
_A=None
import typing as t
from collections import Counter
from dataclasses import dataclass,field
from functools import cached_property
from itertools import chain
from pathlib import Path
from sqlglot import expressions as exp
from vulcan.core.dialect import ParsedColumn,ParsedSemanticExpression,is_semantic_boolean_predicate,parse_semantic_expression
from vulcan.core import constants as c
from vulcan.core.config.common import MetricJoinPath,TableNamingConvention
from vulcan.core.model.definition import MetricModel,Model,SemanticModel
from vulcan.core.model.policy import mask_expression_is_constant
from vulcan.core.model.semantic import STRICT_TIMESTAMP_TYPES,JoinSpec,MeasureSpec,RollupSpec,SegmentSpec,parse_qualified_reference
from vulcan.utils.errors import ConfigError
from vulcan.utils.join_graph import JoinEdge,JoinGraph
@dataclass(frozen=_C)
class Issue:
	message:str;fqn:t.Optional[str]=_A;hint:t.Optional[str]=_A
	@classmethod
	def with_fqn(cls,fqn:t.Optional[str],msg:str,*,hint:t.Optional[str]=_A)->Issue:return cls(message=msg,fqn=fqn,hint=hint)
@dataclass
class ModelValidationContext:
	models:t.Mapping[str,Model];dialect:str;config_path:Path;default_catalog:t.Optional[str]=_A;allow_reciprocal_joins:bool=_B;strict_semantic_validation:bool=_C;metric_join_path:t.Optional[MetricJoinPath]=_A;max_identifier_length:t.Optional[int]=_A;rollup_schema:str=c.ROLLUP;physical_table_naming_convention:TableNamingConvention=TableNamingConvention.SCHEMA_AND_TABLE;semantic_physical_pairs:t.Dict[str,t.Tuple[SemanticModel,Model]]=field(init=_B,default_factory=dict,repr=_B);_linked_semantic_cache:t.Dict[str,'_LinkedSemantic']=field(init=_B,default_factory=dict,repr=_B);issues:t.List[Issue]=field(init=_B,default_factory=list,repr=_B)
	@cached_property
	def semantic_models(self)->t.Tuple[SemanticModel,...]:return tuple(m for m in self.models.values()if isinstance(m,SemanticModel))
	@cached_property
	def metric_models(self)->t.Tuple[MetricModel,...]:return tuple(m for m in self.models.values()if isinstance(m,MetricModel))
	@cached_property
	def semantic_by_name(self)->t.Dict[str,SemanticModel]:return{sm.name:sm for sm in self.semantic_models}
	@cached_property
	def declared_semantic_names(self)->frozenset[str]:return frozenset(self.semantic_by_name.keys())
	@cached_property
	def join_graph(self)->JoinGraph:
		joinables=[m for m in self.models.values()if isinstance(m,SemanticModel)];names={semantic.name for semantic in joinables};graph=JoinGraph(allow_reciprocal_edges=self.allow_reciprocal_joins)
		for semantic in joinables:graph.add(semantic.name)
		for semantic in joinables:
			for join in semantic.joins:
				if join.name not in names:continue
				graph.add(semantic.name,join.name,edge=JoinEdge(join_type=join.type,skip_for_bi=join.skip_for_bi))
		return graph
	@cached_property
	def rollup_index(self)->t.Dict[str,t.Dict[str,RollupSpec]]:
		index:t.Dict[str,t.Dict[str,RollupSpec]]={}
		for semantic_name in self.semantic_physical_pairs:semantic=self.linked_semantic(semantic_name).semantic;index[semantic_name]={rollup.name:rollup for rollup in semantic.rollups}
		return index
	def __post_init__(self)->_A:
		pairs:t.Dict[str,t.Tuple[SemanticModel,Model]]={};dep_issues:t.List[Issue]=[]
		for sm in self.semantic_models:
			deps=sm.depends_on
			if not deps:dep_issues.append(Issue.with_fqn(sm.fqn,'semantic model has empty depends_on.'));continue
			if len(deps)!=1:dep_issues.append(Issue.with_fqn(sm.fqn,'semantic model must depend on exactly one physical model.'));continue
			dep_fqn=next(iter(deps));physical=self.models.get(dep_fqn)
			if physical is _A:dep_issues.append(Issue.with_fqn(sm.fqn,f"depends_on {dep_fqn!r} not found in loaded models (semantic YAML 'depends_on' must match a physical model name in this project)."));continue
			pairs[sm.name]=sm,physical
		self.semantic_physical_pairs=pairs;self.issues=dep_issues
	def _log_shape_violation(self,message:str)->_A:from vulcan.core.console import get_console;get_console().log_error(message)
	def record_shape_violation(self,message:str,*,fqn:str)->t.Optional[Issue]:
		self._log_shape_violation(message)
		if self.strict_semantic_validation:return Issue.with_fqn(fqn,message)
	def extend_issues(self,found:t.Iterable[Issue])->_A:self.issues.extend(found)
	def linked_semantic(self,semantic_name:str)->_LinkedSemantic:
		cached=self._linked_semantic_cache.get(semantic_name)
		if cached is not _A:return cached
		sm,physical=self.semantic_physical_pairs[semantic_name];physical_columns=physical.columns_to_types or{};physical_column_names=frozenset(physical_columns.keys());dimension_names=frozenset(d.name for d in sm.dimensions);measure_names=frozenset(m.name for m in sm.measures);segment_names=frozenset(s.name for s in sm.segments);members=dimension_names|measure_names|segment_names;linked=_LinkedSemantic(name=semantic_name,semantic=sm,physical=physical,physical_columns=physical_columns,physical_column_names=physical_column_names,dimension_names=dimension_names,measure_names=measure_names,segment_names=segment_names,members=members);self._linked_semantic_cache[semantic_name]=linked;return linked
	def declared_measure_ref_keys(self,ls:_LinkedSemantic)->frozenset[t.Tuple[str,str]]:
		semantic_name=ls.name;keys:t.Set[t.Tuple[str,str]]={(semantic_name,name)for name in ls.measure_names}
		for model_name in self.declared_semantic_names:
			if model_name==semantic_name:continue
			if model_name not in self.semantic_physical_pairs:continue
			if not self.join_graph.join_path_exists(semantic_name,model_name):continue
			target_ls=self.linked_semantic(model_name);keys.update((model_name,name)for name in target_ls.measure_names)
		return frozenset(keys)
	def format_issues(self,issues:t.Optional[t.Sequence[Issue]]=_A)->str:
		rows=self.issues if issues is _A else issues;groups:t.Dict[str,t.List[Issue]]={}
		for issue in rows:prefix=self._issue_location_prefix(issue.fqn);groups.setdefault(prefix,[]).append(issue)
		lines:t.List[str]=[]
		for(prefix,group_issues)in groups.items():
			lines.append(f"{prefix} -")
			for issue in group_issues:
				lines.append(f"  {issue.message}")
				if issue.hint:lines.append(f"  HINT: {issue.hint}")
		return'\n'.join(lines)
	def _path_relative_to_config(self,path:Path)->str:
		try:return str(path.resolve().relative_to(self.config_path.resolve()))
		except ValueError:return str(path)
	def _issue_location_prefix(self,fqn:t.Optional[str])->str:
		if fqn and fqn in self.models:
			m=self.models[fqn]
			if m._path:return self._path_relative_to_config(m._path)
			return f"{m.name} ({fqn})"
		if fqn:return fqn
		return str(self.config_path)
class ModelValidationError(ConfigError):
	def __init__(self,ctx:ModelValidationContext)->_A:self.ctx=ctx;text='Model validation failed:\n'+ctx.format_issues()if ctx.issues else'Model validation failed.';super().__init__(text,location=ctx.config_path)
	@property
	def issues(self)->t.List[Issue]:return self.ctx.issues
@dataclass(frozen=_C)
class _LinkedSemantic:name:str;semantic:SemanticModel;physical:Model;physical_columns:t.Mapping[str,exp.DataType];physical_column_names:frozenset[str];dimension_names:frozenset[str];measure_names:frozenset[str];segment_names:frozenset[str];members:frozenset[str]
GraphValidator=t.Callable[[ModelValidationContext],t.Iterable[Issue]]
SemanticModelValidator=t.Callable[[ModelValidationContext,_LinkedSemantic],t.Iterable[Issue]]
MetricValidator=t.Callable[[ModelValidationContext,MetricModel],t.Iterable[Issue]]
T=t.TypeVar('T')
ItemValidator=t.Callable[[ModelValidationContext,_LinkedSemantic,T],t.Iterable[Issue]]
RollupValidator=t.Callable[[ModelValidationContext,_LinkedSemantic,RollupSpec],t.Iterable[Issue]]
@dataclass(frozen=_C)
class _MetricRefs:raw:t.Tuple[str,...];qualified:t.Tuple[t.Tuple[str,str],...];anchor:t.Optional[str]
def _collect_issues(*streams:t.Iterable[Issue])->t.List[Issue]:return list(chain.from_iterable(streams))
def _run_validators(validators:t.Sequence[t.Callable[...,t.Iterable[Issue]]],*args:object)->t.Iterable[Issue]:return chain.from_iterable(fn(*args)for fn in validators)
def _foreach(get_items:t.Callable[[_LinkedSemantic],t.Iterable[T]],*validators:ItemValidator[T])->SemanticModelValidator:return lambda ctx,ls:list(chain.from_iterable(_run_validators(validators,ctx,ls,item)for item in get_items(ls)))
def _semantic_member_label(ls:_LinkedSemantic,kind:str,name:str,*,filter_index:t.Optional[int]=_A,join_target:t.Optional[str]=_A)->str:
	if kind=='join'and join_target:return f"join '{ls.name} -> {join_target}'"
	label=f"{kind} '{ls.name}.{name}'"
	if filter_index is not _A:return f"{label} filter[{filter_index}]"
	return label
def _parse_rollup_member_ref(ls:_LinkedSemantic,ref:str)->t.Optional[t.Tuple[str,str]]:return(ls.name,ref)if'.'not in ref else parse_qualified_reference(ref)
def _parse_semantic_expression_or_issue(ctx:ModelValidationContext,ls:_LinkedSemantic,expression:str,*,member_label:str,into:t.Optional[t.Type[exp.Expression]]=_A,owning_model:t.Optional[str]=_A,use_declaring_model:bool=_C)->t.Union[ParsedSemanticExpression,Issue]:
	effective_owning=ls.name if use_declaring_model and owning_model is _A else owning_model
	try:return parse_semantic_expression(expression,ctx.dialect,owning_model=effective_owning,into=into,context=member_label)
	except ConfigError as exc:return Issue.with_fqn(ls.semantic.fqn,str(exc))
def _boolean_shape_issue(ctx:ModelValidationContext,ls:_LinkedSemantic,tree:t.Optional[exp.Expression],*,member_label:str)->t.Optional[Issue]:
	if tree is _A or is_semantic_boolean_predicate(tree):return
	return ctx.record_shape_violation(f"{member_label} must be a boolean condition",fqn=ls.semantic.fqn)
def _number_body_aggregate_issue(ctx:ModelValidationContext,ls:_LinkedSemantic,tree:t.Optional[exp.Expression],*,member_label:str,braced_measure_refs:t.AbstractSet[t.Tuple[str,str]])->t.Optional[Issue]:
	if tree is _A:return
	if list(tree.find_all(exp.AggFunc))or braced_measure_refs:return
	return ctx.record_shape_violation(f"{member_label} must include an aggregate function",fqn=ls.semantic.fqn)
def _calculated_non_number_aggregate_issue(ctx:ModelValidationContext,ls:_LinkedSemantic,tree:t.Optional[exp.Expression],*,member_label:str,measure_type:str)->t.Optional[Issue]:
	if tree is _A:return
	if list(tree.find_all(exp.AggFunc)):return
	return ctx.record_shape_violation(f"{member_label} of calculated type '{measure_type}' must include an aggregate function",fqn=ls.semantic.fqn)
def _forbid_aggregate_issue(ctx:ModelValidationContext,ls:_LinkedSemantic,tree:t.Optional[exp.Expression],*,member_label:str)->t.Optional[Issue]:
	if tree is _A or not list(tree.find_all(exp.AggFunc)):return
	return ctx.record_shape_violation(f"{member_label} must not include an aggregate function",fqn=ls.semantic.fqn)
def _time_dimension_column_issue(fqn:str,column_type:exp.DataType,field_name:str,*,message_prefix:str='')->t.Optional[Issue]:
	msg_hint=_strict_ts_message_and_hint(column_type,field_name)
	if msg_hint is _A:return
	msg,hint=msg_hint
	if message_prefix:msg=f"{message_prefix}{msg}"
	return Issue.with_fqn(fqn,msg,hint=hint)
def _resolve_name_casefold(name:str,known:t.AbstractSet[str])->t.Optional[str]:
	if name in known:return name
	folded=name.casefold();matches=[candidate for candidate in known if candidate.casefold()==folded]
	if len(matches)==1:return matches[0]
def _physical_column_type(columns:t.Mapping[str,exp.DataType],name:str)->t.Optional[exp.DataType]:resolved=_resolve_name_casefold(name,frozenset(columns));return columns.get(resolved)if resolved is not _A else _A
def _strict_ts_message_and_hint(column_type:exp.DataType,field_name:str)->t.Optional[t.Tuple[str,t.Optional[str]]]:
	if not column_type:return f"'{field_name}' has unknown column type",_A
	if column_type.is_type(*STRICT_TIMESTAMP_TYPES):return
	if column_type.is_type(exp.DataType.Type.DATE):return f"'{field_name}' uses DATE type. Time dimensions require TIMESTAMP.",f"CAST({field_name} AS TIMESTAMP) AS {field_name}"
	if column_type.is_type(exp.DataType.Type.TIME):return f"'{field_name}' uses TIME type (time-of-day only). Time dimensions need full timestamps.",f"CAST(CONCAT(date_column, ' ', {field_name}) AS TIMESTAMP)"
	if column_type.is_type(exp.DataType.Type.INTERVAL):return f"'{field_name}' uses INTERVAL type (duration). Time dimensions need point-in-time values.",f"base_timestamp + {field_name}"
	return f"'{field_name}' requires TIMESTAMP type for time dimensions, got {column_type}",_A
def _declared_but_unresolved_msg(ctx:ModelValidationContext,model_name:str)->str:
	if model_name not in ctx.declared_semantic_names:return f"semantic model {model_name!r} is not declared (declared: {sorted(ctx.declared_semantic_names)})."
	return f"semantic model {model_name!r} is declared but has no linked physical base (check depends_on)."
def _semantic_grains_required(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.Iterable[Issue]:
	if not ls.physical.grains:yield Issue.with_fqn(ls.semantic.fqn,f"physical model {ls.physical.name!r} must define grains.")
def _semantic_joins_require_grains(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.Iterable[Issue]:
	if ls.semantic.joins and not ls.physical.grains:yield Issue.with_fqn(ls.semantic.fqn,f"semantic model {ls.name!r} declares joins but physical model {ls.physical.name!r} has no grains.")
def _semantic_dimension_columns(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.Iterable[Issue]:
	if not ls.physical_column_names:return
	missing_dims={dim for dim in ls.dimension_names if _resolve_name_casefold(dim,ls.physical_column_names)is _A}
	if missing_dims:yield Issue.with_fqn(ls.semantic.fqn,f"dimensions reference unknown columns: {sorted(missing_dims)}.")
def _semantic_dimension_granularities(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.Iterable[Issue]:
	del ctx
	if not ls.physical_column_names:return
	semantic_fqn=ls.semantic.fqn
	for dimension in ls.semantic.dimensions:
		phys_col=_resolve_name_casefold(dimension.name,ls.physical_column_names)
		if dimension.granularities and phys_col is not _A:
			if(issue:=_time_dimension_column_issue(semantic_fqn,ls.physical_columns[phys_col],dimension.name)):yield issue
def _semantic_field_uniqueness(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;semantic_fqn=sm.fqn;all_field_names=[m.name for m in sm.measures]+[s.name for s in sm.segments]+sorted(ls.dimension_names);dupes={n for(n,c)in Counter(all_field_names).items()if c>1}
	if not dupes:return[]
	return[Issue.with_fqn(semantic_fqn,f"duplicate names across dimensions, measures, segments: {sorted(dupes)}.")]
def _measure_self_dimension_issues(ls:_LinkedSemantic,columns:t.Tuple[ParsedColumn,...],*,member_label:str)->t.Iterable[Issue]:
	semantic_fqn=ls.semantic.fqn;semantic_name=ls.name
	for parsed in columns:
		model_name=parsed.model;field=parsed.member;ref=f"{model_name}.{field}"
		if model_name!=semantic_name:yield Issue.with_fqn(semantic_fqn,f"{member_label} {ref!r}: must reference only dimensions on {semantic_name!r} (bare columns or '{{{semantic_name}.column}}').");continue
		if field not in ls.dimension_names:yield Issue.with_fqn(semantic_fqn,f"{member_label} {ref!r}: unknown dimension {field!r}.")
def _measure_number_body_issues(ctx:ModelValidationContext,ls:_LinkedSemantic,columns:t.Tuple[ParsedColumn,...],*,member_label:str)->t.Iterable[Issue]:
	semantic_fqn=ls.semantic.fqn;semantic_name=ls.name
	for parsed in columns:
		model_name=parsed.model;field=parsed.member;ref=f"{model_name}.{field}"
		if not parsed.braced:
			if model_name!=semantic_name:yield Issue.with_fqn(semantic_fqn,f"{member_label} {ref!r}: joined refs must use '{{{model_name}.{field}}}', not bare {field!r}.");continue
			if field in ls.dimension_names:continue
			if field in ls.measure_names:yield Issue.with_fqn(semantic_fqn,f"{member_label} {ref!r}: self measures must use '{{{model_name}.{field}}}', not bare {field!r}.");continue
			yield Issue.with_fqn(semantic_fqn,f"{member_label} {ref!r}: unknown member {field!r} on {model_name!r} (declared dimensions and measures only).");continue
		if model_name==semantic_name:target_ls=ls
		elif not ctx.join_graph.join_path_exists(semantic_name,model_name):yield _semantic_join_path_issue(semantic_fqn,f"{member_label} {ref!r}: no join path between {semantic_name!r} and {model_name!r}.",from_model=semantic_name,to_model=model_name);continue
		else:target_ls=ctx.linked_semantic(model_name)
		if field not in target_ls.dimension_names and field not in target_ls.measure_names:yield Issue.with_fqn(semantic_fqn,f"{member_label} {ref!r}: unknown member {field!r} on {model_name!r} (declared dimensions and measures only).")
def _measure_filter(ctx:ModelValidationContext,ls:_LinkedSemantic,measure:MeasureSpec,filter_index:int,filter_expr:str)->t.Iterable[Issue]:
	filter_ctx=_semantic_member_label(ls,_D,measure.name,filter_index=filter_index);parsed=_parse_semantic_expression_or_issue(ctx,ls,filter_expr,member_label=filter_ctx,into=exp.Condition)
	if isinstance(parsed,Issue):yield parsed;return
	yield from _measure_self_dimension_issues(ls,parsed.columns,member_label=filter_ctx)
	if(shape_issue:=_boolean_shape_issue(ctx,ls,parsed.tree,member_label=filter_ctx)):yield shape_issue
def _measure_filters(ctx:ModelValidationContext,ls:_LinkedSemantic,measure:MeasureSpec)->t.Iterable[Issue]:
	for(filter_index,filter_expr)in enumerate(measure.filters):yield from _measure_filter(ctx,ls,measure,filter_index,filter_expr)
def _measure_body_refs(ctx:ModelValidationContext,ls:_LinkedSemantic,measure:MeasureSpec,*,parsed_body:t.Tuple[ParsedColumn,...],body_ctx:str)->t.Iterable[Issue]:
	if measure.type==_F:yield from _measure_number_body_issues(ctx,ls,parsed_body,member_label=body_ctx)
	else:yield from _measure_self_dimension_issues(ls,parsed_body,member_label=body_ctx)
def _measure_body_shape(ctx:ModelValidationContext,ls:_LinkedSemantic,measure:MeasureSpec,*,parsed_body:ParsedSemanticExpression,body_ctx:str)->t.Iterable[Issue]:
	expression=measure.expression.strip()
	if measure.type==_F:
		braced_measure_refs=frozenset((parsed.model,parsed.member)for parsed in parsed_body.columns if parsed.braced and(parsed.model,parsed.member)in ctx.declared_measure_ref_keys(ls))
		if(issue:=_number_body_aggregate_issue(ctx,ls,parsed_body.tree,member_label=body_ctx,braced_measure_refs=braced_measure_refs)):yield issue
	elif measure.type in{'string','time','boolean'}:
		if(issue:=_calculated_non_number_aggregate_issue(ctx,ls,parsed_body.tree,member_label=body_ctx,measure_type=measure.type)):yield issue
	elif expression not in{'','*'}:
		if(issue:=_forbid_aggregate_issue(ctx,ls,parsed_body.tree,member_label=body_ctx)):yield issue
def _measure_body(ctx:ModelValidationContext,ls:_LinkedSemantic,measure:MeasureSpec)->t.Iterable[Issue]:
	expression=measure.expression.strip()
	if not expression:return
	body_ctx=_semantic_member_label(ls,_D,measure.name);parsed_body=_parse_semantic_expression_or_issue(ctx,ls,measure.expression,member_label=body_ctx)
	if isinstance(parsed_body,Issue):yield parsed_body;return
	yield from _measure_body_refs(ctx,ls,measure,parsed_body=parsed_body.columns,body_ctx=body_ctx);yield from _measure_body_shape(ctx,ls,measure,parsed_body=parsed_body,body_ctx=body_ctx)
def _measure_behavior_time_dimension(ctx:ModelValidationContext,ls:_LinkedSemantic,measure:MeasureSpec)->t.Iterable[Issue]:
	del ctx;behavior=measure.behavior
	if behavior is _A:return
	semantic_fqn=ls.semantic.fqn;measure_name=measure.name;time_dim=behavior.time_dimension.strip()
	if not time_dim:return
	if time_dim not in ls.dimension_names:yield Issue.with_fqn(semantic_fqn,f"measure {measure_name!r} behavior.time_dimension {time_dim!r} is not a declared dimension.");return
	col_type=_physical_column_type(ls.physical_columns,time_dim)
	if col_type is not _A:
		if(issue:=_time_dimension_column_issue(semantic_fqn,col_type,time_dim,message_prefix=f"measure {measure_name!r} behavior.time_dimension ")):yield issue
def _measure_behavior_measure_refs(ctx:ModelValidationContext,ls:_LinkedSemantic,measure:MeasureSpec)->t.Iterable[Issue]:
	del ctx;behavior=measure.behavior
	if behavior is _A:return
	semantic_fqn=ls.semantic.fqn;measure_name=measure.name;behavior_measure_refs=[(field_name,name)for(field_name,raw)in(('numerator',behavior.numerator),('denominator',behavior.denominator),*(('measure_refs',ref)for ref in behavior.measure_refs))if(name:=raw.strip())]
	for(field_name,ref_name)in behavior_measure_refs:
		if ref_name not in ls.measure_names:yield Issue.with_fqn(semantic_fqn,f"measure {measure_name!r} behavior.{field_name} {ref_name!r} is not a declared measure.")
		elif ref_name==measure_name:yield Issue.with_fqn(semantic_fqn,f"measure {measure_name!r} behavior.{field_name} must not reference the measure itself.")
def _segment_dimension_refs(ctx:ModelValidationContext,ls:_LinkedSemantic,*,parsed:ParsedSemanticExpression,segment_ctx:str)->t.Iterable[Issue]:
	del ctx;semantic_name=ls.name;semantic_fqn=ls.semantic.fqn
	for column in parsed.columns:
		model_name=column.model;field=column.member;ref=f"{model_name}.{field}"
		if model_name!=semantic_name:yield Issue.with_fqn(semantic_fqn,f"{segment_ctx} {ref!r}: cross-model refs are not allowed.");continue
		if field not in ls.dimension_names:yield Issue.with_fqn(semantic_fqn,f"{segment_ctx}: unknown dimension {field!r}.")
def _segment(ctx:ModelValidationContext,ls:_LinkedSemantic,segment:SegmentSpec)->t.Iterable[Issue]:
	segment_ctx=_semantic_member_label(ls,_E,segment.name);parsed=_parse_semantic_expression_or_issue(ctx,ls,segment.expression,member_label=segment_ctx,into=exp.Condition)
	if isinstance(parsed,Issue):yield parsed;return
	yield from _segment_dimension_refs(ctx,ls,parsed=parsed,segment_ctx=segment_ctx)
	if(shape_issue:=_boolean_shape_issue(ctx,ls,parsed.tree,member_label=segment_ctx)):yield shape_issue
def _join_target(ctx:ModelValidationContext,ls:_LinkedSemantic,join:JoinSpec)->t.Iterable[Issue]:
	semantic_fqn=ls.semantic.fqn;join_name=join.name
	if join_name not in ctx.declared_semantic_names:yield Issue.with_fqn(semantic_fqn,f"join {join_name!r} target is not a declared semantic model name.");return
	if join_name not in ctx.semantic_physical_pairs:yield Issue.with_fqn(semantic_fqn,f"join {join_name!r} has no linked physical model.")
def _join_predicate(ctx:ModelValidationContext,ls:_LinkedSemantic,join:JoinSpec)->t.Iterable[Issue]:
	semantic_name=ls.name;semantic_fqn=ls.semantic.fqn;join_name=join.name
	if join_name not in ctx.declared_semantic_names:return
	if join_name not in ctx.semantic_physical_pairs:return
	if not ls.physical.grains:return
	target_ls=ctx.linked_semantic(join_name)
	if not join.expression:yield Issue.with_fqn(semantic_fqn,f"join {join_name!r} is missing a resolved expression.");return
	join_ctx=_semantic_member_label(ls,'join',join_name,join_target=join_name);parsed=_parse_semantic_expression_or_issue(ctx,ls,join.expression,member_label=join_ctx,into=exp.Condition,use_declaring_model=_B)
	if isinstance(parsed,Issue):yield parsed;return
	for column in parsed.columns:
		table_name=column.model;column_name=column.member
		if table_name not in(semantic_name,join_name):yield Issue.with_fqn(semantic_fqn,f"join {join_name!r}: expected tables {semantic_name!r} or {join_name!r}, got {table_name!r}.")
		elif table_name==semantic_name and column_name not in ls.dimension_names:yield Issue.with_fqn(semantic_fqn,f"join {join_name!r}: unknown dimension {column_name!r} for {semantic_name!r}.")
		elif table_name==join_name and column_name not in target_ls.dimension_names:yield Issue.with_fqn(semantic_fqn,f"join {join_name!r}: unknown dimension {column_name!r} for {join_name!r}.")
def _graph_join_cycles(ctx:ModelValidationContext)->t.Iterable[Issue]:
	for msg in ctx.join_graph.cycles():yield Issue.with_fqn(_A,msg)
def _graph_unlinked_join_targets(ctx:ModelValidationContext)->t.List[Issue]:
	issues:t.List[Issue]=[];linked_names=frozenset(ctx.semantic_physical_pairs.keys());declared_names=ctx.declared_semantic_names
	for semantic_model in ctx.semantic_models:
		if semantic_model.name in linked_names:continue
		for join in semantic_model.joins:
			join_name=join.name
			if join_name not in declared_names:issues.append(Issue.with_fqn(semantic_model.fqn,f"join {join_name!r} target is not a declared semantic model name."))
	return issues
def _metric_field_issues(ctx:ModelValidationContext,mm:MetricModel,ref:str)->t.List[Issue]:
	parsed=parse_qualified_reference(ref)
	if not parsed:return[]
	model_name,field_name=parsed;metric_fqn=mm.fqn;issues:t.List[Issue]=[];linked=ctx.linked_semantic(model_name);column_types=linked.physical_columns
	if field_name not in linked.members:issues.append(Issue.with_fqn(metric_fqn,f"unknown field {field_name!r} in semantic model {model_name!r}."))
	if ref==mm.ts:
		col_type=_physical_column_type(column_types,field_name)
		if col_type and(issue:=_time_dimension_column_issue(metric_fqn,col_type,field_name)):issues.append(issue)
	return issues
def _metric_ref_strings(mm:MetricModel)->t.List[str]:return[mm.measure,mm.ts,*[s.ref for s in mm.dimensions],*[s.ref for s in mm.segments]]
def _metric_refs(mm:MetricModel)->_MetricRefs:raw=tuple(_metric_ref_strings(mm));qualified=tuple(parsed for ref in raw if(parsed:=parse_qualified_reference(ref))is not _A);parsed_measure=parse_qualified_reference(mm.measure);anchor=parsed_measure[0]if parsed_measure else _A;return _MetricRefs(raw=raw,qualified=qualified,anchor=anchor)
def _metric_reference_issues(ctx:ModelValidationContext,mm:MetricModel,refs:_MetricRefs)->t.List[Issue]:
	out:t.List[Issue]=[];mm_fqn=mm.fqn;metric_reported:t.Set[str]=set()
	for ref in refs.raw:
		parsed=parse_qualified_reference(ref)
		if not parsed:continue
		model_name,_=parsed
		if model_name not in ctx.semantic_by_name:
			if model_name not in metric_reported:metric_reported.add(model_name);out.append(Issue.with_fqn(mm_fqn,f"unknown semantic model {model_name!r} (see {ref!r}); declared: {sorted(ctx.declared_semantic_names)}."))
			continue
		if model_name not in ctx.semantic_physical_pairs:
			if model_name not in metric_reported:metric_reported.add(model_name);out.append(Issue.with_fqn(mm_fqn,f"{ref!r}: {_declared_but_unresolved_msg(ctx,model_name)}"))
			continue
		out.extend(_metric_field_issues(ctx,mm,ref))
	return out
def _metric_directed_join_path_issue(fqn:str,*,anchor:str,target:str)->Issue:return Issue.with_fqn(fqn,f"no directed join path from {anchor!r} to {target!r}.",hint=f"Declare a join from {anchor!r} toward {target!r}, define the measure on {target!r}, or remove the reference to {target!r}. To allow connectivity without a directed path, set join_path: connected on this metric YAML, or metric_join_path: connected in config.yaml.")
def _metric_join_pairs(ctx:ModelValidationContext,mm:MetricModel,refs:_MetricRefs)->t.Iterable[Issue]:
	anchor=refs.anchor
	if anchor is _A or anchor not in ctx.semantic_physical_pairs:return
	if mm.join_path is not _A:effective_join_path=mm.join_path
	elif ctx.metric_join_path is not _A:effective_join_path=ctx.metric_join_path
	else:effective_join_path=MetricJoinPath.CONNECTED
	require_directed=effective_join_path.is_directed;seen_targets:t.Set[str]=set()
	for(target,_)in refs.qualified:
		if target not in ctx.semantic_physical_pairs or target==anchor or target in seen_targets:continue
		seen_targets.add(target)
		if require_directed:
			if ctx.join_graph.directed_join_path_exists(anchor,target):continue
			yield _metric_directed_join_path_issue(mm.fqn,anchor=anchor,target=target)
		elif ctx.join_graph.join_path_exists(anchor,target):continue
		else:yield _semantic_join_path_issue(mm.fqn,f"no join path between {anchor!r} and {target!r}.",from_model=anchor,to_model=target)
def _semantic_join_path_issue(fqn:str,message:str,*,from_model:str,to_model:str)->Issue:return Issue.with_fqn(fqn,message,hint=f"Declare joins linking {from_model!r} and {to_model!r}, or remove the reference to {to_model!r}.")
def _metric_validate(ctx:ModelValidationContext,mm:MetricModel)->t.Iterable[Issue]:refs=_metric_refs(mm);yield from _metric_reference_issues(ctx,mm,refs);yield from _metric_join_pairs(ctx,mm,refs)
def _resolve_rollup_dimension(ctx:ModelValidationContext,ls:_LinkedSemantic,rc:str,ref:str)->t.Tuple[t.Optional[Issue],t.Optional[_LinkedSemantic],t.Optional[str]]:
	semantic_name=ls.name;semantic_fqn=ls.semantic.fqn;issue:t.Optional[Issue]=_A;target:t.Optional[_LinkedSemantic]=_A;resolved_field:t.Optional[str]=_A;parsed=(semantic_name,ref)if'.'not in ref else parse_qualified_reference(ref)
	if parsed is _A:issue=Issue.with_fqn(semantic_fqn,f"{rc}: {ref!r} is not a valid member reference.")
	else:
		model_name,field=parsed
		if model_name!=semantic_name and not ctx.join_graph.join_path_exists(semantic_name,model_name):issue=_semantic_join_path_issue(semantic_fqn,f"{rc}: cross-model dimension {ref!r}: no join path between {semantic_name!r} and {model_name!r}.",from_model=semantic_name,to_model=model_name)
		elif model_name not in ctx.semantic_physical_pairs:issue=Issue.with_fqn(semantic_fqn,f"{rc}: {ref!r}: {_declared_but_unresolved_msg(ctx,model_name)}")
		else:
			target=ctx.linked_semantic(model_name)
			if field not in target.dimension_names:issue=Issue.with_fqn(semantic_fqn,f"{rc}: unknown dimension {ref!r} in {model_name!r}.")
			else:resolved_field=field
	return issue,target,resolved_field
def _rollup_label(rollup:RollupSpec)->str:return f"rollup {rollup.name!r}"
def _qualify_rollup_member(member:str,model_name:str)->str:return member if'.'in member else f"{model_name}.{member}"
def _member_in_source_rollup(member_ref:str,source_model:str,source:RollupSpec,*,owning_model:str,members:t.Sequence[str])->bool:
	parsed=parse_qualified_reference(member_ref)
	if parsed is not _A:qualified=f"{parsed[0]}.{parsed[1]}"
	else:qualified=_qualify_rollup_member(member_ref,owning_model)
	return any(_qualify_rollup_member(m,source_model)==qualified for m in members)
def _rollup_local_member_ref_issues(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup_label:str,ref:str,kind:str,known:frozenset[str],*,allow_cross_model:bool=_B)->t.Iterable[Issue]:
	semantic_name=ls.name;semantic_fqn=ls.semantic.fqn;parsed=_parse_rollup_member_ref(ls,ref)
	if parsed is _A:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: {ref!r} is not a valid {kind} reference.");return
	model_name,field=parsed
	if model_name!=semantic_name:
		if not allow_cross_model:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: cross-model {kind} {ref!r} is not allowed — {kind}s must belong to {semantic_name!r}.");return
		if model_name not in ctx.semantic_physical_pairs:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: {ref!r}: {_declared_but_unresolved_msg(ctx,model_name)}");return
		if not ctx.join_graph.join_path_exists(semantic_name,model_name):yield _semantic_join_path_issue(semantic_fqn,f"{rollup_label}: cross-model {kind} {ref!r}: no join path between {semantic_name!r} and {model_name!r}.",from_model=semantic_name,to_model=model_name);return
		target=ctx.linked_semantic(model_name)
		if kind==_D:known=target.measure_names
		elif kind==_E:known=target.segment_names
		else:known=target.dimension_names
	if field not in known:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: unknown {kind} {ref!r}.")
def _rollup_materialized_identifier(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec)->t.Iterable[Issue]:
	from vulcan.core.engine_adapter import max_materialized_rollup_base_length;semantic_name=ls.name;rollup_label=_rollup_label(rollup);base_name=f"{semantic_name}_{rollup.name}";max_base=max_materialized_rollup_base_length(dialect=ctx.dialect,rollup_schema=ctx.rollup_schema,naming_convention=ctx.physical_table_naming_convention)
	if len(base_name)>max_base:physical_example=f"{ctx.rollup_schema}__{base_name}__{'X'*10}_schema_tmp";yield Issue.with_fqn(ls.semantic.fqn,f"{rollup_label}: combined identifier {base_name!r} ({len(base_name)} chars) exceeds the safe limit of {max_base} for {ctx.dialect} (physical temp table would look like {physical_example!r}). Shorten the semantic model or rollup name.")
def _rollup_materialized_members(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec)->t.Iterable[Issue]:
	rollup_label=_rollup_label(rollup)
	for(kind,refs,known)in((_D,rollup.measures,ls.measure_names),(_E,rollup.segments,ls.segment_names),('dimension',rollup.dimensions,ls.dimension_names)):
		for ref in refs:yield from _rollup_local_member_ref_issues(ctx,ls,rollup_label,ref,kind,known)
def _rollup_materialized_rolling_measures(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec)->t.Iterable[Issue]:
	del ctx;selected_measures={field for ref in rollup.measures if(parsed:=_parse_rollup_member_ref(ls,ref))is not _A for(model_name,field)in(parsed,)if model_name==ls.name};rolling_measures=sorted(measure.name for measure in ls.semantic.measures if measure.name in selected_measures and measure.rolling_window is not _A)
	if not rolling_measures:return
	rollup_label=_rollup_label(rollup)
	if rollup.time_dimension is _A:yield Issue.with_fqn(ls.semantic.fqn,f"{rollup_label}: rolling measure(s) {rolling_measures!r} require 'time_dimension' to be set.")
	elif rollup.date_range is _A:yield Issue.with_fqn(ls.semantic.fqn,f"{rollup_label}: rolling measure(s) {rolling_measures!r} require 'date_range' to be set for Cube rollup compilation.")
def _rollup_materialized_time_dimension(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec)->t.Iterable[Issue]:
	del ctx
	if not rollup.time_dimension:return
	semantic_name=ls.name;semantic_fqn=ls.semantic.fqn;rollup_label=_rollup_label(rollup);parsed=_parse_rollup_member_ref(ls,rollup.time_dimension)
	if parsed is _A:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: {rollup.time_dimension!r} is not a valid time_dimension reference.");return
	model_name,field=parsed
	if model_name!=semantic_name:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: cross-model time_dimension {rollup.time_dimension!r} is not allowed — time_dimension must belong to {semantic_name!r}.");return
	if field not in ls.dimension_names:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: unknown time_dimension {rollup.time_dimension!r}.");return
	col_type=ls.physical_columns.get(field)
	if col_type is not _A and(issue:=_time_dimension_column_issue(semantic_fqn,col_type,field,message_prefix=f"{rollup_label}: time_dimension ")):yield issue
def _rollup_materialized_masked_dimensions(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec)->t.Iterable[Issue]:
	masks=ls.physical.column_mask_expressions or{}
	if not masks:return
	rollup_label=_rollup_label(rollup);refs=*rollup.dimensions,*([rollup.time_dimension]if rollup.time_dimension else());fields=[field for ref in refs if(parsed:=_parse_rollup_member_ref(ls,ref))is not _A for(model_name,field)in(parsed,)if model_name==ls.name]
	for field in fields:
		field_folded=field.casefold();mask_sql=next((expr for(col,expr)in masks.items()if col.casefold()==field_folded),_A)
		if mask_sql is _A or mask_expression_is_constant(mask_sql,dialect=ctx.dialect):continue
		yield Issue.with_fqn(ls.semantic.fqn,f"{rollup_label}: {field!r} cannot be a used in a rollup because its column_mask_expression is not constant.")
def _rollup_composite_sources(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec,source_specs:t.List[t.Tuple[str,RollupSpec]])->t.Iterable[Issue]:
	semantic_name=ls.name;semantic_fqn=ls.semantic.fqn;rollup_label=_rollup_label(rollup);assert rollup.rollups is not _A;seen_refs:t.Set[str]=set();rollup_index=ctx.rollup_index
	for ref in rollup.rollups:
		if ref in seen_refs:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: duplicate rollups entry {ref!r}.");continue
		seen_refs.add(ref);parsed=parse_qualified_reference(ref)
		if parsed is _A:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: rollups entry {ref!r} must be qualified as '{{model}}.{{rollup_name}}'.",hint=f"Qualify each source rollup as '{{model}}.{{rollup_name}}', e.g. '{semantic_name}.arr_monthly'.");continue
		source_model_name,source_rollup_name=parsed
		if source_model_name not in ctx.semantic_physical_pairs:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: rollups entry {ref!r}: {_declared_but_unresolved_msg(ctx,source_model_name)}");continue
		source_spec=rollup_index.get(source_model_name,{}).get(source_rollup_name)
		if source_spec is _A:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: unknown rollup {ref!r}.");continue
		if source_spec.is_composite:yield Issue.with_fqn(semantic_fqn,f"{rollup_label}: rollups entry {ref!r} must reference a materialized rollup, not a composite.");continue
		if source_model_name!=semantic_name and not ctx.join_graph.join_path_exists(semantic_name,source_model_name):yield _semantic_join_path_issue(semantic_fqn,f"{rollup_label}: rollups entry {ref!r}: no join path between {semantic_name!r} and {source_model_name!r}.",from_model=semantic_name,to_model=source_model_name);continue
		source_specs.append((source_model_name,source_spec))
def _rollup_composite_member_sources(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup_label:str,ref:str,kind:str,known:frozenset[str],source_specs:t.Sequence[t.Tuple[str,RollupSpec]],*,source_members:t.Callable[[RollupSpec],t.Sequence[str]])->t.Iterable[Issue]:
	ref_issues=list(_rollup_local_member_ref_issues(ctx,ls,rollup_label,ref,kind,known,allow_cross_model=_C))
	if ref_issues:yield from ref_issues;return
	if not any(_member_in_source_rollup(ref,source_model,source,owning_model=ls.name,members=source_members(source))for(source_model,source)in source_specs):yield Issue.with_fqn(ls.semantic.fqn,f"{rollup_label}: {kind} {ref!r} is not declared on any referenced source rollup.")
def _rollup_composite_measures(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec,source_specs:t.Sequence[t.Tuple[str,RollupSpec]])->t.Iterable[Issue]:
	rollup_label=_rollup_label(rollup)
	for ref in rollup.measures:yield from _rollup_composite_member_sources(ctx,ls,rollup_label,ref,_D,ls.measure_names,source_specs,source_members=lambda source:source.measures)
def _rollup_composite_segments(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec,source_specs:t.Sequence[t.Tuple[str,RollupSpec]])->t.Iterable[Issue]:
	rollup_label=_rollup_label(rollup)
	for ref in rollup.segments:yield from _rollup_composite_member_sources(ctx,ls,rollup_label,ref,_E,ls.segment_names,source_specs,source_members=lambda source:source.segments)
def _rollup_composite_dimensions(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec)->t.Iterable[Issue]:
	rollup_label=_rollup_label(rollup)
	for ref in rollup.dimensions:
		issue,_,_=_resolve_rollup_dimension(ctx,ls,rollup_label,ref)
		if issue:yield issue
def _rollup_composite_time_dimension(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec)->t.Iterable[Issue]:
	if not rollup.time_dimension:return
	rollup_label=_rollup_label(rollup);issue,target,field=_resolve_rollup_dimension(ctx,ls,rollup_label,rollup.time_dimension)
	if issue:yield issue;return
	if target is not _A and field is not _A:
		col_type=target.physical_columns.get(field)
		if col_type is not _A and(ts_issue:=_time_dimension_column_issue(ls.semantic.fqn,col_type,field,message_prefix=f"{rollup_label}: time_dimension ")):yield ts_issue
def _rollup_composite(ctx:ModelValidationContext,ls:_LinkedSemantic,rollup:RollupSpec)->t.Iterable[Issue]:source_specs:t.List[t.Tuple[str,RollupSpec]]=[];yield from _rollup_composite_sources(ctx,ls,rollup,source_specs);yield from _rollup_composite_measures(ctx,ls,rollup,source_specs);yield from _rollup_composite_segments(ctx,ls,rollup,source_specs);yield from _rollup_composite_dimensions(ctx,ls,rollup);yield from _rollup_composite_time_dimension(ctx,ls,rollup)
_ROLLUP_MATERIALIZED_STEPS:tuple[RollupValidator,...]=(_rollup_materialized_identifier,_rollup_materialized_members,_rollup_materialized_rolling_measures,_rollup_materialized_time_dimension,_rollup_materialized_masked_dimensions)
_semantic_materialized_rollups=_foreach(lambda ls:(rollup for rollup in ls.semantic.rollups if not rollup.is_composite),*_ROLLUP_MATERIALIZED_STEPS)
_semantic_composite_rollups=_foreach(lambda ls:(rollup for rollup in ls.semantic.rollups if rollup.is_composite),_rollup_composite)
_semantic_measures=_foreach(lambda ls:ls.semantic.measures,_measure_filters,_measure_body)
_semantic_measure_behaviors=_foreach(lambda ls:ls.semantic.measures,_measure_behavior_time_dimension,_measure_behavior_measure_refs)
_semantic_segments=_foreach(lambda ls:ls.semantic.segments,_segment)
_semantic_joins=_foreach(lambda ls:ls.semantic.joins,_join_target,_join_predicate)
_GRAPH_VALIDATORS:tuple[GraphValidator,...]=(_graph_join_cycles,_graph_unlinked_join_targets)
_SEMANTIC_MODEL_VALIDATORS:tuple[SemanticModelValidator,...]=(_semantic_grains_required,_semantic_joins_require_grains,_semantic_dimension_columns,_semantic_dimension_granularities,_semantic_field_uniqueness,_semantic_measures,_semantic_measure_behaviors,_semantic_segments,_semantic_joins,_semantic_materialized_rollups,_semantic_composite_rollups)
_METRIC_VALIDATORS:tuple[MetricValidator,...]=(_metric_validate,)
def _validate_semantics(ctx:ModelValidationContext)->t.List[Issue]:return _collect_issues(_run_validators(_GRAPH_VALIDATORS,ctx),(issue for name in ctx.semantic_physical_pairs for issue in _run_validators(_SEMANTIC_MODEL_VALIDATORS,ctx,ctx.linked_semantic(name))))
def _validate_metrics(ctx:ModelValidationContext)->t.List[Issue]:return _collect_issues(issue for mm in ctx.metric_models for issue in _run_validators(_METRIC_VALIDATORS,ctx,mm))
def validate_models(models:t.Mapping[str,Model],*,dialect:str,config_path:Path,default_catalog:t.Optional[str]=_A,allow_reciprocal_joins:bool=_B,strict_semantic_validation:bool=_C,metric_join_path:t.Optional[MetricJoinPath]=_A,rollup_schema:t.Optional[str]=_A,physical_table_naming_convention:t.Optional[TableNamingConvention]=_A)->_A:
	from vulcan.core.engine_adapter import max_base_table_identifier_length_for_dialect;ctx=ModelValidationContext(models=models,dialect=dialect,config_path=config_path,default_catalog=default_catalog,allow_reciprocal_joins=allow_reciprocal_joins,strict_semantic_validation=strict_semantic_validation,metric_join_path=metric_join_path,max_identifier_length=max_base_table_identifier_length_for_dialect(dialect),rollup_schema=rollup_schema or c.ROLLUP,physical_table_naming_convention=physical_table_naming_convention or TableNamingConvention.SCHEMA_AND_TABLE)
	if ctx.semantic_models or ctx.metric_models:ctx.extend_issues(_validate_semantics(ctx));ctx.extend_issues(_validate_metrics(ctx))
	if ctx.issues:raise ModelValidationError(ctx)