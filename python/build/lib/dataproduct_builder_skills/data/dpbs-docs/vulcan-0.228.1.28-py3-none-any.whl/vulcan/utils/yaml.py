from __future__ import annotations
_C=True
_B=False
_A=None
import getpass,io,typing as t
from decimal import Decimal
from enum import Enum
from os import getenv
from pathlib import Path
from ruamel import yaml
from ruamel.yaml.constructor import SafeConstructor
from vulcan.core.constants import VAR
from vulcan.core.types import Tag,Term
from vulcan.utils.errors import VulcanError
from vulcan.utils.jinja import ENVIRONMENT,create_var
from vulcan.utils.snake_case import to_snake_case_keys
JINJA_METHODS={'env_var':lambda key,default=_A:getenv(key,default),'user':lambda:getpass.getuser()}
def YAML(typ:t.Optional[str]='safe')->yaml.YAML:yaml_obj=yaml.YAML(typ=typ);yaml_obj.representer.add_representer(Decimal,lambda dumper,data:dumper.represent_str(str(data)));return yaml_obj
class SafeConstructorOverride(SafeConstructor):
	def check_mapping_key(self,node:t.Any,key_node:t.Any,mapping:t.Any,key:t.Any,value:t.Any)->bool:return _C
def load(source:str|Path,raise_if_empty:bool=_C,render_jinja:bool=_C,allow_duplicate_keys:bool=_B,variables:t.Optional[t.Dict[str,t.Any]]=_A,keep_last_duplicate_key:bool=_B,*,to_snake_case:bool=_B,to_snake_case_preserve_paths:t.Optional[t.AbstractSet[str]]=_A)->t.Any:
	path:t.Optional[Path]=_A
	if isinstance(source,Path):
		path=source
		with open(source,'r',encoding='utf-8')as file:source=file.read()
	if render_jinja:source=ENVIRONMENT.from_string(source).render({**JINJA_METHODS,VAR:create_var(variables or{})})
	yaml=YAML()
	if allow_duplicate_keys and keep_last_duplicate_key:yaml.Constructor=SafeConstructorOverride
	yaml.allow_duplicate_keys=allow_duplicate_keys;contents=yaml.load(source)
	if contents is _A:
		if raise_if_empty:error_path=f" '{path}'"if path else'';raise VulcanError(f"YAML source{error_path} can't be empty.")
		return{}
	if to_snake_case and isinstance(contents,dict):contents=to_snake_case_keys(contents,preserve_paths=frozenset(to_snake_case_preserve_paths or()))
	return contents
@t.overload
def dump(value:t.Any,stream:io.IOBase)->_A:...
@t.overload
def dump(value:t.Any)->str:...
def dump(value:t.Any,stream:t.Optional[io.IOBase]=_A)->t.Optional[str]:result=io.StringIO();YAML(typ=_A).dump(value,stream or result);return _A if stream else result.getvalue()
def _serialize_for_yaml(obj:t.Any)->t.Any:
	if isinstance(obj,(Tag,Term)):return str(obj)
	if isinstance(obj,Enum):return obj.value
	if isinstance(obj,set):return[_serialize_for_yaml(item)for item in sorted(obj)]
	if isinstance(obj,dict):return{k:_serialize_for_yaml(v)for(k,v)in obj.items()}
	if isinstance(obj,(list,tuple)):return[_serialize_for_yaml(item)for item in obj]
	return obj
def remove_empty_items(obj:t.Any)->t.Any:
	if isinstance(obj,dict):
		cleaned:t.Dict[t.Any,t.Any]={}
		for(key,value)in obj.items():
			cleaned_value=remove_empty_items(value)
			if cleaned_value not in(_A,'',[],{}):cleaned[key]=cleaned_value
		return cleaned
	if isinstance(obj,list):
		cleaned_list:t.List[t.Any]=[]
		for item in obj:
			cleaned_item=remove_empty_items(item)
			if cleaned_item not in(_A,'',[],{}):cleaned_list.append(cleaned_item)
		return cleaned_list
	return obj
def remove_false_booleans(obj:t.Any)->t.Any:
	if isinstance(obj,dict):
		cleaned:t.Dict[t.Any,t.Any]={}
		for(key,value)in obj.items():
			if value is _B:continue
			cleaned[key]=remove_false_booleans(value)
		return cleaned
	if isinstance(obj,list):return[remove_false_booleans(item)for item in obj if item is not _B]
	return obj
def to_yaml(data:t.Any,*,clean_empty:bool=_C,omit_false_booleans:bool=_B,block_style:bool=_C)->str:
	yaml_formatter=YAML(typ=_A);yaml_formatter.indent(mapping=2,sequence=4,offset=2);yaml_formatter.width=120;yaml_formatter.default_flow_style=_B;yaml_formatter.allow_unicode=_C
	if block_style:
		def represent_dict(dumper:t.Any,map_data:t.Any)->t.Any:return dumper.represent_mapping('tag:yaml.org,2002:map',map_data,flow_style=_B)
		def represent_list(dumper:t.Any,seq_data:t.Any)->t.Any:return dumper.represent_sequence('tag:yaml.org,2002:seq',seq_data,flow_style=_B)
		yaml_formatter.representer.add_representer(dict,represent_dict);yaml_formatter.representer.add_representer(list,represent_list)
	data=_serialize_for_yaml(data)
	if omit_false_booleans:data=remove_false_booleans(data)
	if clean_empty:data=remove_empty_items(data)
	stream=io.StringIO();yaml_formatter.dump(data,stream);return stream.getvalue()