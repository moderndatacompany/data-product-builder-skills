from __future__ import annotations
_A=None
import logging,typing as t
from dataclasses import dataclass
from datetime import timedelta
from hashlib import sha256
import pandas as pd
from vulcan.core.dialect import infer_statement_kind
from vulcan.core.query.fingerprint import sql_fingerprint
from vulcan.utils import JobType
from vulcan.utils.errors import QueryValidationError,rebrand
if t.TYPE_CHECKING:from vulcan.core.state_sync.db.query_history import QueryHistoryState
logger=logging.getLogger(__name__)
QueryHistoryComponent=t.Literal['DQ','PROFILE']
QueryHistoryStatus=t.Literal['SUCCESS','FAILED']
def duration_to_ms(value:t.Any)->t.Optional[int]:
	if isinstance(value,timedelta):return int(value/timedelta(milliseconds=1))
	if isinstance(value,(int,float))and not isinstance(value,bool):return int(value)
	if isinstance(value,str):
		try:return int(pd.to_timedelta(value)/pd.Timedelta(milliseconds=1))
		except ValueError:return
@dataclass
class QueryHistoryRecord:
	sql_text:str;dialect:str;status:QueryHistoryStatus;job_type:JobType;executor:str;fingerprint:str;run_id:t.Optional[str]=_A;duration_ms:t.Optional[int]=_A;request_id:t.Optional[str]=_A;component:t.Optional[QueryHistoryComponent]=_A;normalized_sql:t.Optional[str]=_A;statement_kind:t.Optional[str]=_A;row_count:t.Optional[int]=_A;error_message:t.Optional[str]=_A;warehouse_query_id:t.Optional[str]=_A
	@classmethod
	def from_execution(cls,*,sql_text:str,dialect:str,status:QueryHistoryStatus,job_type:JobType,executor:str,run_id:t.Optional[str]=_A,duration_ms:t.Optional[int]=_A,request_id:t.Optional[str]=_A,component:t.Optional[QueryHistoryComponent]=_A,statement_kind:t.Optional[str]=_A,row_count:t.Optional[int]=_A,error_message:t.Optional[str]=_A,warehouse_query_id:t.Optional[str]=_A)->QueryHistoryRecord:
		try:fingerprint,normalized_sql=sql_fingerprint(sql=sql_text,dialect=dialect)
		except QueryValidationError as exc:logger.warning('query_history: SQL normalization failed; storing raw fingerprint only (dialect=%s, job_type=%s, run_id=%s, request_id=%s, error=%s)',dialect,job_type.value,run_id,request_id,exc.message);fingerprint=sha256(sql_text.encode('utf-8')).hexdigest();normalized_sql=_A
		if statement_kind is _A:statement_kind=infer_statement_kind(sql_text,dialect)
		if error_message:error_message=rebrand(error_message)
		return cls(sql_text=sql_text,dialect=dialect,status=status,job_type=job_type,run_id=run_id,executor=executor,fingerprint=fingerprint,normalized_sql=normalized_sql,duration_ms=duration_ms,request_id=request_id,component=component,statement_kind=statement_kind,row_count=row_count,error_message=error_message,warehouse_query_id=warehouse_query_id)
class QueryHistoryRecorder:
	def __init__(self,state:QueryHistoryState):self._state=state
	def record(self,record:QueryHistoryRecord)->_A:self._state.write_batch([record])