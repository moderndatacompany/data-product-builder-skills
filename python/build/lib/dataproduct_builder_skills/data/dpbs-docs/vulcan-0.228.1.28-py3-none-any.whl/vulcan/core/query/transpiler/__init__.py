from __future__ import annotations
_B=True
_A=None
import os,typing as t
from contextlib import asynccontextmanager
from typing import overload
from schema.auth import SecurityContext
from schema.cube import CubeSchema
from schema.metadata import Metadata
from schema.rest_query import RestQuery
from vulcan.core.config import Config
from vulcan.core.export.cube import build_cube_schema
from vulcan.core.query.transpiler.client import TranspilerClient,make_transpiler_client
from vulcan.core.query.transpiler.types import SemanticQueryContext,TranspileResult
from vulcan.core.query.transpiler import validator
@overload
async def transpile(*,query:RestQuery|str,catalog:Metadata,config:Config,gateway:str,user:str|_A=_A,security_context:SecurityContext,client:TranspilerClient|_A=_A,disable_cube_post_processing:bool=_B,headers:dict[str,str]|_A=_A,include_rollups:bool=_B)->TranspileResult:...
@overload
async def transpile(*,query:RestQuery|str,catalog:CubeSchema,config:Config,gateway:str,user:str|_A=_A,security_context:SecurityContext,client:TranspilerClient|_A=_A,disable_cube_post_processing:bool=_B,headers:dict[str,str]|_A=_A,include_rollups:bool=_B)->TranspileResult:...
async def transpile(*,query:RestQuery|str,catalog:Metadata|CubeSchema,config:Config,gateway:str,user:str|_A=_A,security_context:SecurityContext,client:TranspilerClient|_A=_A,disable_cube_post_processing:bool=_B,headers:dict[str,str]|_A=_A,include_rollups:bool=_B)->TranspileResult:
	async with _using_transpiler_client(client,config)as resolved:resolved_user=(user or'').strip()or os.environ.get('DATAOS_RUN_AS_USER','vulcan');return await _transpile(query=query,catalog=catalog,config=config,gateway=gateway,user=resolved_user,security_context=security_context,client=resolved,disable_cube_post_processing=disable_cube_post_processing,headers=headers,include_rollups=include_rollups)
@asynccontextmanager
async def _using_transpiler_client(client:TranspilerClient|_A,config:Config)->t.AsyncIterator[TranspilerClient]:
	if client is not _A:yield client
	else:
		async with make_transpiler_client(config)as built:yield built
async def _transpile(*,query:RestQuery|str,catalog:Metadata|CubeSchema,config:Config,gateway:str,user:str,security_context:SecurityContext,client:TranspilerClient,disable_cube_post_processing:bool,headers:dict[str,str]|_A,include_rollups:bool)->TranspileResult:
	if isinstance(catalog,Metadata):cube_schema=build_cube_schema(catalog,include_rollups=include_rollups)
	else:
		cube_schema=catalog
		if not include_rollups:cube_schema=cube_schema.strip_pre_aggregations()
	schema=cube_schema.model_dump(mode='json',exclude_none=_B);ctx:SemanticQueryContext|_A=_A
	if isinstance(catalog,Metadata):ctx=validator.validate(query=query,catalog=catalog,user=user,security_context=security_context)
	http_response=await client.transpile(query,schema,config=config,gateway=gateway,user=user,security_context=security_context,disable_cube_post_processing=disable_cube_post_processing,headers=headers);return TranspileResult.from_http_response(http_response,ctx,config=config,gateway=gateway,apply_row_limit=ctx is not _A,wrap_aliases=ctx is not _A)