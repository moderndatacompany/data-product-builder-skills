from __future__ import annotations
_S='last_altered_ts'
_R='start_ts'
_Q='created_ts'
_P='boolean'
_O='end_ts'
_N='bigint'
_M='is_pending_restatement'
_L='is_compacted'
_K='is_removed'
_J='id'
_I='dev_version'
_H='identifier'
_G='is_dev'
_F='version'
_E='name'
_D=True
_C='intervals'
_B=False
_A=None
import typing as t,logging
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.core.state_sync.db.utils import snapshot_name_version_filter,snapshot_id_filter,create_batches,fetchall
from vulcan.core.snapshot import SnapshotIntervals,SnapshotIdLike,SnapshotIdAndVersionLike,SnapshotNameVersionLike,SnapshotTableCleanupTask,SnapshotNameVersion,Snapshot
from vulcan.core.snapshot.definition import Interval
from vulcan.utils import sortable_id
from vulcan.utils.date import now_timestamp
if t.TYPE_CHECKING:import pandas as pd
logger=logging.getLogger(__name__)
INTERVALS=TableSpec(name='_intervals',primary_key=(_J,),columns=(ColumnSpec(_J,indexed=_D),ColumnSpec(_Q,_N),ColumnSpec(_E,indexed=_D),ColumnSpec(_H,'text'),ColumnSpec(_F,indexed=_D),ColumnSpec(_I,indexed=_D),ColumnSpec(_R,_N),ColumnSpec(_O,_N),ColumnSpec(_G,_P),ColumnSpec(_K,_P),ColumnSpec(_L,_P),ColumnSpec(_M,_P),ColumnSpec(_S,_N)))
class IntervalState:
	INTERVAL_BATCH_SIZE=1000;SNAPSHOT_BATCH_SIZE=1000
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A,table_name:t.Optional[str]=_A):self.engine_adapter=engine_adapter;self.intervals_table=exp.table_(table_name or INTERVALS.name,db=schema);self._interval_columns_to_types=INTERVALS.columns_to_types(engine_adapter.dialect)
	def add_snapshots_intervals(self,snapshots_intervals:t.Sequence[SnapshotIntervals])->_A:
		if snapshots_intervals:self._push_snapshot_intervals(snapshots_intervals)
	def remove_intervals(self,snapshot_intervals:t.Sequence[t.Tuple[SnapshotIdAndVersionLike,Interval]],remove_shared_versions:bool=_B)->_A:
		intervals_to_remove:t.Sequence[t.Tuple[t.Union[SnapshotIdAndVersionLike,SnapshotIntervals],Interval]]=snapshot_intervals
		if remove_shared_versions:
			name_version_mapping={s.name_version:interval for(s,interval)in snapshot_intervals};all_snapshots=[]
			for where in snapshot_name_version_filter(self.engine_adapter,name_version_mapping,alias=_A,batch_size=self.SNAPSHOT_BATCH_SIZE):all_snapshots.extend([SnapshotIntervals(name=r[0],identifier=r[1],version=r[2],dev_version=r[3],intervals=[],dev_intervals=[])for r in fetchall(self.engine_adapter,exp.select(_E,_H,_F,_I).from_(self.intervals_table).where(where).distinct())])
			intervals_to_remove=[(snapshot,name_version_mapping[snapshot.name_version])for snapshot in all_snapshots]
		if logger.isEnabledFor(logging.INFO):snapshot_ids=', '.join(str(s.snapshot_id)for(s,_)in intervals_to_remove);logger.info('Removing interval for snapshots: %s',snapshot_ids)
		self.engine_adapter.insert_append(self.intervals_table,_intervals_to_df(intervals_to_remove,is_dev=_B,is_removed=_D),target_columns_to_types=self._interval_columns_to_types,track_rows_processed=_B)
	def get_snapshot_intervals(self,snapshots:t.Collection[SnapshotNameVersionLike])->t.List[SnapshotIntervals]:return self._get_snapshot_intervals(snapshots)[1]
	def compact_intervals(self)->_A:
		interval_ids,snapshot_intervals=self._get_snapshot_intervals(uncompacted_only=_D);logger.info('Compacting %s intervals for %s snapshots',len(interval_ids),len(snapshot_intervals));self._push_snapshot_intervals(snapshot_intervals,is_compacted=_D)
		if interval_ids:
			for interval_id_batch in create_batches(list(interval_ids),batch_size=self.INTERVAL_BATCH_SIZE):self.engine_adapter.delete_from(self.intervals_table,exp.column(_J).isin(*interval_id_batch))
	def refresh_snapshot_intervals(self,snapshots:t.Collection[Snapshot])->t.List[Snapshot]:
		if not snapshots:return[]
		_,intervals=self._get_snapshot_intervals([s for s in snapshots if s.version])
		for s in snapshots:s.intervals=[];s.dev_intervals=[]
		return Snapshot.hydrate_with_intervals_by_version(snapshots,intervals)
	def max_interval_end_per_model(self,snapshots:t.Collection[SnapshotNameVersionLike])->t.Dict[str,int]:
		if not snapshots:return{}
		table_alias=_C;name_col=exp.column(_E,table=table_alias);version_col=exp.column(_F,table=table_alias);result:t.Dict[str,int]={}
		for where in snapshot_name_version_filter(self.engine_adapter,snapshots,alias=table_alias,batch_size=self.SNAPSHOT_BATCH_SIZE):
			query=exp.select(name_col,exp.func('MAX',exp.column(_O,table=table_alias)).as_('max_end_ts')).from_(exp.to_table(self.intervals_table).as_(table_alias)).where(where,copy=_B).where(exp.and_(exp.to_column(_G).not_(),exp.to_column(_K).not_(),exp.to_column(_M).not_()),copy=_B).group_by(name_col,version_col,copy=_B)
			for(name,max_end)in fetchall(self.engine_adapter,query):result[name]=max_end
		return result
	def cleanup_intervals(self,cleanup_targets:t.List[SnapshotTableCleanupTask],expired_snapshot_ids:t.Collection[SnapshotIdLike])->_A:self.compact_intervals();self._delete_intervals_by_version(cleanup_targets);self._delete_intervals_by_dev_version(cleanup_targets);self._update_intervals_for_deleted_snapshots(expired_snapshot_ids)
	def _push_snapshot_intervals(self,snapshots:t.Iterable[t.Union[Snapshot,SnapshotIntervals]],is_compacted:bool=_B)->_A:
		import pandas as pd;new_intervals=[]
		for snapshot in snapshots:
			logger.info('Pushing intervals for snapshot %s',snapshot.snapshot_id)
			for(start_ts,end_ts)in snapshot.intervals:new_intervals.append(_interval_to_df(snapshot,start_ts,end_ts,is_dev=_B,is_compacted=is_compacted,last_altered_ts=snapshot.last_altered_ts))
			for(start_ts,end_ts)in snapshot.dev_intervals:new_intervals.append(_interval_to_df(snapshot,start_ts,end_ts,is_dev=_D,is_compacted=is_compacted,last_altered_ts=snapshot.dev_last_altered_ts))
		for snapshot in snapshots:
			for(start_ts,end_ts)in snapshot.pending_restatement_intervals:new_intervals.append(_interval_to_df(snapshot,start_ts,end_ts,is_dev=_B,is_compacted=is_compacted,is_pending_restatement=_D,last_altered_ts=snapshot.last_altered_ts))
		if new_intervals:self.engine_adapter.insert_append(self.intervals_table,pd.DataFrame(new_intervals),target_columns_to_types=self._interval_columns_to_types,track_rows_processed=_B)
	def _get_snapshot_intervals(self,snapshots:t.Optional[t.Collection[SnapshotNameVersionLike]]=_A,uncompacted_only:bool=_B)->t.Tuple[t.Set[str],t.List[SnapshotIntervals]]:
		if not snapshots and snapshots is not _A:return set(),[]
		query=self._get_snapshot_intervals_query(uncompacted_only);interval_ids:t.Set[str]=set();intervals:t.Dict[t.Tuple[str,str,t.Optional[str],t.Optional[str]],SnapshotIntervals]={}
		for where in snapshot_name_version_filter(self.engine_adapter,snapshots,alias=_C,batch_size=self.SNAPSHOT_BATCH_SIZE)if snapshots else[_A]:
			rows=fetchall(self.engine_adapter,query.where(where))
			for(interval_id,name,identifier,version,dev_version,start,end,is_dev,is_removed,is_pending_restatement,last_altered_ts)in rows:
				interval_ids.add(interval_id);merge_key=name,version,dev_version,identifier;pending_restatement_interval_merge_key=name,version,_A,_A
				if merge_key not in intervals:intervals[merge_key]=SnapshotIntervals(name=name,identifier=identifier,version=version,dev_version=dev_version)
				if pending_restatement_interval_merge_key not in intervals:intervals[pending_restatement_interval_merge_key]=SnapshotIntervals(name=name,identifier=_A,version=version,dev_version=_A)
				if is_removed:
					if is_dev:intervals[merge_key].remove_dev_interval(start,end)
					else:intervals[merge_key].remove_interval(start,end)
				elif is_pending_restatement:intervals[pending_restatement_interval_merge_key].add_pending_restatement_interval(start,end)
				elif is_dev:intervals[merge_key].add_dev_interval(start,end);intervals[merge_key].update_dev_last_altered_ts(last_altered_ts)
				else:intervals[merge_key].add_interval(start,end);intervals[merge_key].update_last_altered_ts(last_altered_ts);intervals[pending_restatement_interval_merge_key].remove_pending_restatement_interval(start,end)
		return interval_ids,[i for i in intervals.values()if not i.is_empty()]
	def _get_snapshot_intervals_query(self,uncompacted_only:bool)->exp.Select:
		A='uncompacted';query=exp.select(_J,exp.column(_E,table=_C),exp.column(_H,table=_C),exp.column(_F,table=_C),exp.column(_I,table=_C),_R,_O,_G,_K,_M,_S).from_(exp.to_table(self.intervals_table).as_(_C)).order_by(exp.column(_E,table=_C),exp.column(_F,table=_C),_Q,_K,_M)
		if uncompacted_only:query.join(exp.select(_E,_F).from_(exp.to_table(self.intervals_table).as_(_C)).where(exp.column(_L).not_()).distinct().subquery(alias=A),on=exp.and_(exp.column(_E,table=_C).eq(exp.column(_E,table=A)),exp.column(_F,table=_C).eq(exp.column(_F,table=A))),copy=_B)
		return query
	def _update_intervals_for_deleted_snapshots(self,snapshot_ids:t.Collection[SnapshotIdLike])->_A:
		if not snapshot_ids:return
		for where in snapshot_id_filter(self.engine_adapter,snapshot_ids,alias=_A,batch_size=self.SNAPSHOT_BATCH_SIZE):self.engine_adapter.update_table(self.intervals_table,{_H:_A,_L:_B},where=where.and_(exp.column(_G)));self.engine_adapter.update_table(self.intervals_table,{_H:_A,_I:_A,_L:_B},where=where.and_(exp.column(_G).not_()))
	def _delete_intervals_by_dev_version(self,targets:t.List[SnapshotTableCleanupTask])->_A:
		dev_keys_to_delete=[SnapshotNameVersion(name=t.snapshot.name,version=t.snapshot.dev_version)for t in targets if t.dev_table_only]
		if not dev_keys_to_delete:return
		for where in snapshot_name_version_filter(self.engine_adapter,dev_keys_to_delete,version_column_name=_I,alias=_A,batch_size=self.SNAPSHOT_BATCH_SIZE):self.engine_adapter.delete_from(self.intervals_table,where.and_(exp.column(_G)))
	def _delete_intervals_by_version(self,targets:t.List[SnapshotTableCleanupTask])->_A:
		non_dev_keys_to_delete=[t.snapshot for t in targets if not t.dev_table_only]
		if not non_dev_keys_to_delete:return
		for where in snapshot_name_version_filter(self.engine_adapter,non_dev_keys_to_delete,alias=_A,batch_size=self.SNAPSHOT_BATCH_SIZE):self.engine_adapter.delete_from(self.intervals_table,where)
def _intervals_to_df(snapshot_intervals:t.Sequence[t.Tuple[t.Union[SnapshotIdAndVersionLike,SnapshotIntervals],Interval]],is_dev:bool,is_removed:bool)->pd.DataFrame:import pandas as pd;return pd.DataFrame([_interval_to_df(s,*interval,is_dev=is_dev,is_removed=is_removed)for(s,interval)in snapshot_intervals])
def _interval_to_df(snapshot:t.Union[SnapshotIdAndVersionLike,SnapshotIntervals],start_ts:int,end_ts:int,is_dev:bool=_B,is_removed:bool=_B,is_compacted:bool=_B,is_pending_restatement:bool=_B,last_altered_ts:t.Optional[int]=_A)->t.Dict[str,t.Any]:return{_J:sortable_id(),_Q:now_timestamp(),_E:snapshot.name,_H:snapshot.identifier if not is_pending_restatement else _A,_F:snapshot.version,_I:snapshot.dev_version if not is_pending_restatement else _A,_R:start_ts,_O:end_ts,_G:is_dev,_K:is_removed,_L:is_compacted,_M:is_pending_restatement,_S:last_altered_ts}