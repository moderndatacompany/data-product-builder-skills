from __future__ import annotations
_r='SecurityContext'
_q='directed'
_p='sortMethod'
_o='direction'
_n='nodeSpacing'
_m='hierarchical'
_l='dragNodes'
_k='navigationButtons'
_j='tooltipDelay'
_i='selectConnectedEdges'
_h='hoverConnectedEdges'
_g='layout'
_f='interaction'
_e='height'
_d='#673AB7'
_c='#EDE7F6'
_b='run_id'
_a='event_type'
_Z='RunDqCounts'
_Y='plan_id'
_X='ModelIntervalAudits'
_W='QueryHistoryRecorder'
_V='environment'
_U='utf-8'
_T='dialect'
_S='models'
_R='.html'
_Q='100%'
_P='#512DA8'
_O='#D1C4E9'
_N='ErrorExec'
_M='font'
_L='highlight'
_K='ModelExec'
_J='from'
_I='title'
_H='to'
_G='hover'
_F='label'
_E='border'
_D='background'
_C=True
_B=False
_A=None
import abc,atexit,collections,logging,os,sys,time,traceback,typing as t
from dataclasses import dataclass
from functools import cached_property
from io import StringIO
from itertools import chain
from pathlib import Path
from shutil import rmtree
from types import MappingProxyType
from datetime import datetime
from packaging.version import Version
from sqlglot import Dialect,exp
from sqlglot.helper import first
from sqlglot.lineage import GraphHTML
from vulcan.core import prometheus
from vulcan.core import constants as c
from vulcan.core.audit import Audit,ModelAudit,StandaloneAudit
from vulcan.core.config import CategorizerConfig,Config,load_configs
from vulcan.core.config.connection import ConnectionConfig
from vulcan.core.config.loader import C
from vulcan.core.config.root import RegexKeyDict
from vulcan.core.console import get_console,RunActivityCapturingConsole
from vulcan.core.context_diff import ContextDiff
from vulcan.core.dialect import format_model_expressions,fqn_to_unquoted,is_meta_expression,normalize_model_name,pandas_to_sql,parse,parse_one
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.environment import Environment,EnvironmentNamingInfo,EnvironmentStatements
from vulcan.core.loader import Loader
from vulcan.core.linter.definition import AnnotatedRuleViolation,Linter
from vulcan.core.linter.source import project_lint_source
from vulcan.core.linter.rules import BUILTIN_RULES
from vulcan.core.macros import ExecutableOrMacro,macro
from vulcan.core.metric import Metric
from vulcan.core.model import Model,SemanticModel,update_model_schemas
from vulcan.core.model.kind import ModelKindName
from vulcan.core.config.model import ModelDefaultsConfig
from vulcan.core.notification import DbNotificationTarget,NotificationEvent,NotificationTarget,NotificationTargetManager
from vulcan.core.plan import Plan,PlanBuilder,SnapshotIntervals,PlanExplainer
from vulcan.core.plan.definition import UserProvidedFlags
from vulcan.core.scheduler import Scheduler,CompletionStatus
from vulcan.core.schema_loader import create_external_models_file
from vulcan.core.selector import Selector,NativeSelector
from vulcan.core.snapshot import DeployabilityIndex,Snapshot,SnapshotEvaluator,SnapshotFingerprint,missing_intervals,to_table_mapping
from vulcan.core.snapshot.definition import get_next_model_interval_start
from vulcan.core.state_sync import CachingStateSync,StateReader,StateSync
from vulcan.core.janitor import cleanup_expired_views,delete_expired_snapshots
from vulcan.core.table_diff import TableDiff
from vulcan.core.test import ModelTextTestResult,ModelTestMetadata,generate_test,run_tests,filter_tests_by_patterns
from vulcan.core.user import User
from vulcan.utils import CorrelationId,JobTypeValues,UniqueKeyDict,Verbosity,sortable_id
from vulcan.utils.concurrency import concurrent_apply_to_values
from vulcan.utils.dag import DAG
from vulcan.utils.date import TimeLike,to_timestamp,format_tz_datetime,now_timestamp,now,to_datetime,make_exclusive
from vulcan.utils.errors import CircuitBreakerError,ConfigError,PlanError,VulcanError,TranspilerError,UncategorizedPlanError,LinterError
from vulcan.utils.config import print_config
from vulcan.utils.git import GitClient
from vulcan.utils.jinja import JinjaMacroRegistry
from vulcan.utils.windows import IS_WINDOWS,fix_windows_path
if t.TYPE_CHECKING:import pandas as pd;from typing_extensions import Literal;from vulcan.core.activity import ModelIntervalAudits,PlanActivity,ErrorExec,ModelExec;from vulcan.core.engine_adapter._typing import BigframeSession,DF,PySparkDataFrame,PySparkSession,SnowparkSession;from vulcan.core.query.history import QueryHistoryRecorder;from vulcan.core.snapshot import Node;from vulcan.core.snapshot.definition import Intervals;from vulcan.core.export.metadata import Metadata;from schema.auth import SecurityContext;from schema.cube import CubeSchema;from schema.odcs_contract import OdcsContract;from schema.odps_spec import OdpsProduct;from schema.rest_query import RestQuery;from vulcan.core.query.rewriter import RewriteResult;from vulcan.core.query.transpiler import TranspileResult;ModelOrSnapshot=t.Union[str,Model,Snapshot];NodeOrSnapshot=t.Union[str,Model,StandaloneAudit,Snapshot]
logger=logging.getLogger(__name__)
@dataclass(frozen=_C)
class LineageMappingSchema:schema:t.Dict[str,t.Any];physical_table_index:t.Dict[str,str]
class BaseContext(abc.ABC):
	@property
	@abc.abstractmethod
	def default_dialect(self)->t.Optional[str]:0
	@property
	@abc.abstractmethod
	def _model_tables(self)->t.Dict[str,str]:0
	@property
	@abc.abstractmethod
	def engine_adapter(self)->EngineAdapter:0
	@property
	def spark(self)->t.Optional[PySparkSession]:return self.engine_adapter.spark
	@property
	def snowpark(self)->t.Optional[SnowparkSession]:return self.engine_adapter.snowpark
	@property
	def bigframe(self)->t.Optional[BigframeSession]:return self.engine_adapter.bigframe
	@property
	def default_catalog(self)->t.Optional[str]:raise NotImplementedError
	def table(self,model_name:str)->str:get_console().log_warning("The Vulcan context's `table` method is deprecated and will be removed in a future release. Please use the `resolve_table` method instead.");return self.resolve_table(model_name)
	def resolve_table(self,model_name:str)->str:
		model_name=normalize_model_name(model_name,self.default_catalog,self.default_dialect)
		if model_name not in self._model_tables:model_name_list='\n'.join(list(self._model_tables));logger.debug(f"'{model_name}' not found in model to table mapping. Available model names: \n{model_name_list}");raise VulcanError(f"Unable to find a table mapping for model '{model_name}'. Has it been spelled correctly?")
		return parse_one(self._model_tables[model_name]).sql(dialect=self.default_dialect,identify=_C)
	def fetchdf(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_B)->pd.DataFrame:return self.engine_adapter.fetchdf(query,quote_identifiers=quote_identifiers)
	def fetchdf_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_B)->pd.DataFrame:return self.engine_adapter.fetchdf_with_params(query,params,quote_identifiers=quote_identifiers)
	def fetch_pyspark_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_B)->PySparkDataFrame:return self.engine_adapter.fetch_pyspark_df(query,quote_identifiers=quote_identifiers)
class ExecutionContext(BaseContext):
	def __init__(self,engine_adapter:EngineAdapter,snapshots:t.Dict[str,Snapshot],deployability_index:t.Optional[DeployabilityIndex]=_A,default_dialect:t.Optional[str]=_A,default_catalog:t.Optional[str]=_A,is_restatement:t.Optional[bool]=_A,parent_intervals:t.Optional[Intervals]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A,config:t.Optional[Config]=_A):self.snapshots=snapshots;self.deployability_index=deployability_index;self._engine_adapter=engine_adapter;self._default_catalog=default_catalog;self._default_dialect=default_dialect;self._variables=variables or{};self._blueprint_variables=blueprint_variables or{};self._is_restatement=is_restatement;self._parent_intervals=parent_intervals;self.config=config
	@property
	def default_dialect(self)->t.Optional[str]:return self._default_dialect
	@property
	def engine_adapter(self)->EngineAdapter:return self._engine_adapter
	@cached_property
	def _model_tables(self)->t.Dict[str,str]:return to_table_mapping(self.snapshots.values(),self.deployability_index)
	@property
	def default_catalog(self)->t.Optional[str]:return self._default_catalog
	@property
	def gateway(self)->t.Optional[str]:return self.var(c.GATEWAY)
	@property
	def is_restatement(self)->t.Optional[bool]:return self._is_restatement
	@property
	def parent_intervals(self)->t.Optional[Intervals]:return self._parent_intervals
	def var(self,var_name:str,default:t.Optional[t.Any]=_A)->t.Optional[t.Any]:return self._variables.get(var_name.lower(),default)
	def blueprint_var(self,var_name:str,default:t.Optional[t.Any]=_A)->t.Optional[t.Any]:return self._blueprint_variables.get(var_name.lower(),default)
	def with_variables(self,variables:t.Dict[str,t.Any],blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A)->ExecutionContext:return ExecutionContext(self._engine_adapter,self.snapshots,self.deployability_index,self._default_dialect,self._default_catalog,self._is_restatement,variables=variables,blueprint_variables=blueprint_variables,config=self.config)
class GenericContext(BaseContext,t.Generic[C]):
	CONFIG_TYPE:t.Type[C];PLAN_BUILDER_TYPE=PlanBuilder
	def __init__(self,notification_targets:t.Optional[t.List[NotificationTarget]]=_A,state_sync:t.Optional[StateSync]=_A,paths:t.Union[str|Path,t.Iterable[str|Path]]='',config:t.Optional[t.Union[C,str,t.Dict[Path,C]]]=_A,gateway:t.Optional[str]=_A,concurrent_tasks:t.Optional[int]=_A,loader:t.Optional[t.Type[Loader]]=_A,load:bool=_C,users:t.Optional[t.List[User]]=_A,config_loader_kwargs:t.Optional[t.Dict[str,t.Any]]=_A,selector:t.Optional[t.Type[Selector]]=_A):
		self.configs=config if isinstance(config,dict)else load_configs(config,self.CONFIG_TYPE,paths,**config_loader_kwargs or{});self._projects={config.project for config in self.configs.values()};(self.dag):DAG[str]=DAG();(self._models):UniqueKeyDict[str,Model]=UniqueKeyDict(_S);(self._audits):UniqueKeyDict[str,ModelAudit]=UniqueKeyDict('audits');(self._standalone_audits):UniqueKeyDict[str,StandaloneAudit]=UniqueKeyDict('standaloneaudits');(self._model_test_metadata):t.List[ModelTestMetadata]=[];(self._model_test_metadata_path_index):t.Dict[Path,t.List[ModelTestMetadata]]={};(self._model_test_metadata_fully_qualified_name_index):t.Dict[str,ModelTestMetadata]={};(self._models_with_tests):t.Set[str]=set();(self._macros):UniqueKeyDict[str,ExecutableOrMacro]=UniqueKeyDict('macros');(self._metrics):UniqueKeyDict[str,Metric]=UniqueKeyDict('metrics');self._jinja_macros=JinjaMacroRegistry();(self._requirements):t.Dict[str,str]={};(self._environment_statements):t.List[EnvironmentStatements]=[];(self._excluded_requirements):t.Set[str]=set();(self._engine_adapter):t.Optional[EngineAdapter]=_A;(self._linters):t.Dict[str,Linter]={};(self._loaded):bool=_B;self._selector_cls=selector or NativeSelector;self.path,self.config=t.cast(t.Tuple[Path,C],next(iter(self.configs.items())));self.config._project_root=self.path.resolve();(self._all_dialects):t.Set[str]={self.config.dialect or''};prometheus.init_from_config(self.config.prometheus,tenant=self.config.tenant,data_product=self.config.project,version=self.config.version,dataplane_name=os.environ.get('DATAOS_DATAPLANE_NAME',''),dataplane_network_type=os.environ.get('DATAOS_DATAPLANE_NETWORK_TYPE',''),dataplane_type=os.environ.get('DATAOS_DATAPLANE_TYPE',''),dataos_fqdn=os.environ.get('DATAOS_FQDN',''),resource_id=os.environ.get('DATAOS_RESOURCE_ID',''),resource_type=os.environ.get('DATAOS_TYPE',''),instance_name=os.environ.get('DATAOS_INSTANCE_TENANT_ID',''),user_name=os.environ.get('DATAOS_RUN_AS_USER',''));self.gateway=gateway;self._scheduler=self.config.get_scheduler(self.gateway);self.environment_ttl=self.config.environment_ttl;self.pinned_environments=Environment.sanitize_names(self.config.pinned_environments);self.auto_categorize_changes=self.config.plan.auto_categorize_changes;self.selected_gateway=(gateway or self.config.default_gateway_name).lower();gw_model_defaults=self.config.get_gateway(self.selected_gateway).model_defaults
		if gw_model_defaults:global_defaults=self.config.model_defaults.model_dump(exclude_unset=_C);gateway_defaults=gw_model_defaults.model_dump(exclude_unset=_C);self.config.model_defaults=ModelDefaultsConfig(**{**global_defaults,**gateway_defaults})
		if'normalization_strategy'in str(self.config.dialect):dialect=Dialect.get_or_raise(self.config.dialect);type(dialect).NORMALIZATION_STRATEGY=dialect.normalization_strategy
		self._loaders=[(loader or config.loader)(self,path,**config.loader_kwargs)for(path,config)in self.configs.items()];self._concurrent_tasks=concurrent_tasks;self._state_connection_config=self.config.get_state_connection(self.gateway)or self.connection_config;(self._snapshot_evaluator):t.Optional[SnapshotEvaluator]=_A;(self._query_history_recorder):t.Optional[_W]=_A;self.console=get_console();setattr(self.console,_T,self.config.dialect);(self._provided_state_sync):t.Optional[StateSync]=state_sync;(self._state_sync):t.Optional[StateSync]=_A;self.notification_targets=(notification_targets or[])+self.config.notification_targets;self.users=(users or[])+self.config.users;self.users=list({user.username:user for user in self.users}.values());self._register_notification_targets();atexit.register(self.shutdown_for_exit);self._register_user_agent_to_connections()
		if load:self.load()
	@cached_property
	def known_users(self)->frozenset[str]:return frozenset((user.username or'').strip()for user in self.config.users if(user.username or'').strip())
	@cached_property
	def git_client(self)->GitClient:return GitClient(self.path)
	@property
	def default_dialect(self)->t.Optional[str]:return self.config.dialect
	@cached_property
	def user_agent(self)->str:
		from vulcan import __version__ as package_version;build_version=(os.getenv('VULCAN_VERSION')or'').strip()
		if build_version and Version(build_version)!=Version(package_version):raise ConfigError(f"Vulcan version mismatch: image={build_version}, package={package_version}")
		vulcan_version=build_version or package_version;return f"DataOS Vulcan {vulcan_version}; {self.config.tenant}/{self.config.project}/{self.config.version}"
	def _register_user_agent_to_connections(self)->_A:
		user_agent=self.user_agent
		for config in self.configs.values():
			for gateway in config.gateways.values():
				for connection in(gateway.connection,gateway.state_connection,gateway.test_connection):
					if connection is not _A:connection.user_agent=user_agent
			if config.state:config.state.user_agent=user_agent
	@property
	def engine_adapter(self)->EngineAdapter:
		if self._engine_adapter is _A:self._engine_adapter=self.connection_config.create_engine_adapter()
		return self._engine_adapter
	@property
	def query_history_recorder(self)->_W:
		if self._query_history_recorder is _A:from vulcan.core.query.history import QueryHistoryRecorder;self._query_history_recorder=QueryHistoryRecorder(self.state_sync.query_history_state)
		return self._query_history_recorder
	def _ad_hoc_query_engine_adapter(self)->EngineAdapter:return self.engine_adapter.with_settings(correlation_id=CorrelationId.from_query_id(sortable_id()),query_history_recorder=self.query_history_recorder)
	def fetchdf(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_B)->pd.DataFrame:return self._ad_hoc_query_engine_adapter().fetchdf(query,quote_identifiers=quote_identifiers)
	def fetchdf_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_B)->pd.DataFrame:return self._ad_hoc_query_engine_adapter().fetchdf_with_params(query,params,quote_identifiers=quote_identifiers)
	@property
	def snapshot_evaluator(self)->SnapshotEvaluator:
		if not self._snapshot_evaluator:self._snapshot_evaluator=SnapshotEvaluator({gateway:adapter.with_settings(execute_log_level=logging.INFO)for(gateway,adapter)in self.engine_adapters.items()},ddl_concurrent_tasks=self.concurrent_tasks,selected_gateway=self.selected_gateway,config=self.config,query_history_recorder=self.query_history_recorder)
		return self._snapshot_evaluator
	def execution_context(self,deployability_index:t.Optional[DeployabilityIndex]=_A,engine_adapter:t.Optional[EngineAdapter]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A)->ExecutionContext:return ExecutionContext(engine_adapter=engine_adapter or self.engine_adapter,snapshots=snapshots or self.snapshots,deployability_index=deployability_index,default_dialect=self.default_dialect,default_catalog=self.default_catalog,config=self.config)
	def upsert_model(self,model:t.Union[str,Model],**kwargs:t.Any)->Model:
		model=self.get_model(model,raise_if_missing=_C)
		if not model.enabled:raise VulcanError(f"The disabled model '{model.name}' cannot be upserted")
		path=model._path;model=model.copy(update=kwargs);model._path=path;self.dag.add(model.fqn,model.depends_on);self._models.update({model.fqn:model,**{fqn:self._models[fqn].copy()for fqn in self.dag.downstream(model.fqn)}});update_model_schemas(self.dag,models=self._models,cache_dir=self.cache_dir)
		if model.dialect:self._all_dialects.add(model.dialect)
		model.validate_definition(known_users=self.known_users);return model
	def scheduler(self,environment:t.Optional[str]=_A,snapshot_evaluator:t.Optional[SnapshotEvaluator]=_A)->Scheduler:
		snapshots:t.Iterable[Snapshot]
		if environment is not _A:
			stored_environment=self.state_sync.get_environment(environment)
			if stored_environment is _A:raise ConfigError(f"Environment '{environment}' was not found.")
			snapshots=self.state_sync.get_snapshots(stored_environment.snapshots).values()
		else:snapshots=self.snapshots.values()
		if not snapshots:raise ConfigError('No models were found')
		return self.create_scheduler(snapshots,snapshot_evaluator or self.snapshot_evaluator)
	def create_scheduler(self,snapshots:t.Iterable[Snapshot],snapshot_evaluator:SnapshotEvaluator)->Scheduler:return Scheduler(snapshots,snapshot_evaluator,self.state_sync,default_catalog=self.default_catalog,max_workers=self.concurrent_tasks,console=self.console,notification_target_manager=self.notification_target_manager)
	@property
	def state_sync(self)->StateSync:
		if not self._state_sync:
			self._state_sync=self._new_state_sync()
			if self._state_sync.get_versions(validate=_B).schema_version==0:self.console.log_status_update('Initializing new project state...');self._state_sync.migrate()
			self._state_sync.get_versions();self._state_sync=CachingStateSync(self._state_sync)
		return self._state_sync
	@property
	def state_reader(self)->StateReader:return self.state_sync
	def refresh(self)->_A:
		if any(loader.reload_needed()for loader in self._loaders):self.load()
	def load(self,update_schemas:bool=_C)->GenericContext[C]:
		load_start_ts=time.perf_counter();validate_models=update_schemas;loaded_projects=[loader.load(validate_models=validate_models)for loader in self._loaders];self.dag=DAG();self._standalone_audits.clear();self._audits.clear();self._macros.clear();self._models.clear();self.__dict__.pop('lineage_mapping_schema',_A);self._metrics.clear();self._requirements.clear();self._excluded_requirements.clear();self._linters.clear();self._environment_statements=[];self._model_test_metadata.clear();self._model_test_metadata_path_index.clear();self._model_test_metadata_fully_qualified_name_index.clear();self._models_with_tests.clear()
		for(loader,project)in zip(self._loaders,loaded_projects):
			self._jinja_macros=self._jinja_macros.merge(project.jinja_macros);self._macros.update(project.macros);self._models.update(project.models);self._metrics.update(project.metrics);self._audits.update(project.audits);self._standalone_audits.update(project.standalone_audits);self._requirements.update(project.requirements);self._excluded_requirements.update(project.excluded_requirements);self._environment_statements.extend(project.environment_statements);self._model_test_metadata.extend(project.model_test_metadata)
			for metadata in project.model_test_metadata:
				if metadata.path not in self._model_test_metadata_path_index:self._model_test_metadata_path_index[metadata.path]=[]
				self._model_test_metadata_path_index[metadata.path].append(metadata);self._model_test_metadata_fully_qualified_name_index[metadata.fully_qualified_test_name]=metadata;self._models_with_tests.add(metadata.model_name)
			config=loader.config;self._linters[config.project]=Linter.from_rules(BUILTIN_RULES.union(project.user_rules),config.linter)
		if any(self._projects):
			prod=self.state_reader.get_environment(c.PROD)
			if prod:
				existing_statements=self.state_reader.get_environment_statements(c.PROD)
				for stmt in existing_statements:
					if stmt.project and stmt.project not in self._projects:self._environment_statements.append(stmt)
		uncached=set()
		if any(self._projects):
			prod=self.state_reader.get_environment(c.PROD)
			if prod:
				for snapshot in self.state_reader.get_snapshots(prod.snapshots).values():
					if snapshot.node.project in self._projects:uncached.add(snapshot.name)
					else:store=self._standalone_audits if snapshot.is_audit else self._models;store[snapshot.name]=snapshot.node
		for model in self._models.values():self.dag.add(model.fqn,model.depends_on)
		if update_schemas:
			for fqn in self.dag:
				model=self._models.get(fqn)
				if not model or fqn in uncached:continue
				if any(dep in uncached for dep in model.depends_on):uncached.add(fqn);self._models.update({fqn:model.copy(update={'mapping_schema':{}})});continue
			update_model_schemas(self.dag,models=self._models,cache_dir=self.cache_dir);models=self.models.values()
			for model in models:model.validate_definition(known_users=self.known_users)
		duplicates=set(self._models)&set(self._standalone_audits)
		if duplicates:raise ConfigError(f"Models and Standalone audits cannot have the same name: {duplicates}")
		self._all_dialects={m.dialect for m in self._models.values()if m.dialect}|{self.default_dialect or''};self._loaded=_C;return self
	def run(self,environment:t.Optional[str]=_A,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,skip_janitor:bool=_B,ignore_cron:bool=_B,select_models:t.Optional[t.Collection[str]]=_A,exit_on_env_update:t.Optional[int]=_A,no_auto_upstream:bool=_B)->CompletionStatus:
		environment=environment or self.config.default_target_environment;environment=Environment.sanitize_name(environment)
		if not skip_janitor and environment.lower()==c.PROD:self._run_janitor()
		run_id=sortable_id();self.notification_target_manager.notify(NotificationEvent.RUN_START,environment=environment,run_id=run_id);self._load_materializations();env_check_attempts_num=max(1,self.config.run.environment_check_max_wait//self.config.run.environment_check_interval)
		def _block_until_finalized()->str:
			for _ in range(env_check_attempts_num):
				assert environment is not _A;environment_state=self.state_sync.get_environment(environment)
				if not environment_state:raise VulcanError(f"Environment '{environment}' was not found.")
				if environment_state.finalized_ts:return environment_state.plan_id
				self.console.log_warning(f"Environment '{environment}' is being updated by plan '{environment_state.plan_id}'. Retrying in {self.config.run.environment_check_interval} seconds...");time.sleep(self.config.run.environment_check_interval)
			raise VulcanError(f"Exceeded the maximum wait time for environment '{environment}' to be ready. This means that the environment either failed to update or the update is taking longer than expected. See https://vulcan.readthedocs.io/en/stable/reference/configuration/#run to adjust the timeout settings.")
		success=_B;interrupted=_B;done=_B;run_start_ts=0;completion_status=CompletionStatus.FAILURE
		while not done:
			plan_id_at_start=_block_until_finalized()
			def _has_environment_changed()->bool:assert environment is not _A;current_environment_state=self.state_sync.get_environment(environment);return not current_environment_state or current_environment_state.plan_id!=plan_id_at_start or not current_environment_state.finalized_ts
			try:run_start_ts=int(round(time.time()*1000));completion_status=self._run(environment,start=start,end=end,execution_time=execution_time,ignore_cron=ignore_cron,select_models=select_models,circuit_breaker=_has_environment_changed,no_auto_upstream=no_auto_upstream,run_id=run_id);done=_C
			except CircuitBreakerError:
				self.console.log_warning(f"Environment '{environment}' modified while running. Restarting the run...")
				if exit_on_env_update:interrupted=_C;done=_C
			except Exception as e:
				partial_activity=_A
				if isinstance(self.console,RunActivityCapturingConsole):
					try:
						models,audits,errors,_=self.console.get_run_capture()
						if models:from vulcan.core.activity import RunActivity;partial_activity=RunActivity(run_id=run_id,plan_id=plan_id_at_start,environment=environment,start_ts=run_start_ts,end_ts=int(round(time.time()*1000)),models_affected=models,errors=errors,audits=audits,success=_B)
					except Exception:pass
				self._finalize_run_and_persist_activity(run_id=run_id,plan_id=plan_id_at_start,environment=environment,run_start_ts=run_start_ts,exception=e,start=start,end=end,execution_time=execution_time);self.notification_target_manager.notify(NotificationEvent.RUN_FAILURE,environment=environment,run_id=run_id,exc=traceback.format_exc());logger.info('Run failed.',exc_info=e);raise e
		self._finalize_run_and_persist_activity(run_id=run_id,plan_id=plan_id_at_start,environment=environment,run_start_ts=run_start_ts,start=start,end=end,execution_time=execution_time,completion_status=completion_status,interrupted=interrupted)
		if completion_status.is_success or completion_status.is_nothing_to_do or interrupted:
			self.notification_target_manager.notify(NotificationEvent.RUN_END,environment=environment,run_id=run_id,nothing_to_do=completion_status.is_nothing_to_do,interrupted=interrupted)
			if completion_status.is_success or interrupted:self.console.log_success(f"Run finished for environment '{environment}'")
		elif completion_status.is_failure:self.notification_target_manager.notify(NotificationEvent.RUN_FAILURE,environment=environment,run_id=run_id,exc='See logs for details.')
		if interrupted and exit_on_env_update is not _A:sys.exit(exit_on_env_update)
		return completion_status
	def run_janitor(self,ignore_ttl:bool)->bool:
		success=_B
		if self.console.start_cleanup(ignore_ttl):
			try:self._run_janitor(ignore_ttl);success=_C
			finally:self.console.stop_cleanup(success=success)
		return success
	def destroy(self)->bool:
		success=_B;environments=self.state_reader.get_environments();schemas_to_delete=set();tables_to_delete=set();views_to_delete=set();all_snapshot_infos=set()
		for environment in environments:
			all_snapshot_infos.update(environment.snapshots);snapshots=self.state_reader.get_snapshots(environment.snapshots).values()
			for snapshot in snapshots:
				if snapshot.is_model and not snapshot.is_symbolic:
					if environment.gateway_managed and snapshot.model_gateway:adapter=self.engine_adapters.get(snapshot.model_gateway,self.engine_adapter)
					else:adapter=self.engine_adapter
					if environment.suffix_target.is_schema or environment.suffix_target.is_catalog:
						schema=snapshot.qualified_view_name.schema_for_environment(environment.naming_info,dialect=adapter.dialect);catalog=snapshot.qualified_view_name.catalog_for_environment(environment.naming_info,dialect=adapter.dialect)
						if catalog:schemas_to_delete.add(f"{catalog}.{schema}")
						else:schemas_to_delete.add(schema)
					if environment.suffix_target.is_table:view_name=snapshot.qualified_view_name.for_environment(environment.naming_info,dialect=adapter.dialect);views_to_delete.add(view_name)
					table_name=snapshot.table_name();tables_to_delete.add(table_name)
		if self.console.start_destroy(schemas_to_delete,views_to_delete,tables_to_delete):
			try:success=self._destroy()
			finally:self.console.stop_destroy(success=success)
		return success
	@t.overload
	def get_model(self,model_or_snapshot:ModelOrSnapshot,raise_if_missing:Literal[_C]=_C)->Model:...
	@t.overload
	def get_model(self,model_or_snapshot:ModelOrSnapshot,raise_if_missing:Literal[_B]=_B)->t.Optional[Model]:...
	def get_model(self,model_or_snapshot:ModelOrSnapshot,raise_if_missing:bool=_B)->t.Optional[Model]:
		if isinstance(model_or_snapshot,Snapshot):return model_or_snapshot.model
		if not isinstance(model_or_snapshot,str):return model_or_snapshot
		try:
			for dialect in self._all_dialects:
				normalized_name=normalize_model_name(model_or_snapshot,dialect=dialect,default_catalog=self.default_catalog)
				if normalized_name in self._models:return self._models[normalized_name]
		except:pass
		if raise_if_missing:
			if model_or_snapshot.endswith(('.sql','.py')):msg='Resolving models by path is not supported, please pass in the model name instead.'
			else:msg=f"Cannot find model with name '{model_or_snapshot}'"
			raise VulcanError(msg)
	@t.overload
	def get_snapshot(self,node_or_snapshot:NodeOrSnapshot)->t.Optional[Snapshot]:...
	@t.overload
	def get_snapshot(self,node_or_snapshot:NodeOrSnapshot,raise_if_missing:Literal[_C])->Snapshot:...
	@t.overload
	def get_snapshot(self,node_or_snapshot:NodeOrSnapshot,raise_if_missing:Literal[_B])->t.Optional[Snapshot]:...
	def get_snapshot(self,node_or_snapshot:NodeOrSnapshot,raise_if_missing:bool=_B)->t.Optional[Snapshot]:
		if isinstance(node_or_snapshot,Snapshot):return node_or_snapshot
		fqn=self._node_or_snapshot_to_fqn(node_or_snapshot);snapshot=self.snapshots.get(fqn)
		if raise_if_missing and not snapshot:raise VulcanError(f"Cannot find snapshot for '{fqn}'")
		return snapshot
	def config_for_path(self,path:Path)->t.Tuple[Config,Path]:
		for(config_path,config)in self.configs.items():
			try:path.relative_to(config_path);return config,config_path
			except ValueError:pass
		return self.config,self.path
	def config_for_node(self,node:Model|Audit)->Config:
		path=node._path
		if path is _A:return self.config
		return self.config_for_path(path)[0]
	@property
	def models(self)->MappingProxyType[str,Model]:return MappingProxyType(self._models)
	@property
	def metrics(self)->MappingProxyType[str,Metric]:return MappingProxyType(self._metrics)
	@property
	def standalone_audits(self)->MappingProxyType[str,StandaloneAudit]:return MappingProxyType(self._standalone_audits)
	@property
	def models_with_tests(self)->t.Set[str]:return self._models_with_tests
	@property
	def snapshots(self)->t.Dict[str,Snapshot]:return self._snapshots()
	@property
	def requirements(self)->t.Dict[str,str]:return self._requirements.copy()
	@cached_property
	def default_catalog(self)->t.Optional[str]:return self.default_catalog_per_gateway.get(self.selected_gateway)
	def render(self,model_or_snapshot:ModelOrSnapshot,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,expand:t.Union[bool,t.Iterable[str]]=_B,**kwargs:t.Any)->exp.Expression:
		execution_time=execution_time or now();model=self.get_model(model_or_snapshot,raise_if_missing=_C)
		if expand and not isinstance(expand,bool):expand={normalize_model_name(x,default_catalog=self.default_catalog,dialect=self.default_dialect)for x in expand}
		expand=self.dag.upstream(model.fqn)if expand is _C else expand or[]
		if model.is_seed:import pandas as pd;df=next(model.render(context=self.execution_context(engine_adapter=self._get_engine_adapter(model.gateway)),start=start,end=end,execution_time=execution_time,**kwargs));return next(pandas_to_sql(t.cast(pd.DataFrame,df),model.columns_to_types))
		snapshots=self.snapshots;deployability_index=DeployabilityIndex.create(snapshots.values(),start=start);return model.render_query_or_raise(start=start,end=end,execution_time=execution_time,snapshots=snapshots,expand=expand,deployability_index=deployability_index,engine_adapter=self._get_engine_adapter(model.gateway),config=self.config_for_node(model),**kwargs)
	def evaluate(self,model_or_snapshot:ModelOrSnapshot,start:TimeLike,end:TimeLike,execution_time:TimeLike,limit:t.Optional[int]=_A,**kwargs:t.Any)->DF:
		snapshots=self.snapshots;fqn=self._node_or_snapshot_to_fqn(model_or_snapshot)
		if fqn not in snapshots:raise VulcanError(f"Cannot find snapshot for '{fqn}'")
		snapshot=snapshots[fqn];expand=[parent for parent in self.dag.upstream(snapshot.model.fqn)if(parent_snapshot:=snapshots.get(parent))and parent_snapshot.is_model and parent_snapshot.model.is_sql and not parent_snapshot.categorized];df=self.snapshot_evaluator.evaluate_and_fetch(snapshot,start=start,end=end,execution_time=execution_time,snapshots=self.snapshots,limit=limit or c.DEFAULT_MAX_LIMIT,expand=expand)
		if df is _A:raise RuntimeError(f"Error evaluating {snapshot.name}")
		return df
	def format(self,transpile:t.Optional[str]=_A,rewrite_casts:t.Optional[bool]=_A,append_newline:t.Optional[bool]=_A,*,check:t.Optional[bool]=_A,paths:t.Optional[t.Tuple[t.Union[str,Path],...]]=_A,**kwargs:t.Any)->bool:
		filtered_targets=[target for target in chain(self._models.values(),self._audits.values())if target._path is not _A and target._path.suffix=='.sql'and(not paths or any(target._path.samefile(p)for p in paths))];unformatted_file_paths=[]
		for target in filtered_targets:
			if target._path is _A or target.formatting is _B:continue
			with open(target._path,'r+',encoding=_U)as file:
				before=file.read();after=self._format(target,before,transpile=transpile,rewrite_casts=rewrite_casts,append_newline=append_newline,**kwargs)
				if not check:file.seek(0);file.write(after);file.truncate()
				elif before!=after:unformatted_file_paths.append(target._path)
		if unformatted_file_paths:
			for path in unformatted_file_paths:self.console.log_status_update(f"{path} needs reformatting.")
			self.console.log_status_update(f"\n{len(unformatted_file_paths)} file(s) need reformatting.");return _B
		return _C
	def _format(self,target:Model|Audit,before:str,*,transpile:t.Optional[str]=_A,rewrite_casts:t.Optional[bool]=_A,append_newline:t.Optional[bool]=_A,**kwargs:t.Any)->str:
		expressions=parse(before,default_dialect=self.config_for_node(target).dialect)
		if transpile and is_meta_expression(expressions[0]):
			for prop in expressions[0].expressions:
				if prop.name.lower()==_T:prop.replace(exp.Property(this=_T,value=exp.Literal.string(transpile or target.dialect)))
		format_config=self.config_for_node(target).format;after=format_model_expressions(expressions,transpile or target.dialect,rewrite_casts=rewrite_casts if rewrite_casts is not _A else not format_config.no_rewrite_casts,**{**format_config.generator_options,**kwargs})
		if append_newline is _A:append_newline=format_config.append_newline
		if append_newline:after+='\n'
		return after
	def plan(self,environment:t.Optional[str]=_A,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,create_from:t.Optional[str]=_A,skip_tests:t.Optional[bool]=_A,restate_models:t.Optional[t.Iterable[str]]=_A,no_gaps:t.Optional[bool]=_A,skip_backfill:t.Optional[bool]=_A,empty_backfill:t.Optional[bool]=_A,forward_only:t.Optional[bool]=_A,allow_destructive_models:t.Optional[t.Collection[str]]=_A,allow_additive_models:t.Optional[t.Collection[str]]=_A,no_prompts:t.Optional[bool]=_A,auto_apply:t.Optional[bool]=_A,no_auto_categorization:t.Optional[bool]=_A,effective_from:t.Optional[TimeLike]=_A,include_unmodified:t.Optional[bool]=_A,select_models:t.Optional[t.Collection[str]]=_A,backfill_models:t.Optional[t.Collection[str]]=_A,categorizer_config:t.Optional[CategorizerConfig]=_A,enable_preview:t.Optional[bool]=_A,no_diff:t.Optional[bool]=_A,run:t.Optional[bool]=_A,diff_rendered:t.Optional[bool]=_A,skip_linter:t.Optional[bool]=_A,explain:t.Optional[bool]=_A,ignore_cron:t.Optional[bool]=_A,min_intervals:t.Optional[int]=_A)->Plan:
		plan_builder=self.plan_builder(environment,start=start,end=end,execution_time=execution_time,create_from=create_from,skip_tests=skip_tests,restate_models=restate_models,no_gaps=no_gaps,skip_backfill=skip_backfill,empty_backfill=empty_backfill,forward_only=forward_only,allow_destructive_models=allow_destructive_models,allow_additive_models=allow_additive_models,no_auto_categorization=no_auto_categorization,effective_from=effective_from,include_unmodified=include_unmodified,select_models=select_models,backfill_models=backfill_models,categorizer_config=categorizer_config,enable_preview=enable_preview,run=run,diff_rendered=diff_rendered,skip_linter=skip_linter,explain=explain,ignore_cron=ignore_cron,min_intervals=min_intervals);plan=plan_builder.build()
		if no_auto_categorization or plan.uncategorized:no_prompts=_B
		if explain:auto_apply=_C
		self.console.plan(plan_builder,auto_apply if auto_apply is not _A else self.config.plan.auto_apply,self.default_catalog,no_diff=no_diff if no_diff is not _A else self.config.plan.no_diff,no_prompts=no_prompts if no_prompts is not _A else self.config.plan.no_prompts);return plan
	def plan_builder(self,environment:t.Optional[str]=_A,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,create_from:t.Optional[str]=_A,skip_tests:t.Optional[bool]=_A,restate_models:t.Optional[t.Iterable[str]]=_A,no_gaps:t.Optional[bool]=_A,skip_backfill:t.Optional[bool]=_A,empty_backfill:t.Optional[bool]=_A,forward_only:t.Optional[bool]=_A,allow_destructive_models:t.Optional[t.Collection[str]]=_A,allow_additive_models:t.Optional[t.Collection[str]]=_A,no_auto_categorization:t.Optional[bool]=_A,effective_from:t.Optional[TimeLike]=_A,include_unmodified:t.Optional[bool]=_A,select_models:t.Optional[t.Collection[str]]=_A,backfill_models:t.Optional[t.Collection[str]]=_A,categorizer_config:t.Optional[CategorizerConfig]=_A,enable_preview:t.Optional[bool]=_A,run:t.Optional[bool]=_A,diff_rendered:t.Optional[bool]=_A,skip_linter:t.Optional[bool]=_A,explain:t.Optional[bool]=_A,ignore_cron:t.Optional[bool]=_A,min_intervals:t.Optional[int]=_A,always_include_local_changes:t.Optional[bool]=_A)->PlanBuilder:
		kwargs:t.Dict[str,t.Optional[UserProvidedFlags]]={'start':start,'end':end,'execution_time':execution_time,'create_from':create_from,'skip_tests':skip_tests,'restate_models':list(restate_models)if restate_models is not _A else _A,'no_gaps':no_gaps,'skip_backfill':skip_backfill,'empty_backfill':empty_backfill,'forward_only':forward_only,'allow_destructive_models':list(allow_destructive_models)if allow_destructive_models is not _A else _A,'allow_additive_models':list(allow_additive_models)if allow_additive_models is not _A else _A,'no_auto_categorization':no_auto_categorization,'effective_from':effective_from,'include_unmodified':include_unmodified,'select_models':list(select_models)if select_models is not _A else _A,'backfill_models':list(backfill_models)if backfill_models is not _A else _A,'enable_preview':enable_preview,'run':run,'diff_rendered':diff_rendered,'skip_linter':skip_linter,'min_intervals':min_intervals};user_provided_flags:t.Dict[str,UserProvidedFlags]={k:v for(k,v)in kwargs.items()if v is not _A};skip_tests=explain or skip_tests or _B;no_gaps=no_gaps or _B;skip_backfill=skip_backfill or _B;empty_backfill=empty_backfill or _B;run=run or _B;diff_rendered=diff_rendered or _B;skip_linter=skip_linter or _B;environment=environment or self.config.default_target_environment;environment=Environment.sanitize_name(environment);is_dev=environment!=c.PROD
		if include_unmodified is _A:include_unmodified=self.config.plan.include_unmodified
		if skip_backfill and not no_gaps and not is_dev:self.console.log_warning('Skipping the backfill stage for production can lead to unexpected results, such as tables being empty or incremental data with non-contiguous time ranges being made available.\nIf you are doing this deliberately to create an empty version of a table to test a change, please consider using Virtual Data Environments instead.')
		if not skip_linter:self.lint_models()
		self._run_plan_tests(skip_tests=skip_tests,environment=environment);environment_ttl=self.environment_ttl if environment not in self.pinned_environments else _A;model_selector=self._new_selector()
		if allow_destructive_models:expanded_destructive_models=model_selector.expand_model_selections(allow_destructive_models)
		else:expanded_destructive_models=_A
		if allow_additive_models:expanded_additive_models=model_selector.expand_model_selections(allow_additive_models)
		else:expanded_additive_models=_A
		if backfill_models:backfill_models=model_selector.expand_model_selections(backfill_models)
		else:backfill_models=_A
		models_override:t.Optional[UniqueKeyDict[str,Model]]=_A
		if select_models:
			try:models_override=model_selector.select_models(select_models,environment,fallback_env_name=create_from or c.PROD,ensure_finalized_snapshots=self.config.plan.use_finalized_state)
			except VulcanError as e:logger.exception(e);raise PlanError(f"{e}\nCheck the Vulcan log file for the full stack trace.\nIf the model has been fixed locally, please ensure that the --select-model expression includes it.")
			if not backfill_models:backfill_models=model_selector.expand_model_selections(select_models)
		expanded_restate_models=_A
		if restate_models is not _A:expanded_restate_models=model_selector.expand_model_selections(restate_models)
		if restate_models is not _A and not expanded_restate_models or backfill_models is not _A and not backfill_models:raise PlanError('Selector did not return any models. Please check your model selection and try again.')
		if always_include_local_changes is _A:force_no_diff=restate_models is not _A or backfill_models is not _A and not backfill_models
		else:force_no_diff=not always_include_local_changes
		snapshots=self._snapshots(models_override);context_diff=self._context_diff(environment or c.PROD,snapshots=snapshots,create_from=create_from,force_no_diff=force_no_diff,ensure_finalized_snapshots=self.config.plan.use_finalized_state,diff_rendered=diff_rendered,always_recreate_environment=self.config.plan.always_recreate_environment);modified_model_names={*context_diff.modified_snapshots,*[s.name for s in context_diff.added]}
		if is_dev and not include_unmodified and backfill_models is _A and expanded_restate_models is _A:backfill_models=modified_model_names or _A
		max_interval_end_per_model=_A;default_start,default_end=_A,_A
		if not run:ignore_cron=_B;max_interval_end_per_model=self._get_max_interval_end_per_model(snapshots,backfill_models);default_start,default_end=self._get_plan_default_start_end(snapshots,max_interval_end_per_model,backfill_models,modified_model_names,execution_time or now());self.state_sync.refresh_snapshot_intervals(context_diff.snapshots.values())
		start_override_per_model=self._calculate_start_override_per_model(min_intervals,start or default_start,end or default_end,execution_time or now(),backfill_models,snapshots,max_interval_end_per_model)
		if not self.config.virtual_environment_mode.is_full:forward_only=_C
		elif forward_only is _A:forward_only=self.config.plan.forward_only
		restate_all_snapshots=expanded_restate_models is not _A and not is_dev and self.config.virtual_environment_mode.is_full;return self.PLAN_BUILDER_TYPE(context_diff=context_diff,start=start,end=end,execution_time=execution_time,apply=self.apply,restate_models=expanded_restate_models,restate_all_snapshots=restate_all_snapshots,backfill_models=backfill_models,no_gaps=no_gaps,skip_backfill=skip_backfill,empty_backfill=empty_backfill,is_dev=is_dev,forward_only=forward_only,allow_destructive_models=expanded_destructive_models,allow_additive_models=expanded_additive_models,environment_ttl=environment_ttl,environment_suffix_target=self.config.environment_suffix_target,environment_catalog_mapping=self.environment_catalog_mapping,categorizer_config=categorizer_config or self.auto_categorize_changes,auto_categorization_enabled=not no_auto_categorization,effective_from=effective_from,include_unmodified=include_unmodified,default_start=default_start,default_end=default_end,enable_preview=enable_preview if enable_preview is not _A else self._plan_preview_enabled,end_bounded=not run,ensure_finalized_snapshots=self.config.plan.use_finalized_state,start_override_per_model=start_override_per_model,end_override_per_model=max_interval_end_per_model,console=self.console,user_provided_flags=user_provided_flags,selected_models={dbt_unique_id for model in model_selector.expand_model_selections(select_models or'*')if(dbt_unique_id:=snapshots[model].node.dbt_unique_id)},explain=explain or _B,ignore_cron=ignore_cron or _B)
	def _get_captured_run_data(self,exception:t.Optional[Exception]=_A)->t.Tuple[t.List[_K],t.List[_X],t.List[_N]]:
		from vulcan.core.activity import ErrorExec;models:t.List[_K]=[];audits:t.List[ModelIntervalAudits]=[];errors:t.List[ErrorExec]=[]
		if isinstance(self.console,RunActivityCapturingConsole):models,audits,errors,_=self.console.get_run_capture()
		if exception is not _A:
			if not errors:
				error_msg=str(exception)
				if len(error_msg)>2000:error_msg=error_msg[:2000]+'... (truncated)'
				errors=[ErrorExec(model_fqn=_A,model_name=_A,error_class=type(exception).__name__,message=error_msg,is_audit_error=_B)]
		return models,audits,errors
	def _finalize_run_and_persist_activity(self,run_id:str,plan_id:str,environment:str,run_start_ts:int,exception:t.Optional[Exception]=_A,*,job_type:JobTypeValues='RUN',start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,completion_status:t.Optional[CompletionStatus]=_A,interrupted:bool=_B)->_A:
		models,audits,errors=self._get_captured_run_data(exception);scheduler_end_ts_ms=int(round(time.time()*1000));from vulcan.core.types import RunDqCounts;count_dq=RunDqCounts.empty()
		if not errors:logger.info('Running quality checks: run %s, %s model(s)',run_id,len(models));count_dq=self._execute_quality_checks(run_id=run_id,environment=environment,job_type=job_type,run_start_ts=run_start_ts,run_end_ts=scheduler_end_ts_ms,models=models,errors=errors,start=start,end=end,execution_time=execution_time)
		run_end_ts=int(round(time.time()*1000));self._record_run_activity(run_id=run_id,plan_id=plan_id,environment=environment,run_start_ts=run_start_ts,run_end_ts=run_end_ts,models=models,errors=errors,audits=audits,dq_counts=count_dq);prometheus.registry.on_run_end(environment=environment,models=models,errors=errors,scheduler_start_ts_ms=run_start_ts,scheduler_end_ts_ms=scheduler_end_ts_ms,completion_status=completion_status,interrupted=interrupted)
	def _finalize_plan_apply_and_record_activity(self,plan:Plan,apply_start_ts:int,exception:t.Optional[Exception]=_A)->t.Optional[PlanActivity]:
		apply_end_ts=int(round(time.time()*1000));_,_,errors=self._get_captured_run_data(exception);plan_activity=self._record_plan_activity(plan,apply_start_ts,apply_end_ts,success=not errors,errors=errors if errors else _A)
		if plan_activity:prometheus.registry.on_plan_end(plan=plan,activity=plan_activity)
		prometheus.registry.on_env_inventory(environment=plan.environment_naming_info.name,snapshot_count=len(plan.environment.snapshots),environment_count=len(self.state_sync.get_environments()))
		if plan_activity and not errors:
			if plan_activity.has_changes:plan_change_data={_Y:plan_activity.plan_id,_V:plan_activity.environment,'added':len(plan_activity.changes.added),'modified':len(plan_activity.changes.direct)+len(plan_activity.changes.metadata),'removed':len(plan_activity.changes.removed),'directly_modified':[change.name for change in plan_activity.changes.direct[:10]],'downstream_affected':len(plan_activity.changes.indirect),'has_breaking_changes':plan_activity.has_breaking_changes,'requires_backfill':plan_activity.requires_backfill};self.notification_target_manager.notify(NotificationEvent.PLAN_CHANGE,**plan_change_data)
			run_id=plan.plan_id;self._finalize_run_and_persist_activity(run_id=run_id,plan_id=plan.plan_id,environment=plan.environment_naming_info.name,run_start_ts=apply_start_ts,job_type='PLAN')
		return plan_activity
	def _record_plan_activity(self,plan:Plan,apply_start_ts:int,apply_end_ts:int,success:bool=_C,errors:t.Optional[t.List[_N]]=_A)->t.Optional[PlanActivity]:
		plan_id=plan.plan_id;environment=plan.environment_naming_info.name
		try:
			from vulcan.core.activity import build_plan_activity;plan_activity=build_plan_activity(plan,apply_start_ts,apply_end_ts,self.git_client,default_catalog=self.default_catalog,errors=errors,success=success,version=self.config.version)
			if plan_activity.has_changes:self.state_sync.store_plan_activity(plan_activity);logger.debug(f"Stored plan activity: {plan_id} ({environment})")
			return plan_activity
		except Exception as e:error_msg=f"Plan {plan_id} applied successfully to '{environment}' but failed to store plan diff: {e}";self.console.log_warning(short_message=error_msg,long_message=f"Plan '{plan_id}' was applied successfully to '{environment}', but activity recording failed. See logs for details: {str(e)}");return locals().get('plan_activity')
	def _record_run_activity(self,run_id:str,plan_id:str,environment:str,run_start_ts:int,run_end_ts:int,models:t.List[_K],errors:t.List[_N],audits:t.Optional[t.List[_X]]=_A,*,dq_counts:t.Optional[_Z]=_A)->_A:
		if not models and not errors:return
		try:from vulcan.core.activity import build_run_activity;success=not errors;run_activity=build_run_activity(run_id=run_id,plan_id=plan_id,environment=environment,start_ts=run_start_ts,end_ts=run_end_ts,models=models,errors=errors,success=success,audits=audits);self.state_sync.store_run_activity(run_activity,dq_counts=dq_counts);model_count=len(models);logger.info(f"Recorded run activity for {model_count} models")
		except Exception as e:logger.error(f"Failed to record run execution for '{environment}': {e}",exc_info=_C,extra={_a:'run_execution_recording_failure',_b:run_id,_Y:plan_id,_V:environment})
	def _execute_quality_checks(self,run_id:str,environment:str,job_type:JobTypeValues,run_start_ts:int,run_end_ts:int,models:t.List[_K],errors:t.List[_N],*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A)->_Z:
		from vulcan.core.types import RunDqCounts;from vulcan.core.soda3.spec import CheckExecutionSummary;count_dq=RunDqCounts.empty();_models:t.List[_K]=[];_start=0;_results:t.Optional['CheckExecutionSummary']=_A;_error:t.Optional[BaseException]=_A
		try:
			errored_model_fqns={error.model_fqn for error in errors if error.model_fqn};_models=[model for model in models if model.fqn not in errored_model_fqns]
			if not _models:logger.info(f"No models executed successfully in run '{run_id}'. Skipping data quality checks.");return count_dq
			_start=int(round(time.time()*1000));logger.info(f"Executing data quality checks for {len(_models)} models");from vulcan.core.soda3.runner import run_soda3_for_successful_models;from vulcan.core.console import Verbosity;console=self.console;verbosity=min(2,max(0,getattr(console,'verbosity',Verbosity.DEFAULT)-Verbosity.DEFAULT));log=console._print if hasattr(console,'_print')else console.log_success;self.notification_target_manager.notify(NotificationEvent.DQ_START,run_id=run_id,environment=environment,model_count=len(_models));_results,profile_result=run_soda3_for_successful_models(self,_models,run_id=run_id,job_type=job_type,environment=environment,execution_time=execution_time,start=start,end=end)
			if _results:
				count_dq=_results.quality_counts();log(_results.summarize());log(_results.format_tree(verbosity=verbosity));total_checks=count_dq.total;passed=count_dq.passed;failed=count_dq.failed;warned=count_dq.warned;not_evaluated=count_dq.not_evaluated;model_count=0;failures_by_dimension:t.Dict[str,t.List[str]]={};warnings_by_dimension:t.Dict[str,t.List[str]]={}
				for summary in[_results]:
					for(model_name,model_data)in summary.results.items():
						model_count+=1
						for(dimension,stats)in model_data.get('dimensions',{}).items():
							if stats['failed']>0:
								if dimension not in failures_by_dimension:failures_by_dimension[dimension]=[]
								failures_by_dimension[dimension].append(model_name)
							if stats['warned']>0:
								if dimension not in warnings_by_dimension:warnings_by_dimension[dimension]=[]
								warnings_by_dimension[dimension].append(model_name)
				pass_rate=passed/total_checks*1e2 if total_checks>0 else 1e2;self.notification_target_manager.notify(NotificationEvent.DQ_END,run_id=run_id,environment=environment,total_checks=total_checks,passed=passed,failed=failed,warned=warned,not_evaluated=not_evaluated,model_count=model_count,pass_rate=pass_rate,failures_by_dimension=failures_by_dimension,warnings_by_dimension=warnings_by_dimension)
			if profile_result:log(profile_result.summarize(verbosity=verbosity))
		except Exception as e:_error=e;logger.error(f"Failed to execute checks for run '{run_id}': {e}",exc_info=_C,extra={_a:'check_execution_failure',_b:run_id,_V:environment});self.console.log_warning(f"Check execution failed (non-fatal): {str(e)}")
		finally:
			if _start:prometheus.registry.on_dq_end(environment=environment,models=_models,check_results=_results,scan_start_ts_ms=_start,scan_end_ts_ms=int(round(time.time()*1000)),error=_error)
		return count_dq
	def apply(self,plan:Plan,circuit_breaker:t.Optional[t.Callable[[],bool]]=_A)->_A:
		if not plan.context_diff.has_changes and not plan.requires_backfill and not plan.has_unmodified_unpromoted:return
		if plan.uncategorized:raise UncategorizedPlanError("Can't apply a plan with uncategorized changes.")
		if plan.explain:explainer=PlanExplainer(state_reader=self.state_reader,default_catalog=self.default_catalog,console=self.console);explainer.evaluate(plan.to_evaluatable());return
		apply_start_ts=int(round(time.time()*1000));self.notification_target_manager.notify(NotificationEvent.APPLY_START,environment=plan.environment_naming_info.name,plan_id=plan.plan_id)
		try:self._apply(plan,circuit_breaker)
		except Exception as e:self._finalize_plan_apply_and_record_activity(plan,apply_start_ts,exception=e);self.notification_target_manager.notify(NotificationEvent.APPLY_FAILURE,environment=plan.environment_naming_info.name,plan_id=plan.plan_id,exc=traceback.format_exc());logger.info('Plan application failed.',exc_info=e);raise e
		self._finalize_plan_apply_and_record_activity(plan,apply_start_ts);self.notification_target_manager.notify(NotificationEvent.APPLY_END,environment=plan.environment_naming_info.name,plan_id=plan.plan_id)
	def invalidate_environment(self,name:str,sync:bool=_B)->_A:
		name=Environment.sanitize_name(name);self.state_sync.invalidate_environment(name)
		if sync:self._cleanup_environments();self.console.log_success(f"Environment '{name}' deleted.")
		else:self.console.log_success(f"Environment '{name}' invalidated.")
	def diff(self,environment:t.Optional[str]=_A,detailed:bool=_B)->bool:
		environment=environment or self.config.default_target_environment;environment=Environment.sanitize_name(environment);context_diff=self._context_diff(environment);self.console.show_environment_difference_summary(context_diff,no_diff=not detailed)
		if context_diff.has_changes:self.console.show_model_difference_summary(context_diff,EnvironmentNamingInfo.from_environment_catalog_mapping(self.environment_catalog_mapping,name=environment,suffix_target=self.config.environment_suffix_target,normalize_name=context_diff.normalize_environment_name),self.default_catalog,no_diff=not detailed)
		return context_diff.has_changes
	def table_diff(self,source:str,target:str,on:t.Optional[t.List[str]|exp.Condition]=_A,skip_columns:t.Optional[t.List[str]]=_A,select_models:t.Optional[t.Collection[str]]=_A,where:t.Optional[str|exp.Condition]=_A,limit:int=20,show:bool=_C,show_sample:bool=_C,decimals:int=3,skip_grain_check:bool=_B,warn_grain_check:bool=_B,temp_schema:t.Optional[str]=_A,schema_diff_ignore_case:bool=_B,**kwargs:t.Any)->t.List[TableDiff]:
		if'|'in source or'|'in target:raise ConfigError('Cross-database table diffing is available in Tobiko Cloud. Read more here: https://vulcan.readthedocs.io/en/stable/guides/tablediff/#diffing-tables-or-views-across-gateways')
		table_diffs:t.List[TableDiff]=[]
		if select_models:
			source_env=self.state_reader.get_environment(source);target_env=self.state_reader.get_environment(target)
			if not source_env:raise VulcanError(f"Could not find environment '{source}'")
			if not target_env:raise VulcanError(f"Could not find environment '{target}'")
			criteria=', '.join(f"'{c}'"for c in select_models)
			try:
				selected_models=self._new_selector().expand_model_selections(select_models)
				if not selected_models:self.console.log_status_update(f"No models matched the selection criteria: {criteria}")
			except Exception as e:raise VulcanError(e)
			models_to_diff:t.List[t.Tuple[Model,EngineAdapter,str,str,t.Optional[t.List[str]|exp.Condition]]]=[];models_without_grain:t.List[Model]=[];source_snapshots_to_name={snapshot.name:snapshot for snapshot in source_env.snapshots};target_snapshots_to_name={snapshot.name:snapshot for snapshot in target_env.snapshots}
			for model_fqn in selected_models:
				model=self._models[model_fqn];adapter=self._get_engine_adapter(model.gateway);source_snapshot=source_snapshots_to_name.get(model.fqn);target_snapshot=target_snapshots_to_name.get(model.fqn)
				if target_snapshot and source_snapshot:
					if source_snapshot.fingerprint!=target_snapshot.fingerprint and(source_snapshot.version!=target_snapshot.version or source_snapshot.is_forward_only):
						source=source_snapshot.qualified_view_name.for_environment(source_env.naming_info,adapter.dialect);target=target_snapshot.qualified_view_name.for_environment(target_env.naming_info,adapter.dialect);model_on=on or model.on
						if not model_on:models_without_grain.append(model)
						else:models_to_diff.append((model,adapter,source,target,model_on))
			if models_without_grain:
				model_names='\n'.join(f"─ {model.name} \n  at '{model._path}'"for model in models_without_grain);message=f"Vulcan doesn't know how to join the tables for the following models:\n{model_names}\n\nPlease specify a `grain` in each model definition. It must be unique and not null."
				if warn_grain_check:self.console.log_warning(message)
				else:raise VulcanError(message)
			if models_to_diff:
				self.console.show_table_diff_details([model[0].name for model in models_to_diff]);self.console.start_table_diff_progress(len(models_to_diff))
				try:tasks_num=min(len(models_to_diff),self.concurrent_tasks);table_diffs=concurrent_apply_to_values(list(models_to_diff),lambda model_info:self._model_diff(model=model_info[0],adapter=model_info[1],source=model_info[2],target=model_info[3],on=model_info[4],source_alias=source_env.name,target_alias=target_env.name,limit=limit,decimals=decimals,skip_columns=skip_columns,where=where,show=show,temp_schema=temp_schema,skip_grain_check=skip_grain_check,schema_diff_ignore_case=schema_diff_ignore_case),tasks_num=tasks_num);self.console.stop_table_diff_progress(success=_C)
				except:self.console.stop_table_diff_progress(success=_B);raise
			elif selected_models:self.console.log_status_update(f"No models contain differences with the selection criteria: {criteria}")
		else:table_diffs=[self._table_diff(source=source,target=target,source_alias=source,target_alias=target,limit=limit,decimals=decimals,adapter=self.engine_adapter,on=on,skip_columns=skip_columns,where=where,schema_diff_ignore_case=schema_diff_ignore_case)]
		if show:self.console.show_table_diff(table_diffs,show_sample,skip_grain_check,temp_schema)
		return table_diffs
	def _model_diff(self,model:Model,adapter:EngineAdapter,source:str,target:str,source_alias:str,target_alias:str,limit:int,decimals:int,on:t.Optional[t.List[str]|exp.Condition]=_A,skip_columns:t.Optional[t.List[str]]=_A,where:t.Optional[str|exp.Condition]=_A,show:bool=_C,temp_schema:t.Optional[str]=_A,skip_grain_check:bool=_B,schema_diff_ignore_case:bool=_B)->TableDiff:
		self.console.start_table_diff_model_progress(model.name);table_diff=self._table_diff(on=on,skip_columns=skip_columns,where=where,limit=limit,decimals=decimals,model=model,adapter=adapter,source=source,target=target,source_alias=source_alias,target_alias=target_alias,schema_diff_ignore_case=schema_diff_ignore_case)
		if show:table_diff.row_diff(temp_schema=temp_schema,skip_grain_check=skip_grain_check)
		self.console.update_table_diff_progress(model.name);return table_diff
	def _table_diff(self,source:str,target:str,source_alias:str,target_alias:str,limit:int,decimals:int,adapter:EngineAdapter,on:t.Optional[t.List[str]|exp.Condition]=_A,model:t.Optional[Model]=_A,skip_columns:t.Optional[t.List[str]]=_A,where:t.Optional[str|exp.Condition]=_A,schema_diff_ignore_case:bool=_B)->TableDiff:
		if not on:raise VulcanError("Vulcan doesn't know how to join the two tables. Specify the `grains` in each model definition or pass join column names in separate `-o` flags.")
		return TableDiff(adapter=adapter.with_settings(execute_log_level=logger.getEffectiveLevel()),source=source,target=target,on=on,skip_columns=skip_columns,where=where,source_alias=source_alias,target_alias=target_alias,limit=limit,decimals=decimals,model_name=model.name if model else _A,model_dialect=model.dialect if model else _A,schema_diff_ignore_case=schema_diff_ignore_case)
	def get_dag(self,select_models:t.Optional[t.Collection[str]]=_A,**options:t.Any)->GraphHTML:
		F='#F57C00';E='#FFE0B2';D='#2E7D32';C='#C8E6C9';B='#616161';A='#EEEEEE';dag=self.dag.prune(*self._new_selector().expand_model_selections(select_models))if select_models else self.dag;nodes={};edges:t.List[t.Dict]=[];default_node={_D:'#F5F5F5',_E:'#9E9E9E',_L:{_D:A,_E:B},_G:{_D:A,_E:B}};rollup_node={_D:'#E8F5E9',_E:'#43A047',_L:{_D:C,_E:D},_G:{_D:C,_E:D}};node_colors={ModelKindName.SEMANTIC:{_D:_c,_E:_d,_L:{_D:_O,_E:_P},_G:{_D:_O,_E:_P}},ModelKindName.METRIC:{_D:'#FFF3E0',_E:'#FB8C00',_L:{_D:E,_E:F},_G:{_D:E,_E:F}}};label_max_chars=20
		def graph_node_label(name:str)->str:
			tail=name.rsplit('.',1)[-1]
			if len(tail)<=label_max_chars:return tail
			return f"{tail[:label_max_chars-3]}..."
		for(node,deps)in dag.graph.items():
			model=self._models.get(node);label=graph_node_label(model.name)if model else graph_node_label(node);title=model.name
			if model is not _A and getattr(model,'source_type',_A)=='rollup':color=rollup_node
			else:color=node_colors.get(model.kind.model_kind_name if model else _A,default_node)
			nodes[node]={'id':node,_F:label,_I:f"<span>{title}</span>",'color':color};edges.extend({_J:d,_H:node}for d in deps)
		return GraphHTML(nodes,edges,options={_e:_Q,'width':_Q,_f:{_G:_C,_h:_C,_i:_C,_j:200,_k:_C,_l:_C},_g:{_m:{_n:200,_o:'DU',_p:_q,'blockShifting':_C,'parentCentralization':_C}},'nodes':{'shape':'box','widthConstraint':{'maximum':250},_M:{'size':16}},**options})
	def get_joins_graph(self,**options:t.Any)->GraphHTML:
		D='arrows';C='top';B='align';A='enabled';semantics=[m for m in self._models.values()if isinstance(m,SemanticModel)];join_labels={'one_to_one':'1:1','one_to_many':'1:Many','many_to_one':'Many:1'};nodes:dict={};edges:t.List[t.Dict[str,t.Any]]=[];semantic_color={_D:_c,_E:_d,_L:{_D:_O,_E:_P},_G:{_D:_O,_E:_P}}
		for sm in semantics:fq=sm.fqn;nodes[fq]={'id':fq,_F:sm.name,_I:f"<span>{sm.fqn}</span>",'color':semantic_color}
		for sm in semantics:
			for join in sm.joins:to_fqn=join.fqn or normalize_model_name(f"semantic.{join.name}",default_catalog=sm.default_catalog,dialect=sm.dialect or'');edges.append({_J:sm.fqn,_H:to_fqn,_F:join_labels.get(join.type,join.type),_I:f"{join.expression}",_M:{B:C}})
		def _merge_reciprocal_join_edges(directed:t.List[t.Dict[str,t.Any]])->t.List[t.Dict[str,t.Any]]:
			by_direction={(edge[_J],edge[_H]):edge for edge in directed};merged:t.List[t.Dict[str,t.Any]]=[];consumed:t.Set[t.Tuple[str,str]]=set()
			for edge in directed:
				src,tgt=edge[_J],edge[_H]
				if(src,tgt)in consumed:continue
				rev=tgt,src
				if rev in by_direction and src!=tgt:consumed.update(((src,tgt),rev));a,b=sorted((src,tgt));ab,ba=by_direction[a,b],by_direction[b,a];merged.append({_J:a,_H:b,_F:f"{ab[_F]}, {ba[_F]}",_I:f"{a} → {b}: {ab[_F]} — {ab[_I]}<br>{b} → {a}: {ba[_F]} — {ba[_I]}",D:{_H:{A:_C},_J:{A:_C}},_M:ab.get(_M,{B:C})})
				else:consumed.add((src,tgt));merged.append(edge)
			return merged
		edges=_merge_reciprocal_join_edges(edges);return GraphHTML(nodes,edges,options={_e:_Q,'width':_Q,'edges':{D:_H},_f:{_G:_C,_h:_C,_i:_C,_j:200,_k:_C,_l:_C},_g:{_m:{A:_C,_n:200,_o:'UD',_p:_q}},'nodes':{'shape':'box',_M:{'size':16}},**options})
	def render_joins_graph(self,path:str,**options:t.Any)->str:
		file_path=Path(path);suffix=file_path.suffix
		if suffix!=_R:
			if suffix:get_console().log_warning(f"The extension {suffix} does not designate an html file. A file with a `.html` extension will be created instead.")
			path=str(file_path.with_suffix(_R))
		with open(path,'w',encoding=_U)as file:file.write(str(self.get_joins_graph(**options)))
		return path
	def render_dag(self,path:str,select_models:t.Optional[t.Collection[str]]=_A)->str:
		file_path=Path(path);suffix=file_path.suffix
		if suffix!=_R:
			if suffix:get_console().log_warning(f"The extension {suffix} does not designate an html file. A file with a `.html` extension will be created instead.")
			path=str(file_path.with_suffix(_R))
		with open(path,'w',encoding=_U)as file:file.write(str(self.get_dag(select_models)))
		return path
	def create_test(self,model:str,input_queries:t.Dict[str,str],overwrite:bool=_B,variables:t.Optional[t.Dict[str,str]]=_A,path:t.Optional[str]=_A,name:t.Optional[str]=_A,include_ctes:bool=_B)->_A:
		input_queries={self.get_model(dep,raise_if_missing=_C).fqn:query for(dep,query)in input_queries.items()}
		try:model_to_test=self.get_model(model,raise_if_missing=_C);test_adapter=self.test_connection_config.create_engine_adapter(register_comments_override=_B);generate_test(model=model_to_test,input_queries=input_queries,models=self._models,engine_adapter=self._get_engine_adapter(model_to_test.gateway),test_engine_adapter=test_adapter,project_path=self.path,overwrite=overwrite,variables=variables,path=path,name=name,include_ctes=include_ctes)
		finally:
			if test_adapter:test_adapter.close()
	def test(self,match_patterns:t.Optional[t.List[str]]=_A,tests:t.Optional[t.List[str]]=_A,verbosity:Verbosity=Verbosity.DEFAULT,preserve_fixtures:bool=_B,stream:t.Optional[t.TextIO]=_A,environment:t.Optional[str]=_A)->ModelTextTestResult:
		if verbosity>=Verbosity.VERBOSE:import pandas as pd;pd.set_option('display.max_columns',_A)
		test_meta=self.select_tests(tests=tests,patterns=match_patterns);result=run_tests(model_test_metadata=test_meta,models=self._models,config=self.config,selected_gateway=self.selected_gateway,dialect=self.default_dialect,verbosity=verbosity,preserve_fixtures=preserve_fixtures,stream=stream,default_catalog=self.default_catalog,default_catalog_dialect=self.config.dialect or'');self.console.log_test_results(result,self.test_connection_config._engine_adapter.DIALECT);return result
	def audit(self,start:TimeLike,end:TimeLike,*,models:t.Optional[t.Iterator[str]]=_A,execution_time:t.Optional[TimeLike]=_A)->bool:
		snapshots=[self.get_snapshot(model,raise_if_missing=_C)for model in models]if models else self.snapshots.values();num_audits=sum(len(snapshot.node.audits_with_args)for snapshot in snapshots);self.console.log_status_update(f"Found {num_audits} audit(s).");errors=[];skipped_count=0
		for snapshot in snapshots:
			audit_results=self.snapshot_evaluator.audit(snapshot=snapshot,start=start,end=end,execution_time=execution_time,snapshots=self.snapshots)
			for audit_result in audit_results:
				audit_id=f"{audit_result.audit.name}"
				if audit_result.model:audit_id+=f" on model {audit_result.model.name}"
				if audit_result.skipped:self.console.log_status_update(f"{audit_id} ⏸️ SKIPPED.");skipped_count+=1
				elif audit_result.count:errors.append(audit_result);self.console.log_status_update(f"{audit_id} ❌ [red]FAIL [{audit_result.count}][/red].")
				else:self.console.log_status_update(f"{audit_id} ✅ [green]PASS[/green].")
			prometheus.registry.on_audits_completed(snapshot=snapshot,audit_results=audit_results)
		self.console.log_status_update(f"\nFinished with {len(errors)} audit error{''if len(errors)==1 else's'} and {skipped_count} audit{''if skipped_count==1 else's'} skipped.")
		for error in errors:
			self.console.log_status_update(f"\nFailure in audit {error.audit.name} ({error.audit._path}).");self.console.log_status_update(f"Got {error.count} results, expected 0.")
			if error.query:self.console.show_sql(f"{error.query.sql(dialect=self.snapshot_evaluator.adapter.dialect)}")
		self.console.log_status_update('Done.');return not errors
	def check_intervals(self,environment:t.Optional[str],no_signals:bool,select_models:t.Collection[str],start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A)->t.Dict[Snapshot,SnapshotIntervals]:
		environment=environment or c.PROD;env=self.state_reader.get_environment(environment)
		if not env:raise VulcanError(f"Environment '{environment}' was not found.")
		snapshots={k.name:v for(k,v)in self.state_sync.get_snapshots(env.snapshots).items()};missing={k.name:v for(k,v)in missing_intervals(snapshots.values(),start=start,end=end,execution_time=end).items()}
		if select_models:selected:t.Collection[str]=self._select_models_for_run(select_models,_C,snapshots.values())
		else:selected=snapshots.keys()
		results={};execution_context=self.execution_context(snapshots=snapshots)
		for fqn in selected:snapshot=snapshots[fqn];intervals=missing.get(fqn)or[];results[snapshot]=SnapshotIntervals(snapshot.snapshot_id,intervals if no_signals else snapshot.check_ready_intervals(intervals,execution_context))
		return results
	def migrate(self)->_A:
		self.notification_target_manager.notify(NotificationEvent.MIGRATION_START);self._load_materializations()
		try:self._new_state_sync().migrate(promoted_snapshots_only=self.config.migration.promoted_snapshots_only)
		except Exception as e:self.notification_target_manager.notify(NotificationEvent.MIGRATION_FAILURE,traceback.format_exc());raise e
		self.notification_target_manager.notify(NotificationEvent.MIGRATION_END)
	def rollback(self)->_A:self._new_state_sync().rollback()
	def create_external_models(self,strict:bool=_B)->_A:
		if not self._models:self.load(update_schemas=_B)
		for(path,config)in self.configs.items():
			deprecated_yaml=path/c.EXTERNAL_MODELS_DEPRECATED_YAML;external_models_yaml=path/c.EXTERNAL_MODELS_YAML if not deprecated_yaml.exists()else deprecated_yaml;external_models_gateway:t.Optional[str]=self.gateway or self.config.default_gateway
			if not external_models_gateway:external_models_gateway=_A
			create_external_models_file(path=external_models_yaml,models=UniqueKeyDict(_S,{fqn:model for(fqn,model)in self._models.items()if self.config_for_node(model)is config}),adapter=self.engine_adapter,state_reader=self.state_reader,dialect=config.model_defaults.dialect,gateway=external_models_gateway,max_workers=self.concurrent_tasks,strict=strict)
	def print_info(self,skip_connection:bool=_B,verbosity:Verbosity=Verbosity.DEFAULT)->_A:
		self.console.log_status_update(f"Models: {len(self.models)}");self.console.log_status_update(f"Macros: {len(self._macros)-len(macro.get_registry())}")
		if skip_connection:return
		if verbosity>=Verbosity.VERBOSE:self.console.log_status_update('');print_config(self.config.get_connection(self.gateway),self.console,'Connection');print_config(self.config.get_test_connection(self.gateway),self.console,'Test Connection');print_config(self.config.get_state_connection(self.gateway),self.console,'State Connection')
		self._try_connection('data warehouse',self.engine_adapter.ping);state_connection=self.config.get_state_connection(self.gateway)
		if state_connection:self._try_connection('state backend',state_connection.connection_validator())
	def print_environment_names(self)->_A:
		result=self._new_state_sync().get_environments_summary()
		if not result:raise VulcanError('This project has no environments. Create an environment using the `vulcan plan` command.')
		self.console.print_environments(result)
	def close(self)->_A:
		if self._snapshot_evaluator:self._snapshot_evaluator.close()
		if self._state_sync:self._state_sync.close()
		if self._engine_adapter:self._engine_adapter.close()
		self._shutdown_engine_adapters()
	def _shutdown_engine_adapters(self)->_A:
		snapshot_evaluator=self.__dict__.get('_snapshot_evaluator');adapters=[*([self._engine_adapter]if self._engine_adapter else[]),*(snapshot_evaluator.adapters.values()if snapshot_evaluator else())];seen:t.Set[int]=set()
		for adapter in adapters:
			try:key=id(adapter.spark or adapter)
			except Exception:key=id(adapter)
			if key in seen:continue
			seen.add(key)
			try:adapter.shutdown()
			except Exception:logger.exception('Failed to shutdown engine adapter')
	def _run(self,environment:str,*,start:t.Optional[TimeLike],end:t.Optional[TimeLike],execution_time:t.Optional[TimeLike],ignore_cron:bool,select_models:t.Optional[t.Collection[str]],circuit_breaker:t.Optional[t.Callable[[],bool]],no_auto_upstream:bool,run_id:t.Optional[str]=_A)->CompletionStatus:
		scheduler=self.scheduler(environment=environment)
		if run_id:correlation_id=CorrelationId.from_run_id(run_id);scheduler.snapshot_evaluator=scheduler.snapshot_evaluator.set_correlation_id(correlation_id)
		snapshots=scheduler.snapshots
		if select_models is not _A:select_models=self._select_models_for_run(select_models,no_auto_upstream,snapshots.values())
		completion_status=scheduler.run(environment,start=start,end=end,execution_time=execution_time,ignore_cron=ignore_cron,circuit_breaker=circuit_breaker,selected_snapshots=select_models,auto_restatement_enabled=environment.lower()==c.PROD,run_environment_statements=_C)
		if completion_status.is_nothing_to_do:
			next_run_ready_msg='';next_ready_interval_start=get_next_model_interval_start(snapshots.values())
			if next_ready_interval_start:utc_time=format_tz_datetime(next_ready_interval_start);local_time=format_tz_datetime(next_ready_interval_start,use_local_timezone=_C);time_msg=local_time if local_time==utc_time else f"{local_time} ({utc_time})";next_run_ready_msg=f"\n\nNext run will be ready at {time_msg}."
			self.console.log_status_update(f"No models are ready to run. Please wait until a model `cron` interval has elapsed.{next_run_ready_msg}")
		return completion_status
	def _apply(self,plan:Plan,circuit_breaker:t.Optional[t.Callable[[],bool]])->_A:self._scheduler.create_plan_evaluator(self).evaluate(plan.to_evaluatable(),circuit_breaker=circuit_breaker)
	def table_name(self,model_name:str,environment:t.Optional[str]=_A,prod:bool=_B)->str:
		environment=environment or self.config.default_target_environment;fqn=self._node_or_snapshot_to_fqn(model_name);target_env=self.state_reader.get_environment(environment)
		if not target_env:raise VulcanError(f"Environment '{environment}' was not found.")
		snapshot_info=_A
		for s in target_env.snapshots:
			if s.name==fqn:snapshot_info=s;break
		if not snapshot_info:raise VulcanError(f"Model '{model_name}' was not found in environment '{environment}'.")
		if target_env.name==c.PROD or prod:return snapshot_info.table_name()
		snapshots=self.state_reader.get_snapshots(target_env.snapshots);deployability_index=DeployabilityIndex.create(snapshots);return snapshot_info.table_name(is_deployable=deployability_index.is_deployable(snapshot_info.snapshot_id))
	def cube_schema_for_environment(self,environment:t.Optional[str]=_A)->'CubeSchema':from vulcan.core.export.cube import build_cube_schema;return build_cube_schema(self.metadata_for_environment(environment),include_rollups=self.config.enable_rollup)
	def metadata_for_environment(self,environment:t.Optional[str]=_A)->Metadata:from vulcan.core.export.metadata import build_metadata;return build_metadata(self,environment=environment)
	def odcs_contract_for_environment(self,model_name:str,environment:t.Optional[str]=_A)->'OdcsContract':
		from schema.odcs_contract import OdcsContract;from vulcan.core.export.bitol_contract import ModelNotFoundError,build_odcs_contract
		try:return build_odcs_contract(self.metadata_for_environment(environment),model_name)
		except ModelNotFoundError as exc:raise VulcanError(str(exc))from exc
	def odps_product_for_environment(self,environment:t.Optional[str]=_A)->'OdpsProduct':from schema.odps_spec import OdpsProduct;from vulcan.core.export.bitol_contract import build_odps_product;return build_odps_product(self.metadata_for_environment(environment))
	def rewrite(self,sql:str,*,user:str,security_context:_r,environment:t.Optional[str]=_A,gateway:t.Optional[str]=_A)->'RewriteResult':
		from vulcan.core.query.rewriter import rewrite as rewrite_warehouse_sql;env=environment or self.config.default_target_environment
		if not self.state_sync.get_environment(env):available=[e.name for e in self.state_sync.get_environments()];raise VulcanError(f"Environment '{env}' not found. Run 'vulcan plan {env}' first. Available: {', '.join(available)if available else'none'}")
		metadata=self.metadata_for_environment(env);resolved_gateway=gateway or self.gateway or metadata.gateway.name;gateways=[metadata.gateway,*(metadata.gateways or[])];gateway_info=next((g for g in gateways if g.name==resolved_gateway),_A)
		if gateway_info is _A:allowed=sorted(g.name for g in gateways);raise VulcanError(f"Unknown gateway {resolved_gateway!r}. Allowed: {allowed}")
		dialect=(gateway_info.dialect or gateway_info.connection_type or'').strip()
		if not dialect:raise VulcanError(f"Gateway {resolved_gateway!r} has no dialect in metadata")
		default_catalog=self.config.get_connection(resolved_gateway).get_catalog();return rewrite_warehouse_sql(sql=sql,user=user,metadata=metadata,security_context=security_context,dialect=dialect,default_catalog=default_catalog)
	async def transpile(self,query:'RestQuery | str',*,user:str,security_context:_r,environment:t.Optional[str]=_A,disable_post_processing:bool=_B)->'TranspileResult':
		from vulcan.core.query.transpiler import transpile;env=environment or self.config.default_target_environment
		if not self.state_sync.get_environment(env):available=[e.name for e in self.state_sync.get_environments()];raise VulcanError(f"Environment '{env}' not found. Run 'vulcan plan {env}' first. Available: {', '.join(available)if available else'none'}")
		metadata=self.metadata_for_environment(env);gateway=self.gateway or metadata.gateway.name
		try:return await transpile(query=query,catalog=metadata,config=self.config,gateway=gateway,user=user,security_context=security_context,disable_cube_post_processing=disable_post_processing,include_rollups=self.config.enable_rollup)
		except TranspilerError as e:
			if e.code==503:raise VulcanError('Failed to connect to the Transpiler service (HTTP 503).\nMake sure the Transpiler is reachable (check transpiler.base_url). For local dev, run `make setup-up` from the docker/ directory.')from e
			if e.code==401:raise VulcanError('Transpiler rejected request (HTTP 401). Set DATAOS_RUN_AS_APIKEY env var for Transpiler auth.')from e
			if e.is_post_processing_error:raise VulcanError(f"Query requires post-processing: {e}\nUse --disable-post-processing flag.")from e
			detail=f"Transpiler error (HTTP {e.code}): {e}"
			if e.response_data:detail+=f"\nDetails: {e.response_data}"
			raise VulcanError(detail)from e
	def clear_caches(self)->_A:
		paths_to_remove=[path/c.CACHE for path in self.configs];paths_to_remove.append(self.cache_dir)
		if IS_WINDOWS:paths_to_remove=[fix_windows_path(path)for path in paths_to_remove]
		for path in paths_to_remove:
			if path.exists():rmtree(path)
		if isinstance(self._state_sync,CachingStateSync):self._state_sync.clear_cache()
	def export_state(self,output_file:Path,environment_names:t.Optional[t.List[str]]=_A,local_only:bool=_B,confirm:bool=_C)->_A:
		from vulcan.core.state_sync.export_import import export_state;self.state_sync.get_versions(validate=_C);local_snapshots=self.snapshots if local_only else _A
		if self.console.start_state_export(output_file=output_file,gateway=self.selected_gateway,state_connection_config=self._state_connection_config,environment_names=environment_names,local_only=local_only,confirm=confirm):
			try:export_state(state_sync=self.state_sync,output_file=output_file,local_snapshots=local_snapshots,environment_names=environment_names,console=self.console);self.console.stop_state_export(success=_C,output_file=output_file)
			except:self.console.stop_state_export(success=_B,output_file=output_file);raise
	def import_state(self,input_file:Path,clear:bool=_B,confirm:bool=_C)->_A:
		from vulcan.core.state_sync.export_import import import_state
		if self.console.start_state_import(input_file=input_file,gateway=self.selected_gateway,state_connection_config=self._state_connection_config,clear=clear,confirm=confirm):
			try:import_state(state_sync=self.state_sync,input_file=input_file,clear=clear,console=self.console);self.console.stop_state_import(success=_C,input_file=input_file)
			except:self.console.stop_state_import(success=_B,input_file=input_file);raise
	def _run_tests(self,verbosity:Verbosity=Verbosity.DEFAULT)->t.Tuple[ModelTextTestResult,str]:test_output_io=StringIO();result=self.test(stream=test_output_io,verbosity=verbosity);return result,test_output_io.getvalue()
	def _run_plan_tests(self,skip_tests:bool=_B,environment:t.Optional[str]=_A)->t.Optional[ModelTextTestResult]:
		if not skip_tests:
			result=self.test(environment=environment)
			if not result.wasSuccessful():raise PlanError('Cannot generate plan due to failing test(s). Fix test(s) and run again.')
			return result
	@property
	def _model_tables(self)->t.Dict[str,str]:return{fqn:snapshot.table_name()if snapshot.version else snapshot.qualified_view_name.for_environment(EnvironmentNamingInfo.from_environment_catalog_mapping(self.environment_catalog_mapping,name=c.PROD,suffix_target=self.config.environment_suffix_target))for(fqn,snapshot)in self.snapshots.items()}
	@cached_property
	def lineage_mapping_schema(self)->LineageMappingSchema:
		schema:t.Dict[str,t.Any]={};physical_table_index:t.Dict[str,str]={};prod_naming=EnvironmentNamingInfo.from_environment_catalog_mapping(self.environment_catalog_mapping,name=c.PROD,suffix_target=self.config.environment_suffix_target)
		def column_types(model:Model)->t.Optional[t.Dict[str,str]]:
			if not(columns_to_types:=model.columns_to_types):return
			columns={col:dtype.sql(dialect=model.dialect)if hasattr(dtype,'sql')else str(dtype)for(col,dtype)in columns_to_types.items()};return columns or _A
		def register_table(table_fqn:str,columns:t.Dict[str,str])->_A:
			parts=table_fqn.split('.')
			if len(parts)>3:return
			node=schema
			for part in parts[:-1]:node=node.setdefault(part,{})
			node[parts[-1]]=columns
		for model in self.models.values():
			if(columns:=column_types(model)):register_table(fqn_to_unquoted(model.fqn,dialect=model.dialect),columns)
		for(model_fqn,snapshot)in self.snapshots.items():
			try:physical_table=snapshot.table_name()if snapshot.version else snapshot.qualified_view_name.for_environment(prod_naming)
			except Exception:logger.debug('Skipping physical table mapping for snapshot %s',model_fqn,exc_info=_C);continue
			if not physical_table:continue
			model=self.get_model(model_fqn,raise_if_missing=_B)
			if not model or not(columns:=column_types(model)):continue
			dialect=model.dialect or self.default_dialect or'postgres'
			try:physical_fqn=fqn_to_unquoted(normalize_model_name(parse_one(physical_table,read=dialect),default_catalog=self.default_catalog,dialect=dialect),dialect=dialect)
			except Exception:continue
			physical_table_index[physical_fqn]=model_fqn;register_table(physical_fqn,columns)
		return LineageMappingSchema(schema=schema,physical_table_index=physical_table_index)
	@cached_property
	def cache_dir(self)->Path:
		if self.config.cache_dir:
			cache_path=Path(self.config.cache_dir)
			if cache_path.is_absolute():return cache_path
			return self.path/cache_path
		return self.path/c.CACHE
	@cached_property
	def engine_adapters(self)->t.Dict[str,EngineAdapter]:
		adapters:t.Dict[str,EngineAdapter]={self.selected_gateway:self.engine_adapter}
		for config in self.configs.values():
			for gateway_name in config.gateways:
				if gateway_name not in adapters:connection=config.get_connection(gateway_name);adapter=connection.create_engine_adapter(concurrent_tasks=self.concurrent_tasks);adapters[gateway_name]=adapter
		return adapters
	@cached_property
	def default_catalog_per_gateway(self)->t.Dict[str,str]:return self._scheduler.get_default_catalog_per_gateway(self)
	@property
	def concurrent_tasks(self)->int:
		if self._concurrent_tasks is _A:self._concurrent_tasks=self.connection_config.concurrent_tasks
		return self._concurrent_tasks
	@cached_property
	def connection_config(self)->ConnectionConfig:return self.config.get_connection(self.selected_gateway)
	@cached_property
	def test_connection_config(self)->ConnectionConfig:return self.config.get_test_connection(self.gateway,self.default_catalog,default_catalog_dialect=self.config.dialect)
	@cached_property
	def environment_catalog_mapping(self)->RegexKeyDict:
		engine_adapter=_A
		try:engine_adapter=self.engine_adapter
		except Exception:pass
		if self.config.environment_catalog_mapping and engine_adapter and not self.engine_adapter.catalog_support.is_multi_catalog_supported:raise VulcanError('Environment catalog mapping is only supported for engine adapters that support multiple catalogs')
		return self.config.environment_catalog_mapping
	def _get_engine_adapter(self,gateway:t.Optional[str]=_A)->EngineAdapter:
		if gateway:
			if(adapter:=self.engine_adapters.get(gateway)):return adapter
			raise VulcanError(f"Gateway '{gateway}' not found in the available engine adapters.")
		return self.engine_adapter
	def _snapshots(self,models_override:t.Optional[UniqueKeyDict[str,Model]]=_A)->t.Dict[str,Snapshot]:
		nodes={**(models_override or self._models),**self._standalone_audits};snapshots=self._nodes_to_snapshots(nodes);stored_snapshots=self.state_reader.get_snapshots(snapshots.values());unrestorable_snapshots={snapshot for snapshot in stored_snapshots.values()if snapshot.name in nodes and snapshot.unrestorable}
		if unrestorable_snapshots:
			for snapshot in unrestorable_snapshots:logger.info('Found a unrestorable snapshot %s. Restamping the model...',snapshot.name);node=nodes[snapshot.name];nodes[snapshot.name]=node.copy(update={'stamp':f"revert to {snapshot.identifier}"})
			snapshots=self._nodes_to_snapshots(nodes);stored_snapshots=self.state_reader.get_snapshots(snapshots.values())
		for snapshot in stored_snapshots.values():snapshot.node=snapshots[snapshot.name].node
		return{name:stored_snapshots.get(s.snapshot_id,s)for(name,s)in snapshots.items()}
	def _context_diff(self,environment:str,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,create_from:t.Optional[str]=_A,force_no_diff:bool=_B,ensure_finalized_snapshots:bool=_B,diff_rendered:bool=_B,always_recreate_environment:bool=_B)->ContextDiff:
		environment=Environment.sanitize_name(environment)
		if force_no_diff:return ContextDiff.create_no_diff(environment,self.state_reader)
		return ContextDiff.create(environment,snapshots=snapshots or self.snapshots,create_from=create_from or c.PROD,state_reader=self.state_reader,provided_requirements=self._requirements,excluded_requirements=self._excluded_requirements,ensure_finalized_snapshots=ensure_finalized_snapshots,diff_rendered=diff_rendered,environment_statements=self._environment_statements,gateway_managed_virtual_layer=self.config.gateway_managed_virtual_layer,infer_python_dependencies=self.config.infer_python_dependencies,always_recreate_environment=always_recreate_environment)
	def _destroy(self)->bool:
		for environment in self.state_reader.get_environments():self.state_sync.invalidate_environment(name=environment.name,protect_prod=_B);self.console.log_success(f"Environment '{environment.name}' invalidated.")
		self._run_janitor(ignore_ttl=_C);self.state_sync.remove_state(including_backup=_C);self.console.log_status_update('State tables removed.');self.clear_caches();return _C
	def _run_janitor(self,ignore_ttl:bool=_B)->_A:current_ts=now_timestamp();self._cleanup_environments(current_ts=current_ts);delete_expired_snapshots(self.state_sync,self.snapshot_evaluator,current_ts=current_ts,ignore_ttl=ignore_ttl,console=self.console,batch_size=self.config.janitor.expired_snapshots_batch_size);self.state_sync.compact_intervals()
	def _cleanup_environments(self,current_ts:t.Optional[int]=_A)->_A:
		current_ts=current_ts or now_timestamp();expired_environments_summaries=self.state_sync.get_expired_environments(current_ts=current_ts)
		for expired_env_summary in expired_environments_summaries:
			expired_env=self.state_reader.get_environment(expired_env_summary.name)
			if expired_env:cleanup_expired_views(default_adapter=self.engine_adapter,engine_adapters=self.engine_adapters,environments=[expired_env],warn_on_delete_failure=self.config.janitor.warn_on_delete_failure,console=self.console)
		self.state_sync.delete_expired_environments(current_ts=current_ts)
	def _try_connection(self,connection_name:str,validator:t.Callable[[],_A])->_A:
		connection_name=connection_name.capitalize()
		try:validator();self.console.log_status_update(f"{connection_name} connection [green]succeeded[/green]")
		except Exception as ex:self.console.log_error(f"{connection_name} connection failed. {ex}")
	def _new_state_sync(self)->StateSync:return self._provided_state_sync or self._scheduler.create_state_sync(self)
	def _new_selector(self,models:t.Optional[UniqueKeyDict[str,Model]]=_A,dag:t.Optional[DAG[str]]=_A)->Selector:return self._selector_cls(self.state_reader,models=models or self._models,context_path=self.path,dag=dag,default_catalog=self.default_catalog,dialect=self.default_dialect,cache_dir=self.cache_dir)
	def _register_notification_targets(self)->_A:
		event_notifications=collections.defaultdict(set)
		for target in self.notification_targets:
			if target.is_configured:
				for event in target.notify_on:event_notifications[event].add(target)
		user_notification_targets={user.username:set(target for target in user.notification_targets if target.is_configured)for user in self.users}
		def store_notification(**kwargs:t.Any)->_A:
			state_sync=self._new_state_sync();store=getattr(state_sync,'store_notification',_A)
			if store is _A:return
			store(**kwargs)
		db_target=DbNotificationTarget.create(store_notification)
		for event in NotificationEvent:event_notifications[event].add(db_target)
		self.notification_target_manager=NotificationTargetManager(event_notifications,user_notification_targets,username=self.config.username)
	def shutdown_for_exit(self)->_A:
		try:self.notification_target_manager.stop()
		except Exception:logger.exception('Notification stop failed on exit.')
		try:prometheus.stop()
		except Exception:logger.exception('Core Prometheus stop failed on exit.')
	def _load_materializations(self)->_A:
		if not self._loaded:
			for loader in self._loaders:loader.load_materializations()
	def _select_models_for_run(self,select_models:t.Collection[str],no_auto_upstream:bool,snapshots:t.Collection[Snapshot])->t.Set[str]:
		models:UniqueKeyDict[str,Model]=UniqueKeyDict(_S,**{s.name:s.model for s in snapshots if s.is_model});dag:DAG[str]=DAG()
		for(fqn,model)in models.items():dag.add(fqn,model.depends_on)
		model_selector=self._new_selector(models=models,dag=dag);result=set(model_selector.expand_model_selections(select_models))
		if not no_auto_upstream:result=set(dag.subdag(*result))
		return result
	@cached_property
	def _project_type(self)->str:project_types={c.DBT if loader.__class__.__name__.lower().startswith(c.DBT)else c.NATIVE for loader in self._loaders};return c.HYBRID if len(project_types)>1 else first(project_types)
	def _nodes_to_snapshots(self,nodes:t.Dict[str,Node])->t.Dict[str,Snapshot]:
		snapshots:t.Dict[str,Snapshot]={};fingerprint_cache:t.Dict[str,SnapshotFingerprint]={}
		for node in nodes.values():
			kwargs:t.Dict[str,t.Any]={}
			if node.project in self._projects:config=self.config_for_node(node);kwargs['ttl']=config.snapshot_ttl;kwargs['table_naming_convention']=config.physical_table_naming_convention
			snapshot=Snapshot.from_node(node,nodes=nodes,cache=fingerprint_cache,**kwargs);snapshots[snapshot.name]=snapshot
		return snapshots
	def _node_or_snapshot_to_fqn(self,node_or_snapshot:NodeOrSnapshot)->str:
		if isinstance(node_or_snapshot,Snapshot):return node_or_snapshot.name
		if isinstance(node_or_snapshot,str)and not self.standalone_audits.get(node_or_snapshot):return normalize_model_name(node_or_snapshot,dialect=self.default_dialect,default_catalog=self.default_catalog)
		if not isinstance(node_or_snapshot,str):return node_or_snapshot.fqn
		return node_or_snapshot
	@property
	def _plan_preview_enabled(self)->bool:
		if self.config.plan.enable_preview is not _A:return self.config.plan.enable_preview
		return self._project_type==c.NATIVE or self.engine_adapter.SUPPORTS_CLONING
	def _get_plan_default_start_end(self,snapshots:t.Dict[str,Snapshot],max_interval_end_per_model:t.Dict[str,datetime],backfill_models:t.Optional[t.Set[str]],modified_model_names:t.Set[str],execution_time:t.Optional[TimeLike]=_A)->t.Tuple[t.Optional[int],t.Optional[int]]:
		if not max_interval_end_per_model:return _A,_A
		default_end=to_timestamp(max(max_interval_end_per_model.values()));default_start:t.Optional[int]=_A
		for model_name in backfill_models or modified_model_names or max_interval_end_per_model:
			if model_name not in snapshots:continue
			node=snapshots[model_name].node;interval_unit=node.interval_unit;default_start=min(default_start or sys.maxsize,to_timestamp(interval_unit.cron_prev(interval_unit.cron_floor(max_interval_end_per_model.get(model_name,node.cron_floor(default_end))),estimate=_C)))
		if execution_time and to_timestamp(default_end)>to_timestamp(execution_time):default_end=to_timestamp(execution_time)
		return default_start,default_end
	def _calculate_start_override_per_model(self,min_intervals:t.Optional[int],plan_start:t.Optional[TimeLike],plan_end:t.Optional[TimeLike],plan_execution_time:TimeLike,backfill_model_fqns:t.Optional[t.Set[str]],snapshots_by_model_fqn:t.Dict[str,Snapshot],end_override_per_model:t.Optional[t.Dict[str,datetime]])->t.Dict[str,datetime]:
		if not min_intervals or not backfill_model_fqns or not plan_start:return{}
		start_overrides:t.Dict[str,datetime]={};end_override_per_model=end_override_per_model or{};plan_execution_time_dt=to_datetime(plan_execution_time);plan_start_dt=to_datetime(plan_start,relative_base=plan_execution_time_dt);plan_end_dt=to_datetime(plan_end or plan_execution_time_dt,relative_base=plan_execution_time_dt);backfill_dag:DAG[str]=DAG()
		for fqn in backfill_model_fqns:backfill_dag.add(fqn,[p.name for p in snapshots_by_model_fqn[fqn].parents if p.name in backfill_model_fqns])
		reversed_dag=backfill_dag.reversed;graph=reversed_dag.graph
		for model_fqn in reversed_dag:
			min_child_start=min([start_overrides[immediate_child_fqn]for immediate_child_fqn in graph[model_fqn]],default=plan_start_dt);snapshot=snapshots_by_model_fqn.get(model_fqn)
			if not snapshot:continue
			starting_point=end_override_per_model.get(model_fqn,plan_end_dt)
			if(node_end:=snapshot.node.end):
				node_end_dt=make_exclusive(node_end)
				if node_end_dt<plan_end_dt:starting_point=node_end_dt
			snapshot_start=snapshot.node.cron_floor(starting_point)
			for _ in range(min_intervals):snapshot_start=snapshot.node.cron_prev(snapshot_start)
			start_overrides[model_fqn]=min(min_child_start,snapshot_start)
		return start_overrides
	def _get_max_interval_end_per_model(self,snapshots:t.Dict[str,Snapshot],backfill_models:t.Optional[t.Set[str]])->t.Dict[str,datetime]:models_for_interval_end=self._get_models_for_interval_end(snapshots,backfill_models)if backfill_models is not _A else _A;return{model_fqn:to_datetime(ts)for(model_fqn,ts)in self.state_sync.max_interval_end_per_model(c.PROD,models=models_for_interval_end,ensure_finalized_snapshots=self.config.plan.use_finalized_state).items()}
	@staticmethod
	def _get_models_for_interval_end(snapshots:t.Dict[str,Snapshot],backfill_models:t.Set[str])->t.Set[str]:
		models_for_interval_end=set();models_stack=list(backfill_models)
		while models_stack:
			next_model=models_stack.pop()
			if next_model not in snapshots:continue
			models_for_interval_end.add(next_model);models_stack.extend(s.name for s in snapshots[next_model].parents if s.name not in models_for_interval_end)
		return models_for_interval_end
	def lint_models(self,models:t.Optional[t.Iterable[t.Union[str,Model]]]=_A,raise_on_error:bool=_C)->t.List[AnnotatedRuleViolation]:
		found_error=_B;all_violations=[]
		for(project,linter)in self._linters.items():
			config_roots=[path for(path,config)in self.configs.items()if config.project==project]
			if not config_roots:raise ConfigError(f"No project root found in configs for linter project {project!r}.")
			lint_violation,violations=linter.lint_project(self,project_lint_source(config_roots[0]),console=self.console)
			if lint_violation:found_error=_C
			all_violations.extend(violations)
		model_list=list(self.get_model(model,raise_if_missing=_C)for model in models)if models else self.models.values()
		for model in model_list:
			if(linter:=self._linters.get(model.project)):
				lint_violation,violations=linter.lint_model(model,self,console=self.console)
				if lint_violation:found_error=_C
				all_violations.extend(violations)
		if raise_on_error and found_error:raise LinterError('Linter detected errors in the code. Please fix them before proceeding.')
		return all_violations
	def select_tests(self,tests:t.Optional[t.List[str]]=_A,patterns:t.Optional[t.List[str]]=_A)->t.List[ModelTestMetadata]:
		test_meta=self._model_test_metadata
		if tests:
			filtered_tests=[]
			for test in tests:
				if'::'in test:
					if test in self._model_test_metadata_fully_qualified_name_index:filtered_tests.append(self._model_test_metadata_fully_qualified_name_index[test])
				else:
					test_path=Path(test)
					if test_path in self._model_test_metadata_path_index:filtered_tests.extend(self._model_test_metadata_path_index[test_path])
			test_meta=filtered_tests
		if patterns:test_meta=filter_tests_by_patterns(test_meta,patterns)
		return test_meta
class Context(GenericContext[Config]):CONFIG_TYPE=Config