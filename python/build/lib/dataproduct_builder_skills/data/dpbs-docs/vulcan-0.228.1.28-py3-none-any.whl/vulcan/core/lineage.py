from __future__ import annotations
_C=True
_B=None
_A=False
import logging,typing as t
from collections import defaultdict
from dataclasses import dataclass
from sqlglot import exp,parse_one
from sqlglot.helper import first
from sqlglot.lineage import Node
from sqlglot.lineage import lineage as sqlglot_lineage
from sqlglot.optimizer import Scope,build_scope,qualify
from vulcan.core.dialect import fqn_to_unquoted,map_result_column_projections,normalize_mapping_schema,normalize_model_name,outer_select
if t.TYPE_CHECKING:from vulcan.core.context import Context;from vulcan.core.model import Model;from vulcan.core.model.definition import RollupModel;from vulcan.core.snapshot.definition import Snapshot;ModelOrSnapshot=t.Union[str,Model,Snapshot]
logger=logging.getLogger(__name__)
CACHE:t.Dict[str,t.Tuple[int,exp.Expression,Scope]]={}
@dataclass(frozen=_C)
class ColumnLineageRef:model:str;column:str;expression:str|_B=_B
def _hop_expression_sql(expr_node:exp.Expression,upstream_col:str,*,dialect:str)->str|_B:
	node=expr_node
	if isinstance(node,exp.Alias):node=node.this
	while isinstance(node,exp.Paren):node=node.this
	if isinstance(node,(exp.Table,exp.Placeholder)):return
	if isinstance(node,exp.Column)and node.name.casefold()==upstream_col.casefold():return
	return node.sql(dialect=dialect)
def _upstream_refs_from_root(root:Node,*,default_catalog:str|_B,dialect:str,model_name_for_table:t.Callable[[str],str])->t.List[ColumnLineageRef]:
	parents:t.Dict[int,Node]={}
	for node in root.walk():
		for child in node.downstream:parents[id(child)]=node
	edges:t.Dict[t.Tuple[str,str],ColumnLineageRef]={}
	for node in root.walk():
		if node.downstream:continue
		table=node.expression.find(exp.Table)
		if not table:continue
		table_fqn=normalize_model_name(table,default_catalog=default_catalog,dialect=dialect);upstream_col=exp.to_column(node.name).name;parent=parents.get(id(node));expr_node=parent.expression if parent else node.expression;expression=_hop_expression_sql(expr_node,upstream_col,dialect=dialect);model_name=model_name_for_table(table_fqn);key=model_name,upstream_col
		if key not in edges:edges[key]=ColumnLineageRef(model=model_name,column=upstream_col,expression=expression)
	return sorted(edges.values(),key=lambda ref:(ref.model,ref.column))
def lineage(column:str|exp.Column,model:Model,trim_selects:bool=_C,**kwargs:t.Any)->Node:
	query=_B;scope=_B
	if model.name in CACHE:
		obj_id,query,scope=CACHE[model.name]
		if obj_id!=id(model):query=_B;scope=_B
	if not query or not scope:
		query=t.cast(exp.Query,model.render_query_or_raise().copy())
		if model.managed_columns:query=query.select(*(exp.alias_(exp.cast(exp.Null(),to=col_type),col)for(col,col_type)in model.managed_columns.items()if col not in query.named_selects),copy=_A)
		query=qualify.qualify(query,dialect=model.dialect,schema=normalize_mapping_schema(model.mapping_schema,dialect=model.dialect),**{'validate_qualify_columns':_A,'infer_schema':_C,**kwargs});scope=build_scope(query)
		if scope:CACHE[model.name]=id(model),query,scope
	return sqlglot_lineage(column,sql=query,scope=scope,trim_selects=trim_selects,dialect=model.dialect,copy=_A)
def column_lineage_refs(context:Context,model_name:ModelOrSnapshot,column:str|exp.Column)->t.List[ColumnLineageRef]:
	model=context.get_model(model_name);dialect=model.dialect;default_catalog=context.default_catalog
	try:root=lineage(column,model,trim_selects=_A)
	except Exception:logger.debug('Failed to compute lineage for %s.%s',model.name,column,exc_info=_C);return[]
	return _upstream_refs_from_root(root,default_catalog=default_catalog,dialect=dialect,model_name_for_table=lambda table_fqn:table_fqn)
def column_dependencies(context:Context,model_name:ModelOrSnapshot,column:str|exp.Column)->t.Dict[str,t.Set[str]]:
	model=context.get_model(model_name);parents=defaultdict(set)
	for node in lineage(column,model,trim_selects=_A).walk():
		if node.downstream:continue
		table=node.expression.find(exp.Table)
		if table:name=normalize_model_name(table,default_catalog=context.default_catalog,dialect=model.dialect);parents[name].add(exp.to_column(node.name).name)
	return dict(parents)
def column_description(context:Context,model_name:str,column:str,quote_column:bool=_A)->t.Optional[str]:
	model=context.get_model(model_name)
	if not model:return
	if column in model.column_descriptions:return model.column_descriptions[column]
	dependencies=column_dependencies(context,model_name,exp.column(column,quoted=quote_column))
	if len(dependencies)!=1:return
	parent,columns=first(dependencies.items())
	if len(columns)!=1:return
	return column_description(context,parent,first(columns))
def lineage_sql(sql:str,result_columns:t.List[str],*,context:Context,dialect:str)->t.Dict[str,t.List[ColumnLineageRef]]:
	try:
		if not result_columns:return{}
		mapping=context.lineage_mapping_schema
		if not mapping.schema:return{}
		parsed=parse_one(sql,read=dialect);select=outer_select(parsed)
		if not select:return{}
		query=parsed if isinstance(parsed,exp.Select)else parsed.args.get('this')if isinstance(parsed,exp.Query)else select;qualified=qualify.qualify(t.cast(exp.Expression,query).copy(),dialect=dialect,schema=normalize_mapping_schema(mapping.schema,dialect=dialect),validate_qualify_columns=_A,infer_schema=_A);qual_select=outer_select(qualified)
		if not qual_select or not(scope:=build_scope(qualified)):return{}
		targets=map_result_column_projections(result_columns,select.expressions,qual_select.expressions);physical_index=mapping.physical_table_index
		def resolve_model(table_fqn:str)->str:
			normalized=fqn_to_unquoted(table_fqn,dialect=dialect)
			if(name:=physical_index.get(normalized)):return name
			for candidate in(table_fqn,normalized):
				if(model:=context.get_model(candidate,raise_if_missing=_A)):return model.name
			return table_fqn
		result:t.Dict[str,t.List[ColumnLineageRef]]={}
		for col in result_columns:
			try:root=sqlglot_lineage(targets[col],sql=qualified,scope=scope,trim_selects=_A,dialect=dialect,copy=_A)
			except Exception:logger.debug('lineage_sql: failed to trace column %r',col,exc_info=_C);continue
			if(refs:=_upstream_refs_from_root(root,default_catalog=context.default_catalog,dialect=dialect,model_name_for_table=resolve_model)):result[col]=refs
		return result
	except Exception:logger.debug('lineage_sql failed',exc_info=_C);return{}