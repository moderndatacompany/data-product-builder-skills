from __future__ import annotations
_E='one_to_one'
_D='many_to_one'
_C='one_to_many'
_B=True
_A=None
import typing as t
from collections import deque
from dataclasses import dataclass
_RECIPROCAL_COMPLEMENT:t.Dict[str,str]={_C:_D,_D:_C,_E:_E}
@dataclass(frozen=_B)
class JoinEdge:join_type:str;skip_for_bi:bool=False
class JoinGraph:
	def __init__(self,graph:t.Optional[t.Dict[str,t.Set[str]]]=_A,*,allow_reciprocal_edges:bool=_B)->_A:
		self._allow_reciprocal_edges=allow_reciprocal_edges;(self._graph):t.Dict[str,t.Set[str]]={};(self._edges):t.Dict[t.Tuple[str,str],JoinEdge]={}
		for(node,dependencies)in(graph or{}).items():
			self.add(node)
			for dependency in dependencies:self.add(node,dependency)
	def add(self,node:str,dependency:t.Optional[str]=_A,*,edge:t.Optional[JoinEdge]=_A)->_A:
		if node not in self._graph:self._graph[node]=set()
		if dependency is _A:return
		self._graph[node].add(dependency)
		if edge is not _A:self._edges[node,dependency]=edge
		self.add(dependency)
	@property
	def graph(self)->t.Dict[str,t.Set[str]]:return self._graph
	def join_path_exists(self,start:str,end:str)->bool:
		if start==end:return _B
		graph=self._graph;queue:t.Deque[str]=deque([start]);visited:t.Set[str]={start}
		while queue:
			curr=queue.popleft()
			for nb in graph.get(curr,()):
				if nb==end:return _B
				if nb not in visited:visited.add(nb);queue.append(nb)
			for(src,targets)in graph.items():
				if curr in targets and src==end:return _B
				if curr in targets and src not in visited:visited.add(src);queue.append(src)
		return False
	def directed_join_path(self,start:str,end:str)->t.Optional[str]:
		if start==end:return start
		graph=self._graph;queue:t.Deque[str]=deque([start]);parent:t.Dict[str,str]={};visited:t.Set[str]={start}
		while queue:
			curr=queue.popleft()
			for nb in sorted(graph.get(curr,())):
				if nb in visited:continue
				visited.add(nb);parent[nb]=curr
				if nb==end:
					path:t.List[str]=[];at=end
					while _B:
						path.append(at)
						if at==start:break
						at=parent[at]
					path.reverse();return'.'.join(path)
				queue.append(nb)
	def directed_join_path_exists(self,start:str,end:str)->bool:return self.directed_join_path(start,end)is not _A
	def _is_reciprocal(self,left:str,right:str)->bool:graph=self._graph;return right in graph.get(left,())and left in graph.get(right,())
	def reciprocal_pairs(self)->t.List[t.Tuple[str,str]]:
		pairs:t.Set[t.Tuple[str,str]]=set()
		for(source,targets)in self._graph.items():
			for target in targets:
				if source==target:continue
				if self._is_reciprocal(source,target):pairs.add(tuple(sorted((source,target))))
		return sorted(pairs)
	def _validate_reciprocal_pair(self,left:str,right:str)->t.Optional[str]:
		if not self._edges:return
		edge_lr=self._edges.get((left,right));edge_rl=self._edges.get((right,left))
		if edge_lr is _A or edge_rl is _A:return
		expected_rl=_RECIPROCAL_COMPLEMENT.get(edge_lr.join_type)
		if expected_rl!=edge_rl.join_type:return f"Reciprocal join type mismatch between '{left}' and '{right}': '{left}' declares {edge_lr.join_type!r} to '{right}' but '{right}' declares {edge_rl.join_type!r} to '{left}' (expected {expected_rl!r})."
		skip_count=int(edge_lr.skip_for_bi)+int(edge_rl.skip_for_bi)
		if skip_count!=1:return f"Reciprocal join between '{left}' and '{right}': exactly one direction must set skip_for_bi."
	def _strip_reciprocal_back_edges(self,reciprocals:t.Sequence[t.Tuple[str,str]])->t.Dict[str,t.Set[str]]:
		graph={node:set(targets)for(node,targets)in self._graph.items()}
		for(left,right)in reciprocals:graph.get(left,set()).discard(right)
		return graph
	def _find_directed_cycle(self,graph:t.Mapping[str,t.AbstractSet[str]])->t.Optional[t.List[str]]:
		visited:t.Set[str]=set();rec_stack:t.Set[str]=set();path:t.List[str]=[]
		def directed_cycle_from(node:str)->t.Optional[t.List[str]]:
			visited.add(node);rec_stack.add(node);path.append(node)
			for nb in sorted(graph.get(node,())):
				if nb not in visited:
					cycle=directed_cycle_from(nb)
					if cycle:return cycle
				elif nb in rec_stack:i=path.index(nb);return path[i:]+[nb]
			path.pop();rec_stack.remove(node)
		for n in sorted(graph):
			if n not in visited:
				cycle=directed_cycle_from(n)
				if cycle:return cycle
	def _format_cycle_error(self,cycle:t.Sequence[str])->str:cycle_fmt=' -> '.join(f"'{x}'"for x in cycle);suffix=' (reciprocal edges between two nodes are allowed).'if self._allow_reciprocal_edges else'.';return f"Circular relationship detected: {cycle_fmt}. Directed loops are not allowed{suffix}"
	def cycles(self)->t.List[str]:
		if not self._graph:return[]
		reciprocals=self.reciprocal_pairs()
		if self._allow_reciprocal_edges:
			issues=[msg for(left,right)in reciprocals if(msg:=self._validate_reciprocal_pair(left,right))is not _A]
			if issues:return issues
			cycle_graph=self._strip_reciprocal_back_edges(reciprocals)
		else:cycle_graph=self._graph
		cycle=self._find_directed_cycle(cycle_graph);return[self._format_cycle_error(cycle)]if cycle else[]