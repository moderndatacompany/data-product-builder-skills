from __future__ import annotations
_L='clustered_by'
_K='signals'
_J='grains'
_I='physical_properties'
_H='partitioned_by_'
_G='columns_to_types_'
_F=True
_E=False
_D='name'
_C='dialect'
_B='before'
_A=None
import typing as t
from enum import Enum
from functools import cached_property
from typing_extensions import Self
from pydantic import Field
from sqlglot import Dialect,exp,parse_one
from sqlglot.helper import ensure_collection,ensure_list
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from vulcan.core import dialect as d
from vulcan.core.config.common import VirtualEnvironmentMode
from vulcan.core.config.linter import LinterConfig
from vulcan.core.dialect import normalize_model_name
from vulcan.utils import classproperty
from vulcan.core.model.common import bool_validator,default_catalog_validator,depends_on_validator,properties_validator,parse_properties
from vulcan.core.model.policy import MaskExpression,parse_mask_sql
from schema.types import ColumnClassificationValue
from vulcan.core.types import Tag,Term
from vulcan.core.model.kind import CustomKind,IncrementalByUniqueKeyKind,ModelKind,OnDestructiveChange,SCDType2ByColumnKind,SCDType2ByTimeKind,TimeColumn,ViewKind,model_kind_validator,OnAdditiveChange
from vulcan.core.node import _Node,str_or_exp_to_str
from vulcan.core.reference import Reference
from vulcan.utils.date import TimeLike
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import ValidationInfo,field_validator,list_of_fields_validator,model_validator,get_dialect
if t.TYPE_CHECKING:from vulcan.core._typing import CustomMaterializationProperties,SessionProperties;from vulcan.core.engine_adapter._typing import GrantsConfig
from vulcan.core.model.policy import PolicySpec
from vulcan.core.soda3.spec import DataQualitySpec
FunctionCall=t.Tuple[str,t.Dict[str,exp.Expression]]
class GrantsTargetLayer(str,Enum):
	ALL='all';PHYSICAL='physical';VIRTUAL='virtual'
	@classproperty
	def default(cls)->'GrantsTargetLayer':return GrantsTargetLayer.VIRTUAL
	@property
	def is_all(self)->bool:return self==GrantsTargetLayer.ALL
	@property
	def is_physical(self)->bool:return self==GrantsTargetLayer.PHYSICAL
	@property
	def is_virtual(self)->bool:return self==GrantsTargetLayer.VIRTUAL
	def __str__(self)->str:return self.name
	def __repr__(self)->str:return str(self)
class ModelMeta(_Node):
	dialect:str='';name:str;kind:ModelKind=ViewKind();retention:t.Optional[int]=_A;table_format:t.Optional[str]=_A;storage_format:t.Optional[str]=_A;partitioned_by_:t.List[exp.Expression]=Field(default=[],alias='partitioned_by');clustered_by:t.List[exp.Expression]=[];default_catalog:t.Optional[str]=_A;depends_on_:t.Optional[t.Set[str]]=Field(default=_A,alias='depends_on');columns_to_types_:t.Optional[t.Dict[str,exp.DataType]]=Field(default=_A,alias='columns');column_descriptions_:t.Optional[t.Dict[str,str]]=Field(default=_A,alias='column_descriptions');column_tags_:t.Optional[t.Dict[str,t.List[Tag]]]=Field(default=_A,alias='column_tags');column_terms_:t.Optional[t.Dict[str,t.List[Term]]]=Field(default=_A,alias='column_terms');column_mask_expressions_:t.Optional[t.Dict[str,MaskExpression]]=Field(default=_A,alias='column_mask_expressions');column_classifications_:t.Optional[t.Dict[str,str]]=Field(default=_A,alias='column_classifications');audits:t.List[FunctionCall]=[];grains:t.List[exp.Expression]=[];dq:t.Optional[DataQualitySpec]=Field(default=_A,description='Optional kind: dq spec (Soda v3) baked from project YAML.');policy:t.Optional[PolicySpec]=Field(default=_A,description='Access policy spec merged from kind: policy assets.');references:t.List[exp.Expression]=[];physical_schema_override:t.Optional[str]=_A;physical_properties_:t.Optional[exp.Tuple]=Field(default=_A,alias=_I);virtual_properties_:t.Optional[exp.Tuple]=Field(default=_A,alias='virtual_properties');session_properties_:t.Optional[exp.Tuple]=Field(default=_A,alias='session_properties');allow_partials:bool=_E;signals:t.List[FunctionCall]=[];enabled:bool=_F;physical_version:t.Optional[str]=_A;gateway:t.Optional[str]=_A;optimize_query:t.Optional[bool]=_A;ignored_rules_:t.Optional[t.Set[str]]=Field(default=_A,exclude=_F,alias='ignored_rules');formatting:t.Optional[bool]=Field(default=_A,exclude=_F);virtual_environment_mode:VirtualEnvironmentMode=VirtualEnvironmentMode.default;grants_:t.Optional[exp.Tuple]=Field(default=_A,alias='grants');grants_target_layer:GrantsTargetLayer=GrantsTargetLayer.default;_bool_validator=bool_validator;_model_kind_validator=model_kind_validator;_properties_validator=properties_validator;_default_catalog_validator=default_catalog_validator;_depends_on_validator=depends_on_validator
	@field_validator('audits',_K,mode=_B)
	def _func_call_validator(cls,v:t.Any,field:t.Any)->t.Any:is_signal=getattr(field,_D if hasattr(field,_D)else'field_name')==_K;return d.extract_function_calls(v,allow_tuples=is_signal)
	@field_validator('tags_','terms_',mode=_B)
	def _value_or_tuple_validator(cls,v:t.Any,info:ValidationInfo)->t.Any:
		if v is _A:return
		return ensure_list(cls._validate_value_or_tuple(v,info.data))
	@classmethod
	def _validate_value_or_tuple(cls,v:t.Dict[str,t.Any],data:t.Dict[str,t.Any],normalize:bool=_E)->t.Any:
		dialect=data.get(_C)
		def _normalize(value:t.Any)->t.Any:return normalize_identifiers(value,dialect=dialect)if normalize else value
		if isinstance(v,exp.Paren):v=[v.unnest()]
		if isinstance(v,(exp.Tuple,exp.Array)):return[_normalize(e).name for e in v.expressions]
		if isinstance(v,exp.Expression):return _normalize(v).name
		if isinstance(v,str):value=_normalize(v);return value.name if isinstance(value,exp.Expression)else value
		if isinstance(v,(list,tuple)):return[cls._validate_value_or_tuple(elm,data,normalize=normalize)for elm in v]
		return v
	@field_validator('table_format','storage_format',mode=_B)
	def _format_validator(cls,v:t.Any,info:ValidationInfo)->t.Optional[str]:
		if isinstance(v,exp.Expression)and not isinstance(v,(exp.Literal,exp.Identifier)):return v.sql(info.data.get(_C))
		return str_or_exp_to_str(v)
	@field_validator(_C,mode=_B)
	def _dialect_validator(cls,v:t.Any)->t.Optional[str]:dialect=str_or_exp_to_str(v);return dialect and dialect.lower()
	@field_validator('physical_version',mode=_B)
	def _physical_version_validator(cls,v:t.Any)->t.Optional[str]:
		if v is _A:return v
		return str_or_exp_to_str(v)
	@field_validator('gateway',mode=_B)
	def _gateway_validator(cls,v:t.Any)->t.Optional[str]:
		if v is _A:return
		gateway=str_or_exp_to_str(v);return gateway and gateway.lower()
	@field_validator(_H,_L,mode=_B)
	def _partition_and_cluster_validator(cls,v:t.Any,info:ValidationInfo)->t.List[exp.Expression]:
		if isinstance(v,list)and all(isinstance(i,str)for i in v)and info.field_name==_H:string_to_parse=f"({','.join(v)})";parsed=parse_one(string_to_parse,into=exp.PartitionedByProperty,dialect=get_dialect(info));v=parsed.this.expressions if isinstance(parsed.this,exp.Schema)else v
		expressions=list_of_fields_validator(v,info.data)
		for expression in expressions:
			num_cols=len(list(expression.find_all(exp.Column)));error_msg:t.Optional[str]=_A
			if num_cols==0:error_msg='does not contain a column'
			elif num_cols>1:error_msg='contains multiple columns'
			if error_msg:raise ConfigError(f"Field '{expression}' {error_msg}")
		return expressions
	@field_validator(_G,'derived_columns_to_types',mode=_B,check_fields=_E)
	def _columns_validator(cls,v:t.Any,info:ValidationInfo)->t.Optional[t.Dict[str,exp.DataType]]:
		columns_to_types={};dialect=info.data.get(_C);normalize=cls._should_normalize_identifiers(info)
		if isinstance(v,exp.Schema):
			for column in v.expressions:
				expr=column.args.get('kind')
				if not isinstance(expr,exp.DataType):raise ConfigError(f"Missing data type for column '{column.name}'.")
				expr.meta[_C]=dialect;col_name=normalize_identifiers(column,dialect=dialect).name if normalize else column.name;columns_to_types[col_name]=expr
			return columns_to_types
		if isinstance(v,dict):
			udt=Dialect.get_or_raise(dialect).SUPPORTS_USER_DEFINED_TYPES
			for(k,data_type)in v.items():expr=exp.DataType.build(data_type,dialect=dialect,udt=udt);expr.meta[_C]=dialect;col_name=normalize_identifiers(k,dialect=dialect).name if normalize else str(k);columns_to_types[col_name]=expr
			return columns_to_types
		return v
	@classmethod
	def _should_normalize_identifiers(cls,info:ValidationInfo)->bool:
		A='source_type';source_type=info.data.get(A)
		if source_type is _A:
			source_type_field=cls.model_fields.get(A)
			if source_type_field is not _A and isinstance(source_type_field.default,str):source_type=source_type_field.default
		if source_type in('semantic','metric'):return _E
		kind=info.data.get('kind');return not bool(getattr(kind,'is_external',_E))
	@field_validator('column_descriptions_',mode=_B)
	def _column_descriptions_validator(cls,vs:t.Any,info:ValidationInfo)->t.Optional[t.Dict[str,str]]:
		dialect=info.data.get(_C);normalize=cls._should_normalize_identifiers(info)
		if vs is _A:return
		if isinstance(vs,exp.Paren):vs=vs.flatten()
		if isinstance(vs,(exp.Tuple,exp.Array)):vs=vs.expressions
		def _extract_string_literal(expr:exp.Expression,column_name:str)->str:
			if isinstance(expr,exp.Literal):return expr.name
			elif isinstance(expr,exp.Paren):return _extract_string_literal(expr.unnest(),column_name)
			else:raise ValueError(f"column_descriptions['{column_name}'] must be a string literal, got {type(expr).__name__}")
		raw_col_descriptions={}
		if isinstance(vs,dict):
			for(col_name,value)in vs.items():
				if not isinstance(value,str):raise ValueError(f"column_descriptions['{col_name}'] must be a string, got {type(value).__name__}")
				raw_col_descriptions[col_name]=value
		else:
			for v in vs:column_name='.'.join([part.this for part in v.this.parts]);raw_col_descriptions[column_name]=_extract_string_literal(v.expression,column_name)
		col_descriptions={normalize_identifiers(k,dialect=dialect).name:v for(k,v)in raw_col_descriptions.items()}if normalize else dict(raw_col_descriptions);columns_to_types=info.data.get(_G)
		if columns_to_types:
			from vulcan.core.console import get_console;console=get_console()
			for column_name in list(col_descriptions):
				if column_name not in columns_to_types:console.log_warning(f"In model '{info.data[_D]}', a description is provided for an unknown column '{column_name}'");del col_descriptions[column_name]
		return col_descriptions
	@field_validator('column_mask_expressions_',mode=_B)
	def _column_mask_expressions_validator(cls,vs:t.Any,info:ValidationInfo)->t.Optional[t.Dict[str,MaskExpression]]:
		dialect=info.data.get(_C);normalize=cls._should_normalize_identifiers(info)
		if vs is _A:return
		if isinstance(vs,exp.Paren):vs=vs.flatten()
		if isinstance(vs,(exp.Tuple,exp.Array)):vs=vs.expressions
		raw_masks:dict[str,MaskExpression]={}
		if isinstance(vs,dict):
			for(col_name,value)in vs.items():
				if not isinstance(value,str):raise ValueError(f"column_mask_expressions['{col_name}'] must be a SQL string, got {type(value).__name__}")
				raw_masks[str(col_name)]=parse_mask_sql(value,dialect=dialect,context=f"column_mask_expressions['{col_name}']")
		else:
			for v in vs:column_name='.'.join([part.this for part in v.this.parts]);raw_masks[column_name]=parse_mask_sql(v.expression,dialect=dialect,context=f"column_mask_expressions['{column_name}']")
		col_masks={normalize_identifiers(k,dialect=dialect).name:v for(k,v)in raw_masks.items()}if normalize else dict(raw_masks);columns_to_types=info.data.get(_G)
		if columns_to_types:
			from vulcan.core.console import get_console;console=get_console()
			for column_name in list(col_masks):
				if column_name not in columns_to_types:console.log_warning(f"In model '{info.data[_D]}', a mask expression is provided for an unknown column '{column_name}'");del col_masks[column_name]
		return col_masks
	@field_validator('column_classifications_',mode=_B)
	def _column_classifications_validator(cls,vs:t.Any,info:ValidationInfo)->t.Optional[t.Dict[str,str]]:
		dialect=info.data.get(_C);normalize=cls._should_normalize_identifiers(info)
		if vs is _A:return
		if isinstance(vs,exp.Paren):vs=vs.flatten()
		if isinstance(vs,(exp.Tuple,exp.Array)):vs=vs.expressions
		raw_classifications:dict[str,str]={}
		if isinstance(vs,dict):
			for(col_name,value)in vs.items():
				if isinstance(value,exp.Literal):raw_classifications[str(col_name)]=value.name
				else:raw_classifications[str(col_name)]=str(value)
		else:
			for v in vs:
				if isinstance(v,exp.EQ):column_name='.'.join(part.this for part in v.this.parts);level_expr=v.expression
				elif isinstance(v,exp.Alias):
					if not isinstance(v.this,exp.Column):raise ValueError(f"column_classifications shorthand entries must be column identifiers, got {type(v.this).__name__}")
					column_name='.'.join(part.this for part in v.this.parts);level_expr=v.alias
				else:raise ValueError(f"column_classifications entries must use col = 'level' or col level syntax, got {type(v).__name__}")
				if isinstance(level_expr,exp.Literal):raw_classifications[column_name]=level_expr.name
				elif isinstance(level_expr,exp.Identifier):raw_classifications[column_name]=level_expr.name
				else:raw_classifications[column_name]=str(level_expr)
		col_classifications:t.Dict[str,str]={};allowed_levels=frozenset(t.get_args(ColumnClassificationValue))
		for(col_name,raw)in raw_classifications.items():
			normalized=str(raw).strip().casefold()
			if not normalized:raise ValueError(f"column_classifications['{col_name}'] column classification cannot be empty")
			if normalized not in allowed_levels:allowed=', '.join(sorted(allowed_levels));raise ValueError(f"column_classifications['{col_name}'] column classification must be one of: {allowed}; got {raw!r}")
			col_classifications[col_name]=normalized
		if normalize:col_classifications={normalize_identifiers(k,dialect=dialect).name:v for(k,v)in col_classifications.items()}
		columns_to_types=info.data.get(_G)
		if columns_to_types:
			from vulcan.core.console import get_console;console=get_console()
			for column_name in list(col_classifications):
				if column_name not in columns_to_types:console.log_warning(f"In model '{info.data[_D]}', a classification is provided for an unknown column '{column_name}'");del col_classifications[column_name]
		return col_classifications
	@classmethod
	def _parse_column_tags_terms_metadata(cls,vs:t.Any,info:ValidationInfo,*,field_label:str)->t.Optional[t.Dict[str,t.List[t.Any]]]:
		dialect=info.data.get(_C);normalize=cls._should_normalize_identifiers(info)
		if vs is _A:return
		if isinstance(vs,exp.Paren):vs=vs.flatten()
		if isinstance(vs,(exp.Tuple,exp.Array)):vs=vs.expressions
		def _extract_string_list(expr:exp.Expression)->t.List[str]:
			if isinstance(expr,(exp.Tuple,exp.Array)):return[e.name if isinstance(e,exp.Literal)else str(e)for e in expr.expressions]
			if isinstance(expr,exp.Literal):return[expr.name]
			if isinstance(expr,exp.Paren):return _extract_string_list(expr.unnest())
			return[str(expr)]
		raw_col_metadata=vs if isinstance(vs,dict)else{'.'.join([part.this for part in v.this.parts]):_extract_string_list(v.expression)for v in vs};col_metadata:t.Dict[str,t.List[t.Any]]={normalize_identifiers(k,dialect=dialect).name:v for(k,v)in raw_col_metadata.items()}if normalize else dict(raw_col_metadata);columns_to_types=info.data.get(_G)
		if columns_to_types:
			from vulcan.core.console import get_console;console=get_console()
			for column_name in list(col_metadata):
				if column_name not in columns_to_types:console.log_warning(f"In model '{info.data[_D]}', {field_label} are provided for an unknown column '{column_name}'");del col_metadata[column_name]
		return col_metadata
	@field_validator('column_tags_',mode=_B)
	def _column_tags_validator(cls,vs:t.Any,info:ValidationInfo)->t.Optional[t.Dict[str,t.List[Tag]]]:
		col_metadata=cls._parse_column_tags_terms_metadata(vs,info,field_label='tags')
		if col_metadata is _A:return
		return{col:[Tag(tag)for tag in tags]for(col,tags)in col_metadata.items()}
	@field_validator('column_terms_',mode=_B)
	def _column_terms_validator(cls,vs:t.Any,info:ValidationInfo)->t.Optional[t.Dict[str,t.List[Term]]]:
		col_metadata=cls._parse_column_tags_terms_metadata(vs,info,field_label='terms')
		if col_metadata is _A:return
		return{col:[Term(term)for term in terms]for(col,terms)in col_metadata.items()}
	@field_validator(_J,'references',mode=_B)
	def _refs_validator(cls,vs:t.Any,info:ValidationInfo)->t.List[exp.Expression]:
		dialect=info.data.get(_C)
		if isinstance(vs,exp.Paren):vs=vs.unnest()
		if isinstance(vs,(exp.Tuple,exp.Array)):vs=vs.expressions
		else:vs=[d.parse_one(v,dialect=dialect)if isinstance(v,str)else v for v in ensure_collection(vs)]
		refs=[]
		for v in vs:v=exp.column(v)if isinstance(v,exp.Identifier)else v;v.meta[_C]=dialect;refs.append(v)
		return refs
	@field_validator('ignored_rules_',mode=_B)
	def ignored_rules_validator(cls,vs:t.Any)->t.Any:return LinterConfig._validate_rules(vs)
	@field_validator('grants_target_layer',mode=_B)
	def _grants_target_layer_validator(cls,v:t.Any)->t.Any:
		if isinstance(v,exp.Identifier):return v.this
		if isinstance(v,exp.Literal)and v.is_string:return v.this
		return v
	@field_validator('session_properties_',mode=_B)
	def session_properties_validator(cls,v:t.Any,info:ValidationInfo)->t.Any:
		parsed_session_properties=parse_properties(type(cls),v,info)
		if not parsed_session_properties:return parsed_session_properties
		for eq in parsed_session_properties:
			prop_name=eq.left.name
			if prop_name=='query_label':
				query_label=eq.right
				if not isinstance(query_label,(exp.Array,exp.Tuple,exp.Paren,d.MacroFunc,d.MacroVar)):raise ConfigError('Invalid value for `session_properties.query_label`. Must be an array or tuple.')
				label_tuples:t.List[exp.Expression]=[query_label.unnest()]if isinstance(query_label,exp.Paren)else query_label.expressions
				for label_tuple in label_tuples:
					if not(isinstance(label_tuple,exp.Tuple)and len(label_tuple.expressions)==2 and all(isinstance(label,exp.Literal)for label in label_tuple.expressions)):raise ConfigError('Invalid entry in `session_properties.query_label`. Must be tuples of string literals with length 2.')
			elif prop_name=='authorization':
				authorization=eq.right
				if not(isinstance(authorization,exp.Literal)and authorization.is_string)and not isinstance(authorization,(d.MacroFunc,d.MacroVar)):raise ConfigError('Invalid value for `session_properties.authorization`. Must be a string literal.')
		return parsed_session_properties
	@model_validator(mode=_B)
	def _pre_root_validator(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		grain=data.pop('grain',_A)
		if grain:
			grains=data.get(_J)
			if grains:raise ConfigError(f"Cannot use argument 'grain' ({grain}) with 'grains' ({grains}), use only grains")
			data[_J]=ensure_list(grain)
		table_properties=data.pop('table_properties',_A)
		if table_properties:
			if not isinstance(table_properties,str):model_name=data[_D];from vulcan.core.console import get_console;get_console().log_warning(f"Model '{model_name}' is using the `table_properties` attribute which is deprecated. Please use `physical_properties` instead.")
			physical_properties=data.get(_I)
			if physical_properties:raise ConfigError(f"Cannot use argument 'table_properties' ({table_properties}) with 'physical_properties' ({physical_properties}), use only physical_properties.")
			data[_I]=table_properties
		_=data.pop('profiles',_A);return data
	@model_validator(mode='after')
	def _root_validator(self)->Self:
		kind:t.Any=self.kind
		for field in(_H,_L):
			if getattr(self,field,_A)and not kind.is_materialized and not(kind.is_view and kind.materialized):name=field[:-1]if field.endswith('_')else field;raise ValueError(f"{name} field cannot be set for {kind.name} models")
		if kind.is_incremental_by_partition and not getattr(self,_H,_A):raise ValueError(f"partitioned_by field is required for {kind.name} models")
		if(storage_format:=self.storage_format)and storage_format.lower()in{'iceberg','hive','hudi','delta'}:from vulcan.core.console import get_console;get_console().log_warning(f"Model {self.name} has `storage_format` set to a table format '{storage_format}' which is deprecated. Please use the `table_format` property instead.")
		if self.gateway is not _A:raise ConfigError(f"Model '{self.name}' cannot have `gateway` set explicitly. Gateway selection is handled automatically.")
		if self.grants is not _A and not kind.supports_grants:raise ValueError(f"grants cannot be set for {kind.name} models")
		return self
	@property
	def time_column(self)->t.Optional[TimeColumn]:return getattr(self.kind,'time_column',_A)
	@property
	def unique_key(self)->t.List[exp.Expression]:
		if isinstance(self.kind,(SCDType2ByTimeKind,SCDType2ByColumnKind,IncrementalByUniqueKeyKind)):return self.kind.unique_key
		return[]
	@property
	def column_descriptions(self)->t.Dict[str,str]:return self.column_descriptions_ or{}
	@property
	def column_mask_expressions(self)->t.Dict[str,MaskExpression]:return self.column_mask_expressions_ or{}
	@property
	def column_classifications(self)->t.Dict[str,ColumnClassificationValue]:return t.cast(t.Dict[str,ColumnClassificationValue],self.column_classifications_ or{})
	@property
	def lookback(self)->int:return getattr(self.kind,'lookback',0)or 0
	def lookback_start(self,start:TimeLike)->TimeLike:
		if self.lookback==0:return start
		for _ in range(self.lookback):start=self.interval_unit.cron_prev(start)
		return start
	@property
	def batch_size(self)->t.Optional[int]:return getattr(self.kind,'batch_size',_A)
	@property
	def batch_concurrency(self)->t.Optional[int]:return getattr(self.kind,'batch_concurrency',_A)
	@cached_property
	def physical_properties(self)->t.Dict[str,exp.Expression]:
		if self.physical_properties_:return{e.this.name:e.expression for e in self.physical_properties_.expressions}
		return{}
	@cached_property
	def virtual_properties(self)->t.Dict[str,exp.Expression]:
		if self.virtual_properties_:return{e.this.name:e.expression for e in self.virtual_properties_.expressions}
		return{}
	@property
	def session_properties(self)->SessionProperties:
		if not self.session_properties_:return{}
		return d.interpret_key_value_pairs(self.session_properties_)
	@property
	def custom_materialization_properties(self)->CustomMaterializationProperties:
		if isinstance(self.kind,CustomKind):return self.kind.materialization_properties
		return{}
	@cached_property
	def grants(self)->t.Optional[GrantsConfig]:
		if self.grants_ is _A:return
		if not self.grants_.expressions:return{}
		grants_dict={}
		for eq_expr in self.grants_.expressions:
			try:permission_name=self._validate_config_expression(eq_expr.left);grantee_list=self._validate_nested_config_values(eq_expr.expression);grants_dict[permission_name]=grantee_list
			except ConfigError as e:permission_name=eq_expr.left.name if hasattr(eq_expr.left,_D)else str(eq_expr.left);raise ConfigError(f"Invalid grants configuration for '{permission_name}': {e}")
		return grants_dict if grants_dict else _A
	@property
	def all_references(self)->t.List[Reference]:return[Reference(model_name=self.name,expression=e,unique=_F)for e in self.grains]+[Reference(model_name=self.name,expression=e,unique=_F)for e in self.references]
	@property
	def on(self)->t.List[str]:
		on:t.List[str]=[]
		for expr in[ref.expression for ref in self.all_references if ref.unique]:
			if isinstance(expr,exp.Tuple):on.extend([key.this.sql(dialect=self.dialect)for key in expr.expressions])
			else:on.append(expr.this.sql(dialect=self.dialect))
		return on
	@property
	def managed_columns(self)->t.Dict[str,exp.DataType]:return getattr(self.kind,'managed_columns',{})
	@property
	def when_matched(self)->t.Optional[exp.Whens]:
		if isinstance(self.kind,IncrementalByUniqueKeyKind):return self.kind.when_matched
	@property
	def merge_filter(self)->t.Optional[exp.Expression]:
		if isinstance(self.kind,IncrementalByUniqueKeyKind):return self.kind.merge_filter
	@property
	def catalog(self)->t.Optional[str]:return self.fully_qualified_table.catalog
	@cached_property
	def fully_qualified_table(self)->exp.Table:return exp.to_table(self.fqn)
	@cached_property
	def fqn(self)->str:return normalize_model_name(self.name,default_catalog=self.default_catalog,dialect=self.dialect)
	@property
	def on_destructive_change(self)->OnDestructiveChange:return getattr(self.kind,'on_destructive_change',OnDestructiveChange.ALLOW)
	@property
	def on_additive_change(self)->OnAdditiveChange:return getattr(self.kind,'on_additive_change',OnAdditiveChange.ALLOW)
	@property
	def ignored_rules(self)->t.Set[str]:return self.ignored_rules_ or set()
	def _validate_config_expression(self,expr:exp.Expression)->str:
		if isinstance(expr,(d.MacroFunc,d.MacroVar)):raise ConfigError(f"Unresolved macro: {expr.sql(dialect=self.dialect)}")
		if isinstance(expr,exp.Null):raise ConfigError('NULL value')
		if isinstance(expr,exp.Literal):return str(expr.this).strip()
		if isinstance(expr,(exp.Column,exp.Identifier)):return expr.name
		return expr.sql(dialect=self.dialect).strip()
	def _validate_nested_config_values(self,value_expr:exp.Expression)->t.List[str]:
		result=[]
		def flatten_expr(expr:exp.Expression)->_A:
			if isinstance(expr,exp.Array):
				for elem in expr.expressions:flatten_expr(elem)
			elif isinstance(expr,(exp.Tuple,exp.Paren)):
				expressions=[expr.unnest()]if isinstance(expr,exp.Paren)else expr.expressions
				for elem in expressions:flatten_expr(elem)
			else:result.append(self._validate_config_expression(expr))
		flatten_expr(value_expr);return result