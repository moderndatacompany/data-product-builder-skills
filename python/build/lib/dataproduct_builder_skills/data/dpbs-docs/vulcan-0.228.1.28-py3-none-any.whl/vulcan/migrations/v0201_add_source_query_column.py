from sqlglot import exp
def migrate_schemas(engine_adapter,schema,**kwargs):
	requests_table='_query_requests';perspectives_table='_query_perspective'
	if schema:requests_table=f"{schema}.{requests_table}";perspectives_table=f"{schema}.{perspectives_table}"
	for table in(requests_table,perspectives_table):engine_adapter.execute(exp.Alter(this=exp.to_table(table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column('source_query'),kind=exp.DataType.build('text'))]))
def migrate_rows(engine_adapter,schema,**kwargs):0