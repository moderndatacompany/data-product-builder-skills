from __future__ import annotations
import fnmatch,typing as t
def to_snake_case(name:str)->str:return''.join(f"_{c.lower()}"if c.isupper()and idx!=0 else c.lower()for(idx,c)in enumerate(name))
def _path_join(parent:str,segment:str)->str:return f"{parent}/{segment}"if parent else segment
def _path_matches_preserve(path:str,pattern:str)->bool:
	if pattern.endswith('/**'):prefix=pattern[:-3];return path==prefix or path.startswith(f"{prefix}/")
	return fnmatch.fnmatchcase(path,pattern)
def _is_preserved_path(path:str,preserve_paths:t.AbstractSet[str])->bool:return any(_path_matches_preserve(path,pattern)for pattern in preserve_paths)
def to_snake_case_keys(obj:t.Any,*,preserve_paths:t.FrozenSet[str]=frozenset(),_path:str='')->t.Any:
	if isinstance(obj,dict):
		if _path and _is_preserved_path(_path,preserve_paths):return obj
		out:t.Dict[t.Any,t.Any]={}
		for(k,v)in obj.items():
			if not isinstance(k,str):out[k]=to_snake_case_keys(v,preserve_paths=preserve_paths,_path=_path_join(_path,str(k)));continue
			child_path=_path_join(_path,k);sk=to_snake_case(k)
			if _is_preserved_path(child_path,preserve_paths):out[sk]=v
			else:out[sk]=to_snake_case_keys(v,preserve_paths=preserve_paths,_path=child_path)
		return out
	if isinstance(obj,list):
		if _path and _is_preserved_path(_path,preserve_paths):return obj
		return[to_snake_case_keys(item,preserve_paths=preserve_paths,_path=_path)for item in obj]
	if isinstance(obj,tuple):return tuple(to_snake_case_keys(item,preserve_paths=preserve_paths,_path=_path)for item in obj)
	if isinstance(obj,set):return{to_snake_case_keys(item,preserve_paths=preserve_paths,_path=_path)for item in obj}
	return obj