from __future__ import annotations
_M='name cannot be empty'
_L='before'
_K='PolicyFilterExpression'
_J='filter'
_I='json'
_H='member'
_G='operator'
_F='mask'
_E='group'
_D='rules'
_C='name'
_B=True
_A=None
import json,re,typing as t
from enum import Enum
from pathlib import Path
import sqlglot.expressions as exp
from sqlglot import ParseError,parse_one
from pydantic import Field,PrivateAttr,field_validator,model_validator
from typing_extensions import Literal
from vulcan.core.constants import POLICY_KIND
from vulcan.utils.hashing import hash_data
from vulcan.utils.pydantic import PydanticModel,field_validator as sm_field_validator
from schema.filters.operators import FilterOperator as WireFilterOperator
from schema.filters.operators import validate_operator_values as validate_wire_operator_values
POLICY_FIELD_PATTERN=re.compile('^[a-zA-Z_][a-zA-Z0-9_]{0,63}$')
GROUP_PATTERN=re.compile('^[a-z][a-z0-9_]{0,63}$')
MASK_BRACE_REF_PATTERN=re.compile('\\{[^{}]+\\}')
MaskExpression=str
def parse_mask_sql(value:t.Any,*,dialect:t.Optional[str]=_A,context:str='mask_expression')->str:
	if isinstance(value,exp.Expression):ast=value.unnest()if isinstance(value,exp.Paren)else value
	elif isinstance(value,str):
		expression=value.strip()
		if not expression:raise ValueError('mask expression cannot be empty')
		match=MASK_BRACE_REF_PATTERN.search(expression)
		if match:raise ValueError(f"{context} must use bare column names, not {{...}} references (found {match.group(0)!r}; e.g. use email instead of {{users.email}}).")
		try:ast=parse_one(expression,dialect=dialect)
		except ParseError as err:raise ValueError(f"{context} is not valid SQL ({err}).")from err
	else:raise ValueError(f"mask expression must be a SQL string or expression, got {type(value).__name__}")
	return ast.sql(dialect=dialect)
def mask_expression_is_constant(mask_sql:str,*,dialect:t.Optional[str]=_A)->bool:ast=parse_one(mask_sql,dialect=dialect);return not any(column.name for column in ast.find_all(exp.Column))
class FilterOperator(str,Enum):EQUALS='equals';NOT_EQUALS='notEquals';CONTAINS='contains';NOT_CONTAINS='notContains';STARTS_WITH='startsWith';NOT_STARTS_WITH='notStartsWith';ENDS_WITH='endsWith';NOT_ENDS_WITH='notEndsWith';IN='in';NOT_IN='notIn';GT='gt';GTE='gte';LT='lt';LTE='lte';SET='set';NOT_SET='notSet';IN_DATE_RANGE='inDateRange';NOT_IN_DATE_RANGE='notInDateRange';ON_THE_DATE='onTheDate';BEFORE_DATE='beforeDate';BEFORE_OR_ON_DATE='beforeOrOnDate';AFTER_DATE='afterDate';AFTER_OR_ON_DATE='afterOrOnDate';MEASURE_FILTER='measureFilter'
_OPERATORS_WITHOUT_VALUES=frozenset({FilterOperator.SET,FilterOperator.NOT_SET,FilterOperator.MEASURE_FILTER})
POLICY_FILTER_OPERATORS=frozenset(FilterOperator)-{FilterOperator.MEASURE_FILTER}
FilterValue=t.Union[str,int,float,bool,_A]
def _validate_policy_field(value:str)->str:
	if not POLICY_FIELD_PATTERN.match(value):raise ValueError(f"invalid policy filter field: {value!r}")
	return value
def _stable_hash(obj:t.Any)->str:return hash_data([json.dumps(obj,sort_keys=_B,default=str)])
def _policy_text(value:str)->exp.Expression:return exp.Identifier(this=value,quoted=_B)
def _policy_value_to_exp(value:FilterValue)->exp.Expression:
	if value is _A:return exp.null()
	if isinstance(value,bool):return exp.true()if value else exp.false()
	if isinstance(value,int):return exp.Literal.number(value)
	if isinstance(value,float):return exp.Literal.number(value)
	return _policy_text(str(value))
class PolicyUnaryFilter(PydanticModel):
	member:str=Field(min_length=1);operator:FilterOperator;values:list[FilterValue]|_A=_A
	@sm_field_validator(_G)
	@classmethod
	def _reject_measure_filter(cls,value:FilterOperator)->FilterOperator:
		if value not in POLICY_FILTER_OPERATORS:raise ValueError(f"operator '{value.value}' is not allowed in policy filters (row-level only; measureFilter is forbidden)")
		return value
	@sm_field_validator(_H)
	@classmethod
	def _validate_short_field(cls,value:str)->str:return _validate_policy_field(value)
	@model_validator(mode='after')
	def _validate_shape(self)->PolicyUnaryFilter:validate_wire_operator_values(operator=WireFilterOperator(self.operator.value),values=self.values);return self
	@property
	def field_name(self)->str:return self.member
	def data_hash(self)->str:return _stable_hash(self.model_dump(mode=_I,exclude_none=_B,by_alias=_B))
	def metadata_hash(self)->str:return _stable_hash(self.model_dump(mode=_I,exclude_none=_B,by_alias=_B,include={_H,_G}))
	def render_exp(self)->exp.Expression:
		inner:list[exp.Expression]=[exp.Property(this=exp.to_identifier(_H),value=_policy_text(self.member)),exp.Property(this=exp.to_identifier(_G),value=_policy_text(self.operator.value))]
		if self.values is not _A:inner.append(exp.Property(this=exp.to_identifier('values'),value=exp.Tuple(expressions=[_policy_value_to_exp(v)for v in self.values])))
		return exp.Tuple(expressions=inner)
class PolicyLogicalFilter(PydanticModel):
	and_:list[_K]|_A=Field(default=_A,alias='and');or_:list[_K]|_A=Field(default=_A,alias='or')
	@model_validator(mode='after')
	def _validate_group(self)->PolicyLogicalFilter:
		if bool(self.and_)==bool(self.or_):raise ValueError("logical filter requires exactly one of 'and' or 'or'")
		children=self.and_ or self.or_ or[]
		if not children:raise ValueError("'and'/'or' must contain at least one filter")
		return self
	def _children(self)->list[PolicyFilterExpression]:return self.and_ or self.or_ or[]
	def data_hash(self)->str:return _stable_hash(self.model_dump(mode=_I,exclude_none=_B,by_alias=_B))
	def metadata_hash(self)->str:return self.data_hash()
	def render_exp(self)->exp.Expression:key='and'if self.and_ else'or';return exp.Property(this=exp.to_identifier(key),value=exp.Tuple(expressions=[child.render_exp()for child in self._children()]))
PolicyFilterExpression=t.Union[PolicyUnaryFilter,PolicyLogicalFilter]
class PolicyRuleSpec(PydanticModel):
	group:str;filter:t.List[PolicyFilterExpression]|_A=_A;mask:t.List[str]|_A=_A
	@sm_field_validator(_E)
	@classmethod
	def validate_group(cls,value:str)->str:
		group=value.strip()
		if not GROUP_PATTERN.match(group):raise ValueError(f"invalid policy group: {group!r}")
		return group
	@sm_field_validator(_F,mode=_L)
	@classmethod
	def _coerce_mask_names(cls,value:t.Any)->t.Any:
		if value is _A:return
		if value=='*':raise ValueError("mask wildcard '*' is not supported; list explicit member names")
		if not isinstance(value,list):raise ValueError('mask must be a list of member names')
		out:list[str]=[];seen:set[str]=set()
		for entry in value:
			if isinstance(entry,dict):raise ValueError('mask entries must be member names only; move mask expressions to dimension mask_expression or column_mask_expressions on the model')
			name=_validate_policy_field(str(entry).strip())
			if name in seen:raise ValueError(f"duplicate mask member {name!r}")
			seen.add(name);out.append(name)
		return out
	@staticmethod
	def _collect_filter_members(filters:t.Iterable[PolicyFilterExpression])->set[str]:
		names:set[str]=set()
		for expr in filters:
			if isinstance(expr,PolicyUnaryFilter):names.add(expr.field_name)
			elif isinstance(expr,PolicyLogicalFilter):names.update(PolicyRuleSpec._collect_filter_members(expr._children()))
		return names
	def filter_members(self)->frozenset[str]:
		if not self.filter:return frozenset()
		return frozenset(self._collect_filter_members(self.filter))
	def mask_members(self)->frozenset[str]:return frozenset(self.mask or())
	def referenced_members(self)->frozenset[str]:return self.filter_members()|self.mask_members()
	def data_hash(self)->str:payload={_E:self.group,_J:[f.data_hash()for f in self.filter]if self.filter else _A,_F:sorted(self.mask)if self.mask else _A};return _stable_hash(payload)
	def metadata_hash(self)->str:payload={_E:self.group,_J:[f.metadata_hash()for f in self.filter]if self.filter else _A,_F:sorted(self.mask)if self.mask else _A};return _stable_hash(payload)
	def render_exp(self)->exp.Expression:
		inner:list[exp.Expression]=[exp.Property(this=exp.to_identifier(_E),value=_policy_text(self.group))]
		if self.filter:inner.append(exp.Property(this=exp.to_identifier(_J),value=exp.Tuple(expressions=[f.render_exp()for f in self.filter])))
		if self.mask:inner.append(exp.Property(this=exp.to_identifier(_F),value=exp.Tuple(expressions=[_policy_text(name)for name in sorted(self.mask)])))
		return exp.Tuple(expressions=inner)
class PolicySpec(PydanticModel):
	name:str;rules:t.List[PolicyRuleSpec]=Field(min_length=1);_path:t.Optional[Path]=PrivateAttr(default=_A);_rel_path:t.Optional[Path]=PrivateAttr(default=_A)
	@sm_field_validator(_C)
	@classmethod
	def _validate_name(cls,value:str)->str:
		name=value.strip()
		if not name:raise ValueError(_M)
		return name
	@sm_field_validator(_D)
	@classmethod
	def _unique_rule_groups(cls,rules:t.List[PolicyRuleSpec])->t.List[PolicyRuleSpec]:
		seen:set[str]=set()
		for rule in rules:
			if rule.group in seen:raise ValueError(f"duplicate policy rule group: {rule.group!r}")
			seen.add(rule.group)
		return rules
	def masked_members(self)->frozenset[str]:
		members:set[str]=set()
		for rule in self.rules:members.update(rule.mask_members())
		return frozenset(members)
	def referenced_members(self)->frozenset[str]:
		members:set[str]=set()
		for rule in self.rules:members.update(rule.referenced_members())
		return frozenset(members)
	def data_hash(self)->str:rules_sorted=sorted(self.rules,key=lambda r:r.group);payload={_C:self.name,_D:[r.data_hash()for r in rules_sorted]};return _stable_hash(payload)
	def fingerprint(self)->str:return self.data_hash()
	def metadata_hash(self)->str:rules_sorted=sorted(self.rules,key=lambda r:r.group);payload={_C:self.name,_D:[r.metadata_hash()for r in rules_sorted]};return _stable_hash(payload)
	@classmethod
	def from_rules(cls,name:str,rules:t.List[PolicyRuleSpec],*,path:t.Optional[Path]=_A,rel_path:t.Optional[Path]=_A)->PolicySpec:spec=cls(name=name,rules=rules);spec._path=path;spec._rel_path=rel_path;return spec
	def render_exp(self)->exp.Expression:inner:list[exp.Expression]=[exp.Property(this=exp.to_identifier('kind'),value=exp.to_identifier(POLICY_KIND)),exp.Property(this=exp.to_identifier(_C),value=_policy_text(self.name)),exp.Property(this=exp.to_identifier(_D),value=exp.Tuple(expressions=[rule.render_exp()for rule in sorted(self.rules,key=lambda r:r.group)]))];return exp.Tuple(expressions=inner)
class PolicyAssetSpec(PydanticModel):
	kind:Literal['policy']=POLICY_KIND;name:str;depends_on:t.List[str];rules:t.List[PolicyRuleSpec]=Field(min_length=1);_path:t.Optional[Path]=PrivateAttr(default=_A);_rel_path:t.Optional[Path]=PrivateAttr(default=_A)
	@sm_field_validator(_C)
	@classmethod
	def _validate_asset_name(cls,value:str)->str:
		name=value.strip()
		if not name:raise ValueError(_M)
		return name
	@sm_field_validator('depends_on',mode=_L)
	@classmethod
	def _normalize_depends_on(cls,value:t.Any)->t.List[str]:
		if isinstance(value,str):items=[value]
		elif isinstance(value,list):items=value
		else:raise ValueError('depends_on must be a model name or list of model names')
		normalized:list[str]=[];seen:set[str]=set()
		for item in items:
			dep=str(item).strip()
			if not dep:raise ValueError('depends_on entries cannot be empty')
			if dep in seen:raise ValueError(f"duplicate depends_on entry {dep!r}")
			seen.add(dep);normalized.append(dep)
		if not normalized:raise ValueError('depends_on cannot be empty')
		return normalized
	@sm_field_validator(_D)
	@classmethod
	def _unique_rule_groups(cls,rules:t.List[PolicyRuleSpec])->t.List[PolicyRuleSpec]:
		seen:set[str]=set()
		for rule in rules:
			if rule.group in seen:raise ValueError(f"duplicate policy rule group: {rule.group!r}")
			seen.add(rule.group)
		return rules
	def to_policy_spec(self)->PolicySpec:return PolicySpec.from_rules(self.name,self.rules,path=self._path,rel_path=self._rel_path)