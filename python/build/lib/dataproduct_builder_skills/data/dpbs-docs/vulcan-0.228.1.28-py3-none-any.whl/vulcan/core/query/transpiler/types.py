from __future__ import annotations
_B=True
_A=None
import logging,typing as t
from dataclasses import dataclass
import pydantic
from pydantic import Field
from sqlglot import exp,parse_one
from schema.auth import SecurityContext
from schema.metadata import Metadata,QueryableModelKind
from schema.rest_query import RestQuery
from vulcan.core.config import Config
from vulcan.core.dialect import remove_outer_limit,wrap_query_with_alias_mapping
from vulcan.utils.errors import VulcanError
from vulcan.utils.pydantic import PydanticModel
logger=logging.getLogger(__name__)
class TranspilerHttpResponse(PydanticModel):
	model_config=pydantic.ConfigDict(extra='ignore');sql:t.Dict[str,t.Any]=Field(...,description='SQL generation result containing sql array, aliases, order, etc.')
	@property
	def sql_statement(self)->str:
		sql_data=self.sql.get('sql',[])
		if isinstance(sql_data,list)and len(sql_data)>0:return sql_data[0]
		return str(sql_data)
	@property
	def sql_params(self)->t.Optional[t.List[t.Any]]:
		sql_data=self.sql.get('sql',[])
		if isinstance(sql_data,list)and len(sql_data)>1:params=sql_data[1];return params if params else _A
	@property
	def alias_mapping(self)->t.Dict[str,str]:return self.sql.get('aliasNameToMember',{})
	@property
	def order(self)->t.List[t.Any]:return self.sql.get('order',[])
@dataclass(frozen=_B)
class QueryAnalysis:models:frozenset[str];members:frozenset[str];kinds:frozenset[QueryableModelKind];policy_models:frozenset[str];row_limit:int|_A
@dataclass(frozen=_B)
class SemanticQueryContext:
	metadata:Metadata;query:RestQuery|exp.Expression;user:str;security_context:SecurityContext;analysis:QueryAnalysis
	@property
	def index(self):return self.metadata.index
	@property
	def models(self)->frozenset[str]:return self.analysis.models
	@property
	def members(self)->frozenset[str]:return self.analysis.members
	@property
	def kinds(self)->frozenset[QueryableModelKind]:return self.analysis.kinds
	@property
	def flattened_models(self)->frozenset[str]:return self.analysis.policy_models
	@property
	def group(self)->str:return(self.security_context.group or'').strip()
	def row_limit(self)->int|_A:
		if isinstance(self.query,RestQuery):return self.query.limit
		return self.analysis.row_limit
	def limit(self)->int|_A:return self.row_limit()
@dataclass(frozen=_B)
class TranspileResult:
	sql:str;wrapped_sql:str;params:list[t.Any]|_A;columns:dict[str,str];dialect:str;context:SemanticQueryContext|_A
	@property
	def sql_statement(self)->str:return self.sql
	@property
	def wrapped_sql_statement(self)->str:return self.wrapped_sql
	@property
	def sql_params(self)->list[t.Any]|_A:return self.params
	@property
	def alias_mapping(self)->dict[str,str]:return self.columns
	@classmethod
	def from_http_response(cls,http_response:TranspilerHttpResponse,context:SemanticQueryContext|_A,*,config:Config,gateway:str,apply_row_limit:bool,wrap_aliases:bool=_B)->TranspileResult:
		from vulcan.core.query.transpiler.client import dialect_for_gateway;dialect=dialect_for_gateway(config,gateway);sql=http_response.sql_statement
		if apply_row_limit and context is not _A:sql=_apply_row_limit(sql,context,dialect=dialect)
		columns=http_response.alias_mapping;wrapped=_wrap_aliases(sql,columns,dialect=dialect)if wrap_aliases else sql;return cls(sql=sql,wrapped_sql=wrapped,params=http_response.sql_params,columns=columns,dialect=dialect,context=context)
def _apply_row_limit(sql:str,ctx:SemanticQueryContext,*,dialect:str)->str:
	row_limit=ctx.row_limit()
	try:expression=parse_one(sql,dialect=dialect)
	except Exception as e:raise VulcanError(f"Failed to parse SQL for row limit: {e}")from e
	expression=remove_outer_limit(expression)
	if row_limit is not _A:expression=t.cast(exp.Expression,expression.limit(row_limit))
	return expression.sql(dialect=dialect)
def _wrap_aliases(sql:str,columns:dict[str,str],*,dialect:str)->str:
	if not columns:return sql
	try:return wrap_query_with_alias_mapping(sql,columns,dialect=dialect)
	except Exception as exc:logger.warning('Failed to wrap SQL with alias mapping: %s. Using original SQL.',exc,exc_info=_B);return sql