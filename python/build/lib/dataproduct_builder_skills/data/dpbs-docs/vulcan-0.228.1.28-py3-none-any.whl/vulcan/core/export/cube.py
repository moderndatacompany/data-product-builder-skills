from __future__ import annotations
_I='segment'
_H='measure'
_G='dimension'
_F='SEMANTIC'
_E='rollup'
_D=False
_C='time'
_B=True
_A=None
import logging,re,typing as t
from collections import defaultdict
from sqlglot import exp,parse_one
from vulcan.core.model.definition import METRIC_COL_MEASURE,METRIC_COL_TS,SemanticModel
from vulcan.core.model.policy import MaskExpression
from vulcan.core.model.semantic import DimensionSpec,LogicalTypeValue,parse_qualified_reference
from schema.cube import Cube,CubeAccessPolicyEntry,CubeDimension,CubeJoin,CubeMemberLevelExcludes,CubeMemberLevelIncludesAll,CubeMemberLevelIncludesNone,CubeMemberMaskingIncludes,CubeMemberMaskingIncludesAll,CubeMeasure,CubePreAggregation,CubeRef,CubeRowLevelAllowAll,CubeRowLevelFilters,CubeSchema,CubeSegment,CubeSqlMask,Include,View
from schema.filters import PolicyEntry
from schema.metadata import ColumnEntry,DimensionDetails,MeasureDetails,Metadata,ModelEntry,RollupDetails,SegmentDetails,Table
logger=logging.getLogger(__name__)
_TABLE='TABLE'
_BRACED_SPAN=re.compile('\\{[^{}]+\\}')
_BRACED_COL_PREFIX='__CUBE_BRACED_COL_'
_TABLE_SENTINEL='__CUBE_TABLE__'
_TABLE_QUALIFIED=re.compile(rf'"{re.escape(_TABLE_SENTINEL)}"\."([^"]+)"|{re.escape(_TABLE_SENTINEL)}\.([a-zA-Z_][a-zA-Z0-9_]*)')
def _qualify(expression:str,*,owning_model:str,dialect:str|_A=_A)->str:
	_=owning_model;sql=(expression or'').strip()
	if not sql:return expression
	dialect=dialect or'postgres';protected_spans:list[str]=[]
	def protect_braced_spans(raw:str)->str:
		def repl(match:re.Match[str])->str:index=len(protected_spans);protected_spans.append(match.group(0));return f"{_BRACED_COL_PREFIX}{index}__.__x__"
		return _BRACED_SPAN.sub(repl,raw)
	protected=protect_braced_spans(sql)
	try:tree=parse_one(protected,dialect=dialect)
	except Exception as exc:logger.debug('Failed to parse expression %r: %s',sql,exc);return expression
	has_bare_columns=any(isinstance(node,exp.Column)and node.name and not node.table for node in tree.walk())
	if not has_bare_columns:return expression
	def qualify_bare_column(node:exp.Expression)->exp.Expression:
		if isinstance(node,exp.Column)and node.name and not node.table:return exp.column(node.name,table=_TABLE_SENTINEL)
		return node
	rewritten=tree.transform(qualify_bare_column).sql(dialect=dialect)
	def restore_table_template_refs(raw:str)->str:
		def repl(match:re.Match[str])->str:column=match.group(1)or match.group(2);return f"{{{_TABLE}}}.{column}"
		raw=_TABLE_QUALIFIED.sub(repl,raw)
		for(index,span)in enumerate(protected_spans):placeholder=f"{_BRACED_COL_PREFIX}{index}__.__x__";raw=raw.replace(placeholder,span)
		return raw
	return restore_table_template_refs(rewritten)
def _mask(mask_expression:MaskExpression|_A,*,owning_model:str,dialect:str|_A=_A)->CubeSqlMask|_A:
	if mask_expression is _A:return
	sql=_qualify(str(mask_expression),owning_model=owning_model,dialect=dialect);return CubeSqlMask(sql=sql.strip())
def _access_policy(policy:PolicyEntry)->CubeAccessPolicyEntry:
	A='*'
	if policy.filter:row_level=CubeRowLevelFilters(filters=list(policy.filter))
	else:row_level=CubeRowLevelAllowAll(allow_all=_B)
	member_masking:CubeMemberMaskingIncludesAll|CubeMemberMaskingIncludes|_A
	if policy.mask==A:member_level=CubeMemberLevelIncludesNone(includes=[]);member_masking=CubeMemberMaskingIncludesAll(includes=A)
	elif policy.mask:member_level=CubeMemberLevelExcludes(excludes=list(policy.mask));member_masking=CubeMemberMaskingIncludes(includes=list(policy.mask))
	else:member_level=CubeMemberLevelIncludesAll(includes=A);member_masking=_A
	return CubeAccessPolicyEntry(group=policy.group,row_level=row_level,member_level=member_level,member_masking=member_masking)
def _measure(col:ColumnEntry,*,semantic_name:str,dialect:str|_A=_A)->CubeMeasure:assert isinstance(col.details,MeasureDetails);measure=col.details;sql=_qualify(measure.expression,owning_model=semantic_name,dialect=dialect)if measure.expression else _A;filters=[{'sql':f"({_qualify(expr,owning_model=semantic_name,dialect=dialect)})"}for expr in measure.filters or[]];return CubeMeasure(name=col.name,type=measure.agg_type,sql=sql or _A,filters=filters,rolling_window=measure.rolling_window,public=col.public)
def _dimension(col:ColumnEntry,*,owning_model:str,dialect:str|_A=_A)->CubeDimension:assert isinstance(col.details,DimensionDetails);dimension=col.details;logical_type:LogicalTypeValue=col.ltype;time_format=str(dimension.time_format)if dimension.time_format and logical_type==_C else _A;granularities=sorted([g.model_copy(update={'ai_context':_A,'description':_A})for g in dimension.time_granularities],key=lambda granularity:granularity.name)if dimension.time_granularities else _A;return CubeDimension(name=col.name,sql=col.name,type=logical_type,primary_key=col.primary_key,public=col.public,format=time_format,granularities=granularities,mask=_mask(dimension.mask_expression,owning_model=owning_model,dialect=dialect))
def _sql_table(table:t.Optional[Table])->str:
	assert table is not _A;physical_name=table.physical.name
	if table.virtual is not _A and table.virtual.name!=physical_name:return table.virtual.name
	return physical_name
def _qualify_member(member:str,cube_name:str)->str:return member if'.'in member else f"{cube_name}.{member}"
def _rollup_object_key(model_name:str,rollup_name:str)->str:return f"{model_name}_{rollup_name}"
def _serve_ready_rollup_keys(metadata:Metadata)->frozenset[str]:
	rollups_with_no_missing_intervals={model.name.split('.')[-1]:model for model in metadata.models if model.source_type==_E and not metadata.missing_intervals.get(model.name)};serve_ready_keys:t.Set[str]=set()
	for semantic in metadata.models:
		if semantic.kind!=_F:continue
		for rollup_spec in semantic.rollups:
			if rollup_spec.is_composite:continue
			object_key=_rollup_object_key(semantic.name,rollup_spec.name)
			if object_key in rollups_with_no_missing_intervals:serve_ready_keys.add(object_key)
	return frozenset(serve_ready_keys)
def _rollup_serve_ready(rollup:RollupDetails,semantic_name:str,serve_ready_rollup_keys:t.AbstractSet[str])->bool:
	if rollup.is_composite:
		assert rollup.rollups is not _A
		for source_ref in rollup.rollups:
			parsed=parse_qualified_reference(source_ref)
			if parsed is _A:return _D
			source_model,source_rollup=parsed
			if _rollup_object_key(source_model,source_rollup)not in serve_ready_rollup_keys:return _D
		return _B
	return _rollup_object_key(semantic_name,rollup.name)in serve_ready_rollup_keys
def _pre_aggregation(rollup:RollupDetails,cube_name:str)->CubePreAggregation:
	def qualify(member:str)->str:return _qualify_member(member,cube_name)
	kwargs=dict(name=rollup.name,measures=[qualify(measure)for measure in rollup.measures],dimensions=[qualify(dimension)for dimension in rollup.dimensions],segments=[qualify(segment)for segment in rollup.segments],time_dimension=qualify(rollup.time_dimension)if rollup.time_dimension else _A,granularity=rollup.granularity,external=_D)
	if rollup.is_composite:return CubePreAggregation(type='rollup_join',rollups=list(rollup.rollups or[]),**kwargs)
	return CubePreAggregation(type=_E,**kwargs)
def _cube(semantic:ModelEntry,physical:ModelEntry,*,serve_ready_rollup_keys:t.AbstractSet[str],include_rollups:bool)->Cube:
	assert physical.table is not _A;sql_table=_sql_table(physical.table);dimension_columns=sorted((column for column in semantic.columns if column.kind==_G),key=lambda column:column.name);dimensions=[_dimension(column,owning_model=semantic.name,dialect=semantic.dialect)for column in dimension_columns];measures=[_measure(column,semantic_name=semantic.name,dialect=semantic.dialect)for column in sorted((column for column in semantic.columns if column.kind==_H),key=lambda column:column.name)];segments=[CubeSegment(name=column.name,sql=_qualify(t.cast(SegmentDetails,column.details).expression or'',owning_model=semantic.name,dialect=semantic.dialect),public=column.public)for column in sorted((column for column in semantic.columns if column.kind==_I),key=lambda column:column.name)];joins=[CubeJoin(name=join.model,relationship=join.relationship,sql=join.expression)for join in sorted(semantic.joins,key=lambda join:join.model)];access_policy=[_access_policy(policy)for policy in semantic.policies]if semantic.policies else _A;pre_aggregations:t.Optional[t.List[CubePreAggregation]]=_A
	if include_rollups:emitted=[_pre_aggregation(rollup_spec,semantic.name)for rollup_spec in semantic.rollups if _rollup_serve_ready(rollup_spec,semantic.name,serve_ready_rollup_keys)];pre_aggregations=emitted or _A
	return Cube(name=semantic.name,sql_table=sql_table,measures=measures,dimensions=dimensions,segments=segments,joins=joins,pre_aggregations=pre_aggregations,access_policy=access_policy)
def _build_cubes(metadata:Metadata,*,include_rollups:bool=_B)->t.List[Cube]:
	models_by_name={model.name:model for model in metadata.models};semantic_models=[model for model in metadata.models if model.kind==_F];serve_ready_rollup_keys=frozenset()if not include_rollups else _serve_ready_rollup_keys(metadata);cubes:t.List[Cube]=[]
	for semantic in sorted(semantic_models,key=lambda model:model.name):
		if not semantic.depends_on:continue
		physical=models_by_name.get(semantic.depends_on[0])
		if physical is _A or physical.table is _A:continue
		cubes.append(_cube(semantic,physical,serve_ready_rollup_keys=serve_ready_rollup_keys,include_rollups=include_rollups))
	return cubes
def _metric_field_triples(metric_entry:ModelEntry)->t.Iterator[t.Tuple[str,str,str]]:
	measure_column=next((column for column in metric_entry.columns if column.name==METRIC_COL_MEASURE),_A);ts_column=next((column for column in metric_entry.columns if column.name==METRIC_COL_TS),_A)
	if measure_column is _A or ts_column is _A or not measure_column.depends_on or not ts_column.depends_on or not measure_column.depends_on[0].model or not ts_column.depends_on[0].model:return
	yield(measure_column.depends_on[0].model,measure_column.depends_on[0].column or'',_H);yield(ts_column.depends_on[0].model,ts_column.depends_on[0].column or'','ts')
	for dimension_column in sorted((column for column in metric_entry.columns if column.kind==_G and column.name not in(METRIC_COL_MEASURE,METRIC_COL_TS)),key=lambda column:column.name):
		if not dimension_column.depends_on:continue
		yield(dimension_column.depends_on[0].model,dimension_column.depends_on[0].column or'',dimension_column.name)
	for segment_column in sorted((column for column in metric_entry.columns if column.kind==_I),key=lambda column:column.name):
		if not segment_column.depends_on:continue
		yield(segment_column.depends_on[0].model,segment_column.depends_on[0].column or'',segment_column.name)
def _view(metric_entry:ModelEntry)->View:
	measure_column=next((column for column in metric_entry.columns if column.name==METRIC_COL_MEASURE),_A);column_triples=tuple(_metric_field_triples(metric_entry))
	if measure_column is _A or not column_triples or not measure_column.depends_on:return View(name=metric_entry.name,cubes=[])
	join_map=metric_entry.join_map or{};columns_by_cube:t.DefaultDict[str,t.Dict[str,str]]=defaultdict(dict)
	for(cube_name,column_name,alias)in column_triples:
		column_aliases=columns_by_cube[cube_name]
		if column_name not in column_aliases:column_aliases[column_name]=alias
	cube_refs:t.List[CubeRef]=[]
	for(cube_name,column_aliases)in columns_by_cube.items():join_path=join_map.get(cube_name,cube_name);includes:t.List[t.Union[str,Include]]=[source_column if column_aliases[source_column]==source_column else Include(name=source_column,alias=column_aliases[source_column])for source_column in sorted(column_aliases)];cube_refs.append(CubeRef(join_path=join_path,includes=includes))
	return View(name=metric_entry.name,cubes=cube_refs)
def _build_views(metadata:Metadata)->t.List[View]:
	metrics=[model for model in metadata.models if model.kind=='METRIC']
	if not metrics:return[]
	return[_view(metric_entry)for metric_entry in sorted(metrics,key=lambda metric:metric.name)]
def _loaded_dim_type(dim:DimensionSpec)->str:
	if dim.granularities:return _C
	semantic_config=getattr(dim,'semantic_config',_A)
	if semantic_config is not _A and getattr(semantic_config,'type',_A)==_C:return _C
	return'string'
def build_cube_schema_for_rollups(semantic_models:t.Iterable[SemanticModel])->CubeSchema:
	cubes:t.List[Cube]=[]
	for semantic in sorted(semantic_models,key=lambda model:model.name):
		depends_on=sorted(semantic.depends_on)if semantic.depends_on else[]
		if not depends_on:continue
		grain_names={grain.name for grain in semantic.grains or[]};cubes.append(Cube(name=semantic.name,sql_table=depends_on[0],measures=[CubeMeasure(name=measure.name,type=measure.type,sql=_qualify(measure.expression or'',owning_model=semantic.name,dialect=semantic.dialect),filters=[{'sql':f"({_qualify(filter_expr,owning_model=semantic.name,dialect=semantic.dialect)})"}for filter_expr in measure.filters or[]],rolling_window=measure.rolling_window,public=measure.public)for measure in semantic.measures],dimensions=[CubeDimension(name=dimension.name,sql=dimension.name,type=_loaded_dim_type(dimension),primary_key=dimension.name in grain_names,public=dimension.public)for dimension in semantic.dimensions],segments=[CubeSegment(name=segment.name,sql=_qualify(segment.expression,owning_model=semantic.name,dialect=semantic.dialect),public=segment.public)for segment in semantic.segments],joins=[CubeJoin(name=join.name,relationship=join.type,sql=join.expression)for join in semantic.joins]))
	return CubeSchema(cubes=cubes,views=[])
def build_cube_schema(metadata:Metadata,*,include_rollups:bool=_B)->CubeSchema:
	cubes=_build_cubes(metadata,include_rollups=include_rollups)
	if not cubes:return CubeSchema(cubes=[],views=[])
	views=_build_views(metadata);return CubeSchema(cubes=cubes,views=views)