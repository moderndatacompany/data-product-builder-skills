from __future__ import annotations
_m='metric'
_l='semantic'
_k='skip_for_bi'
_j='granularity'
_i='measures'
_h='format'
_g='interval'
_f='BOOLEAN'
_e='count_distinct_approx'
_d='count_distinct'
_c='SegmentSpec'
_b='filters'
_a='MeasureSpec'
_Z='measure'
_Y='granularities'
_X='string'
_W='ref'
_V='dimensions'
_U=False
_T='number'
_S='boolean'
_R='<unknown>'
_Q='time'
_P='public'
_O='segments'
_N='behavior'
_M='count'
_L='expression'
_K='terms'
_J='tags'
_I='type'
_H='ai_context'
_G='after'
_F='description'
_E='json'
_D='before'
_C='name'
_B=True
_A=None
import json,re,typing as t
from functools import cached_property
from typing import get_args
from pydantic import Field,field_validator,model_validator
from typing_extensions import Literal
from sqlglot import exp
from schema.joins import JoinOn,compile_join_on
from schema.rest_query import RestDateRange
from schema.types import AiContextSpec,DimensionBehaviorSpec,JoinRelationshipValue as JoinRelationshipValue,LogicalTypeValue as LogicalTypeValue,MeasureBehaviorSpec,MeasureTypeValue as MeasureTypeValue,MetricGranularityValue as MetricGranularityValue,RollingWindowSpec as RollingWindowSpec,TimeGranularitySpec as _WireTimeGranularitySpec
from vulcan.core.types import Tag,Term
from vulcan.core.config.common import MetricJoinPath
from vulcan.utils.errors import ConfigError
from vulcan.utils.hashing import hash_data
from vulcan.utils.pydantic import PydanticModel
MAX_IDENTIFIER_LENGTH=64
VALID_IDENTIFIER_PATTERN=re.compile('^[a-zA-Z_][a-zA-Z0-9_]{0,63}$')
_METRIC_ADJUNCT_NAME_RESERVED=frozenset({_Z,_Q,'ts'})
from sqlglot import ParseError
from vulcan.utils.errors import VulcanError
STRICT_TIMESTAMP_TYPES:t.Final[t.Tuple[exp.DataType.Type,...]]=(exp.DataType.Type.TIMESTAMP,exp.DataType.Type.TIMESTAMPTZ,exp.DataType.Type.TIMESTAMPNTZ,exp.DataType.Type.TIMESTAMPLTZ,exp.DataType.Type.DATETIME,exp.DataType.Type.DATETIME2)
class NamingError(ValueError):0
def _hash(obj:t.Any)->str:return hash_data([json.dumps(obj,sort_keys=_B,default=str)])
_BEHAVIOR_LEGACY_YAML_ALIASES='behaviour','semantic_config'
def _normalize_behavior_alias(data:t.Any,*,context:str)->t.Any:
	if not isinstance(data,dict):return data
	canonical=data.get(_N);legacy_present=[key for key in _BEHAVIOR_LEGACY_YAML_ALIASES if data.get(key)is not _A]
	if canonical is not _A and legacy_present:raise ValueError(f"{context}: 'behavior' cannot be combined with legacy aliases ({', '.join(repr(k)for k in legacy_present)}); use 'behavior' only.")
	if len(legacy_present)>1:raise ValueError(f"{context}: only one legacy behavior alias may be set; use 'behavior' instead.")
	if canonical is not _A or not legacy_present:return data
	legacy_key=legacy_present[0];member_name=data.get(_C,_R);from vulcan.core.console import get_console;get_console().log_warning(f"{context} '{member_name}' uses deprecated '{legacy_key}'; use 'behavior' instead.");out=dict(data);out[_N]=data[legacy_key]
	for key in _BEHAVIOR_LEGACY_YAML_ALIASES:out.pop(key,_A)
	return out
def sql_dtype_to_logical_type(col_type:t.Optional[exp.DataType])->LogicalTypeValue:
	if not col_type:return _X
	if col_type.is_type(exp.DataType.Type.BOOLEAN):return _S
	if col_type.is_type(exp.DataType.Type.BIT):
		if not col_type.expressions:return _S
		width=col_type.expressions[0].this
		if isinstance(width,exp.Literal)and width.is_int and int(width.this)==1:return _S
		return _T
	if col_type.is_type(*exp.DataType.INTEGER_TYPES,*exp.DataType.REAL_TYPES):return _T
	if col_type.is_type(*STRICT_TIMESTAMP_TYPES):return _Q
	return _X
def parse_qualified_reference(ref:str)->t.Tuple[str,str]|_A:
	parts=ref.split('.')
	if len(parts)!=2 or not parts[0]or not parts[1]:return
	return parts[0],parts[1]
def _validate_identifier(value:str,*,context:str='identifier')->str:
	if not value:raise NamingError(f"{context} must not be empty")
	if not VALID_IDENTIFIER_PATTERN.match(value):raise NamingError(f"{context} must match {VALID_IDENTIFIER_PATTERN.pattern}, got {value!r}")
	return value
def _validate_qualified_reference(ref:str,*,context:str='reference')->str:
	parsed=parse_qualified_reference(ref)
	if not parsed:raise NamingError(f"{context} must be exactly one qualified reference in the form 'name.field', got {ref!r}")
	semantic_name,field=parsed;_validate_identifier(semantic_name,context=f"{context} (semantic model name)");_validate_identifier(field,context=f"{context} (field)");return ref
def _literal(s:str)->exp.Expression:return exp.Literal.string(s)
def _text(s:str)->exp.Expression:return exp.Identifier(this=s,quoted=_B)
def _upper(s:str)->exp.Expression:return exp.to_identifier(s.upper().replace('-','_'))
def _is_unquoted_identifier(s:str)->bool:return bool(re.match('^[a-zA-Z_][a-zA-Z0-9_]*$',s))
def _entry(d:'DimensionSpec')->exp.Expression:name=d.name;return exp.to_identifier(name)if _is_unquoted_identifier(name)else _literal(name)
def _require_unique(kind:str,values:t.List[str])->_A:
	dupes={x for x in values if values.count(x)>1}
	if dupes:raise ValueError(f"duplicate {kind}: {sorted(dupes)}")
_BRACED_MODEL_MEMBER=re.compile('\\{\\s*([a-zA-Z_][a-zA-Z0-9_]{0,63})\\s*\\.\\s*([a-zA-Z_][a-zA-Z0-9_]{0,63})\\s*\\}')
def normalize_self_dimension_refs(expression:str,*,declaring_model:str,context:str)->str:
	sql=expression.strip()
	if not sql:return expression
	changed=_U
	def _repl(match:re.Match[str])->str:
		nonlocal changed;model_name=match.group(1);member=match.group(2)
		if model_name!=declaring_model:raise ValueError(f"{context}: foreign reference {{{model_name}.{member}}} is not allowed; use bare dimension names on {declaring_model!r}.")
		if match.group(0)!=member:changed=_B
		return member
	normalized=_BRACED_MODEL_MEMBER.sub(_repl,sql)
	if changed and normalized!=sql:from vulcan.core.console import get_console;get_console().log_warning(f'{context}: normalized "{expression}" -> "{normalized}"')
	return normalized
def _normalize_measure_spec(measure:_a,*,owning_model:str)->_a:
	updates:t.Dict[str,t.Any]={};measure_ctx=f"measure '{owning_model}.{measure.name}'"
	if measure.filters:updates[_b]=[normalize_self_dimension_refs(filter_expr,declaring_model=owning_model,context=f"{measure_ctx} filter[{index}]")for(index,filter_expr)in enumerate(measure.filters)]
	return measure.model_copy(update=updates)if updates else measure
def _normalize_segment_spec(segment:_c,*,owning_model:str)->_c:
	if not segment.expression.strip():return segment
	return segment.model_copy(update={_L:normalize_self_dimension_refs(segment.expression,declaring_model=owning_model,context=f"segment '{owning_model}.{segment.name}'")})
def _segment_name_from_ref(ref:str)->str:
	parsed=parse_qualified_reference(ref)
	if not parsed:raise NamingError(f"segment ref must be exactly one qualified reference in the form 'name.field', got {ref!r}")
	semantic_name,field=parsed;return f"{semantic_name}_{field}".lower()
def _coerce_metric_dimensions_yaml(entries:t.Any,*,context:str=_V)->t.List[t.Dict[str,t.Any]]:
	if not isinstance(entries,list):raise ValueError(f"{context} must be a list")
	shorthand_refs_by_derived_name:t.Dict[str,t.List[str]]={};out:t.List[t.Dict[str,t.Any]]=[]
	for(i,x)in enumerate(entries):
		loc=f"{context}[{i}]"
		if isinstance(x,str):
			ref=_validate_qualified_reference(x.strip(),context=loc);parsed=parse_qualified_reference(ref)
			if not parsed:raise NamingError(f"{loc}: invalid qualified reference {ref!r}")
			_,field_name=parsed;_validate_identifier(field_name,context=f"{loc} (name derived from ref field)");shorthand_refs_by_derived_name.setdefault(field_name,[]).append(ref);out.append({_C:field_name,_W:ref})
		elif isinstance(x,dict):out.append(dict(x))
		else:raise ValueError(f"{loc}: entry must be a qualified reference string or a dict, got {type(x).__name__}")
	clashes={name:refs for(name,refs)in shorthand_refs_by_derived_name.items()if len(set(refs))>1}
	if clashes:detail='; '.join(f"{name!r}: {refs}"for(name,refs)in sorted(clashes.items()));raise ValueError(f"duplicate dimension name derived from qualified refs; use an explicit object entry with 'name' for one dimension: {detail}")
	return out
def _coerce_metric_segments_yaml(entries:t.Any,*,context:str=_O)->t.List[t.Dict[str,t.Any]]:
	if not isinstance(entries,list):raise ValueError(f"{context} must be a list")
	out:t.List[t.Dict[str,t.Any]]=[]
	for(i,x)in enumerate(entries):
		loc=f"{context}[{i}]"
		if not isinstance(x,str):raise ValueError(f"{loc}: segment must be a qualified reference string, got {type(x).__name__}")
		ref=_validate_qualified_reference(x.strip(),context=loc);derived=_segment_name_from_ref(ref);_validate_identifier(derived,context=f"{loc} (name derived as semantic_field)");out.append({_C:derived,_W:ref})
	return out
class MeasureSpec(PydanticModel):
	_MEASURE_TYPES:t.ClassVar[frozenset[str]]=frozenset(get_args(MeasureTypeValue));_RESERVED_MEASURE_NAMES:t.ClassVar[frozenset[str]]=frozenset({_M});_MEASURE_TYPES_ALLOWING_FILTERS:t.ClassVar[frozenset[str]]=frozenset({'sum','avg','min','max',_M,_d,_e});name:str;type:MeasureTypeValue;expression:str='';description:str='';filters:t.List[str]=Field(default_factory=list);rolling_window:t.Optional[RollingWindowSpec]=_A;public:bool=_B;tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);behavior:t.Optional[MeasureBehaviorSpec]=_A;ai_context:t.Optional[AiContextSpec]=_A
	@model_validator(mode=_D)
	@classmethod
	def normalize_behavior_alias(cls,data:t.Any)->t.Any:return _normalize_behavior_alias(data,context=_Z)
	@model_validator(mode=_D)
	@classmethod
	def normalize_type(cls,data:t.Any)->t.Any:
		if isinstance(data,dict)and _I in data and isinstance(data[_I],str):data={**data,_I:data[_I].strip().lower()}
		return data
	@model_validator(mode=_G)
	def validate_measure_name(self)->MeasureSpec:_validate_identifier(self.name,context='measure name');return self
	@model_validator(mode=_G)
	def validate_expression_required(self)->MeasureSpec:
		if self.type==_M:return self
		if not self.expression.strip():raise ValueError(f"Measure {self.name!r} of type {self.type!r} requires a non-empty expression")
		return self
	@model_validator(mode=_G)
	def validate_filters_nonempty(self)->MeasureSpec:
		for(i,f)in enumerate(self.filters):
			if not str(f).strip():raise ValueError(f"Measure {self.name!r} has empty filter at index {i}")
		return self
	@model_validator(mode=_G)
	def validate_number_no_filters(self)->MeasureSpec:
		if self.type==_T and self.filters:raise ValueError(f"Measure {self.name!r}: type 'number' cannot be combined with filters")
		return self
	@model_validator(mode=_G)
	def validate_filters_allowed_for_type(self)->MeasureSpec:
		if self.filters and self.type not in type(self)._MEASURE_TYPES_ALLOWING_FILTERS:raise ValueError(f"Measure {self.name!r}: filters are not allowed for type {self.type!r}")
		return self
	@classmethod
	def implicit_count(cls)->MeasureSpec:return cls(name=_M,type=_M,expression='*',description='',filters=[],rolling_window=_A,public=_B,tags=[],terms=[],behavior=_A,ai_context=_A)
	def data_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,exclude={_F,_P,_J,_K,_H,_N});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,include={_C,_F,_J,_K,_H,_N,_P});return _hash(raw)
	@cached_property
	def exp(self)->exp.DataType:
		k=self.type
		if k in('sum','avg','min','max',_T):return exp.DataType.build('DOUBLE')
		if k in(_M,_d,_e):return exp.DataType.build('BIGINT')
		if k==_X:return exp.DataType.build('VARCHAR')
		if k==_Q:return exp.DataType.build('TIMESTAMP')
		if k==_S:return exp.DataType.build(_f)
		return exp.DataType.build('UNKNOWN')
	def render_exp(self)->exp.Expression:
		inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier(_I),value=_upper(self.type))]
		if self.expression:inner.append(exp.Property(this=exp.to_identifier(_L),value=_text(self.expression)))
		if self.filters:inner.append(exp.Property(this=exp.to_identifier(_b),value=exp.Tuple(expressions=[_text(str(f))for f in self.filters])))
		if self.rolling_window is not _A:rw=self.rolling_window.model_dump(mode=_E,exclude_none=_B);inner.append(exp.Property(this=exp.to_identifier('rolling_window'),value=_literal(json.dumps(rw,sort_keys=_B))))
		return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=inner))
class TimeGranularitySpec(_WireTimeGranularitySpec):
	ai_context:t.Optional[AiContextSpec]=_A
	def data_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,exclude={_F,_H});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,include={_C,_g,_F,_H});return _hash(raw)
	def render_exp(self)->exp.Expression:
		inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier(_g),value=_text(self.interval))]
		for(key,val)in(('offset',self.offset),('origin',self.origin)):
			if val is not _A:inner.append(exp.Property(this=exp.to_identifier(key),value=_text(val)))
		return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=inner))
class DimensionSpec(PydanticModel):
	name:str;description:t.Optional[str]=_A;tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);format:t.Optional[str]=_A;granularities:t.List[TimeGranularitySpec]=Field(default_factory=list);behavior:t.Optional[DimensionBehaviorSpec]=_A;ai_context:t.Optional[AiContextSpec]=_A;public:bool=_B
	@model_validator(mode=_D)
	@classmethod
	def normalize_behavior_alias(cls,data:t.Any)->t.Any:return _normalize_behavior_alias(data,context='dimension')
	@model_validator(mode=_D)
	@classmethod
	def _strip_deprecated_mask_expression(cls,data:t.Any)->t.Any:
		A='mask_expression'
		if not isinstance(data,dict)or A not in data:return data
		name=data.get(_C,_R);from vulcan.core.console import get_console;get_console().log_warning(f"dimension {name!r}: 'mask_expression' is not allowed and ignored.");updated=data.copy();updated.pop(A,_A);return updated
	@classmethod
	def implicit_grain(cls,grain:exp.Expression)->DimensionSpec:
		e=grain.unnest()
		if isinstance(e,exp.Tuple):raise ConfigError(f"MODEL grains must list each column separately (e.g. grains (a, b)); got a composite grain expression: {e.sql()}")
		if isinstance(e,exp.Column):name=str(e.name)
		elif isinstance(e,exp.Identifier):name=str(e.name)
		else:raise ConfigError(f"MODEL grains must be simple column identifiers; got {e.sql()} ({type(e).__name__})")
		return cls(name=_validate_identifier(name,context='implicit grain dimension name'),description=_A,tags=[],terms=[],format=_A,granularities=[],behavior=_A,ai_context=_A,public=_U)
	@classmethod
	def implicit_policy_member(cls,name:str)->DimensionSpec:return cls(name=_validate_identifier(name,context='implicit policy dimension name'),description=_A,tags=[],terms=[],format=_A,granularities=[],behavior=_A,ai_context=_A,public=_U)
	@field_validator(_C)
	@classmethod
	def validate_name(cls,v:str)->str:return _validate_identifier(v,context='dimension name')
	@model_validator(mode=_G)
	def validate_granularity_names_unique(self)->DimensionSpec:
		names=[g.name for g in self.granularities];dupes={n for n in names if names.count(n)>1}
		if dupes:raise ValueError(f"Duplicate granularity names on dimension {self.name!r}: {sorted(dupes)}")
		return self
	def render_exp(self)->exp.Expression:
		inner:t.List[exp.Expression]=[]
		if self.format:inner.append(exp.Property(this=exp.to_identifier(_h),value=_text(self.format)))
		if self.granularities:inner.append(exp.Property(this=exp.to_identifier(_Y),value=exp.Tuple(expressions=[g.render_exp()for g in sorted(self.granularities,key=lambda x:x.name)])))
		if not inner:return _entry(self)
		return exp.Property(this=exp.to_identifier(self.name)if _is_unquoted_identifier(self.name)else _literal(self.name),value=exp.Tuple(expressions=inner))
	def data_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,include={_C,_h,_P});raw[_Y]=[g.data_hash()for g in sorted(self.granularities,key=lambda x:x.name)];return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,include={_C,_F,_J,_K,_H,_N});raw[_Y]=[g.metadata_hash()for g in sorted(self.granularities,key=lambda x:x.name)];return _hash(raw)
class SegmentSpec(PydanticModel):
	name:str;expression:str;description:str='';public:bool=_B;tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);ai_context:t.Optional[AiContextSpec]=_A
	@field_validator(_C)
	@classmethod
	def validate_name(cls,v:str)->str:return _validate_identifier(v,context='segment name')
	@cached_property
	def exp(self)->exp.DataType:return exp.DataType.build(_f)
	def data_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,exclude={_F,_J,_K,_H,_P});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,include={_C,_F,_J,_K,_H,_P});return _hash(raw)
	def render_exp(self)->exp.Expression:return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=[exp.Property(this=exp.to_identifier(_L),value=_text(self.expression))]))
class RollupSpec(PydanticModel):
	name:str;measures:t.List[str]=Field(default_factory=list);dimensions:t.List[str]=Field(default_factory=list);segments:t.List[str]=Field(default_factory=list);time_dimension:t.Optional[str]=_A;granularity:t.Optional[MetricGranularityValue]=_A;date_range:t.Optional[RestDateRange]=_A;rollups:t.Optional[t.List[str]]=_A;description:str=''
	@property
	def is_composite(self)->bool:return self.rollups is not _A
	@model_validator(mode=_D)
	@classmethod
	def reject_segments(cls,data:t.Any)->t.Any:
		if isinstance(data,dict)and data.get(_O):name=data.get(_C,_R);raise ValueError(f"rollup {name!r}: 'segments' are not supported on rollups")
		return data
	@field_validator(_C)
	@classmethod
	def validate_name(cls,v:str)->str:return _validate_identifier(v,context='rollup name')
	@model_validator(mode=_G)
	def _validate_shape(self)->'RollupSpec':
		if self.granularity is not _A and self.time_dimension is _A:raise ValueError(f"rollup {self.name!r}: 'granularity' requires 'time_dimension' to be set")
		if self.date_range is not _A and self.time_dimension is _A:raise ValueError(f"rollup {self.name!r}: 'date_range' requires 'time_dimension' to be set")
		if isinstance(self.date_range,list)and not 1<=len(self.date_range)<=2:raise ValueError(f"rollup {self.name!r}: 'date_range' must contain one or two values")
		if self.rollups is not _A:
			if len(self.rollups)!=2:raise ValueError(f"rollup {self.name!r}: composite rollups requires exactly two 'rollups' entries qualified as '{{model}}.{{rollup_name}}'")
			for ref in self.rollups:
				if parse_qualified_reference(ref)is _A:raise ValueError(f"rollup {self.name!r}: rollups entry {ref!r} must be qualified as '{{model}}.{{rollup_name}}'")
		if not(self.measures or self.dimensions or self.time_dimension):raise ValueError(f"rollup {self.name!r}: must reference at least one measure, dimension, or time_dimension")
		return self
	def data_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,exclude={_F});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,include={_C,_F});return _hash(raw)
	def involved_semantic_names(self,owning:str)->t.FrozenSet[str]:refs=*(self.rollups or()),*self.dimensions,*([self.time_dimension]if self.time_dimension else[]),*self.measures;names={owning,*(ref.partition('.')[0]for ref in refs if ref and'.'in ref)};return frozenset(names)
	def render_exp(self)->exp.Expression:
		props:t.List[exp.Expression]=[]
		if self.measures:props.append(exp.Property(this=exp.to_identifier(_i),value=exp.Tuple(expressions=[_text(m)for m in self.measures])))
		if self.dimensions:props.append(exp.Property(this=exp.to_identifier(_V),value=exp.Tuple(expressions=[_text(d)for d in self.dimensions])))
		if self.segments:props.append(exp.Property(this=exp.to_identifier(_O),value=exp.Tuple(expressions=[_text(s)for s in self.segments])))
		if self.time_dimension:props.append(exp.Property(this=exp.to_identifier('time_dimension'),value=_text(self.time_dimension)))
		if self.granularity:props.append(exp.Property(this=exp.to_identifier(_j),value=_text(self.granularity)))
		if self.date_range:date_range=exp.Tuple(expressions=[_text(value)for value in self.date_range])if isinstance(self.date_range,list)else _text(self.date_range);props.append(exp.Property(this=exp.to_identifier('date_range'),value=date_range))
		if self.rollups:props.append(exp.Property(this=exp.to_identifier('rollups'),value=exp.Tuple(expressions=[_text(r)for r in self.rollups])))
		return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=props))
class JoinSpec(PydanticModel):
	name:str;type:JoinRelationshipValue;on:JoinOn|_A=_A;expression:str|_A=_A;skip_for_bi:bool=_U;ai_context:t.Optional[AiContextSpec]=_A;fqn:t.Optional[str]=Field(default=_A)
	@field_validator(_C)
	@classmethod
	def validate_name(cls,v:str)->str:return _validate_identifier(v,context='join name')
	@field_validator(_I,mode=_D)
	@classmethod
	def normalize_relationship(cls,v:t.Any)->t.Any:
		if isinstance(v,str):return v.strip().lower()
		return v
	@model_validator(mode=_D)
	@classmethod
	def _drop_legacy_resolved_flag(cls,data:t.Any)->t.Any:
		A='resolved'
		if isinstance(data,dict)and A in data:data={key:value for(key,value)in data.items()if key!=A}
		return data
	@model_validator(mode=_G)
	def _validate_predicate_present(self)->JoinSpec:
		has_on=self.on is not _A;has_expr=bool(self.expression and self.expression.strip())
		if not has_on and not has_expr:hint=' Unquoted `on:` is parsed as a YAML boolean by some loaders; quote the key as `"on":`';raise ValueError(f"join requires exactly one of 'on' or 'expression'.{hint}")
		return self
	def resolve(self,*,source_model:str)->JoinSpec:
		if self.on is not _A:on_tree,expression=compile_join_on(self.on,source_model=source_model,target_model=self.name);return self.model_copy(update={'on':on_tree,_L:expression})
		assert self.expression is not _A;from vulcan.core.console import get_console;get_console().log_warning(f"join '{source_model} -> {self.name}': deprecated 'expression'; use 'on' field.");return self.model_copy(update={'on':_A,_L:self.expression.strip()})
	def data_hash(self)->str:raw={_C:self.name,_I:self.type,_L:self.expression};return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,include={_C,_H,_k});return _hash(raw)
	def render_exp(self)->exp.Expression:return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=[exp.Property(this=exp.to_identifier(_I),value=_upper(self.type)),exp.Property(this=exp.to_identifier(_L),value=_text(self.expression)),exp.Property(this=exp.to_identifier(_k),value=exp.true()if self.skip_for_bi else exp.false())]))
class SemanticModelSpec(PydanticModel):
	kind:Literal[_l]=_l;name:str;depends_on:str;description:t.Optional[str]=_A;owner:t.Optional[str]=_A;tags:t.Optional[t.List[Tag]]=_A;terms:t.Optional[t.List[Term]]=_A;ai_context:t.Optional[AiContextSpec]=_A;measures:t.List[MeasureSpec]=Field(default_factory=list);segments:t.List[SegmentSpec]=Field(default_factory=list);joins:t.List[JoinSpec]=Field(default_factory=list);dimensions:t.List[DimensionSpec]=Field(...);rollups:t.List[RollupSpec]=Field(default_factory=list)
	@model_validator(mode=_D)
	@classmethod
	def _warn_deprecated_policies(cls,data:t.Any)->t.Any:
		A='policies'
		if not isinstance(data,dict)or A not in data:return data
		name=data.get(_C,_R);from vulcan.core.console import get_console;get_console().log_warning(f"semantic {name!r}: 'policies' is not allowed and ignored.");updated=data.copy();updated.pop(A,_A);return updated
	@field_validator(_V,mode=_D)
	@classmethod
	def coerce_dimension_inputs(cls,v:t.Any)->t.List[DimensionSpec]:
		if not isinstance(v,list):raise ValueError('dimensions must be a list')
		def _coerce_dimension(x:t.Any)->DimensionSpec:
			if isinstance(x,DimensionSpec):return x
			if isinstance(x,str):return DimensionSpec(name=_validate_identifier(x,context='dimension column'))
			if isinstance(x,dict):return DimensionSpec.model_validate(x)
			raise ValueError(f"dimension entry must be str, dict, or DimensionSpec, got {type(x).__name__}")
		return[_coerce_dimension(x)for x in v]
	@model_validator(mode=_G)
	def validate_root(self)->SemanticModelSpec:
		_validate_identifier(self.name,context='semantic model name')
		if not self.dimensions:raise ValueError("semantic model must declare a non-empty 'dimensions' allow-list")
		_require_unique('measure names',[m.name for m in self.measures]);_require_unique('segment names',[s.name for s in self.segments]);_require_unique('join names',[j.name for j in self.joins]);_require_unique('rollup names',[r.name for r in self.rollups]);reserved=MeasureSpec._RESERVED_MEASURE_NAMES
		for m in self.measures:
			if m.name in reserved:raise ValueError(f"Measure name {m.name!r} is reserved (automatic count is implied)")
		for j in self.joins:
			if j.name==self.name:raise ValueError(f"join name {j.name!r} must not equal to name {self.name!r}")
		owning=self.name;measures=[_normalize_measure_spec(m,owning_model=owning)for m in self.measures];segments=[_normalize_segment_spec(s,owning_model=owning)for s in self.segments];object.__setattr__(self,_i,measures);object.__setattr__(self,_O,segments);resolved_joins=[join.resolve(source_model=self.name)for join in self.joins];object.__setattr__(self,'joins',resolved_joins);return self
class MetricNamedRefSpec(PydanticModel):
	name:str;ref:str;description:str='';tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);ai_context:t.Optional[AiContextSpec]=_A
	@model_validator(mode=_G)
	def validate_name_and_ref(self)->MetricNamedRefSpec:_validate_identifier(self.name,context='metric dimension or segment name');_validate_qualified_reference(self.ref,context='metric dimension or segment ref');return self
	def data_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,exclude={_F,_J,_K,_H});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_E,exclude_none=_B,include={_C,_W,_F,_J,_K,_H});return _hash(raw)
	def render_exp(self)->exp.Property:
		name_expr=exp.to_identifier(self.name)if _is_unquoted_identifier(self.name)else _literal(self.name)
		if not self.description.strip()and not self.tags and not self.terms:return exp.Property(this=name_expr,value=_literal(self.ref))
		inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier(_W),value=_literal(self.ref))]
		if self.description.strip():inner.append(exp.Property(this=exp.to_identifier(_F),value=_text(self.description.strip())))
		if self.tags:inner.append(exp.Property(this=exp.to_identifier(_J),value=exp.Tuple(expressions=[_literal(str(tag))for tag in self.tags])))
		if self.terms:inner.append(exp.Property(this=exp.to_identifier(_K),value=exp.Tuple(expressions=[_literal(str(term))for term in self.terms])))
		return exp.Property(this=name_expr,value=exp.Tuple(expressions=inner))
MetricDimensionSpec=MetricNamedRefSpec
MetricSegmentSpec=MetricNamedRefSpec
class MetricSpec(PydanticModel):
	kind:Literal[_m]=_m;name:str;measure:str;ts:str;granularity:MetricGranularityValue;dimensions:t.List[MetricNamedRefSpec]=Field(default_factory=list);segments:t.List[MetricNamedRefSpec]=Field(default_factory=list);description:str='';owner:t.Optional[str]=_A;tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);ai_context:t.Optional[AiContextSpec]=_A;join_path:t.Optional[MetricJoinPath]=_A
	@field_validator('join_path',mode=_D)
	@classmethod
	def _validate_join_path(cls,v:t.Any)->t.Any:
		if v is _A:return
		return MetricJoinPath.coerce(v)
	@model_validator(mode=_D)
	@classmethod
	def reject_legacy_metric_yaml_keys(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		forbidden=[k for k in(_Q,'slices')if k in data]
		if forbidden:raise ValueError(f"invalid metric YAML keys {forbidden!r}: use top-level 'ts', 'granularity', and 'dimensions' instead")
		return data
	@field_validator(_j,mode=_D)
	@classmethod
	def normalize_granularity(cls,v:t.Any)->t.Any:
		if isinstance(v,str):return v.strip().lower()
		return v
	@field_validator('ts')
	@classmethod
	def validate_ts(cls,v:str)->str:
		if not isinstance(v,str):raise ValueError(f"metric ts must be a string qualified reference, got {type(v).__name__}")
		return _validate_qualified_reference(v.strip(),context='metric ts')
	@field_validator(_V,mode=_D)
	@classmethod
	def coerce_dimensions(cls,v:t.Any)->t.List[t.Dict[str,t.Any]]:return _coerce_metric_dimensions_yaml(v if v is not _A else[])
	@field_validator(_O,mode=_D)
	@classmethod
	def coerce_segments(cls,v:t.Any)->t.List[t.Dict[str,t.Any]]:return _coerce_metric_segments_yaml(v if v is not _A else[])
	@model_validator(mode=_G)
	def validate_metric(self)->MetricSpec:
		_validate_identifier(self.name,context='metric name');all_refs=[self.measure,self.ts,*[s.ref for s in self.dimensions],*[s.ref for s in self.segments]]
		for ref in all_refs:_validate_qualified_reference(ref,context='metric item')
		_require_unique('metric refs',all_refs);all_names=[s.name for s in self.dimensions]+[s.name for s in self.segments];_require_unique('dimension/segment names',all_names)
		for n in all_names:
			if n.lower()in _METRIC_ADJUNCT_NAME_RESERVED:raise ValueError(f"name {n!r} is reserved")
		return self
	@property
	def depends_on_semantic_names(self)->t.FrozenSet[str]:
		names:t.Set[str]=set()
		for ref in(self.measure,self.ts,*[s.ref for s in self.dimensions],*[s.ref for s in self.segments]):
			parsed=parse_qualified_reference(ref)
			if parsed:names.add(parsed[0])
		return frozenset(names)