from __future__ import annotations
_V='boolean'
_U='snapshot'
_T='fingerprint'
_S='ttl_ms'
_R='bigint'
_Q='dev_version'
_P='next_auto_restatement_ts'
_O='kind_name'
_N='auto_restatements'
_M='snapshot_version'
_L='snapshot_name'
_K='forward_only'
_J='unrestorable'
_I='unpaused_ts'
_H='version'
_G='snapshots'
_F='identifier'
_E=True
_D=False
_C='updated_ts'
_B='name'
_A=None
import typing as t,json,logging
from pathlib import Path
from collections import defaultdict
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.core.state_sync.db.utils import snapshot_name_filter,snapshot_name_version_filter,snapshot_id_filter,fetchone,fetchall
from vulcan.core.environment import Environment
from vulcan.core.model import SeedModel,ModelKindName
from vulcan.core.snapshot.cache import SnapshotCache
from vulcan.core.snapshot import SnapshotIdLike,SnapshotNameVersionLike,SnapshotTableCleanupTask,SnapshotNameVersion,SnapshotInfoLike,Snapshot,SnapshotIdAndVersion,SnapshotId,SnapshotFingerprint
from vulcan.core.state_sync.common import RowBoundary,ExpiredSnapshotBatch,ExpiredBatchRange,LimitBoundary
from vulcan.utils.date import now_timestamp,TimeLike,to_timestamp
from vulcan.utils import unique
if t.TYPE_CHECKING:import pandas as pd
logger=logging.getLogger(__name__)
SNAPSHOTS=TableSpec(name='_snapshots',primary_key=(_B,_F),columns=(ColumnSpec(_B,indexed=_E),ColumnSpec(_F,indexed=_E),ColumnSpec(_H,indexed=_E),ColumnSpec(_Q,indexed=_E),ColumnSpec(_U,blob=_E),ColumnSpec(_O,'text'),ColumnSpec(_C,_R),ColumnSpec(_I,_R),ColumnSpec(_S,_R),ColumnSpec(_J,_V),ColumnSpec(_K,_V),ColumnSpec(_T,blob=_E)))
AUTO_RESTATEMENTS=TableSpec(name='_auto_restatements',primary_key=(_L,_M),columns=(ColumnSpec(_L,indexed=_E),ColumnSpec(_M,indexed=_E),ColumnSpec(_P,_R)))
class SnapshotState:
	SNAPSHOT_BATCH_SIZE=1000
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A,cache_dir:Path=Path()):self.engine_adapter=engine_adapter;self.snapshots_table=exp.table_(SNAPSHOTS.name,db=schema);self.auto_restatements_table=exp.table_(AUTO_RESTATEMENTS.name,db=schema);dialect=engine_adapter.dialect;self._snapshot_columns_to_types=SNAPSHOTS.columns_to_types(dialect);self._auto_restatement_columns_to_types=AUTO_RESTATEMENTS.columns_to_types(dialect);self._snapshot_cache=SnapshotCache(cache_dir)
	def push_snapshots(self,snapshots:t.Iterable[Snapshot],overwrite:bool=_D)->_A:
		if overwrite:snapshots=tuple(snapshots);self.delete_snapshots(snapshots)
		snapshots_to_store=[]
		for snapshot in snapshots:
			if isinstance(snapshot.node,SeedModel):seed_model=t.cast(SeedModel,snapshot.node);snapshot=snapshot.copy(update={'node':seed_model.to_dehydrated()})
			snapshots_to_store.append(snapshot)
		self.engine_adapter.insert_append(self.snapshots_table,_snapshots_to_df(snapshots_to_store),target_columns_to_types=self._snapshot_columns_to_types,track_rows_processed=_D)
		for snapshot in snapshots:self._snapshot_cache.put(snapshot)
	def unpause_snapshots(self,snapshots:t.Collection[SnapshotInfoLike],unpaused_dt:TimeLike)->_A:
		unrestorable_snapshots_by_forward_only:t.Dict[bool,t.List[SnapshotNameVersion]]=defaultdict(list)
		for snapshot in snapshots:unrestorable_snapshots_by_forward_only[not snapshot.is_forward_only].append(snapshot.name_version)
		updated_ts=now_timestamp();unpaused_ts=to_timestamp(unpaused_dt)
		for where in snapshot_name_filter([s.name for s in snapshots],batch_size=self.SNAPSHOT_BATCH_SIZE):self.engine_adapter.update_table(self.snapshots_table,{_I:_A,_C:updated_ts},where=where)
		self._update_snapshots([s.snapshot_id for s in snapshots],unpaused_ts=unpaused_ts,updated_ts=updated_ts)
		for(forward_only,snapshot_name_versions)in unrestorable_snapshots_by_forward_only.items():
			forward_only_exp=exp.column(_K).is_(exp.convert(forward_only))
			for where in snapshot_name_version_filter(self.engine_adapter,snapshot_name_versions,batch_size=self.SNAPSHOT_BATCH_SIZE,alias=_A):self.engine_adapter.update_table(self.snapshots_table,{_J:_E,_C:updated_ts},where=forward_only_exp.and_(where))
	def get_expired_snapshots(self,environments:t.Iterable[Environment],current_ts:int,ignore_ttl:bool,batch_range:ExpiredBatchRange)->t.Optional[ExpiredSnapshotBatch]:
		expired_query=exp.select(_B,_F,_H,_C).from_(self.snapshots_table)
		if not ignore_ttl:expired_query=expired_query.where(exp.column(_C)+exp.column(_S)<=current_ts)
		expired_query=expired_query.where(batch_range.where_filter);promoted_snapshot_ids={snapshot.snapshot_id for environment in environments for snapshot in(environment.snapshots if environment.finalized_ts is not _A else[*environment.snapshots,*(environment.previous_finalized_snapshots or[])])}
		if promoted_snapshot_ids:not_in_conditions=[exp.not_(condition)for condition in snapshot_id_filter(self.engine_adapter,promoted_snapshot_ids,batch_size=self.SNAPSHOT_BATCH_SIZE)];expired_query=expired_query.where(exp.and_(*not_in_conditions))
		expired_query=expired_query.order_by(exp.column(_C),exp.column(_B),exp.column(_F))
		if isinstance(batch_range.end,LimitBoundary):expired_query=expired_query.limit(batch_range.end.batch_size)
		rows=fetchall(self.engine_adapter,expired_query)
		if not rows:return
		expired_candidates={SnapshotId(name=name,identifier=identifier):SnapshotNameVersion(name=name,version=version)for(name,identifier,version,_)in rows}
		if not expired_candidates:return
		def _is_snapshot_used(snapshot:SnapshotIdAndVersion)->bool:return snapshot.snapshot_id in promoted_snapshot_ids or snapshot.snapshot_id not in expired_candidates
		last_row=rows[-1];last_row_boundary=RowBoundary(updated_ts=last_row[3],name=last_row[0],identifier=last_row[1]);result_batch_range=ExpiredBatchRange(start=batch_range.start,end=last_row_boundary);unique_expired_versions=unique(expired_candidates.values());expired_snapshot_ids:t.Set[SnapshotId]=set();cleanup_tasks:t.List[SnapshotTableCleanupTask]=[];snapshots=self._get_snapshots_with_same_version(unique_expired_versions);snapshots_by_version=defaultdict(set);snapshots_by_dev_version=defaultdict(set)
		for s in snapshots:snapshots_by_version[s.name,s.version].add(s.snapshot_id);snapshots_by_dev_version[s.name,s.dev_version].add(s.snapshot_id)
		expired_snapshots=[s for s in snapshots if not _is_snapshot_used(s)];all_expired_snapshot_ids={s.snapshot_id for s in expired_snapshots};cleanup_targets:t.List[t.Tuple[SnapshotId,bool]]=[]
		for snapshot in expired_snapshots:
			shared_version_snapshots=snapshots_by_version[snapshot.name,snapshot.version];shared_version_snapshots.discard(snapshot.snapshot_id);shared_dev_version_snapshots=snapshots_by_dev_version[snapshot.name,snapshot.dev_version];shared_dev_version_snapshots.discard(snapshot.snapshot_id)
			if not shared_dev_version_snapshots:dev_table_only=bool(shared_version_snapshots);cleanup_targets.append((snapshot.snapshot_id,dev_table_only))
		snapshot_ids_to_cleanup=[snapshot_id for(snapshot_id,_)in cleanup_targets];full_snapshots=self._get_snapshots(snapshot_ids_to_cleanup)
		for(snapshot_id,dev_table_only)in cleanup_targets:
			if snapshot_id in full_snapshots:cleanup_tasks.append(SnapshotTableCleanupTask(snapshot=full_snapshots[snapshot_id].table_info,dev_table_only=dev_table_only));expired_snapshot_ids.add(snapshot_id);all_expired_snapshot_ids.discard(snapshot_id)
		if all_expired_snapshot_ids:expired_snapshot_ids.update(all_expired_snapshot_ids)
		if expired_snapshot_ids or cleanup_tasks:return ExpiredSnapshotBatch(expired_snapshot_ids=expired_snapshot_ids,cleanup_tasks=cleanup_tasks,batch_range=result_batch_range)
	def delete_snapshots(self,snapshot_ids:t.Iterable[SnapshotIdLike])->_A:
		if not snapshot_ids:return
		for where in snapshot_id_filter(self.engine_adapter,snapshot_ids,batch_size=self.SNAPSHOT_BATCH_SIZE):self.engine_adapter.delete_from(self.snapshots_table,where=where)
	def touch_snapshots(self,snapshot_ids:t.Iterable[SnapshotIdLike])->_A:self._update_snapshots(snapshot_ids)
	def get_snapshots(self,snapshot_ids:t.Iterable[SnapshotIdLike])->t.Dict[SnapshotId,Snapshot]:return self._get_snapshots(snapshot_ids)
	def get_snapshots_by_names(self,snapshot_names:t.Iterable[str],current_ts:t.Optional[int]=_A,exclude_expired:bool=_E)->t.Set[SnapshotIdAndVersion]:
		if not snapshot_names:return set()
		if exclude_expired:current_ts=current_ts or now_timestamp();unexpired_expr=exp.column(_C)+exp.column(_S)>current_ts
		else:unexpired_expr=_A
		return{SnapshotIdAndVersion(name=name,identifier=identifier,version=version,kind_name=kind_name or _A,dev_version=dev_version,fingerprint=fingerprint)for where in snapshot_name_filter(snapshot_names=snapshot_names,batch_size=self.SNAPSHOT_BATCH_SIZE)for(name,identifier,version,kind_name,dev_version,fingerprint)in fetchall(self.engine_adapter,exp.select(_B,_F,_H,_O,_Q,_T).from_(self.snapshots_table).where(where).and_(unexpired_expr))}
	def snapshots_exist(self,snapshot_ids:t.Iterable[SnapshotIdLike])->t.Set[SnapshotId]:return{SnapshotId(name=name,identifier=identifier)for where in snapshot_id_filter(self.engine_adapter,snapshot_ids,batch_size=self.SNAPSHOT_BATCH_SIZE)for(name,identifier)in fetchall(self.engine_adapter,exp.select(_B,_F).from_(self.snapshots_table).where(where))}
	def nodes_exist(self,names:t.Iterable[str],exclude_external:bool=_D)->t.Set[str]:
		names=set(names)
		if not names:return names
		query=exp.select(_B).from_(self.snapshots_table).where(exp.column(_B).isin(*names)).distinct()
		if exclude_external:query=query.where(exp.column(_O).neq(ModelKindName.EXTERNAL.value))
		return{name for(name,)in fetchall(self.engine_adapter,query)}
	def update_auto_restatements(self,next_auto_restatement_ts:t.Dict[SnapshotNameVersion,t.Optional[int]])->_A:
		next_auto_restatement_ts_deleted=[];next_auto_restatement_ts_filtered={}
		for(k,v)in next_auto_restatement_ts.items():
			if v is _A:next_auto_restatement_ts_deleted.append(k)
			else:next_auto_restatement_ts_filtered[k]=v
		for where in snapshot_name_version_filter(self.engine_adapter,next_auto_restatement_ts_deleted,column_prefix=_U,alias=_A,batch_size=self.SNAPSHOT_BATCH_SIZE):self.engine_adapter.delete_from(self.auto_restatements_table,where=where)
		if not next_auto_restatement_ts_filtered:return
		self.engine_adapter.merge(self.auto_restatements_table,_auto_restatements_to_df(next_auto_restatement_ts_filtered),target_columns_to_types=self._auto_restatement_columns_to_types,unique_key=(exp.column(_L),exp.column(_M)))
	def count(self)->int:result=fetchone(self.engine_adapter,exp.select('COUNT(*)').from_(self.snapshots_table));return result[0]if result else 0
	def clear_cache(self)->_A:self._snapshot_cache.clear()
	def _update_snapshots(self,snapshots:t.Iterable[SnapshotIdLike],**kwargs:t.Any)->_A:
		properties=kwargs
		if _C not in properties:properties[_C]=now_timestamp()
		for where in snapshot_id_filter(self.engine_adapter,snapshots,batch_size=self.SNAPSHOT_BATCH_SIZE):self.engine_adapter.update_table(self.snapshots_table,properties,where=where)
	def _push_snapshots(self,snapshots:t.Iterable[Snapshot])->_A:
		snapshots_to_store=[]
		for snapshot in snapshots:
			if isinstance(snapshot.node,SeedModel):seed_model=t.cast(SeedModel,snapshot.node);snapshot=snapshot.copy(update={'node':seed_model.to_dehydrated()})
			snapshots_to_store.append(snapshot)
		self.engine_adapter.insert_append(self.snapshots_table,_snapshots_to_df(snapshots_to_store),target_columns_to_types=self._snapshot_columns_to_types,track_rows_processed=_D)
	def _get_snapshots(self,snapshot_ids:t.Iterable[SnapshotIdLike],lock_for_update:bool=_D)->t.Dict[SnapshotId,Snapshot]:
		duplicates:t.Dict[SnapshotId,Snapshot]={}
		def _loader(snapshot_ids_to_load:t.Set[SnapshotId])->t.Collection[Snapshot]:
			fetched_snapshots:t.Dict[SnapshotId,Snapshot]={}
			for query in self._get_snapshots_expressions(snapshot_ids_to_load,lock_for_update):
				for(serialized_snapshot,_,_,_,updated_ts,unpaused_ts,unrestorable,forward_only,next_auto_restatement_ts)in fetchall(self.engine_adapter,query):
					snapshot=parse_snapshot(serialized_snapshot=serialized_snapshot,updated_ts=updated_ts,unpaused_ts=unpaused_ts,unrestorable=unrestorable,forward_only=forward_only,next_auto_restatement_ts=next_auto_restatement_ts);snapshot_id=snapshot.snapshot_id
					if snapshot_id in fetched_snapshots:other=duplicates.get(snapshot_id,fetched_snapshots[snapshot_id]);duplicates[snapshot_id]=snapshot if snapshot.updated_ts>other.updated_ts else other;fetched_snapshots[snapshot_id]=duplicates[snapshot_id]
					else:fetched_snapshots[snapshot_id]=snapshot
			return fetched_snapshots.values()
		snapshots,cached_snapshots=self._snapshot_cache.get_or_load({s.snapshot_id for s in snapshot_ids},_loader)
		if cached_snapshots:
			cached_snapshots_in_state:t.Set[SnapshotId]=set()
			for where in snapshot_id_filter(self.engine_adapter,cached_snapshots,batch_size=self.SNAPSHOT_BATCH_SIZE):
				query=exp.select(_B,_F,_C,_I,_J,_K,_P).from_(exp.to_table(self.snapshots_table).as_(_G)).join(exp.to_table(self.auto_restatements_table).as_(_N),on=exp.and_(exp.column(_B,table=_G).eq(exp.column(_L,table=_N)),exp.column(_H,table=_G).eq(exp.column(_M,table=_N))),join_type='left',copy=_D).where(where)
				if lock_for_update:query=query.lock(copy=_D)
				for(name,identifier,updated_ts,unpaused_ts,unrestorable,forward_only,next_auto_restatement_ts)in fetchall(self.engine_adapter,query):snapshot_id=SnapshotId(name=name,identifier=identifier);snapshot=snapshots[snapshot_id];snapshot.updated_ts=updated_ts;snapshot.unpaused_ts=unpaused_ts;snapshot.unrestorable=unrestorable;snapshot.forward_only=forward_only;snapshot.next_auto_restatement_ts=next_auto_restatement_ts;cached_snapshots_in_state.add(snapshot_id)
			missing_cached_snapshots=cached_snapshots-cached_snapshots_in_state
			for missing_cached_snapshot_id in missing_cached_snapshots:snapshots.pop(missing_cached_snapshot_id,_A)
		if duplicates:self.push_snapshots(duplicates.values(),overwrite=_E);logger.error('Found duplicate snapshots in the state store.')
		return snapshots
	def _get_snapshots_expressions(self,snapshot_ids:t.Iterable[SnapshotIdLike],lock_for_update:bool=_D)->t.Iterator[exp.Expression]:
		for where in snapshot_id_filter(self.engine_adapter,snapshot_ids,alias=_G,batch_size=self.SNAPSHOT_BATCH_SIZE):
			query=exp.select('snapshots.snapshot','snapshots.name','snapshots.identifier','snapshots.version','snapshots.updated_ts','snapshots.unpaused_ts','snapshots.unrestorable','snapshots.forward_only','auto_restatements.next_auto_restatement_ts').from_(exp.to_table(self.snapshots_table).as_(_G)).join(exp.to_table(self.auto_restatements_table).as_(_N),on=exp.and_(exp.column(_B,table=_G).eq(exp.column(_L,table=_N)),exp.column(_H,table=_G).eq(exp.column(_M,table=_N))),join_type='left',copy=_D).where(where)
			if lock_for_update:query=query.lock(copy=_D)
			yield query
	def _get_snapshots_with_same_version(self,snapshots:t.Collection[SnapshotNameVersionLike],lock_for_update:bool=_D)->t.List[SnapshotIdAndVersion]:
		if not snapshots:return[]
		snapshot_rows=[]
		for where in snapshot_name_version_filter(self.engine_adapter,snapshots,batch_size=self.SNAPSHOT_BATCH_SIZE):
			query=exp.select(_B,_F,_H,_O,_Q,_T).from_(exp.to_table(self.snapshots_table).as_(_G)).where(where)
			if lock_for_update:query=query.lock(copy=_D)
			snapshot_rows.extend(fetchall(self.engine_adapter,query))
		return[SnapshotIdAndVersion(name=name,identifier=identifier,version=version,kind_name=kind_name or _A,dev_version=dev_version,fingerprint=SnapshotFingerprint.parse_raw(fingerprint))for(name,identifier,version,kind_name,dev_version,fingerprint)in snapshot_rows]
def parse_snapshot(serialized_snapshot:str,updated_ts:int,unpaused_ts:t.Optional[int],unrestorable:bool,forward_only:bool,next_auto_restatement_ts:t.Optional[int])->Snapshot:return Snapshot(**{**json.loads(serialized_snapshot),_C:updated_ts,_I:unpaused_ts,_J:unrestorable,_K:forward_only,_P:next_auto_restatement_ts})
def _snapshot_to_json(snapshot:Snapshot)->str:return snapshot.json(exclude={'intervals','dev_intervals','pending_restatement_intervals',_C,_I,_J,_K,_P})
def _snapshots_to_df(snapshots:t.Iterable[Snapshot])->pd.DataFrame:import pandas as pd;return pd.DataFrame([{_B:snapshot.name,_F:snapshot.identifier,_H:snapshot.version,_U:_snapshot_to_json(snapshot),_O:snapshot.model_kind_name.value if snapshot.model_kind_name else _A,_C:snapshot.updated_ts,_I:snapshot.unpaused_ts,_S:snapshot.ttl_ms,_J:snapshot.unrestorable,_K:snapshot.forward_only,_Q:snapshot.dev_version,_T:snapshot.fingerprint.json()}for snapshot in snapshots])
def _auto_restatements_to_df(auto_restatements:t.Dict[SnapshotNameVersion,int])->pd.DataFrame:import pandas as pd;return pd.DataFrame([{_L:name_version.name,_M:name_version.version,_P:ts}for(name_version,ts)in auto_restatements.items()])