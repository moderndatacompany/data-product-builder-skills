from __future__ import annotations
_A6='allow_partials'
_A5='join_path'
_A4='TIMESTAMP'
_A3='ai_context'
_A2='columns_to_types_'
_A1='column_hashes_'
_A0='is_hydrated'
_z='rollup'
_y='depends_on_'
_x='_query_renderer'
_w='clustered_by'
_v='auto_restatement_cron'
_u='unknown'
_t='enabled'
_s='post_statements'
_r='pre_statements'
_q='optimize_query'
_p='interval_unit'
_o='cron'
_n='jinja_macros'
_m='granularity'
_l='metric'
_k='grains'
_j='depends_on'
_i='rollups'
_h='joins'
_g='measures'
_f='semantic'
_e='json'
_d='measure'
_c='terms'
_b='tags'
_a='null'
_Z='none'
_Y='column_descriptions'
_X='column_terms'
_W='column_tags'
_V='on_virtual_update'
_U='ts'
_T='seed'
_S='transaction'
_R='description'
_Q='merge_filter'
_P='signals'
_O='UNKNOWN'
_N='clickhouse'
_M='dialect'
_L='value'
_K='segments'
_J='dimensions'
_I='query'
_H='default_catalog'
_G='name'
_F='audits'
_E='__dict__'
_D='kind'
_C=False
_B=True
_A=None
import json,logging,types,re,typing as t
from typing_extensions import override
from functools import cached_property,partial
from pathlib import Path
from pydantic import Field,PrivateAttr,model_validator
from sqlglot import diff,exp,parse_one
from sqlglot.diff import Insert
from vulcan.core.dialect import build_expression_probe_query,is_compatible,normalize_model_name
from sqlglot.helper import seq_get
from sqlglot.optimizer.qualify_columns import quote_identifiers
from sqlglot.optimizer.simplify import gen
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.schema import MappingSchema,nested_set
from sqlglot.time import format_time
from vulcan.core import constants as c
from vulcan.core import dialect as d
from vulcan.core.audit import Audit,ModelAudit
from vulcan.core.config.common import MetricJoinPath
from vulcan.core.node import IntervalUnit,resolve_finest_cron
from vulcan.core.macros import MacroRegistry,macro
from vulcan.core.model.common import ParsableSql,VIRTUAL_MODEL_RENDER_DEFINITION_EXCLUDED_PROPERTIES,make_python_env,parse_dependencies,parse_strings_with_macro_refs,single_value_or_tuple,sorted_python_env_payloads,validate_extra_and_required_fields,without_model_properties
from vulcan.utils.paths import relative_to_project_config
from vulcan.core.model.meta import ModelMeta
from vulcan.core.model.kind import ModelKindName,SeedKind,ModelKind,FullKind,create_model_kind,CustomKind,MetricKind,SemanticKind
from vulcan.core.model.seed import CsvSeedReader,Seed,create_seed
from vulcan.core.model.policy import PolicySpec,parse_mask_sql
from vulcan.core.renderer import ExpressionRenderer,QueryRenderer
from vulcan.core.signal import SignalRegistry
from vulcan.core.types import Tag,Term
from vulcan.utils.hashtag import parse_hashtag_markers_by_column
from vulcan.utils import columns_to_types_all_known,get_columns_to_types_from_query,str_to_bool,UniqueKeyDict
from vulcan.utils.cron import CroniterCache
from vulcan.utils.date import TimeLike,make_inclusive,to_datetime,to_time_column
from vulcan.utils.errors import ConfigError,VulcanError,raise_config_error,PythonModelEvalError
from vulcan.utils.hashing import hash_data
from vulcan.utils.jinja import JinjaMacroRegistry,extract_macro_references_and_variables
from vulcan.utils.pydantic import PydanticModel,PRIVATE_FIELDS,field_serializer
from vulcan.utils.metaprogramming import Executable,SqlValue,build_env,prepare_env,serialize_env,format_evaluated_code_exception
if t.TYPE_CHECKING:from sqlglot.dialects.dialect import DialectType;from vulcan.core.node import _Node,SchemaDrift;from vulcan.core._typing import Self,TableName,SessionProperties;from vulcan.core.context import ExecutionContext;from vulcan.core.engine_adapter import EngineAdapter;from vulcan.core.engine_adapter._typing import QueryOrDF;from vulcan.core.engine_adapter.shared import DataObjectType;from vulcan.core.linter.rule import Rule;from vulcan.core.snapshot import DeployabilityIndex,Node,Snapshot;from vulcan.utils.jinja import MacroReference
from schema.types import LogicalTypeValue
from vulcan.core.model.semantic import AiContextSpec,DimensionSpec,JoinSpec,MeasureSpec,MetricGranularityValue,MetricNamedRefSpec,MetricSpec,RollupSpec,SemanticModelSpec,SegmentSpec,_literal,_hash,parse_qualified_reference
logger=logging.getLogger(__name__)
PROPERTIES={'physical_properties','session_properties','virtual_properties'}
RUNTIME_RENDERED_MODEL_FIELDS={_F,_P,_Q}|PROPERTIES
CRON_SHORTCUTS={'@midnight','@hourly','@daily','@weekly','@monthly','@yearly','@annually'}
class _Model(ModelMeta,frozen=_B):
	python_env:t.Dict[str,Executable]={};jinja_macros:JinjaMacroRegistry=JinjaMacroRegistry();audit_definitions:t.Dict[str,ModelAudit]={};mapping_schema:t.Dict[str,t.Any]={};extract_dependencies_from_query:bool=_B;pre_statements_:t.Optional[t.List[ParsableSql]]=Field(default=_A,alias=_r);post_statements_:t.Optional[t.List[ParsableSql]]=Field(default=_A,alias=_s);on_virtual_update_:t.Optional[t.List[ParsableSql]]=Field(default=_A,alias=_V);_full_depends_on:t.Optional[t.Set[str]]=_A;_statement_renderer_cache:t.Dict[int,ExpressionRenderer]={};_is_metadata_only_change_cache:t.Dict[int,bool]={};_expressions_validator=ParsableSql.validator()
	def __getstate__(self)->t.Dict[t.Any,t.Any]:state=super().__getstate__();private=state[PRIVATE_FIELDS];private['_statement_renderer_cache']={};return state
	def copy(self,**kwargs:t.Any)->Self:model=super().copy(**kwargs);model._statement_renderer_cache={};model.__dict__.pop(_W,_A);model.__dict__.pop(_X,_A);return model
	@cached_property
	def column_tags(self)->t.Dict[str,t.List[Tag]]:
		if self.column_tags_ is not _A:return self.column_tags_
		tags,_=parse_hashtag_markers_by_column(self.column_descriptions);return tags
	@cached_property
	def column_terms(self)->t.Dict[str,t.List[Term]]:
		if self.column_terms_ is not _A:return self.column_terms_
		_,terms=parse_hashtag_markers_by_column(self.column_descriptions);return terms
	def render(self,*,context:ExecutionContext,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,**kwargs:t.Any)->t.Iterator[QueryOrDF]:yield self.render_query_or_raise(start=start,end=end,execution_time=execution_time,snapshots=context.snapshots,deployability_index=context.deployability_index,engine_adapter=context.engine_adapter,config=context.config,**kwargs)
	def render_definition(self,include_python:bool=_B,include_defaults:bool=_C,render_query:bool=_C)->t.List[exp.Expression]:
		expressions=[];comment=_A
		for(field_name,field_info)in ModelMeta.all_field_infos().items():
			if not hasattr(self,field_name):continue
			field_value=getattr(self,field_name);meta_field=field_info.alias or field_name
			if include_defaults and field_value or field_value!=field_info.default:
				if field_name==_R:comment=field_value
				elif field_name==_D:expressions.append(exp.Property(this=_D,value=field_value.to_expression(dialect=self.dialect)))
				elif field_name==_G:expressions.append(exp.Property(this=field_name,value=exp.to_table(field_value,dialect=self.dialect)))
				elif meta_field not in(_H,_t,'ignored_rules_',_Y):expressions.append(exp.Property(this=meta_field,value=meta_field_converter(meta_field,field_name)(field_value)))
		model=d.Model(expressions=expressions);model.comments=[comment]if comment else _A;jinja_expressions=[];python_expressions=[]
		if include_python:
			python_env=d.PythonCode(expressions=sorted_python_env_payloads(self.python_env))
			if python_env.expressions:python_expressions.append(python_env)
			jinja_expressions=self.jinja_macros.to_expressions()
		return[model,*python_expressions,*jinja_expressions]
	def render_query(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,table_mapping:t.Optional[t.Dict[str,str]]=_A,expand:t.Iterable[str]=tuple(),deployability_index:t.Optional[DeployabilityIndex]=_A,engine_adapter:t.Optional[EngineAdapter]=_A,**kwargs:t.Any)->t.Optional[exp.Query]:return exp.select(*(exp.cast(exp.Null(),column_type,copy=_C).as_(name,copy=_C,quoted=_B)for(name,column_type)in(self.columns_to_types or{}).items()),copy=_C).from_(exp.values([tuple([1])],alias='t',columns=['dummy']),copy=_C)
	def render_query_or_raise(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,table_mapping:t.Optional[t.Dict[str,str]]=_A,expand:t.Iterable[str]=tuple(),deployability_index:t.Optional[DeployabilityIndex]=_A,engine_adapter:t.Optional[EngineAdapter]=_A,**kwargs:t.Any)->exp.Query:
		query=self.render_query(start=start,end=end,execution_time=execution_time,snapshots=snapshots,table_mapping=table_mapping,expand=expand,deployability_index=deployability_index,engine_adapter=engine_adapter,**kwargs)
		if query is _A:raise VulcanError(f"Failed to render query for model '{self.name}'.")
		return query
	def render_pre_statements(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,snapshots:t.Optional[t.Collection[Snapshot]]=_A,expand:t.Iterable[str]=tuple(),deployability_index:t.Optional[DeployabilityIndex]=_A,engine_adapter:t.Optional[EngineAdapter]=_A,inside_transaction:t.Optional[bool]=_B,**kwargs:t.Any)->t.List[exp.Expression]:return self._render_statements([stmt for stmt in self.pre_statements if stmt.args.get(_S,_B)==inside_transaction],start=start,end=end,execution_time=execution_time,snapshots=snapshots,expand=expand,deployability_index=deployability_index,engine_adapter=engine_adapter,**kwargs)
	def render_post_statements(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,expand:t.Iterable[str]=tuple(),deployability_index:t.Optional[DeployabilityIndex]=_A,engine_adapter:t.Optional[EngineAdapter]=_A,inside_transaction:t.Optional[bool]=_B,**kwargs:t.Any)->t.List[exp.Expression]:return self._render_statements([stmt for stmt in self.post_statements if stmt.args.get(_S,_B)==inside_transaction],start=start,end=end,execution_time=execution_time,snapshots=snapshots,expand=expand,deployability_index=deployability_index,engine_adapter=engine_adapter,**kwargs)
	def render_on_virtual_update(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,expand:t.Iterable[str]=tuple(),deployability_index:t.Optional[DeployabilityIndex]=_A,engine_adapter:t.Optional[EngineAdapter]=_A,**kwargs:t.Any)->t.List[exp.Expression]:return self._render_statements(self.on_virtual_update,start=start,end=end,execution_time=execution_time,snapshots=snapshots,expand=expand,deployability_index=deployability_index,engine_adapter=engine_adapter,**kwargs)
	def render_audit_query(self,audit:Audit,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,deployability_index:t.Optional[DeployabilityIndex]=_A,**kwargs:t.Any)->exp.Query:
		B='engine_adapter';A='this_model';from vulcan.core.snapshot import DeployabilityIndex;deployability_index=deployability_index or DeployabilityIndex.all_deployable();snapshot=(snapshots or{}).get(self.fqn);this_model=kwargs.pop(A,_A)or(snapshot.table_name(deployability_index.is_deployable(snapshot))if snapshot else self.fqn);columns_to_types:t.Optional[t.Dict[str,t.Any]]=_A
		if B in kwargs:
			try:columns_to_types=kwargs[B].columns(this_model)
			except Exception:pass
		if self.time_column:low,high=[self.convert_to_time_column(dt,columns_to_types)for dt in make_inclusive(start or c.EPOCH,end or c.EPOCH,self.dialect)];where=self.time_column.column.between(low,high)
		else:where=_A
		quoted_model_name=quote_identifiers(exp.to_table(this_model,dialect=self.dialect),dialect=self.dialect);query_renderer=QueryRenderer(audit.query,audit.dialect or self.dialect,audit.macro_definitions,path=audit._path or Path(),jinja_macro_registry=audit.jinja_macros,python_env=self.python_env,only_execution_time=self.kind.only_execution_time,default_catalog=self.default_catalog);rendered_query=query_renderer.render(start=start,end=end,execution_time=execution_time,snapshots=snapshots,deployability_index=deployability_index,**{**audit.defaults,A:exp.select('*').from_(quoted_model_name).where(where).subquery()if where is not _A else quoted_model_name,**kwargs})
		if rendered_query is _A:raise VulcanError(f"Failed to render query for audit '{audit.name}', model '{self.name}'.")
		return rendered_query
	@property
	def pre_statements(self)->t.List[exp.Expression]:return self._get_parsed_statements('pre_statements_')
	@property
	def post_statements(self)->t.List[exp.Expression]:return self._get_parsed_statements('post_statements_')
	@property
	def on_virtual_update(self)->t.List[exp.Expression]:return self._get_parsed_statements('on_virtual_update_')
	@property
	def macro_definitions(self)->t.List[d.MacroDef]:return[s for s in self.pre_statements+self.post_statements+self.on_virtual_update if isinstance(s,d.MacroDef)]
	def _get_parsed_statements(self,attr_name:str)->t.List[exp.Expression]:
		value=getattr(self,attr_name)
		if not value:return[]
		result=[]
		for v in value:
			parsed=v.parse(self.dialect)
			if getattr(v,_S,_A)is not _A:parsed.set(_S,v.transaction)
			if not isinstance(parsed,exp.Semicolon):result.append(parsed)
		return result
	def _render_statements(self,statements:t.Iterable[exp.Expression],**kwargs:t.Any)->t.List[exp.Expression]:rendered=(self._statement_renderer(statement).render(**kwargs)for statement in statements if not isinstance(statement,d.MacroDef));return[r for expressions in rendered if expressions for r in expressions]
	def _statement_renderer(self,expression:exp.Expression)->ExpressionRenderer:
		expression_key=id(expression)
		if expression_key not in self._statement_renderer_cache:self._statement_renderer_cache[expression_key]=ExpressionRenderer(expression,self.dialect,self.macro_definitions,path=self._path,jinja_macro_registry=self.jinja_macros,python_env=self.python_env,only_execution_time=_C,default_catalog=self.default_catalog,model=self)
		return self._statement_renderer_cache[expression_key]
	def render_signals(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A)->t.List[t.Dict[str,str|int|float|bool]]:
		def _render(e:exp.Expression)->str|int|float|bool:
			rendered_exprs=self._create_renderer(e).render(start=start,end=end,execution_time=execution_time)or[]
			if len(rendered_exprs)!=1:raise VulcanError(f"Expected one expression but got {len(rendered_exprs)}")
			rendered=rendered_exprs[0]
			if rendered.is_int:return int(rendered.this)
			if rendered.is_number:return float(rendered.this)
			if isinstance(rendered,(exp.Literal,exp.Boolean)):return rendered.this
			return rendered.sql(dialect=self.dialect)
		return[{k:_render(v)for(k,v)in signal.items()}for(name,signal)in self.signals if not name]
	def render_signal_calls(self)->EvaluatableSignals:python_env=self.python_env;env=prepare_env(python_env);signals_to_kwargs={name:{k:seq_get(self._create_renderer(v).render()or[],0)for(k,v)in kwargs.items()}for(name,kwargs)in self.signals if name};return EvaluatableSignals(signals_to_kwargs=signals_to_kwargs,python_env=python_env,prepared_python_env=env)
	def render_merge_filter(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A)->t.Optional[exp.Expression]:
		if self.merge_filter is _A:return
		rendered_exprs=self._create_renderer(self.merge_filter).render(start=start,end=end,execution_time=execution_time)or[]
		if len(rendered_exprs)!=1:raise VulcanError(f"Expected one expression but got {len(rendered_exprs)}")
		return rendered_exprs[0].transform(d.replace_merge_table_aliases,dialect=self.dialect)
	def _render_properties(self,properties:t.Dict[str,exp.Expression]|SessionProperties,**render_kwargs:t.Any)->t.Dict[str,t.Any]:
		def _render(expression:exp.Expression)->exp.Expression|_A:
			rendered_exprs=self._statement_renderer(expression).render(**render_kwargs)
			if not rendered_exprs or rendered_exprs[0].sql().lower()in{_Z,_a}:logger.info(f"Rendering '{expression.sql(dialect=self.dialect)}' did not return an expression");return
			if len(rendered_exprs)!=1:raise VulcanError(f"Expected one result when rendering '{expression.sql(dialect=self.dialect)}' but got {len(rendered_exprs)}")
			return rendered_exprs[0]
		return{k:rendered for(k,v)in properties.items()if(rendered:=_render(v)if isinstance(v,exp.Expression)else v)}
	def render_physical_properties(self,**render_kwargs:t.Any)->t.Dict[str,t.Any]:return self._render_properties(properties=self.physical_properties,**render_kwargs)
	def render_virtual_properties(self,**render_kwargs:t.Any)->t.Dict[str,t.Any]:return self._render_properties(properties=self.virtual_properties,**render_kwargs)
	def render_session_properties(self,**render_kwargs:t.Any)->t.Dict[str,t.Any]:return self._render_properties(properties=self.session_properties,**render_kwargs)
	def _create_renderer(self,expression:exp.Expression)->ExpressionRenderer:return ExpressionRenderer(expression,self.dialect,[],path=self._path,jinja_macro_registry=self.jinja_macros,python_env=self.python_env,only_execution_time=_C,quote_identifiers=_C)
	def ctas_query(self,**render_kwarg:t.Any)->exp.Query:
		query=self.render_query_or_raise(**render_kwarg).limit(0)
		for select_or_set_op in query.find_all(exp.Select,exp.SetOperation):
			if isinstance(select_or_set_op,exp.Select)and select_or_set_op.args.get('from'):select_or_set_op.where(exp.false(),copy=_C)
		if self.managed_columns:query.select(*[exp.alias_(exp.cast(exp.Null(),to=col_type),col)for(col,col_type)in self.managed_columns.items()if col not in query.named_selects],append=_B,copy=_C)
		return query
	def text_diff(self,other:Node,rendered:bool=_C)->str:
		if not isinstance(other,_Model):raise VulcanError(f"Cannot diff model '{self.name} against a non-model node '{other.name}'")
		old_path=relative_to_project_config(self._path);new_path=relative_to_project_config(other._path);text_diff=d.text_diff(self.render_definition(render_query=rendered),other.render_definition(render_query=rendered),self.dialect,other.dialect,fromfile=old_path,tofile=new_path).strip()
		if not text_diff and not rendered:text_diff=d.text_diff(self.render_definition(render_query=_B),other.render_definition(render_query=_B),self.dialect,other.dialect,fromfile=old_path,tofile=new_path).strip()
		return text_diff
	def schema_diff(self,other:Node)->t.Optional['SchemaDrift']:
		from vulcan.core.node import SchemaDrift,SchemaElementChange;from vulcan.core.schema_diff import get_schema_differ,TableAlterAddColumnOperation,TableAlterDropColumnOperation,TableAlterChangeColumnTypeOperation
		if not isinstance(other,_Model):return
		old_schema=self.columns_to_types;new_schema=other.columns_to_types
		if not old_schema or not new_schema:return
		try:
			schema_differ=get_schema_differ(self.dialect);alter_operations=schema_differ.compare_columns(self.name,old_schema,new_schema,ignore_destructive=_C,ignore_additive=_C);added=[];removed=[];modified=[]
			for op in alter_operations:
				col_name=op.column.alias_or_name
				if isinstance(op,TableAlterAddColumnOperation):added.append(SchemaElementChange(name=col_name,type=op.column_type.sql(dialect=self.dialect)))
				elif isinstance(op,TableAlterDropColumnOperation):old_type=old_schema.get(col_name);type_str=old_type.sql(dialect=self.dialect)if old_type else _u;removed.append(SchemaElementChange(name=col_name,type=type_str))
				elif isinstance(op,TableAlterChangeColumnTypeOperation):modified.append(SchemaElementChange(name=col_name,type=op.column_type.sql(dialect=self.dialect)))
			if not(added or removed or modified):return
			return SchemaDrift(added=added,removed=removed,modified=modified)
		except Exception as e:from vulcan.core.console import get_console;get_console().log_warning(f"Failed to use SchemaDiffer for schema diff on '{self.name}': {str(e)}");return
	def set_time_format(self,default_time_format:str=c.DEFAULT_TIME_COLUMN_FORMAT)->_A:
		if not self.time_column:return
		if self.time_column.format:formatted_time=format_time(self.time_column.format,d.Dialect.get_or_raise(self.dialect).TIME_MAPPING);assert formatted_time is not _A;self.time_column.format=formatted_time
		else:self.time_column.format=default_time_format
	def convert_to_time_column(self,time:TimeLike,columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A)->exp.Expression:
		if self.time_column:
			if columns_to_types is _A:columns_to_types=self.columns_to_types_or_raise
			if self.time_column.column.name not in columns_to_types:raise ConfigError(f"Time column '{self.time_column.column.sql(dialect=self.dialect)}' not found in model '{self.name}'.")
			time_column_type=columns_to_types[self.time_column.column.name];return to_time_column(time,time_column_type,self.dialect,self.time_column.format)
		return exp.convert(time)
	def set_mapping_schema(self,schema:t.Dict)->_A:self.mapping_schema.clear();self.mapping_schema.update(schema)
	def update_schema(self,schema:MappingSchema)->_A:
		for dep in self.depends_on:
			table=exp.to_table(dep);mapping_schema=schema.find(table)
			if mapping_schema:nested_set(self.mapping_schema,tuple(part.sql(copy=_C)for part in table.parts),{col:dtype.sql(dialect=self.dialect)for(col,dtype)in mapping_schema.items()})
	@property
	def depends_on(self)->t.Set[str]:return self.full_depends_on-{self.fqn}
	def _validate_columns_exist(self,columns_to_types:t.Dict[str,exp.DataType])->_A:
		if not columns_to_types:return
		if hasattr(self,'_columns_exist_validated'):return
		column_names=set(columns_to_types.keys());from vulcan.core.console import get_console;console=get_console();metadata_fields=[(self.column_descriptions_,'descriptions'),(self.column_tags_,_b),(self.column_terms_,_c),(self.column_mask_expressions_,'mask expressions'),(self.column_classifications_,'classifications')]
		for(metadata_dict,metadata_type)in metadata_fields:
			if metadata_dict:
				for col_name in list(metadata_dict):
					if col_name not in column_names:console.log_warning(f"In model '{self.name}', {metadata_type} are provided for an unknown column '{col_name}'");del metadata_dict[col_name]
		self._columns_exist_validated=_B
	def _validate_column_mask_expressions(self)->_A:
		if isinstance(self,MetricModel):return
		mask_expressions=dict(self.column_mask_expressions_ or{});columns_to_types=self.columns_to_types
		if not mask_expressions or not columns_to_types or not self.annotated:return
		dialect=self.dialect;parsed_expressions:dict[str,str]={};column_refs:set[str]=set()
		for(masked_column,raw_expression)in mask_expressions.items():
			if masked_column not in columns_to_types:raise_config_error(f"column_mask_expressions[{masked_column!r}] is not a model column",self._path)
			try:parsed_sql=parse_mask_sql(raw_expression,dialect=dialect,context=f"column_mask_expressions['{masked_column}']")
			except ValueError as err:raise_config_error(str(err),self._path)
			parsed_expressions[masked_column]=parsed_sql;column_refs|={column.name for column in parse_one(parsed_sql,dialect=dialect).find_all(exp.Column)if column.name and not column.table}
		if(unknown_column_refs:=sorted(column_refs-columns_to_types.keys())):raise_config_error(f"column_mask_expressions reference unknown columns {unknown_column_refs}",self._path)
		typed_query=build_expression_probe_query(parsed_expressions,columns_to_types,dialect=dialect)
		for select_expr in typed_query.selects:
			masked_column=select_expr.output_name
			if not masked_column or masked_column not in parsed_expressions:continue
			expected_type=columns_to_types[masked_column];inferred_type=select_expr.type or exp.DataType.build(_O,dialect=dialect)
			if not is_compatible(expected_type,inferred_type):raise_config_error(f"column_mask_expressions[{masked_column!r}] type mismatch: inferred {inferred_type.sql(dialect=dialect)}, expected {expected_type.sql(dialect=dialect)}",self._path)
	@property
	def columns_to_types(self)->t.Optional[t.Dict[str,exp.DataType]]:
		if self.columns_to_types_ is _A:return
		result={**self.columns_to_types_,**self.managed_columns};self._validate_columns_exist(result);return result
	@property
	def columns_to_types_or_raise(self)->t.Dict[str,exp.DataType]:
		columns_to_types=self.columns_to_types
		if columns_to_types is _A:raise VulcanError(f"Column information is not available for model '{self.name}'")
		return columns_to_types
	@property
	def annotated(self)->bool:
		if self.columns_to_types is _A:return _C
		columns_to_types={k:v for(k,v)in self.columns_to_types.items()if k not in self.managed_columns}
		if not columns_to_types:return _C
		return columns_to_types_all_known(columns_to_types)
	@property
	def sorted_python_env(self)->t.List[t.Tuple[str,Executable]]:return sorted(self.python_env.items(),key=lambda x:(x[1].kind,x[0]))
	@property
	def view_name(self)->str:return self.fully_qualified_table.name
	@property
	def schema_name(self)->str:return self.fully_qualified_table.db or c.DEFAULT_SCHEMA
	@property
	def physical_schema(self)->str:return self.physical_schema_override or f"{c.SQLMESH}__{self.schema_name}"
	@property
	def is_sql(self)->bool:return _C
	@property
	def is_python(self)->bool:return _C
	@property
	def is_seed(self)->bool:return _C
	@property
	def is_semantic(self)->bool:return _C
	@property
	def is_metric(self)->bool:return _C
	@property
	def depends_on_self(self)->bool:return self.fqn in self.full_depends_on
	@property
	def forward_only(self)->bool:return getattr(self.kind,'forward_only',_C)
	@property
	def disable_restatement(self)->bool:return getattr(self.kind,'disable_restatement',_C)
	@property
	def auto_restatement_intervals(self)->t.Optional[int]:return getattr(self.kind,'auto_restatement_intervals',_A)
	@property
	def auto_restatement_cron(self)->t.Optional[str]:return getattr(self.kind,_v,_A)
	def auto_restatement_croniter(self,value:TimeLike)->CroniterCache:
		cron=self.auto_restatement_cron
		if cron is _A:raise VulcanError('Auto restatement cron is not set.')
		return CroniterCache(cron,value)
	@property
	def wap_supported(self)->bool:return self.kind.is_materialized and(self.storage_format or'').lower()=='iceberg'
	def _validate_owner(self,known_users:t.AbstractSet[str])->_A:
		owner=(self.owner or'').strip()
		if not owner:raise_config_error('Model is missing an owner. Set `owner` on the model or in `model_defaults.owner`.',self._path)
		if owner not in known_users:known_str=', '.join(sorted(known_users))or'(none)';raise_config_error(f"Model owner '{owner}' is not listed in config.users. Known users: {known_str}",self._path)
	def validate_definition(self,*,known_users:t.Optional[t.AbstractSet[str]]=_A)->_A:
		if known_users is not _A:self._validate_owner(known_users)
		for field in('partitioned_by',_w):
			values=getattr(self,field)
			if values:
				values=[col.name for expr in values for col in t.cast(exp.Expression,exp.maybe_parse(expr,dialect=self.dialect)).find_all(exp.Column)];unique_keys=set(values)
				if len(values)!=len(unique_keys):raise_config_error(f"All keys in '{field}' must be unique in the model definition",self._path)
				columns_to_types=self.columns_to_types
				if columns_to_types is not _A:
					missing_keys=unique_keys-set(columns_to_types)
					if missing_keys:missing_keys_str=', '.join(f"'{k}'"for k in sorted(missing_keys));raise_config_error(f"{field} keys [{missing_keys_str}] are missing in the model definition",self._path)
		if self.kind.is_incremental_by_time_range and not self.time_column:raise_config_error('Incremental by time range models must have a time_column field',self._path)
		if self.kind.is_incremental_unmanaged and getattr(self.kind,'insert_overwrite',_C)and not self.partitioned_by_:raise_config_error('Unmanaged incremental models with insert / overwrite enabled must specify the partitioned_by field',self._path)
		if self.kind.is_managed:
			if self.dialect=='snowflake'and'target_lag'not in self.physical_properties:raise_config_error("Snowflake managed tables must specify the 'target_lag' physical property",self._path)
		if self.physical_version is not _A and not self.forward_only:raise_config_error('Pinning a physical version is only supported for forward only models',self._path)
		if not self.is_sql:
			if self.optimize_query:raise_config_error('Vulcan query optimizer can only be enabled for SQL models',self._path)
		if self.kind.name in(ModelKindName.EMBEDDED,ModelKindName.SEMANTIC,ModelKindName.METRIC)and self.audits:raise_config_error('Audits are not supported for embedded, semantic, or metric models',self._path)
		if isinstance(self.kind,CustomKind):from vulcan.core.snapshot.evaluator import get_custom_materialization_type_or_raise;get_custom_materialization_type_or_raise(self.kind.materialization)
		if self.policy and self.columns_to_types:
			model_columns=frozenset(self.columns_to_types.keys())
			for rule in self.policy.rules:
				unknown=rule.referenced_members()-model_columns
				if unknown:raise_config_error(f"Policy group {rule.group!r} references unknown columns {sorted(unknown)}",self._path)
		if self.policy:
			for name in sorted(self.policy.masked_members()):
				mask_expression=(self.column_mask_expressions or{}).get(name)
				if mask_expression in(_A,'')or isinstance(mask_expression,str)and not mask_expression.strip():raise_config_error(f"column_mask_expression is missing for proposed masking on column {name!r} (policy: {self.policy._path})",self._path)
		self._validate_column_mask_expressions()
	def is_breaking_change(self,previous:Model)->t.Optional[bool]:raise NotImplementedError
	def is_metadata_only_change(self,other:_Node)->bool:
		if self._is_metadata_only_change_cache.get(id(other),_A)is not _A:return self._is_metadata_only_change_cache[id(other)]
		is_metadata_change=_B
		if not isinstance(other,_Model)or self.metadata_hash==other.metadata_hash or self._data_hash_values_no_sql!=other._data_hash_values_no_sql:is_metadata_change=_C
		else:
			this_statements=[s for s in[*self.pre_statements,*self.post_statements]if not self._is_metadata_statement(s)];other_statements=[s for s in[*other.pre_statements,*other.post_statements]if not other._is_metadata_statement(s)]
			if len(this_statements)!=len(other_statements):is_metadata_change=_C
			else:
				for(this_statement,other_statement)in zip(this_statements,other_statements):
					this_rendered=self._statement_renderer(this_statement).render()or this_statement;other_rendered=other._statement_renderer(other_statement).render()or other_statement
					if this_rendered!=other_rendered:is_metadata_change=_C;break
		self._is_metadata_only_change_cache[id(other)]=is_metadata_change;return is_metadata_change
	@property
	def data_hash(self)->str:
		if self._data_hash is _A:self._data_hash=hash_data(self._data_hash_values)
		return self._data_hash
	@property
	def _data_hash_values(self)->t.List[str]:return self._data_hash_values_no_sql+self._data_hash_values_sql
	@property
	def _data_hash_values_sql(self)->t.List[str]:
		data=[]
		for statements in[self.pre_statements_,self.post_statements_]:
			for statement in statements or[]:data.append(statement.sql)
		return data
	@property
	def _data_hash_values_no_sql(self)->t.List[str]:
		data=[str([(k,v)for(k,v)in self.sorted_python_env if not v.is_metadata]),*self.kind.data_hash_values,self.table_format,self.storage_format,str(self.lookback),*(gen(expr)for expr in self.partitioned_by or[]),*(gen(expr)for expr in self.clustered_by or[]),self.stamp,self.physical_schema,self.physical_version,self.gateway,self.interval_unit.value if self.interval_unit is not _A else _A,str(self.optimize_query)if self.optimize_query is not _A else _A,self.virtual_environment_mode.value]
		for(column_name,column_type)in(self.columns_to_types_ or{}).items():data.append(column_name);data.append(column_type.sql(dialect=self.dialect))
		for(key,value)in(self.physical_properties or{}).items():data.append(key);data.append(gen(value))
		return data
	def _audit_metadata_hash_values(self)->t.List[str]:
		from vulcan.core.audit.builtin import BUILT_IN_AUDITS;metadata=[]
		for(audit_name,audit_args)in sorted(self.audits,key=lambda a:a[0]):
			metadata.append(audit_name)
			if audit_name in BUILT_IN_AUDITS:
				for(arg_name,arg_value)in audit_args.items():metadata.append(arg_name);metadata.append(gen(arg_value))
			else:audit=self.audit_definitions[audit_name];metadata.extend([audit.query_.sql,audit.dialect,str(audit.skip),str(audit.blocking)])
		return metadata
	def audit_metadata_hash(self)->str:return hash_data(self._audit_metadata_hash_values())
	@property
	def metadata_hash(self)->str:
		if self._metadata_hash is _A:
			metadata=[self.dialect,self.owner,self.description,json.dumps(self.column_descriptions,sort_keys=_B),json.dumps(self.column_mask_expressions,sort_keys=_B,default=str),*([f"column_classifications:{json.dumps(self.column_classifications,sort_keys=_B)}"]if self.column_classifications else[]),json.dumps({k:sorted(v)for(k,v)in(self.column_tags or{}).items()},sort_keys=_B),json.dumps({k:sorted(v)for(k,v)in(self.column_terms or{}).items()},sort_keys=_B),self.cron,self.cron_tz.key if self.cron_tz else _A,str(self.start)if self.start else _A,str(self.end)if self.end else _A,str(self.retention)if self.retention else _A,str(self.batch_size)if self.batch_size is not _A else _A,str(self.batch_concurrency)if self.batch_concurrency is not _A else _A,json.dumps(self.mapping_schema,sort_keys=_B),*sorted(self.tags),*sorted(self.terms),*sorted(ref.json(sort_keys=_B)for ref in self.all_references),*self.kind.metadata_hash_values,self.project,str(self.allow_partials),gen(self.session_properties_)if self.session_properties_ else _A,*[gen(g)for g in self.grains],*self._audit_metadata_hash_values(),json.dumps(self.grants,sort_keys=_B)if self.grants else _A,self.grants_target_layer]
			for(key,value)in(self.virtual_properties or{}).items():metadata.append(key);metadata.append(gen(value))
			for(signal_name,args)in sorted(self.signals,key=lambda x:x[0]):
				metadata.append(signal_name)
				for(k,v)in sorted(args.items()):metadata.append(f"{k}:{gen(v)}")
			if self.dbt_node_info:metadata.append(self.dbt_node_info.json(sort_keys=_B))
			metadata.extend(self._additional_metadata);self._metadata_hash=hash_data(metadata)
		return self._metadata_hash
	@property
	def is_model(self)->bool:return _B
	@property
	def grants_table_type(self)->DataObjectType:
		A='materialized';from vulcan.core.engine_adapter.shared import DataObjectType
		if self.kind.is_view:
			if hasattr(self.kind,A)and getattr(self.kind,A,_C):return DataObjectType.MATERIALIZED_VIEW
			return DataObjectType.VIEW
		if self.kind.is_managed:return DataObjectType.MANAGED_TABLE
		return DataObjectType.TABLE
	@property
	def _additional_metadata(self)->t.List[str]:
		additional_metadata=[];metadata_only_macros=[(k,v)for(k,v)in self.sorted_python_env if v.is_metadata]
		if metadata_only_macros:additional_metadata.append(str(metadata_only_macros))
		for statements in[self.pre_statements_,self.post_statements_,self.on_virtual_update_]:
			for statement in statements or[]:additional_metadata.append(statement.sql)
		if self.dq is not _A:additional_metadata.append(self.dq.fingerprint())
		if self.policy is not _A:additional_metadata.append(self.policy.fingerprint())
		return additional_metadata
	def _is_metadata_statement(self,statement:exp.Expression)->bool:
		if isinstance(statement,d.MacroDef):return _B
		if isinstance(statement,d.MacroFunc):
			target_macro=macro.get_registry().get(statement.name)
			if target_macro:return target_macro.metadata_only
			target_macro=self.python_env.get(statement.name)
			if target_macro:return bool(target_macro.is_metadata)
		return _C
	@property
	def full_depends_on(self)->t.Set[str]:
		if not self.extract_dependencies_from_query:return self.depends_on_ or set()
		if self._full_depends_on is _A:
			depends_on=self.depends_on_ or set();query=self.render_query(needs_optimization=_C)
			if query is not _A:depends_on|=d.find_tables(query,default_catalog=self.default_catalog,dialect=self.dialect)
			self._full_depends_on=depends_on
		return self._full_depends_on
	@property
	def partitioned_by(self)->t.List[exp.Expression]:
		if self.time_column and not self._is_time_column_in_partitioned_by:
			if hasattr(self.kind,'partition_by_time_column')and self.kind.partition_by_time_column:return[TIME_COL_PARTITION_FUNC.get(self.dialect,lambda x,y:x)(self.time_column.column,self.columns_to_types),*self.partitioned_by_]
		return self.partitioned_by_
	@property
	def partition_interval_unit(self)->t.Optional[IntervalUnit]:
		if self.time_column and not self._is_time_column_in_partitioned_by:return self.interval_unit
	@property
	def audits_with_args(self)->t.List[t.Tuple[Audit,t.Dict[str,exp.Expression]]]:
		from vulcan.core.audit.builtin import BUILT_IN_AUDITS;audits_by_name={**BUILT_IN_AUDITS,**self.audit_definitions};audits_with_args=[];added_audits=set()
		for(audit_name,audit_args)in self.audits:audits_with_args.append((audits_by_name[audit_name],audit_args.copy()));added_audits.add(audit_name)
		for audit_name in self.audit_definitions:
			if audit_name not in added_audits:audits_with_args.append((audits_by_name[audit_name],{}))
		return audits_with_args
	@property
	def _is_time_column_in_partitioned_by(self)->bool:return self.time_column is not _A and self.time_column.column in{col for expr in self.partitioned_by_ for col in expr.find_all(exp.Column)}
	@property
	def violated_rules_for_query(self)->t.Dict[type[Rule],t.Any]:return{}
class SqlModel(_Model):
	query_:ParsableSql=Field(alias=_I);source_type:t.Literal['sql']='sql';_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A
	def __getstate__(self)->t.Dict[t.Any,t.Any]:state=super().__getstate__();state[_E]=state[_E].copy();state[_E].pop(_x,_A);state[_E].pop(_Y,_A);state[_E].pop(_W,_A);state[_E].pop(_X,_A);private=state[PRIVATE_FIELDS];private['_columns_to_types']=_A;return state
	def copy(self,**kwargs:t.Any)->Self:
		model=super().copy(**kwargs);model.__dict__.pop(_x,_A);model.__dict__.pop(_Y,_A);model.__dict__.pop(_W,_A);model.__dict__.pop(_X,_A);model._columns_to_types=_A
		if kwargs.get('update',{}).keys()&{_y,_I}:model._full_depends_on=_A
		return model
	@property
	def query(self)->t.Union[exp.Query,d.JinjaQuery,d.MacroFunc]:parsed_query=self.query_.parse(self.dialect);return t.cast(t.Union[exp.Query,d.JinjaQuery,d.MacroFunc],parsed_query)
	def render_query(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,table_mapping:t.Optional[t.Dict[str,str]]=_A,expand:t.Iterable[str]=tuple(),deployability_index:t.Optional[DeployabilityIndex]=_A,engine_adapter:t.Optional[EngineAdapter]=_A,**kwargs:t.Any)->t.Optional[exp.Query]:query=self._query_renderer.render(start=start,end=end,execution_time=execution_time,snapshots=snapshots,table_mapping=table_mapping,expand=expand,deployability_index=deployability_index,engine_adapter=engine_adapter,**kwargs);return query
	def render_definition(self,include_python:bool=_B,include_defaults:bool=_C,render_query:bool=_C)->t.List[exp.Expression]:
		result=super().render_definition(include_python=include_python,include_defaults=include_defaults)
		if render_query:
			result.extend(self.render_pre_statements());result.append(self.render_query()or self.query);result.extend(self.render_post_statements())
			if(virtual_update:=self.render_on_virtual_update()):result.append(d.VirtualUpdateStatement(expressions=virtual_update))
		else:
			result.extend(self.pre_statements);result.append(self.query);result.extend(self.post_statements)
			if self.on_virtual_update:result.append(d.VirtualUpdateStatement(expressions=self.on_virtual_update))
		return result
	@property
	def is_sql(self)->bool:return _B
	@property
	def columns_to_types(self)->t.Optional[t.Dict[str,exp.DataType]]:
		if self.columns_to_types_ is not _A:self._columns_to_types=self.columns_to_types_
		elif self._columns_to_types is _A:
			try:query=self._query_renderer.render()
			except Exception:logger.exception('Failed to render query for model %s',self.fqn);return
			if query is _A:return
			unknown=exp.DataType.build(_u);columns_to_types={}
			for select in query.selects:
				output_name=select.output_name
				if not output_name or output_name in columns_to_types:return
				columns_to_types[output_name]=(select.type or unknown).copy()
			self._columns_to_types=columns_to_types
		if'*'in self._columns_to_types:return
		result={**self._columns_to_types,**self.managed_columns};self._validate_columns_exist(result);return result
	@cached_property
	def column_descriptions(self)->t.Dict[str,str]:
		if self.column_descriptions_ is not _A:return self.column_descriptions_
		query=self.render_query()
		if query is _A:return{}
		return{select.alias_or_name:select.comments[-1].strip()for select in query.selects if select.comments and select.alias_or_name}
	def set_mapping_schema(self,schema:t.Dict)->_A:super().set_mapping_schema(schema);self._on_mapping_schema_set()
	def update_schema(self,schema:MappingSchema)->_A:super().update_schema(schema);self._on_mapping_schema_set()
	def _on_mapping_schema_set(self)->_A:self._columns_to_types=_A;self._query_renderer.update_schema(self.mapping_schema)
	def validate_definition(self,*,known_users:t.Optional[t.AbstractSet[str]]=_A)->_A:
		if known_users is not _A:self._validate_owner(known_users)
		query=self._query_renderer.render()
		if query is _A:
			if self.depends_on_ is _A:raise_config_error('Dependencies must be provided explicitly for models that can be rendered only at runtime',self._path)
			return
		if not isinstance(query,exp.Query):raise_config_error('Missing SELECT query in the model definition',self._path)
		projection_list=query.selects
		if not projection_list:raise_config_error('Query missing select statements',self._path)
		if self.depends_on_self and not self.annotated:raise_config_error('Self-referencing models require inferrable column types. There are three options available to mitigate this issue: add explicit types to all projections in the outermost SELECT statement, leverage external models (https://vulcan.readthedocs.io/en/stable/concepts/models/external_models/), or use the `columns` model attribute (https://vulcan.readthedocs.io/en/stable/concepts/models/overview/#columns).',self._path)
		super().validate_definition()
	def is_breaking_change(self,previous:Model)->t.Optional[bool]:
		if not isinstance(previous,SqlModel):return
		if self.lookback!=previous.lookback:return
		try:previous_query=previous.render_query()
		except Exception:previous_query=_A
		this_query=self.render_query()
		if previous_query is _A or this_query is _A:return
		if previous_query is this_query:edits=[]
		else:edits=diff(previous_query,this_query,matchings=[(previous_query,this_query)],delta_only=_B,dialect=self.dialect if self.dialect==previous.dialect else _A)
		inserted_expressions={e.expression for e in edits if isinstance(e,Insert)}
		for edit in edits:
			if not isinstance(edit,Insert):return
			expr=edit.expression
			if isinstance(expr,exp.UDTF):
				parent=expr.find_ancestor(exp.Subquery)
				if not parent:return
				expr=parent
			if not _is_projection(expr)and expr.parent not in inserted_expressions:return
		return _C
	def is_metadata_only_change(self,previous:_Node)->bool:
		if self._is_metadata_only_change_cache.get(id(previous),_A)is not _A:return self._is_metadata_only_change_cache[id(previous)]
		if not super().is_metadata_only_change(previous):return _C
		if not isinstance(previous,SqlModel):self._is_metadata_only_change_cache[id(previous)]=_C;return _C
		this_rendered_query=self.render_query()or self.query;previous_rendered_query=previous.render_query()or previous.query;is_metadata_change=this_rendered_query==previous_rendered_query;self._is_metadata_only_change_cache[id(previous)]=is_metadata_change;return is_metadata_change
	@cached_property
	def _query_renderer(self)->QueryRenderer:no_quote_identifiers=self.kind.is_view and self.dialect in('trino','spark');return QueryRenderer(self.query,self.dialect,self.macro_definitions,schema=self.mapping_schema,path=self._path,jinja_macro_registry=self.jinja_macros,python_env=self.python_env,only_execution_time=self.kind.only_execution_time,default_catalog=self.default_catalog,quote_identifiers=not no_quote_identifiers,optimize_query=self.optimize_query,model=self)
	@property
	def _data_hash_values_no_sql(self)->t.List[str]:return[*super()._data_hash_values_no_sql,*self.jinja_macros.data_hash_values]
	@property
	def _data_hash_values_sql(self)->t.List[str]:return[*super()._data_hash_values_sql,self.query_.sql]
	@property
	def _additional_metadata(self)->t.List[str]:return[*super()._additional_metadata,self.query_.sql]
	@property
	def violated_rules_for_query(self)->t.Dict[type[Rule],t.Any]:self.render_query();return self._query_renderer._violated_rules
class RollupModel(SqlModel):
	source_type:t.Literal[_z]=_z;extract_dependencies_from_query:bool=_B
	@model_validator(mode='before')
	@classmethod
	def remove_legacy_snapshot_fields(cls,values:t.Any)->t.Any:
		if not isinstance(values,dict):return values
		legacy_fields='rollup_spec','rollup_columns','owning_semantic_name','transpile_schema'
		if not any(field in values for field in legacy_fields):return values
		values=values.copy()
		for field in legacy_fields:values.pop(field,_A)
		return values
class SeedModel(_Model):
	kind:SeedKind;seed:Seed;column_hashes_:t.Optional[t.Dict[str,str]]=Field(default=_A,alias='column_hashes');derived_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A;is_hydrated:bool=_B;source_type:t.Literal[_T]=_T
	def __getstate__(self)->t.Dict[t.Any,t.Any]:state=super().__getstate__();state[_E]=state[_E].copy();state[_E].pop('_reader',_A);return state
	def copy(self,**kwargs:t.Any)->Self:model=super().copy(**kwargs);model.__dict__.pop('_reader',_A);return model
	def render(self,*,context:ExecutionContext,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,**kwargs:t.Any)->t.Iterator[QueryOrDF]:
		if not self.is_hydrated:return
		yield from self.render_seed()
	def render_seed(self)->t.Iterator[QueryOrDF]:
		import numpy as np;self._ensure_hydrated();date_columns=[];datetime_columns=[];bool_columns=[];string_columns=[];columns_to_types=self.columns_to_types_ or{};column_names_to_check=set(columns_to_types)
		for(name,tpe)in columns_to_types.items():
			if tpe.this in(exp.DataType.Type.DATE,exp.DataType.Type.DATE32):date_columns.append(name)
			elif tpe.this in exp.DataType.TEMPORAL_TYPES:datetime_columns.append(name)
			elif tpe.is_type('boolean'):bool_columns.append(name)
			elif tpe.this in exp.DataType.TEXT_TYPES:string_columns.append(name)
		for df in self._reader.read(batch_size=self.kind.batch_size):
			rename_dict={}
			for column in columns_to_types:
				if column not in df:
					normalized_name=normalize_identifiers(column,dialect=self.dialect).name
					if normalized_name in df:rename_dict[normalized_name]=column
			if rename_dict:df.rename(columns=rename_dict,inplace=_B);column_names_to_check-=set(rename_dict)
			missing_columns=column_names_to_check-set(df.columns)
			if missing_columns:raise_config_error(f"Seed model '{self.name}' has missing columns: {missing_columns}",self._path)
			for column in[*date_columns,*datetime_columns]:import pandas as pd;df[column]=pd.to_datetime(df[column],errors='coerce')
			for column in date_columns:
				try:df[column]=df[column].dt.date
				except Exception as ex:logger.error("Failed to convert column '%s' to date in seed model '%s': %s",column,self.name,ex)
			for column in bool_columns:df[column]=df[column].apply(lambda i:str_to_bool(str(i)))
			df.loc[:,string_columns]=df[string_columns].mask(cond=lambda x:x.notna(),other=df[string_columns].astype(str));yield df.replace({np.nan:_A})
	@property
	def columns_to_types(self)->t.Optional[t.Dict[str,exp.DataType]]:
		if self.columns_to_types_ is not _A:result=self.columns_to_types_
		elif self.derived_columns_to_types is not _A:result=self.derived_columns_to_types
		elif self.is_hydrated:result=self._reader.columns_to_types
		else:return
		if result:self._validate_columns_exist(result)
		return result
	@property
	def column_hashes(self)->t.Dict[str,str]:
		if self.column_hashes_ is not _A:return self.column_hashes_
		self._ensure_hydrated();return self._reader.column_hashes
	@property
	def is_seed(self)->bool:return _B
	@property
	def seed_path(self)->Path:
		seed_path=Path(self.kind.path)
		if not seed_path.is_absolute():
			if self._path is _A:raise VulcanError(f"Seed model '{self.name}' has no path")
			return self._path.parent/seed_path
		return seed_path
	@property
	def depends_on(self)->t.Set[str]:return(self.depends_on_ or set())-{self.fqn}
	@property
	def depends_on_self(self)->bool:return _C
	@property
	def batch_size(self)->t.Optional[int]:0
	def to_dehydrated(self)->SeedModel:
		if not self.is_hydrated:return self
		return self.copy(update={_T:Seed(content=''),_A0:_C,_A1:self.column_hashes,'derived_columns_to_types':self.columns_to_types if self.columns_to_types_ is _A else _A})
	def to_hydrated(self,content:str)->SeedModel:
		if self.is_hydrated:return self
		return self.copy(update={_T:Seed(content=content),_A0:_B,_A1:_A})
	def is_breaking_change(self,previous:Model)->t.Optional[bool]:
		if not isinstance(previous,SeedModel):return
		new_columns=set(self.column_hashes);old_columns=set(previous.column_hashes)
		if not new_columns.issuperset(old_columns):return
		for col in old_columns:
			if self.column_hashes[col]!=previous.column_hashes[col]:return
		return _C
	def _ensure_hydrated(self)->_A:
		if not self.is_hydrated:raise VulcanError(f"Seed model '{self.name}' is not hydrated.")
	@cached_property
	def _reader(self)->CsvSeedReader:return self.seed.reader(dialect=self.dialect,settings=self.kind.csv_settings)
	@property
	def _data_hash_values_no_sql(self)->t.List[str]:
		data=super()._data_hash_values_no_sql
		for(column_name,column_hash)in self.column_hashes.items():data.append(column_name);data.append(column_hash)
		data.append(json.dumps(self.grants,sort_keys=_B)if self.grants else'');data.append(self.grants_target_layer);return data
class PythonModel(_Model):
	kind:ModelKind=FullKind();entrypoint:str;source_type:t.Literal['python']='python'
	def validate_definition(self,*,known_users:t.Optional[t.AbstractSet[str]]=_A)->_A:
		super().validate_definition(known_users=known_users)
		if self.kind and not self.kind.supports_python_models:raise_config_error(f"Cannot create Python model '{self.name}' as the '{self.kind.name}' kind doesn't support Python models",self._path)
	def render(self,*,context:ExecutionContext,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,**kwargs:t.Any)->t.Iterator[QueryOrDF]:
		env=prepare_env(self.python_env);start,end=make_inclusive(start or c.EPOCH,end or c.EPOCH,self.dialect);execution_time=to_datetime(execution_time or c.EPOCH);variables={**env.get(c.SQLMESH_VARS,{}),**env.get(c.SQLMESH_VARS_METADATA,{}),**kwargs.pop('variables',{})};blueprint_variables={k:d.parse_one(v.sql,dialect=self.dialect)if isinstance(v,SqlValue)else v for(k,v)in{**env.get(c.SQLMESH_BLUEPRINT_VARS,{}),**env.get(c.SQLMESH_BLUEPRINT_VARS_METADATA,{})}.items()}
		try:
			kwargs={**variables,**kwargs,'start':start,'end':end,'execution_time':execution_time,'latest':execution_time};df_or_iter=env[self.entrypoint](context=context.with_variables(variables,blueprint_variables=blueprint_variables),**kwargs)
			if not isinstance(df_or_iter,types.GeneratorType):df_or_iter=[df_or_iter]
			for df in df_or_iter:yield df
		except Exception as e:raise PythonModelEvalError(format_evaluated_code_exception(e,self.python_env))
	def render_definition(self,include_python:bool=_B,include_defaults:bool=_C,render_query:bool=_C)->t.List[exp.Expression]:return super().render_definition(include_python=_B,include_defaults=include_defaults,render_query=render_query)
	@property
	def is_python(self)->bool:return _B
	def is_breaking_change(self,previous:Model)->t.Optional[bool]:0
	@property
	def _data_hash_values_no_sql(self)->t.List[str]:data=super()._data_hash_values_no_sql;data.append(self.entrypoint);return data
class ExternalModel(_Model):
	source_type:t.Literal['external']='external'
	def is_breaking_change(self,previous:Model)->t.Optional[bool]:
		if not isinstance(previous,ExternalModel):return
		if not previous.columns_to_types_or_raise.items()-self.columns_to_types_or_raise.items():return _C
	@property
	def depends_on(self)->t.Set[str]:return set()
	@property
	def depends_on_self(self)->bool:return _C
_SEMANTIC_DB='__virtual'
METRIC_COL_MEASURE=_d
METRIC_COL_TS=_U
class _LogicalColumnTypesMixin:
	def _declared_column_names(self)->t.List[str]:raise NotImplementedError
	def _canonicalize_logical_types(self,columns:t.Mapping[str,exp.DataType])->t.Dict[str,exp.DataType]:
		result=dict(columns)
		for name in self._declared_column_names():
			matching_keys=[key for key in result if str(key).casefold()==name.casefold()]
			if not matching_keys:continue
			dtype=result[name]if name in result else result[matching_keys[0]]
			for key in matching_keys:result.pop(key,_A)
			result[name]=dtype
		return result
	def _effective_column_types(self,value:t.Optional[t.Dict[str,exp.DataType]]=_A)->t.Optional[t.Dict[str,exp.DataType]]:
		source=self.columns_to_types_ if value is _A else value;override=self._cols_types_override;effective=override if override is not _A else source
		if effective is _A:return
		return self._canonicalize_logical_types(effective)
	@field_serializer(_A2,when_used=_e,check_fields=_C)
	def _serialize_effective_column_types(self,value:t.Optional[t.Dict[str,exp.DataType]])->t.Optional[t.Dict[str,str]]:
		effective=self._effective_column_types(value)
		if effective is _A:return
		return{name:dtype.sql(dialect=self.dialect)for(name,dtype)in effective.items()}
	@property
	def columns_to_types(self)->t.Optional[t.Dict[str,exp.DataType]]:
		effective=self._effective_column_types()
		if effective is _A:return
		result={**effective,**self.managed_columns};self._validate_columns_exist(result);return result
class SemanticModel(_LogicalColumnTypesMixin,_Model):
	source_type:t.Literal[_f]=_f;ai_context:t.Optional[AiContextSpec]=_A;dimensions:t.List[DimensionSpec]=Field(...);measures:t.List[MeasureSpec]=Field(default_factory=list);segments:t.List[SegmentSpec]=Field(default_factory=list);joins:t.List[JoinSpec]=Field(default_factory=list);rollups:t.List[RollupSpec]=Field(default_factory=list)
	@model_validator(mode='before')
	@classmethod
	def remove_legacy_policies(cls,values:t.Any)->t.Any:
		A='policies'
		if isinstance(values,dict)and A in values:values=values.copy();values.pop(A)
		return values
	_cols_types_override:t.Optional[t.Dict[str,exp.DataType]]=PrivateAttr(default=_A)
	def _declared_column_names(self)->t.List[str]:return[*(dimension.name for dimension in self.dimensions),*(measure.name for measure in self.measures),*(segment.name for segment in self.segments)]
	def validate_definition(self,*,known_users:t.Optional[t.AbstractSet[str]]=_A)->_A:
		super().validate_definition(known_users=known_users)
		if self.kind and not isinstance(self.kind,SemanticKind):raise_config_error(f"Cannot create semantic model '{self.name}' as the '{self.kind.name}' kind is not SEMANTIC",self._path)
	@property
	def is_semantic(self)->bool:return _B
	@cached_property
	def fqn(self)->str:return normalize_model_name(f"{_SEMANTIC_DB}.{self.name}",default_catalog=self.default_catalog,dialect=self.dialect)
	@override
	def update_schema(self,schema:MappingSchema)->_A:super().update_schema(schema);self._on_mapping_schema_set()
	@override
	def set_mapping_schema(self,schema:t.Dict)->_A:super().set_mapping_schema(schema);self._on_mapping_schema_set()
	def _on_mapping_schema_set(self)->_A:
		if not self.columns_to_types_:return
		from vulcan.core.model.schema import flatten_nested_mapping_schema;dialect=self.dialect;columns_by_path=flatten_nested_mapping_schema(self.mapping_schema);full=self._canonicalize_logical_types(self.columns_to_types_)
		for d in self.dimensions:
			sql_type:t.Optional[str]=_A
			for dep in sorted(self.depends_on):
				path=tuple(p.sql(copy=_C)for p in exp.to_table(dep,dialect=dialect).parts);row=columns_by_path.get(path)
				if row is _A:continue
				row_folded={str(col).casefold():typ for(col,typ)in row.items()};sql_type=row_folded.get(d.name.casefold())
				if sql_type is not _A:break
			if sql_type is _A:continue
			full[d.name]=exp.DataType.build(sql_type,dialect=dialect)
		self._cols_types_override=full;self._data_hash=_A;self._metadata_hash=_A
	def render_definition(self,include_python:bool=_B,include_defaults:bool=_C,render_query:bool=_C)->t.List[exp.Expression]:
		result=super().render_definition(include_python=include_python,include_defaults=include_defaults,render_query=render_query)
		if not result:return result
		head=result[0]
		if not isinstance(head,d.Model):return result
		member_blocks=(_J,self.dimensions),*((name,members)for(name,members)in((_g,self.measures),(_K,self.segments),(_h,self.joins),(_i,self.rollups))if members);body=[exp.Property(this=exp.to_identifier(prop_name),value=exp.Tuple(expressions=[member.render_exp()for member in sorted(members,key=lambda x:x.name)]))for(prop_name,members)in member_blocks];merged=d.Model(expressions=[*without_model_properties(head.expressions,exclude=lambda p:p.name.lower()in VIRTUAL_MODEL_RENDER_DEFINITION_EXCLUDED_PROPERTIES),*body]);merged.comments=head.comments;return[merged,*result[1:]]
	@property
	def _data_hash_values_no_sql(self)->t.List[str]:top={k:v for(k,v)in{_D:_f,_G:self.name,_j:tuple(sorted(self.depends_on))}.items()if v is not _A};payload={**top,_k:sorted(gen(g)for g in self.grains),_J:[d.data_hash()for d in self.dimensions],_g:[m.data_hash()for m in sorted(self.measures,key=lambda x:x.name)],_K:[s.data_hash()for s in sorted(self.segments,key=lambda x:x.name)],_h:[j.data_hash()for j in sorted(self.joins,key=lambda x:x.name)],_i:[r.data_hash()for r in sorted(self.rollups,key=lambda x:x.name)]};return[*super()._data_hash_values_no_sql,_hash(payload)]
	@property
	def _additional_metadata(self)->t.List[str]:top={k:v for(k,v)in{_G:self.name,_R:self.description,_A3:self.ai_context.model_dump(mode=_e,exclude_none=_B)if self.ai_context else _A}.items()if v is not _A};payload={**top,_J:[d.metadata_hash()for d in self.dimensions],_g:[m.metadata_hash()for m in sorted(self.measures,key=lambda x:x.name)],_K:[s.metadata_hash()for s in sorted(self.segments,key=lambda x:x.name)],_h:[j.metadata_hash()for j in sorted(self.joins,key=lambda x:x.name)],_i:[r.metadata_hash()for r in sorted(self.rollups,key=lambda x:x.name)]};return[*super()._additional_metadata,_hash(payload)]
	def is_breaking_change(self,previous:Model)->t.Optional[bool]:
		if not isinstance(previous,SemanticModel):return
		if self.name!=previous.name:return _B
		if not{m.name for m in self.measures}.issuperset({m.name for m in previous.measures}):return _B
		if not{s.name for s in self.segments}.issuperset({s.name for s in previous.segments}):return _B
		if not{j.name for j in self.joins}.issuperset({j.name for j in previous.joins}):return _B
		if not{d.name for d in self.dimensions}.issuperset({d.name for d in previous.dimensions}):return _B
		if not{r.name for r in self.rollups}.issuperset({r.name for r in previous.rollups}):return _B
		if self.data_hash!=previous.data_hash:return _B
		return _C
class MetricModel(_LogicalColumnTypesMixin,_Model):
	source_type:t.Literal[_l]=_l;measure:str;ts:str;granularity:MetricGranularityValue;dimensions:t.List[MetricNamedRefSpec]=Field(default_factory=list);segments:t.List[MetricNamedRefSpec]=Field(default_factory=list);ai_context:t.Optional[AiContextSpec]=_A;join_path:t.Optional[MetricJoinPath]=_A;_cols_types_override:t.Optional[t.Dict[str,exp.DataType]]=PrivateAttr(default=_A)
	def _declared_column_names(self)->t.List[str]:return[METRIC_COL_MEASURE,METRIC_COL_TS,*(dimension.name for dimension in self.dimensions),*(segment.name for segment in self.segments)]
	def validate_definition(self,*,known_users:t.Optional[t.AbstractSet[str]]=_A)->_A:
		super().validate_definition(known_users=known_users)
		if self.kind and not isinstance(self.kind,MetricKind):raise_config_error(f"Cannot create metric model '{self.name}' as the '{self.kind.name}' kind is not METRIC",self._path)
	@property
	def is_metric(self)->bool:return _B
	@cached_property
	def fqn(self)->str:return normalize_model_name(f"{_SEMANTIC_DB}.{self.name}",default_catalog=self.default_catalog,dialect=self.dialect)
	@override
	def update_schema(self,schema:MappingSchema)->_A:super().update_schema(schema);self._on_mapping_schema_set()
	@override
	def set_mapping_schema(self,schema:t.Dict)->_A:super().set_mapping_schema(schema);self._on_mapping_schema_set()
	def _datatype_for_qual_ref(self,ref:str,*,columns_by_path:t.Dict[t.Tuple[str,...],t.Dict[str,str]])->t.Optional[exp.DataType]:
		parsed=parse_qualified_reference(ref)
		if not parsed:return
		sem,field=parsed;dialect=self.dialect;dep:t.Optional[str]=_A
		for fq in self.depends_on:
			last=exp.to_table(fq,dialect=dialect).parts[-1];short=last.name if isinstance(last,exp.Identifier)else str(last)
			if short.casefold()==sem.casefold():dep=fq;break
		if not dep:return
		path=tuple(p.sql(copy=_C)for p in exp.to_table(dep,dialect=dialect).parts);row=columns_by_path.get(path)
		if row is _A:return
		row_folded={str(col).casefold():typ for(col,typ)in row.items()};type_sql=row_folded.get(field.casefold());return exp.DataType.build(type_sql,dialect=dialect)if type_sql else _A
	def _on_mapping_schema_set(self)->_A:
		from vulcan.core.model.schema import flatten_nested_mapping_schema;unknown=exp.DataType.build(_O);timestamp=exp.DataType.build(_A4);boolean=exp.DataType.build('BOOLEAN');columns_by_path=flatten_nested_mapping_schema(self.mapping_schema);refs:t.List[t.Tuple[str,str,exp.DataType]]=[(METRIC_COL_MEASURE,self.measure,unknown),(METRIC_COL_TS,self.ts,timestamp),*[(sl.name,sl.ref,unknown)for sl in sorted(self.dimensions,key=lambda x:x.name)],*[(seg.name,seg.ref,boolean)for seg in sorted(self.segments,key=lambda x:x.name)]];cols={metric_key:self._datatype_for_qual_ref(r,columns_by_path=columns_by_path)or fb for(metric_key,r,fb)in refs};dialect=self.dialect;prev=getattr(self,'_cols_types_override',_A)
		if prev and set(prev)==set(cols)and all(prev[k].sql(dialect=dialect)==cols[k].sql(dialect=dialect)for k in cols):return
		self._cols_types_override=cols;self._data_hash=_A;self._metadata_hash=_A
	def render_definition(self,include_python:bool=_B,include_defaults:bool=_C,render_query:bool=_C)->t.List[exp.Expression]:
		result=super().render_definition(include_python=include_python,include_defaults=include_defaults,render_query=render_query)
		if not result:return result
		head=result[0]
		if not isinstance(head,d.Model):return result
		body:t.List[exp.Property]=[exp.Property(this=exp.to_identifier(_d),value=_literal(self.measure)),exp.Property(this=exp.to_identifier(_U),value=_literal(self.ts)),exp.Property(this=exp.to_identifier(_m),value=_literal(self.granularity))]
		if self.dimensions:body.append(exp.Property(this=exp.to_identifier(_J),value=exp.Tuple(expressions=[s.render_exp()for s in sorted(self.dimensions,key=lambda x:x.name)])))
		if self.segments:body.append(exp.Property(this=exp.to_identifier(_K),value=exp.Tuple(expressions=[s.render_exp()for s in sorted(self.segments,key=lambda x:x.name)])))
		if self.join_path is not _A:body.append(exp.Property(this=exp.to_identifier(_A5),value=exp.Literal.string(self.join_path.value)))
		merged=d.Model(expressions=[*without_model_properties(head.expressions,exclude=lambda p:p.name.lower()in VIRTUAL_MODEL_RENDER_DEFINITION_EXCLUDED_PROPERTIES),*body]);merged.comments=head.comments;return[merged,*result[1:]]
	@property
	def _data_hash_values_no_sql(self)->t.List[str]:top={k:v for(k,v)in{_D:_l,_G:self.name,_d:self.measure}.items()if v is not _A};payload={**top,_U:self.ts,_m:self.granularity,_J:[s.data_hash()for s in sorted(self.dimensions,key=lambda x:x.name)],_K:[s.data_hash()for s in sorted(self.segments,key=lambda x:x.name)]};return[*super()._data_hash_values_no_sql,_hash(payload)]
	@property
	def _additional_metadata(self)->t.List[str]:
		top={k:v for(k,v)in{_G:self.name,_R:self.description or'','owner':self.owner,_b:self.tags,_c:self.terms}.items()if v is not _A};payload={**top,_A3:self.ai_context.model_dump(mode=_e,exclude_none=_B)if self.ai_context else _A,_U:self.ts,_m:self.granularity,_J:[s.metadata_hash()for s in sorted(self.dimensions,key=lambda x:x.name)],_K:[s.metadata_hash()for s in sorted(self.segments,key=lambda x:x.name)]}
		if self.join_path is not _A:payload[_A5]=self.join_path.value
		return[*super()._additional_metadata,_hash(payload)]
	def is_breaking_change(self,previous:Model)->t.Optional[bool]:
		if not isinstance(previous,MetricModel):return
		if self.name!=previous.name:return _B
		if self.measure!=previous.measure:return _B
		if self.ts!=previous.ts or self.granularity!=previous.granularity:return _B
		old_dimension_refs={s.ref for s in previous.dimensions}
		if not{s.ref for s in self.dimensions}.issuperset(old_dimension_refs):return _B
		old_segment_refs={s.ref for s in previous.segments}
		if not{s.ref for s in self.segments}.issuperset(old_segment_refs):return _B
		return _C
Model=t.Union[SqlModel,SeedModel,PythonModel,ExternalModel,SemanticModel,MetricModel,RollupModel]
class AuditResult(PydanticModel):audit:Audit;audit_args:t.Dict[t.Any,t.Any];model:t.Optional[_Model]=_A;count:t.Optional[int]=_A;query:t.Optional[exp.Expression]=_A;skipped:bool=_C;blocking:bool=_B
class EvaluatableSignals(PydanticModel):signals_to_kwargs:t.Dict[str,t.Dict[str,t.Optional[exp.Expression]]];python_env:t.Dict[str,Executable];prepared_python_env:t.Dict[str,t.Any]
def _extract_blueprints(blueprints:t.Any,path:Path)->t.List[t.Any]:
	if not blueprints:return[_A]
	if isinstance(blueprints,exp.Paren):return[blueprints.unnest()]
	if isinstance(blueprints,(exp.Tuple,exp.Array)):return blueprints.expressions
	if isinstance(blueprints,list):return blueprints
	raise_config_error(f"Expected a list or tuple consisting of key-value mappings for the 'blueprints' property, got '{blueprints}' instead",path);return[]
def _extract_blueprint_variables(blueprint:t.Any,path:Path)->t.Dict[str,t.Any]:
	if not blueprint:return{}
	if isinstance(blueprint,(exp.Paren,exp.PropertyEQ)):blueprint=blueprint.unnest();return{blueprint.left.name.lower():blueprint.right}
	if isinstance(blueprint,(exp.Tuple,exp.Array)):return{e.left.name.lower():e.right for e in blueprint.expressions}
	if isinstance(blueprint,dict):return{k.lower():v for(k,v)in blueprint.items()}
	raise_config_error(f"Expected a key-value mapping for the blueprint value, got '{blueprint}' instead",path);return{}
def create_models_from_blueprints(gateway:t.Optional[str|exp.Expression],blueprints:t.Any,get_variables:t.Callable[[t.Optional[str]],t.Dict[str,str]],loader:t.Callable[...,Model],path:Path=Path(),module_path:Path=Path(),dialect:DialectType=_A,default_catalog_per_gateway:t.Optional[t.Dict[str,str]]=_A,**loader_kwargs:t.Any)->t.List[Model]:
	model_blueprints:t.List[Model]=[]
	for blueprint in _extract_blueprints(blueprints,path):
		blueprint_variables=_extract_blueprint_variables(blueprint,path)
		if gateway:rendered_gateway=render_expression(expression=exp.maybe_parse(gateway,dialect=dialect),module_path=module_path,macros=loader_kwargs.get('macros'),jinja_macros=loader_kwargs.get(_n),path=path,dialect=dialect,default_catalog=loader_kwargs.get(_H),blueprint_variables=blueprint_variables);gateway_name=rendered_gateway[0].name if rendered_gateway else _A
		else:gateway_name=_A
		if default_catalog_per_gateway and gateway_name and(catalog:=default_catalog_per_gateway.get(gateway_name))is not _A:loader_kwargs[_H]=catalog
		model_blueprints.append(loader(path=path,module_path=module_path,dialect=dialect,variables=get_variables(gateway_name),blueprint_variables=blueprint_variables,**loader_kwargs))
	return model_blueprints
def load_sql_based_models(expressions:t.List[exp.Expression],get_variables:t.Callable[[t.Optional[str]],t.Dict[str,str]],path:Path=Path(),module_path:Path=Path(),dialect:DialectType=_A,default_catalog_per_gateway:t.Optional[t.Dict[str,str]]=_A,**loader_kwargs:t.Any)->t.List[Model]:
	gateway:t.Optional[exp.Expression]=_A;blueprints:t.Optional[exp.Expression]=_A;model_meta=seq_get(expressions,0)
	for prop in isinstance(model_meta,d.Model)and model_meta.expressions or[]:
		if prop.name=='gateway':gateway=prop.args[_L]
		elif prop.name=='blueprints':blueprints=prop.pop().args[_L]
	if isinstance(blueprints,d.MacroFunc):
		rendered_blueprints=render_expression(expression=blueprints,module_path=module_path,macros=loader_kwargs.get('macros'),jinja_macros=loader_kwargs.get(_n),variables=get_variables(_A),path=path,dialect=dialect,default_catalog=loader_kwargs.get(_H))
		if not rendered_blueprints:raise_config_error('Failed to render blueprints property',path)
		assert rendered_blueprints
		if len(rendered_blueprints)>1:rendered_blueprints=[exp.Tuple(expressions=rendered_blueprints)]
		blueprints=rendered_blueprints[0]
	return create_models_from_blueprints(gateway=gateway,blueprints=blueprints,get_variables=get_variables,loader=partial(load_sql_based_model,expressions),path=path,module_path=module_path,dialect=dialect,default_catalog_per_gateway=default_catalog_per_gateway,**loader_kwargs)
def load_sql_based_model(expressions:t.List[exp.Expression],*,defaults:t.Optional[t.Dict[str,t.Any]]=_A,path:t.Optional[Path]=_A,module_path:Path=Path(),time_column_format:str=c.DEFAULT_TIME_COLUMN_FORMAT,macros:t.Optional[MacroRegistry]=_A,jinja_macros:t.Optional[JinjaMacroRegistry]=_A,audits:t.Optional[t.Dict[str,ModelAudit]]=_A,python_env:t.Optional[t.Dict[str,Executable]]=_A,dialect:t.Optional[str]=_A,physical_schema_mapping:t.Optional[t.Dict[re.Pattern,str]]=_A,default_catalog:t.Optional[str]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,infer_names:t.Optional[bool]=_C,blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A,**kwargs:t.Any)->Model:
	B='assertions';A='columns';missing_model_msg=f"""Please add a MODEL block at the top of the file. Example:

MODEL (
  name vulcan_example.full_model, --model name
  kind FULL, --materialization
  cron '@daily', --schedule
);

"""
	if not expressions:raise_config_error(missing_model_msg)
	dialect=dialect or'';meta=expressions[0]
	if not isinstance(meta,d.Model):
		if not infer_names:raise_config_error(missing_model_msg)
		meta=d.Model(expressions=[]);expressions.insert(0,meta)
	unrendered_properties={};unrendered_merge_filter=_A
	for prop in meta.expressions:
		if isinstance(prop,d.MacroFunc):continue
		prop_name=prop.name.lower()
		if prop_name in{_P,_F}|PROPERTIES:unrendered_properties[prop_name]=prop.args.get(_L)
		elif prop.name.lower()==_D and(value:=prop.args.get(_L))and value.name.lower()=='incremental_by_unique_key':
			for kind_prop in value.expressions:
				if kind_prop.name.lower()==_Q:unrendered_merge_filter=kind_prop
	rendered_meta_exprs=render_expression(expression=meta,module_path=module_path,macros=macros,jinja_macros=jinja_macros,variables=variables,path=path,dialect=dialect,default_catalog=default_catalog,blueprint_variables=blueprint_variables)
	if rendered_meta_exprs is _A or len(rendered_meta_exprs)!=1:raise_config_error(f"Invalid MODEL statement:\n{meta.sql(dialect=dialect,pretty=_B)}",path);raise
	rendered_meta=rendered_meta_exprs[0];rendered_defaults=render_model_defaults(defaults=defaults,module_path=module_path,macros=macros,jinja_macros=jinja_macros,variables=variables,path=path,dialect=dialect,default_catalog=default_catalog)if defaults else{};rendered_defaults=parse_defaults_properties(rendered_defaults,dialect=dialect);query_or_seed_insert,pre_statements,post_statements,on_virtual_update,inline_audits=_split_sql_model_statements(expressions[1:],path,dialect=dialect);meta_fields:t.Dict[str,t.Any]={_M:dialect,_R:'\n'.join(comment.strip()for comment in rendered_meta.comments)if rendered_meta.comments else _A,**{prop.name.lower():prop.args.get(_L)for prop in rendered_meta.expressions},**kwargs};meta_fields.update(unrendered_properties)
	if B in meta_fields:
		if _F in meta_fields:raise_config_error("Cannot specify both 'audits' and 'assertions' - use one or the other",path)
		meta_fields[_F]=meta_fields.pop(B)
	if unrendered_merge_filter:
		for(idx,kind_prop)in enumerate(meta_fields[_D].expressions):
			if kind_prop.name.lower()==_Q:meta_fields[_D].expressions[idx]=unrendered_merge_filter
	if isinstance(meta_fields.get(_M),exp.Expression):meta_fields[_M]=meta_fields[_M].name
	name=meta_fields.pop(_G,'')
	if not name and infer_names:
		if path is _A:raise ValueError(f"Model {name} must have a name")
		name=get_model_name(path)
	if not name:raise_config_error("Please add the required 'name' field to the MODEL block at the top of the file.\n\n")
	if _H in meta_fields:raise_config_error('`default_catalog` cannot be set on a per-model basis. It must be set at the connection level.',path)
	common_kwargs=dict(pre_statements=pre_statements,post_statements=post_statements,on_virtual_update=on_virtual_update,defaults=rendered_defaults,path=path,module_path=module_path,macros=macros,python_env=python_env,jinja_macros=jinja_macros,physical_schema_mapping=physical_schema_mapping,default_catalog=default_catalog,variables=variables,inline_audits=inline_audits,blueprint_variables=blueprint_variables,use_original_sql=_B,**meta_fields);kind=common_kwargs.pop(_D,ModelMeta.all_field_infos()[_D].default)
	if kind.name!=ModelKindName.SEED:return create_sql_model(name,query_or_seed_insert,kind=kind,time_column_format=time_column_format,**common_kwargs)
	seed_properties={p.name.lower():p.args.get(_L)for p in kind.expressions};explicit_seed_columns=meta_fields.get(A)or(rendered_defaults or{}).get(A)
	if not explicit_seed_columns and isinstance(query_or_seed_insert,exp.Query)and(inferred_columns:=get_columns_to_types_from_query(query_or_seed_insert,dialect)):common_kwargs[A]=inferred_columns
	return create_seed_model(name,SeedKind(**seed_properties),**common_kwargs)
def create_sql_model(name:TableName,query:t.Optional[exp.Expression],**kwargs:t.Any)->Model:
	if not isinstance(query,(exp.Query,d.JinjaQuery,d.MacroFunc)):raise_config_error('A query is required and must be a SELECT statement, a UNION statement, or a JINJA_QUERY block',kwargs.get('path'));assert isinstance(query,(exp.Query,d.JinjaQuery,d.MacroFunc))
	return _create_model(SqlModel,name,query=query,**kwargs)
def create_seed_model(name:TableName,seed_kind:SeedKind,*,path:t.Optional[Path]=_A,module_path:Path=Path(),**kwargs:t.Any)->Model:
	seed_path=Path(seed_kind.path);marker,*subdirs=seed_path.parts
	if marker.lower()=='$root':seed_path=module_path.joinpath(*subdirs);seed_kind.path=str(seed_path)
	elif not seed_path.is_absolute():
		if path is _A:seed_path=seed_path
		elif path.is_dir():seed_path=path/seed_path
		else:seed_path=path.parent/seed_path
	seed=create_seed(seed_path);return _create_model(SeedModel,name,path=path,seed=seed,kind=seed_kind,depends_on=kwargs.pop(_j,_A),module_path=module_path,**kwargs)
def create_python_model(name:str,entrypoint:str,python_env:t.Dict[str,Executable],*,macros:t.Optional[MacroRegistry]=_A,jinja_macros:t.Optional[JinjaMacroRegistry]=_A,path:Path=Path(),module_path:Path=Path(),depends_on:t.Optional[t.Set[str]]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A,**kwargs:t.Any)->Model:
	dialect=kwargs.get(_M);dependencies_unspecified=depends_on is _A;parsed_depends_on,referenced_variables=parse_dependencies(python_env,entrypoint,strict_resolution=dependencies_unspecified,variables=variables,blueprint_variables=blueprint_variables)if python_env is not _A else(set(),set())
	if dependencies_unspecified:depends_on=parsed_depends_on-{name}
	else:depends_on_rendered=render_expression(expression=exp.Array(expressions=[exp.maybe_parse(dep,dialect=dialect)for dep in depends_on or[]]),module_path=module_path,macros=macros,jinja_macros=jinja_macros,variables=variables,path=path,dialect=dialect,default_catalog=kwargs.get(_H));depends_on={dep.sql(dialect=dialect)for dep in t.cast(t.List[exp.Expression],depends_on_rendered)[0].expressions}
	used_variables={k:v for(k,v)in(variables or{}).items()if k in referenced_variables}
	if used_variables:python_env[c.SQLMESH_VARS]=Executable.value(used_variables,sort_root_dict=_B)
	return _create_model(PythonModel,name,path=path,depends_on=depends_on,entrypoint=entrypoint,python_env=python_env,macros=macros,jinja_macros=jinja_macros,module_path=module_path,variables=variables,blueprint_variables=blueprint_variables,**kwargs)
def create_external_model(name:TableName,*,dialect:t.Optional[str]=_A,path:Path=Path(),defaults:t.Optional[t.Dict[str,t.Any]]=_A,**kwargs:t.Any)->ExternalModel:return t.cast(ExternalModel,_create_model(ExternalModel,name,defaults=defaults,dialect=dialect,path=path,kind=ModelKindName.EXTERNAL.value,**kwargs))
def _resolve_model_owner(*,spec_owner:t.Optional[str],inherited_owner:t.Optional[str]=_A,defaults:t.Optional[t.Dict[str,t.Any]]=_A)->str:
	if spec_owner is not _A:return spec_owner
	if inherited_owner and inherited_owner.strip():return inherited_owner.strip()
	default_owner=(defaults or{}).get('owner')if defaults else _A
	if default_owner is not _A and str(default_owner).strip():return str(default_owner).strip()
	return''
def create_semantic_model(name:str,*,spec:SemanticModelSpec,project:str,depends_on:'Model',dialect:str,default_catalog:t.Optional[str],path:t.Optional[Path],module_path:Path=Path(),defaults:t.Optional[t.Dict[str,t.Any]]=_A)->SemanticModel:
	physical=depends_on;depends_on_fqn=normalize_model_name(physical.name,default_catalog,dialect);grains=list(getattr(physical,_k,_A)or());inject_implicit_count=bool(grains)and not any(m.name.lower()=='count'for m in spec.measures);explicit_dimensions=list(spec.dimensions);seen_dimensions:t.Set[str]={d.name for d in explicit_dimensions};implicit_dimensions:t.List[DimensionSpec]=[]
	for grain in grains:
		dim=DimensionSpec.implicit_grain(grain)
		if dim.name not in seen_dimensions:seen_dimensions.add(dim.name);implicit_dimensions.append(dim)
	if physical.policy:
		for member in sorted(physical.policy.referenced_members()):
			if member not in seen_dimensions:seen_dimensions.add(member);implicit_dimensions.append(DimensionSpec.implicit_policy_member(member))
	dimensions=explicit_dimensions+implicit_dimensions;measures=sorted([*spec.measures,MeasureSpec.implicit_count()]if inject_implicit_count else spec.measures,key=lambda m:m.name);segments=sorted(spec.segments,key=lambda s:s.name);physical_columns=physical.columns_to_types or{};physical_columns_by_folded_name:t.Dict[str,exp.DataType]={k.casefold():v for(k,v)in physical_columns.items()};unknown=exp.DataType.build(_O);columns_to_types:t.Dict[str,exp.DataType]={**{d.name:physical_columns_by_folded_name.get(d.name.casefold(),unknown)for d in dimensions},**{m.name:m.exp for m in measures},**{s.name:s.exp for s in segments}};column_tags:t.Dict[str,t.List[Tag]]={};column_terms:t.Dict[str,t.List[Term]]={};column_descriptions:t.Dict[str,str]={};column_classifications:t.Dict[str,str]={}
	for group in(dimensions,measures,segments):
		for obj in group:
			if(text:=(obj.description or'').strip()):column_descriptions[obj.name]=text
			if obj.tags:column_tags[obj.name]=list(obj.tags)
			if obj.terms:column_terms[obj.name]=list(obj.terms)
	for dim in dimensions:
		col=dim.name
		if col not in column_descriptions:
			for(phys_col,phys_desc)in physical.column_descriptions.items():
				if phys_col.casefold()==col.casefold()and str(phys_desc).strip():column_descriptions[col]=str(phys_desc).strip();break
		if col not in column_tags:
			for(phys_col,phys_tags)in physical.column_tags.items():
				if phys_col.casefold()==col.casefold()and phys_tags:column_tags[col]=list(phys_tags);break
		if col not in column_terms:
			for(phys_col,phys_terms)in physical.column_terms.items():
				if phys_col.casefold()==col.casefold()and phys_terms:column_terms[col]=list(phys_terms);break
		if col not in column_classifications:
			for(phys_col,level)in physical.column_classifications.items():
				if phys_col.casefold()==col.casefold()and level:column_classifications[col]=level;break
	joins=[join.model_copy(update={'fqn':normalize_model_name(f"{_SEMANTIC_DB}.{join.name}",default_catalog=default_catalog,dialect=dialect)})for join in spec.joins];description=spec.description if spec.description is not _A else physical.description;owner=_resolve_model_owner(spec_owner=spec.owner,inherited_owner=physical.owner,defaults=defaults);tags=list(spec.tags)if spec.tags is not _A else list(physical.tags);terms=list(spec.terms)if spec.terms is not _A else list(physical.terms);cron_vals=physical.cron;cron_tz_vals=physical.cron_tz;interval_vals=physical.interval_unit_;return t.cast(SemanticModel,_create_model(SemanticModel,name,ai_context=spec.ai_context,column_classifications=column_classifications or _A,column_descriptions=column_descriptions or _A,column_tags=column_tags or _A,column_terms=column_terms or _A,columns=columns_to_types,cron=cron_vals,cron_tz=cron_tz_vals,default_catalog=default_catalog,depends_on={depends_on_fqn},description=description,dialect=dialect,dimensions=dimensions,grains=grains,interval_unit=interval_vals,joins=joins,kind=SemanticKind(),measures=measures,owner=owner,path=path,module_path=module_path,project=project,rollups=spec.rollups,segments=spec.segments,tags=tags,terms=terms))
def create_metric_model(name:str,*,spec:MetricSpec,project:str,depends_on:t.Iterable[SemanticModel],dialect:str,default_catalog:t.Optional[str],path:t.Optional[Path],module_path:Path=Path(),description:t.Optional[str]=_A,defaults:t.Optional[t.Dict[str,t.Any]]=_A)->MetricModel:
	models_by_name={semantic.name:semantic for semantic in depends_on};resolved=tuple(models_by_name.values());depends_on_fqns={semantic.fqn for semantic in resolved};owner=_resolve_model_owner(spec_owner=spec.owner,defaults=defaults);cron_vals,cron_tz_vals,interval_vals=resolve_finest_cron(nodes=resolved,path=path)
	def _dtype(ref:str)->t.Optional[exp.DataType]:
		parsed=parse_qualified_reference(ref)
		if not parsed:return
		semantic_name,field=parsed;model=models_by_name.get(semantic_name);ctt=model.columns_to_types if model else _A
		if not ctt:return
		return ctt.get(field)
	unknown=exp.DataType.build(_O);timestamp=exp.DataType.build(_A4);boolean=exp.DataType.build('BOOLEAN');columns_to_types:t.Dict[str,exp.DataType]={METRIC_COL_MEASURE:_dtype(spec.measure)or unknown,METRIC_COL_TS:_dtype(spec.ts)or timestamp,**{d.name:_dtype(d.ref)or unknown for d in sorted(spec.dimensions,key=lambda s:s.name)},**{seg.name:_dtype(seg.ref)or boolean for seg in sorted(spec.segments,key=lambda s:s.name)}};column_tags:t.Dict[str,t.List[Tag]]={};column_terms:t.Dict[str,t.List[Term]]={};column_descriptions:t.Dict[str,str]={};column_classifications:t.Dict[str,str]={}
	def _copy_from_semantic_ref(metric_col:str,ref:str)->_A:
		parsed=parse_qualified_reference(ref)
		if not parsed:return
		semantic_name,field=parsed;sm=models_by_name.get(semantic_name)
		if not sm:return
		if metric_col not in column_descriptions:
			for(sem_col,sem_desc)in sm.column_descriptions.items():
				if sem_col.casefold()==field.casefold()and str(sem_desc).strip():column_descriptions[metric_col]=str(sem_desc).strip();break
		if metric_col not in column_tags:
			for(sem_col,sem_tags)in sm.column_tags.items():
				if sem_col.casefold()==field.casefold()and sem_tags:column_tags[metric_col]=list(sem_tags);break
		if metric_col not in column_terms:
			for(sem_col,sem_terms)in sm.column_terms.items():
				if sem_col.casefold()==field.casefold()and sem_terms:column_terms[metric_col]=list(sem_terms);break
		if metric_col not in column_classifications:
			for(sem_col,level)in sm.column_classifications.items():
				if sem_col.casefold()==field.casefold()and level:column_classifications[metric_col]=level;break
	for(metric_col,ref)in((METRIC_COL_MEASURE,spec.measure),(METRIC_COL_TS,spec.ts),*((dim.name,dim.ref)for dim in sorted(spec.dimensions,key=lambda s:s.name)),*((segment.name,segment.ref)for segment in sorted(spec.segments,key=lambda s:s.name))):_copy_from_semantic_ref(metric_col,ref)
	for dim in sorted(spec.dimensions,key=lambda s:s.name):
		if dim.description.strip():column_descriptions[dim.name]=dim.description.strip()
		if dim.tags:column_tags[dim.name]=list(dim.tags)
		if dim.terms:column_terms[dim.name]=list(dim.terms)
	for segment in sorted(spec.segments,key=lambda s:s.name):
		if segment.description.strip():column_descriptions[segment.name]=segment.description.strip()
		if segment.tags:column_tags[segment.name]=list(segment.tags)
		if segment.terms:column_terms[segment.name]=list(segment.terms)
	return t.cast(MetricModel,_create_model(MetricModel,name,ai_context=spec.ai_context,column_classifications=column_classifications or _A,column_descriptions=column_descriptions or _A,column_tags=column_tags or _A,column_terms=column_terms or _A,columns=columns_to_types,cron=cron_vals,cron_tz=cron_tz_vals,default_catalog=default_catalog,depends_on=depends_on_fqns,description=description,dialect=dialect,dimensions=spec.dimensions,granularity=spec.granularity,interval_unit=interval_vals,join_path=spec.join_path,kind=MetricKind(),measure=spec.measure,owner=owner,path=path,module_path=module_path,project=project,segments=spec.segments,tags=list(spec.tags)if spec.tags else _A,terms=list(spec.terms)if spec.terms else _A,ts=spec.ts))
def create_rollup_model(name:str,*,query:exp.Expression,depends_on:t.Iterable[str],cron_nodes:t.Iterable[_Model],dialect:str,path:Path,owner:t.Optional[str]=_A,source_path:t.Optional[Path]=_A,project:t.Optional[str]=_A,default_catalog:t.Optional[str]=_A,module_path:Path=Path(),description:t.Optional[str]=_A,defaults:t.Optional[t.Dict[str,t.Any]]=_A)->RollupModel:
	from vulcan.core.model.kind import create_model_kind;depends_on_fqns=set(depends_on);cron_node_list=list(cron_nodes)
	if not depends_on_fqns:raise_config_error(f"rollup model {name!r}: depends_on must not be empty")
	if not cron_node_list:raise_config_error(f"rollup model {name!r}: cron_nodes must not be empty")
	resolved_owner=_resolve_model_owner(spec_owner=_A,inherited_owner=owner,defaults=defaults);cron_vals,cron_tz_vals,interval_vals=resolve_finest_cron(nodes=cron_node_list,path=path);rollup_defaults={key:value for(key,value)in(defaults or{}).items()if key not in{_o,'cron_tz',_p}}
	if not isinstance(query,exp.Query):raise_config_error(f"rollup model {name!r}: query must be a SELECT statement",path)
	return t.cast(RollupModel,_create_model(RollupModel,name,defaults=rollup_defaults,cron=cron_vals,cron_tz=cron_tz_vals,default_catalog=default_catalog,depends_on=depends_on_fqns,description=description or _A,dialect=dialect,interval_unit=interval_vals,kind=create_model_kind('FULL',dialect,rollup_defaults),owner=resolved_owner,path=path,module_path=module_path,source_path=source_path,project=project,query=query))
def _create_model(klass:t.Type[_Model],name:TableName,*,defaults:t.Optional[t.Dict[str,t.Any]]=_A,path:t.Optional[Path]=_A,time_column_format:str=c.DEFAULT_TIME_COLUMN_FORMAT,jinja_macros:t.Optional[JinjaMacroRegistry]=_A,jinja_macro_references:t.Optional[t.Set[MacroReference]]=_A,depends_on:t.Optional[t.Set[str]]=_A,dialect:t.Optional[str]=_A,physical_schema_mapping:t.Optional[t.Dict[re.Pattern,str]]=_A,python_env:t.Optional[t.Dict[str,Executable]]=_A,audit_definitions:t.Optional[t.Dict[str,ModelAudit]]=_A,inline_audits:t.Optional[t.Dict[str,ModelAudit]]=_A,module_path:Path=Path(),macros:t.Optional[MacroRegistry]=_A,signal_definitions:t.Optional[SignalRegistry]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A,use_original_sql:bool=_C,**kwargs:t.Any)->Model:
	profiles=kwargs.pop('profiles',_A)
	if isinstance(profiles,exp.Expression):from vulcan.core.console import get_console;get_console().log_warning(f"Model '{name}' declares `profiles` in MODEL (...). Column profiling belongs in `type: dq` YAML (`profiles:`), not MODEL. This property is ignored.")
	validate_extra_and_required_fields(klass,{_G,*kwargs}-{'grain','table_properties'},'MODEL block',path)
	for prop in PROPERTIES:kwargs[prop]=_resolve_properties((defaults or{}).get(prop),kwargs.get(prop))
	dialect=dialect or'';physical_schema_mapping=physical_schema_mapping or{};model_schema_name=exp.to_table(name,dialect=dialect).db;physical_schema_override:t.Optional[str]=_A
	for(re_pattern,override_schema)in physical_schema_mapping.items():
		if re.match(re_pattern,model_schema_name):physical_schema_override=override_schema;break
	raw_kind=kwargs.pop(_D,_A)
	if raw_kind:kwargs[_D]=create_model_kind(raw_kind,dialect,defaults or{})
	defaults={k:v for(k,v)in(defaults or{}).items()if k in klass.all_fields()}
	if not issubclass(klass,SqlModel):defaults.pop(_q,_A)
	statements:t.List[t.Union[exp.Expression,t.Tuple[exp.Expression,bool]]]=[]
	if _I in kwargs:statements.append(kwargs[_I]);kwargs[_I]=ParsableSql.from_parsed_expression(kwargs[_I],dialect,use_meta_sql=use_original_sql)
	for statement_field in[_r,_s,_V]:
		if statement_field in defaults:kwargs[statement_field]=[exp.maybe_parse(stmt,dialect=dialect)for stmt in defaults[statement_field]]+kwargs.get(statement_field,[])
		if statement_field in kwargs:
			is_metadata=statement_field==_V
			for stmt in kwargs[statement_field]:expr=stmt.parse(dialect)if isinstance(stmt,ParsableSql)else stmt;statements.append((expr,is_metadata))
			kwargs[statement_field]=[stmt if isinstance(stmt,ParsableSql)else ParsableSql.from_parsed_expression(stmt,dialect,use_meta_sql=use_original_sql)for stmt in kwargs[statement_field]]
	for property_name in PROPERTIES:
		property_values=kwargs.get(property_name)
		if isinstance(property_values,exp.Tuple):statements.extend(property_values.expressions)
	if isinstance(getattr(kwargs.get(_D),_Q,_A),exp.Expression):statements.append(kwargs[_D].merge_filter)
	jinja_macro_references,referenced_variables=extract_macro_references_and_variables(*(gen(e if isinstance(e,exp.Expression)else e[0])for e in statements))
	if jinja_macros:jinja_macros=jinja_macros if jinja_macros.trimmed else jinja_macros.trim(jinja_macro_references)
	else:jinja_macros=JinjaMacroRegistry()
	for jinja_macro in jinja_macros.root_macros.values():referenced_variables.update(extract_macro_references_and_variables(jinja_macro.definition)[1])
	if(default_audits:=defaults.pop(_F,_A)):kwargs[_F]=default_audits+d.extract_function_calls(kwargs.pop(_F,[]))
	source_path=str(path.resolve().relative_to(module_path.resolve()))if path and module_path.parts else _A;model=klass(name=name,**{**(defaults or{}),_n:jinja_macros or JinjaMacroRegistry(),_M:dialect,_j:depends_on,'physical_schema_override':physical_schema_override,'source_path':source_path,**kwargs});audit_definitions={**(audit_definitions or{}),**(inline_audits or{})};used_audits:t.Set[str]={audit_name for(audit_name,_)in model.audits};audit_definitions={audit_name:audit_definitions[audit_name]for audit_name in used_audits if audit_name in audit_definitions};model.audit_definitions.update(audit_definitions);statements.extend((audit.query,_B)for audit in audit_definitions.values());from vulcan.core.audit.builtin import BUILT_IN_AUDITS;available_audits=BUILT_IN_AUDITS.keys()|model.audit_definitions.keys()
	for(referenced_audit,audit_args)in model.audits:
		if referenced_audit not in available_audits:raise_config_error(f"Audit '{referenced_audit}' is undefined",location=path)
		if'blocking'in audit_args:raise_config_error(f"Audit '{referenced_audit}' cannot override the 'blocking' parameter.",location=path)
		statements.extend((audit_arg_expression,_B)for audit_arg_expression in audit_args.values())
	signal_definitions=signal_definitions or UniqueKeyDict(_P)
	for(referenced_signal,kwargs)in model.signals:
		if referenced_signal and referenced_signal not in signal_definitions:raise_config_error(f"Signal '{referenced_signal}' is undefined",location=path)
		statements.extend((signal_kwarg,_B)for signal_kwarg in kwargs.values())
	python_env=make_python_env(statements,jinja_macro_references,module_path,macros or macro.get_registry(),variables=variables,referenced_variables=referenced_variables,path=path,python_env=python_env,strict_resolution=depends_on is _A,blueprint_variables=blueprint_variables,dialect=dialect);env:t.Dict[str,t.Tuple[t.Any,t.Optional[bool]]]={}
	for(signal_name,_)in model.signals:
		if signal_name and signal_name in signal_definitions:func=signal_definitions[signal_name].func;setattr(func,c.SQLMESH_METADATA,_B);build_env(func,env=env,name=signal_name,path=module_path)
	model.python_env.update(python_env);model.python_env.update(serialize_env(env,path=module_path));model._path=path;model.set_time_format(time_column_format);return t.cast(Model,model)
INSERT_SEED_MACRO_CALL=d.parse_one('@INSERT_SEED()')
def _split_sql_model_statements(expressions:t.List[exp.Expression],path:t.Optional[Path],dialect:t.Optional[str]=_A)->t.Tuple[t.Optional[exp.Expression],t.List[exp.Expression],t.List[exp.Expression],t.List[exp.Expression],UniqueKeyDict[str,ModelAudit]]:
	from vulcan.core.audit import ModelAudit,load_audit;query_positions=[];sql_statements=[];on_virtual_update=[];inline_audits:UniqueKeyDict[str,ModelAudit]=UniqueKeyDict('inline_audits');idx=0;length=len(expressions)
	while idx<length:
		expr=expressions[idx]
		if isinstance(expr,d.Audit):loaded_audit=load_audit([expr,expressions[idx+1]],dialect=dialect);assert isinstance(loaded_audit,ModelAudit);inline_audits[loaded_audit.name]=loaded_audit;idx+=2
		elif isinstance(expr,d.VirtualUpdateStatement):
			for statement in expr.expressions:on_virtual_update.append(statement)
			idx+=1
		else:
			if isinstance(expr,(exp.Query,d.JinjaQuery))or expr==INSERT_SEED_MACRO_CALL or isinstance(expr,d.MacroFunc)and(expr.this.name.lower()=='union'or length==1):query_positions.append((expr,idx))
			sql_statements.append(expr);idx+=1
	if not query_positions:return _A,sql_statements,[],on_virtual_update,inline_audits
	if len(query_positions)>1:raise_config_error('Only one SELECT query is allowed per model',path)
	query,pos=query_positions[0];return query,sql_statements[:pos],sql_statements[pos+1:],on_virtual_update,inline_audits
def _resolve_properties(default:t.Optional[t.Dict[str,t.Any]],provided:t.Optional[exp.Expression|t.Dict[str,t.Any]])->t.Optional[exp.Expression]:
	if isinstance(provided,dict):properties={k:exp.Literal.string(k).eq(v)for(k,v)in provided.items()}
	elif provided:
		if isinstance(provided,exp.Paren):provided=exp.Tuple(expressions=[provided.this])
		properties={expr.this.name:expr for expr in provided}
	else:properties={}
	for(k,v)in(default or{}).items():
		if k not in properties:properties[k]=exp.Literal.string(k).eq(v)
		elif properties[k].expression.sql().lower()in{_Z,_a}:del properties[k]
	if properties:return exp.Tuple(expressions=list(properties.values()))
def _list_of_calls_to_exp(value:t.List[t.Tuple[str,t.Dict[str,t.Any]]])->exp.Expression:return exp.Tuple(expressions=[exp.Anonymous(this=v[0],expressions=[exp.EQ(this=exp.convert(left),expression=exp.convert(right))for(left,right)in v[1].items()])for v in value])
def _is_projection(expr:exp.Expression)->bool:parent=expr.parent;return isinstance(parent,exp.Select)and expr.arg_key=='expressions'
def _single_expr_or_tuple(values:t.Sequence[exp.Expression])->exp.Expression|exp.Tuple:return values[0]if len(values)==1 else exp.Tuple(expressions=values)
def _refs_to_sql(values:t.Any)->exp.Expression:return exp.Tuple(expressions=values)
def render_meta_fields(fields:t.Dict[str,t.Any],module_path:Path,path:t.Optional[Path],jinja_macros:t.Optional[JinjaMacroRegistry],macros:t.Optional[MacroRegistry],dialect:DialectType,variables:t.Optional[t.Dict[str,t.Any]],default_catalog:t.Optional[str],blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A)->t.Dict[str,t.Any]:
	def render_field_value(value:t.Any)->t.Any:
		if isinstance(value,exp.Expression)or isinstance(value,str)and'@'in value:
			expression=exp.maybe_parse(value,dialect=dialect);rendered_expr=render_expression(expression=expression,module_path=module_path,macros=macros,jinja_macros=jinja_macros,variables=variables,path=path,dialect=dialect,default_catalog=default_catalog,blueprint_variables=blueprint_variables)
			if not rendered_expr:raise VulcanError(f"Rendering `{expression.sql(dialect=dialect)}` did not return an expression")
			if len(rendered_expr)!=1:raise VulcanError(f"Rendering `{expression.sql(dialect=dialect)}` must return one result, but got {len(rendered_expr)}")
			if rendered_expr[0].sql().lower()in{_Z,_a}:return
			return rendered_expr[0]
		return value
	for(field_name,field_info)in ModelMeta.all_field_infos().items():
		field=field_info.alias or field_name;field_value=fields.get(field)
		if field==_o and isinstance(field_value,str)and field_value.lower()in CRON_SHORTCUTS or field_value is _A:continue
		if field in RUNTIME_RENDERED_MODEL_FIELDS:fields[field]=parse_strings_with_macro_refs(field_value,dialect);continue
		if isinstance(field_value,dict):
			rendered_dict={}
			for(key,value)in field_value.items():
				if key in RUNTIME_RENDERED_MODEL_FIELDS:rendered_dict[key]=parse_strings_with_macro_refs(value,dialect)
				elif key==_v and isinstance(value,str)and value.lower()in CRON_SHORTCUTS:rendered_dict[key]=value
				elif(rendered:=render_field_value(value))is not _A:rendered_dict[key]=rendered
			if rendered_dict:fields[field]=rendered_dict
			else:fields.pop(field)
		elif isinstance(field_value,list):
			rendered_list=[rendered for value in field_value if(rendered:=render_field_value(value))is not _A]
			if rendered_list:fields[field]=rendered_list
			else:fields.pop(field)
		else:
			rendered_field=render_field_value(field_value)
			if rendered_field is not _A:fields[field]=rendered_field
			else:fields.pop(field)
	return fields
def render_model_defaults(defaults:t.Dict[str,t.Any],module_path:Path,path:t.Optional[Path],jinja_macros:t.Optional[JinjaMacroRegistry],macros:t.Optional[MacroRegistry],dialect:DialectType,variables:t.Optional[t.Dict[str,t.Any]],default_catalog:t.Optional[str])->t.Dict[str,t.Any]:
	rendered_defaults=render_meta_fields(fields=defaults,module_path=module_path,macros=macros,jinja_macros=jinja_macros,variables=variables,path=path,dialect=dialect,default_catalog=default_catalog)
	for boolean in{_q,_A6,_t}:
		var=rendered_defaults.get(boolean)
		if var is not _A and not isinstance(var,(exp.Boolean,bool)):raise ConfigError(f"Expected boolean for '{var}', got '{type(var)}' instead")
	var=rendered_defaults.get(_p)
	if isinstance(var,str):
		try:rendered_defaults[_p]=IntervalUnit(var)
		except ValueError as e:raise ConfigError(f"Invalid interval unit: {var}")from e
	return rendered_defaults
def parse_defaults_properties(defaults:t.Dict[str,t.Any],dialect:DialectType)->t.Dict[str,t.Any]:
	for prop in PROPERTIES:
		default_properties=defaults.get(prop)
		for(key,value)in(default_properties or{}).items():
			if isinstance(key,str)and d.SQLMESH_MACRO_PREFIX in str(value):defaults[prop][key]=exp.maybe_parse(value,dialect=dialect)
	return defaults
def render_expression(expression:exp.Expression,module_path:Path,path:t.Optional[Path],jinja_macros:t.Optional[JinjaMacroRegistry]=_A,macros:t.Optional[MacroRegistry]=_A,dialect:DialectType=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,default_catalog:t.Optional[str]=_A,blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A)->t.Optional[t.List[exp.Expression]]:meta_python_env=make_python_env(expressions=expression,jinja_macro_references=_A,module_path=module_path,macros=macros or macro.get_registry(),variables=variables,path=path,blueprint_variables=blueprint_variables);return ExpressionRenderer(expression,dialect,[],path=path,jinja_macro_registry=jinja_macros,python_env=meta_python_env,default_catalog=default_catalog,quote_identifiers=_C,normalize_identifiers=_C).render()
def meta_field_converter(meta_field:str,field_name:str)->t.Callable[[t.Any],exp.Expression]:
	for key in(meta_field,field_name):
		converter=META_FIELD_CONVERTER.get(key)
		if converter is not _A:return converter
	return exp.to_identifier
META_FIELD_CONVERTER:t.Dict[str,t.Callable]={'start':lambda value:exp.Literal.string(value),_o:lambda value:exp.Literal.string(value),'cron_tz':lambda value:exp.Literal.string(value),'partitioned_by_':_single_expr_or_tuple,_w:_single_expr_or_tuple,_y:lambda value:exp.Tuple(expressions=sorted(value)),'pre':_list_of_calls_to_exp,'post':_list_of_calls_to_exp,_F:_list_of_calls_to_exp,_A2:lambda value:exp.Schema(expressions=[exp.ColumnDef(this=exp.to_column(c),kind=t)for(c,t)in value.items()]),'column_descriptions_':lambda value:exp.Schema(expressions=[exp.to_column(c).eq(d)for(c,d)in value.items()]),'column_tags_':lambda value:exp.Schema(expressions=[exp.to_column(c).eq(exp.Tuple(expressions=[exp.Literal.string(t)for t in tags]))for(c,tags)in value.items()]),'column_terms_':lambda value:exp.Schema(expressions=[exp.to_column(c).eq(exp.Tuple(expressions=[exp.Literal.string(t)for t in terms]))for(c,terms)in value.items()]),'column_mask_expressions_':lambda value:exp.Schema(expressions=[exp.to_column(c).eq(exp.Literal.string(v)if isinstance(v,str)else exp.convert(v))for(c,v)in value.items()]),'column_classifications_':lambda value:exp.Schema(expressions=[exp.to_column(c).eq(exp.to_identifier(v))for(c,v)in value.items()]),_b:single_value_or_tuple,_c:single_value_or_tuple,'tags_':single_value_or_tuple,'terms_':single_value_or_tuple,_k:_refs_to_sql,'references':_refs_to_sql,'physical_properties_':lambda value:value,'virtual_properties_':lambda value:value,'session_properties_':lambda value:value,_A6:exp.convert,_P:lambda values:exp.tuple_(*(exp.func(name,*(exp.PropertyEQ(this=exp.var(k),expression=v)for(k,v)in args.items()))if name else exp.Tuple(expressions=[exp.var(k).eq(v)for(k,v)in args.items()])for(name,args)in values)),'formatting':str,_q:str,'virtual_environment_mode':lambda value:exp.Literal.string(value.value),'dbt_node_info_':lambda value:value.to_expression(),'grants_':lambda value:value,'grants_target_layer':lambda value:exp.Literal.string(value.value),'dq':lambda dq:dq.render_exp(),'policy':lambda policy:policy.render_exp()}
def get_model_name(path:Path)->str:
	root_idx=next((i for(i,part)in enumerate(path.parts)if part in c.MODEL_ROOT_DIRS),_A)
	if root_idx is _A:raise ValueError(f"Model path must be under '{c.MODELS}/' or '{c.ASSETS}/': {path}")
	path_parts=list(path.parts[root_idx+1:-1])+[path.stem];return'.'.join(path_parts[-3:])
def clickhouse_partition_func(column:exp.Expression,columns_to_types:t.Optional[t.Dict[str,exp.DataType]])->exp.Expression:
	B="DateTime64(9, 'UTC')";A='toMonday';col_type=columns_to_types and columns_to_types.get(column.name)or exp.DataType.build(_O);col_type_is_conformable=col_type.is_type(exp.DataType.Type.DATE,exp.DataType.Type.DATE32,exp.DataType.Type.DATETIME,exp.DataType.Type.DATETIME64)
	if col_type_is_conformable:return exp.func(A,column,dialect=_N)
	if col_type.is_type(exp.DataType.Type.UNKNOWN):return exp.func(A,exp.cast(column,exp.DataType.build(B,dialect=_N)),dialect=_N)
	return exp.cast(exp.func(A,exp.cast(column,exp.DataType.build(B,dialect=_N)),dialect=_N),col_type)
TIME_COL_PARTITION_FUNC={_N:clickhouse_partition_func}