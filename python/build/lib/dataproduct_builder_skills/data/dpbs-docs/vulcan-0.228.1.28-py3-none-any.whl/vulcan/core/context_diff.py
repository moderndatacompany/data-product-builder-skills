from __future__ import annotations
_C=None
_B='\n'
_A=False
import sys,typing as t
from enum import Enum
from difflib import ndiff,unified_diff
from functools import cached_property
from vulcan.core import constants as c
from vulcan.core.console import get_console
from vulcan.core.macros import RuntimeStage
from vulcan.core.model.common import sorted_python_env_payloads
from vulcan.core.snapshot import Snapshot,SnapshotId,SnapshotTableInfo
from vulcan.utils.errors import VulcanError
from vulcan.utils.pydantic import PydanticModel
if sys.version_info>=(3,12):from importlib import metadata
else:import importlib_metadata as metadata
if t.TYPE_CHECKING:from vulcan.core.state_sync import StateReader;from vulcan.core.node import SchemaDrift
from vulcan.utils.metaprogramming import Executable
from vulcan.core.environment import EnvironmentStatements
IGNORED_PACKAGES={'vulcan','sqlglot'}
class ContextDiff(PydanticModel):
	environment:str;is_new_environment:bool;is_unfinalized_environment:bool;normalize_environment_name:bool;previous_gateway_managed_virtual_layer:bool;gateway_managed_virtual_layer:bool;create_from:str;create_from_env_exists:bool;added:t.Set[SnapshotId];removed_snapshots:t.Dict[SnapshotId,SnapshotTableInfo];modified_snapshots:t.Dict[str,t.Tuple[Snapshot,Snapshot]];snapshots:t.Dict[SnapshotId,Snapshot];new_snapshots:t.Dict[SnapshotId,Snapshot];previous_plan_id:t.Optional[str];previously_promoted_snapshot_ids:t.Set[SnapshotId];previous_finalized_snapshots:t.Optional[t.List[SnapshotTableInfo]];previous_requirements:t.Dict[str,str]={};requirements:t.Dict[str,str]={};previous_environment_statements:t.List[EnvironmentStatements]=[];environment_statements:t.List[EnvironmentStatements];diff_rendered:bool=_A
	@classmethod
	def create(cls,environment:str,snapshots:t.Dict[str,Snapshot],create_from:str,state_reader:StateReader,ensure_finalized_snapshots:bool=_A,provided_requirements:t.Optional[t.Dict[str,str]]=_C,excluded_requirements:t.Optional[t.Set[str]]=_C,diff_rendered:bool=_A,environment_statements:t.Optional[t.List[EnvironmentStatements]]=[],gateway_managed_virtual_layer:bool=_A,infer_python_dependencies:bool=True,always_recreate_environment:bool=_A)->ContextDiff:
		environment=environment.lower();existing_env=state_reader.get_environment(environment);create_from_env_exists=_A;recreate_environment=always_recreate_environment and not environment==create_from
		if existing_env is _C or existing_env.expired or recreate_environment:
			env=state_reader.get_environment(create_from.lower())
			if not env and create_from!=c.PROD:get_console().log_warning(f"The environment name '{create_from}' was passed to the `plan` command's `--create-from` argument, but '{create_from}' does not exist. Initializing new environment '{environment}' from scratch.")
			is_new_environment=True;create_from_env_exists=env is not _C;previously_promoted_snapshot_ids=set()
		else:env=existing_env;is_new_environment=_A;previously_promoted_snapshot_ids={s.snapshot_id for s in env.promoted_snapshots}
		environment_snapshot_infos=[]
		if env:environment_snapshot_infos=env.snapshots if not ensure_finalized_snapshots else env.finalized_or_current_snapshots
		remote_snapshot_name_to_info={snapshot_info.name:snapshot_info for snapshot_info in environment_snapshot_infos};removed={snapshot_table_info.snapshot_id:snapshot_table_info for snapshot_table_info in environment_snapshot_infos if snapshot_table_info.name not in snapshots};added={snapshot.snapshot_id for snapshot in snapshots.values()if snapshot.name not in remote_snapshot_name_to_info};modified_snapshot_name_to_snapshot_info={snapshot.name:remote_snapshot_name_to_info[snapshot.name]for snapshot in snapshots.values()if snapshot.snapshot_id not in added and snapshot.fingerprint!=remote_snapshot_name_to_info[snapshot.name].fingerprint};stored=state_reader.get_snapshots([*snapshots.values(),*modified_snapshot_name_to_snapshot_info.values()]);merged_snapshots={};modified_snapshots={};new_snapshots={}
		for snapshot in snapshots.values():
			s_id=snapshot.snapshot_id;modified_snapshot_info=modified_snapshot_name_to_snapshot_info.get(snapshot.name);existing_snapshot=stored.get(s_id)
			if modified_snapshot_info and snapshot.node_type!=modified_snapshot_info.node_type:added.add(snapshot.snapshot_id);removed[modified_snapshot_info.snapshot_id]=modified_snapshot_info;modified_snapshot_name_to_snapshot_info.pop(snapshot.name)
			elif existing_snapshot:
				existing_snapshot.node=snapshot.node;merged_snapshots[s_id]=existing_snapshot.copy()
				if modified_snapshot_info:modified_snapshots[s_id.name]=existing_snapshot,stored[modified_snapshot_info.snapshot_id]
			else:
				snapshot=snapshot.copy();merged_snapshots[s_id]=snapshot;new_snapshots[snapshot.snapshot_id]=snapshot
				if modified_snapshot_info:snapshot.previous_versions=modified_snapshot_info.all_versions;modified_snapshots[s_id.name]=snapshot,stored[modified_snapshot_info.snapshot_id]
		requirements=_build_requirements(provided_requirements or{},excluded_requirements or set(),snapshots.values(),infer_python_dependencies=infer_python_dependencies);previous_environment_statements=state_reader.get_environment_statements(env.name)if env else[]
		if existing_env and always_recreate_environment:previous_plan_id:t.Optional[str]=existing_env.plan_id
		else:previous_plan_id=env.plan_id if env and not is_new_environment else _C
		return ContextDiff(environment=environment,is_new_environment=is_new_environment,is_unfinalized_environment=bool(env and not env.finalized_ts),normalize_environment_name=is_new_environment or bool(env and env.normalize_name),create_from=create_from,create_from_env_exists=create_from_env_exists,added=added,removed_snapshots=removed,modified_snapshots=modified_snapshots,snapshots=merged_snapshots,new_snapshots=new_snapshots,previous_plan_id=previous_plan_id,previously_promoted_snapshot_ids=previously_promoted_snapshot_ids,previous_finalized_snapshots=env.previous_finalized_snapshots if env else _C,previous_requirements=env.requirements if env else{},requirements=requirements,diff_rendered=diff_rendered,previous_environment_statements=previous_environment_statements,environment_statements=environment_statements,previous_gateway_managed_virtual_layer=env.gateway_managed if env else _A,gateway_managed_virtual_layer=gateway_managed_virtual_layer)
	@classmethod
	def create_no_diff(cls,environment:str,state_reader:StateReader)->ContextDiff:
		env=state_reader.get_environment(environment.lower())
		if not env:raise VulcanError(f"Environment '{environment}' must exist for this operation.")
		environment_statements=state_reader.get_environment_statements(environment);snapshots=state_reader.get_snapshots(env.snapshots);return ContextDiff(environment=env.name,is_new_environment=_A,is_unfinalized_environment=_A,normalize_environment_name=env.normalize_name,create_from='',create_from_env_exists=_A,added=set(),removed_snapshots={},modified_snapshots={},snapshots=snapshots,new_snapshots={},previous_plan_id=env.plan_id,previously_promoted_snapshot_ids={s.snapshot_id for s in env.promoted_snapshots},previous_finalized_snapshots=env.previous_finalized_snapshots,previous_requirements=env.requirements,requirements=env.requirements,previous_environment_statements=environment_statements,environment_statements=environment_statements,previous_gateway_managed_virtual_layer=env.gateway_managed,gateway_managed_virtual_layer=env.gateway_managed)
	@property
	def has_changes(self)->bool:return self.has_snapshot_changes or self.is_new_environment or self.is_unfinalized_environment or self.has_requirement_changes or self.has_environment_statements_changes or self.previous_gateway_managed_virtual_layer!=self.gateway_managed_virtual_layer
	@property
	def has_requirement_changes(self)->bool:return self.previous_requirements!=self.requirements
	@property
	def has_environment_statements_changes(self)->bool:return sorted(self.environment_statements,key=lambda s:s.project or'')!=sorted(self.previous_environment_statements,key=lambda s:s.project or'')
	@property
	def has_snapshot_changes(self)->bool:return bool(self.added or self.removed_snapshots or self.modified_snapshots)
	@property
	def added_materialized_snapshot_ids(self)->t.Set[SnapshotId]:return{s_id for s_id in self.added if self.snapshots[s_id].model_kind_name and self.snapshots[s_id].model_kind_name.is_materialized}
	@property
	def promotable_snapshot_ids(self)->t.Set[SnapshotId]:return{*self.previously_promoted_snapshot_ids,*self.added,*self.current_modified_snapshot_ids}-set(self.removed_snapshots)
	@property
	def unpromoted_models(self)->t.Set[SnapshotId]:return set(self.snapshots)-self.previously_promoted_snapshot_ids
	@property
	def current_modified_snapshot_ids(self)->t.Set[SnapshotId]:return{current.snapshot_id for(current,_)in self.modified_snapshots.values()}
	@cached_property
	def snapshots_by_name(self)->t.Dict[str,Snapshot]:return{x.name:x for x in self.snapshots.values()}
	def requirements_diff(self)->str:return'    '+'\n    '.join(ndiff([f"{k}=={self.previous_requirements[k]}"for k in sorted(self.previous_requirements)],[f"{k}=={self.requirements[k]}"for k in sorted(self.requirements)]))
	def environment_statements_diff_text(self,include_python_env:bool=_A)->str:return'\n\n'.join(_B.join(f"    {line}"if line.strip()else''for line in body.split(_B))for(_,chunk)in self.environment_statements_diff(include_python_env=include_python_env)if(body:=chunk.rstrip(_B)))
	def environment_statements_diff(self,include_python_env:bool=_A)->t.List[t.Tuple[str,str]]:
		A='python_env';_CONFIG_IDENTITY_KEYS='domain','discoverable','version','alignment','status'
		def extract_config_attrs(stmts:t.List[EnvironmentStatements],attribute:str)->t.Dict[str,str]:return{s.project or'(root)':('true'if v else'false')if isinstance((v:=getattr(s,attribute)),bool)else t.cast(str,v.value)if isinstance(v,Enum)else str(v)for s in sorted(stmts,key=lambda x:x.project or'')}
		def extract_statements(statements:t.List[EnvironmentStatements],attr:str)->t.List[str]:return[string for statement in statements for expr in(sorted_python_env_payloads(statement.python_env)if attr==A else getattr(statement,attr))for string in expr.split(_B)]
		def compute_diff(attribute:str)->t.Optional[t.Tuple[str,str]]:
			if attribute in _CONFIG_IDENTITY_KEYS:
				prev=extract_config_attrs(self.previous_environment_statements,attribute);curr=extract_config_attrs(self.environment_statements,attribute);labels=sorted(set(prev)|set(curr));multi_label=len(labels)>1;chunk=[f"{sign} {head}: {val}"for label in labels if(p:=prev.get(label))!=(c:=curr.get(label))for head in[f"{attribute} ({label})"if multi_label else attribute]for(sign,val)in(('-',p),('+',c))if val is not _C]
				if not chunk:return
				return'text',_B.join(chunk)+_B
			previous=extract_statements(self.previous_environment_statements,attribute);current=extract_statements(self.environment_statements,attribute)
			if previous==current:return
			diff_text=attribute if not attribute==A else'dependencies';diff_text+=':\n'
			if attribute==A:diff=list(unified_diff(previous,current));diff_text+=_B.join(diff[2:]if len(diff)>1 else diff);return'python',diff_text+_B
			diff_lines=list(ndiff(previous,current))
			if any(line.startswith(('-','+'))for line in diff_lines):diff_text+='  '+'\n  '.join(diff_lines)+_B;return'sql',diff_text
		return[diff for attribute in[RuntimeStage.BEFORE_ALL.value,RuntimeStage.AFTER_ALL.value,*_CONFIG_IDENTITY_KEYS,*([A]if include_python_env else[])]if(diff:=compute_diff(attribute))is not _C]
	@property
	def environment_snapshots(self)->t.List[SnapshotTableInfo]:return[*self.removed_snapshots.values(),*(old.table_info for(_,old)in self.modified_snapshots.values()),*[s.table_info for(s_id,s)in self.snapshots.items()if s_id not in self.added and s.name not in self.modified_snapshots]]
	def directly_modified(self,name:str)->bool:
		if name not in self.modified_snapshots:return _A
		current,previous=self.modified_snapshots[name];return current.is_directly_modified(previous)
	def indirectly_modified(self,name:str)->bool:
		if name not in self.modified_snapshots:return _A
		current,previous=self.modified_snapshots[name];return current.is_indirectly_modified(previous)
	def metadata_updated(self,name:str)->bool:
		if name not in self.modified_snapshots:return _A
		current,previous=self.modified_snapshots[name];return current.is_metadata_updated(previous)
	def text_diff(self,name:str)->str:
		if name not in self.snapshots_by_name:raise VulcanError(f"`{name}` does not exist.")
		if name not in self.modified_snapshots:return''
		new,old=self.modified_snapshots[name]
		try:return old.node.text_diff(new.node,rendered=self.diff_rendered)
		except VulcanError as e:get_console().log_warning(f"Failed to diff model '{name}': {str(e)}.");return''
	def schema_diff(self,name:str)->t.Optional['SchemaDrift']:
		from vulcan.core.node import SchemaDrift
		if name not in self.snapshots_by_name:raise VulcanError(f"`{name}` does not exist.")
		if name not in self.modified_snapshots:return
		new,old=self.modified_snapshots[name]
		try:return old.node.schema_diff(new.node)
		except VulcanError as e:get_console().log_warning(f"Failed to get schema diff for model '{name}': {str(e)}.");return
def _build_requirements(provided_requirements:t.Dict[str,str],excluded_requirements:t.Set[str],snapshots:t.Collection[Snapshot],infer_python_dependencies:bool=True)->t.Dict[str,str]:
	A='from ';requirements={k:v for(k,v)in provided_requirements.items()if k not in excluded_requirements}
	if not infer_python_dependencies:return requirements
	distributions=metadata.packages_distributions()
	for snapshot in snapshots:
		if not snapshot.is_model:continue
		for executable in snapshot.model.python_env.values():
			if executable.kind!='import':continue
			try:
				start=A if executable.payload.startswith(A)else'import ';lib=executable.payload.split(start)[1].split()[0].split('.')[0]
				if lib not in distributions:continue
				for dist in distributions[lib]:
					if dist not in requirements and dist not in IGNORED_PACKAGES and dist not in excluded_requirements:requirements[dist]=metadata.version(dist)
			except metadata.PackageNotFoundError:from vulcan.core.console import get_console;get_console().log_warning(f"Failed to find package for {lib}.")
	return requirements