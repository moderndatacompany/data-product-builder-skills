from __future__ import annotations
import logging,typing as t
from datetime import datetime
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.utils import raise_if_not_postgres
from vulcan.utils.date import to_timestamp
logger=logging.getLogger(__name__)
def expire_query_fingerprints_by_models(engine_adapter:EngineAdapter,fingerprints_table:exp.Table,model_names:t.Union[str,t.List[str]],run_id:str)->None:
	C='invalidated_by_run_id';B='_model';A='expires_ts';raise_if_not_postgres(engine_adapter,feature='expire_query_fingerprints_by_models')
	if isinstance(model_names,str):model_names=[model_names]
	if not model_names:return
	run_info=f" (run_id={run_id})"if run_id else'';logger.info(f"Expiring query fingerprint entries for {len(model_names)} model(s): {model_names}{run_info}");now_ts=to_timestamp(datetime.utcnow());where_clause=exp.and_(exp.Exists(this=exp.select(exp.Literal.number(1)).from_(exp.Unnest(expressions=[exp.column('depends_on')],alias=exp.TableAlias(this=exp.to_identifier(B)))).where(exp.column(B).isin(*[exp.Literal.string(m)for m in model_names]))),exp.or_(exp.column(A).is_(exp.null()),exp.column(A)>now_ts),exp.column(C).is_(exp.null()));update_props={A:now_ts,'invalidated_ts':now_ts,C:run_id};engine_adapter.execute(exp.update(fingerprints_table,update_props,where=where_clause));rowcount=getattr(engine_adapter.cursor,'rowcount',None)
	if rowcount is not None and rowcount>=0:logger.info(f"Expired {rowcount} query fingerprint entries {run_info}");return
	logger.info(f"Expired query fingerprint entries (row count not reported by {engine_adapter.dialect} driver){run_info}")