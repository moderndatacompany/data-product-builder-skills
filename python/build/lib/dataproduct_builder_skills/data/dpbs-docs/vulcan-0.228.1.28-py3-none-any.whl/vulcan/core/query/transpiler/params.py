from __future__ import annotations
import typing as t,sqlglot
from sqlglot import exp
from vulcan.core.engine_adapter._parameter_utils import normalize_query_params
from vulcan.utils.errors import VulcanError
_INLINE_PARAM_SCALAR_TYPES=str,int,float,bool,type(None)
def inline_query_params(sql:str,params:t.Optional[t.Sequence[t.Any]],*,dialect:str)->exp.Expression:
	if not params:return sqlglot.parse_one(sql,read=dialect)
	normalized_sql,named_params=normalize_query_params(sql,params,output_style='named')
	if not isinstance(named_params,dict):raise VulcanError(f"Transpiler SQL returned {len(params)} parameter value(s) but no recognized parameter markers were found in the SQL")
	for(name,value)in named_params.items():
		if not isinstance(value,_INLINE_PARAM_SCALAR_TYPES):raise VulcanError(f"Transpiler parameter {name!r} has non-scalar type {type(value).__name__!r}; only JSON scalar values can be inlined")
	query=sqlglot.parse_one(normalized_sql,read=dialect);placeholders=list(query.find_all(exp.Placeholder));placeholder_names={node.name for node in placeholders}
	if placeholder_names!=set(named_params):raise VulcanError(f"Transpiler SQL parameter mismatch: markers {sorted(placeholder_names)} != values {sorted(named_params)}")
	for node in placeholders:node.replace(exp.convert(named_params[node.name]))
	if next(query.find_all(exp.Placeholder,exp.Parameter),None)is not None:raise VulcanError('Transpiler SQL still contains parameter markers after inlining')
	return query