from __future__ import annotations
_B=False
_A='before'
import typing as t
from enum import Enum
import re
from vulcan.utils import classproperty
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import field_validator
ALL_CONFIG_FILENAMES='config.py','config.yml','config.yaml','vulcan.yml','vulcan.yaml'
YAML_CONFIG_FILENAMES=tuple(n for n in ALL_CONFIG_FILENAMES if not n.endswith('.py'))
USAGE_FILENAMES='usage.yml','usage.yaml'
DBT_PROJECT_FILENAME='dbt_project.yml'
class EnvironmentSuffixTarget(str,Enum):
	SCHEMA='schema';TABLE='table';CATALOG='catalog'
	@property
	def is_schema(self)->bool:return self==EnvironmentSuffixTarget.SCHEMA
	@property
	def is_table(self)->bool:return self==EnvironmentSuffixTarget.TABLE
	@property
	def is_catalog(self)->bool:return self==EnvironmentSuffixTarget.CATALOG
	@classproperty
	def default(cls)->EnvironmentSuffixTarget:return EnvironmentSuffixTarget.SCHEMA
	def __str__(self)->str:return self.name
	def __repr__(self)->str:return str(self)
class MetricJoinPath(str,Enum):
	CONNECTED='connected';DIRECTED='directed'
	@property
	def is_directed(self)->bool:return self is MetricJoinPath.DIRECTED
	@classproperty
	def default(cls)->MetricJoinPath:return cls.DIRECTED
	@classmethod
	def coerce(cls,value:t.Any)->MetricJoinPath:
		if isinstance(value,cls):return value
		if isinstance(value,str):
			normalized=value.strip().casefold()
			for member in cls:
				if member.value==normalized or member.name.casefold()==normalized:return member
			raise ValueError(f"Invalid metric join path {value!r}; expected 'connected' or 'directed'.")
		raise TypeError(f"metric join path must be 'connected' or 'directed', got {type(value).__name__}")
	def __str__(self)->str:return self.value
	def __repr__(self)->str:return str(self)
def _metric_join_path_validator(v:t.Any)->MetricJoinPath:
	if v is None:return MetricJoinPath.default()
	return MetricJoinPath.coerce(v)
metric_join_path_validator=field_validator('metric_join_path',mode=_A,check_fields=_B)(_metric_join_path_validator)
class VirtualEnvironmentMode(str,Enum):
	FULL='1';DEV_ONLY='0'
	@property
	def is_full(self)->bool:return self==VirtualEnvironmentMode.FULL
	@property
	def is_dev_only(self)->bool:return self==VirtualEnvironmentMode.DEV_ONLY
	@classproperty
	def default(cls)->VirtualEnvironmentMode:return VirtualEnvironmentMode.FULL
	def __str__(self)->str:return self.name
	def __repr__(self)->str:return str(self)
class DataProductAlignment(str,Enum):
	SOURCE_ALIGNED='source_aligned';CONSUMER_ALIGNED='consumer_aligned'
	@property
	def is_source_aligned(self)->bool:return self==DataProductAlignment.SOURCE_ALIGNED
	@property
	def is_consumer_aligned(self)->bool:return self==DataProductAlignment.CONSUMER_ALIGNED
	def __str__(self)->str:return self.name
	def __repr__(self)->str:return str(self)
class TableNamingConvention(str,Enum):
	SCHEMA_AND_TABLE='schema_and_table';TABLE_ONLY='table_only';HASH_MD5='hash_md5'
	@classproperty
	def default(cls)->TableNamingConvention:return TableNamingConvention.SCHEMA_AND_TABLE
	def __str__(self)->str:return self.name
	def __repr__(self)->str:return str(self)
def _concurrent_tasks_validator(v:t.Any)->int:
	if isinstance(v,str):v=int(v)
	if not isinstance(v,int)or v<=0:raise ConfigError(f"The number of concurrent tasks must be an integer value greater than 0. '{v}' was provided")
	return v
concurrent_tasks_validator=field_validator('backfill_concurrent_tasks','ddl_concurrent_tasks','concurrent_tasks',mode=_A,check_fields=_B)(_concurrent_tasks_validator)
def _http_headers_validator(v:t.Any)->t.Any:
	if isinstance(v,dict):return[(key,value)for(key,value)in v.items()]
	return v
http_headers_validator=field_validator('http_headers',mode=_A,check_fields=_B)(_http_headers_validator)
def _variables_validator(value:t.Dict[str,t.Any])->t.Dict[str,t.Any]:
	if not isinstance(value,dict):raise ConfigError(f"Variables must be a dictionary, not {type(value)}")
	def _validate_type(v:t.Any)->None:
		if isinstance(v,list):
			for item in v:_validate_type(item)
		elif isinstance(v,dict):
			for item in v.values():_validate_type(item)
		elif v is not None and not isinstance(v,(str,int,float,bool)):raise ConfigError(f"Unsupported variable value type: {type(v)}")
	_validate_type(value);return{k.lower():v for(k,v)in value.items()}
variables_validator=field_validator('variables',mode=_A,check_fields=_B)(_variables_validator)
def compile_regex_mapping(value:t.Dict[str|re.Pattern,t.Any])->t.Dict[re.Pattern,t.Any]:
	compiled_regexes={}
	for(k,v)in value.items():
		try:compiled_regexes[re.compile(k)]=v
		except re.error:raise ConfigError(f"`{k}` is not a valid regular expression.")
	return compiled_regexes