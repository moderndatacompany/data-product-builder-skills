from __future__ import annotations
_K='SEMANTIC'
_J='semantic'
_I='source_type'
_H='COUNT(DISTINCT {inner})'
_G='name'
_F='measure'
_E=', '
_D='count'
_C=False
_B=True
_A=None
import logging,typing as t,zoneinfo
from collections import defaultdict
from dataclasses import dataclass,field
from datetime import datetime
from functools import cached_property
from urllib.parse import urlparse
from sqlglot import exp,parse_one
from vulcan.core.audit.definition import Audit
from schema.types import IntervalUnit as _WireIntervalUnit
from schema.metadata import AuditEntry,ColumnDetails,ColumnEntry,ColumnKind,ColumnLineage,DependsOn,DimensionDetails,DqRuleEntry,GatewayInfo,Graph,GraphColumn,GraphEdge,GraphNode,JoinDetail,JoinEdge,LineageUpstream,MeasureDetails,Metadata,ModelDataQuality,ModelEntry,ModelKindValue,ModelSourceType,NominalRun,PhysicalDetails,ProductInfo,RollupDetails,SegmentDetails,UserEntry,Table,TableDetail
from schema.filters import PolicyEntry
from schema.types import ColumnClassificationValue
from vulcan.core import constants as c
from vulcan.core.context import Context
from vulcan.core.dialect import parse_semantic_member_refs,fqn_to_unquoted
from vulcan.core.environment import Environment,EnvironmentNamingInfo,EnvironmentStatements
from vulcan.core.model import MetricModel,Model,SemanticModel
from vulcan.core.model.definition import METRIC_COL_MEASURE,METRIC_COL_TS,_Model
from vulcan.core.model.policy import MaskExpression
from vulcan.core.model.semantic import DimensionSpec,MeasureSpec,SegmentSpec,parse_qualified_reference,sql_dtype_to_logical_type
from vulcan.core.snapshot import DeployabilityIndex,missing_intervals as snapshot_missing_intervals
from vulcan.core.snapshot.definition import Intervals,Snapshot,SnapshotId,SnapshotTableInfo
from vulcan.utils.date import TimeLike,now,to_datetime
from vulcan.utils.errors import ConfigError,VulcanError
from vulcan.utils.hashing import hash_data
from vulcan.utils.cron import CroniterCache
from vulcan.utils.join_graph import JoinGraph
logger=logging.getLogger(__name__)
_AUDIT_COLUMN_ARG_KEYS='columns','column'
_MEASURE_AGG_TEMPLATES:t.Dict[str,str]={'sum':'SUM({inner})','avg':'AVG({inner})','min':'MIN({inner})','max':'MAX({inner})',_D:'COUNT({inner})','count_distinct':_H,'count_distinct_approx':_H}
_MEASURE_BODY_EXPRESSION_DISCLAIMER='-- Catalog notation; not transpiler SQL.'
_LineageFlat=t.Tuple[str,str,str,t.Optional[str]]
_DependsOnEdges=t.Dict[t.Tuple[str,str],DependsOn]
_ResolveAlias=t.Callable[[str],t.Optional[str]]
@dataclass(frozen=_B)
class AuthoredColumnMeta:description:t.Optional[str];tags:t.List[str];terms:t.List[str];classification:t.Optional[ColumnClassificationValue]
@dataclass(frozen=_B)
class ResolvedColumn:kind:ColumnKind;depends_on:t.Tuple[DependsOn,...];details:t.Optional[ColumnDetails];public:bool=_B;primary_key:bool=_C;ai_context:t.Any=_A;behavior:t.Any=_A
@dataclass(frozen=_B)
class LinkedSemantic:
	name:str;semantic:SemanticModel;physical:Model;grain_names:frozenset[str];dimensions:t.Mapping[str,DimensionSpec];measures:t.Mapping[str,MeasureSpec];segments:t.Mapping[str,SegmentSpec]
	def mask_for(self,column_name:str)->t.Optional[MaskExpression]:
		masks=self.physical.column_mask_expressions;folded=column_name.casefold()
		for(col,expr)in masks.items():
			if col.casefold()==folded:return expr
@dataclass
class MetadataContext:
	_fqn_name:t.Dict[str,str];_by_fqn:t.Dict[str,Model];_name_fqn:t.Dict[str,str];allow_reciprocal_joins:bool=_B;env_naming_info:t.Optional[EnvironmentNamingInfo]=_A;deployability_index:t.Optional[DeployabilityIndex]=_A;connection_uri:str='';gateway:t.Optional[GatewayInfo]=_A;_linked_semantic_cache:t.Dict[str,LinkedSemantic]=field(init=_C,default_factory=dict,repr=_C)
	@property
	def gateway_dialect(self)->t.Optional[str]:return self.gateway.dialect if self.gateway else _A
	def export_dialect(self,model:t.Optional[_Model]=_A)->str:return _export_dialect(model,gateway_dialect=self.gateway_dialect)
	@cached_property
	def semantic_models(self)->t.Tuple[SemanticModel,...]:return tuple(m for m in self._by_fqn.values()if isinstance(m,SemanticModel))
	@cached_property
	def join_graph(self)->JoinGraph:return _join_graph_from_semantics(self.semantic_models,allow_reciprocal_joins=self.allow_reciprocal_joins)
	def linked_semantic(self,semantic_name:str)->LinkedSemantic:
		cached=self._linked_semantic_cache.get(semantic_name)
		if cached is not _A:return cached
		semantic=self.by_name(semantic_name)
		if semantic is _A:raise VulcanError(f"semantic model {semantic_name!r} not found in export scope")
		if isinstance(semantic,SemanticModel):resolved=semantic
		elif str(getattr(semantic,_I,'')).strip().lower()==_J:resolved=t.cast(SemanticModel,semantic)
		else:raise VulcanError(f"model {semantic_name!r} is not a semantic model")
		physical=_physical_for_semantic(self,resolved);grain_names=frozenset(name for grain in resolved.grains if(name:=_grain_column_name(grain))is not _A);linked=LinkedSemantic(name=semantic_name,semantic=resolved,physical=physical,grain_names=grain_names,dimensions={dimension.name:dimension for dimension in resolved.dimensions},measures={measure.name:measure for measure in resolved.measures},segments={segment.name:segment for segment in resolved.segments});self._linked_semantic_cache[semantic_name]=linked;return linked
	def by_name(self,name:str)->t.Optional[Model]:
		fqn=self._name_fqn.get(name)
		if not fqn:return
		return self._by_fqn.get(fqn)
	def by_fqn(self,fqn:str)->t.Optional[Model]:return self._by_fqn.get(fqn)
	def resolve_column_name(self,model:t.Optional[Model],column_name:str)->str:
		if model and(columns_to_types:=model.columns_to_types):
			if column_name in columns_to_types:return column_name
			folded=column_name.casefold();matches=[col for col in columns_to_types if col.casefold()==folded]
			if len(matches)==1:return matches[0]
		return column_name
	def export_model_for_alias(self,qualifier:str)->t.Optional[str]:
		model=self.by_name(qualifier)
		if model is _A:return
		return self._fqn_name.get(_semantic_anchor_fqn(model))
	def names_for_fqns(self,fqns:t.Collection[str])->t.List[str]:return[fqn_to_unquoted(self._fqn_name.get(fqn,fqn))for fqn in fqns]
	def _export_ref(self,col:exp.Column)->t.Optional[t.Tuple[str,str]]:
		alias=col.table if col.table else _A
		if not alias or not col.name:return
		export_model=self.export_model_for_alias(str(alias))
		if not export_model:return
		return export_model,col.name
	def _qualify_semantic_tree(self,expression:str,*,dialect:str)->t.Optional[exp.Expression]:
		if not expression or not expression.strip():return
		try:parsed=parse_one(expression.strip(),dialect=dialect);parsed=parsed.transform(_unwrap_struct_column,copy=_B);return parsed.transform(lambda node:_qualify_export_columns(node,resolve_alias=self.export_model_for_alias),copy=_B)
		except Exception as exc:logger.debug('Failed to qualify semantic expression %r: %s',expression,exc);return
	def _predicate_for_column(self,expression:str,export_model:str,column:str,*,dialect:str)->t.Optional[str]:
		parsed=self._qualify_semantic_tree(expression,dialect=dialect)
		if not parsed:return
		conjuncts=_and_conjuncts(parsed)
		if len(conjuncts)<=1:return parsed.sql(dialect=dialect)
		matched:t.List[exp.Expression]=[]
		for conjunct in conjuncts:
			refs={(str(c.table),c.name)for c in conjunct.find_all(exp.Column)if c.table and c.name}
			if(export_model,column)in refs:matched.append(conjunct)
		if not matched:return parsed.sql(dialect=dialect)
		if len(matched)==1:return matched[0].sql(dialect=dialect)
		return exp.and_(*matched).sql(dialect=dialect)
	def _measure_value_expression(self,measure:MeasureSpec,*,dialect:str,body_refs:t.Set[t.Tuple[str,str]])->t.Optional[str]:
		agg_type=str(measure.type);template=_MEASURE_AGG_TEMPLATES.get(agg_type)
		if template and len(body_refs)==1:ref_model,ref_col=next(iter(body_refs));return _annotate_measure_body_expression(template.format(inner=f"{ref_model}.{ref_col}"))
		if agg_type==_D and(not measure.expression or not measure.expression.strip()or measure.expression.strip()=='*')and not body_refs:return
		measure_tree=self._qualify_semantic_tree(measure.expression,dialect=dialect);qualified_inner=measure_tree.sql(dialect=dialect)if measure_tree else _A
		if not qualified_inner:return
		if not template:return qualified_inner
		return _annotate_measure_body_expression(template.format(inner=qualified_inner))
	def measure_depends_on(self,measure:MeasureSpec,*,dialect:str,physical_model:t.Optional[Model]=_A,owning_model:t.Optional[str]=_A)->t.List[DependsOn]:
		edges:_DependsOnEdges={};agg_type=str(measure.type);body_refs:t.Set[t.Tuple[str,str]]=set();expression=(measure.expression or'').strip();measure_ctx=f"measure '{owning_model}.{measure.name}'"if owning_model else f"measure {measure.name!r} expression"
		if expression and expression!='*':
			try:
				for parsed in parse_semantic_member_refs(measure.expression,dialect,owning_model=owning_model,context=measure_ctx):
					if(ref:=self._export_ref(parsed.col)):body_refs.add(ref)
			except ConfigError as exc:logger.debug('Failed to parse measure body for %s: %s',measure.name,exc)
		elif agg_type in _MEASURE_AGG_TEMPLATES and physical_model and(grain_col:=_single_grain_column(physical_model)):export_model=self._fqn_name.get(str(physical_model.fqn),physical_model.name);column=self.resolve_column_name(physical_model,grain_col);body_refs.add((export_model,column))
		if body_refs:
			value_expression=self._measure_value_expression(measure,dialect=dialect,body_refs=body_refs)
			for(export_model,column)in sorted(body_refs):edges[export_model,column]=DependsOn(model=export_model,column=column,expression=value_expression)
		for filter_expr in measure.filters or[]:
			if not filter_expr or not filter_expr.strip():continue
			filter_tree=self._qualify_semantic_tree(filter_expr,dialect=dialect);qualified_filter=filter_tree.sql(dialect=dialect)if filter_tree else _A
			if not qualified_filter:continue
			try:cols=parse_semantic_member_refs(filter_expr,dialect,owning_model=owning_model,into=exp.Condition,context=f"measure {measure.name!r} filter")
			except ConfigError as exc:logger.debug('Failed to parse measure filter for %s: %s',measure.name,exc);continue
			for parsed in cols:
				ref=self._export_ref(parsed.col)
				if not ref:continue
				export_model,column=ref
				if(export_model,column)in edges:continue
				edges[export_model,column]=DependsOn(model=export_model,column=column,expression=qualified_filter)
		return _sorted_depends_on_edges(edges)
	def segment_depends_on(self,segment:SegmentSpec,*,dialect:str,owning_model:t.Optional[str]=_A)->t.List[DependsOn]:
		if not segment.expression or not segment.expression.strip():return[]
		edges:_DependsOnEdges={}
		try:cols=parse_semantic_member_refs(segment.expression,dialect,owning_model=owning_model,into=exp.Condition,context=f"segment {segment.name!r} expression")
		except ConfigError as exc:logger.debug('Failed to parse segment expression for %s: %s',segment.name,exc);return[]
		for parsed in cols:
			ref=self._export_ref(parsed.col)
			if not ref:continue
			export_model,column=ref;edges[export_model,column]=DependsOn(model=export_model,column=column,expression=self._predicate_for_column(segment.expression,export_model,column,dialect=dialect))
		return _sorted_depends_on_edges(edges)
	def physical_depends_on(self,context:Context,snapshot:Snapshot,column_name:str)->t.List[DependsOn]:
		from vulcan.core import lineage as _lineage;dialect=self.export_dialect(snapshot.model)
		try:refs=_lineage.column_lineage_refs(context,snapshot,column_name)
		except Exception:logger.debug('Failed to compute physical lineage for %s.%s',snapshot.model.name,column_name,exc_info=_B);return[]
		edges:_DependsOnEdges={}
		for ref in refs:
			export_model=self._fqn_name.get(ref.model,fqn_to_unquoted(ref.model,dialect=dialect));export_column=self.resolve_column_name(self.by_fqn(ref.model),ref.column);key=export_model,export_column
			if key not in edges:edges[key]=DependsOn(model=export_model,column=export_column,expression=ref.expression)
		return _sorted_depends_on_edges(edges)
def _authored_column_meta(model:_Model,column_name:str)->AuthoredColumnMeta:col_tags=model.column_tags;col_terms=model.column_terms;tags=[str(x)for x in col_tags.get(column_name,[])or[]];terms=[str(x)for x in col_terms.get(column_name,[])or[]];descriptions=model.column_descriptions;classifications=model.column_classifications;return AuthoredColumnMeta(description=descriptions.get(column_name),tags=tags,terms=terms,classification=classifications.get(column_name))
def _dimension_export_details(spec:DimensionSpec,grain_names:t.Set[str],mask_expression:t.Any)->t.Tuple[DimensionDetails,bool,t.Any]:is_grain_dimension=spec.name in grain_names;return DimensionDetails(time_format=spec.format if spec.format else _A,time_granularities=spec.granularities or _A,mask_expression=mask_expression),bool(spec.public)and not is_grain_dimension,spec.behavior
def _assemble_column_entry(name:str,dtype:exp.DataType,authored:AuthoredColumnMeta,resolved:ResolvedColumn)->ColumnEntry:return ColumnEntry(name=name,kind=resolved.kind,ltype=sql_dtype_to_logical_type(dtype),dtype=dtype.sql()or str(dtype)or'',description=authored.description,tags=authored.tags,terms=authored.terms,classification=authored.classification,primary_key=resolved.primary_key,public=resolved.public,depends_on=list(resolved.depends_on),details=resolved.details,behavior=resolved.behavior,ai_context=resolved.ai_context)
def _depends_on_for_metric_ref(ref:str)->DependsOn:model,column=t.cast(t.Tuple[str,str],parse_qualified_reference(ref));return DependsOn(model=model,column=column)
def _resolve_dimension(linked:LinkedSemantic,name:str,spec:DimensionSpec,*,metric_ref:t.Optional[str]=_A,ai_context:t.Any=_A)->ResolvedColumn:
	details,public,behavior=_dimension_export_details(spec,set(linked.grain_names),linked.mask_for(name))
	if metric_ref is not _A:depends_on=_depends_on_for_metric_ref(metric_ref),;primary_key=_C;resolved_ai=ai_context if ai_context is not _A else spec.ai_context
	else:physical_name=linked.physical.name;depends_on=DependsOn(model=physical_name,column=name),;primary_key=name in linked.grain_names;resolved_ai=spec.ai_context
	return ResolvedColumn(kind='dimension',depends_on=depends_on,details=details,primary_key=primary_key,public=public,behavior=behavior,ai_context=resolved_ai)
def _resolve_measure(linked:LinkedSemantic,spec:MeasureSpec,*,mctx:t.Optional[MetadataContext]=_A,metric_ref:t.Optional[str]=_A)->ResolvedColumn:
	details=MeasureDetails(expression=spec.expression or _A,agg_type=spec.type,filters=list(spec.filters or[]),rolling_window=spec.rolling_window)
	if metric_ref is not _A:depends_on=_depends_on_for_metric_ref(metric_ref),
	else:assert mctx is not _A;dialect=mctx.export_dialect(linked.semantic);depends_on=tuple(mctx.measure_depends_on(spec,dialect=dialect,physical_model=linked.physical,owning_model=linked.name))
	return ResolvedColumn(kind=_F,depends_on=depends_on,details=details,public=spec.public,ai_context=spec.ai_context,behavior=spec.behavior)
def _resolve_segment(linked:LinkedSemantic,spec:SegmentSpec,*,mctx:t.Optional[MetadataContext]=_A,metric_ref:t.Optional[str]=_A)->ResolvedColumn:
	if metric_ref is not _A:depends_on=_depends_on_for_metric_ref(metric_ref),
	else:assert mctx is not _A;dialect=mctx.export_dialect(linked.semantic);depends_on=tuple(mctx.segment_depends_on(spec,dialect=dialect,owning_model=linked.name))
	return ResolvedColumn(kind='segment',depends_on=depends_on,details=SegmentDetails(expression=spec.expression or _A),public=spec.public,ai_context=spec.ai_context)
def _build_semantic_columns(linked:LinkedSemantic,mctx:MetadataContext)->t.List[ColumnEntry]:
	sem=linked.semantic;out:t.List[ColumnEntry]=[]
	for(name,dtype)in(sem.columns_to_types or{}).items():
		if(dimension:=linked.dimensions.get(name)):resolved=_resolve_dimension(linked,name,dimension)
		elif(measure:=linked.measures.get(name)):resolved=_resolve_measure(linked,measure,mctx=mctx)
		elif(segment:=linked.segments.get(name)):resolved=_resolve_segment(linked,segment,mctx=mctx)
		else:continue
		authored=_authored_column_meta(sem,name);out.append(_assemble_column_entry(name,dtype,authored,resolved))
	if not any(column.name==_D and column.kind==_F for column in out):out.append(ColumnEntry(name=_D,kind=_F,ltype='number',dtype='BIGINT',description='Count of rows',public=_B,depends_on=[],details=MeasureDetails(expression=_A,agg_type=_D,filters=[],rolling_window=_A)))
	return out
def _build_metric_columns(metric:MetricModel,mctx:MetadataContext)->t.List[ColumnEntry]:
	dimensions_by_column={dimension.name:dimension for dimension in metric.dimensions};segments_by_column={segment.name:segment for segment in metric.segments};out:t.List[ColumnEntry]=[]
	for(name,dtype)in(metric.columns_to_types or{}).items():
		if name==METRIC_COL_MEASURE:source_model,field_name=parse_qualified_reference(metric.measure);linked=mctx.linked_semantic(source_model);resolved=_resolve_measure(linked,linked.measures[field_name],metric_ref=metric.measure)
		elif name==METRIC_COL_TS:source_model,field_name=parse_qualified_reference(metric.ts);linked=mctx.linked_semantic(source_model);resolved=_resolve_dimension(linked,field_name,linked.dimensions[field_name],metric_ref=metric.ts)
		elif(metric_dim:=dimensions_by_column.get(name)):source_model,field_name=parse_qualified_reference(metric_dim.ref);linked=mctx.linked_semantic(source_model);resolved=_resolve_dimension(linked,field_name,linked.dimensions[field_name],metric_ref=metric_dim.ref,ai_context=metric_dim.ai_context)
		elif(metric_seg:=segments_by_column.get(name)):source_model,field_name=parse_qualified_reference(metric_seg.ref);linked=mctx.linked_semantic(source_model);resolved=_resolve_segment(linked,linked.segments[field_name],metric_ref=metric_seg.ref)
		else:continue
		authored=_authored_column_meta(metric,name);out.append(_assemble_column_entry(name,dtype,authored,resolved))
	return out
def _unwrap_struct_column(node:exp.Expression)->exp.Expression:
	if isinstance(node,exp.Struct):
		cols=list(node.find_all(exp.Column))
		if len(cols)==1:return cols[0]
	return node
def _qualify_export_columns(node:exp.Expression,*,resolve_alias:_ResolveAlias)->exp.Expression:
	if isinstance(node,exp.Column)and node.table and node.name:
		if(export_model:=resolve_alias(str(node.table))):return exp.column(node.name,table=export_model,quoted=_C)
	if isinstance(node,exp.Struct):
		cols=list(node.find_all(exp.Column))
		if len(cols)==1:return _qualify_export_columns(cols[0],resolve_alias=resolve_alias)
	return node
def _and_conjuncts(tree:exp.Expression)->t.List[exp.Expression]:
	if isinstance(tree,exp.And):return _and_conjuncts(tree.this)+_and_conjuncts(tree.expression)
	return[tree]
def _sorted_depends_on_edges(edges:_DependsOnEdges)->t.List[DependsOn]:return sorted(edges.values(),key=lambda dep:(dep.model,dep.column or''))
def _grain_column_name(grain:exp.Expression)->t.Optional[str]:
	node=grain.unnest()
	if isinstance(node,exp.Column):return str(node.name)
	if isinstance(node,exp.Identifier):return str(node.name)
def _physical_for_semantic(mctx:MetadataContext,semantic:SemanticModel)->Model:
	depends_on=semantic.depends_on
	if not depends_on:raise VulcanError(f"semantic model {semantic.name!r} has no physical depends_on")
	if len(depends_on)!=1:raise VulcanError(f"semantic model {semantic.name!r} must depend on exactly one physical model")
	anchor=next(iter(depends_on));physical=mctx.by_fqn(anchor)
	if physical is _A:raise VulcanError(f"semantic model {semantic.name!r} depends_on {anchor!r} not found in export scope")
	return physical
def _semantic_anchor_fqn(model:Model)->str:
	if isinstance(model,SemanticModel)and model.depends_on:return min(model.depends_on)
	return str(model.fqn)
def _single_grain_column(model:Model)->t.Optional[str]:
	grains=model.grains
	if len(grains)!=1:return
	return _grain_column_name(grains[0])
def _annotate_measure_body_expression(expression:str)->str:return f"{expression} {_MEASURE_BODY_EXPRESSION_DISCLAIMER}"
def _join_graph_from_semantics(semantics:t.Iterable[SemanticModel],*,allow_reciprocal_joins:bool)->JoinGraph:
	joinables=list(semantics);names={semantic.name for semantic in joinables};graph=JoinGraph(allow_reciprocal_edges=allow_reciprocal_joins)
	for semantic in joinables:graph.add(semantic.name)
	for semantic in joinables:
		for join in semantic.joins:
			if join.name in names:graph.add(semantic.name,join.name)
	return graph
def _export_dialect(model:t.Optional[_Model],*,gateway_dialect:t.Optional[str])->str:
	if model is not _A:
		model_dialect=model.dialect
		if isinstance(model_dialect,str)and model_dialect:return model_dialect
		if model_dialect:
			name=getattr(model_dialect,_G,_A)
			if name:return str(name)
	if gateway_dialect:return gateway_dialect
	raise VulcanError('Cannot resolve SQL dialect for metadata export: model dialect is unset and gateway dialect is unavailable.')
def _model_source_path(node:_Model)->t.Optional[str]:return node.source_path
def _model_reference_expressions(model:_Model)->t.List[str]:
	references=model.references
	if not references:return[]
	dialect=model.dialect;expressions:t.List[str]=[]
	for expr in references:
		if isinstance(expr,exp.Tuple):expressions.append(_E.join(key.sql(dialect=dialect)for key in expr.expressions))
		else:expressions.append(expr.sql(dialect=dialect))
	return sorted(expressions,key=str)
def _model_entry_shared_fields(node:_Model,*,mctx:MetadataContext,kind:ModelKindValue,source_type:ModelSourceType,dialect:t.Optional[str]=_A,evaluatable:bool=_C,table:t.Optional[Table]=_A)->t.Dict[str,t.Any]:return{_G:node.name,'fqn':node.fqn,'path':_model_source_path(node),'kind':kind,_I:source_type,'table':table,'description':node.description or _A,'tags':[str(tag)for tag in node.tags],'terms':[str(term)for term in node.terms],'owner':node.owner or _A,'dialect':dialect or node.dialect,'cron':str(node.cron),'cron_tz':node.cron_tz.key if node.cron_tz else _A,'evaluatable':evaluatable,'interval_unit':_WireIntervalUnit(node.interval_unit.value)if node.interval_unit else _A,'depends_on':mctx.names_for_fqns(node.depends_on)}
def _build_table(snapshot:Snapshot,model:t.Optional[Model],mctx:MetadataContext)->t.Optional[Table]:
	dialect=mctx.export_dialect(model);uri=mctx.connection_uri or''
	try:
		is_deployable=mctx.deployability_index.is_deployable(snapshot.snapshot_id)if mctx.deployability_index else _B;table=snapshot.table_name(is_deployable=is_deployable);table=fqn_to_unquoted(table,dialect=dialect);physical=TableDetail(connection_uri=uri,name=table)
		if mctx.env_naming_info is _A:return Table(physical=physical,virtual=_A)
		view=snapshot.qualified_view_name.for_environment(mctx.env_naming_info,dialect=dialect);view=fqn_to_unquoted(view,dialect=dialect);virtual=_A if table==view else TableDetail(connection_uri=uri,name=view);return Table(physical=physical,virtual=virtual)
	except Exception as e:logger.warning('Could not build table for snapshot %s: %s',snapshot.name,e);raise
def _build_physical_columns(context:Context,snapshot:Snapshot,model:Model,mctx:MetadataContext,*,is_external:bool,grain_names:t.Set[str])->t.List[ColumnEntry]:
	column_masks=model.column_mask_expressions;columns:t.List[ColumnEntry]=[]
	for(name,dtype)in(model.columns_to_types or{}).items():authored=_authored_column_meta(model,name);columns.append(ColumnEntry(name=fqn_to_unquoted(name)if is_external else name,kind='physical',ltype=sql_dtype_to_logical_type(dtype),dtype=dtype.sql()or str(dtype)or'',primary_key=name in grain_names,description=authored.description,tags=authored.tags,terms=authored.terms,classification=authored.classification,depends_on=mctx.physical_depends_on(context,snapshot,name),details=PhysicalDetails(mask_expression=column_masks[name])if name in column_masks else _A))
	return columns
def _audit_column_names(audit_args:t.Optional[t.Dict[str,t.Any]])->t.Optional[t.List[str]]:
	if not audit_args:return
	columns_expr=next((audit_args[key]for key in _AUDIT_COLUMN_ARG_KEYS if key in audit_args),_A)
	if columns_expr is _A:return
	while isinstance(columns_expr,exp.Paren):columns_expr=columns_expr.this
	names:t.List[str]=[]
	if isinstance(columns_expr,exp.Tuple):names=[c.name for c in columns_expr.expressions if isinstance(c,exp.Column)]
	elif isinstance(columns_expr,exp.Column):names=[columns_expr.name]
	elif isinstance(columns_expr,exp.Array):names=[lit.this for lit in columns_expr.expressions if isinstance(lit,exp.Literal)]
	else:return
	return names or _A
def _audit_entry_for(audit:Audit,audit_args:t.Dict[str,t.Any])->AuditEntry:return AuditEntry(name=audit.name,description=audit.description,dimension=audit.dimension,columns=_audit_column_names(audit_args),args={k:v.sql()if hasattr(v,'sql')else str(v)for(k,v)in(audit_args or{}).items()})
def _directed_metric_join_map(metric:MetricModel,join_graph:JoinGraph)->t.Dict[str,str]:
	parsed_measure=parse_qualified_reference(metric.measure)
	if not parsed_measure:raise ValueError(f"metric {metric.name!r} has an invalid measure reference.")
	anchor,_=parsed_measure;join_map:t.Dict[str,str]={};seen_targets:t.Set[str]=set()
	for ref in(metric.measure,metric.ts,*[dimension.ref for dimension in metric.dimensions],*[segment.ref for segment in metric.segments]):
		parsed=parse_qualified_reference(ref)
		if not parsed:continue
		cube_name=parsed[0]
		if cube_name==anchor or cube_name in seen_targets:continue
		seen_targets.add(cube_name);join_path=join_graph.directed_join_path(anchor,cube_name)
		if join_path is _A:raise ValueError(f"metric {metric.name!r}: no directed join path from {anchor!r} to {cube_name!r}.")
		join_map[cube_name]=join_path
	return join_map
def _model_entry_for_metric(context:Context,snapshot:Snapshot,mctx:MetadataContext)->ModelEntry:metric=t.cast(MetricModel,snapshot.node);dialect=mctx.export_dialect(metric);effective_join_path=metric.join_path if metric.join_path is not _A else context.config.metric_join_path;join_map=_directed_metric_join_map(metric,mctx.join_graph)if effective_join_path.is_directed else{};return ModelEntry(**_model_entry_shared_fields(metric,mctx=mctx,kind='METRIC',source_type='metric',dialect=dialect),columns=_build_metric_columns(metric,mctx),default_granularity=metric.granularity,metric_join_path=effective_join_path.value,join_map=join_map,ai_context=metric.ai_context)
def _model_entry_for_semantic(snapshot:Snapshot,mctx:MetadataContext)->ModelEntry:semantic=t.cast(SemanticModel,snapshot.node);linked=mctx.linked_semantic(semantic.name);grains=sorted(linked.grain_names);physical_policy=linked.physical.policy;return ModelEntry(**_model_entry_shared_fields(semantic,mctx=mctx,kind=_K,source_type=_J),grains=grains,references=_model_reference_expressions(semantic),joins=[JoinDetail(model=join.name,relationship=join.type,expression=join.expression,on=join.on,skip_for_bi=join.skip_for_bi,ai_context=join.ai_context)for join in semantic.joins],columns=_build_semantic_columns(linked,mctx),ai_context=semantic.ai_context,policies=[PolicyEntry.model_validate(rule.model_dump(mode='json'))for rule in physical_policy.rules]if physical_policy else[],rollups=[RollupDetails(name=rollup.name,measures=list(rollup.measures),dimensions=list(rollup.dimensions),segments=list(rollup.segments),time_dimension=rollup.time_dimension,granularity=rollup.granularity,rollups=list(rollup.rollups)if rollup.rollups is not _A else _A,description=rollup.description or _A)for rollup in sorted(semantic.rollups,key=lambda spec:spec.name)])
def _model_entry_for_physical(context:Context,snapshot:Snapshot,mctx:MetadataContext)->ModelEntry:
	model=snapshot.model;table=_build_table(snapshot,model,mctx);is_external=str(model.source_type).strip().lower()=='external';grains=sorted(name for grain in model.grains if(name:=_grain_column_name(grain))is not _A);grain_names=set(grains);columns=_build_physical_columns(context,snapshot,model,mctx,is_external=is_external,grain_names=grain_names);attached_audit_names={name for(name,_)in model.audits or[]};audits=[_audit_entry_for(audit,audit_args)for(audit,audit_args)in model.audits_with_args if audit.name in attached_audit_names];shared=_model_entry_shared_fields(model,mctx=mctx,kind=t.cast(ModelKindValue,str(model.kind.name)),source_type=t.cast(ModelSourceType,str(model.source_type).strip().lower()),evaluatable=snapshot.evaluatable,table=table)
	if is_external:shared[_G]=fqn_to_unquoted(model.name)
	return ModelEntry(**shared,display_name=_A,columns=columns,grains=grains,references=_model_reference_expressions(model),dq=ModelDataQuality(filter=model_dq.filter,profiles=list(model_dq.profiles),rules=[DqRuleEntry(name=rule.name,expression=rule.expression,dimension=rule.dimension,description=rule.description,extra=dict(rule.extra))for rule in model_dq.rules])if(model_dq:=model.dq)is not _A else _A,audits=audits,partitioned_by=_A if not model.partitioned_by else _E.join(expr.sql(pretty=_B,dialect=model.dialect)for expr in model.partitioned_by),clustered_by=_A if not model.clustered_by else _E.join(col.sql(dialect=model.dialect)for col in model.clustered_by),table_format=model.table_format,storage_format=model.storage_format,batch_size=model.batch_size,lookback=model.lookback if model.lookback>0 else _A,policies=[PolicyEntry.model_validate(rule.model_dump(mode='json'))for rule in model.policy.rules]if model.policy else[])
def _build_model_entry(context:Context,snapshot:Snapshot,mctx:MetadataContext)->ModelEntry:
	node=snapshot.node
	if isinstance(node,MetricModel):return _model_entry_for_metric(context,snapshot,mctx)
	if isinstance(node,SemanticModel):return _model_entry_for_semantic(snapshot,mctx)
	return _model_entry_for_physical(context,snapshot,mctx)
def _graph_collect_model_edges(models:t.List[ModelEntry],names:t.Set[str])->tuple[t.List[GraphEdge],dict[str,t.List[str]],dict[str,t.List[str]]]:
	edges:t.List[GraphEdge]=[];parents:t.Dict[str,t.List[str]]=defaultdict(list);children:t.Dict[str,t.List[str]]=defaultdict(list);seen_edges:t.Set[t.Tuple[str,str]]=set()
	def add_edge(from_n:str,to_n:str)->_A:
		key=from_n,to_n
		if key in seen_edges:return
		seen_edges.add(key);edges.append(GraphEdge(to=to_n,from_=from_n));parents[to_n].append(from_n);children[from_n].append(to_n)
	for entry in sorted(models,key=lambda m:m.name):
		dependant=entry.name
		if dependant not in names:continue
		for dep in entry.depends_on:
			if dep not in names:continue
			add_edge(dep,dependant)
	edges.sort(key=lambda e:(e.from_,e.to));normalized_parents={name:sorted(set(parent_list))for(name,parent_list)in parents.items()};normalized_children={name:sorted(set(child_list))for(name,child_list)in children.items()};return edges,normalized_parents,normalized_children
def _graph_flatten_lineage(entry:ModelEntry,names:t.Set[str])->t.List[_LineageFlat]:
	out:t.List[_LineageFlat]=[]
	for col in entry.columns:
		for ref in col.depends_on:
			pred=ref.model
			if pred not in names:continue
			out.append((pred,col.name,ref.column or'',ref.expression))
	return out
def _graph_merge_lineage(entries:t.List[_LineageFlat])->t.List[ColumnLineage]:
	by_pred:t.Dict[t.Tuple[str,str],t.List[t.Tuple[str,t.Optional[str]]]]=defaultdict(list)
	for(pred_node,target_col,source_col,expression)in entries:by_pred[target_col,pred_node].append((source_col,expression))
	grouped:t.Dict[str,t.List[LineageUpstream]]=defaultdict(list)
	for((target_col,pred_node),pairs)in by_pred.items():
		col_exprs:t.Dict[str,t.Optional[str]]={}
		for(source_col,expr)in pairs:
			if source_col not in col_exprs:col_exprs[source_col]=expr
			elif not col_exprs[source_col]and expr:col_exprs[source_col]=expr
		grouped[target_col].append(LineageUpstream(node=pred_node,columns=list(col_exprs.keys()),expressions={source_col:expr for(source_col,expr)in col_exprs.items()if expr}))
	lineage:t.List[ColumnLineage]=[]
	for target_col in sorted(grouped.keys()):contributors=grouped[target_col];lineage.append(ColumnLineage(to=target_col,from_=sorted(contributors,key=lambda x:x.node)))
	return lineage
def _build_graph(models:t.List[ModelEntry])->Graph:
	names={m.name for m in models};edges,parent_map,child_map=_graph_collect_model_edges(models,names);relationships:t.List[JoinEdge]=[]
	for m in sorted(models,key=lambda x:x.name):
		if m.kind!=_K:continue
		for j in m.joins:
			if j.model not in names:continue
			relationships.append(JoinEdge(to=j.model,type_=j.relationship,from_=m.name,skip_for_bi=j.skip_for_bi))
	relationships.sort(key=lambda r:(r.from_,r.to));nodes=[GraphNode(name=m.name,kind=m.kind,source_type=m.source_type,columns=[GraphColumn(name=col.name,ltype=col.ltype,kind=col.kind)for col in m.columns],parents=sorted(parent_map.get(m.name,[])),children=sorted(child_map.get(m.name,[])),column_lineage=_graph_merge_lineage(_graph_flatten_lineage(m,names)))for m in sorted(models,key=lambda x:x.name)];parents={k:sorted([p for p in v if p in names])for(k,v)in parent_map.items()if k in names};children={k:sorted([p for p in v if p in names])for(k,v)in child_map.items()if k in names};return Graph(nodes=nodes,edges=edges,relationships=relationships,parent_map=dict(sorted(parents.items())),child_map=dict(sorted(children.items())))
def _environment_snapshot_set_fingerprint(snapshots_info:t.Sequence[SnapshotTableInfo])->str:
	fingerprint_parts:t.List[str]=[]
	for s in sorted(snapshots_info,key=lambda x:x.name):fingerprint_parts.append(s.name);fingerprint_parts.append(s.identifier)
	return'crc32:'+hash_data(fingerprint_parts)
def _build_product_info(context:Context,*,env_name:str,stmts:t.Optional[t.List[EnvironmentStatements]]=_A)->ProductInfo:
	if stmts is _A:stmts=context.state_sync.get_environment_statements(env_name)
	stmt:t.Optional[EnvironmentStatements]=_A
	if stmts:
		if len(stmts)==1:stmt=stmts[0]
		else:
			want_project=context.config.project or _A
			for candidate in sorted(stmts,key=lambda x:x.project or''):
				if(candidate.project or _A)==want_project:stmt=candidate;break
			if stmt is _A:stmt=sorted(stmts,key=lambda x:x.project or'')[0]
	discoverable=stmt.discoverable if stmt else c.DEFAULT_DISCOVERABLE;version=stmt.version if stmt else c.DEFAULT_VERSION;alignment=str(stmt.alignment.value)if stmt else c.DEFAULT_ALIGNMENT;domain=stmt.domain if stmt else _A;status=stmt.status if stmt else'Draft';config=context.config;users=[UserEntry(username=u.username,type=u.type)for u in context.users];product=ProductInfo(display_name=config.display_name,description=config.description,tags=list(config.tags),terms=list(config.terms),users=users,domain=domain,discoverable=discoverable,version=version,alignment=alignment,usage=config.usage,issue_tracker=config.issue_tracker,compliance=config.compliance,support=list(config.support),sla=dict(config.sla),license=config.license,data_holder=config.data_holder,status=status,repository=context.git_client.project_folder_url());return product
def _build_gateway_metadata(context:Context)->t.Tuple[GatewayInfo,t.Optional[t.List[GatewayInfo]]]:
	default_name=context.config.default_gateway_name;default_key=default_name.lower();gateways_cfg=context.config.gateways;gateway_names=sorted(gateways_cfg.keys())if isinstance(gateways_cfg,dict)else[default_key];all_gateways:t.List[GatewayInfo]=[]
	for name in gateway_names:
		connection=context.config.get_connection(name)
		if connection is _A:continue
		connection_uri=connection.get_connection_uri();host=getattr(connection,'host',_A);port=getattr(connection,'port',_A);database=getattr(connection,'database',_A);account=getattr(connection,'account',_A)
		if connection_uri:
			parsed=urlparse(connection_uri)
			if parsed.scheme=='duckdb':
				if parsed.netloc:database=database or parsed.netloc
			else:
				host=host or parsed.hostname
				if port is _A:port=parsed.port
				path=parsed.path.lstrip('/')
				if path:database=database or path
		all_gateways.append(GatewayInfo(name=name,connection_type=connection.type_,dialect=connection.DIALECT,connection_uri=connection_uri,host=host,port=port,database=database,account=account))
	default=next((gateway for gateway in all_gateways if gateway.name==default_key),_A)
	if default is _A:raise VulcanError(f"Cannot export default gateway '{default_name}': not found in configured gateways")
	others=[gateway for gateway in all_gateways if gateway.name!=default_key];return default,others or _A
def nominal_runs_by_model(models:t.Iterable[ModelEntry],*,as_of:datetime,missing_intervals:t.Mapping[str,t.Sequence[t.Tuple[str,str]]])->t.Dict[str,NominalRun]:
	runs:t.Dict[str,NominalRun]={}
	for entry in models:
		if not entry.evaluatable:continue
		tz=zoneinfo.ZoneInfo(entry.cron_tz)if entry.cron_tz else _A;prev=CroniterCache(entry.cron,time=as_of,tz=tz).get_prev();nxt=CroniterCache(entry.cron,time=as_of,tz=tz).get_next();runs[entry.name]=NominalRun(prev=prev,next=nxt,is_pending=bool(missing_intervals.get(entry.name)))
	return runs
def missing_intervals_by_model(snapshots:t.Iterable[Snapshot],*,env_name:str,execution_time:t.Optional[TimeLike]=_A)->t.Dict[str,t.List[t.Tuple[str,str]]]:
	from vulcan.utils.date import now;snapshot_list=list(snapshots);deployability_index=_A if env_name==c.PROD else DeployabilityIndex.create({s.snapshot_id:s for s in snapshot_list});by_snapshot=snapshot_missing_intervals(snapshot_list,execution_time=execution_time or now(),deployability_index=deployability_index);result:t.Dict[str,t.List[t.Tuple[str,str]]]={}
	for(snapshot,intervals)in by_snapshot.items():
		if not snapshot.is_model:continue
		model_name=snapshot.model.name;result[model_name]=[(to_datetime(start).isoformat(),to_datetime(end).isoformat())for(start,end)in intervals]
	return result
def build_metadata(context:Context,*,environment:t.Optional[str]=_A,env:t.Optional[Environment]=_A,stmts:t.Optional[t.List[EnvironmentStatements]]=_A,snapshots:t.Optional[t.Dict[SnapshotId,Snapshot]]=_A)->Metadata:
	execution_time=now();env_name=env.name if env is not _A else Environment.sanitize_name(environment or context.config.default_target_environment)
	if env is _A:env=context.state_sync.get_environment(env_name)
	if not env:available=[e.name for e in context.state_sync.get_environments()];raise VulcanError(f"Environment '{env_name}' was not found. Available: {_E.join(available)if available else'none'}")
	snapshots_info=env.finalized_or_current_snapshots
	if snapshots is _A:snapshots=context.state_sync.get_snapshots(snapshots_info)
	fingerprint=_environment_snapshot_set_fingerprint(snapshots_info);env_naming_info=env.naming_info;deployability_index=DeployabilityIndex.create(snapshots)if env.name!=c.PROD else _A;product=_build_product_info(context,env_name=env_name,stmts=stmts);gateway,gateways=_build_gateway_metadata(context);connection_uri=''
	try:
		conn=context.config.get_connection()
		if hasattr(conn,'get_connection_uri'):connection_uri=conn.get_connection_uri()
	except Exception:pass
	fqn_name={s.model.fqn:s.model.name for s in snapshots.values()if s.is_model};by_fqn={s.model.fqn:s.model for s in snapshots.values()if s.is_model};name_fqn={name:fqn for(fqn,name)in fqn_name.items()};mctx=MetadataContext(_fqn_name=fqn_name,_by_fqn=by_fqn,_name_fqn=name_fqn,allow_reciprocal_joins=context.config.allow_reciprocal_joins,env_naming_info=env_naming_info,deployability_index=deployability_index,connection_uri=connection_uri,gateway=gateway);has_reciprocal_joins=context.config.allow_reciprocal_joins and bool(mctx.join_graph.reciprocal_pairs());models=[_build_model_entry(context=context,snapshot=s,mctx=mctx)for s in sorted(snapshots.values(),key=lambda snap:snap.name)if s.is_model];tenant=context.config.tenant if context.config.tenant is not _A else'';graph=_build_graph(models);as_of=to_datetime(execution_time);missing_intervals=missing_intervals_by_model(snapshots.values(),env_name=env_name,execution_time=execution_time);nominal_runs=nominal_runs_by_model(models,as_of=as_of,missing_intervals=missing_intervals);return Metadata(tenant=tenant,name=context.config.project,discoverable=product.discoverable,version=product.version,alignment=product.alignment,fingerprint=fingerprint,product=product,gateway=gateway,gateways=gateways,models=models,graph=graph,env=env_name,has_reciprocal_joins=has_reciprocal_joins,as_of=as_of,missing_intervals=missing_intervals,nominal_runs=nominal_runs)