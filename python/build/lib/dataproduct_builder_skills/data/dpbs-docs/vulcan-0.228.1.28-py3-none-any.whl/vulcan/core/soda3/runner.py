from __future__ import annotations
_X='columnProfiles'
_W='get_cloud_dict'
_V='table_to_model_name'
_U='profiles'
_T='ModelExec'
_S='_checks'
_R='unknown'
_Q='Model'
_P='filter'
_O='table'
_N='value'
_M='name'
_L=False
_K=True
_J='not_evaluated_checks'
_I='warned_checks'
_H='failed_checks'
_G='not_evaluated'
_F='warned'
_E='failed'
_D='passed'
_C='Context'
_B='dimensions'
_A=None
import json,logging,re,types,typing as t
from datetime import date,datetime
import vulcan.core.soda3,yaml
from soda.common.log import Log,LogLevel
from soda.execution.check.check import CheckOutcome
from soda.scan import Scan
from vulcan.core import constants as c
from vulcan.core.soda3 import _NAME_ATTR_KEY,_DIMENSION_ATTR_KEY
from vulcan.core.soda3.cloud import SodaStateSyncBackend,SodaStateSyncSampler
from vulcan.core.soda3.spec import CheckExecutionSummary,DataQualitySpec,ProfileExecutionSummary,SchemaProfileResult,SchemaStats,_table_alias,build_sodacl_yaml,validate_dq_dimension
from vulcan.utils.date import TimeLike,date_dict,make_inclusive,now_timestamp,to_datetime
from vulcan.utils import JobType,JobTypeValues
from vulcan.utils.errors import ConfigError
if t.TYPE_CHECKING:from vulcan.core.activity import ModelExec;from vulcan.core.context import Context;from vulcan.core.model import Model
logger=logging.getLogger(__name__)
_LOG_LEVEL_TO_PY={LogLevel.ERROR:logging.ERROR,LogLevel.WARNING:logging.WARNING,LogLevel.INFO:logging.INFO,LogLevel.DEBUG:logging.DEBUG}
def _sanitize_soda_name(s:str)->str:s=s.lower();return re.sub('[^a-z0-9_]','_',s)
def _soda_str(value:t.Any)->str:
	if isinstance(value,datetime):return value.isoformat(sep=' ',timespec='seconds')
	if isinstance(value,date):return value.isoformat()
	if isinstance(value,(list,dict,tuple)):
		try:return json.dumps(value,default=str,ensure_ascii=_L)
		except(TypeError,ValueError):return str(value)
	if isinstance(value,set):
		try:return json.dumps(sorted(value,key=str),default=str,ensure_ascii=_L)
		except(TypeError,ValueError):return str(value)
	return str(value)
def _create_soda_data_source_config(context:_C,gateway_name:str,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:gateway_config=context.config.get_gateway(gateway_name);connection=gateway_config.connection;return connection.soda_conn_config(catalog=catalog,schema=schema)
def _build_soda_variables(context:_C,gateway_name:str,environment:str,*,execution_time:t.Optional[TimeLike]=_A,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A)->t.Dict[str,str]:A='gateway';dialect=context.config.get_connection(gateway_name).DIALECT;gateway_config=context.config.get_gateway(gateway_name);start_time,end_time=make_inclusive(start or c.EPOCH,end or c.EPOCH,dialect=dialect)if start is not _A or end is not _A else(_A,_A);dd=date_dict(to_datetime(execution_time or now_timestamp()),start_time,end_time);gw=gateway_config.variables or{};cfg=context.config.variables or{};merged:t.Dict[str,t.Any]={**dd,**gw,A:gateway_name,**{k:v for(k,v)in cfg.items()if k not in{*dd,*gw,A}}};result={key:_soda_str(val)for(key,val)in merged.items()};logger.debug('Soda scan variables (gateway=%r, environment=%r)\n%s\n',gateway_name,environment,yaml.dump({'variables':result},default_flow_style=_L,allow_unicode=_K,sort_keys=_K).rstrip());return result
def _extract_check_details(check_dict:t.Dict[str,t.Any])->t.Dict[str,t.Any]:D='query';C='definition';B='column';A='type';diagnostics=check_dict.get('diagnostics',{});return{_M:check_dict.get(_NAME_ATTR_KEY,'unnamed'),A:check_dict.get(A,_R),B:check_dict.get(B),C:check_dict.get(C),'outcome_reasons':check_dict.get('outcomeReasons',[]),_N:diagnostics.get(_N),D:diagnostics.get(D)}
def _build_execution_summary(scan:Scan,model_name_to_filter_exp:t.Dict[str,t.Optional[str]],table_to_model_name:t.Optional[t.Dict[str,str]]=_A)->CheckExecutionSummary:
	results_by_model:t.Dict[str,t.Dict[str,t.Any]]={};table_to_model_name=table_to_model_name or{};checks=getattr(scan,_S,[])
	for check in checks:
		check_dict=check.get_dict();resource_attrs=check_dict.get('resourceAttributes',[]);attributes={attr[_M]:attr[_N]for attr in resource_attrs if isinstance(attr,dict)};raw_table=check_dict.get(_O);model_name=table_to_model_name.get(raw_table)or raw_table or _R;dimension=validate_dq_dimension(attributes.get(_DIMENSION_ATTR_KEY));outcome=check.outcome
		if model_name not in results_by_model:filter_expr=model_name_to_filter_exp.get(model_name,_A);results_by_model[model_name]={_P:filter_expr,_B:{}}
		if dimension not in results_by_model[model_name][_B]:results_by_model[model_name][_B][dimension]={_D:0,_E:0,_F:0,_G:0,_H:[],_I:[],_J:[]}
		dimension_stats=results_by_model[model_name][_B][dimension]
		if outcome==CheckOutcome.PASS:dimension_stats[_D]+=1
		elif outcome==CheckOutcome.FAIL:dimension_stats[_E]+=1;dimension_stats[_H].append(_extract_check_details(check_dict))
		elif outcome==CheckOutcome.WARN:dimension_stats[_F]+=1;dimension_stats[_I].append(_extract_check_details(check_dict))
		elif outcome is _A:dimension_stats[_G]+=1;dimension_stats[_J].append(_extract_check_details(check_dict))
	return CheckExecutionSummary(results=results_by_model)
def _merge_check_summaries(summaries:t.Optional[t.List[CheckExecutionSummary]])->t.Optional[CheckExecutionSummary]:
	if not summaries:return
	if len(summaries)==1:return summaries[0]
	merged_results:t.Dict[str,t.Dict[str,t.Any]]={}
	for summary in summaries:
		for(model_name,model_data)in summary.results.items():
			merged_model=merged_results.setdefault(model_name,{_P:model_data.get(_P),_B:{}});merged_dims=merged_model[_B]
			for(dim,stats)in model_data.get(_B,{}).items():
				if dim not in merged_dims:merged_dims[dim]={_D:0,_E:0,_F:0,_G:0,_H:[],_I:[],_J:[]}
				target=merged_dims[dim];target[_D]+=stats.get(_D,0);target[_E]+=stats.get(_E,0);target[_F]+=stats.get(_F,0);target[_G]+=stats.get(_G,0);target[_H].extend(stats.get(_H,[]));target[_I].extend(stats.get(_I,[]));target[_J].extend(stats.get(_J,[]))
	return CheckExecutionSummary(results=merged_results)
def _models_by_fqn_from_environment_snapshots(context:_C,environment:str,model_execs:t.Sequence[_T])->t.Dict[str,_Q]:
	if not model_execs:return{}
	exec_fqns={me.fqn for me in model_execs};env=context.state_sync.get_environment(environment)
	if not env:logger.debug('[soda3] Environment %r not found in state_sync; skipping snapshot model index',environment);return{}
	by_fqn:t.Dict[str,_Q]={}
	for snapshot in context.state_sync.get_snapshots(env.snapshots).values():
		if not snapshot.is_model:continue
		if snapshot.name not in exec_fqns:continue
		by_fqn[snapshot.name]=snapshot.model
	return by_fqn
def _collect_batch_results(scan:Scan,schema_prefix:str,schema_profile_results:t.List[SchemaProfileResult],prefix_stats:t.Dict[str,SchemaStats],table_to_model_name:t.Optional[t.Dict[str,str]]=_A)->_A:
	if not hasattr(scan,'_profile_columns_result_tables'):return
	schema_profiles=scan._profile_columns_result_tables;schema_profile_results.append({'prefix':schema_prefix,_U:schema_profiles,_V:table_to_model_name or{}});prefix_tables=set();total_columns=0
	for profile_table in schema_profiles:
		if hasattr(profile_table,_W):
			profile_dict=profile_table.get_cloud_dict();table=profile_dict.get(_O);column_profiles=profile_dict.get(_X,[])
			if table_to_model_name:table=table_to_model_name.get(table,table)
			if table:prefix_tables.add(table)
			total_columns+=len(column_profiles)
	prefix_stats[schema_prefix]=SchemaStats(tables=len(prefix_tables),columns=total_columns);logger.info(f"✅ Batch complete: {total_columns} columns in {len(prefix_tables)} tables")
def _build_profile_execution_summary(schema_profile_results:t.List[SchemaProfileResult],prefix_stats:t.Dict[str,SchemaStats],run_id:str,environment:str)->ProfileExecutionSummary:
	model_profiles:t.Dict[str,t.List[str]]={}
	for schema_result in schema_profile_results:
		profile_tables=schema_result[_U];table_to_model_name=schema_result.get(_V)or{}
		for profile_table in profile_tables:
			if hasattr(profile_table,_W):profile_dict=profile_table.get_cloud_dict()
			else:continue
			raw_table=profile_dict.get(_O);column_profiles=profile_dict.get(_X,[])
			if raw_table and column_profiles:
				model_key=table_to_model_name.get(raw_table,raw_table)
				if model_key not in model_profiles:model_profiles[model_key]=[]
				for col_profile in column_profiles:
					col_name=col_profile.get('columnName')
					if col_name:model_profiles[model_key].append(col_name)
	return ProfileExecutionSummary(run_id=run_id,environment=environment,model_profiles=model_profiles,prefix_stats=prefix_stats)
def _patch_soda_scan_logs(scan:Scan,*,label:str)->_A:
	logs=scan._logs
	def wrapped(_logs_self:t.Any,level:LogLevel,message:str,location:t.Any,doc:t.Any,exception:BaseException|_A)->_A:
		A='[%s] %s';py_level=_LOG_LEVEL_TO_PY.get(level,logging.INFO);logger.log(py_level,A,label,message)
		if exception is not _A:logger.log(py_level,A,label,exception)
		entry=Log(level=level,message=message,location=location,doc=doc,exception=exception);_logs_self.logs.append(entry)
	logs.log=types.MethodType(wrapped,logs)
def validate_dq_spec_sodacl_parses(spec:DataQualitySpec,model_name:str)->_A:
	path=spec._path;path_label=str(path)if path is not _A else'(unknown dq file path)';sodacl_yaml=build_sodacl_yaml(spec,model_name);scan=Scan();_patch_soda_scan_logs(scan,label=model_name);scan_def_safe=_sanitize_soda_name(model_name);data_source_name=f"soda3_load_validation_{scan_def_safe}";scan.set_scan_definition_name(data_source_name);scan.set_data_source_name(data_source_name)
	try:scan.add_sodacl_yaml_str(sodacl_yaml)
	except Exception as e:raise ConfigError(f"Invalid kind: dq file {path_label}: SodaCL validation failed: {e}")from e
	if not scan.has_error_logs():return
	messages=_sodacl_error_messages(scan);detail='; '.join(messages)if messages else'SodaCL validation failed. See https://docs.soda.io/sodacl-reference/';raise ConfigError(f"Invalid kind: dq file {path_label}: {detail}")
def _sodacl_error_messages(scan:Scan)->t.List[str]:
	B='ERROR';A='message';getter=getattr(scan,'get_error_logs',_A)
	if callable(getter):return[getattr(log,A,str(log))for log in getter()]
	out:t.List[str]=[];logs=getattr(scan,'_logs',_A);log_list=getattr(logs,'logs',_A)if logs is not _A else _A
	if not log_list:return out
	for log in log_list:
		level=getattr(log,'level',_A);is_error=str(level)==B or getattr(level,_M,_A)==B
		if is_error:out.append(getattr(log,A,str(log)))
	return out
def _print_scan_outcome(scan:Scan,*,label:str)->_A:
	A='outcome'
	if scan.has_error_logs():
		for log in scan.get_error_logs():logger.warning('[soda3:%s] %s',label,log.message)
	checks=getattr(scan,_S,[]);passed=sum(1 for c in checks if getattr(c,A,_A)==CheckOutcome.PASS);failed=sum(1 for c in checks if getattr(c,A,_A)==CheckOutcome.FAIL);logger.info('[soda3:%s] checks=%s pass=%s fail=%s',label,len(checks),passed,failed)
def run_data_quality_scan(context:_C,model:_Q,*,run_id:str='',job_type:JobTypeValues='RUN',environment:str,execution_time:t.Optional[TimeLike]=_A,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A)->t.Optional[t.Tuple[CheckExecutionSummary,Scan,str,t.Dict[str,str]]]:
	spec=getattr(model,'dq',_A)
	if spec is _A:return
	gateway_name=context.config.default_gateway_name
	if not gateway_name:raise ConfigError('No default gateway configured; cannot run soda3 DQ.')
	combined_sodacl=build_sodacl_yaml(spec,model.name);logger.debug('[soda3: runner] %s <<- DQ <<- \n%s',model.name,combined_sodacl);table_expr=model.fully_qualified_table;catalog,schema=table_expr.catalog,table_expr.db;schema_prefix=f"{catalog}.{schema}";alias=_table_alias(model.name);table_to_model_name={alias:str(model.name),str(model.name):str(model.name)};schema_prefix_safe=schema_prefix.replace('.','_').lower();project_name=(context.config.project or'vulcan').replace('-','_');data_source_name=_sanitize_soda_name(f"soda3_{project_name}_{environment}_{schema_prefix_safe}");scan=Scan();_patch_soda_scan_logs(scan,label=model.name);scan.set_scan_definition_name(data_source_name);scan.set_data_source_name(data_source_name);soda_data_source_config=_create_soda_data_source_config(context=context,gateway_name=gateway_name,catalog=catalog,schema=schema);is_spark_programmatic=soda_data_source_config.get('__soda_programmatic__')=='spark_df'
	if is_spark_programmatic:
		spark_session=context.spark
		if catalog:spark_session.catalog.setCurrentCatalog(catalog)
		if schema:spark_session.catalog.setCurrentDatabase(schema)
		scan.add_spark_session(spark_session,data_source_name=data_source_name)
	else:data_source_yaml=yaml.dump({f"data_source {data_source_name}":soda_data_source_config});scan.add_configuration_yaml_str(data_source_yaml)
	scan.add_sodacl_yaml_str(combined_sodacl);soda_variables=_build_soda_variables(context=context,gateway_name=gateway_name,environment=environment,execution_time=execution_time,start=start,end=end)
	if soda_variables:scan.add_variables(soda_variables)
	backend=SodaStateSyncBackend(state_sync=context.state_sync,environment=environment,run_id=run_id or _A,table_to_model_name=table_to_model_name,dialect=context.engine_adapter.dialect,job_type=JobType(job_type));scan._configuration.soda_cloud=backend;scan._configuration.sampler=SodaStateSyncSampler(backend=backend);scan.set_verbose(_K);scan.execute();_print_scan_outcome(scan,label=model.name);filter_val=spec.filter.strip()if spec.filter else _A;check_summary=_build_execution_summary(scan,{str(model.name):filter_val},table_to_model_name);return check_summary,scan,schema_prefix,table_to_model_name
def run_soda3_for_successful_models(context:_C,successful_model_execs:t.Sequence[_T],*,run_id:str,job_type:JobTypeValues,environment:str,execution_time:t.Optional[TimeLike]=_A,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A)->t.Tuple[t.Optional[CheckExecutionSummary],t.Optional[ProfileExecutionSummary]]:
	check_summaries:t.List[CheckExecutionSummary]=[];schema_profile_results:t.List[SchemaProfileResult]=[];prefix_stats:t.Dict[str,t.Any]={};models_by_fqn=_models_by_fqn_from_environment_snapshots(context,environment,successful_model_execs)
	for me in successful_model_execs:
		m=models_by_fqn.get(me.fqn)
		if m is _A:logger.debug('[soda3] Skipping DQ for %s (%s): model not in context or environment snapshots',me.name,me.fqn);continue
		try:
			out=run_data_quality_scan(context,m,run_id=run_id,job_type=job_type,environment=environment,execution_time=execution_time,start=start,end=end)
			if out is _A:continue
			check_summary,scan,schema_prefix,table_to_model_map=out;check_summaries.append(check_summary);_collect_batch_results(scan,schema_prefix,schema_profile_results,prefix_stats,table_to_model_map)
		except Exception as e:logger.error('[soda3] DQ failed for model %s: %s',me.name,e,exc_info=_K)
	merged_check=_merge_check_summaries(check_summaries)if check_summaries else _A;merged_profile=_build_profile_execution_summary(schema_profile_results,prefix_stats,run_id,environment)if schema_profile_results else _A;return merged_check,merged_profile