from __future__ import annotations
_F='terms'
_E='tags'
_D='before'
_C=True
_B=False
_A=None
import typing as t,zoneinfo
from datetime import datetime
from enum import Enum
from functools import cached_property
from pathlib import Path
from pydantic import Field
from sqlglot import exp
from vulcan.utils.cron import CroniterCache,interval_seconds
from vulcan.utils.date import TimeLike,to_datetime,validate_date_range
from vulcan.utils.errors import ConfigError,raise_config_error
from vulcan.utils.pydantic import PydanticModel,SQLGlotCron,field_validator,model_validator,PRIVATE_FIELDS
from vulcan.core.types import Tag,Term
from vulcan.utils.hashtag import parse_hashtag_markers
if t.TYPE_CHECKING:from vulcan.core._typing import Self;from vulcan.core.snapshot import Node
class IntervalUnit(str,Enum):
	YEAR='year';MONTH='month';DAY='day';HOUR='hour';HALF_HOUR='half_hour';QUARTER_HOUR='quarter_hour';FIVE_MINUTE='five_minute'
	@classmethod
	def from_cron(klass,cron:str)->IntervalUnit:
		croniter=CroniterCache(cron);interval_seconds=croniter.interval_seconds
		if not interval_seconds:samples=[croniter.get_next()for _ in range(5)];interval_seconds=int(min(b-a for(a,b)in zip(samples,samples[1:])).total_seconds())
		for(unit,seconds)in INTERVAL_SECONDS.items():
			if seconds<=interval_seconds:return unit
		raise ConfigError(f"Invalid cron '{cron}': must run at a frequency of 5 minutes or slower.")
	@property
	def is_date_granularity(self)->bool:return self in(IntervalUnit.YEAR,IntervalUnit.MONTH,IntervalUnit.DAY)
	@property
	def is_year(self)->bool:return self==IntervalUnit.YEAR
	@property
	def is_month(self)->bool:return self==IntervalUnit.MONTH
	@property
	def is_day(self)->bool:return self==IntervalUnit.DAY
	@property
	def is_hour(self)->bool:return self==IntervalUnit.HOUR
	@property
	def is_minute(self)->bool:return self in(IntervalUnit.FIVE_MINUTE,IntervalUnit.QUARTER_HOUR,IntervalUnit.HALF_HOUR)
	@property
	def cron_expr(self)->str:
		if self==IntervalUnit.FIVE_MINUTE:return'*/5 * * * *'
		if self==IntervalUnit.QUARTER_HOUR:return'*/15 * * * *'
		if self==IntervalUnit.HALF_HOUR:return'*/30 * * * *'
		if self==IntervalUnit.HOUR:return'0 * * * *'
		if self==IntervalUnit.DAY:return'0 0 * * *'
		if self==IntervalUnit.MONTH:return'0 0 1 * *'
		if self==IntervalUnit.YEAR:return'0 0 1 1 *'
		return''
	def croniter(self,value:TimeLike)->CroniterCache:return CroniterCache(self.cron_expr,value)
	def cron_next(self,value:TimeLike,estimate:bool=_B)->datetime:return self.croniter(value).get_next(estimate=estimate)
	def cron_prev(self,value:TimeLike,estimate:bool=_B)->datetime:return self.croniter(value).get_prev(estimate=estimate)
	def cron_floor(self,value:TimeLike,estimate:bool=_B)->datetime:croniter=self.croniter(value);croniter.get_next(estimate=estimate);return croniter.get_prev(estimate=_C)
	@property
	def seconds(self)->int:return INTERVAL_SECONDS[self]
	@property
	def milliseconds(self)->int:return self.seconds*1000
class DbtNodeInfo(PydanticModel):
	unique_id:str;name:str;fqn:str;alias:t.Optional[str]=_A
	@model_validator(mode='after')
	def post_init(self)->Self:
		if self.alias==self.name:self.alias=_A
		return self
	def to_expression(self)->exp.Expression:return exp.tuple_(*(exp.PropertyEQ(this=exp.var(k),expression=exp.Literal.string(v))for(k,v)in sorted(self.model_dump(exclude_none=_C).items())))
class DbtInfoMixin:
	@property
	def dbt_node_info(self)->t.Optional[DbtNodeInfo]:raise NotImplementedError
	@property
	def dbt_unique_id(self)->t.Optional[str]:
		if self.dbt_node_info:return self.dbt_node_info.unique_id
	@property
	def dbt_fqn(self)->t.Optional[str]:
		if self.dbt_node_info:return self.dbt_node_info.fqn
INTERVAL_SECONDS={IntervalUnit.YEAR:31536000,IntervalUnit.MONTH:2419200,IntervalUnit.DAY:86400,IntervalUnit.HOUR:3600,IntervalUnit.HALF_HOUR:1800,IntervalUnit.QUARTER_HOUR:900,IntervalUnit.FIVE_MINUTE:300}
class _Node(DbtInfoMixin,PydanticModel):
	name:str;project:str='';description:t.Optional[str]=_A;owner:t.Optional[str]=_A;start:t.Optional[TimeLike]=_A;end:t.Optional[TimeLike]=_A;cron:SQLGlotCron='@daily';cron_tz:t.Optional[zoneinfo.ZoneInfo]=_A;interval_unit_:t.Optional[IntervalUnit]=Field(alias='interval_unit',default=_A);tags_:t.Optional[t.List[Tag]]=Field(default=_A,alias=_E);terms_:t.Optional[t.List[Term]]=Field(default=_A,alias=_F);stamp:t.Optional[str]=_A;dbt_node_info_:t.Optional[DbtNodeInfo]=Field(alias='dbt_node_info',default=_A);source_path:t.Optional[str]=_A;_path:t.Optional[Path]=_A;_data_hash:t.Optional[str]=_A;_metadata_hash:t.Optional[str]=_A;_croniter:t.Optional[CroniterCache]=_A;__inferred_interval_unit:t.Optional[IntervalUnit]=_A
	def _explicit_list_field(self,*,field:str,legacy_field:str)->t.Optional[t.List[t.Any]]:
		data=self.__dict__
		if field in data:return data[field]
		legacy=data.get(legacy_field)
		if legacy:return legacy
	def __str__(self)->str:path=f": {self._path.name}"if self._path else'';return f"{self.__class__.__name__}<{self.name}{path}>"
	@cached_property
	def tags(self)->t.List[Tag]:
		explicit=self._explicit_list_field(field='tags_',legacy_field=_E)
		if explicit is not _A:return explicit
		tags,_=parse_hashtag_markers(self.description);return tags
	@cached_property
	def terms(self)->t.List[Term]:
		explicit=self._explicit_list_field(field='terms_',legacy_field=_F)
		if explicit is not _A:return explicit
		_,terms=parse_hashtag_markers(self.description);return terms
	def __getstate__(self)->t.Dict[t.Any,t.Any]:A='__dict__';state=super().__getstate__();state[A]=state[A].copy();state[A].pop(_E,_A);state[A].pop(_F,_A);private=state[PRIVATE_FIELDS];private['_data_hash']=_A;private['_metadata_hash']=_A;return state
	def copy(self,**kwargs:t.Any)->Self:node=super().copy(**kwargs);node.__dict__.pop(_E,_A);node.__dict__.pop(_F,_A);node._data_hash=_A;node._metadata_hash=_A;return node
	@field_validator('name',mode=_D)
	@classmethod
	def _name_validator(cls,v:t.Any)->t.Optional[str]:
		if v is _A:return
		if isinstance(v,exp.Expression):return v.meta['sql']
		return str(v)
	@field_validator('cron_tz',mode=_D)
	def _cron_tz_validator(cls,v:t.Any)->t.Optional[zoneinfo.ZoneInfo]:
		if not v or v=='UTC':return
		v=str_or_exp_to_str(v)
		try:return zoneinfo.ZoneInfo(v)
		except Exception as e:
			available_timezones=zoneinfo.available_timezones()
			if available_timezones:raise ConfigError(f"{e}. {v} must be in {available_timezones}.")
			else:raise ConfigError(f"{e}. IANA time zone data is not available on your system. `pip install tzdata` to leverage cron time zones or remove this field which will default to UTC.")
	@field_validator('start','end',mode=_D)
	@classmethod
	def _date_validator(cls,v:t.Any)->t.Optional[TimeLike]:
		if isinstance(v,exp.Expression):v=v.name
		if v and not to_datetime(v):raise ConfigError(f"'{v}' needs to be time-like: https://pypi.org/project/dateparser")
		return v
	@field_validator('owner','description','stamp',mode=_D)
	@classmethod
	def _string_expr_validator(cls,v:t.Any)->t.Optional[str]:return str_or_exp_to_str(v)
	@field_validator('interval_unit_',mode=_D)
	@classmethod
	def _interval_unit_validator(cls,v:t.Any)->t.Optional[t.Union[IntervalUnit,str]]:
		if isinstance(v,IntervalUnit):return v
		v=str_or_exp_to_str(v)
		if v:v=v.lower()
		return v
	@model_validator(mode='after')
	def _node_root_validator(self)->Self:
		interval_unit=self.interval_unit_
		if interval_unit and not getattr(self,'allow_partials',_A):
			cron=self.cron;max_interval_unit=IntervalUnit.from_cron(cron)
			if interval_unit.seconds>max_interval_unit.seconds:raise ConfigError(f"Cron '{cron}' cannot be more frequent than interval unit '{interval_unit.value}'. If this is intentional, set allow_partials to True.")
		start=self.start;end=self.end
		if end is not _A and start is _A:raise ConfigError('Must define a start date if an end date is defined.')
		validate_date_range(start,end);return self
	@property
	def batch_size(self)->t.Optional[int]:0
	@property
	def batch_concurrency(self)->t.Optional[int]:0
	@property
	def interval_unit(self)->IntervalUnit:
		if self.interval_unit_ is not _A:return self.interval_unit_
		return self._inferred_interval_unit()
	@property
	def depends_on(self)->t.Set[str]:return set()
	@property
	def fqn(self)->str:return self.name
	@property
	def data_hash(self)->str:raise NotImplementedError
	@property
	def metadata_hash(self)->str:raise NotImplementedError
	def is_metadata_only_change(self,previous:_Node)->bool:return self.data_hash==previous.data_hash and self.metadata_hash!=previous.metadata_hash
	def is_data_change(self,previous:_Node)->bool:return(self.data_hash!=previous.data_hash or self.metadata_hash!=previous.metadata_hash)and not self.is_metadata_only_change(previous)
	def croniter(self,value:TimeLike)->CroniterCache:
		if self._croniter is _A:self._croniter=CroniterCache(self.cron,value,tz=self.cron_tz)
		else:self._croniter.curr=to_datetime(value,tz=self.cron_tz)
		return self._croniter
	def cron_next(self,value:TimeLike,estimate:bool=_B)->datetime:return self.croniter(value).get_next(estimate=estimate)
	def cron_prev(self,value:TimeLike,estimate:bool=_B)->datetime:return self.croniter(value).get_prev(estimate=estimate)
	def cron_floor(self,value:TimeLike,estimate:bool=_B)->datetime:return self.croniter(self.cron_next(value,estimate=estimate)).get_prev(estimate=_C)
	def text_diff(self,other:Node,rendered:bool=_B)->str:raise NotImplementedError
	def schema_diff(self,other:Node)->t.Optional['SchemaDrift']:0
	def _inferred_interval_unit(self)->IntervalUnit:
		if not self.__inferred_interval_unit:self.__inferred_interval_unit=IntervalUnit.from_cron(self.cron)
		return self.__inferred_interval_unit
	@property
	def is_model(self)->bool:return _B
	@property
	def is_audit(self)->bool:return _B
	@property
	def dbt_node_info(self)->t.Optional[DbtNodeInfo]:return self.dbt_node_info_
class SchemaElementChange(PydanticModel,frozen=_C):name:str;type:str;text_diff:t.Optional[str]=_A
class SchemaDrift(PydanticModel,frozen=_C):
	added:t.List[SchemaElementChange]=Field(default_factory=list);removed:t.List[SchemaElementChange]=Field(default_factory=list);modified:t.List[SchemaElementChange]=Field(default_factory=list)
	def to_dict(self)->t.Dict[str,t.Any]:return{field:[item.model_dump()for item in getattr(self,field)]for field in['added','removed','modified']if getattr(self,field)}
class NodeType(str,Enum):
	MODEL='model';AUDIT='audit'
	def __str__(self)->str:return self.name
def resolve_finest_cron(*,nodes:t.Iterable['_Node'],path:t.Optional[Path]=_A)->t.Tuple[str,t.Optional[zoneinfo.ZoneInfo],t.Optional[IntervalUnit]]:
	resolved=list(nodes)
	if not resolved:raise_config_error('Cannot resolve cron from an empty dependency set',path)
	anchor=resolved[0];best_key:t.Optional[t.Tuple[int,str]]=_A
	for node in resolved:
		seconds=interval_seconds(str(node.cron))
		if not seconds:raise_config_error(f"Cannot resolve cron for non-deterministic schedule {node.cron!r} on {node.name!r}",path or node._path)
		key=seconds,node.name
		if best_key is _A or key<best_key:best_key=key;anchor=node
	timezones={node.cron_tz for node in resolved if node.cron_tz is not _A}
	if len(timezones)>1:raise_config_error(f"Cannot resolve cron: dependency nodes use mixed cron_tz values {sorted(str(tz)for tz in timezones)}",path or anchor._path)
	return str(anchor.cron),anchor.cron_tz,anchor.interval_unit_
def str_or_exp_to_str(v:t.Any)->t.Optional[str]:
	if isinstance(v,exp.Expression):return v.name
	return str(v)if v is not _A else _A