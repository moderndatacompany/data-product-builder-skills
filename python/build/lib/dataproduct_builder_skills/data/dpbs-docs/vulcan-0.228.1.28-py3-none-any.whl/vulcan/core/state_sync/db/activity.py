from __future__ import annotations
_u='max_seq'
_t='COALESCE'
_s='count_dq_not_evaluated'
_r='count_dq_warn'
_q='count_dq_fail'
_p='count_dq_pass'
_o='count_dq_total'
_n='count_errors'
_m='count_models'
_l='run_data'
_k='total_evaluation_ms'
_j='bytes_processed'
_i='rows_affected'
_h='models_affected'
_g='has_environment_changes'
_f='has_requirements_changes'
_e='count_backfills'
_d='count_metadata'
_c='count_removed'
_b='count_indirect'
_a='count_added'
_Z='count_direct'
_Y='has_backfills'
_X='has_changes'
_W='plan_diff'
_V='models_affected_metadata'
_U='models_affected_indirectly'
_T='models_affected_directly'
_S='version'
_R='prev_plan_id'
_Q='git_commit_sha'
_P='run_seq'
_O='plan_seq'
_N='run_id'
_M='success'
_L='ARRAY<TEXT>'
_K='executor'
_J='created_ts_ns'
_I='end_ts'
_H='start_ts'
_G='boolean'
_F='plan_id'
_E='text'
_D='environment'
_C=True
_B=None
_A='bigint'
import logging,typing as t
from datetime import datetime
from sqlglot import exp
from vulcan.core.activity import PlanActivity,RunActivity
from vulcan.core.types import RunDqCounts
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.query_fingerprints import expire_query_fingerprints_by_models
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.core.state_sync.db.utils import fetchone,is_postgres
from vulcan.utils import get_executor
from vulcan.utils.date import to_timestamp
logger=logging.getLogger(__name__)
ACTIVITY_PLANS=TableSpec(name='_plans',primary_key=(_F,),columns=(ColumnSpec(_F,indexed=_C),ColumnSpec(_D,indexed=_C),ColumnSpec(_H,_A),ColumnSpec(_I,_A),ColumnSpec(_J,_A),ColumnSpec(_K,_E),ColumnSpec(_Q,_E),ColumnSpec(_R,_E),ColumnSpec(_S,_E),ColumnSpec(_T,_L),ColumnSpec(_U,_L),ColumnSpec(_V,_L),ColumnSpec(_W,'jsonb'),ColumnSpec(_X,_G),ColumnSpec(_Y,_G),ColumnSpec(_M,_G),ColumnSpec(_O,_A),ColumnSpec(_Z,_A),ColumnSpec(_a,_A),ColumnSpec(_b,_A),ColumnSpec(_c,_A),ColumnSpec(_d,_A),ColumnSpec(_e,_A),ColumnSpec(_f,_G),ColumnSpec(_g,_G)))
ACTIVITY_RUNS=TableSpec(name='_runs',primary_key=(_N,),columns=(ColumnSpec(_N,indexed=_C),ColumnSpec(_F,indexed=_C),ColumnSpec(_D,indexed=_C),ColumnSpec(_H,_A),ColumnSpec(_I,_A),ColumnSpec(_J,_A),ColumnSpec(_K,_E),ColumnSpec(_M,_G),ColumnSpec(_h,_L),ColumnSpec(_i,_A),ColumnSpec(_j,_A),ColumnSpec(_k,_A),ColumnSpec(_l,'jsonb'),ColumnSpec(_P,_A),ColumnSpec(_m,_A),ColumnSpec(_n,_A),ColumnSpec(_o,_A),ColumnSpec(_p,_A),ColumnSpec(_q,_A),ColumnSpec(_r,_A),ColumnSpec(_s,_A)))
ACTIVITY_LOG=TableSpec(name='_activity_log',primary_key=('id',),columns=(ColumnSpec('id',_E),ColumnSpec(_D,indexed=_C),ColumnSpec('model_name',indexed=_C,nullable=_C),ColumnSpec('event_type',indexed=_C),ColumnSpec('event_ts',_A),ColumnSpec('event_data',_E)))
class ActivityState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_B):self.engine_adapter=engine_adapter;self.schema=schema;dialect=engine_adapter.dialect;self.plans_table=exp.table_(ACTIVITY_PLANS.name,db=schema);self.runs_table=exp.table_(ACTIVITY_RUNS.name,db=schema);self.query_fingerprints=exp.table_('_query_fingerprints',db=schema);self._plan_columns_to_types=ACTIVITY_PLANS.columns_to_types(dialect);self._run_columns_to_types=ACTIVITY_RUNS.columns_to_types(dialect);self._activity_log_columns_to_types=ACTIVITY_LOG.columns_to_types(dialect)
	def store_plan_activity(self,plan_activity:PlanActivity)->_B:
		import pandas as pd,time;updated_ts_ns=time.time_ns()
		with self.engine_adapter.transaction():
			self.engine_adapter.delete_from(self.plans_table,where=exp.EQ(this=exp.column(_F),expression=exp.Literal.string(plan_activity.plan_id)));next_seq_result=fetchone(self.engine_adapter,exp.select(exp.func(_t,exp.func('MAX',exp.column(_O)),0).as_(_u)).from_(self.plans_table).where(exp.EQ(this=exp.column(_D),expression=exp.Literal.string(plan_activity.environment))));plan_seq=(next_seq_result[0]or 0)+1 if next_seq_result else 1;diff_json=plan_activity.json();models_directly=_B;models_indirectly=_B;models_metadata=_B
			if plan_activity.models_affected_directly:models_directly=plan_activity.models_affected_directly
			if plan_activity.models_affected_indirectly:models_indirectly=plan_activity.models_affected_indirectly
			if plan_activity.models_affected_metadata:models_metadata=plan_activity.models_affected_metadata
			changes=plan_activity.changes;df=pd.DataFrame([{_F:plan_activity.plan_id,_D:plan_activity.environment,_H:int(plan_activity.start_ts),_I:int(plan_activity.end_ts),_J:updated_ts_ns,_K:plan_activity.executor,_Q:plan_activity.git_commit_sha,_R:plan_activity.prev_plan_id,_S:plan_activity.version,_T:models_directly,_U:models_indirectly,_V:models_metadata,_W:diff_json,_X:plan_activity.has_changes,_Y:bool(plan_activity.backfills),_M:plan_activity.success,_O:plan_seq,_Z:len(changes.direct),_a:len(changes.added),_b:len(changes.indirect),_c:len(changes.removed),_d:len(changes.metadata),_e:len(plan_activity.backfills),_f:plan_activity.has_requirements_changes,_g:plan_activity.has_environment_changes}]);self.engine_adapter.insert_append(self.plans_table,df,target_columns_to_types=self._plan_columns_to_types,track_rows_processed=False)
	def store_run_activity(self,run_activity:RunActivity,*,dq_counts:RunDqCounts|_B=_B)->str:
		if dq_counts is _B:dq_counts=RunDqCounts.empty()
		import pandas as pd,time;run_id=run_activity.run_id;executor=get_executor();updated_ts_ns=time.time_ns()
		with self.engine_adapter.transaction():
			self.engine_adapter.delete_from(self.runs_table,where=exp.EQ(this=exp.column(_N),expression=exp.Literal.string(run_id)));next_seq_result=fetchone(self.engine_adapter,exp.select(exp.func(_t,exp.func('MAX',exp.column(_P)),0).as_(_u)).from_(self.runs_table).where(exp.EQ(this=exp.column(_D),expression=exp.Literal.string(run_activity.environment))));run_seq=(next_seq_result[0]or 0)+1 if next_seq_result else 1;execution_json=run_activity.model_dump_json();df=pd.DataFrame([{_N:run_id,_F:run_activity.plan_id,_D:run_activity.environment,_H:int(run_activity.start_ts),_I:int(run_activity.end_ts),_J:updated_ts_ns,_K:executor,_M:run_activity.success,_h:[m.name for m in run_activity.models_affected]if run_activity.models_affected else _B,_i:run_activity.rows_affected,_j:run_activity.bytes_processed,_k:run_activity.total_evaluation_ms,_l:execution_json,_P:run_seq,_m:len(run_activity.models_affected),_n:len(run_activity.errors),_o:dq_counts.total,_p:dq_counts.passed,_q:dq_counts.failed,_r:dq_counts.warned,_s:dq_counts.not_evaluated}]);self.engine_adapter.insert_append(self.runs_table,df,target_columns_to_types=self._run_columns_to_types,track_rows_processed=False)
			if run_activity.models_affected and is_postgres(self.engine_adapter):model_names=[m.name for m in run_activity.models_affected];self._expire_query_fingerprints_by_models(model_names=model_names,run_id=run_id)
		return run_id
	def _expire_query_fingerprints_by_models(self,model_names:t.Union[str,t.List[str]],run_id:str)->_B:expire_query_fingerprints_by_models(self.engine_adapter,self.query_fingerprints,model_names,run_id)