from __future__ import annotations
_C='vulcan_version'
_B='sqlglot_version'
_A='schema_version'
import logging,typing as t
from sqlglot._version import __version__ as SQLGLOT_VERSION
from sqlglot import exp
from sqlglot.helper import seq_get
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.core.state_sync.db.utils import fetchone,SQLMESH_VERSION
from vulcan.core.state_sync.base import SCHEMA_VERSION,Versions
logger=logging.getLogger(__name__)
VERSIONS=TableSpec(name='_versions',primary_key=(_A,),columns=(ColumnSpec(_A,'int'),ColumnSpec(_B,indexed=True),ColumnSpec(_C,indexed=True)))
class VersionState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=None):self.engine_adapter=engine_adapter;self.versions_table=exp.table_(VERSIONS.name,db=schema);self._version_columns_to_types=VERSIONS.columns_to_types(engine_adapter.dialect)
	def update_versions(self,schema_version:int=SCHEMA_VERSION,sqlglot_version:str=SQLGLOT_VERSION,vulcan_version:str=SQLMESH_VERSION)->None:import pandas as pd;self.engine_adapter.delete_from(self.versions_table,'TRUE');self.engine_adapter.insert_append(self.versions_table,pd.DataFrame([{_A:schema_version,_B:sqlglot_version,_C:vulcan_version}]),target_columns_to_types=self._version_columns_to_types,track_rows_processed=False)
	def get_versions(self)->Versions:
		no_version=Versions()
		if not self.engine_adapter.table_exists(self.versions_table):return no_version
		query=exp.select('*').from_(self.versions_table);row=fetchone(self.engine_adapter,query)
		if not row:return no_version
		return Versions(schema_version=row[0],sqlglot_version=row[1],vulcan_version=seq_get(row,2))