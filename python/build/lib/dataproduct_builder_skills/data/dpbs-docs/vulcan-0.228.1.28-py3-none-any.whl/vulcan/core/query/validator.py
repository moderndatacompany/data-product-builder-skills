from __future__ import annotations
_B=False
_A=None
import re,typing as t
from sqlglot import exp,parse
from sqlglot.errors import SqlglotError
from typing_extensions import Self
from schema.metadata import Metadata
from vulcan.core.dialect import find_tables_unquoted,fqn_to_unquoted
from vulcan.core.query.lineage import unknown_table_refs
from vulcan.utils.errors import QueryValidationError
POLICY_CTE_PREFIX='__vulcan_'
_ALLOWED_STATEMENT_TYPES=exp.Select,exp.Union,exp.Intersect,exp.Except,exp.Subquery,exp.Values
_FORBIDDEN_STATEMENT_TYPES=exp.Insert,exp.Update,exp.Delete,exp.Merge,exp.Create,exp.Drop,exp.Alter,exp.TruncateTable,exp.Replace,exp.Command
_RESERVED_CTE=re.compile(f"^{re.escape(POLICY_CTE_PREFIX)}")
class QueryValidator:
	def __init__(self,*,metadata:Metadata,dialect:str,default_catalog:str|_A)->_A:self.metadata=metadata;self.dialect=dialect;self.default_catalog=default_catalog;self._available_tables=sorted(metadata.index.queryable_tables.keys())
	def validate(self,sql:str,*,allow_rollups:bool=_B)->_A:
		statements=self._parse_statements(sql)
		if len(statements)!=1:raise QueryValidationError('MULTIPLE_STATEMENTS',f"Only one SQL statement is allowed; found {len(statements)}")
		expression=statements[0];table_refs=self._extract_tables(expression);self._allow_rollups=allow_rollups
		for rule in self._RULES:rule(self,expression,table_refs)
	def _parse_statements(self,sql:str)->list[exp.Expression]:
		A='PARSE_ERROR'
		try:statements=parse(sql,read=self.dialect);return[statement for statement in statements if statement is not _A]
		except SqlglotError as exc:raise QueryValidationError(A,f"Failed to parse SQL: {exc}")from exc
		except Exception as exc:raise QueryValidationError(A,f"Unexpected parse error: {exc}")from exc
	def _extract_tables(self,expression:exp.Expression)->t.Set[str]:
		try:return find_tables_unquoted(expression,default_catalog=self.default_catalog,dialect=self.dialect)
		except Exception as exc:raise QueryValidationError('TABLE_EXTRACTION_ERROR',f"Failed to extract tables: {exc}")from exc
	def _check_read_only(self,expression:exp.Expression,table_refs:t.Set[str])->_A:
		A='DATA_MANIPULATION_DETECTED';del table_refs
		if not isinstance(expression,_ALLOWED_STATEMENT_TYPES):raise QueryValidationError(A,f"Only SELECT queries are allowed. Found: {type(expression).__name__}")
		for node in expression.walk():
			if isinstance(node,_FORBIDDEN_STATEMENT_TYPES):raise QueryValidationError(A,f"Data manipulation not allowed: {type(node).__name__}")
	def _check_known_tables(self,expression:exp.Expression,table_refs:t.Set[str])->_A:
		del expression
		if not table_refs:return
		allow_rollups=getattr(self,'_allow_rollups',_B);unknown=unknown_table_refs(table_refs,metadata=self.metadata,dialect=self.dialect,allow_rollups=allow_rollups)
		if not unknown:return
		if not allow_rollups:
			rollup_only=sorted(name for name in unknown if fqn_to_unquoted(name,dialect=self.dialect)in self.metadata.index.rollup_tables)
			if rollup_only:raise QueryValidationError('ROLLUP_TABLE_NOT_QUERYABLE',f"rollup tables cannot be queried directly: {rollup_only}")
		missing=', '.join(f"'{name}'"for name in unknown);available=', '.join(f"'{name}'"for name in self._available_tables);raise QueryValidationError('NOT_FOUND',f"{missing} not found. Available tables: {available}")
	def _check_no_user_reserved_cte_names(self,expression:exp.Expression,table_refs:t.Set[str])->_A:
		del table_refs;reserved:list[str]=[]
		for with_clause in expression.find_all(exp.With):
			for cte in with_clause.expressions:
				alias=cte.alias
				if alias is _A:continue
				name=alias.name if hasattr(alias,'name')else str(alias)
				if not name or not _RESERVED_CTE.match(name):continue
				if _is_policy_cte_definition(cte,name=name,metadata=self.metadata):continue
				reserved.append(name)
		if not reserved:return
		raise QueryValidationError('RESERVED_CTE_NAME',f"CTE names must not use the reserved policy prefix {POLICY_CTE_PREFIX!r}; found: {sorted(set(reserved))}")
	_RULES:tuple[t.Callable[[Self,exp.Expression,t.Set[str]],_A],...]=(_check_read_only,_check_known_tables,_check_no_user_reserved_cte_names)
def _is_policy_cte_definition(cte:exp.CTE,*,name:str,metadata:Metadata)->bool:
	model_name=_model_name_for_policy_cte(name,metadata)
	if model_name is _A:return _B
	query=cte.this
	if not isinstance(query,exp.Select):return _B
	from_clause=query.args.get('from')
	if from_clause is _A:return _B
	source=from_clause.this
	if not isinstance(source,exp.Table):return _B
	dialect=metadata.gateway.dialect or'postgres';table_sql=exp.table_name(source,identify=_B);normalized=fqn_to_unquoted(table_sql,dialect=dialect);return normalized==model_name
def _model_name_for_policy_cte(name:str,metadata:Metadata)->str|_A:
	if not name.startswith(POLICY_CTE_PREFIX):return
	suffix=name[len(POLICY_CTE_PREFIX):]
	for model_name in metadata.index.queryable_tables.values():
		if model_name.replace('.','_')==suffix:return model_name