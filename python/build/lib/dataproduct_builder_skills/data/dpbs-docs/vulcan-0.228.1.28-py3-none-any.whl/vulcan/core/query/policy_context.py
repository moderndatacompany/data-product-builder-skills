from __future__ import annotations
_A=None
import re,typing as t
from schema.auth import SecurityContext
from schema.filters import PolicyEntry,PolicyFilterExpression,PolicyLogicalFilter,PolicyUnaryFilter
from schema.filters.operators import FilterValue
from schema.metadata import Metadata,ModelEntry
from vulcan.utils.errors import PolicySecurityContextIncomplete,RewriteError
_SECURITY_CONTEXT_VALUE_RE=re.compile('^\\{\\s*securityContext\\s*\\.\\s*([a-zA-Z][a-zA-Z0-9_]*)\\s*\\}$')
def normalize_context_key(key:str)->str:
	if'_'in key or key.islower():return key
	return re.sub('([A-Z])','_\\1',key).lower().lstrip('_')
def parse_security_context_template(value:str)->str|_A:
	match=_SECURITY_CONTEXT_VALUE_RE.fullmatch(value.strip())
	if not match:return
	return normalize_context_key(match.group(1))
def resolve_filter_value(value:FilterValue,security_context:SecurityContext)->FilterValue:
	if not isinstance(value,str):return value
	match=_SECURITY_CONTEXT_VALUE_RE.fullmatch(value.strip())
	if not match:return value
	template_key=match.group(1);lookup_key=normalize_context_key(template_key);resolved=security_context.to_dict().get(lookup_key)
	if resolved is _A:raise RewriteError(f"security context missing required key {lookup_key!r} (referenced as {{securityContext.{template_key}}})")
	if isinstance(resolved,str)and not resolved.strip():raise RewriteError(f"security context key {lookup_key!r} is empty (referenced as {{securityContext.{template_key}}})")
	return resolved
def collect_required_context_keys(filters:t.Sequence[PolicyFilterExpression])->frozenset[str]:
	keys:set[str]=set()
	for expr in filters:
		if isinstance(expr,PolicyUnaryFilter):
			for value in expr.values or[]:
				if isinstance(value,str):
					lookup_key=parse_security_context_template(value)
					if lookup_key is not _A:keys.add(lookup_key)
		elif isinstance(expr,PolicyLogicalFilter):keys.update(collect_required_context_keys(expr.and_ or expr.or_ or[]))
	return frozenset(keys)
def policy_for_group(entry:ModelEntry,group:str|_A)->PolicyEntry|_A:
	normalized=(group or'').strip()
	if not normalized:return
	for policy in entry.policies:
		if policy.group==normalized:return policy
def _context_value_present(present:t.Mapping[str,t.Any],key:str)->bool:
	A=False;value=present.get(key)
	if value is _A:return A
	if isinstance(value,str)and not value.strip():return A
	return True
def missing_context_keys(required:t.AbstractSet[str],security_context:SecurityContext)->list[str]:present=security_context.to_dict();return sorted(key for key in required if not _context_value_present(present,key))
def validate_policy_context_keys(*,models:t.Sequence[str],metadata:Metadata,group:str,security_context:SecurityContext)->_A:
	normalized_group=(group or'').strip()
	if not normalized_group:return
	for model_name in sorted(models):
		entry=metadata.require_entry(model_name);policy=policy_for_group(entry,normalized_group)
		if policy is _A or not policy.filter:continue
		required=collect_required_context_keys(policy.filter);missing=missing_context_keys(required,security_context)
		if missing:raise PolicySecurityContextIncomplete(model=model_name,group=normalized_group,missing_keys=missing)