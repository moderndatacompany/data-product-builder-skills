from __future__ import annotations
_C='semantic'
_B='metric'
_A=None
import typing as t
from schema.auth import SecurityContext
from schema.metadata import Metadata
from schema.rest_query import RestQuery
from sqlglot import exp
from vulcan.core.query.policy_context import validate_policy_context_keys
from vulcan.core.query.transpiler.query import analyze,parse
from vulcan.core.query.transpiler.types import SemanticQueryContext
from vulcan.utils.errors import PolicyAccessDenied,PolicySecurityContextIncomplete,SemanticQueryValidationError
SemanticQueryRule=t.Callable[[SemanticQueryContext],_A]
def assert_semantic_api_models_only(ctx:SemanticQueryContext)->_A:
	invalid=sorted(name for name in ctx.models if ctx.index.queryable_models.get(name)not in{_C,_B})
	if not invalid:return
	raise SemanticQueryValidationError('SEMANTIC_UNKNOWN_MODEL',f"unknown or non-queryable semantic model(s): {invalid}")
def assert_query_not_empty(ctx:SemanticQueryContext)->_A:
	if not ctx.models:raise SemanticQueryValidationError('SEMANTIC_QUERY_EMPTY','query does not reference any semantic or metric model')
def assert_known_members(ctx:SemanticQueryContext)->_A:
	invalid=sorted(member for member in ctx.members if ctx.index.parse_qualified_member_ref(member)is _A)
	if not invalid:return
	raise SemanticQueryValidationError('SEMANTIC_UNKNOWN_MEMBER',f"unknown semantic member(s): {invalid}")
def assert_no_mixed_kinds(ctx:SemanticQueryContext)->_A:
	if _C in ctx.kinds and _B in ctx.kinds:raise SemanticQueryValidationError('SEMANTIC_MIXED_KIND','semantic and metric models cannot be combined in one query')
def assert_single_metric(ctx:SemanticQueryContext)->_A:
	metric_models=[name for name in ctx.models if ctx.index.queryable_models.get(name)==_B]
	if len(metric_models)>1:raise SemanticQueryValidationError('SEMANTIC_MULTIPLE_METRICS',f"metric queries must reference a single metric model, got {sorted(metric_models)}")
def assert_semantic_policy_access(ctx:SemanticQueryContext)->_A:
	protected=ctx.index.protected_models
	if not protected:return
	group=ctx.group
	for model in ctx.flattened_models:
		allowed=protected.get(model)
		if allowed is not _A and(not group or group not in allowed):raise PolicyAccessDenied(semantic=model,group=group or'(empty)',allowed_groups=sorted(allowed))
def assert_policy_security_context_keys(ctx:SemanticQueryContext)->_A:validate_policy_context_keys(models=ctx.flattened_models,metadata=ctx.metadata,group=ctx.group,security_context=ctx.security_context)
DEFAULT_RULES:tuple[SemanticQueryRule,...]=(assert_semantic_api_models_only,assert_query_not_empty,assert_known_members,assert_no_mixed_kinds,assert_single_metric,assert_semantic_policy_access,assert_policy_security_context_keys)
def validate(*,query:RestQuery|str|exp.Expression,catalog:Metadata,user:str,security_context:SecurityContext,rules:t.Sequence[SemanticQueryRule]=DEFAULT_RULES)->SemanticQueryContext:
	parsed=parse(query);analysis=analyze(parsed,catalog);ctx=SemanticQueryContext(metadata=catalog,query=parsed,user=user,security_context=security_context,analysis=analysis)
	for rule in rules:rule(ctx)
	return ctx