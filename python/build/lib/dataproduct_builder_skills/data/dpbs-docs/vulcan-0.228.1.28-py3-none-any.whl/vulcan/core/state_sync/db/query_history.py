from __future__ import annotations
_S='created_ts'
_R='warehouse_query_id'
_Q='executor'
_P='error_message'
_O='row_count'
_N='duration_ms'
_M='status'
_L='dialect'
_K='statement_kind'
_J='fingerprint'
_I='normalized_sql'
_H='sql_text'
_G='component'
_F='job_type'
_E='request_id'
_D='run_id'
_C='bigint'
_B='text'
_A=True
import logging,typing as t,pandas as pd
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.query.history import QueryHistoryRecord
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.utils import sortable_id
from vulcan.utils.date import now_timestamp
logger=logging.getLogger(__name__)
QUERY_HISTORY=TableSpec(name='_sql_history',primary_key=('id',),description='Append-only warehouse SQL execution log (one row per statement)',columns=(ColumnSpec('id',indexed=_A,description='Sortable ULID primary key'),ColumnSpec(_D,indexed=_A,nullable=_A,description='Links to _runs.run_id'),ColumnSpec(_E,indexed=_A,nullable=_A),ColumnSpec(_F,_B,description='PLAN, RUN, or QUERY'),ColumnSpec(_G,_B,nullable=_A,description='Emitting subsystem (DQ, PROFILE)'),ColumnSpec(_H,blob=_A,description='SQL as executed'),ColumnSpec(_I,blob=_A,nullable=_A,description='Canonical sqlglot-normalized SQL'),ColumnSpec(_J,indexed=_A,description='SHA-256 of normalized SQL when available'),ColumnSpec(_K,_B,nullable=_A),ColumnSpec(_L,_B),ColumnSpec(_M,_B,description='SUCCESS or FAILED'),ColumnSpec(_N,_C,nullable=_A),ColumnSpec(_O,_C,nullable=_A),ColumnSpec(_P,blob=_A,nullable=_A),ColumnSpec(_Q,_B),ColumnSpec(_R,_B,nullable=_A),ColumnSpec(_S,_C,description='Insertion time (Unix ms)')))
class QueryHistoryState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=None):self.engine_adapter=engine_adapter;self.schema=schema;dialect=engine_adapter.dialect;self.table=exp.table_(QUERY_HISTORY.name,db=schema);self._columns_to_types=QUERY_HISTORY.columns_to_types(dialect)
	def write_batch(self,records:t.Sequence[QueryHistoryRecord])->None:
		if not records:return
		df=records_to_dataframe(records);df=df[QUERY_HISTORY.column_names()];self.engine_adapter.insert_append(self.table,df,target_columns_to_types=self._columns_to_types,track_rows_processed=False)
def records_to_dataframe(records:t.Sequence[QueryHistoryRecord])->pd.DataFrame:
	created_ts=now_timestamp();rows=[]
	for record in records:rows.append({'id':sortable_id(),_D:record.run_id,_E:record.request_id,_F:record.job_type.value,_G:record.component,_H:record.sql_text,_I:record.normalized_sql,_J:record.fingerprint,_K:record.statement_kind,_L:record.dialect,_M:record.status,_N:record.duration_ms,_O:record.row_count,_P:record.error_message,_Q:record.executor,_R:record.warehouse_query_id,_S:created_ts})
	return pd.DataFrame(rows)