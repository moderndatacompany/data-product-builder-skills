from __future__ import annotations
_J='fabric'
_I='athena'
_H='redshift'
_G='postgres'
_F='bigquery'
_E='snowflake'
_D='duckdb'
_C='mssql'
_B=True
_A=None
import json,logging,os,typing as t,uuid
from urllib.parse import urljoin
import httpx
from schema.auth import SecurityContext
from schema.rest_query import RestQuery
from vulcan.core.config import Config
from vulcan.core.query.transpiler.types import TranspilerHttpResponse
from vulcan.utils.errors import VulcanError,TranspilerError
logger=logging.getLogger(__name__)
_SEMANTIC_DIALECT_MAPPING:t.Dict[str,str]={_D:_D,_E:_E,'databricks':'databricks-jdbc',_F:_F,_G:_G,_H:_H,'mysql':'mysql','spark':'spark','trino':'trino',_I:_I,_J:_J,_C:_C,'tsql':_C}
def _require_non_empty(value:str|_A,*,field:str)->str:
	resolved=(value or'').strip()
	if not resolved:raise ValueError(f"{field} is unset")
	return resolved
def dialect_for_gateway(config:Config,gateway:str)->str:conn=config.get_connection(gateway);return(getattr(conn,'DIALECT',_A)or getattr(conn,'type_',_A)or'').strip()
def db_type_for_gateway(config:Config,gateway:str)->str:
	dialect=dialect_for_gateway(config,gateway)
	if not dialect:raise VulcanError(f"Gateway {gateway!r} has no dialect; cannot determine db_type for transpiler.")
	return _SEMANTIC_DIALECT_MAPPING.get(dialect,dialect)
class TranspilerClient:
	def __init__(self,url:str,timeout:int=30,headers:t.Optional[t.Dict[str,str]]=_A)->_A:self.url=url;self.timeout=timeout;self.default_headers=headers or{};(self._client):t.Optional[httpx.AsyncClient]=_A
	async def __aenter__(self)->'TranspilerClient':self._client=httpx.AsyncClient(timeout=self.timeout,headers=self.default_headers);return self
	async def __aexit__(self,exc_type,exc_val,exc_tb)->_A:
		if self._client:await self._client.aclose()
	async def transpile(self,query:RestQuery|str,schema:dict[str,t.Any],*,config:Config,gateway:str,user:str,security_context:SecurityContext,disable_cube_post_processing:bool=_B,headers:dict[str,str]|_A=_A)->TranspilerHttpResponse:tenant_id=_require_non_empty(config.tenant,field='config.tenant');vulcan_id=_require_non_empty(config.name,field='config.name');rollup_schema=_require_non_empty(config.get_rollup_schema(gateway),field=f"gateway {gateway!r} rollup_schema");db_type=db_type_for_gateway(config,gateway);return await self._transpile(query,schema=schema,tenant_id=tenant_id,request_id=str(uuid.uuid4()),db_type=db_type,vulcan_id=vulcan_id,rollup_schema=rollup_schema,user=user,disable_post_processing=disable_cube_post_processing,security_context=security_context,headers=headers)
	async def _transpile(self,query:RestQuery|str,*,schema:dict[str,t.Any],tenant_id:str,request_id:str,db_type:str,vulcan_id:str,rollup_schema:str,user:str,disable_post_processing:bool=_B,security_context:SecurityContext|_A=_A,headers:t.Optional[t.Dict[str,str]]=_A)->TranspilerHttpResponse:
		F='query_type';E='status_code';D='sql';C='message';B='error';A='format'
		if not self._client:raise RuntimeError('TranspilerClient must be used as async context manager')
		if isinstance(query,RestQuery):format_value='rest';query_value:t.Any=query.model_dump(exclude_none=_B,by_alias=_B)
		else:format_value=D;query_value=query
		request_headers:t.Dict[str,str]={**self.default_headers,**(headers or{})};payload={'query':query_value,A:format_value,'disable_post_processing':disable_post_processing,'schema':schema};request_headers['X-Request-Id']=request_id;request_headers['X-Tenant-Id']=tenant_id;request_headers['X-DB-Type']=db_type;request_headers['X-User']=user;request_headers['X-Vulcan-Id']=vulcan_id;request_headers['X-Rollup-Schema']=rollup_schema;request_headers.update((security_context or SecurityContext()).to_headers());logger.info('Query --> %s',query_value if isinstance(query_value,str)else json.dumps(query_value,default=str))
		try:
			response=await self._client.post(self.url,json=payload,headers=request_headers)
			if response.status_code!=200:
				try:data=response.json()if response.content else{}
				except Exception:data={}
				err=data.get(B)
				if isinstance(err,dict)and'code'in err and C in err:message=err[C]
				else:message=data.get('detail',data.get(C,f"HTTP {response.status_code}"))
				logger.error('Transpiler non-200 response status=%s format=%s error=%s',response.status_code,format_value,message,extra={E:response.status_code,A:format_value});raise TranspilerError(message=message,code=response.status_code,response_data=data)
			try:data=response.json()
			except Exception as json_error:logger.error('Transpiler invalid JSON response format=%s error=%s',format_value,json_error);logger.debug('Transpiler raw response (first 500 chars): %s',response.text[:500]);raise TranspilerError(message=f"Invalid JSON response from Transpiler: {str(json_error)}",code=502)
			sql_data=data.get(D,{})
			if isinstance(sql_data,dict)and sql_data.get('status')==B:error_message=sql_data.get(B,'Unknown error from Transpiler');query_type=sql_data.get(F,'unknown');logger.error('Transpiler error in response body status=%s format=%s error=%s query_type=%s',response.status_code,format_value,error_message,query_type,extra={E:response.status_code,A:format_value,F:query_type});raise TranspilerError(message=error_message,code=400,response_data=data,query_type=query_type)
			http_response=TranspilerHttpResponse(**data);logger.info('Query <-- %s',' '.join(http_response.sql_statement.split()));return http_response
		except httpx.RequestError as e:logger.error('Transpiler connection error url=%s format=%s error=%s',self.url,format_value,e);raise TranspilerError(message=f"Failed to connect to Transpiler: {str(e)}",code=503,is_connection_error=_B)
		except TranspilerError:raise
		except Exception as e:logger.error('Unexpected error in Transpiler client url=%s format=%s error=%s',self.url,format_value,e);raise TranspilerError(message=f"Unexpected error: {str(e)}",code=500)
def make_transpiler_client(config:Config,token:t.Optional[str]=_A)->TranspilerClient:
	base=config.transpiler.base_url;base=base if base.endswith('/')else base+'/';transpiler_url=urljoin(base,'v1/sql');headers:dict[str,str]={};effective_token=token or config.transpiler.token or os.environ.get('DATAOS_RUN_AS_APIKEY')
	if effective_token:headers['Authorization']=f"Bearer {effective_token}"
	return TranspilerClient(url=transpiler_url,timeout=config.transpiler.timeout,headers=headers if headers else _A)