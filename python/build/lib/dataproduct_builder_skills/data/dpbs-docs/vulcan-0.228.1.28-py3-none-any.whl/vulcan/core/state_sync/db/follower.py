from __future__ import annotations
_B='bigint'
_A='user_id'
import typing as t
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils.migration import ColumnSpec,TableSpec
MAX_ANALYTICS_LIMIT=365
FOLLOWERS=TableSpec(name='_followers',primary_key=(_A,),description='Users following this data product',columns=(ColumnSpec(_A,indexed=True),ColumnSpec('active','boolean'),ColumnSpec('followed_at',_B),ColumnSpec('updated_at',_B),ColumnSpec('metadata','jsonb')))
class FollowerState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=None)->None:self.engine_adapter=engine_adapter;self.schema=schema;self.followers_table=exp.table_(FOLLOWERS.name,db=schema);self._followers_columns_to_types=FOLLOWERS.columns_to_types(engine_adapter.dialect)