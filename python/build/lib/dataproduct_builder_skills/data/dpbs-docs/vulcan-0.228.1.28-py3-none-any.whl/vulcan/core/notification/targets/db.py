from __future__ import annotations
_C='state_store'
_B=True
_A=None
import logging,typing as t
from pydantic import Field
from vulcan.core.notification.events import NotificationEvent,NotificationPayload,NotificationStatus
from vulcan.core.notification.targets.base import BaseNotificationTarget
logger=logging.getLogger(__name__)
class DbNotificationTarget(BaseNotificationTarget,frozen=_B):
	type_:t.Literal[_C]=Field(alias='type',default=_C);sync:bool=_B;username:t.Optional[str]=_A
	@classmethod
	def create(cls,store_fn:t.Callable[...,_A],username:t.Optional[str]=_A)->DbNotificationTarget:target=cls(username=username);object.__setattr__(target,'_store_fn',store_fn);return target
	@property
	def is_configured(self)->bool:return _B
	def send(self,notification_status:NotificationStatus,msg:str,*,event:NotificationEvent,payload:NotificationPayload)->_A:
		payload_dict=payload.model_dump(mode='json',exclude_none=_B);environment=getattr(payload,'environment',_A);run_id=getattr(payload,'run_id',_A);plan_id=getattr(payload,'plan_id',_A)
		try:self._store_fn(event=event,status=notification_status,summary=msg.strip(),payload=payload_dict,environment=environment,run_id=run_id,plan_id=plan_id,username=self.username)
		except Exception:logger.exception("Failed to persist notification event '%s' to state DB.",event.value);raise
	def __hash__(self)->int:return hash((self.type_,self.username))
	def __eq__(self,other:object)->bool:return isinstance(other,DbNotificationTarget)and self.username==other.username