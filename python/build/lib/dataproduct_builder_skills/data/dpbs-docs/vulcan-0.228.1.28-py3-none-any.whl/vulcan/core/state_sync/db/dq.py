from __future__ import annotations
_A0='columnName'
_z='column'
_y='scanEndTimestamp'
_x='scanStartTimestamp'
_w='boolean'
_v='measured_at'
_u='numeric'
_t='partition_name'
_s='metric_name'
_r='outcome_reasons'
_q='start_ts'
_p='type'
_o='updated_ts'
_n='group_by'
_m='resource_attributes'
_l='dimension'
_k='check_name'
_j='json'
_i='number'
_h='table'
_g='profiled_at'
_f='profile_type'
_e='check_id'
_d='archetype'
_c='filter'
_b='definition'
_a='check_type'
_Z='end_ts'
_Y='unknown'
_X=False
_W='location'
_V='diagnostics'
_U='outcome'
_T='identity'
_S='value_type'
_R='value_json'
_Q='value_text'
_P='metric_identity'
_O='value'
_N='metrics'
_M='value_number'
_L='model_name'
_K='column_name'
_J='run_id'
_I='bigint'
_H='dataTime'
_G='check_identity'
_F='environment'
_E='created_ts'
_D='id'
_C=True
_B='text'
_A=None
import json,typing as t,logging
from decimal import Decimal
from datetime import date,datetime,timezone,timedelta
import pandas as pd
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.core.state_sync.db.utils import fetchall,json_to_dict
from vulcan.utils import JobType,get_executor,sortable_id,to_snake_case_keys
from vulcan.utils.date import now_timestamp
from vulcan.core.soda3 import _NAME_ATTR_KEY,_DIMENSION_ATTR_KEY
from vulcan.core.soda3.spec import CheckOutcome,ScanResults,validate_dq_dimension
from vulcan.core.query.history import QueryHistoryRecord,QueryHistoryStatus,duration_to_ms
from vulcan.core.state_sync.db.query_history import QUERY_HISTORY,records_to_dataframe
logger=logging.getLogger(__name__)
DQ_RESULTS=TableSpec(name='_dq_results',primary_key=(_D,),columns=(ColumnSpec(_D,indexed=_C),ColumnSpec(_J,indexed=_C),ColumnSpec(_F,indexed=_C),ColumnSpec(_q,_I),ColumnSpec(_Z,_I),ColumnSpec(_G,indexed=_C),ColumnSpec(_U,_B),ColumnSpec(_r,_B),ColumnSpec(_V,_B),ColumnSpec(_E,_I)))
DQ_DEFINITIONS=TableSpec(name='_dq_definitions',primary_key=(_G,_F),columns=(ColumnSpec(_G,indexed=_C),ColumnSpec(_F,indexed=_C),ColumnSpec(_k,_B),ColumnSpec(_a,_B),ColumnSpec(_K,_B),ColumnSpec(_l,_B),ColumnSpec(_b,_B),ColumnSpec(_L,indexed=_C),ColumnSpec(_m,_B),ColumnSpec(_W,_B),ColumnSpec(_n,_B),ColumnSpec(_c,_B),ColumnSpec(_N,_B),ColumnSpec(_d,_B),ColumnSpec(_o,_I)))
DQ_METRICS=TableSpec(name='_dq_metrics',primary_key=(_D,),columns=(ColumnSpec(_D,indexed=_C),ColumnSpec(_J,indexed=_C),ColumnSpec(_F,indexed=_C),ColumnSpec(_e,indexed=_C),ColumnSpec(_G,indexed=_C),ColumnSpec(_P,indexed=_C),ColumnSpec(_s,indexed=_C),ColumnSpec(_L,indexed=_C),ColumnSpec(_K,_B),ColumnSpec(_t,_B),ColumnSpec(_Q,_B),ColumnSpec(_M,_u),ColumnSpec(_R,_B),ColumnSpec(_S,_B),ColumnSpec(_v,_I),ColumnSpec(_E,_I)))
DQ_PROFILES=TableSpec(name='_dq_profiles',primary_key=(_D,),columns=(ColumnSpec(_D,indexed=_C),ColumnSpec(_J,indexed=_C),ColumnSpec(_F,indexed=_C),ColumnSpec(_L,indexed=_C),ColumnSpec(_K,_B),ColumnSpec(_f,_B),ColumnSpec(_Q,_B),ColumnSpec(_M,_u),ColumnSpec(_R,_B),ColumnSpec(_S,_B),ColumnSpec(_g,_I),ColumnSpec(_E,_I)))
DQ_FEEDBACKS=TableSpec(name='_dq_feedbacks',primary_key=(_D,),columns=(ColumnSpec(_D,indexed=_C),ColumnSpec(_J,indexed=_C),ColumnSpec(_e,indexed=_C),ColumnSpec(_G,indexed=_C),ColumnSpec('measurement_id',indexed=_C),ColumnSpec('feedback_type',_B),ColumnSpec('feedback_category',_B),ColumnSpec('is_correctly_classified',_w),ColumnSpec('is_anomaly',_w),ColumnSpec('seasonality_reason',_B),ColumnSpec('skip_measurements',_B),ColumnSpec('feedback_text',_B),ColumnSpec('metadata_json',_B),ColumnSpec('user_id',_B),ColumnSpec(_E,_I),ColumnSpec(_o,_I)))
def format_data_time(value:t.Any)->str:
	B='Z';A='+00:00'
	if isinstance(value,int):dt=datetime.fromtimestamp(value/1000,tz=timezone.utc);return dt.isoformat().replace(A,B)
	if isinstance(value,datetime):dt=value if value.tzinfo is not _A else value.replace(tzinfo=timezone.utc);dt=dt.astimezone(timezone.utc);return dt.isoformat().replace(A,B)
	if isinstance(value,date):dt=datetime(value.year,value.month,value.day,tzinfo=timezone.utc);return dt.isoformat().replace(A,B)
	if isinstance(value,str):return value
	raise ValueError(f"Unsupported type for dataTime: {type(value)}")
def convert_value(value:t.Any,column_name:t.Optional[str]=_A)->t.Any:
	if isinstance(value,Decimal):return float(value)
	if column_name==_H:return format_data_time(value)
	return value
def _parse_diagnostics(raw:t.Any)->t.Dict[str,t.Any]:return json_to_dict(raw)
_SODA_DERIVED_QUERY_SUFFIXES='.failing_sql','.passing_sql'
class QualityState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A):self.engine_adapter=engine_adapter;self.schema=schema;dialect=engine_adapter.dialect;self.check_results_table=exp.table_(DQ_RESULTS.name,db=schema);self.checks_definitions_table=exp.table_(DQ_DEFINITIONS.name,db=schema);self.check_metrics_table=exp.table_(DQ_METRICS.name,db=schema);self.profiles_table=exp.table_(DQ_PROFILES.name,db=schema);self.check_feedback_table=exp.table_(DQ_FEEDBACKS.name,db=schema);self.runs_table=exp.table_('_runs',db=schema);self._check_results_columns_to_types=DQ_RESULTS.columns_to_types(dialect);self._checks_definitions_columns_to_types=DQ_DEFINITIONS.columns_to_types(dialect);self._check_metrics_columns_to_types=DQ_METRICS.columns_to_types(dialect);self._profiles_columns_to_types=DQ_PROFILES.columns_to_types(dialect);self._check_feedback_columns_to_types=DQ_FEEDBACKS.columns_to_types(dialect);self.query_history_table=exp.table_(QUERY_HISTORY.name,db=schema);self._query_history_columns_to_types=QUERY_HISTORY.columns_to_types(dialect)
	def _store_checks_and_profile_results(self,scan_results:t.Dict[str,t.Any],run_id:str,environment:str,*,job_type:t.Optional[JobType]=_A,dialect:t.Optional[str]=_A)->str:
		scan_id=scan_results['scanId']
		try:
			checks_df,check_id_map=self._prepare_checks_dataframe(scan_results,run_id,environment);metrics_df=self._prepare_metrics_dataframe(scan_results,run_id,environment,check_id_map);profiles_df=self._prepare_profiles_dataframe(scan_results,run_id,environment);query_history_df=pd.DataFrame()
			if job_type in(JobType.PLAN,JobType.RUN)and dialect:query_history_df=self._prepare_scan_query_history_dataframe(scan_results,run_id=run_id,job_type=job_type,dialect=dialect)
			with self.engine_adapter.transaction():
				if not checks_df.empty:self._write_checks_batch(checks_df);self._upsert_checks_definitions(checks_df)
				if not metrics_df.empty:self._write_metrics_batch(metrics_df)
				if not profiles_df.empty:self._write_profiles_batch(profiles_df)
				if not query_history_df.empty:query_history_df=query_history_df[QUERY_HISTORY.column_names()];self.engine_adapter.insert_append(self.query_history_table,query_history_df,target_columns_to_types=self._query_history_columns_to_types,track_rows_processed=_X)
			logger.info(f"Stored check scan {scan_id}, run {run_id}: {len(checks_df)} checks, {len(metrics_df)} metrics, {len(profiles_df)} profile metrics");return scan_id
		except Exception as e:logger.error(f"Failed to store scan results for scan {scan_id}: {e}",exc_info=_C);raise
	def _prepare_scan_query_history_dataframe(self,scan_results:t.Dict[str,t.Any],*,run_id:str,job_type:JobType,dialect:str)->pd.DataFrame:
		if job_type not in(JobType.PLAN,JobType.RUN):raise ValueError(f"Soda query history requires PLAN or RUN job_type, got {job_type!r}")
		request_id=_A;records:t.List[QueryHistoryRecord]=[]
		for query in scan_results.get('queries',[]):
			if not isinstance(query,dict):continue
			record=self._query_history_record_from_soda_query(query,run_id=run_id,request_id=request_id,job_type=job_type,dialect=dialect)
			if record is not _A:records.append(record)
		if not records:return pd.DataFrame()
		return records_to_dataframe(records)
	@staticmethod
	def _query_history_record_from_soda_query(query:t.Dict[str,t.Any],*,run_id:str,request_id:t.Optional[str],job_type:JobType,dialect:str)->t.Optional[QueryHistoryRecord]:
		duration=query.get('duration_ms',query.get('duration'))
		if duration is _A:return
		name=query.get('name')or''
		if any(name.endswith(suffix)for suffix in _SODA_DERIVED_QUERY_SUFFIXES):return
		sql_text=query.get('sql')or''
		if not sql_text.strip():return
		exception=query.get('exception');status:QueryHistoryStatus='FAILED'if exception else'SUCCESS';duration_ms=duration_to_ms(duration);error_message=str(exception)if exception else _A;return QueryHistoryRecord.from_execution(sql_text=sql_text,dialect=dialect,status=status,job_type=job_type,run_id=run_id,executor=get_executor(),request_id=request_id,component='DQ',duration_ms=duration_ms,error_message=error_message)
	def _prepare_checks_dataframe(self,scan_results:ScanResults,run_id:str,environment:str)->t.Tuple[pd.DataFrame,t.Dict[str,str]]:
		C='outcomeReasons';B='group';A='unnamed';all_checks=scan_results.get('checks',[])+scan_results.get('automatedMonitoringChecks',[])
		if not all_checks:return pd.DataFrame(),{}
		rows=[];check_id_map={};created_ts=now_timestamp()
		for check in all_checks:
			resource_attrs=check.get('resourceAttributes',{});dimension=_A
			if isinstance(resource_attrs,list):
				for attr in resource_attrs:
					if not isinstance(attr,dict):continue
					name=attr.get(_NAME_ATTR_KEY)
					if name==_DIMENSION_ATTR_KEY:dimension=attr.get(_O)
			elif isinstance(resource_attrs,dict):dimension=resource_attrs.get(_DIMENSION_ATTR_KEY)
			check_id=sortable_id();check_identity=check.get(_T)
			if not check_identity:raise ValueError(f"Check missing 'identity' field. Check name: '{check.get(_NAME_ATTR_KEY,A)}', table: '{check.get(_h,_Y)}'.")
			if not dimension or not str(dimension).strip():raise ValueError(f"Check missing '{_DIMENSION_ATTR_KEY}' in resourceAttributes. Check name: '{check.get(_NAME_ATTR_KEY,A)}', identity: '{check_identity}'.")
			dimension=validate_dq_dimension(dimension);metric_identities=check.get(_N,[])
			for metric_id in metric_identities:check_id_map[metric_id]=check_id,check_identity
			effective_model_name=check.get(_h,_Y);diagnostics_json=_A;diagnostics=check.get(_V)
			if diagnostics:diagnostics_json=json.dumps(to_snake_case_keys(diagnostics))
			rows.append({_D:check_id,_J:run_id,_F:environment,_L:effective_model_name,_q:scan_results[_x],_Z:scan_results[_y],_G:check_identity,_k:check.get(_NAME_ATTR_KEY,A),_a:check.get(_p,_Y),_b:check.get(_b),_l:dimension,_m:json.dumps(resource_attrs)if resource_attrs else _A,_W:json.dumps(check.get(_W))if check.get(_W)else _A,_n:json.dumps(check.get(B))if check.get(B)else _A,_K:check.get(_z),_c:check.get(_c),_N:json.dumps(check.get(_N))if check.get(_N)else _A,_U:check.get(_U)or CheckOutcome.NOT_EVALUATED.value,_r:json.dumps(check.get(C))if check.get(C)else _A,_d:check.get(_d),_V:diagnostics_json,_E:created_ts})
		return pd.DataFrame(rows),check_id_map
	def _prepare_metrics_dataframe(self,scan_results:ScanResults,run_id:str,environment:str,check_id_map:t.Dict[str,str])->pd.DataFrame:
		metrics_list=scan_results.get(_N,[])
		if not metrics_list:return pd.DataFrame()
		rows=[];created_ts=now_timestamp()
		for metric in metrics_list:
			metric_id=sortable_id();metric_identity=metric.get(_T);check_mapping=check_id_map.get(metric_identity)
			if check_mapping:check_id,check_identity=check_mapping
			else:check_id,check_identity=_A,_A
			value=metric.get(_O);value_text,value_number,value_json,value_type=_A,_A,_A,_A
			if value is not _A:
				if isinstance(value,(int,float)):value_number=float(value);value_type=_i
				elif isinstance(value,str):value_text=value;value_type=_B
				elif isinstance(value,(dict,list)):value_json=json.dumps(value);value_type=_j
				else:value_json=json.dumps(value);value_type=_j
			rows.append({_D:metric_id,_J:run_id,_F:environment,_e:check_id,_G:check_identity or'',_P:metric.get(_T),_s:metric.get('metricName')or metric.get(_NAME_ATTR_KEY,_Y),_L:metric.get(_h,_Y),_K:metric.get(_A0)or metric.get(_z),_t:metric.get('partition'),_Q:value_text,_M:value_number,_R:value_json,_S:value_type,_v:metric.get(_H)or scan_results[_y],_E:created_ts})
		return pd.DataFrame(rows)
	def _prepare_profiles_dataframe(self,scan_results:ScanResults,run_id:str,environment:str)->pd.DataFrame:
		profiling=scan_results.get('profiling',[])
		if not profiling:return pd.DataFrame()
		rows=[];current_ts=now_timestamp();profiled_at=scan_results.get(_x,current_ts)
		for profile_table in profiling:
			model_name=profile_table.get(_h)
			if not model_name:continue
			full_model_name=model_name;row_count=profile_table.get('rowCount')
			if row_count is not _A:rows.append({_D:sortable_id(),_J:run_id,_F:environment,_L:full_model_name,_K:_A,_f:'row_count',_Q:_A,_M:float(row_count),_R:_A,_S:_i,_g:profiled_at,_E:current_ts})
			column_profiles=profile_table.get('columnProfiles',[])
			for col_profile in column_profiles:
				column_name=col_profile.get(_A0);profile_data=col_profile.get('profile',{})
				if not column_name or not profile_data:continue
				for(metric_name,metric_value)in profile_data.items():
					if metric_value is _A:continue
					value_text=_A;value_number=_A;value_json=_A;value_type=_A
					if isinstance(metric_value,(int,float)):value_number=float(metric_value);value_type=_i
					elif isinstance(metric_value,str):
						try:value_number=float(metric_value);value_type=_i
						except(ValueError,TypeError):value_text=metric_value;value_type=_B
					elif isinstance(metric_value,(dict,list)):value_json=json.dumps(metric_value);value_type=_j
					else:value_text=str(metric_value);value_type=_B
					rows.append({_D:sortable_id(),_J:run_id,_F:environment,_L:full_model_name,_K:column_name,_f:metric_name,_Q:value_text,_M:value_number,_R:value_json,_S:value_type,_g:profiled_at,_E:current_ts})
			table_profile=profile_table.get('tableProfile',{})
			if table_profile:
				table_labels=table_profile.get('tableLabels')
				if table_labels:rows.append({_D:sortable_id(),_J:run_id,_F:environment,_L:full_model_name,_K:_A,_f:'table_labels',_Q:_A,_M:_A,_R:json.dumps(table_labels),_S:_j,_g:profiled_at,_E:current_ts})
		if not rows:return pd.DataFrame()
		return pd.DataFrame(rows)
	def _write_checks_batch(self,df:pd.DataFrame)->_A:df_to_insert=df[DQ_RESULTS.column_names()].copy();self.engine_adapter.insert_append(self.check_results_table,df_to_insert,target_columns_to_types=self._check_results_columns_to_types,track_rows_processed=_X)
	def _upsert_checks_definitions(self,df:pd.DataFrame)->_A:
		if df.empty:return
		distinct=df.drop_duplicates(subset=[_G,_F],keep='last')[[_G,_F,_k,_a,_K,_l,_b,_L,_m,_W,_n,_c,_N,_d,_Z]].copy();distinct=distinct.rename(columns={_Z:_o});self.engine_adapter.merge(self.checks_definitions_table,distinct,target_columns_to_types=self._checks_definitions_columns_to_types,unique_key=(exp.column(_G),exp.column(_F)))
	def _write_metrics_batch(self,df:pd.DataFrame)->_A:self.engine_adapter.insert_append(self.check_metrics_table,df,target_columns_to_types=self._check_metrics_columns_to_types,track_rows_processed=_X)
	def _write_profiles_batch(self,df:pd.DataFrame)->_A:df=df[DQ_PROFILES.column_names()];self.engine_adapter.insert_append(self.profiles_table,df,target_columns_to_types=self._profiles_columns_to_types,track_rows_processed=_X)
	def _get_historic_measurements(self,metric_identity:str,limit:int=100)->t.List[t.Dict[str,t.Any]]:
		try:
			query=exp.select(exp.column(_D),exp.column(_P).as_(_T),exp.column(_M).as_(_O),exp.column(_E).as_(_H)).from_(self.check_metrics_table).where(exp.and_(exp.EQ(this=exp.column(_P),expression=exp.Literal.string(metric_identity)),exp.Is(this=exp.column(_M),expression=exp.Null()).not_())).order_by(exp.column(_E),desc=_C).limit(limit);rows=fetchall(self.engine_adapter,query);results:t.List[t.Dict[str,t.Any]]=[]
			for row in rows:id_,identity,value_number,created_ts=row;value=convert_value(value_number,_O);data_time=convert_value(created_ts,_H);results.append({_D:id_,_T:identity,_O:value,_H:data_time})
			logger.debug(f"Fetched {len(results)} historic measurements for metric '{metric_identity}'");return results
		except Exception as e:logger.error(f"Failed to fetch historic measurements for '{metric_identity}': {e}",exc_info=_C);return[]
	def _get_historic_check_results(self,check_identity:str,limit:int=100)->t.List[t.Dict[str,t.Any]]:
		E='measurementId';D='testResultId';C='m';B='cd';A='c'
		try:
			c=exp.to_table(self.check_results_table).as_(A);m=exp.to_table(self.check_metrics_table).as_(C);cd=exp.to_table(self.checks_definitions_table).as_(B);select_exprs=[exp.column(_a,table=B).as_(_p),exp.column(_D,table=A).as_(D),exp.column(_U,table=A),exp.column(_E,table=A).as_(_H),exp.column(_V,table=A),exp.column(_D,table=C).as_(E)];query=exp.select(*select_exprs).from_(c).join(cd,on=exp.and_(exp.EQ(this=exp.column(_G,table=A),expression=exp.column(_G,table=B)),exp.EQ(this=exp.column(_F,table=A),expression=exp.column(_F,table=B))),join_type='inner').join(m,on=exp.EQ(this=exp.column(_D,table=A),expression=exp.column(_e,table=C)),join_type='left').where(exp.EQ(this=exp.column(_G,table=A),expression=exp.Literal.string(check_identity))).order_by(exp.Ordered(this=exp.column(_E,table=A),desc=_C)).limit(limit);rows=fetchall(self.engine_adapter,query);results:t.List[t.Dict[str,t.Any]]=[]
			for row in rows:type,test_result_id,outcome,created_ts,diagnostics_raw,measurement_id=row;data_time=convert_value(created_ts,_H);diagnostics=_parse_diagnostics(diagnostics_raw);results.append({_p:type,D:test_result_id,_U:outcome,_H:data_time,_V:diagnostics,E:measurement_id})
			logger.debug(f"Fetched {len(results)} historic check results for check '{check_identity}'");return results
		except Exception as e:logger.error(f"Failed to fetch historic check results for '{check_identity}': {e}",exc_info=_C);return[]
	def _get_historic_metric_change_over_time(self,metric_identity:str,same_day_last_week:bool=_X)->t.List[t.Dict[str,t.Any]]:
		try:
			conditions:t.List[exp.Expression]=[exp.EQ(this=exp.column(_P),expression=exp.Literal.string(metric_identity))];previous_time_start=_A;previous_time_end=_A;today=date.today()
			if same_day_last_week:last_week=today-timedelta(days=7);previous_time_start=datetime(year=last_week.year,month=last_week.month,day=last_week.day,tzinfo=timezone.utc);previous_time_end=datetime(year=last_week.year,month=last_week.month,day=last_week.day,hour=23,minute=59,second=59,tzinfo=timezone.utc)
			if previous_time_start and previous_time_end:start_ms=int(previous_time_start.timestamp()*1000);end_ms=int(previous_time_end.timestamp()*1000);conditions.append(exp.GT(this=exp.column(_E),expression=exp.Literal.number(start_ms)));conditions.append(exp.LTE(this=exp.column(_E),expression=exp.Literal.number(end_ms)))
			query=exp.select(exp.column(_D),exp.column(_P),exp.column(_M),exp.column(_E).as_(_H)).from_(self.check_metrics_table).where(exp.and_(*conditions)).order_by(exp.column(_E));rows=fetchall(self.engine_adapter,query);results:t.List[t.Dict[str,t.Any]]=[]
			for row in rows:measurement_id,identity,value_number,data_time=row;results.append({_D:measurement_id,_T:identity,_O:convert_value(value_number,_O),_H:convert_value(data_time,_H)})
			logger.debug(f"Fetched {len(results)} historic changes over time for '{metric_identity}'");return results
		except Exception as e:logger.error(f"Failed to fetch change-over-time data for '{metric_identity}': {e}",exc_info=_C);return[]