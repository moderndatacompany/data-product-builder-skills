_A='red'
import logging,traceback,typing as t
from functools import wraps
import click
from sqlglot.errors import SqlglotError
from vulcan.core.context import Context
from vulcan.utils import debug_mode_enabled
from vulcan.utils.errors import VulcanError,rebrand
DECORATOR_RETURN_TYPE=t.TypeVar('DECORATOR_RETURN_TYPE')
logger=logging.getLogger(__name__)
def _emit_cli_error(context:t.Optional[Context],message:str)->None:
	message=rebrand(message)
	if context:context.console.log_error(message)
	else:click.echo(click.style(f"Error: {message}",fg=_A),err=True)
def error_handler(func:t.Callable[...,DECORATOR_RETURN_TYPE])->t.Callable[...,DECORATOR_RETURN_TYPE]:
	@wraps(func)
	def wrapper(*args:t.List[t.Any],**kwargs:t.Any)->DECORATOR_RETURN_TYPE:
		context_or_obj=args[0];vulcan_context=context_or_obj.obj if isinstance(context_or_obj,click.Context)else context_or_obj
		if not isinstance(vulcan_context,Context):vulcan_context=None
		handler=_debug_exception_handler if debug_mode_enabled()else _default_exception_handler;return handler(vulcan_context,lambda:func(*args,**kwargs))
	return wrapper
def _default_exception_handler(context:t.Optional[Context],func:t.Callable[[],DECORATOR_RETURN_TYPE])->DECORATOR_RETURN_TYPE:
	try:return func()
	except click.ClickException as ex:_emit_cli_error(context,ex.format_message());exit(ex.exit_code or 1)
	except(VulcanError,SqlglotError,ValueError)as ex:_emit_cli_error(context,str(ex));exit(1)
	except Exception:tb_str=traceback.format_exc();click.echo(click.style(rebrand(tb_str),fg=_A),err=True);exit(1)
	finally:
		if context:context.close()
def _debug_exception_handler(context:t.Optional[Context],func:t.Callable[[],DECORATOR_RETURN_TYPE])->DECORATOR_RETURN_TYPE:
	try:return func()
	except click.ClickException as ex:_emit_cli_error(context,ex.format_message());exit(ex.exit_code or 1)
	except(VulcanError,SqlglotError,ValueError)as ex:_emit_cli_error(context,str(ex));exit(1)
	except Exception:tb_str=traceback.format_exc();logger.exception('Unhandled exception');click.echo(click.style(rebrand(tb_str),fg=_A),err=True);raise
	finally:
		if context:context.close()