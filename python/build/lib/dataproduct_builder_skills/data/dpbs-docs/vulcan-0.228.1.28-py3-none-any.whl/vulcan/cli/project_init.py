_D='──────────────────────────────\n'
_C='default'
_B=True
_A=None
import os,typing as t
from enum import Enum
from pathlib import Path
from dataclasses import dataclass
from rich.prompt import Prompt
from rich.console import Console
from vulcan.utils.date import yesterday_ds
from vulcan.utils.errors import VulcanError
from vulcan.core.config.connection import CONNECTION_CONFIG_TO_TYPE,DIALECT_TO_TYPE,INIT_DISPLAY_INFO_TO_TYPE
PRIMITIVES=str,int,bool,float
def _yaml_quote(value:str)->str:escaped=(value or'').replace('\\','\\\\').replace('"','\\"');return f'"{escaped}"'
class ProjectTemplate(Enum):DEFAULT=_C;EMPTY='empty'
class InitCliMode(Enum):DEFAULT=_C;FLOW='flow'
def _gen_config(engine_type:t.Optional[str],settings:t.Optional[str],start:t.Optional[str],template:ProjectTemplate,cli_mode:InitCliMode,tenant:str,name:str,description:str,dialect:t.Optional[str]=_A)->str:
	project_dialect=dialect or DIALECT_TO_TYPE.get(engine_type);connection_settings=settings or'      type: duckdb\n      database: db.db'
	if not settings:
		if engine_type in CONNECTION_CONFIG_TO_TYPE:
			required_fields=[];non_required_fields=[]
			for(field_key,field)in CONNECTION_CONFIG_TO_TYPE[engine_type].model_fields.items():
				field_name=field.alias or field_key;default_value=field.get_default()
				if isinstance(default_value,Enum):default_value=default_value.value
				elif not isinstance(default_value,PRIMITIVES):default_value=''
				required=field.is_required()or field_name=='type';option_str=f"      {'# 'if not required else''}{field_name}: {default_value}\n"
				if engine_type=='duckdb'and field_name=='database':option_str='      database: db.db\n';required=_B
				if required:required_fields.append(option_str)
				else:non_required_fields.append(option_str)
			connection_settings=''.join(required_fields+non_required_fields)
	default_configs={ProjectTemplate.DEFAULT:f'''name: {_yaml_quote(name)}
display_name: "Human Friendly Name"
tenant: {_yaml_quote(tenant)}
description: {_yaml_quote(description)}
discoverable: true
version: "0.1.0"
alignment: source_aligned
domain: {_yaml_quote(tenant)}

usage_path: ./usage.yml
agreement_path: ./agreement.md

# --- Product metadata (catalog / marketplace listing) ---
# Lifecycle stage shown to consumers.
status: Active  # Draft | Active

# Regulatory regimes the product is governed under, plus residency and an escalation
# contact. legal_contact is for governance escalation, distinct from support channels.
compliance:
  regimes:
    - GDPR
    - SOC2
  data_residency: us-only
  legal_contact: legal@example.com

# Where consumers get help. tool: slack|teams|email|ticket|other;
# scope: interactive|announcements|issues.
support:
  - channel: data-platform-help
    tool: slack
    scope: interactive
    url: https://example.slack.com/archives/data-platform
    hours: Mon-Fri 09:00-17:00 UTC

# Service-level expectations keyed by a fixed vocabulary (uptime, latency,
# update_frequency, time_to_repair, end_of_life, ...). This product refreshes daily.
sla:
  update_frequency:
    target: 1
    unit: d
    monitoring:
      system: vulcan-scheduler

# Usage license/terms for the product. Points at the generated agreement by default.
license:
  url: ./agreement.md

# Non-sensitive organizational identity for marketplace display (legal name, URL).
# Do not store tax IDs or registration numbers in git.
data_holder:
  legal_name: Example Org Inc.
  url: https://example.com

# Where consumers file defects or data-quality issues. provider is a fixed vocabulary
# (github, jira, gitlab, linear, asana, azure_devops, other); url must be reachable.
issue_tracker:
  provider: github
  url: https://github.com/your-org/your-repo/issues

# Optional categorization
tags: []  # e.g. ["marketing", "saas", "analytics"]
terms: []  # e.g. ["glossary.data_product", "glossary.business_intelligence"]

users:
  - username: "example"
    github_username: "example"
    email: "example@example.com"
    type: "MEMBER"
  - username: "owner"
    github_username: "owner"
    email: "owner@example.com"
    type: "OWNER"

# notification_targets:
#   - type: console
#     notify_on:
#       - apply_start
#       - apply_end
#       - run_start
#       - run_end
#       - migration_start
#       - migration_end
#       - apply_failure
#       - run_failure
#       - audit_failure
#       - migration_failure
#       - plan_change
#       - dq_start
#       - dq_end

# --- Gateway Connection ---
gateways:
  {engine_type}:
    connection:
{connection_settings}
model_defaults:
  dialect: {project_dialect}
  start: {start or yesterday_ds()} # Start date for backfill history
  cron: \'@daily\'    # Run models daily at 12am UTC (can override per model)

# --- Pre-aggregation (rollups) ---
# When true, `rollups:` blocks in semantic models materialize physical pre-aggregation
# tables (`<rollup_schema>.<model>_<rollup>`) that Vulcan owns and refreshes, so serve-time
# queries hit small summarized tables instead of scanning raw facts. When false (the default)
# rollup specs still validate but build nothing — queries fall back to the raw model. See the
# `rollups:` example in models/semantics/incremental_model.yml; flip this to true to enable it.
enable_rollup: false

# --- Linting Rules ---
# Enforce standards for your team
linter:
  enabled: true
  rules:
    - ambiguousorinvalidcolumn
    - invalidselectstarexpansion
    - noambiguousprojections

ignore_patterns:
  - "*-deploy.yaml"

# --- Auth Extension ---
# Python hook that runs after Heimdall authorises a request. Use it to map
# identity provider tags to group names for access policies.
# afterAuthorize: "plugins.auth_ext:resolve_user_groups"
'''};default_configs[ProjectTemplate.EMPTY]=default_configs[ProjectTemplate.DEFAULT];flow_cli_mode="\n# FLOW: Minimal prompts, automatic changes, summary output\n\nplan:\n  no_diff: true             # Hide detailed text differences for changed models\n  no_prompts: true          # No interactive prompts\n  auto_apply: true          # Apply changes automatically\n\n# --- Optional: Set a default target environment ---\n# This is intended for local development to prevent users from accidentally applying plans to the prod environment.\n# It is a development only config and should NOT be committed to your git repo.\n\n# Uncomment the following line to use a default target environment derived from the logged in user's name.\n# default_target_environment: dev_{{ user() }}\n\n# Example usage:\n# vulcan plan            # Automatically resolves to: vulcan plan dev_yourname\n# vulcan plan prod       # Specify `prod` to apply changes to production\n";return default_configs[template]+(flow_cli_mode if cli_mode==InitCliMode.FLOW else'')
@dataclass
class ExampleObjects:sql_models:t.Dict[str,str];python_models:t.Dict[str,str];seeds:t.Dict[str,str];tests:t.Dict[str,str];sql_macros:t.Dict[str,str];python_macros:t.Dict[str,str];semantic_models:t.Dict[str,str];metric_models:t.Dict[str,str];dq_models:t.Dict[str,str];policies:t.Dict[str,str];plugins:t.Dict[str,str]
def _gen_example_objects(schema_name:str,uppercase_columns:bool=False)->ExampleObjects:
	sql_models:t.Dict[str,str]={};python_models:t.Dict[str,str]={};seeds:t.Dict[str,str]={};tests:t.Dict[str,str]={};sql_macros:t.Dict[str,str]={};python_macros:t.Dict[str,str]={'__init__':''};semantic_models:t.Dict[str,str]={};metric_models:t.Dict[str,str]={};dq_models:t.Dict[str,str]={};full_model_name=f"{schema_name}.full_model";incremental_model_name=f"{schema_name}.incremental_model";seed_model_name=f"{schema_name}.seed_model"
	def _col(name:str)->str:return name.upper()if uppercase_columns else name
	c_id=_col('id');c_item_id=_col('item_id');c_event_date=_col('event_date');c_num_orders=_col('num_orders');c_total_events=_col('total_events');sql_models[full_model_name]=f"""MODEL (
  name {full_model_name},
  kind FULL,
  owner 'example',
  cron '@daily',
  grains ({c_item_id}),
  tags ('example', 'summary', 'orders'),
  terms ('product.full_model', 'example.summary'),
  description 'Example aggregate model built from the incremental starter model',
  column_descriptions (
    {c_item_id} = 'Identifier for the grouped item',
    {c_num_orders} = 'Count of distinct records aggregated into the full model'
  ),
  column_tags (
    {c_item_id} = ('identifier', 'grouping'),
    {c_num_orders} = ('metric', 'aggregate')
  ),
  column_terms (
    {c_item_id} = ('example.item_id', 'reference.item_id'),
    {c_num_orders} = ('example.num_orders', 'metric.num_orders')
  ),
  column_classifications (
    {c_item_id} = internal,
    {c_num_orders} = public
  ),
  assertions (
    not_null(columns := ({c_item_id})),
    forall(criteria := ({c_item_id} > 0))
  ),
);

SELECT
  {c_item_id},
  COUNT(DISTINCT {c_id}) AS {c_num_orders},
FROM
  {incremental_model_name}
GROUP BY {c_item_id}
  """;sql_models[incremental_model_name]=f"""MODEL (
  name {incremental_model_name},
  kind INCREMENTAL_BY_TIME_RANGE (
    time_column {c_event_date}
  ),
  owner 'example',
  start '2020-01-01',
  cron '@daily',
  grains ({c_id}, {c_event_date}),
  tags ('example', 'usage', 'events'),
  terms ('product.incremental_model', 'telemetry.events'),
  description 'Example incremental fact model used by the starter project',
  column_descriptions (
    {c_id} = 'Unique record identifier',
    {c_item_id} = 'Item identifier used for aggregation',
    {c_event_date} = 'Event date used as the incremental time column'
  ),
  column_tags (
    {c_id} = ('identifier', 'record'),
    {c_item_id} = ('identifier', 'foreign_key'),
    {c_event_date} = ('date', 'partition')
  ),
  column_terms (
    {c_id} = ('example.id', 'reference.id'),
    {c_item_id} = ('example.item_id', 'reference.item_id'),
    {c_event_date} = ('example.event_date', 'temporal.event_date')
  ),
  column_mask_expressions (
    {c_id} = 0,
    {c_event_date} = CAST(NULL AS TIMESTAMP)
  ),
  column_classifications (
    {c_id} = restricted,
    {c_item_id} = internal,
    {c_event_date} = restricted
  ),
  assertions (
    not_null(columns := ({c_id}, {c_item_id}, {c_event_date})),
  ),
);

SELECT
  {c_id},
  {c_item_id},
  CAST({c_event_date} AS TIMESTAMP) AS {c_event_date},
FROM
  {seed_model_name}
WHERE
  {c_event_date} BETWEEN @start_date AND @end_date
  """;sql_models[seed_model_name]=f"""MODEL (
  name {seed_model_name},
  kind SEED (
    path '../seeds/seed_data.csv'
  ),
  owner 'example',
  columns (
    {c_id} INTEGER,
    {c_item_id} INTEGER,
    {c_event_date} TIMESTAMP
  ),
  grains ({c_id}, {c_event_date}),
  tags ('example', 'seed', 'reference'),
  terms ('product.seed_model', 'reference.seed_data'),
  description 'Example seed model used by the starter project',
  column_descriptions (
    {c_id} = 'Unique row identifier',
    {c_item_id} = 'Item identifier for the seed row',
    {c_event_date} = 'Seed row event date'
  ),
  column_tags (
    {c_id} = ('identifier', 'primary_key'),
    {c_item_id} = ('identifier', 'foreign_key'),
    {c_event_date} = ('date', 'reference')
  ),
  column_terms (
    {c_id} = ('example.id', 'reference.id'),
    {c_item_id} = ('example.item_id', 'reference.item_id'),
    {c_event_date} = ('example.event_date', 'temporal.event_date')
  )
);
  """;seeds['seed_data']=f"""{c_id},{c_item_id},{c_event_date}
1,2,2020-01-01 00:00:00
2,1,2020-01-01 00:00:00
3,3,2020-01-03 00:00:00
4,1,2020-01-04 00:00:00
5,1,2020-01-05 00:00:00
6,1,2020-01-06 00:00:00
7,1,2020-01-07 00:00:00
""";tests['test_full_model']=f"""test_example_full_model:
  model: {full_model_name}
  inputs:
    {incremental_model_name}:
      rows:
      - {c_id}: 1
        {c_item_id}: 1
      - {c_id}: 2
        {c_item_id}: 1
      - {c_id}: 3
        {c_item_id}: 2
  outputs:
    query:
      rows:
      - {c_item_id}: 1
        {c_num_orders}: 2
      - {c_item_id}: 2
        {c_num_orders}: 1
  """;_metric_dim=f"  - name: item_id\n    ref: incremental_model.{c_item_id}"if uppercase_columns else f"  - incremental_model.{c_item_id}";semantic_models['incremental_model']=f"""# Canonical semantic example generated by `vulcan init`
kind: semantic
name: incremental_model
depends_on: {incremental_model_name}
description: Incremental event data (semantic layer)

dimensions:
  - name: {c_id}
    behavior:
      type: identifier
  - name: {c_item_id}
    behavior:
      type: categorical
  - name: {c_event_date}

measures:
  - name: {c_total_events}
    type: count
    description: Total number of events
    tags:
      - usage
      - events
      - metric
    terms:
      - product.total_events
      - usage.events

segments:
  - name: recent_events
    expression: \"{c_event_date} >= CURRENT_DATE - INTERVAL '7 days'\"
    description: Events from the last 7 days
    tags:
      - temporal
      - recent

# Rollups pre-aggregate this model's measures into a physical table for fast serving.
# This one materializes `<rollup_schema>.incremental_model_daily` — daily {c_total_events}
# grouped by {c_item_id}. Rollups are inert unless `enable_rollup: true` is set in
# config.yaml: the spec still validates, but no table is built and queries fall back to the
# raw model (with no warning). Flip that flag on to have Vulcan build and refresh the table.
rollups:
  - name: daily
    measures:
      - {c_total_events}
    dimensions:
      - {c_item_id}
    time_dimension: {c_event_date}
    granularity: day
    description: Daily total events by item
""";metric_models['event_activity']=f"""# Metric example generated by `vulcan init`
kind: metric
name: event_activity
measure: incremental_model.{c_total_events}
ts: incremental_model.{c_event_date}
granularity: day
dimensions:
{_metric_dim}
description: Daily event activity by item
tags:
  - engagement
  - metric
terms:
  - glossary.event_activity
  - glossary.daily_events
""";dq_models['full_model']=f"""# Data quality example generated by `vulcan init`
kind: dq
name: full_model_dq
depends_on: {full_model_name}

profiles:
  - {c_item_id}
  - {c_num_orders}

filter: {c_item_id} > 0

rules:
  - missing_count({c_item_id}) = 0:
      name: no_missing_item_ids
      dimension: completeness
      description: All rows must have an item_id

  - duplicate_count({c_item_id}) = 0:
      name: unique_item_ids
      dimension: uniqueness
      description: item_id must be unique in the full model

  - failed rows:
      name: negative_order_counts
      dimension: validity
      fail query: |
        SELECT {c_item_id}, {c_num_orders}
        FROM {full_model_name}
        WHERE {c_num_orders} < 0
      samples limit: 10
      description: Order counts must not be negative
""";plugins:t.Dict[str,str]={};plugins['auth_ext']='from __future__ import annotations\n\nfrom schema.auth import AuthExtensionContext, SecurityContext\n\nROLE_ID_TAG_PREFIX = "roles:id:"\n\n\nasync def resolve_user_groups(ctx: AuthExtensionContext) -> SecurityContext:\n    """Derive the group from Heimdall role tags for use in access policies.\n\n    Map the first matching \'roles:id:<name>\' tag to a group name.\n    Return a default group when no tags match so every request has a context.\n    """\n    groups = [\n        tag.replace(ROLE_ID_TAG_PREFIX, "role:", 1)\n        for tag in ctx.user_tags\n        if tag.startswith(ROLE_ID_TAG_PREFIX)\n    ]\n    group = groups[0] if groups else "analyst"\n    return SecurityContext(group=group)\n';policies:t.Dict[str,str]={};policies['access/incremental_model_masking']=f"""# Access policy example generated by `vulcan init`
type: policy
name: incremental_model_masking
depends_on:
  - {incremental_model_name}

rules:
  - group: admin
  - group: analyst
    mask:
      - {c_id}
      - {c_event_date}
    filter:
      - member: {c_item_id}
        operator: gt
        values:
          - 0
""";return ExampleObjects(sql_models=sql_models,python_models=python_models,seeds=seeds,tests=tests,python_macros=python_macros,sql_macros=sql_macros,semantic_models=semantic_models,metric_models=metric_models,dq_models=dq_models,policies=policies,plugins=plugins)
def init_example_project(path:t.Union[str,Path],engine_type:t.Optional[str],dialect:t.Optional[str]=_A,template:ProjectTemplate=ProjectTemplate.DEFAULT,schema_name:str='vulcan_example',cli_mode:InitCliMode=InitCliMode.DEFAULT,start:t.Optional[str]=_A,tenant:t.Optional[str]=_A,name:t.Optional[str]=_A,description:t.Optional[str]=_A)->Path:
	C='sql';B='yml';A='py';root_path=Path(path);resolved_root_path=root_path.absolute();project_name=(name or resolved_root_path.name or root_path.name).strip()
	if not project_name:project_name='vulcan_project'
	project_tenant=(tenant or os.getenv('DATAOS_TENANT_ID')or _C).strip()
	if not project_tenant:project_tenant=_C
	project_description=(description or f"{project_name} Vulcan project.").strip()
	if not project_description:project_description=f"{project_name} Vulcan project."
	config_path=root_path/'config.yaml';audits_path=root_path/'audits';macros_path=root_path/'macros';models_path=root_path/'models';semantic_models_path=models_path/'semantics';metric_models_path=models_path/'metrics';dq_models_path=root_path/'dq';seeds_path=root_path/'seeds';tests_path=root_path/'tests';policies_path=root_path/'policies';plugins_path=root_path/'plugins'
	if config_path.exists():raise VulcanError(f"Found an existing config file '{config_path}'.\n\nPlease change to another directory or remove the existing file.")
	engine_types="', '".join(CONNECTION_CONFIG_TO_TYPE)
	if engine_type is _A:raise VulcanError(f"Missing `engine` argument to `vulcan init` - please specify a SQL engine for your project. Options: '{engine_types}'.")
	if engine_type and engine_type not in CONNECTION_CONFIG_TO_TYPE:raise VulcanError(f"Invalid engine '{engine_type}'. Please specify one of '{engine_types}'.")
	_create_config(config_path=config_path,engine_type=engine_type,dialect=dialect,settings=_A,start=start,template=template,cli_mode=cli_mode,tenant=project_tenant,name=project_name,description=project_description);_create_usage_file(root_path/'usage.yml',with_examples=template!=ProjectTemplate.EMPTY);_create_agreement_file(root_path/'agreement.md',with_examples=template!=ProjectTemplate.EMPTY);_create_gitignore(root_path/'.gitignore');_create_folders([audits_path,macros_path,models_path,semantic_models_path,metric_models_path,dq_models_path,seeds_path,tests_path,policies_path,plugins_path]);example_objects=_gen_example_objects(schema_name=schema_name,uppercase_columns=engine_type=='snowflake')
	if template!=ProjectTemplate.EMPTY:_create_object_files(models_path,example_objects.sql_models,C);_create_object_files(models_path,example_objects.python_models,A);_create_object_files(seeds_path,example_objects.seeds,'csv');_create_object_files(tests_path,example_objects.tests,'yaml');_create_object_files(macros_path,example_objects.python_macros,A);_create_object_files(macros_path,example_objects.sql_macros,C);_create_object_files(semantic_models_path,example_objects.semantic_models,B);_create_object_files(metric_models_path,example_objects.metric_models,B);_create_object_files(dq_models_path,example_objects.dq_models,B);_create_policy_files(policies_path,example_objects.policies);_create_object_files(plugins_path,example_objects.plugins,A)
	return config_path
_GITIGNORE_BLOCK='# Vulcan runtime\n.vulcan/\n.cache/\n.logs/\n\n# Local warehouse / state databases\n*.db\n*.duckdb\n\n# Environment / secrets\n.env\n.env.local\n.env.*.local\n\n# OS / editor\n.DS_Store\n'
_GITIGNORE_PATTERNS=tuple(line for line in _GITIGNORE_BLOCK.splitlines()if line and not line.startswith('#'))
def _create_gitignore(path:Path)->_A:
	A='\n'
	if not path.exists():_write_file(path,_GITIGNORE_BLOCK);return
	content=path.read_text(encoding='utf-8');existing=set(content.splitlines());missing=[pattern for pattern in _GITIGNORE_PATTERNS if pattern not in existing]
	if not missing:return
	separator=''if not content or content.endswith(A)else A;addition=A.join(['# Vulcan',*missing])+A;_write_file(path,f"{content}{separator}{addition}")
def _create_folders(target_folders:t.Sequence[Path])->_A:
	for folder_path in target_folders:folder_path.mkdir(exist_ok=_B);(folder_path/'.gitkeep').touch()
def _create_config(config_path:Path,engine_type:t.Optional[str],dialect:t.Optional[str],settings:t.Optional[str],start:t.Optional[str],template:ProjectTemplate,cli_mode:InitCliMode,tenant:str,name:str,description:str)->_A:project_config=_gen_config(engine_type=engine_type,settings=settings,start=start,template=template,cli_mode=cli_mode,tenant=tenant,name=name,description=description,dialect=dialect);_write_file(config_path,project_config)
def _create_object_files(path:Path,object_dict:t.Dict[str,str],file_extension:str)->_A:
	for(object_name,object_def)in object_dict.items():_write_file(path/f"{object_name.split('.')[-1]}.{file_extension}",object_def)
def _create_policy_files(policies_path:Path,policies:t.Dict[str,str])->_A:
	for(policy_key,policy_def)in policies.items():parts=policy_key.split('/');subdir=policies_path/'/'.join(parts[:-1])if len(parts)>1 else policies_path;subdir.mkdir(parents=_B,exist_ok=_B);_write_file(subdir/f"{parts[-1]}.yml",policy_def)
def _create_usage_file(path:Path,*,with_examples:bool)->_A:
	if with_examples:payload='# Business outcomes this product is meant to enable. Plain strings, not KPI targets.\nobjectives:\n  - Provide a governed daily view of event activity for analytics\n  - Support self-serve reporting on item-level engagement\n\n# Strategic programs or architecture choices this product supports. Distinct from\n# tags (search labels) and terms (glossary references).\nalignments:\n  - Source-aligned event and usage domain model\n  - Starter analytics enablement initiative\n\n# Display-only pricing for catalog/marketplace listings. unit uses opendataproducts.org\n# pricing-model labels as free text (free, subscription, usage). Vulcan does not bill.\npricing_plans:\n  - name: Internal Usage\n    unit: free\n    notes: Employee and partner use only; not for external distribution\n\n# Intended use cases and audiences. Each entry is a title plus optional details.\ngood_for:\n  - title: Event activity reporting\n    details: |\n      Daily counts of events by item via the total_events measure and the\n      event_activity metric. Suitable for engagement dashboards and trend reviews.\n  - title: Item-level aggregation\n    details: |\n      Group activity by item_id to compare event volume across items over time.\n\n# Use cases where this product is a poor fit. Pair with caveats when freshness or\n# grain limits the answer.\nnot_for:\n  - title: Real-time monitoring\n    details: |\n      Models refresh on a @daily cron. Do not use for sub-minute freshness,\n      alerting, or intraday operational decisions.\n  - title: User-level behavioural analysis\n    details: |\n      The product exposes aggregated event counts, not per-user event streams.\n\n# Limitations and freshness windows consumers should read before trusting results.\n# severity (low|medium|high) is authoring metadata for display only.\ncaveats:\n  - title: Historical coverage starts 2020-01-01\n    details: |\n      The incremental model backfills from 2020-01-01; earlier periods are empty.\n    severity: medium\n  - title: Daily refresh cadence\n    details: |\n      Tables update once per day; intra-day changes appear on the next successful run.\n    severity: low\n\n# Curated links to docs, dashboards, and runbooks. type is one of\n# doc, design, dashboard, runbook, or other.\nreferences:\n  - title: Documentation\n    url: https://example.com/documentation\n    type: doc\n'
	else:payload='good_for: []\nnot_for: []\ncaveats: []\nreferences: []\n'
	_write_file(path,payload)
def _create_agreement_file(path:Path,*,with_examples:bool)->_A:
	if with_examples:payload='# Data Product Usage Agreement — Internal Analytics Only\n\nThis agreement governs your access to and use of **[Dataset/Data Product Name]** ("the Data Product") within **[Organization Name]**. Read it before proceeding. Accepting grants you access under the terms below; rejecting will end this request and no access will be provisioned.\n\n## 1. Grant of Access\n\nSubject to your acceptance of this agreement, you are granted access to the Data Product solely for the purpose of generating organizational insights for internal decision-making, including analysis, reporting, dashboarding, and strategic planning conducted on behalf of [Organization Name].\n\n## 2. Scope of Permitted Use\n\nYou may query, analyze, visualize, and report on the Data Product strictly within the purpose stated in Section 1. Any aggregate or derived output you create from the Data Product remains subject to this same scope of use.\n\n## 3. Prohibited Use\n\nYou agree that you will not:\n\n- share, publish, export, or distribute the Data Product, or any derivative of it, outside the organization, in raw or processed form;\n- use the Data Product to train, fine-tune, or evaluate any machine learning model, unless that use has been separately approved in writing;\n- attempt to re-identify individuals from anonymized or pseudonymized fields;\n- use the Data Product to profile individual employees or customers beyond the analytical purpose stated in Section 1;\n- resell, sublicense, or otherwise commercially exploit the Data Product.\n\n## 4. Data Handling\n\nYou agree to access and store the Data Product only within approved internal systems. You will not copy the Data Product, or any extract of it, to personal devices, unmanaged cloud storage, or third-party tools outside existing organizational agreements. Where you export data for reporting purposes, you agree to include only the minimum data necessary to support the report.\n\n## 5. Retention\n\nYou agree to delete any extract or derivative dataset you create once your specific analysis is complete, unless a documented business need requires retention. The source Data Product remains governed by the organization\'s standard retention schedule.\n\n## 6. Attribution\n\nAny report, insight, or output derived from the Data Product must cite the dataset name and the version or timestamp used.\n\n## 7. Monitoring and Enforcement\n\nAccess to the Data Product is logged. Use inconsistent with this agreement will be treated as a data governance incident, may result in immediate revocation of access, and may be escalated under [Organization Name]\'s standard policy violation procedures.\n\n## 8. Duration\n\nThis agreement remains in effect for the duration of your access to the Data Product and applies to any data or derivatives retained after access ends.\n'
	else:payload='# Data Product Usage Agreement\n'
	_write_file(path,payload)
def _write_file(path:Path,payload:str)->_A:
	with open(path,'w',encoding='utf-8')as fd:fd.write(payload)
def interactive_init(path:Path,console:Console,project_template:t.Optional[ProjectTemplate]=_A)->t.Tuple[ProjectTemplate,t.Optional[str],t.Optional[InitCliMode]]:console.print('──────────────────────────────');console.print('Welcome to Vulcan!');project_template=_init_template_prompt(console)if not project_template else project_template;engine_type=_init_engine_prompt(console);cli_mode=_init_cli_mode_prompt(console);return project_template,engine_type,cli_mode
def _init_integer_prompt(console:Console,err_msg_entity:str,num_options:int,retry_func:t.Callable[[t.Any],t.Any])->int:
	err_msg="\nERROR: '{option_str}' is not a valid {err_msg_entity} number - please enter a number between 1 and {num_options} or exit with control+c\n"
	while _B:
		option_str=Prompt.ask('Enter a number',console=console);value_error=False
		try:option_num=int(option_str)
		except ValueError:value_error=_B
		if value_error or option_num<1 or option_num>num_options:console.print(err_msg.format(option_str=option_str,err_msg_entity=err_msg_entity,num_options=num_options),style='red');continue
		console.print('');return option_num
def _init_display_choices(values_dict:t.Dict[str,str],console:Console)->t.Dict[int,str]:
	display_num_to_value={}
	for(i,value_str)in enumerate(values_dict.keys()):console.print(f"    \\[{i+1}] {' 'if i<9 else''}{value_str} {values_dict[value_str]}");display_num_to_value[i+1]=value_str
	console.print('');return display_num_to_value
def _init_template_prompt(console:Console)->ProjectTemplate:console.print(_D);console.print('What type of project do you want to set up?\n');template_descriptions={ProjectTemplate.DEFAULT.name:'- Create Vulcan example project models and files',ProjectTemplate.EMPTY.name:'  - Create a Vulcan configuration file and project directories only'};display_num_to_template=_init_display_choices(template_descriptions,console);template_num=_init_integer_prompt(console,'project type',len(template_descriptions),_init_template_prompt);return ProjectTemplate(display_num_to_template[template_num].lower())
def _init_engine_prompt(console:Console)->str:console.print(_D);console.print('Choose your SQL engine:\n');DISPLAY_NAME_TO_TYPE={v[1]:k for(k,v)in INIT_DISPLAY_INFO_TO_TYPE.items()};ordered_engine_display_names={info[1]:''for info in sorted(INIT_DISPLAY_INFO_TO_TYPE.values(),key=lambda x:x[0])};display_num_to_display_name=_init_display_choices(ordered_engine_display_names,console);engine_num=_init_integer_prompt(console,'engine',len(ordered_engine_display_names),_init_engine_prompt);return DISPLAY_NAME_TO_TYPE[display_num_to_display_name[engine_num]]
def _init_cli_mode_prompt(console:Console)->InitCliMode:console.print(_D);console.print('Choose your Vulcan CLI experience:\n');cli_mode_descriptions={InitCliMode.DEFAULT.name:'- See and control every detail',InitCliMode.FLOW.name:'   - Automatically run changes and show summary output'};display_num_to_cli_mode=_init_display_choices(cli_mode_descriptions,console);cli_mode_num=_init_integer_prompt(console,'config',len(cli_mode_descriptions),_init_cli_mode_prompt);return InitCliMode(display_num_to_cli_mode[cli_mode_num].lower())