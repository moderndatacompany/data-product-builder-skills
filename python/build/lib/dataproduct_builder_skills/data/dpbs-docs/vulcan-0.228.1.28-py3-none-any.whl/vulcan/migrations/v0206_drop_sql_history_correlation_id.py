import typing as t
from sqlglot import exp
def _sql_history_table(schema:t.Optional[str])->str:return f"{schema}._sql_history"if schema else'_sql_history'
def migrate_schemas(engine_adapter,schema,**kwargs):
	A='correlation_id';table=_sql_history_table(schema)
	if not engine_adapter.table_exists(table):return
	columns=engine_adapter.columns(table)
	if A not in columns:return
	engine_adapter.execute(exp.Alter(this=exp.to_table(table),kind='TABLE',actions=[exp.Drop(this=exp.to_column(A),exists=True,kind='COLUMN')]))
def migrate_rows(engine_adapter,schema,**kwargs):0