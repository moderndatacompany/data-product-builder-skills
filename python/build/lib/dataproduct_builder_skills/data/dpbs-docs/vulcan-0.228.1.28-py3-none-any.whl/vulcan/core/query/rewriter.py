from __future__ import annotations
_C='physical'
_B=False
_A=None
import typing as t
from dataclasses import dataclass
from sqlglot import exp,parse_one
from sqlglot.errors import ParseError
from sqlglot.optimizer.scope import traverse_scope
from schema.auth import SecurityContext
from schema.filters import PolicyEntry,PolicyFilterExpression,PolicyLogicalFilter,PolicyUnaryFilter
from schema.filters.operators import FilterOperator
from schema.metadata import Index,Metadata,ModelEntry,PhysicalDetails
from vulcan.core.dialect import find_tables_unquoted,fqn_to_unquoted,normalize_model_name
from vulcan.core.query.lineage import resolve_referenced_models
from vulcan.core.query.policy_context import policy_for_group,resolve_filter_value,validate_policy_context_keys
from vulcan.core.query.validator import POLICY_CTE_PREFIX,QueryValidator
from vulcan.utils.errors import AccessDenied,PolicySecurityContextIncomplete,QueryValidationError,RewriteError
@dataclass(frozen=True)
class RewriteResult:original_sql:str;rewritten_sql:str;depends_on:tuple[str,...];group:str;policy_ctes:tuple[str,...];protected_models:frozenset[str];user:str
def rewrite(*,sql:str,user:str,metadata:Metadata,security_context:SecurityContext,dialect:str|_A=_A,default_catalog:str|_A=_A)->RewriteResult:
	A='PARSE_ERROR';sql_dialect=(dialect or metadata.gateway.dialect or'').strip()
	if not sql_dialect:raise QueryValidationError(A,'dialect is unset; pass dialect or configure metadata.gateway.dialect')
	warehouse_validator=QueryValidator(metadata=metadata,dialect=sql_dialect,default_catalog=default_catalog);warehouse_validator.validate(sql);depends_on_models=resolve_referenced_models(sql,metadata=metadata,dialect=sql_dialect,default_catalog=default_catalog);caller_group=(security_context.group or'').strip();_check_policy_access(depends_on=depends_on_models,metadata=metadata,caller_group=caller_group);validate_policy_context_keys(models=depends_on_models,metadata=metadata,group=caller_group,security_context=security_context)
	try:query_expression=parse_one(sql,dialect=sql_dialect)
	except ParseError as exc:raise QueryValidationError(A,f"Failed to parse SQL: {exc}")from exc
	query_table_fqns=find_tables_unquoted(query_expression,default_catalog=default_catalog,dialect=sql_dialect);metadata_index=metadata.index;model_to_policy_cte:dict[str,str]={};policy_cte_expressions:list[exp.CTE]=[];models_with_policy_applied:set[str]=set();query_table_to_model={table_fqn:model_name for table_fqn in query_table_fqns if(model_name:=_model_for_table(table_fqn,index=metadata_index,dialect=sql_dialect))and model_name in depends_on_models}
	for model_name in sorted(depends_on_models):
		if metadata_index.protected_models.get(model_name)is _A:continue
		model_entry=metadata.require_entry(model_name);group_policy=policy_for_group(model_entry,caller_group)
		if group_policy is _A or not(group_policy.filter or group_policy.mask):continue
		policy_cte_alias=f"{POLICY_CTE_PREFIX}{model_name.replace('.','_')}";policy_cte_expressions.append(_build_policy_cte(model_entry,group_policy,cte_name=policy_cte_alias,dialect=sql_dialect,security_context=security_context));model_to_policy_cte[model_name]=policy_cte_alias;models_with_policy_applied.add(model_name)
	rewritten_expression=query_expression
	if model_to_policy_cte:rewritten_expression=_substitute_policy_ctes(rewritten_expression,policy_cte_nodes=policy_cte_expressions,model_name_to_cte_alias=model_to_policy_cte,table_fqn_to_model=query_table_to_model,dialect=sql_dialect,default_catalog=default_catalog)
	rewritten_sql=rewritten_expression.sql(dialect=sql_dialect,pretty=True,comments=_B);return RewriteResult(original_sql=sql,rewritten_sql=rewritten_sql,depends_on=depends_on_models,group=caller_group,policy_ctes=tuple(model_to_policy_cte.values()),protected_models=frozenset(models_with_policy_applied),user=user)
def _check_policy_access(*,depends_on:t.Sequence[str],metadata:Metadata,caller_group:str)->_A:
	A='(empty)';protected=metadata.index.protected_models
	if not protected:return
	for model_name in sorted(depends_on):
		allowed_groups=protected.get(model_name)
		if allowed_groups is _A:continue
		if not caller_group or caller_group not in allowed_groups:raise AccessDenied(model=model_name,group=caller_group or A,allowed_groups=sorted(allowed_groups))
		entry=metadata.require_entry(model_name)
		if not policy_for_group(entry,caller_group):raise AccessDenied(model=model_name,group=caller_group or A,allowed_groups=sorted(allowed_groups))
def _model_for_table(table_ref:str,*,index:Index,dialect:str)->str|_A:return index.queryable_tables.get(fqn_to_unquoted(table_ref,dialect=dialect))
def _build_policy_cte(entry:ModelEntry,policy:PolicyEntry,*,cte_name:str,dialect:str,security_context:SecurityContext)->exp.CTE:
	masked=frozenset(policy.mask or());projections:list[exp.Expression]=[]
	for column in entry.columns:
		if column.kind!=_C:continue
		if column.name in masked:
			mask_expression_sql=_mask_expression_for_column(entry,column.name)
			if not mask_expression_sql:raise RewriteError(f"model {entry.name!r} masks column {column.name!r} but no mask_expression is configured")
			try:parsed_mask_ast=parse_one(mask_expression_sql,dialect=dialect)
			except Exception as exc:raise RewriteError(f"failed to parse mask expression for column {column.name!r}: {exc}")from exc
			if isinstance(parsed_mask_ast,exp.Alias):masked_projection=parsed_mask_ast.this
			elif isinstance(parsed_mask_ast,exp.Column):masked_projection=parsed_mask_ast
			else:masked_projection=parsed_mask_ast
			projections.append(exp.alias_(masked_projection,column.name,copy=_B))
		else:projections.append(exp.column(column.name))
	row_filter_predicate=_compile_filters(policy.filter,dialect=dialect,security_context=security_context)if policy.filter else _A;policy_select=exp.select(*projections).from_(exp.to_table(entry.name))
	if row_filter_predicate is not _A:policy_select=policy_select.where(row_filter_predicate,copy=_B)
	return exp.CTE(this=policy_select,alias=exp.to_table(cte_name))
def _mask_expression_for_column(entry:ModelEntry,column_name:str)->str|_A:
	for col in entry.columns:
		if col.kind==_C and col.name==column_name and col.details is not _A:
			if isinstance(col.details,PhysicalDetails):return col.details.mask_expression
def _compile_filters(filters:t.Sequence[PolicyFilterExpression],*,dialect:str,security_context:SecurityContext)->exp.Expression|_A:
	if not filters:return
	predicates=[_compile_filter_expression(expr,dialect=dialect,security_context=security_context)for expr in filters]
	if len(predicates)==1:return predicates[0]
	return exp.and_(*predicates)
def _compile_filter_expression(expr:PolicyFilterExpression,*,dialect:str,security_context:SecurityContext)->exp.Expression:
	if isinstance(expr,PolicyUnaryFilter):return _compile_unary_filter(expr,dialect=dialect,security_context=security_context)
	if isinstance(expr,PolicyLogicalFilter):
		child_predicates=expr.and_ or expr.or_ or[];compiled_children=[_compile_filter_expression(child,dialect=dialect,security_context=security_context)for child in child_predicates]
		if expr.and_:return exp.and_(*compiled_children)
		return exp.or_(*compiled_children)
	raise RewriteError(f"unsupported policy filter expression: {type(expr).__name__}")
def _compile_unary_filter(unary_filter:PolicyUnaryFilter,*,dialect:str,security_context:SecurityContext)->exp.Expression:
	column=exp.column(unary_filter.field_name);operator=unary_filter.operator;values=[resolve_filter_value(value,security_context)for value in unary_filter.values or[]]
	if operator==FilterOperator.EQUALS:
		if len(values)==1:return exp.EQ(this=column,expression=_literal(values[0],dialect=dialect))
		return exp.or_(*[exp.EQ(this=column.copy(),expression=_literal(value,dialect=dialect))for value in values])
	if operator==FilterOperator.NOT_EQUALS:
		if len(values)==1:return exp.NEQ(this=column,expression=_literal(values[0],dialect=dialect))
		return exp.and_(*[exp.NEQ(this=column.copy(),expression=_literal(value,dialect=dialect))for value in values])
	if operator==FilterOperator.IN:return exp.In(this=column,expressions=[_literal(v,dialect=dialect)for v in values])
	if operator==FilterOperator.NOT_IN:return exp.Not(this=exp.In(this=column,expressions=[_literal(v,dialect=dialect)for v in values]))
	if operator==FilterOperator.GT:return exp.GT(this=column,expression=_literal(values[0],dialect=dialect))
	if operator==FilterOperator.GTE:return exp.GTE(this=column,expression=_literal(values[0],dialect=dialect))
	if operator==FilterOperator.LT:return exp.LT(this=column,expression=_literal(values[0],dialect=dialect))
	if operator==FilterOperator.LTE:return exp.LTE(this=column,expression=_literal(values[0],dialect=dialect))
	if operator==FilterOperator.SET:return exp.not_(exp.Is(this=column,expression=exp.Null()))
	if operator==FilterOperator.NOT_SET:return exp.Is(this=column,expression=exp.Null())
	if operator==FilterOperator.CONTAINS:return exp.ILike(this=column,expression=exp.Literal.string(f"%{values[0]}%"))
	if operator==FilterOperator.NOT_CONTAINS:return exp.not_(exp.ILike(this=column,expression=exp.Literal.string(f"%{values[0]}%")))
	if operator==FilterOperator.STARTS_WITH:return exp.ILike(this=column,expression=exp.Literal.string(f"{values[0]}%"))
	if operator==FilterOperator.NOT_STARTS_WITH:return exp.not_(exp.ILike(this=column,expression=exp.Literal.string(f"{values[0]}%")))
	if operator==FilterOperator.ENDS_WITH:return exp.ILike(this=column,expression=exp.Literal.string(f"%{values[0]}"))
	if operator==FilterOperator.NOT_ENDS_WITH:return exp.not_(exp.ILike(this=column,expression=exp.Literal.string(f"%{values[0]}")))
	if operator==FilterOperator.IN_DATE_RANGE:start,end=_date_range_bounds(values);return _inclusive_date_range(column,start,end,dialect=dialect)
	if operator==FilterOperator.NOT_IN_DATE_RANGE:start,end=_date_range_bounds(values);return exp.not_(_inclusive_date_range(column,start,end,dialect=dialect))
	if operator==FilterOperator.ON_THE_DATE:day=values[0];return _inclusive_date_range(column,day,day,dialect=dialect)
	if operator==FilterOperator.BEFORE_DATE:return exp.LT(this=column,expression=_literal(values[0],dialect=dialect))
	if operator==FilterOperator.BEFORE_OR_ON_DATE:return exp.LTE(this=column,expression=_literal(values[0],dialect=dialect))
	if operator==FilterOperator.AFTER_DATE:return exp.GT(this=column,expression=_literal(values[0],dialect=dialect))
	if operator==FilterOperator.AFTER_OR_ON_DATE:return exp.GTE(this=column,expression=_literal(values[0],dialect=dialect))
	raise RewriteError(f"unsupported policy filter operator: {operator.value}")
def _date_range_bounds(values:list[t.Any])->tuple[t.Any,t.Any]:
	if not values:raise RewriteError('date range operators require at least one value')
	if len(values)==1:return values[0],values[0]
	return values[0],values[1]
def _inclusive_date_range(column:exp.Column,start:t.Any,end:t.Any,*,dialect:str)->exp.Expression:return exp.and_(exp.GTE(this=column.copy(),expression=_literal(start,dialect=dialect)),exp.LTE(this=column.copy(),expression=_literal(end,dialect=dialect)))
def _literal(value:t.Any,*,dialect:str)->exp.Expression:
	if value is _A:return exp.Null()
	if isinstance(value,bool):return exp.Boolean(this=value)
	if isinstance(value,int):return exp.Literal.number(value)
	if isinstance(value,float):return exp.Literal.number(str(value))
	return exp.Literal.string(str(value))
def _substitute_policy_ctes(expression:exp.Expression,*,policy_cte_nodes:t.Sequence[exp.CTE],model_name_to_cte_alias:t.Mapping[str,str],table_fqn_to_model:t.Mapping[str,str],dialect:str,default_catalog:str|_A=_A)->exp.Expression:
	A='with';table_fqn_to_policy_cte={table_fqn:cte_alias for(table_fqn,model_name)in table_fqn_to_model.items()if(cte_alias:=model_name_to_cte_alias.get(model_name))}
	if not table_fqn_to_policy_cte:return expression
	rewritten_ast=expression.copy()
	for scope in traverse_scope(rewritten_ast):
		for table in scope.tables:
			if not table.name or table.name in scope.cte_sources:continue
			table_fqn=_normalized_table_name(table,dialect,default_catalog=default_catalog);cte_alias=table_fqn_to_policy_cte.get(table_fqn)
			if cte_alias is _A:continue
			table.set('this',exp.to_identifier(cte_alias));table.set('db',_A);table.set('catalog',_A)
	expected_substituted_table_fqns=set(table_fqn_to_policy_cte)
	for scope in traverse_scope(rewritten_ast):
		for table in scope.tables:
			if not table.name or table.name in scope.cte_sources:continue
			table_fqn=_normalized_table_name(table,dialect,default_catalog=default_catalog)
			if table_fqn in expected_substituted_table_fqns:raise RewriteError(f"protected table {table_fqn!r} was not rewritten to a policy CTE")
	if not policy_cte_nodes:return rewritten_ast
	user_with_clause=rewritten_ast.args.get(A)
	if user_with_clause:user_with_clause.set('expressions',list(policy_cte_nodes)+list(user_with_clause.expressions))
	else:rewritten_ast.set(A,exp.With(expressions=list(policy_cte_nodes)))
	return rewritten_ast
def _normalized_table_name(table:exp.Table,dialect:str,*,default_catalog:str|_A=_A)->str:
	if not table.name:return''
	return fqn_to_unquoted(normalize_model_name(table,default_catalog=default_catalog,dialect=dialect),dialect=dialect)