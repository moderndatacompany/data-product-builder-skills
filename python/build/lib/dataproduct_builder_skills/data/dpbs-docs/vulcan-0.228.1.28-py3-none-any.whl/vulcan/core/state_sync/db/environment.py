from __future__ import annotations
_W='requirements'
_V='gateway_managed'
_U='boolean'
_T='normalize_name'
_S='previous_finalized_snapshots'
_R='catalog_name_override'
_Q='suffix_target'
_P='promoted_snapshot_ids'
_O='bigint'
_N='previous_plan_id'
_M='end_at'
_L='start_at'
_K='snapshots'
_J='environment_statements'
_I='finalized_ts'
_H='expiration_ts'
_G='plan_id'
_F='environment_name'
_E=False
_D='text'
_C='name'
_B=True
_A=None
import typing as t,json,logging
from sqlglot import exp
from vulcan.core import constants as c
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.core.state_sync.db.utils import fetchall,fetchone
from vulcan.core.environment import Environment,EnvironmentStatements,EnvironmentSummary
from vulcan.utils.date import now_timestamp,time_like_to_str
from vulcan.utils.errors import VulcanError
if t.TYPE_CHECKING:import pandas as pd
logger=logging.getLogger(__name__)
ENVIRONMENTS=TableSpec(name='_environments',primary_key=(_C,),columns=(ColumnSpec(_C,indexed=_B),ColumnSpec(_K,blob=_B),ColumnSpec(_L,_D),ColumnSpec(_M,_D),ColumnSpec(_G,_D),ColumnSpec(_N,_D),ColumnSpec(_H,_O),ColumnSpec(_I,_O),ColumnSpec(_P,blob=_B),ColumnSpec(_Q,_D),ColumnSpec(_R,_D),ColumnSpec(_S,blob=_B),ColumnSpec(_T,_U),ColumnSpec(_V,_U),ColumnSpec(_W,blob=_B)))
ENVIRONMENT_STATEMENTS=TableSpec(name='_environment_statements',primary_key=(_F,),columns=(ColumnSpec(_F,indexed=_B),ColumnSpec(_G,_D),ColumnSpec(_J,blob=_B)))
class EnvironmentState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A):self.engine_adapter=engine_adapter;self.environments_table=exp.table_(ENVIRONMENTS.name,db=schema);self.environment_statements_table=exp.table_(ENVIRONMENT_STATEMENTS.name,db=schema);dialect=engine_adapter.dialect;self._environment_columns_to_types=ENVIRONMENTS.columns_to_types(dialect);self._environment_statements_columns_to_types=ENVIRONMENT_STATEMENTS.columns_to_types(dialect)
	def update_environment(self,environment:Environment)->_A:self.engine_adapter.delete_from(self.environments_table,where=exp.EQ(this=exp.column(_C),expression=exp.Literal.string(environment.name)));self.engine_adapter.insert_append(self.environments_table,_environment_to_df(environment),target_columns_to_types=self._environment_columns_to_types,track_rows_processed=_E)
	def update_environment_statements(self,environment_name:str,plan_id:str,environment_statements:t.List[EnvironmentStatements])->_A:
		self.engine_adapter.delete_from(self.environment_statements_table,where=exp.EQ(this=exp.column(_F),expression=exp.Literal.string(environment_name)))
		if environment_statements:self.engine_adapter.insert_append(self.environment_statements_table,_environment_statements_to_df(environment_name,plan_id,environment_statements),target_columns_to_types=self._environment_statements_columns_to_types,track_rows_processed=_E)
	def invalidate_environment(self,name:str,protect_prod:bool=_B)->_A:
		name=name.lower()
		if protect_prod and name==c.PROD:raise VulcanError('Cannot invalidate the production environment.')
		filter_expr=exp.column(_C).eq(name);self.engine_adapter.update_table(self.environments_table,{_H:now_timestamp()},where=filter_expr)
	def finalize(self,environment:Environment)->_A:
		logger.info("Finalizing environment '%s'",environment.name);environment_filter=exp.column(_C).eq(exp.Literal.string(environment.name));stored_plan_id_query=exp.select(_G).from_(self.environments_table).where(environment_filter,copy=_E).lock(copy=_E);stored_plan_id_row=fetchone(self.engine_adapter,stored_plan_id_query)
		if not stored_plan_id_row:raise VulcanError(f"Missing environment '{environment.name}' can't be finalized")
		stored_plan_id=stored_plan_id_row[0]
		if stored_plan_id!=environment.plan_id:raise VulcanError(f"Another plan ({stored_plan_id}) was applied to the target environment '{environment.name}' while your current plan ({environment.plan_id}) was still in progress, interrupting it. Please re-apply your plan to resolve this error.")
		environment.finalized_ts=now_timestamp();self.engine_adapter.update_table(self.environments_table,{_I:environment.finalized_ts},where=environment_filter)
	def get_expired_environments(self,current_ts:int)->t.List[EnvironmentSummary]:return self._fetch_environment_summaries(where=self._create_expiration_filter_expr(current_ts))
	def delete_expired_environments(self,current_ts:t.Optional[int]=_A)->t.List[EnvironmentSummary]:
		current_ts=current_ts or now_timestamp();expired_environments=self.get_expired_environments(current_ts=current_ts);self.engine_adapter.delete_from(self.environments_table,where=self._create_expiration_filter_expr(current_ts))
		if(expired_environments_exprs:=[exp.EQ(this=exp.column(_F),expression=exp.Literal.string(env.name))for env in expired_environments]):self.engine_adapter.delete_from(self.environment_statements_table,where=exp.or_(*expired_environments_exprs))
		return expired_environments
	def get_environments(self)->t.List[Environment]:return[self._environment_from_row(row)for row in fetchall(self.engine_adapter,self._environments_query())]
	def get_environments_summary(self)->t.List[EnvironmentSummary]:return self._fetch_environment_summaries()
	def get_environment(self,environment:str,lock_for_update:bool=_E)->t.Optional[Environment]:
		row=fetchone(self.engine_adapter,self._environments_query(where=exp.EQ(this=exp.column(_C),expression=exp.Literal.string(environment)),lock_for_update=lock_for_update))
		if not row:return
		env=self._environment_from_row(row);return env
	def get_environment_statements(self,environment:str)->t.List[EnvironmentStatements]:
		query=exp.select(exp.to_identifier(_J)).from_(self.environment_statements_table).where(exp.EQ(this=exp.column(_F),expression=exp.Literal.string(environment)));result=fetchone(engine_adapter=self.engine_adapter,query=query)
		if result and(statements:=json.loads(result[0])):return[EnvironmentStatements.parse_obj(environment_statements)for environment_statements in statements]
		return[]
	def _environment_from_row(self,row:t.Tuple[str,...])->Environment:return Environment(**{field:row[i]for(i,field)in enumerate(sorted(Environment.all_fields()))})
	def _environment_summmary_from_row(self,row:t.Tuple[str,...])->EnvironmentSummary:return EnvironmentSummary(**{field:row[i]for(i,field)in enumerate(sorted(EnvironmentSummary.all_fields()))})
	def _environments_query(self,where:t.Optional[str|exp.Expression]=_A,lock_for_update:bool=_E,required_fields:t.Optional[t.List[str]]=_A)->exp.Select:
		query_fields=required_fields if required_fields else sorted(Environment.all_fields());query=exp.select(*(exp.to_identifier(field)for field in query_fields)).from_(self.environments_table).where(where)
		if lock_for_update:return query.lock(copy=_E)
		return query
	def _create_expiration_filter_expr(self,current_ts:int)->exp.Expression:return exp.LTE(this=exp.column(_H),expression=exp.Literal.number(current_ts))
	def _fetch_environment_summaries(self,where:t.Optional[str|exp.Expression]=_A)->t.List[EnvironmentSummary]:return[self._environment_summmary_from_row(row)for row in fetchall(self.engine_adapter,self._environments_query(where=where,required_fields=sorted(EnvironmentSummary.all_fields())))]
def _environment_to_df(environment:Environment)->pd.DataFrame:import pandas as pd;return pd.DataFrame([{_C:environment.name,_K:json.dumps(environment.snapshot_dicts()),_L:time_like_to_str(environment.start_at),_M:time_like_to_str(environment.end_at)if environment.end_at else _A,_G:environment.plan_id,_N:environment.previous_plan_id,_H:environment.expiration_ts,_I:environment.finalized_ts,_P:json.dumps(environment.promoted_snapshot_id_dicts())if environment.promoted_snapshot_ids is not _A else _A,_Q:environment.suffix_target.value,_R:environment.catalog_name_override,_S:json.dumps(environment.previous_finalized_snapshot_dicts())if environment.previous_finalized_snapshots is not _A else _A,_T:environment.normalize_name,_V:environment.gateway_managed,_W:json.dumps(environment.requirements)}])
def _environment_statements_to_df(environment_name:str,plan_id:str,environment_statements:t.List[EnvironmentStatements])->pd.DataFrame:import pandas as pd;return pd.DataFrame([{_F:environment_name,_G:plan_id,_J:json.dumps([e.dict()for e in environment_statements])}])