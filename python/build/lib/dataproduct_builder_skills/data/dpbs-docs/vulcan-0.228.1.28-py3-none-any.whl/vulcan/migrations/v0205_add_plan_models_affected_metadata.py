import typing as t
from sqlglot import exp
def _plans_table(schema:t.Optional[str])->str:return f"{schema}._plans"if schema else'_plans'
def migrate_schemas(engine_adapter,schema,**kwargs):
	A='models_affected_metadata';plans_table=_plans_table(schema);engine_adapter.execute(exp.Alter(this=exp.to_table(plans_table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column(A),kind=exp.DataType.build('ARRAY<TEXT>'))]))
	try:engine_adapter.create_index(plans_table,'idx_plans_models_metadata_gin',(A,),index_type='GIN')
	except Exception:pass
def migrate_rows(engine_adapter,schema,**kwargs):0