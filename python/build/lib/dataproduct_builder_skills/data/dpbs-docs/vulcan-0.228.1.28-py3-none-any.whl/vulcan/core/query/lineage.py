from __future__ import annotations
_A=False
import typing as t
from dataclasses import dataclass
from sqlglot import exp,parse_one
from sqlglot.errors import SqlglotError
from schema.metadata import Index,Metadata
from vulcan.core.dialect import find_tables_unquoted,fqn_to_unquoted
from vulcan.utils.errors import QueryValidationError
@dataclass(frozen=True)
class TableRefPartition:known_models:tuple[str,...];unknown_tables:tuple[str,...]
def resolve_table_to_model(table_fqn:str,index:Index,*,dialect:str,allow_rollups:bool=_A)->str|None:
	normalized=fqn_to_unquoted(table_fqn,dialect=dialect)
	if(model:=index.queryable_tables.get(normalized)):return model
	if allow_rollups and(model:=index.rollup_tables.get(normalized)):return model
def resolve_referenced_models(sql:str,*,metadata:Metadata,dialect:str,default_catalog:str|None,allow_rollups:bool=_A)->tuple[str,...]:expression=_parse_sql(sql,dialect=dialect);table_refs=_extract_tables(expression,default_catalog=default_catalog,dialect=dialect);return _partition_table_refs(table_refs,metadata=metadata,dialect=dialect,allow_rollups=allow_rollups).known_models
def unknown_table_refs(table_refs:t.Iterable[str],*,metadata:Metadata,dialect:str,allow_rollups:bool=_A)->tuple[str,...]:return _partition_table_refs(table_refs,metadata=metadata,dialect=dialect,allow_rollups=allow_rollups).unknown_tables
def _partition_table_refs(table_refs:t.Iterable[str],*,metadata:Metadata,dialect:str,allow_rollups:bool=_A)->TableRefPartition:
	index=metadata.index;known_models:set[str]=set();unknown_tables:list[str]=[]
	for table_ref in table_refs:
		normalized=fqn_to_unquoted(table_ref,dialect=dialect);model_name=resolve_table_to_model(normalized,index,dialect=dialect,allow_rollups=allow_rollups)
		if model_name:known_models.add(model_name)
		else:unknown_tables.append(normalized)
	return TableRefPartition(known_models=tuple(sorted(known_models)),unknown_tables=tuple(sorted(unknown_tables)))
def _parse_sql(sql:str,*,dialect:str)->exp.Expression:
	A='PARSE_ERROR'
	try:return parse_one(sql,read=dialect)
	except SqlglotError as exc:raise QueryValidationError(A,f"Failed to parse SQL: {exc}")from exc
	except Exception as exc:raise QueryValidationError(A,f"Unexpected parse error: {exc}")from exc
def _extract_tables(expression:exp.Expression,*,default_catalog:str|None,dialect:str)->t.Set[str]:
	try:return find_tables_unquoted(expression,default_catalog=default_catalog,dialect=dialect)
	except Exception as exc:raise QueryValidationError('TABLE_EXTRACTION_ERROR',f"Failed to extract tables: {exc}")from exc