import typing as t
from sqlglot import exp
def _plans_table(schema:t.Optional[str])->str:return f"{schema}._plans"if schema else'_plans'
def _runs_table(schema:t.Optional[str])->str:return f"{schema}._runs"if schema else'_runs'
def _dq_results_table(schema:t.Optional[str])->str:return f"{schema}._dq_results"if schema else'_dq_results'
def _add_bigint_column(engine_adapter:t.Any,table:str,column:str)->None:engine_adapter.execute(exp.Alter(this=exp.to_table(table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column(column),kind=exp.DataType.build('bigint'))]))
def migrate_schemas(engine_adapter,schema,**kwargs):
	plans_table=_plans_table(schema);runs_table=_runs_table(schema)
	for column in('count_direct','count_added','count_indirect','count_removed','count_metadata','count_backfills'):_add_bigint_column(engine_adapter,plans_table,column)
	for column in('count_models','count_errors','count_dq_total','count_dq_pass','count_dq_fail','count_dq_warn','count_dq_not_evaluated'):_add_bigint_column(engine_adapter,runs_table,column)
def migrate_rows(engine_adapter,schema,**kwargs):
	if engine_adapter.dialect!='postgres':return
	plans_table=_plans_table(schema);runs_table=_runs_table(schema);dq_results_table=_dq_results_table(schema);engine_adapter.execute(f"""
        UPDATE {plans_table} SET
          count_direct = COALESCE(jsonb_array_length(plan_diff->'changes'->'direct'), 0),
          count_added = COALESCE(jsonb_array_length(plan_diff->'changes'->'added'), 0),
          count_indirect = COALESCE(jsonb_array_length(plan_diff->'changes'->'indirect'), 0),
          count_removed = COALESCE(jsonb_array_length(plan_diff->'changes'->'removed'), 0),
          count_metadata = COALESCE(jsonb_array_length(plan_diff->'changes'->'metadata'), 0),
          count_backfills = COALESCE(jsonb_array_length(plan_diff->'backfills'), 0)
        """);engine_adapter.execute(f"\n        UPDATE {runs_table} SET\n          count_models = COALESCE(cardinality(models_affected), 0),\n          count_errors = COALESCE(jsonb_array_length(run_data->'errors'), 0)\n        ");engine_adapter.execute(f"""
        UPDATE {runs_table} r SET
          count_dq_total = sub.total,
          count_dq_pass = sub.passed,
          count_dq_fail = sub.failed,
          count_dq_warn = sub.warned,
          count_dq_not_evaluated = sub.not_evaluated
        FROM (
          SELECT run_id,
                 COUNT(*) AS total,
                 COUNT(*) FILTER (WHERE outcome = 'pass') AS passed,
                 COUNT(*) FILTER (WHERE outcome IN ('fail', 'error')) AS failed,
                 COUNT(*) FILTER (WHERE outcome = 'warn') AS warned,
                 COUNT(*) FILTER (WHERE outcome = 'not_evaluated') AS not_evaluated
          FROM {dq_results_table}
          GROUP BY run_id
        ) sub
        WHERE r.run_id = sub.run_id
        """)