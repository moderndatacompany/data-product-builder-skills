from __future__ import annotations
_B=None
_A=True
import json,typing as t
from datetime import date,datetime
from decimal import Decimal
from hashlib import sha256
from sqlglot import parse_one
from sqlglot.errors import SqlglotError
from vulcan.utils.errors import QueryValidationError
def _normalize_sql(sql:str,*,dialect:str)->str:
	A='PARSE_ERROR'
	try:expression=parse_one(sql,read=dialect)
	except SqlglotError as exc:raise QueryValidationError(A,f"Failed to parse SQL: {exc}")from exc
	except Exception as exc:raise QueryValidationError(A,f"Unexpected parse error: {exc}")from exc
	try:return expression.sql(dialect=dialect,pretty=_A,comments=False,normalize=_A,normalize_functions='upper')
	except Exception as exc:raise QueryValidationError('NORMALIZATION_ERROR',f"Failed to normalize SQL: {exc}")from exc
def _normalize_params(params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]])->str:
	if params is _B:return''
	return json.dumps(params,sort_keys=_A,separators=(',',':'),default=_default_json_serializer,ensure_ascii=_A)
def sql_fingerprint(*,sql:str,dialect:str,gateway:t.Optional[str]=_B,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=_B)->tuple[str,str]:normalized_sql=_normalize_sql(sql,dialect=dialect);parts=[normalized_sql]if gateway is _B else[gateway,normalized_sql,_normalize_params(params)];fingerprint=sha256(':'.join(parts).encode('utf-8')).hexdigest();return fingerprint,normalized_sql
def _default_json_serializer(obj:t.Any)->str:
	if isinstance(obj,(datetime,date)):return obj.isoformat()
	if isinstance(obj,Decimal):return str(obj)
	if isinstance(obj,bytes):return obj.hex()
	return str(obj)