from __future__ import annotations
_A=False
from dataclasses import dataclass
from sqlglot import exp
from sqlglot.dialects.dialect import DialectType
MAX_TEXT_INDEX_LENGTH={'mysql':'250','tsql':'450'}
def index_text_type(dialect:DialectType)->str:return f"VARCHAR({MAX_TEXT_INDEX_LENGTH[str(dialect)]})"if dialect in MAX_TEXT_INDEX_LENGTH else'TEXT'
def blob_text_type(dialect:DialectType)->str:return'LONGTEXT'if dialect=='mysql'else'TEXT'
@dataclass(frozen=True)
class ColumnSpec:name:str;type:str='text';indexed:bool=_A;blob:bool=_A;nullable:bool=_A;description:str=''
@dataclass(frozen=True)
class TableSpec:
	name:str;columns:tuple[ColumnSpec,...];primary_key:tuple[str,...];description:str=''
	def column_names(self)->list[str]:return[col.name for col in self.columns]
	def columns_to_types(self,dialect:DialectType)->dict[str,exp.DataType]:
		result:dict[str,exp.DataType]={}
		for col in self.columns:
			if col.blob:sql_type=blob_text_type(dialect)
			elif col.indexed:sql_type=index_text_type(dialect)
			else:sql_type=col.type
			result[col.name]=exp.DataType.build(sql_type,nullable=col.nullable)
		return result
	def column_descriptions(self)->dict[str,str]:return{col.name:col.description for col in self.columns if col.description}