from __future__ import annotations
_AW='RisingWave'
_AV='s3_staging_dir'
_AU='region_name'
_AT='aws_secret_access_key'
_AS='aws_access_key_id'
_AR='ClickHouse'
_AQ='http_scheme'
_AP='schema_location_mapping'
_AO='tenant_id'
_AN='Azure SQL'
_AM='authentication'
_AL='driver_name'
_AK='connect_timeout'
_AJ='application_name'
_AI='enable_iam_auth'
_AH='GCP Postgres'
_AG='credentials_provider'
_AF='session_configuration'
_AE='http_headers'
_AD='disable_databricks_connect'
_AC='access_token'
_AB='disable_spark_session'
_AA='Databricks'
_A9='warehouse'
_A8='private_key_path'
_A7='Snowflake'
_A6='DataOS_Vulcan'
_A5='configuration'
_A4='MotherDuck'
_A3='connection'
_A2='type_'
_A1='https'
_A0='catalog_support'
_z='trust_server_certificate'
_y='login_timeout'
_x='charset'
_w='http_path'
_v='server_hostname'
_u='autocommit'
_t='role'
_s='private_key_passphrase'
_r=':memory:'
_q='azuresql'
_p='encrypt'
_o='timeout'
_n='driver'
_m='vulcan'
_l='auth_type'
_k='oauth'
_j='motherduck'
_i='mssql'
_h='gcp_postgres'
_g='risingwave'
_f='fabric'
_e='sslmode'
_d='token'
_c='athena'
_b='pymssql'
_a='redshift'
_Z='authenticator'
_Y='snowflake'
_X='md:'
_W='pyodbc'
_V='databricks'
_U='private_key'
_T='clickhouse'
_S='mysql'
_R='bigquery'
_Q='spark'
_P='before'
_O='trino'
_N='username'
_M='postgres'
_L='duckdb'
_K='catalog'
_J='user'
_I='schema'
_H='port'
_G='host'
_F='password'
_E='database'
_D='type'
_C=True
_B=False
_A=None
import abc,base64,logging,os,importlib,pathlib,re,typing as t
from enum import Enum
from functools import partial
import pydantic
from pydantic import Field
from pydantic_core import from_json
from packaging import version
from sqlglot import exp
from sqlglot.helper import subclasses
from vulcan.core import engine_adapter
from vulcan.core.config.base import BaseConfig
from vulcan.core.config.common import concurrent_tasks_validator,http_headers_validator,compile_regex_mapping
from vulcan.core.engine_adapter.shared import CatalogSupport
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils import debug_mode_enabled,str_to_bool
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import ValidationInfo,field_validator,model_validator,validation_error_message,get_concrete_types_from_typehint
from vulcan.utils.aws import validate_s3_uri
if t.TYPE_CHECKING:from vulcan.core._typing import Self
logger=logging.getLogger(__name__)
RECOMMENDED_STATE_SYNC_ENGINES={_M,_h,_S,_i,_q}
FORBIDDEN_STATE_SYNC_ENGINES={_Q,_O,_T}
MOTHERDUCK_TOKEN_REGEX=re.compile('(\\?|\\&)(motherduck_token=)(\\S*)')
PASSWORD_REGEX=re.compile('(password=)(\\S+)')
SPARK_PROPERTIES_INCLUSION_LIST=frozenset()
SPARK_PROPERTIES_EXCLUSION_LIST=frozenset({'spark.submit.deployMode'})
def _get_engine_import_validator(import_name:str,engine_type:str,extra_name:t.Optional[str]=_A,decorate:bool=_C)->t.Callable:
	extra_name=extra_name or engine_type
	def validate(cls:t.Any,data:t.Any)->t.Any:
		check_import=str_to_bool(str(data.pop('check_import',_C)))if isinstance(data,dict)else _C
		if not check_import:return data
		try:importlib.import_module(import_name)
		except ImportError:
			if debug_mode_enabled():raise
			logger.exception('Failed to import the engine library');raise ConfigError(f"Failed to import the '{engine_type}' engine library. This may be due to a missing or incompatible installation. Please ensure the required dependency is installed by running: `pip install \"vulcan[{extra_name}]\"`. For more details, check the logs in the 'logs/' folder, or rerun the command with the '--debug' flag.")
		return data
	return model_validator(mode=_P)(validate)if decorate else validate
class ConnectionConfig(abc.ABC,BaseConfig):
	type_:str;DIALECT:t.ClassVar[str];DISPLAY_NAME:t.ClassVar[str];DISPLAY_ORDER:t.ClassVar[int];concurrent_tasks:int;register_comments:bool;pre_ping:bool;pretty_sql:bool=_B;schema_differ_overrides:t.Optional[t.Dict[str,t.Any]]=_A;catalog_type_overrides:t.Optional[t.Dict[str,str]]=_A;user_agent:t.Optional[str]=Field(default=_A,exclude=_C);shared_connection:t.ClassVar[bool]=_B
	@property
	@abc.abstractmethod
	def _connection_kwargs_keys(self)->t.Set[str]:0
	@property
	@abc.abstractmethod
	def _engine_adapter(self)->t.Type[EngineAdapter]:0
	@property
	@abc.abstractmethod
	def _connection_factory(self)->t.Callable:0
	@property
	def _static_connection_kwargs(self)->t.Dict[str,t.Any]:return{}
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{}
	@property
	def _cursor_init(self)->t.Optional[t.Callable[[t.Any],_A]]:0
	@property
	def is_recommended_for_state_sync(self)->bool:return self.type_ in RECOMMENDED_STATE_SYNC_ENGINES
	@property
	def is_forbidden_for_state_sync(self)->bool:return self.type_ in FORBIDDEN_STATE_SYNC_ENGINES
	@property
	def _connection_factory_with_kwargs(self)->t.Callable[[],t.Any]:return partial(self._connection_factory,**{**self._static_connection_kwargs,**{k:v for(k,v)in self.dict().items()if k in self._connection_kwargs_keys}})
	def connection_validator(self)->t.Callable[[],_A]:return self.create_engine_adapter().ping
	def create_engine_adapter(self,register_comments_override:bool=_B,concurrent_tasks:t.Optional[int]=_A)->EngineAdapter:concurrent_tasks=concurrent_tasks or self.concurrent_tasks;return self._engine_adapter(self._connection_factory_with_kwargs,multithreaded=concurrent_tasks>1,default_catalog=self.get_catalog(),cursor_init=self._cursor_init,register_comments=register_comments_override or self.register_comments,pre_ping=self.pre_ping,pretty_sql=self.pretty_sql,shared_connection=self.shared_connection,schema_differ_overrides=self.schema_differ_overrides,catalog_type_overrides=self.catalog_type_overrides,user_agent=self.user_agent,**self._extra_engine_config)
	def get_catalog(self)->t.Optional[str]:
		if hasattr(self,_K):return self.catalog
		if hasattr(self,_E):return self.database
		if hasattr(self,'db'):return self.db
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:raise ValueError(f"Unsupported connection type for Soda checks. ")
	@abc.abstractmethod
	def get_connection_uri(self)->str:raise NotImplementedError(f"Not Implemented for {self.type_} connection type")
	@model_validator(mode=_P)
	@classmethod
	def _expand_json_strings_to_concrete_types(cls,data:t.Any)->t.Any:
		if data and isinstance(data,dict):
			for maybe_json_field_name in cls._get_list_and_dict_field_names():
				if(value:=data.get(maybe_json_field_name))and isinstance(value,str):
					value=value.strip()
					if value.startswith('{')or value.startswith('['):data[maybe_json_field_name]=from_json(value)
		return data
	@classmethod
	def _get_list_and_dict_field_names(cls)->t.Set[str]:
		field_names=set()
		for(name,field)in cls.model_fields.items():
			if field.annotation:
				field_types=get_concrete_types_from_typehint(field.annotation)
				if any(ft is t for t in(list,tuple,set,dict)for ft in field_types):field_names.add(name)
		return field_names
class DuckDBAttachOptions(BaseConfig):
	type:str;path:str;read_only:bool=_B;data_path:t.Optional[str]=_A;encrypted:bool=_B;data_inlining_row_limit:t.Optional[int]=_A;metadata_schema:t.Optional[str]=_A
	def to_sql(self,alias:str)->str:
		A='ducklake';options=[]
		if self.type not in(_L,A,_j):options.append(f"TYPE {self.type.upper()}")
		if self.read_only:options.append('READ_ONLY')
		path=self.path
		if self.type==A:
			if not path.startswith('ducklake:'):path=f"ducklake:{path}"
			if self.data_path is not _A:options.append(f"DATA_PATH '{self.data_path}'")
			if self.encrypted:options.append('ENCRYPTED')
			if self.data_inlining_row_limit is not _A:options.append(f"DATA_INLINING_ROW_LIMIT {self.data_inlining_row_limit}")
			if self.metadata_schema is not _A:options.append(f"METADATA_SCHEMA '{self.metadata_schema}'")
		options_sql=f" ({', '.join(options)})"if options else'';alias_sql='';alias_sql=f" AS {alias}"if not(self.type==_j or self.path.startswith(_X))else'';return f"ATTACH IF NOT EXISTS '{path}'{alias_sql}{options_sql}"
class BaseDuckDBConnectionConfig(ConnectionConfig):
	database:t.Optional[str]=_A;catalogs:t.Optional[t.Dict[str,t.Union[str,DuckDBAttachOptions]]]=_A;extensions:t.List[t.Union[str,t.Dict[str,t.Any]]]=[];connector_config:t.Dict[str,t.Any]={};secrets:t.Union[t.List[t.Dict[str,t.Any]],t.Dict[str,t.Dict[str,t.Any]]]=[];filesystems:t.List[t.Dict[str,t.Any]]=[];concurrent_tasks:int=1;register_comments:bool=_C;pre_ping:t.Literal[_B]=_B;token:t.Optional[str]=_A;shared_connection:t.ClassVar[bool]=_C;_data_file_to_adapter:t.ClassVar[t.Dict[str,EngineAdapter]]={}
	@model_validator(mode=_P)
	def _validate_database_catalogs(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		db_path=data.get(_E)
		if db_path and data.get('catalogs'):raise ConfigError('Cannot specify both `database` and `catalogs`. Define all your catalogs in `catalogs` and have the first entry be the default catalog')
		if isinstance(db_path,str)and db_path.startswith(_X):raise ConfigError("Please use connection type 'motherduck' without the `md:` prefix if you want to use a MotherDuck database as the single `database`.")
		return data
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.DuckDBEngineAdapter
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return{_E}
	@property
	def _connection_factory(self)->t.Callable:import duckdb;return duckdb.connect
	@property
	def _cursor_init(self)->t.Optional[t.Callable[[t.Any],_A]]:
		import duckdb;from duckdb import BinderException
		def init(cursor:duckdb.DuckDBPyConnection)->_A:
			B='repository';A='name'
			for extension in self.extensions:
				extension=extension if isinstance(extension,dict)else{A:extension};install_command=f"INSTALL {extension[A]}"
				if extension.get(B):install_command=f"{install_command} FROM {extension[B]}"
				if extension.get('force_install'):install_command=f"FORCE {install_command}"
				try:cursor.execute(install_command);cursor.execute(f"LOAD {extension[A]}")
				except Exception as e:raise ConfigError(f"Failed to load extension {extension[A]}: {e}")
			if self.connector_config:
				option_names=list(self.connector_config);in_part=','.join('?'for _ in range(len(option_names)));cursor.execute(f"SELECT name, value FROM duckdb_settings() WHERE name IN ({in_part})",option_names);existing_values={field:setting for(field,setting)in cursor.fetchall()}
				for(field,setting)in self.connector_config.items():
					if existing_values.get(field)!=setting:
						try:cursor.execute(f"SET {field} = '{setting}'")
						except Exception as e:raise ConfigError(f"Failed to set connector config {field} to {setting}: {e}")
			if self.secrets:
				duckdb_version=duckdb.__version__
				if version.parse(duckdb_version)<version.parse('0.10.0'):from vulcan.core.console import get_console;get_console().log_warning(f"DuckDB version {duckdb_version} does not support secrets-based authentication (requires 0.10.0 or later).\nTo use secrets, please upgrade DuckDB. For older versions, configure legacy authentication via `connector_config`.\nMore info: https://duckdb.org/docs/stable/extensions/httpfs/s3api_legacy_authentication.html")
				else:
					if isinstance(self.secrets,list):secrets_items=[(secret_dict,'')for secret_dict in self.secrets]
					else:secrets_items=[(secret_dict,secret_name)for(secret_name,secret_dict)in self.secrets.items()]
					for(secret_dict,secret_name)in secrets_items:
						secret_settings:t.List[str]=[]
						for(field,setting)in secret_dict.items():secret_settings.append(f"{field} '{setting}'")
						if secret_settings:
							secret_clause=', '.join(secret_settings)
							try:cursor.execute(f"CREATE OR REPLACE SECRET {secret_name} ({secret_clause});")
							except Exception as e:raise ConfigError(f"Failed to create secret: {e}")
			if self.filesystems:
				from fsspec import filesystem
				for file_system in self.filesystems:options=file_system.copy();fs=options.pop('fs');fs=filesystem(fs,**options);cursor.register_filesystem(fs)
			for(i,(alias,path_options))in enumerate((getattr(self,'catalogs',_A)or{}).items()):
				alias=exp.parse_identifier(alias,dialect=_L).sql(identify=_C,dialect=_L)
				try:
					if isinstance(path_options,DuckDBAttachOptions):query=path_options.to_sql(alias)
					else:
						query=f"ATTACH IF NOT EXISTS '{path_options}'"
						if not path_options.startswith(_X):query+=f" AS {alias}"
					cursor.execute(query)
				except BinderException as e:
					if not('database with name "memory" already exists'in str(e)and path_options==_r)and f'database with name "{path_options.path.replace(_X,"")}" already exists'not in str(e):raise e
				if i==0 and not getattr(self,_E,_A):cursor.execute(f"USE {alias}")
		return init
	def create_engine_adapter(self,register_comments_override:bool=_B,concurrent_tasks:t.Optional[int]=_A)->EngineAdapter:
		data_files=set((self.catalogs or{}).values())
		if self.database:
			if isinstance(self,MotherDuckConnectionConfig):data_files.add(f"md:{self.database}"+(f"?motherduck_token={self.token}"if self.token else''))
			else:data_files.add(self.database)
		data_files.discard(_r)
		for data_file in data_files:
			key=data_file if isinstance(data_file,str)else data_file.path;adapter=BaseDuckDBConnectionConfig._data_file_to_adapter.get(key)
			if adapter is not _A:logger.info(f"Using existing DuckDB adapter due to overlapping data file: {self._mask_sensitive_data(key)}");return adapter
		if data_files:masked_files={self._mask_sensitive_data(file if isinstance(file,str)else file.path)for file in data_files};logger.info(f"Creating new DuckDB adapter for data files: {masked_files}")
		else:logger.info('Creating new DuckDB adapter for in-memory database')
		adapter=super().create_engine_adapter(register_comments_override,concurrent_tasks=concurrent_tasks)
		for data_file in data_files:key=data_file if isinstance(data_file,str)else data_file.path;BaseDuckDBConnectionConfig._data_file_to_adapter[key]=adapter
		return adapter
	def get_catalog(self)->t.Optional[str]:
		if self.database:return pathlib.Path(self.database.replace(_r,'memory')).stem
		if self.catalogs:return list(self.catalogs)[0]
	def _mask_sensitive_data(self,string:str)->str:result=MOTHERDUCK_TOKEN_REGEX.sub(lambda m:f"{m.group(1)}{m.group(2)}{'*'*8 if m.group(3)else''}",string);result=PASSWORD_REGEX.sub(lambda m:f"{m.group(1)}{'*'*8}",result);return result
class MotherDuckConnectionConfig(BaseDuckDBConnectionConfig):
	type_:t.Literal[_j]=Field(alias=_D,default=_j);DIALECT:t.ClassVar[t.Literal[_L]]=_L;DISPLAY_NAME:t.ClassVar[t.Literal[_A4]]=_A4;DISPLAY_ORDER:t.ClassVar[t.Literal[5]]=5
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return set()
	@property
	def _static_connection_kwargs(self)->t.Dict[str,t.Any]:
		from vulcan import __version__;custom_user_agent_config={'custom_user_agent':f"Vulcan/{__version__}"};connection_str=_X
		if self.database:connection_str+=f"{self.database}?attach_mode=single"
		if self.token:connection_str+=f"{'&'if self.database else'?'}motherduck_token={self.token}"
		return{_E:connection_str,'config':custom_user_agent_config}
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{'is_motherduck':_C}
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_L,_E:self.catalogs,_A5:self.connector_config}
		if catalog:config[_E]=catalog
		if schema:config[_I]=schema
		return config
	def get_connection_uri(self)->str:
		base=_X
		if self.database:base+=f"{self.database}?attach_mode=single"
		if self.token:sep='&'if self.database else'?';base+=f"{sep}motherduck_token={self.token}"
		return base
class DuckDBConnectionConfig(BaseDuckDBConnectionConfig):
	type_:t.Literal[_L]=Field(alias=_D,default=_L);DIALECT:t.ClassVar[t.Literal[_L]]=_L;DISPLAY_NAME:t.ClassVar[t.Literal['DuckDB']]='DuckDB';DISPLAY_ORDER:t.ClassVar[t.Literal[1]]=1
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_L,_E:self.catalogs,_A5:self.connector_config}
		if catalog:config[_E]=catalog
		if schema:config[_I]=schema
		return config
	def get_connection_uri(self)->str:
		if self.database:return f"duckdb://{self.database}"
		return'duckdb://memory'
class SnowflakeConnectionConfig(ConnectionConfig):
	account:str;user:t.Optional[str]=_A;password:t.Optional[str]=_A;warehouse:t.Optional[str]=_A;database:t.Optional[str]=_A;role:t.Optional[str]=_A;authenticator:t.Optional[str]=_A;token:t.Optional[str]=_A;host:t.Optional[str]=_A;port:t.Optional[int]=_A;application:t.Literal[_A6]=_A6;private_key:t.Optional[t.Union[str,bytes]]=_A;private_key_path:t.Optional[str]=_A;private_key_passphrase:t.Optional[str]=_A;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:bool=_B;session_parameters:t.Optional[dict]=_A;type_:t.Literal[_Y]=Field(alias=_D,default=_Y);DIALECT:t.ClassVar[t.Literal[_Y]]=_Y;DISPLAY_NAME:t.ClassVar[t.Literal[_A7]]=_A7;DISPLAY_ORDER:t.ClassVar[t.Literal[2]]=2;_concurrent_tasks_validator=concurrent_tasks_validator
	@model_validator(mode=_P)
	def _validate_authenticator(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		from snowflake.connector.network import DEFAULT_AUTHENTICATOR,OAUTH_AUTHENTICATOR;auth=data.get(_Z);auth=auth.upper()if auth else DEFAULT_AUTHENTICATOR;user=data.get(_J);password=data.get(_F);data[_U]=cls._get_private_key(data,auth)
		if auth==DEFAULT_AUTHENTICATOR and not data.get(_U)and(not user or not password):raise ConfigError('User and password must be provided if using default authentication')
		if auth==OAUTH_AUTHENTICATOR and not data.get(_d):raise ConfigError('Token must be provided if using oauth authentication')
		return data
	_engine_import_validator=_get_engine_import_validator('snowflake.connector.network',_Y)
	@classmethod
	def _get_private_key(cls,values:t.Dict[str,t.Optional[str]],auth:str)->t.Optional[bytes]:
		from cryptography.hazmat.backends import default_backend;from cryptography.hazmat.primitives import serialization;from snowflake.connector.network import DEFAULT_AUTHENTICATOR,KEY_PAIR_AUTHENTICATOR;private_key=values.get(_U);private_key_path=values.get(_A8);private_key_passphrase=values.get(_s);user=values.get(_J);password=values.get(_F);auth=auth if auth and auth!=DEFAULT_AUTHENTICATOR else KEY_PAIR_AUTHENTICATOR
		if not private_key and not private_key_path:return
		if private_key and private_key_path:raise ConfigError('Cannot specify both `private_key` and `private_key_path`')
		if auth!=KEY_PAIR_AUTHENTICATOR:raise ConfigError(f"Private key or private key path can only be provided when using {KEY_PAIR_AUTHENTICATOR} authentication")
		if not user:raise ConfigError(f"User must be provided when using {KEY_PAIR_AUTHENTICATOR} authentication")
		if password:raise ConfigError(f"Password cannot be provided when using {KEY_PAIR_AUTHENTICATOR} authentication")
		if isinstance(private_key,bytes):return private_key
		if private_key_passphrase:encoded_passphrase=private_key_passphrase.encode()
		else:encoded_passphrase=_A
		if private_key:
			if private_key.startswith('-'):p_key=serialization.load_pem_private_key(data=bytes(private_key,'utf-8'),password=encoded_passphrase,backend=default_backend())
			else:p_key=serialization.load_der_private_key(data=base64.b64decode(private_key),password=encoded_passphrase,backend=default_backend())
		elif private_key_path:
			with open(private_key_path,'rb')as key:p_key=serialization.load_pem_private_key(key.read(),password=encoded_passphrase,backend=default_backend())
		else:return
		return p_key.private_bytes(encoding=serialization.Encoding.DER,format=serialization.PrivateFormat.PKCS8,encryption_algorithm=serialization.NoEncryption())
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return{_J,_F,'account',_A9,_E,_t,_Z,_d,_U,'session_parameters','application',_G,_H}
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.SnowflakeEngineAdapter
	@property
	def _static_connection_kwargs(self)->t.Dict[str,t.Any]:return{_u:_B,'paramstyle':'qmark'}
	@property
	def _connection_factory(self)->t.Callable:from snowflake import connector;return connector.connect
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		B='SNOWFLAKE_JWT';A='SNOWFLAKE';config={_D:_Y,'account':str(self.account),_E:self.database,_A9:str(self.warehouse),_N:str(self.user)}
		if self.role:config[_t]=str(self.role)
		auth_upper=(self.authenticator or A).upper()
		if auth_upper==A:config[_F]=str(self.password)
		elif auth_upper==B:
			config[_Z]=B
			if self.private_key_path:
				config[_A8]=str(self.private_key_path)
				if self.private_key_passphrase:config[_s]=str(self.private_key_passphrase)
				config.pop(_U,_A)
			elif self.private_key:
				if isinstance(self.private_key,bytes):from cryptography.hazmat.backends import default_backend;from cryptography.hazmat.primitives import serialization;p_key=serialization.load_der_private_key(self.private_key,password=_A,backend=default_backend());pem_bytes=p_key.private_bytes(encoding=serialization.Encoding.PEM,format=serialization.PrivateFormat.PKCS8,encryption_algorithm=serialization.NoEncryption());config[_U]=pem_bytes.decode('utf-8')
				else:
					config[_U]=str(self.private_key)
					if self.private_key_passphrase:config[_s]=str(self.private_key_passphrase)
		if self.token:config[_Z]=_k;config[_d]=str(self.token)
		if self.authenticator and auth_upper!='OAUTH'and _Z not in config:config[_Z]=str(self.authenticator)
		if catalog:config[_E]=catalog
		if schema:config[_I]=schema
		return config
	def get_connection_uri(self)->str:return f"snowflake://{self.account}"
class DatabricksConnectionConfig(ConnectionConfig):
	server_hostname:t.Optional[str]=_A;http_path:t.Optional[str]=_A;access_token:t.Optional[str]=_A;auth_type:t.Optional[str]=_A;oauth_client_id:t.Optional[str]=_A;oauth_client_secret:t.Optional[str]=_A;catalog:t.Optional[str]=_A;http_headers:t.Optional[t.List[t.Tuple[str,str]]]=_A;session_configuration:t.Optional[t.Dict[str,t.Any]]=_A;databricks_connect_server_hostname:t.Optional[str]=_A;databricks_connect_access_token:t.Optional[str]=_A;databricks_connect_cluster_id:t.Optional[str]=_A;databricks_connect_use_serverless:bool=_B;force_databricks_connect:bool=_B;disable_databricks_connect:bool=_B;disable_spark_session:bool=_B;concurrent_tasks:int=1;register_comments:bool=_C;pre_ping:t.Literal[_B]=_B;type_:t.Literal[_V]=Field(alias=_D,default=_V);DIALECT:t.ClassVar[t.Literal[_V]]=_V;DISPLAY_NAME:t.ClassVar[t.Literal[_AA]]=_AA;DISPLAY_ORDER:t.ClassVar[t.Literal[3]]=3;_concurrent_tasks_validator=concurrent_tasks_validator;_http_headers_validator=http_headers_validator
	@model_validator(mode=_P)
	def _databricks_connect_validator(cls,data:t.Any)->t.Any:
		C='databricks_connect_cluster_id';B='databricks_connect_access_token';A='databricks_connect_server_hostname';logging.getLogger('SQLQueryContextLogger').setLevel(logging.CRITICAL)
		if not isinstance(data,dict):return data
		from vulcan.core.engine_adapter.databricks import DatabricksEngineAdapter
		if DatabricksEngineAdapter.can_access_spark_session(bool(data.get(_AB))):return data
		databricks_connect_use_serverless=data.get('databricks_connect_use_serverless');server_hostname,http_path,access_token,auth_type=data.get(_v),data.get(_w),data.get(_AC),data.get(_l)
		if(not server_hostname or not http_path or not access_token)and(not databricks_connect_use_serverless and not auth_type):raise ValueError('`server_hostname`, `http_path`, and `access_token` are required for Databricks connections when not running in a notebook')
		if databricks_connect_use_serverless and not server_hostname and not data.get(A):raise ValueError('`server_hostname` or `databricks_connect_server_hostname` is required when `databricks_connect_use_serverless` is set')
		if DatabricksEngineAdapter.can_access_databricks_connect(bool(data.get(_AD))):
			if not data.get(B):data[B]=access_token
			if not data.get(A):data[A]=f"https://{server_hostname}"
			if not databricks_connect_use_serverless and not data.get(C):
				if t.TYPE_CHECKING:assert http_path is not _A
				data[C]=http_path.split('/')[-1]
		if auth_type:
			from databricks.sql.auth.auth import AuthType;all_data=[m.value for m in AuthType]
			if auth_type not in all_data:raise ValueError(f"`auth_type` {auth_type} does not match a valid option: {all_data}")
			client_id=data.get('oauth_client_id');client_secret=data.get('oauth_client_secret')
			if client_secret and not client_id:raise ValueError('`oauth_client_id` is required when `oauth_client_secret` is specified')
			if not http_path:raise ValueError('`http_path` is still required when using `auth_type`')
		return data
	_engine_import_validator=_get_engine_import_validator(_V,_V)
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:
		if self.use_spark_session_only:return set()
		return{_v,_w,_AC,_AE,_AF,_K}
	@property
	def _engine_adapter(self)->t.Type[engine_adapter.DatabricksEngineAdapter]:return engine_adapter.DatabricksEngineAdapter
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{k:v for(k,v)in self.dict().items()if k.startswith('databricks_connect_')or k in(_K,_AD,_AB)}
	@property
	def use_spark_session_only(self)->bool:from vulcan.core.engine_adapter.databricks import DatabricksEngineAdapter;return DatabricksEngineAdapter.can_access_spark_session(self.disable_spark_session)or self.force_databricks_connect
	@property
	def _connection_factory(self)->t.Callable:
		if self.use_spark_session_only:from vulcan.engines.spark.db_api.spark_session import connection;return connection
		from databricks import sql;return sql.connect
	@property
	def _static_connection_kwargs(self)->t.Dict[str,t.Any]:
		from vulcan.core.engine_adapter.databricks import DatabricksEngineAdapter
		if not self.use_spark_session_only:
			conn_kwargs:t.Dict[str,t.Any]={'_user_agent_entry':_m}
			if self.auth_type and _k in self.auth_type:
				if self.oauth_client_secret:from databricks.sdk.core import oauth_service_principal,Config;config=Config(host=f"https://{self.server_hostname}",client_id=self.oauth_client_id,client_secret=self.oauth_client_secret);conn_kwargs[_AG]=lambda:oauth_service_principal(config)
				else:conn_kwargs[_l]=self.auth_type
			return conn_kwargs
		if DatabricksEngineAdapter.can_access_spark_session(self.disable_spark_session):from pyspark.sql import SparkSession;return dict(spark=SparkSession.getActiveSession(),catalog=self.catalog)
		from databricks.connect import DatabricksSession
		if t.TYPE_CHECKING:assert self.databricks_connect_server_hostname is not _A;assert self.databricks_connect_access_token is not _A
		if self.databricks_connect_use_serverless:builder=DatabricksSession.builder.remote(host=self.databricks_connect_server_hostname,token=self.databricks_connect_access_token,serverless=_C)
		else:
			if t.TYPE_CHECKING:assert self.databricks_connect_cluster_id is not _A
			builder=DatabricksSession.builder.remote(host=self.databricks_connect_server_hostname,token=self.databricks_connect_access_token,cluster_id=self.databricks_connect_cluster_id)
		return dict(spark=builder.userAgent(_m).getOrCreate(),catalog=self.catalog)
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		if not self.server_hostname or not self.http_path or not self.access_token:raise ValueError('`server_hostname`, `http_path`, and `access_token` are required for Databricks Soda connections')
		config={_D:_Q,'method':_V,_G:str(self.server_hostname),_w:str(self.http_path),_d:str(self.access_token),_K:self.catalog}
		if self.http_headers:
			for(header_name,header_value)in self.http_headers:
				if header_name.lower()=='user-agent':config['user_agent']=header_value;break
		if self.session_configuration:config[_AF]=self.session_configuration
		if catalog:config[_K]=catalog
		if schema:config[_I]=str(schema)
		return config
	def get_connection_uri(self)->str:
		if not self.server_hostname:raise ConfigError('server_hostname is required for Databricks connection URI')
		return f"databricks://{self.server_hostname}"
class BigQueryConnectionMethod(str,Enum):OAUTH=_k;OAUTH_SECRETS='oauth-secrets';SERVICE_ACCOUNT='service-account';SERVICE_ACCOUNT_JSON='service-account-json'
class BigQueryPriority(str,Enum):
	BATCH='batch';INTERACTIVE='interactive'
	@property
	def is_batch(self)->bool:return self==self.BATCH
	@property
	def is_interactive(self)->bool:return self==self.INTERACTIVE
	@property
	def bigquery_constant(self)->str:
		from google.cloud.bigquery import QueryPriority
		if self.is_batch:return QueryPriority.BATCH
		return QueryPriority.INTERACTIVE
class BigQueryConnectionConfig(ConnectionConfig):
	method:BigQueryConnectionMethod=BigQueryConnectionMethod.OAUTH;project:t.Optional[str]=_A;execution_project:t.Optional[str]=_A;quota_project:t.Optional[str]=_A;location:t.Optional[str]=_A;keyfile:t.Optional[str]=_A;keyfile_json:t.Optional[t.Dict[str,t.Any]]=_A;token:t.Optional[str]=_A;refresh_token:t.Optional[str]=_A;client_id:t.Optional[str]=_A;client_secret:t.Optional[str]=_A;token_uri:t.Optional[str]=_A;scopes:t.Tuple[str,...]=('https://www.googleapis.com/auth/bigquery',);impersonated_service_account:t.Optional[str]=_A;job_creation_timeout_seconds:t.Optional[int]=_A;job_execution_timeout_seconds:t.Optional[int]=_A;job_retries:t.Optional[int]=1;job_retry_deadline_seconds:t.Optional[int]=_A;priority:t.Optional[BigQueryPriority]=_A;maximum_bytes_billed:t.Optional[int]=_A;concurrent_tasks:int=1;register_comments:bool=_C;pre_ping:t.Literal[_B]=_B;type_:t.Literal[_R]=Field(alias=_D,default=_R);DIALECT:t.ClassVar[t.Literal[_R]]=_R;DISPLAY_NAME:t.ClassVar[t.Literal['BigQuery']]='BigQuery';DISPLAY_ORDER:t.ClassVar[t.Literal[4]]=4;_engine_import_validator=_get_engine_import_validator('google.cloud.bigquery',_R)
	@field_validator('execution_project')
	def validate_execution_project(cls,v:t.Optional[str],info:ValidationInfo)->t.Optional[str]:
		if v and not info.data.get('project'):raise ConfigError('If the `execution_project` field is specified, you must also specify the `project` field to provide a default object location.')
		return v
	@field_validator('quota_project')
	def validate_quota_project(cls,v:t.Optional[str],info:ValidationInfo)->t.Optional[str]:
		if v and not info.data.get('project'):raise ConfigError('If the `quota_project` field is specified, you must also specify the `project` field to provide a default object location.')
		return v
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return set()
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.BigQueryEngineAdapter
	@property
	def _static_connection_kwargs(self)->t.Dict[str,t.Any]:
		import google.auth;from google.auth import impersonated_credentials;from google.api_core import client_info,client_options;from google.oauth2 import credentials,service_account
		if self.method==BigQueryConnectionMethod.OAUTH:creds,_=google.auth.default(scopes=self.scopes)
		elif self.method==BigQueryConnectionMethod.SERVICE_ACCOUNT:creds=service_account.Credentials.from_service_account_file(self.keyfile,scopes=self.scopes)
		elif self.method==BigQueryConnectionMethod.SERVICE_ACCOUNT_JSON:creds=service_account.Credentials.from_service_account_info(self.keyfile_json,scopes=self.scopes)
		elif self.method==BigQueryConnectionMethod.OAUTH_SECRETS:creds=credentials.Credentials(token=self.token,refresh_token=self.refresh_token,client_id=self.client_id,client_secret=self.client_secret,token_uri=self.token_uri,scopes=self.scopes)
		else:raise ConfigError('Invalid BigQuery Connection Method')
		if self.impersonated_service_account:creds=impersonated_credentials.Credentials(source_credentials=creds,target_principal=self.impersonated_service_account,target_scopes=self.scopes)
		options=client_options.ClientOptions(quota_project_id=self.quota_project);project=self.execution_project or self.project or _A;client=google.cloud.bigquery.Client(project=project and exp.parse_identifier(project,dialect=_R).name,credentials=creds,location=self.location,client_info=client_info.ClientInfo(user_agent=_m),client_options=options);return{'client':client}
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{k:v for(k,v)in self.dict().items()if k in{'job_creation_timeout_seconds','job_execution_timeout_seconds','job_retries','job_retry_deadline_seconds','priority','maximum_bytes_billed'}}
	@property
	def _connection_factory(self)->t.Callable:from google.cloud.bigquery.dbapi import connect;return connect
	def get_catalog(self)->t.Optional[str]:return self.project
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		A='project_id';import json;config={_D:_R,A:self.project}
		if self.method==BigQueryConnectionMethod.SERVICE_ACCOUNT:
			if self.keyfile:config['account_info_json_path']=str(self.keyfile)
		elif self.method==BigQueryConnectionMethod.SERVICE_ACCOUNT_JSON:
			if self.keyfile_json:config['account_info_json']=json.dumps(self.keyfile_json)
		elif self.method==BigQueryConnectionMethod.OAUTH_SECRETS:
			if self.token:config[_d]=str(self.token)
			if self.refresh_token:config['refresh_token']=str(self.refresh_token)
		elif self.method==BigQueryConnectionMethod.OAUTH:config['use_context_auth']=_C
		if self.location:config['location']=str(self.location)or'US'
		if self.quota_project:config['storage_project_id']=str(self.quota_project)
		if self.impersonated_service_account:config['impersonation_account']=str(self.impersonated_service_account)
		if self.scopes:config['auth_scopes']=list(self.scopes)
		if catalog:config[A]=catalog
		if schema:config['dataset']=schema
		return config
	def get_connection_uri(self)->str:return _R
class GCPPostgresConnectionConfig(ConnectionConfig):
	instance_connection_string:str;user:str;password:t.Optional[str]=_A;enable_iam_auth:t.Optional[bool]=_A;db:str;ip_type:t.Union[t.Literal['public'],t.Literal['private'],t.Literal['psc']]='public';keyfile:t.Optional[str]=_A;keyfile_json:t.Optional[t.Dict[str,t.Any]]=_A;timeout:t.Optional[int]=_A;scopes:t.Tuple[str,...]=('https://www.googleapis.com/auth/sqlservice.admin',);driver:str='pg8000';type_:t.Literal[_h]=Field(alias=_D,default=_h);DIALECT:t.ClassVar[t.Literal[_M]]=_M;DISPLAY_NAME:t.ClassVar[t.Literal[_AH]]=_AH;DISPLAY_ORDER:t.ClassVar[t.Literal[13]]=13;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:bool=_C;_engine_import_validator=_get_engine_import_validator('google.cloud.sql',_h,'gcppostgres')
	@model_validator(mode=_P)
	def _validate_auth_method(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		password=data.get(_F);enable_iam_auth=data.get(_AI)
		if not password and not enable_iam_auth:raise ConfigError("GCP Postgres connection configuration requires either password set for a postgres user account or enable_iam_auth set to 'True' for an IAM user account.")
		return data
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return{'instance_connection_string',_n,_J,_F,'db',_AI,_o}
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.PostgresEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:
		from google.cloud.sql.connector import Connector;from google.oauth2 import service_account;creds=_A
		if self.keyfile:creds=service_account.Credentials.from_service_account_file(self.keyfile,scopes=self.scopes)
		elif self.keyfile_json:creds=service_account.Credentials.from_service_account_info(self.keyfile_json,scopes=self.scopes)
		kwargs={'credentials':creds,'ip_type':self.ip_type}
		if self.timeout:kwargs[_o]=self.timeout
		return Connector(**kwargs).connect
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:raise ValueError('GCP Postgres connection is not supported for Soda checks.')
	def get_connection_uri(self)->str:return f"postgres://{self.instance_connection_string}"
class RedshiftConnectionConfig(ConnectionConfig):
	user:t.Optional[str]=_A;password:t.Optional[str]=_A;database:t.Optional[str]=_A;host:t.Optional[str]=_A;port:t.Optional[int]=_A;source_address:t.Optional[str]=_A;unix_sock:t.Optional[str]=_A;ssl:t.Optional[bool]=_A;sslmode:t.Optional[str]=_A;timeout:t.Optional[int]=_A;tcp_keepalive:t.Optional[bool]=_A;application_name:t.Optional[str]=_A;preferred_role:t.Optional[str]=_A;principal_arn:t.Optional[str]=_A;credentials_provider:t.Optional[str]=_A;region:t.Optional[str]=_A;cluster_identifier:t.Optional[str]=_A;iam:t.Optional[bool]=_A;is_serverless:t.Optional[bool]=_A;serverless_acct_id:t.Optional[str]=_A;serverless_work_group:t.Optional[str]=_A;enable_merge:t.Optional[bool]=_A;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:bool=_B;type_:t.Literal[_a]=Field(alias=_D,default=_a);DIALECT:t.ClassVar[t.Literal[_a]]=_a;DISPLAY_NAME:t.ClassVar[t.Literal['Redshift']]='Redshift';DISPLAY_ORDER:t.ClassVar[t.Literal[7]]=7;_engine_import_validator=_get_engine_import_validator('redshift_connector',_a)
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return{_J,_F,_E,_G,_H,'source_address','unix_sock','ssl',_e,_o,'tcp_keepalive',_AJ,'preferred_role','principal_arn',_AG,'region','cluster_identifier','iam','is_serverless','serverless_acct_id','serverless_work_group'}
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.RedshiftEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:from redshift_connector import connect;return connect
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{'enable_merge':self.enable_merge}
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_a,_G:str(self.host),_H:int(self.port)if self.port else 5439,_N:str(self.user),_F:str(self.password),_E:self.database}
		if self.timeout:config['connection_timeout_sec']=int(self.timeout)
		if not self.password:
			if self.iam:config['access_key_id']=_A
		if schema:config[_I]=schema
		if catalog:config[_E]=catalog
		return config
	def get_connection_uri(self)->str:
		if not self.host:raise ConfigError('host is required for Redshift connection URI')
		port=self.port or 5439
		if self.region and self.cluster_identifier:return f"redshift://{self.cluster_identifier}.{self.region}:{port}"
		return f"redshift://{self.host}:{port}"
class PostgresConnectionConfig(ConnectionConfig):
	host:str;user:str;password:str;port:int;database:str;keepalives_idle:t.Optional[int]=_A;connect_timeout:int=10;role:t.Optional[str]=_A;sslmode:t.Optional[str]=_A;application_name:t.Optional[str]=_A;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:bool=_C;type_:t.Literal[_M]=Field(alias=_D,default=_M);DIALECT:t.ClassVar[t.Literal[_M]]=_M;DISPLAY_NAME:t.ClassVar[t.Literal['Postgres']]='Postgres';DISPLAY_ORDER:t.ClassVar[t.Literal[12]]=12;_engine_import_validator=_get_engine_import_validator('psycopg2',_M)
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return{_G,_J,_F,_H,_E,'keepalives_idle',_AK,_e,_AJ}
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.PostgresEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:from psycopg2 import connect;return connect
	@property
	def _cursor_init(self)->t.Optional[t.Callable[[t.Any],_A]]:
		if not self.role:return
		def init(cursor:t.Any)->_A:cursor.execute(f"SET ROLE {self.role}")
		return init
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_M,_G:str(self.host),_H:int(self.port),_E:str(self.database),_N:str(self.user),_F:str(self.password),'quote_tables':_C}
		if self.connect_timeout:config['connection_timeout']=int(self.connect_timeout)
		if self.sslmode:config[_e]=str(self.sslmode)
		if catalog:config[_E]=catalog
		if schema:config[_I]=schema
		return config
	def get_connection_uri(self)->str:return f"postgres://{self.host}:{self.port}"
class MySQLConnectionConfig(ConnectionConfig):
	host:str;user:str;password:str;port:t.Optional[int]=_A;database:t.Optional[str]=_A;charset:t.Optional[str]=_A;collation:t.Optional[str]=_A;ssl_disabled:t.Optional[bool]=_A;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:bool=_C;type_:t.Literal[_S]=Field(alias=_D,default=_S);DIALECT:t.ClassVar[t.Literal[_S]]=_S;DISPLAY_NAME:t.ClassVar[t.Literal['MySQL']]='MySQL';DISPLAY_ORDER:t.ClassVar[t.Literal[14]]=14;_engine_import_validator=_get_engine_import_validator('pymysql',_S)
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:
		connection_keys={_G,_J,_F}
		if self.port is not _A:connection_keys.add(_H)
		if self.database is not _A:connection_keys.add(_E)
		if self.charset is not _A:connection_keys.add(_x)
		if self.collation is not _A:connection_keys.add('collation')
		if self.ssl_disabled is not _A:connection_keys.add('ssl_disabled')
		return connection_keys
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.MySQLEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:from pymysql import connect;return connect
	def get_connection_uri(self)->str:port=self.port or 3306;return f"mysql://{self.host}:{port}"
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_S,_G:str(self.host),_H:int(self.port),_N:str(self.user),_F:str(self.password)}
		if self.charset:config[_x]=str(self.charset)
		if catalog:config[_E]=catalog
		elif schema:config[_E]=schema
		return config
class MSSQLConnectionConfig(ConnectionConfig):
	host:str;user:t.Optional[str]=_A;password:t.Optional[str]=_A;database:t.Optional[str]='';timeout:t.Optional[int]=0;login_timeout:t.Optional[int]=60;charset:t.Optional[str]='UTF-8';appname:t.Optional[str]=_A;port:t.Optional[int]=1433;conn_properties:t.Optional[t.Union[t.List[str],str]]=_A;autocommit:t.Optional[bool]=_B;tds_version:t.Optional[str]=_A;driver:t.Literal[_b,_W]=_b;driver_name:t.Optional[str]=_A;trust_server_certificate:t.Optional[bool]=_A;encrypt:t.Optional[bool]=_A;odbc_properties:t.Optional[t.Dict[str,t.Any]]=_A;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:bool=_C;type_:t.Literal[_i]=Field(alias=_D,default=_i);DIALECT:t.ClassVar[t.Literal['tsql']]='tsql';DISPLAY_NAME:t.ClassVar[t.Literal['MSSQL']]='MSSQL';DISPLAY_ORDER:t.ClassVar[t.Literal[11]]=11
	@model_validator(mode=_P)
	@classmethod
	def _mssql_engine_import_validator(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		driver=data.get(_n,_b);driver_configs={_b:(_b,_i),_W:(_W,'mssql-odbc')}
		if driver not in driver_configs:raise ValueError(f"Unsupported driver: {driver}")
		import_module,extra_name=driver_configs[driver];validator_func=_get_engine_import_validator(import_module,driver,extra_name,decorate=_B);return validator_func(cls,data)
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:
		B='tds_version';A='conn_properties';base_keys={_G,_J,_F,_E,_o,_y,_x,'appname',_H,A,_u,B}
		if self.driver==_W:base_keys.update({_AL,_z,_p,'odbc_properties'});base_keys.discard(B);base_keys.discard(A)
		return base_keys
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.MSSQLEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:
		if self.driver==_b:import pymssql;return pymssql.connect
		import pyodbc
		def connect(**kwargs:t.Any)->t.Callable:
			A='YES';host=kwargs.pop(_G);port=kwargs.pop(_H,1433);database=kwargs.pop(_E,'');user=kwargs.pop(_J,_A);password=kwargs.pop(_F,_A);driver_name=kwargs.pop(_AL,'ODBC Driver 18 for SQL Server');trust_server_certificate=kwargs.pop(_z,_B);encrypt=kwargs.pop(_p,_C);login_timeout=kwargs.pop(_y,60);conn_str_parts=[f"DRIVER={{{driver_name}}}",f"SERVER={host},{port}"]
			if database:conn_str_parts.append(f"DATABASE={database}")
			conn_str_parts.append(f"Encrypt={A if encrypt else'NO'}")
			if trust_server_certificate:conn_str_parts.append('TrustServerCertificate=YES')
			conn_str_parts.append(f"Connection Timeout={login_timeout}")
			if user:conn_str_parts.append(f"UID={user}")
			if password:conn_str_parts.append(f"PWD={password}")
			if self.odbc_properties:
				for(key,value)in self.odbc_properties.items():
					if key.lower()in(_n,'server',_E,'uid','pwd',_p,'trustservercertificate','connection timeout'):continue
					if isinstance(value,bool):conn_str_parts.append(f"{key}={A if value else'NO'}")
					else:conn_str_parts.append(f"{key}={value}")
			conn_str=';'.join(conn_str_parts);conn=pyodbc.connect(conn_str,autocommit=kwargs.get(_u,_B))
			def handle_datetimeoffset(dto_value:t.Any)->t.Any:from datetime import datetime,timedelta,timezone;import struct;tup=struct.unpack('<6hI2h',dto_value);return datetime(tup[0],tup[1],tup[2],tup[3],tup[4],tup[5],tup[6]//1000,timezone(timedelta(hours=tup[7],minutes=tup[8])))
			conn.add_output_converter(-155,handle_datetimeoffset);return conn
		return connect
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{_A0:CatalogSupport.REQUIRES_SET_CATALOG}
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:'sqlserver',_G:str(self.host),_E:self.database};config[_AM]='SQL'
		if self.user:config[_N]=str(self.user)
		if self.password:config[_F]=str(self.password)
		if self.port:config[_H]=int(self.port)
		if self.login_timeout:config[_y]=int(self.login_timeout)
		if self.encrypt is not _A:config[_p]=self.encrypt
		if self.trust_server_certificate is not _A:config[_z]=self.trust_server_certificate
		if self.driver==_W and self.driver_name:config[_n]=str(self.driver_name)
		if catalog:config[_E]=catalog
		if schema:config[_I]=schema
		return config
	def get_connection_uri(self)->str:port=self.port or 1433;return f"mssql://{self.host}:{port}"
class AzureSQLConnectionConfig(MSSQLConnectionConfig):
	type_:t.Literal[_q]=Field(alias=_D,default=_q);DISPLAY_NAME:t.ClassVar[t.Literal[_AN]]=_AN;DISPLAY_ORDER:t.ClassVar[t.Literal[10]]=10
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{_A0:CatalogSupport.SINGLE_CATALOG_ONLY}
	def get_connection_uri(self)->str:port=self.port or 1433;return f"azuresql://{self.host}:{port}"
class FabricConnectionConfig(MSSQLConnectionConfig):
	type_:t.Literal[_f]=Field(alias=_D,default=_f);DIALECT:t.ClassVar[t.Literal[_f]]=_f;DISPLAY_NAME:t.ClassVar[t.Literal['Fabric']]='Fabric';DISPLAY_ORDER:t.ClassVar[t.Literal[17]]=17;driver:t.Literal[_W]=_W;workspace_id:str;tenant_id:str;autocommit:t.Optional[bool]=_C
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:from vulcan.core.engine_adapter.fabric import FabricEngineAdapter;return FabricEngineAdapter
	def get_connection_uri(self)->str:port=self.port or 1433;return f"fabric://{self.host}:{port}"
	@property
	def _connection_factory(self)->t.Callable:
		base_factory=super()._connection_factory
		def create_fabric_connection(target_catalog:t.Optional[str]=_A,*args:t.Any,**kwargs:t.Any)->t.Callable:kwargs[_E]=target_catalog or self.database;return base_factory(*args,**kwargs)
		return create_fabric_connection
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{_E:self.database,_A0:CatalogSupport.REQUIRES_SET_CATALOG,'workspace_id':self.workspace_id,_AO:self.tenant_id,_J:self.user,_F:self.password}
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config=super().soda_conn_config(catalog=catalog,schema=schema);config[_D]=_f;authentication=(self.odbc_properties or{}).get('Authentication')
		if authentication:
			config[_AM]=str(authentication)
			if str(authentication).lower()=='activedirectoryserviceprincipal':config['client_id']=config.pop(_N,_A);config['client_secret']=config.pop(_F,_A)
		if self.tenant_id:config[_AO]=str(self.tenant_id)
		return config
class SparkConnectionConfig(ConnectionConfig):
	config_dir:t.Optional[str]=_A;catalog:t.Optional[str]=_A;config:t.Dict[str,t.Any]={};wap_enabled:bool=_B;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:t.Literal[_B]=_B;type_:t.Literal[_Q]=Field(alias=_D,default=_Q);DIALECT:t.ClassVar[t.Literal[_Q]]=_Q;DISPLAY_NAME:t.ClassVar[t.Literal['Spark']]='Spark';DISPLAY_ORDER:t.ClassVar[t.Literal[8]]=8;_engine_import_validator=_get_engine_import_validator('pyspark',_Q)
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return{_K}
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.SparkEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:from vulcan.engines.spark.db_api.spark_session import connection;return connection
	@property
	def _static_connection_kwargs(self)->t.Dict[str,t.Any]:
		from pyspark.conf import SparkConf;from pyspark.sql import SparkSession
		if self.config_dir:os.environ['SPARK_CONF_DIR']=self.config_dir
		spark_config=SparkConf();spark_properties=_filter_spark_properties(_load_spark_properties_file(_spark_properties_file_path()));merged_spark_properties=_merge_spark_properties(spark_properties,_load_spark_properties_file(_spark_event_log_properties_file_path()))
		for(k,v)in merged_spark_properties.items():spark_config.set(k,v)
		if self.config:
			for(k,v)in self.config.items():spark_config.set(k,v)
		spark=SparkSession.builder.config(conf=spark_config).getOrCreate();spark_app_id=spark.sparkContext.getConf().get('spark.app.id',_A)
		if spark_app_id:logger.info('Spark application id: %s',spark_app_id)
		return{_Q:spark}
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{'wap_enabled':self.wap_enabled}
	def get_connection_uri(self)->str:
		A='spark://local';master=self.config.get('spark.master','local[*]')
		if master.startswith('local'):return A
		if master.startswith('spark://'):return master
		return A
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:return{'__soda_programmatic__':'spark_df',_K:catalog,_I:schema}
class TrinoAuthenticationMethod(str,Enum):
	NO_AUTH='no-auth';BASIC='basic';LDAP='ldap';KERBEROS='kerberos';JWT='jwt';CERTIFICATE='certificate';OAUTH=_k
	@property
	def is_no_auth(self)->bool:return self==self.NO_AUTH
	@property
	def is_basic(self)->bool:return self==self.BASIC
	@property
	def is_ldap(self)->bool:return self==self.LDAP
	@property
	def is_kerberos(self)->bool:return self==self.KERBEROS
	@property
	def is_jwt(self)->bool:return self==self.JWT
	@property
	def is_certificate(self)->bool:return self==self.CERTIFICATE
	@property
	def is_oauth(self)->bool:return self==self.OAUTH
class TrinoConnectionConfig(ConnectionConfig):
	method:TrinoAuthenticationMethod=TrinoAuthenticationMethod.NO_AUTH;host:str;user:str;catalog:str;port:t.Optional[int]=_A;http_scheme:t.Literal['http',_A1]=_A1;roles:t.Optional[t.Dict[str,str]]=_A;http_headers:t.Optional[t.Dict[str,str]]=_A;session_properties:t.Optional[t.Dict[str,str]]=_A;retries:int=3;timezone:t.Optional[str]=_A;password:t.Optional[str]=_A;verify:t.Optional[bool]=_A;impersonation_user:t.Optional[str]=_A;keytab:t.Optional[str]=_A;krb5_config:t.Optional[str]=_A;principal:t.Optional[str]=_A;service_name:str=_O;hostname_override:t.Optional[str]=_A;mutual_authentication:bool=_B;force_preemptive:bool=_B;sanitize_mutual_error_response:bool=_C;delegate:bool=_B;jwt_token:t.Optional[str]=_A;client_certificate:t.Optional[str]=_A;client_private_key:t.Optional[str]=_A;cert:t.Optional[str]=_A;schema_location_mapping:t.Optional[dict[re.Pattern,str]]=_A;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:t.Literal[_B]=_B;type_:t.Literal[_O]=Field(alias=_D,default=_O);DIALECT:t.ClassVar[t.Literal[_O]]=_O;DISPLAY_NAME:t.ClassVar[t.Literal['Trino']]='Trino';DISPLAY_ORDER:t.ClassVar[t.Literal[9]]=9;_engine_import_validator=_get_engine_import_validator(_O,_O)
	@field_validator(_AP,mode=_P)
	@classmethod
	def _validate_regex_keys(cls,value:t.Dict[str|re.Pattern,str])->t.Dict[re.Pattern,t.Any]:
		compiled=compile_regex_mapping(value)
		for replacement in compiled.values():
			if'@{schema_name}'not in replacement:raise ConfigError("schema_location_mapping needs to include the '@{schema_name}' placeholder in the value so Vulcan knows where to substitute the schema name")
		return compiled
	@model_validator(mode='after')
	def _root_validator(self)->Self:
		port=self.port
		if self.http_scheme=='http'and not self.method.is_no_auth and not self.method.is_basic:raise ConfigError('HTTP scheme can only be used with no-auth or basic method')
		if port is _A:self.port=80 if self.http_scheme=='http'else 443
		if(self.method.is_ldap or self.method.is_basic)and(not self.password or not self.user):raise ConfigError(f"Username and Password must be provided if using {self.method.value} authentication")
		if self.method.is_kerberos and(not self.principal or not self.keytab or not self.krb5_config):raise ConfigError('Kerberos requires the following fields: principal, keytab, and krb5_config')
		if self.method.is_jwt and not self.jwt_token:raise ConfigError('JWT requires `jwt_token` to be set')
		if self.method.is_certificate and(not self.cert or not self.client_certificate or not self.client_private_key):raise ConfigError('Certificate requires the following fields: cert, client_certificate, and client_private_key')
		return self
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:kwargs={_G,_H,_K,'roles',_AQ,_AE,'session_properties','timezone'};return kwargs
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.TrinoEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:from trino.dbapi import connect;return connect
	@property
	def _static_connection_kwargs(self)->t.Dict[str,t.Any]:
		from trino.auth import BasicAuthentication,CertificateAuthentication,JWTAuthentication,KerberosAuthentication,OAuth2Authentication
		if self.method.is_basic or self.method.is_ldap:auth=BasicAuthentication(self.user,self.password)
		elif self.method.is_kerberos:
			if self.keytab:os.environ['KRB5_CLIENT_KTNAME']=self.keytab
			auth=KerberosAuthentication(config=self.krb5_config,service_name=self.service_name,principal=self.principal,mutual_authentication=self.mutual_authentication,ca_bundle=self.cert,force_preemptive=self.force_preemptive,hostname_override=self.hostname_override,sanitize_mutual_error_response=self.sanitize_mutual_error_response,delegate=self.delegate)
		elif self.method.is_oauth:auth=OAuth2Authentication()
		elif self.method.is_jwt:auth=JWTAuthentication(self.jwt_token)
		elif self.method.is_certificate:auth=CertificateAuthentication(self.client_certificate,self.client_private_key)
		else:auth=_A
		return{'auth':auth,_J:self.impersonation_user or self.user,'max_attempts':self.retries,'verify':self.cert if self.cert is not _A else self.verify,'source':_m}
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{_AP:self.schema_location_mapping}
	def get_connection_uri(self)->str:port=self.port or 8080;return f"trino://{self.host}:{port}"
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_O,_G:str(self.host),_H:int(self.port),_N:str(self.user),_J:str(self.user),_K:catalog or self.catalog}
		if self.http_scheme!=_A1:config[_AQ]=str(self.http_scheme)
		if self.method.is_no_auth:config[_l]='NoAuthentication'
		if self.method.is_basic or self.method.is_ldap:
			if self.password:config[_F]=str(self.password)
		elif self.method.is_jwt:
			config[_l]='jwt'
			if self.jwt_token:config['jwt_token']=str(self.jwt_token)
		if catalog:config[_K]=catalog
		if schema:config[_I]=schema
		return config
class ClickhouseConnectionConfig(ConnectionConfig):
	host:str;username:str;password:t.Optional[str]=_A;port:t.Optional[int]=_A;cluster:t.Optional[str]=_A;connect_timeout:int=10;send_receive_timeout:int=300;query_limit:int=0;use_compression:bool=_C;compression_method:t.Optional[str]=_A;connection_settings:t.Optional[t.Dict[str,t.Any]]=_A;http_proxy:t.Optional[str]=_A;verify:bool=_C;ca_cert:t.Optional[str]=_A;client_cert:t.Optional[str]=_A;client_cert_key:t.Optional[str]=_A;https_proxy:t.Optional[str]=_A;server_host_name:t.Optional[str]=_A;tls_mode:t.Optional[str]=_A;concurrent_tasks:int=1;register_comments:bool=_C;pre_ping:bool=_B;connection_pool_options:t.Optional[t.Dict[str,t.Any]]=_A;type_:t.Literal[_T]=Field(alias=_D,default=_T);DIALECT:t.ClassVar[t.Literal[_T]]=_T;DISPLAY_NAME:t.ClassVar[t.Literal[_AR]]=_AR;DISPLAY_ORDER:t.ClassVar[t.Literal[6]]=6;_engine_import_validator=_get_engine_import_validator('clickhouse_connect',_T)
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:kwargs={_G,_N,_H,_F,_AK,'send_receive_timeout','query_limit','http_proxy','verify','ca_cert','client_cert','client_cert_key','https_proxy','server_host_name','tls_mode'};return kwargs
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.ClickhouseEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:
		from clickhouse_connect.dbapi import connect;from clickhouse_connect.driver import httputil;from functools import partial;pool_manager_options:t.Dict[str,t.Any]=dict(maxsize=self.concurrent_tasks,block=_C,verify=self.verify,ca_cert=self.ca_cert,client_cert=self.client_cert,client_cert_key=self.client_cert_key,https_proxy=self.https_proxy)
		if self.server_host_name:
			pool_manager_options[_v]=self.server_host_name
			if self.verify:pool_manager_options['assert_hostname']=self.server_host_name
		if self.connection_pool_options:pool_manager_options.update(self.connection_pool_options)
		pool_mgr=httputil.get_pool_manager(**pool_manager_options);return partial(connect,pool_mgr=pool_mgr)
	@property
	def cloud_mode(self)->bool:return'clickhouse.cloud'in self.host
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{'cluster':self.cluster,'cloud_mode':self.cloud_mode}
	@property
	def _static_connection_kwargs(self)->t.Dict[str,t.Any]:
		from vulcan import __version__;compress:bool|str=self.use_compression
		if compress and self.compression_method:compress=self.compression_method
		settings=self.connection_settings or{};settings['mutations_sync']='2';settings['insert_distributed_sync']='1'
		if self.cluster or self.cloud_mode:settings['database_replicated_enforce_synchronous_settings']='1';settings['insert_quorum']='auto'
		return{'compress':compress,'client_name':f"Vulcan/{__version__}",**settings}
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_T,_G:str(self.host),_N:str(self.username)}
		if self.port:config[_H]=int(self.port)
		if self.password:config[_F]=str(self.password)
		if catalog:config[_E]=catalog
		if schema:config[_I]=schema
		return config
	def get_connection_uri(self)->str:port=self.port or 9000;return f"clickhouse://{self.host}:{port}"
class AthenaConnectionConfig(ConnectionConfig):
	aws_access_key_id:t.Optional[str]=_A;aws_secret_access_key:t.Optional[str]=_A;role_arn:t.Optional[str]=_A;role_session_name:t.Optional[str]=_A;region_name:t.Optional[str]=_A;work_group:t.Optional[str]=_A;s3_staging_dir:t.Optional[str]=_A;schema_name:t.Optional[str]=_A;catalog_name:t.Optional[str]=_A;s3_warehouse_location:t.Optional[str]=_A;concurrent_tasks:int=4;register_comments:t.Literal[_B]=_B;pre_ping:t.Literal[_B]=_B;type_:t.Literal[_c]=Field(alias=_D,default=_c);DIALECT:t.ClassVar[t.Literal[_c]]=_c;DISPLAY_NAME:t.ClassVar[t.Literal['Athena']]='Athena';DISPLAY_ORDER:t.ClassVar[t.Literal[15]]=15;_engine_import_validator=_get_engine_import_validator('pyathena',_c)
	@model_validator(mode='after')
	def _root_validator(self)->Self:
		work_group=self.work_group;s3_staging_dir=self.s3_staging_dir;s3_warehouse_location=self.s3_warehouse_location
		if not work_group and not s3_staging_dir:raise ConfigError('At least one of work_group or s3_staging_dir must be set')
		if s3_staging_dir:self.s3_staging_dir=validate_s3_uri(s3_staging_dir,base=_C,error_type=ConfigError)
		if s3_warehouse_location:self.s3_warehouse_location=validate_s3_uri(s3_warehouse_location,base=_C,error_type=ConfigError)
		return self
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return{_AS,_AT,'role_arn','role_session_name',_AU,'work_group',_AV,'schema_name','catalog_name'}
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.AthenaEngineAdapter
	@property
	def _extra_engine_config(self)->t.Dict[str,t.Any]:return{'s3_warehouse_location':self.s3_warehouse_location}
	def get_connection_uri(self)->str:region=self.region_name or'us-east-1';return f"awsathena://athena.{region}.amazonaws.com"
	@property
	def _connection_factory(self)->t.Callable:from pyathena import connect;return connect
	def get_catalog(self)->t.Optional[str]:return self.catalog_name
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_c}
		if self.catalog_name:config[_K]=str(self.catalog_name)
		if self.schema_name:config[_I]=str(self.schema_name)
		if self.aws_access_key_id:config[_AS]=str(self.aws_access_key_id)
		if self.aws_secret_access_key:config[_AT]=str(self.aws_secret_access_key)
		if self.region_name:config[_AU]=str(self.region_name)
		if self.s3_staging_dir:config[_AV]=str(self.s3_staging_dir)
		if catalog:config[_K]=catalog
		if schema:config[_I]=schema
		return config
class RisingwaveConnectionConfig(ConnectionConfig):
	host:str;user:str;password:t.Optional[str]=_A;port:int;database:str;role:t.Optional[str]=_A;sslmode:t.Optional[str]=_A;concurrent_tasks:int=4;register_comments:bool=_C;pre_ping:bool=_C;type_:t.Literal[_g]=Field(alias=_D,default=_g);DIALECT:t.ClassVar[t.Literal[_g]]=_g;DISPLAY_NAME:t.ClassVar[t.Literal[_AW]]=_AW;DISPLAY_ORDER:t.ClassVar[t.Literal[16]]=16;_engine_import_validator=_get_engine_import_validator('psycopg2',_g)
	@property
	def _connection_kwargs_keys(self)->t.Set[str]:return{_G,_J,_F,_H,_E,_t,_e}
	@property
	def _engine_adapter(self)->t.Type[EngineAdapter]:return engine_adapter.RisingwaveEngineAdapter
	@property
	def _connection_factory(self)->t.Callable:from psycopg2 import connect;return connect
	def get_connection_uri(self)->str:return f"risingwave://{self.host}:{self.port}"
	@property
	def _cursor_init(self)->t.Optional[t.Callable[[t.Any],_A]]:
		def init(cursor:t.Any)->_A:sql='SET RW_IMPLICIT_FLUSH TO true;';cursor.execute(sql)
		return init
	def soda_conn_config(self,catalog:t.Optional[str]=_A,schema:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		config={_D:_M,_G:str(self.host),_H:int(self.port),_E:self.database,_N:str(self.user),_F:str(self.password)if self.password else''}
		if self.sslmode:config[_e]=str(self.sslmode)
		if schema:config[_I]=schema
		if catalog:config[_E]=catalog
		return config
CONNECTION_CONFIG_TO_TYPE={tpe.all_field_infos()[_A2].default:tpe for tpe in subclasses(__name__,ConnectionConfig,exclude=(ConnectionConfig,BaseDuckDBConnectionConfig))}
DIALECT_TO_TYPE={tpe.all_field_infos()[_A2].default:tpe.DIALECT for tpe in subclasses(__name__,ConnectionConfig,exclude=(ConnectionConfig,BaseDuckDBConnectionConfig))}
INIT_DISPLAY_INFO_TO_TYPE={tpe.all_field_infos()[_A2].default:(tpe.DISPLAY_ORDER,tpe.DISPLAY_NAME)for tpe in subclasses(__name__,ConnectionConfig,exclude=(ConnectionConfig,BaseDuckDBConnectionConfig))}
def parse_connection_config(v:t.Dict[str,t.Any])->ConnectionConfig:
	if _D not in v:raise ConfigError('Missing connection type.')
	connection_type=v[_D]
	if connection_type=='depot':return _load_depot_connection(v['address'])
	if connection_type not in CONNECTION_CONFIG_TO_TYPE:raise ConfigError(f"Unknown connection type '{connection_type}'.")
	return CONNECTION_CONFIG_TO_TYPE[connection_type](**v)
def _spark_properties_file_path()->pathlib.Path:return pathlib.Path(os.getenv('VULCAN_SPARK_PROPERTIES_FILE','/opt/spark/conf/spark.properties'))
def _spark_event_log_properties_file_path()->pathlib.Path:return pathlib.Path(os.getenv('DATAOS_SPARK_EVENT_LOG',_dataos_secret_path()/'sparkEventLog.conf'))
def _load_spark_properties_file(path:pathlib.Path)->t.Dict[str,str]:
	if not path.is_file():return{}
	from jproperties import Properties;properties=Properties()
	with path.open('rb')as properties_file:properties.load(properties_file)
	return{key:value.data for(key,value)in properties.items()}
def _filter_spark_properties(properties:t.Dict[str,str],inclusion_list:t.AbstractSet[str]=SPARK_PROPERTIES_INCLUSION_LIST,exclusion_list:t.AbstractSet[str]=SPARK_PROPERTIES_EXCLUSION_LIST)->t.Dict[str,str]:
	if inclusion_list:return{key:value for(key,value)in properties.items()if key in inclusion_list and key not in exclusion_list}
	return{key:value for(key,value)in properties.items()if key not in exclusion_list}
def _merge_spark_properties(*property_sets:t.Dict[str,str])->t.Dict[str,str]:
	merged_properties:t.Dict[str,str]={}
	for property_set in property_sets:merged_properties.update(property_set)
	return merged_properties
def _dataos_secret_path()->pathlib.Path:return pathlib.Path(os.getenv('DATAOS_SECRET_DIR','/etc/dataos/secret'))
def _parse_dataos_depot_name(address:str)->str:
	from urllib.parse import urlparse
	if not address or not isinstance(address,str):raise ConfigError(f"address must be a non-empty string")
	parsed=urlparse(address)
	if parsed.scheme!='dataos':raise ConfigError(f"address must use 'dataos://' scheme: {address}")
	depot_name=parsed.netloc
	if not depot_name:raise ConfigError(f"Depot name cannot be empty: {address}")
	return depot_name
def _load_yaml_mapping(path:pathlib.Path)->t.Dict[str,t.Any]:
	from vulcan.utils.yaml import load as yaml_load
	try:raw=yaml_load(path)
	except Exception as e:raise ConfigError(f"Failed to load file {path}: {e}")
	if not isinstance(raw,dict):raise ConfigError(f"file must be a mapping: {path}")
	return t.cast(t.Dict[str,t.Any],raw)
def _load_depot_connection(address:str)->ConnectionConfig:
	depot_name=_parse_dataos_depot_name(address);depot_path=_dataos_secret_path()/f"{depot_name}_config.yaml"
	if not depot_path.is_file():raise ConfigError(f"Depot file not found: {depot_path}")
	depot_config=_load_yaml_mapping(depot_path)
	if not isinstance(depot_config,dict)or _A3 not in depot_config:raise ConfigError(f"Depot file must contain 'connection' key: {depot_path}")
	connection_data=depot_config[_A3]
	if not isinstance(connection_data,dict):raise ConfigError(f"Invalid 'connection' in depot file: {depot_path}")
	logger.info(f"Loaded depot connection '{depot_name}' from {depot_path}");return parse_connection_config(connection_data)
def _connection_config_validator(cls:t.Type,v:ConnectionConfig|t.Dict[str,t.Any]|_A)->ConnectionConfig|_A:
	if v is _A or isinstance(v,ConnectionConfig):return v
	check_config_and_vars_msg='\n\nVerify your config.yaml and environment variables.'
	try:return parse_connection_config(v)
	except pydantic.ValidationError as e:raise ConfigError(validation_error_message(e,f"Invalid '{v[_D]}' connection config:")+check_config_and_vars_msg)
	except ConfigError as e:raise ConfigError(str(e)+check_config_and_vars_msg)
connection_config_validator:t.Callable=field_validator(_A3,'state_connection','test_connection','default_connection','default_test_connection','state',mode=_P,check_fields=_B)(_connection_config_validator)
if t.TYPE_CHECKING:SerializableConnectionConfig:t.TypeAlias=ConnectionConfig
else:import pydantic;SerializableConnectionConfig=pydantic.SerializeAsAny[ConnectionConfig]