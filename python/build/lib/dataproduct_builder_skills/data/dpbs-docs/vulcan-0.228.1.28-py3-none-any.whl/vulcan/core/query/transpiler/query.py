from __future__ import annotations
_B=False
_A=None
import typing as t
from sqlglot import exp,parse_one
from sqlglot.errors import ParseError
from sqlglot.optimizer.scope import Scope,traverse_scope
from schema.filters import RestLogicalFilter,RestUnaryFilter
from schema.metadata import Index,Metadata,QueryableModelKind
from schema.rest_query import RestQuery
from vulcan.core.query.transpiler.types import QueryAnalysis
from vulcan.utils.errors import SemanticQueryValidationError
if t.TYPE_CHECKING:from schema.filters import RestFilterExpression
def parse(query:RestQuery|str|exp.Expression)->RestQuery|exp.Expression:
	if isinstance(query,(RestQuery,exp.Expression)):return query
	try:return parse_one(query)
	except ParseError as e:raise SemanticQueryValidationError('SEMANTIC_QUERY_PARSE_ERROR',f"failed to parse semantic SQL: {e}")from e
def analyze(parsed:RestQuery|exp.Expression,metadata:Metadata)->QueryAnalysis:
	if isinstance(parsed,RestQuery):members_list=_member_refs_from_rest(parsed);members=frozenset(members_list);models=frozenset(_model_from_member(ref)for ref in members_list);row_limit=_A
	else:models,members=_referred_from_sql(parsed,metadata);row_limit=_limit_from_expression(parsed)
	index=metadata.index;kinds=frozenset(kind for name in models if(kind:=index.queryable_models.get(name))is not _A);return QueryAnalysis(models=models,members=members,kinds=kinds,policy_models=_policy_models(models,metadata),row_limit=row_limit)
def referred_models(query:RestQuery|exp.Expression,metadata:Metadata)->frozenset[str]:normalized=parse(query)if isinstance(query,str)else query;return analyze(normalized,metadata).models
def referred_members(query:RestQuery|exp.Expression,metadata:Metadata)->frozenset[str]:normalized=parse(query)if isinstance(query,str)else query;return analyze(normalized,metadata).members
def _policy_models(models:frozenset[str],metadata:Metadata)->frozenset[str]:
	if not metadata.index.protected_models:return frozenset()
	flattened:set[str]=set();index=metadata.index
	for name in models:
		kind=index.queryable_models.get(name)
		if kind=='semantic':flattened.add(name)
		elif kind=='metric':flattened.update(metadata.require_entry(name).depends_on)
	return frozenset(flattened)
def _table_ref_name(table:exp.Table)->str:parts=[part for part in(table.catalog,table.db,table.name)if part];return'.'.join(parts)
def _table_ref_candidates(table:exp.Table)->list[str]:
	candidates:list[str]=[];ref=_table_ref_name(table)
	if ref:candidates.append(ref)
	if table.name and table.name not in candidates:candidates.append(table.name)
	return candidates
def _resolve_table_ref(table:exp.Table,index:Index)->str|_A:
	if not table.name:return
	candidates=_table_ref_candidates(table)
	for candidate in candidates:
		if candidate in index.queryable_models:return candidate
		mapped=index.queryable_tables.get(candidate)
		if mapped is not _A:return mapped
	return candidates[0]if candidates else table.name
def _model_from_member(member:str)->str:return member.split('.',1)[0]
def _member_refs_from_rest(query:RestQuery)->list[str]:
	refs:list[str]=[]
	if query.measures:refs.extend(query.measures)
	if query.dimensions:refs.extend(query.dimensions)
	if query.segments:refs.extend(query.segments)
	if query.timeDimensions:refs.extend(td.dimension for td in query.timeDimensions)
	if query.filters:refs.extend(_filter_member_refs(query.filters))
	if query.order:
		if isinstance(query.order,dict):refs.extend(query.order.keys())
		else:refs.extend(member for(member,_direction)in query.order)
	if query.joinHints:
		for hint in query.joinHints:refs.extend(hint)
	return refs
def _filter_member_refs(filters:list[RestFilterExpression])->list[str]:
	out:list[str]=[]
	for f in filters:
		if isinstance(f,RestUnaryFilter):out.append(f.member)
		elif isinstance(f,RestLogicalFilter):children=f.and_ or f.or_ or[];out.extend(_filter_member_refs(children))
	return out
_BI_VIRTUAL_COLUMNS=frozenset({'__joinField','__user'})
_SUPPORTED_FILTER_SUBQUERY_PARENTS=exp.In,exp.EQ,exp.NEQ,exp.GT,exp.GTE,exp.LT,exp.LTE
def _is_relational_subquery(subquery:exp.Subquery)->bool:
	parent=subquery.parent
	while isinstance(parent,exp.Subquery):parent=parent.parent
	return isinstance(parent,(exp.From,exp.Join))
def _is_supported_filter_subquery(subquery:exp.Subquery)->bool:
	parent=subquery.parent
	if not isinstance(parent,_SUPPORTED_FILTER_SUBQUERY_PARENTS):return _B
	while parent is not _A and not isinstance(parent,(exp.Where,exp.Having,exp.Join,exp.Select)):parent=parent.parent
	return isinstance(parent,exp.Where)
def _in_subquery(node:exp.Expression)->bool:
	parent=node.parent
	while parent is not _A:
		if isinstance(parent,exp.Subquery):
			if not(_is_relational_subquery(parent)or _is_supported_filter_subquery(parent)):return True
		elif isinstance(parent,exp.Exists):return True
		parent=parent.parent
	return _B
def _column_name(column:exp.Column)->str|_A:
	if column.name:return column.name
	parts=[part.name for part in column.parts if part.name]
	if parts:return parts[-1]
def _scope_source(scope:Scope,name:str)->exp.Table|Scope|_A:
	current:Scope|_A=scope
	while current is not _A:
		source=current.sources.get(name)
		if isinstance(source,(exp.Table,Scope)):return source
		current=current.parent
def _scope_source_models(scope:Scope,index:Index)->dict[str,str]:
	models:dict[str,str]={}
	for(alias,source)in scope.sources.items():
		if not isinstance(source,exp.Table)or _in_subquery(source):continue
		model=_resolve_table_ref(source,index)
		if model is not _A:models[alias]=model
	return models
def _is_query_local_output_alias(column:exp.Column,scope:Scope)->bool:
	if column.table or not isinstance(scope.expression,exp.Select):return _B
	explicit_aliases={expression.alias for expression in scope.expression.expressions if isinstance(expression,exp.Alias)and expression.alias}
	if column.name not in explicit_aliases:return _B
	node:exp.Expression=column
	while node.parent is not _A and node.parent is not scope.expression:node=node.parent
	return all(node is not expression for expression in scope.expression.expressions)
def _scope_column_model(column:exp.Column,scope:Scope,source_models:dict[str,str],index:Index)->str|_A:
	table_ref=column.table
	if table_ref:
		source=_scope_source(scope,table_ref)
		if isinstance(source,Scope):return
		if isinstance(source,exp.Table):
			if _in_subquery(source):return
			return _resolve_table_ref(source,index)
		return table_ref
	if _is_query_local_output_alias(column,scope):return
	unique_models=set(source_models.values())
	if len(unique_models)==1:return next(iter(unique_models))
def _referred_from_sql(parsed:exp.Expression,metadata:Metadata)->tuple[frozenset[str],frozenset[str]]:
	index=metadata.index;models:set[str]=set();members:set[str]=set()
	for scope in traverse_scope(parsed):
		source_models=_scope_source_models(scope,index);models.update(source_models.values())
		for column in scope.columns:
			if _in_subquery(column):continue
			model=_scope_column_model(column,scope,source_models,index);col_name=_column_name(column)
			if col_name in _BI_VIRTUAL_COLUMNS:
				if model:models.add(model)
				continue
			if model:
				models.add(model)
				if col_name:members.add(f"{model}.{col_name}")
	return frozenset(models),frozenset(members)
def _literal_int(node:exp.Expression|_A)->int|_A:
	if not isinstance(node,exp.Literal)or node.is_string:return
	try:return int(node.this)
	except(TypeError,ValueError):return
def _limit_from_expression(expression:exp.Expression)->int|_A:
	B='with_ties';A='limit_options';limit_node=expression.args.get('limit')
	if limit_node is _A:return
	if isinstance(limit_node,exp.Fetch):
		opts=limit_node.args.get(A)
		if opts is not _A and opts.args.get(B):return
		return _literal_int(limit_node.args.get('count'))
	if isinstance(limit_node,exp.Limit):
		opts=limit_node.args.get(A)
		if opts is not _A and(opts.args.get('percent')or opts.args.get(B)):return
		return _literal_int(limit_node.args.get('expression'))