from __future__ import annotations
_V='semantic expression'
_U='catalog'
_T='ASSERTION'
_S='expression'
_R='model'
_Q='METRIC'
_P='AUDIT'
_O='MODEL'
_N='LIMIT'
_M='ORDER_BY'
_L='HAVING'
_K='GROUP_BY'
_J='WHERE'
_I='JOIN'
_H='name'
_G='sql'
_F='\n'
_E='this'
_D='expressions'
_C=False
_B=True
_A=None
import functools,logging,re,sys,typing as t
from contextlib import contextmanager
from dataclasses import dataclass
from difflib import unified_diff
from enum import Enum,auto
from functools import lru_cache
from sqlglot import Dialect,Generator,ParseError,Parser,Tokenizer,TokenType,exp
from sqlglot.dialects.dialect import DialectType,rename_func
from sqlglot.dialects import DuckDB,Snowflake
from sqlglot.dialects.databricks import Databricks
from sqlglot.dialects.fabric import Fabric
from sqlglot.dialects.tsql import TSQL
import sqlglot.dialects.athena as athena
from sqlglot.helper import seq_get
from sqlglot.optimizer.annotate_types import annotate_types
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.optimizer.qualify import qualify
from sqlglot.optimizer.qualify_columns import quote_identifiers
from sqlglot.optimizer.qualify_tables import qualify_tables
from sqlglot.optimizer.scope import traverse_scope
from sqlglot.schema import MappingSchema
from sqlglot.tokens import Token
from vulcan.core.constants import MAX_MODEL_DEFINITION_SIZE
from vulcan.utils import get_source_columns_to_types
from vulcan.utils.errors import VulcanError,ConfigError,raise_config_error
from vulcan.utils.pandas import columns_to_types_from_df
if t.TYPE_CHECKING:import pandas as pd;from sqlglot._typing import E
SQLMESH_MACRO_PREFIX='@'
TABLES_META='vulcan.tables'
logger=logging.getLogger(__name__)
class Databricks2(Databricks):
	class Parser(Databricks.Parser):PLACEHOLDER_PARSERS=dict(Databricks.Parser.PLACEHOLDER_PARSERS);PLACEHOLDER_PARSERS.pop(TokenType.L_BRACE,_A)
for _tsql_generator in(TSQL.Generator,Fabric.Generator):_tsql_generator.TRANSFORMS={**_tsql_generator.TRANSFORMS,exp.ApproxDistinct:rename_func('APPROX_COUNT_DISTINCT')}
class Model(exp.Expression):arg_types={_D:_B}
class Audit(exp.Expression):arg_types={_D:_B}
class Metric(exp.Expression):arg_types={_D:_B}
class Jinja(exp.Func):arg_types={_E:_B}
class JinjaQuery(Jinja):0
class JinjaStatement(Jinja):0
class VirtualUpdateStatement(exp.Expression):arg_types={_D:_B}
class ModelKind(exp.Expression):arg_types={_E:_B,_D:_C}
class MacroVar(exp.Var):0
class MacroFunc(exp.Func):
	@property
	def name(self)->str:return self.this.name
class MacroDef(MacroFunc):arg_types={_E:_B,_S:_B}
class MacroSQL(MacroFunc):arg_types={_E:_B,'into':_C}
class MacroStrReplace(MacroFunc):0
class PythonCode(exp.Expression):arg_types={_D:_B}
class DColonCast(exp.Cast):0
class MetricAgg(exp.AggFunc):
	arg_types={_E:_B}
	@property
	def output_name(self)->str:return self.this.name
class StagedFilePath(exp.Expression):arg_types=exp.Table.arg_types.copy()
def _parse_statement(self:Parser)->t.Optional[exp.Expression]:
	if self._curr is _A:return
	parser=PARSERS.get(self._curr.text.upper());error_msg=_A
	if parser:
		comments=self._curr.comments;index=self._index
		try:self._advance();meta=self._parse_wrapped(lambda:t.cast(t.Callable,parser)(self))
		except ParseError as parse_error:error_msg=parse_error.args[0];self._retreat(index)
		if self._index!=index:meta.comments=comments;return meta
	try:return self.__parse_statement()
	except ParseError:
		if error_msg:raise ParseError(error_msg)
		raise
def _parse_lambda(self:Parser,alias:bool=_C)->t.Optional[exp.Expression]:
	node=self.__parse_lambda(alias=alias)
	if isinstance(node,exp.Lambda):node.set(_E,self._parse_alias(node.this))
	return node
def _parse_id_var(self:Parser,any_token:bool=_B,tokens:t.Optional[t.Collection[TokenType]]=_A)->t.Optional[exp.Expression]:
	A='Expecting }'
	if self._prev and self._prev.text==SQLMESH_MACRO_PREFIX and self._match(TokenType.L_BRACE):
		identifier=self.__parse_id_var(any_token=any_token,tokens=tokens)
		if not self._match(TokenType.R_BRACE):self.raise_error(A)
		identifier.args[_E]=f"@{{{identifier.name}}}"
	else:identifier=self.__parse_id_var(any_token=any_token,tokens=tokens)
	while identifier and not identifier.args.get('quoted')and self._is_connected()and(self._match_texts(('{',SQLMESH_MACRO_PREFIX))or self._curr.token_type not in self.RESERVED_TOKENS):
		this=identifier.name;brace=_C
		if self._prev.text=='{':this+='{';brace=_B
		else:
			if self._prev.text==SQLMESH_MACRO_PREFIX:this+='@'
			if self._match(TokenType.L_BRACE):this+='{';brace=_B
		next_id=self._parse_id_var(any_token=_C)
		if next_id:this+=next_id.name
		else:return identifier
		if brace:
			if self._match(TokenType.R_BRACE):this+='}'
			else:self.raise_error(A)
		identifier=self.expression(exp.Identifier,this=this,quoted=identifier.quoted)
	return identifier
def _parse_macro(self:Parser,keyword_macro:str='')->t.Optional[exp.Expression]:
	if self._prev.text!=SQLMESH_MACRO_PREFIX:return self._parse_parameter()
	comments=self._prev.comments;index=self._index;field=self._parse_primary()or self._parse_function(functions={})or self._parse_id_var()
	def _build_macro(field:t.Optional[exp.Expression])->t.Optional[exp.Expression]:
		if isinstance(field,exp.Func):
			macro_name=field.name.upper()
			if macro_name!=keyword_macro and macro_name in KEYWORD_MACROS:self._retreat(index);return
			if isinstance(field,exp.Anonymous):
				if macro_name=='DEF':return self.expression(MacroDef,this=field.expressions[0],expression=field.expressions[1],comments=comments)
				if macro_name=='SQL':into=field.expressions[1].this.lower()if len(field.expressions)>1 else _A;return self.expression(MacroSQL,this=field.expressions[0],into=into,comments=comments)
			else:field=self.expression(exp.Anonymous,this=field.sql_name(),expressions=list(field.args.values()),comments=comments)
			return self.expression(MacroFunc,this=field,comments=comments)
		if field is _A:return
		if field.is_string or isinstance(field,exp.Identifier)and field.quoted:return self.expression(MacroStrReplace,this=exp.Literal.string(field.this),comments=comments)
		if'@'in field.this:return field
		return self.expression(MacroVar,this=field.this,comments=comments)
	if isinstance(field,(exp.Window,exp.IgnoreNulls,exp.RespectNulls)):field.set(_E,_build_macro(field.this))
	else:field=_build_macro(field)
	return field
KEYWORD_MACROS={'WITH',_I,_J,_K,_L,_M,_N}
def _parse_matching_macro(self:Parser,name:str)->t.Optional[exp.Expression]:
	if not self._match_pair(TokenType.PARAMETER,TokenType.VAR,advance=_C)or self._next and self._next.text.upper()!=name.upper():return
	self._advance();return _parse_macro(self,keyword_macro=name)
def _parse_body_macro(self:Parser)->t.Tuple[str,t.Optional[exp.Expression]]:
	name=self._next and self._next.text.upper()
	if name==_I:return'joins',self._parse_join()
	if name==_J:return'where',self._parse_where()
	if name==_K:return'group',self._parse_group()
	if name==_L:return'having',self._parse_having()
	if name==_M:return'order',self._parse_order()
	if name==_N:return'limit',self._parse_limit()
	return'',_A
def _parse_with(self:Parser,skip_with_token:bool=_C)->t.Optional[exp.Expression]:
	macro=_parse_matching_macro(self,'WITH')
	if not macro:return self.__parse_with(skip_with_token=skip_with_token)
	macro.this.append(_D,self.__parse_with(skip_with_token=_B));return macro
def _parse_join(self:Parser,skip_join_token:bool=_C,parse_bracket:bool=_C)->t.Optional[exp.Expression]:
	index=self._index;method,side,kind=self._parse_join_parts();macro=_parse_matching_macro(self,_I)
	if not macro:self._retreat(index);return self.__parse_join(skip_join_token=skip_join_token,parse_bracket=parse_bracket)
	join=self.__parse_join(skip_join_token=_B)
	if method:join.set('method',method.text)
	if side:join.set('side',side.text)
	if kind:join.set('kind',kind.text)
	macro.this.append(_D,join);return macro
def _warn_unsupported(self:Parser)->_A:from vulcan.core.console import get_console;sql=self._find_sql(self._tokens[0],self._tokens[-1])[:self.error_message_context];get_console().log_warning(f"'{sql}' could not be semantically understood as it contains unsupported syntax, Vulcan will treat the command as is. Note that any references to the model's underlying physical table can't be resolved in this case, consider using Jinja as explained here https://vulcan.readthedocs.io/en/stable/concepts/macros/macro_variables/#audit-only-variables")
def _parse_select(self:Parser,nested:bool=_C,table:bool=_C,parse_subquery_alias:bool=_B,parse_set_operation:bool=_B,consume_pipe:bool=_B,from_:t.Optional[exp.From]=_A)->t.Optional[exp.Expression]:
	select=self.__parse_select(nested=nested,table=table,parse_subquery_alias=parse_subquery_alias,parse_set_operation=parse_set_operation,consume_pipe=consume_pipe,from_=from_)
	if not select and not parse_set_operation and self._match_pair(TokenType.PARAMETER,TokenType.VAR,advance=_C):self._advance();return _parse_macro(self)
	return select
def _parse_where(self:Parser,skip_where_token:bool=_C)->t.Optional[exp.Expression]:
	macro=_parse_matching_macro(self,_J)
	if not macro:return self.__parse_where(skip_where_token=skip_where_token)
	macro.this.append(_D,self.__parse_where(skip_where_token=_B));return macro
def _parse_group(self:Parser,skip_group_by_token:bool=_C)->t.Optional[exp.Expression]:
	macro=_parse_matching_macro(self,_K)
	if not macro:return self.__parse_group(skip_group_by_token=skip_group_by_token)
	macro.this.append(_D,self.__parse_group(skip_group_by_token=_B));return macro
def _parse_having(self:Parser,skip_having_token:bool=_C)->t.Optional[exp.Expression]:
	macro=_parse_matching_macro(self,_L)
	if not macro:return self.__parse_having(skip_having_token=skip_having_token)
	macro.this.append(_D,self.__parse_having(skip_having_token=_B));return macro
def _parse_order(self:Parser,this:t.Optional[exp.Expression]=_A,skip_order_token:bool=_C)->t.Optional[exp.Expression]:
	macro=_parse_matching_macro(self,_M)
	if not macro:return self.__parse_order(this,skip_order_token=skip_order_token)
	macro.this.append(_D,self.__parse_order(this,skip_order_token=_B));return macro
def _parse_limit(self:Parser,this:t.Optional[exp.Expression]=_A,top:bool=_C,skip_limit_token:bool=_C)->t.Optional[exp.Expression]:
	macro=_parse_matching_macro(self,'TOP'if top else _N)
	if not macro:return self.__parse_limit(this,top=top,skip_limit_token=skip_limit_token)
	macro.this.append(_D,self.__parse_limit(this,top=top,skip_limit_token=_B));return macro
def _parse_value(self:Parser,values:bool=_B)->t.Optional[exp.Expression]:
	wrapped=self._match(TokenType.L_PAREN,advance=_C);expr=self.__parse_value()
	if expr and not wrapped and isinstance(seq_get(expr.expressions,0),MacroFunc):return expr.expressions[0]
	return expr
def _parse_macro_or_clause(self:Parser,parser:t.Callable)->t.Optional[exp.Expression]:return _parse_macro(self)if self._match(TokenType.PARAMETER)else parser()
def _parse_props(self:Parser)->t.Optional[exp.Expression]:
	key=self._parse_id_var(any_token=_B)
	if not key:return
	name=key.name.lower()
	if name=='time_data_type':value=self._parse_types(schema=_B)
	elif name=='when_matched':value=self._parse_wrapped(lambda:_parse_macro_or_clause(self,self._parse_when_matched),optional=_B)
	elif name=='merge_filter':value=self._parse_conjunction()
	elif self._match(TokenType.L_PAREN):value=self.expression(exp.Tuple,expressions=self._parse_csv(self._parse_equality));self._match_r_paren()
	else:value=self._parse_bracket(self._parse_field(any_token=_B))
	if name=='path'and value:value=exp.Literal.string(value.this.replace('\\','/'))
	return self.expression(exp.Property,this=name,value=value)
def _parse_types(self:Parser,check_func:bool=_C,schema:bool=_C,allow_identifiers:bool=_B)->t.Optional[exp.Expression]:
	start=self._curr;parsed_type=self.__parse_types(check_func=check_func,schema=schema,allow_identifiers=allow_identifiers)
	if schema and parsed_type:parsed_type.meta[_G]=self._find_sql(start,self._prev)
	return parsed_type
def _parse_table_parts(self:Parser,schema:bool=_C,is_db_reference:bool=_C,wildcard:bool=_C)->exp.Table|StagedFilePath:
	index=self._index;table=self.__parse_table_parts(schema=schema,is_db_reference=is_db_reference,wildcard=wildcard);table_arg=table.this;name=table_arg.name if isinstance(table_arg,exp.Var)else''
	if name.startswith(SQLMESH_MACRO_PREFIX):
		if self._prev.token_type==TokenType.STRING or'{'in name or self._curr and self._prev.token_type in(TokenType.L_PAREN,TokenType.R_PAREN)and self._curr.text.upper()not in('FILE_FORMAT','PATTERN')and not(table.args.get('format')or table.args.get('pattern')):self._retreat(index);return Parser._parse_table_parts(self,schema=schema,is_db_reference=is_db_reference)
		table_arg.replace(MacroVar(this=name[1:]));return StagedFilePath(**table.args)
	return table
def _parse_if(self:Parser)->t.Optional[exp.Expression]:
	index=self._index
	try:return self.__parse_if()
	except ParseError:
		self._retreat(index);self._match_l_paren();cond=self._parse_conjunction();self._match(TokenType.COMMA);last_token=self._tokens[-1]
		if last_token.token_type==TokenType.R_PAREN:self._tokens[-2].comments.extend(last_token.comments);self._tokens.pop()
		else:self.raise_error('Expecting )')
		index=self._index;stmt=self._parse_statement()
		if self._curr:self._retreat(index);stmt=self._parse_as_command(self._tokens[index])
		return exp.Anonymous(this='IF',expressions=[cond,stmt])
def _create_parser(expression_type:t.Type[exp.Expression],table_keys:t.List[str])->t.Callable:
	def parse(self:Parser)->t.Optional[exp.Expression]:
		from vulcan.core.model.kind import ModelKindName;expressions:t.List[exp.Expression]=[]
		while _B:
			prev_property=seq_get(expressions,-1)
			if not self._match(TokenType.COMMA,expression=prev_property)and expressions:break
			key_expression=self._parse_id_var(any_token=_B)
			if not key_expression:break
			if isinstance(key_expression,MacroFunc):expressions.append(key_expression);continue
			key=key_expression.name.lower();start=self._curr;value:t.Optional[exp.Expression|str]
			if key in table_keys:
				value=self._parse_table_parts()
				if value and self._prev.token_type==TokenType.STRING:self.raise_error(f"'{key}' property cannot be a string value: {value}. Please use the identifier syntax instead, e.g. foo.bar instead of 'foo.bar'")
			elif key=='columns':value=self._parse_schema()
			elif key=='kind':
				field=_parse_macro_or_clause(self,lambda:self._parse_id_var(any_token=_B))
				if not field or isinstance(field,(MacroVar,MacroFunc)):value=field
				else:
					try:kind=ModelKindName[field.name.upper()]
					except KeyError:raise VulcanError(f"Model kind specified as '{field.name}', but that is not a valid model kind.\n\nPlease specify one of {', '.join(ModelKindName)}.")
					if kind in(ModelKindName.INCREMENTAL_BY_TIME_RANGE,ModelKindName.INCREMENTAL_BY_UNIQUE_KEY,ModelKindName.INCREMENTAL_BY_PARTITION,ModelKindName.INCREMENTAL_UNMANAGED,ModelKindName.SEED,ModelKindName.VIEW,ModelKindName.SCD_TYPE_2,ModelKindName.SCD_TYPE_2_BY_TIME,ModelKindName.SCD_TYPE_2_BY_COLUMN,ModelKindName.CUSTOM)and self._match(TokenType.L_PAREN,advance=_C):props=self._parse_wrapped_csv(functools.partial(_parse_props,self))
					else:props=_A
					value=self.expression(ModelKind,this=kind.value,expressions=props)
			elif key==_S:value=self._parse_conjunction()
			elif key=='partitioned_by':
				partitioned_by=self._parse_partitioned_by()
				if isinstance(partitioned_by.this,exp.Schema):value=exp.tuple_(*partitioned_by.this.expressions)
				else:value=partitioned_by.this
			else:value=self._parse_bracket(self._parse_field(any_token=_B))
			if isinstance(value,exp.Expression):value.meta[_G]=self._find_sql(start,self._prev)
			expressions.append(self.expression(exp.Property,this=key,value=value))
		return self.expression(expression_type,expressions=expressions)
	return parse
MODEL_DDL_KEYWORDS=frozenset({_O,'ASSET'})
AUDIT_DDL_KEYWORDS=frozenset({_P,_T})
PARSERS={_O:_create_parser(Model,[_H]),'ASSET':_create_parser(Model,[_H]),_P:_create_parser(Audit,[_R]),_T:_create_parser(Audit,[_R]),_Q:_create_parser(Metric,[_H])}
def _props_sql(self:Generator,expressions:t.List[exp.Expression])->str:
	props=[];size=len(expressions)
	for(i,prop)in enumerate(expressions):
		if isinstance(prop,MacroFunc):sql=self.indent(self.sql(prop,comment=_C))
		else:sql=self.indent(f"{prop.name} {self.sql(prop,'value')}")
		if i<size-1:sql+=','
		props.append(self.maybe_comment(sql,expression=prop))
	return _F.join(props)
def _on_virtual_update_sql(self:Generator,expressions:t.List[exp.Expression])->str:statements=_F.join(self.sql(expression)if isinstance(expression,JinjaStatement)else f"{self.sql(expression)};"for expression in expressions);return f"{ON_VIRTUAL_UPDATE_BEGIN};\n{statements}\n{ON_VIRTUAL_UPDATE_END};"
def _vulcan_ddl_sql(self:Generator,expression:Model|Audit|Metric,name:str)->str:return _F.join([f"{name} (",_props_sql(self,expression.expressions),')'])
def _model_kind_sql(self:Generator,expression:ModelKind)->str:
	props=_props_sql(self,expression.expressions)
	if props:return _F.join([f"{expression.this} (",props,')'])
	return expression.name.upper()
def _macro_keyword_func_sql(self:Generator,expression:exp.Expression)->str:name=expression.name;keyword=name.replace('_',' ');*args,clause=expression.expressions;macro=f"@{name}({self.format_args(*args)})";return self.sql(clause).replace(keyword,macro,1)
def _macro_func_sql(self:Generator,expression:MacroFunc)->str:
	expression=expression.this;name=expression.name
	if name in KEYWORD_MACROS:sql=_macro_keyword_func_sql(self,expression)
	else:sql=f"@{name}({self.format_args(*expression.expressions)})"
	return self.maybe_comment(sql,expression)
def _whens_sql(self:Generator,expression:exp.Whens)->str:
	if isinstance(expression.parent,exp.Merge):return self.whens_sql(expression)
	return self.wrap(self.expressions(expression,sep=' ',indent=_C))
def _override(klass:t.Type[Tokenizer|Parser],func:t.Callable)->_A:name=func.__name__;setattr(klass,f"_{name}",getattr(klass,name));setattr(klass,name,func)
def format_model_expressions(expressions:t.List[exp.Expression],dialect:t.Optional[str]=_A,rewrite_casts:bool=_B,**kwargs:t.Any)->str:
	if len(expressions)==1 and is_meta_expression(expressions[0]):return expressions[0].sql(pretty=_B,dialect=dialect)
	if rewrite_casts:
		def cast_to_colon(node:exp.Expression)->exp.Expression:
			if isinstance(node,exp.Cast)and not any(arg for(name,arg)in node.args.items()if name not in(_E,'to')):
				this=node.this
				if not isinstance(this,(exp.Binary,exp.Unary))or isinstance(this,exp.Paren):cast=DColonCast(this=this,to=node.to);cast.comments=node.comments;node=cast
			exp.replace_children(node,cast_to_colon);return node
		new_expressions=[]
		for expression in expressions:expression=expression.copy();exp.replace_children(expression,cast_to_colon);new_expressions.append(expression)
		expressions=new_expressions
	formatted=';\n\n'.join(expression.sql(pretty=_B,dialect=dialect,**kwargs)for expression in expressions).strip();from vulcan.utils.sql import _normalize_block_comments;formatted=_normalize_block_comments(formatted);return formatted
def text_diff(a:t.List[exp.Expression],b:t.List[exp.Expression],a_dialect:t.Optional[str]=_A,b_dialect:t.Optional[str]=_A,fromfile:str='',tofile:str='')->str:a_sql=[line for expr in a for line in expr.sql(pretty=_B,comments=_C,dialect=a_dialect).split(_F)];b_sql=[line for expr in b for line in expr.sql(pretty=_B,comments=_C,dialect=b_dialect).split(_F)];logger.debug('text_diff A (%d lines):\n%s\ntext_diff B (%d lines):\n%s',len(a_sql),_F.join(a_sql),len(b_sql),_F.join(b_sql));return _F.join(unified_diff(a_sql,b_sql,fromfile=fromfile,tofile=tofile,n=5))
DIALECT_PATTERN=re.compile("(model|audit).*?\\(.*?dialect\\s+'?([a-z]*)",re.IGNORECASE|re.DOTALL)
def _is_command_statement(command:str,tokens:t.List[Token],pos:int)->bool:
	try:return tokens[pos].text.upper()==command.upper()and tokens[pos+1].token_type==TokenType.SEMICOLON
	except IndexError:return _C
JINJA_QUERY_BEGIN='JINJA_QUERY_BEGIN'
JINJA_STATEMENT_BEGIN='JINJA_STATEMENT_BEGIN'
JINJA_END='JINJA_END'
ON_VIRTUAL_UPDATE_BEGIN='ON_VIRTUAL_UPDATE_BEGIN'
ON_VIRTUAL_UPDATE_END='ON_VIRTUAL_UPDATE_END'
def _is_jinja_statement_begin(tokens:t.List[Token],pos:int)->bool:return _is_command_statement(JINJA_STATEMENT_BEGIN,tokens,pos)
def _is_jinja_query_begin(tokens:t.List[Token],pos:int)->bool:return _is_command_statement(JINJA_QUERY_BEGIN,tokens,pos)
def _is_jinja_end(tokens:t.List[Token],pos:int)->bool:return _is_command_statement(JINJA_END,tokens,pos)
def jinja_query(query:str)->JinjaQuery:return JinjaQuery(this=exp.Literal.string(query.strip()))
def jinja_statement(statement:str)->JinjaStatement:return JinjaStatement(this=exp.Literal.string(statement.strip()))
def _is_virtual_statement_begin(tokens:t.List[Token],pos:int)->bool:return _is_command_statement(ON_VIRTUAL_UPDATE_BEGIN,tokens,pos)
def _is_virtual_statement_end(tokens:t.List[Token],pos:int)->bool:return _is_command_statement(ON_VIRTUAL_UPDATE_END,tokens,pos)
def virtual_statement(statements:t.List[exp.Expression])->VirtualUpdateStatement:return VirtualUpdateStatement(expressions=statements)
class ChunkType(Enum):JINJA_QUERY=auto();JINJA_STATEMENT=auto();SQL=auto();VIRTUAL_STATEMENT=auto();VIRTUAL_JINJA_STATEMENT=auto()
def parse_one(sql:str,dialect:t.Optional[str]=_A,into:t.Optional[exp.IntoType]=_A)->exp.Expression:
	expressions=parse(sql,default_dialect=dialect,match_dialect=_C,into=into)
	if not expressions:raise VulcanError(f"No expressions found in '{sql}'")
	elif len(expressions)>1:raise VulcanError(f"Multiple expressions found in '{sql}'")
	return expressions[0]
def infer_statement_kind(sql:str,dialect:str)->t.Optional[str]:
	from sqlglot import parse_one as sqlglot_parse_one;from sqlglot.errors import SqlglotError
	if not sql or not sql.strip():return
	try:expression=sqlglot_parse_one(sql,read=dialect)
	except SqlglotError:return
	except Exception:logger.debug('infer_statement_kind failed for dialect=%s',dialect,exc_info=_B);return
	return expression.key.upper()if expression else _A
def parse(sql:str,default_dialect:t.Optional[str]=_A,match_dialect:bool=_B,into:t.Optional[exp.IntoType]=_A)->t.List[exp.Expression]:
	match=match_dialect and DIALECT_PATTERN.search(sql[:MAX_MODEL_DEFINITION_SIZE]);dialect=Dialect.get_or_raise(match.group(2)if match else default_dialect);tokens=dialect.tokenize(sql);chunks:t.List[t.Tuple[t.List[Token],ChunkType]]=[([],ChunkType.SQL)];total=len(tokens);pos=0;virtual=_C
	while pos<total:
		token=tokens[pos]
		if _is_virtual_statement_end(tokens,pos):chunks[-1][0].append(token);virtual=_C;chunks.append(([],ChunkType.SQL));pos+=2
		elif _is_jinja_end(tokens,pos)or chunks[-1][1]==ChunkType.SQL and token.token_type==TokenType.SEMICOLON and pos<total-1:
			if token.token_type==TokenType.SEMICOLON:pos+=1
			else:chunks[-1][0].append(token);pos+=2
			chunks.append(([],ChunkType.VIRTUAL_STATEMENT if virtual and tokens[pos]!=ON_VIRTUAL_UPDATE_END else ChunkType.SQL))
		elif _is_jinja_query_begin(tokens,pos):chunks.append(([token],ChunkType.JINJA_QUERY));pos+=2
		elif _is_jinja_statement_begin(tokens,pos):chunks.append(([token],ChunkType.JINJA_STATEMENT));pos+=2
		elif _is_virtual_statement_begin(tokens,pos):chunks.append(([token],ChunkType.VIRTUAL_STATEMENT));pos+=2;virtual=_B
		else:chunks[-1][0].append(token);pos+=1
	parser=dialect.parser();expressions:t.List[exp.Expression]=[]
	def parse_sql_chunk(chunk:t.List[Token],meta_sql:bool=_B)->t.List[exp.Expression]:
		parsed_expressions:t.List[t.Optional[exp.Expression]]=parser.parse(chunk,sql)if into is _A else parser.parse_into(into,chunk,sql);expressions=[]
		for expression in parsed_expressions:
			if expression:
				if meta_sql:expression.meta[_G]=parser._find_sql(chunk[0],chunk[-1])
				expressions.append(expression)
		return expressions
	def parse_jinja_chunk(chunk:t.List[Token],meta_sql:bool=_B)->exp.Expression:
		start,*_,end=chunk;segment=sql[start.end+2:end.start-1];factory=jinja_query if chunk_type==ChunkType.JINJA_QUERY else jinja_statement;expression=factory(segment.strip())
		if meta_sql:expression.meta[_G]=sql[start.start:end.end+1]
		return expression
	def parse_virtual_statement(chunks:t.List[t.Tuple[t.List[Token],ChunkType]],pos:int)->t.Tuple[t.List[exp.Expression],int]:
		virtual_update_statements=[];start=chunks[pos][0][0].start
		while chunks[pos-1][0]==[]or chunks[pos-1][0][-1].text.upper()!=ON_VIRTUAL_UPDATE_END:
			chunk,chunk_type=chunks[pos]
			if chunk_type==ChunkType.JINJA_STATEMENT:virtual_update_statements.append(parse_jinja_chunk(chunk,_C))
			else:virtual_update_statements.extend(parse_sql_chunk(chunk[int(chunk[0].text.upper()==ON_VIRTUAL_UPDATE_BEGIN):-1],_C))
			pos+=1
		if virtual_update_statements:statements=virtual_statement(virtual_update_statements);end=chunk[-1].end+1;statements.meta[_G]=sql[start:end];return[statements],pos
		return[],pos
	pos=0;total_chunks=len(chunks)
	while pos<total_chunks:
		chunk,chunk_type=chunks[pos]
		if chunk_type==ChunkType.VIRTUAL_STATEMENT:virtual_expression,pos=parse_virtual_statement(chunks,pos);expressions.extend(virtual_expression)
		elif chunk_type==ChunkType.SQL:expressions.extend(parse_sql_chunk(chunk))
		else:expressions.append(parse_jinja_chunk(chunk))
		pos+=1
	return expressions
def extend_sqlglot()->_A:
	tokenizers={Tokenizer};parsers={Parser};generators={Generator}
	for dialect in Dialect.classes.values():
		if dialect==athena.Athena:tokenizers.add(athena._TrinoTokenizer);parsers.add(athena._TrinoParser);generators.add(athena._TrinoGenerator);generators.add(athena._HiveGenerator)
		if hasattr(dialect,'Tokenizer'):tokenizers.add(dialect.Tokenizer)
		if hasattr(dialect,'Parser'):parsers.add(dialect.Parser)
		if hasattr(dialect,'Generator'):generators.add(dialect.Generator)
	for tokenizer in tokenizers:tokenizer.VAR_SINGLE_TOKENS.update(SQLMESH_MACRO_PREFIX)
	for parser in parsers:parser.FUNCTIONS.update({'JINJA':Jinja.from_arg_list,_Q:MetricAgg.from_arg_list});parser.PLACEHOLDER_PARSERS.update({TokenType.PARAMETER:_parse_macro});parser.QUERY_MODIFIER_PARSERS.update({TokenType.PARAMETER:lambda self:_parse_body_macro(self)})
	for generator in generators:
		if MacroFunc not in generator.TRANSFORMS:generator.TRANSFORMS.update({Audit:lambda self,e:_vulcan_ddl_sql(self,e,_P),DColonCast:lambda self,e:f"{self.sql(e,_E)}::{self.sql(e,'to')}",Jinja:lambda self,e:e.name,JinjaQuery:lambda self,e:f"{JINJA_QUERY_BEGIN};\n{e.name}\n{JINJA_END};",JinjaStatement:lambda self,e:f"{JINJA_STATEMENT_BEGIN};\n{e.name}\n{JINJA_END};",VirtualUpdateStatement:lambda self,e:_on_virtual_update_sql(self,e),MacroDef:lambda self,e:f"@DEF({self.sql(e.this)}, {self.sql(e.expression)})",MacroFunc:_macro_func_sql,MacroStrReplace:lambda self,e:f"@{self.sql(e.this)}",MacroSQL:lambda self,e:f"@SQL({self.sql(e.this)})",MacroVar:lambda self,e:f"@{e.name}",Metric:lambda self,e:_vulcan_ddl_sql(self,e,_Q),Model:lambda self,e:_vulcan_ddl_sql(self,e,_O),ModelKind:_model_kind_sql,PythonCode:lambda self,e:self.expressions(e,sep=_F,indent=_C),StagedFilePath:lambda self,e:self.table_sql(e),exp.Whens:_whens_sql})
		if MacroDef not in generator.WITH_SEPARATED_COMMENTS:generator.WITH_SEPARATED_COMMENTS=*generator.WITH_SEPARATED_COMMENTS,Model,MacroDef
		generator.UNWRAPPED_INTERVAL_VALUES=*generator.UNWRAPPED_INTERVAL_VALUES,MacroStrReplace,MacroVar
	_override(Parser,_parse_select);_override(Parser,_parse_statement);_override(Parser,_parse_join);_override(Parser,_parse_order);_override(Parser,_parse_where);_override(Parser,_parse_group);_override(Parser,_parse_with);_override(Parser,_parse_having);_override(Parser,_parse_limit);_override(Parser,_parse_value);_override(Parser,_parse_lambda);_override(Parser,_parse_types);_override(Parser,_parse_if);_override(Parser,_parse_id_var);_override(Parser,_warn_unsupported);_override(Snowflake.Parser,_parse_table_parts);DuckDB.Parser.NO_PAREN_FUNCTION_PARSERS.pop('@',_A)
def select_from_values(values:t.List[t.Tuple[t.Any,...]],columns_to_types:t.Dict[str,exp.DataType],batch_size:int=0,alias:str='t')->t.Iterator[exp.Select]:
	if batch_size<=0:batch_size=sys.maxsize
	num_rows=len(values)
	for i in range(0,num_rows,batch_size):yield select_from_values_for_batch_range(values=values,target_columns_to_types=columns_to_types,batch_start=i,batch_end=min(i+batch_size,num_rows),alias=alias)
def select_from_values_for_batch_range(values:t.List[t.Tuple[t.Any,...]],target_columns_to_types:t.Dict[str,exp.DataType],batch_start:int,batch_end:int,alias:str='t',source_columns:t.Optional[t.List[str]]=_A)->exp.Select:
	source_columns=source_columns or list(target_columns_to_types);source_columns_to_types=get_source_columns_to_types(target_columns_to_types,source_columns)
	if not values:where=exp.false();expressions=[tuple(exp.cast(exp.null(),to=kind)for kind in source_columns_to_types.values())]
	else:where=_A;expressions=[tuple(transform_values(v,source_columns_to_types))for v in values[batch_start:batch_end]]
	values_exp=exp.values(expressions,alias=alias,columns=source_columns_to_types)
	if values:
		for(value,kind)in zip(values_exp.expressions[0].expressions,source_columns_to_types.values()):
			if isinstance(value,exp.Null):value.replace(exp.cast(value,to=kind))
	casted_columns=[exp.alias_(exp.cast(exp.column(column)if column in source_columns_to_types else exp.Null(),to=kind),column,copy=_C)for(column,kind)in target_columns_to_types.items()];return exp.select(*casted_columns).from_(values_exp,copy=_C).where(where,copy=_C)
def pandas_to_sql(df:pd.DataFrame,columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,batch_size:int=0,alias:str='t')->t.Iterator[exp.Select]:yield from select_from_values(values=list(df.itertuples(index=_C,name=_A)),columns_to_types=columns_to_types or columns_to_types_from_df(df),batch_size=batch_size,alias=alias)
def set_default_catalog(table:str|exp.Table,default_catalog:t.Optional[str])->exp.Table:
	table=exp.to_table(table)
	if default_catalog and not table.catalog and table.db:table.set(_U,exp.parse_identifier(default_catalog))
	return table
@lru_cache(maxsize=16384)
def normalize_model_name(table:str|exp.Table|exp.Column,default_catalog:t.Optional[str],dialect:DialectType=_A)->str:
	if isinstance(table,exp.Column):table=exp.table_(table.this,db=table.args.get('table'),catalog=table.args.get('db'))
	else:table=exp.to_table(table,dialect=dialect)
	table=set_default_catalog(table,default_catalog);return exp.table_name(normalize_identifiers(table,dialect=dialect),identify=_B)
def fqn_to_unquoted(fqn:str,dialect:DialectType=_A)->str:
	table=exp.to_table(fqn,dialect=dialect);parts=[]
	if table.catalog:parts.append(table.catalog)
	if table.db:parts.append(table.db)
	if table.name:parts.append(table.name)
	return'.'.join(parts)
def normalize_identifier(value:t.Optional[str],dialect:DialectType=_A)->str:
	raw=(value or'').strip()
	if not raw:return''
	if dialect is _A:return raw
	table=exp.to_table(raw,dialect=dialect);normalized=normalize_identifiers(table,dialect=dialect);return normalized.name
def find_tables(expression:exp.Expression,default_catalog:t.Optional[str],dialect:DialectType=_A)->t.Set[str]:
	if TABLES_META not in expression.meta:expression.meta[TABLES_META]={normalize_model_name(table,default_catalog=default_catalog,dialect=dialect)for scope in traverse_scope(expression)for table in scope.tables if table.name and table.name not in scope.cte_sources}
	return expression.meta[TABLES_META]
def find_tables_unquoted(expression:exp.Expression,*,default_catalog:t.Optional[str],dialect:DialectType=_A)->t.Set[str]:return{fqn_to_unquoted(table_ref,dialect=dialect)for table_ref in find_tables(expression,default_catalog=default_catalog,dialect=dialect)}
def add_table(node:exp.Expression,table:str)->exp.Expression:
	def _transform(node:exp.Expression)->exp.Expression:
		if isinstance(node,exp.Column)and not node.table:return exp.column(node.this,table=table)
		if isinstance(node,exp.Identifier):return exp.column(node,table=table)
		return node
	return node.transform(_transform)
def transform_values(values:t.Tuple[t.Any,...],columns_to_types:t.Dict[str,exp.DataType])->t.Iterator[t.Any]:
	def _transform_value(value:t.Any,dtype:exp.DataType)->t.Any:
		if isinstance(value,list)and dtype.is_type(*exp.DataType.ARRAY_TYPES)and len(dtype.expressions)==1:element_type=dtype.expressions[0];return exp.convert([_transform_value(v,element_type)for v in value])
		if isinstance(value,dict)and dtype.is_type(*exp.DataType.STRUCT_TYPES)and len(value)==len(dtype.expressions):
			expressions=[]
			for((field_name,field_value),field_type)in zip(value.items(),dtype.expressions):
				if isinstance(field_type,exp.ColumnDef):field_type=field_type.kind
				else:field_type=exp.DataType.build(exp.DataType.Type.UNKNOWN)
				expressions.append(exp.PropertyEQ(this=exp.to_identifier(field_name),expression=_transform_value(field_value,field_type)))
			return exp.Struct(expressions=expressions)
		if dtype.is_type(exp.DataType.Type.JSON):return exp.func('PARSE_JSON',f"'{value}'")
		return exp.convert(value)
	for(col_value,col_type)in zip(values,columns_to_types.values()):yield _transform_value(col_value,col_type)
def to_schema(sql_path:str|exp.Table,dialect:DialectType=_A)->exp.Table:
	if isinstance(sql_path,exp.Table)and sql_path.this is _A:return sql_path
	table=exp.to_table(sql_path.copy()if isinstance(sql_path,exp.Table)else sql_path,dialect=dialect);table.set(_U,table.args.get('db'));table.set('db',table.args.get(_E));table.set(_E,_A);return table
def schema_(db:exp.Identifier|str,catalog:t.Optional[exp.Identifier|str]=_A,quoted:t.Optional[bool]=_A)->exp.Table:return exp.Table(this=_A,db=exp.to_identifier(db,quoted=quoted)if db else _A,catalog=exp.to_identifier(catalog,quoted=quoted)if catalog else _A)
def normalize_mapping_schema(schema:t.Dict,dialect:DialectType)->MappingSchema:return MappingSchema(_unquote_schema(schema),dialect=dialect,normalize=_C)
def _unquote_schema(schema:t.Dict)->t.Dict:return{k.strip('"'):_unquote_schema(v)if isinstance(v,dict)else v for(k,v)in schema.items()}
@contextmanager
def normalize_and_quote(query:E,dialect:DialectType,default_catalog:t.Optional[str],quote:bool=_B)->t.Iterator[E]:
	qualify_tables(query,catalog=default_catalog,dialect=dialect);normalize_identifiers(query,dialect=dialect);yield query
	if quote:quote_identifiers(query,dialect=dialect)
def interpret_expression(e:exp.Expression)->exp.Expression|str|int|float|bool:
	if e.is_int:return int(e.this)
	if e.is_number:return float(e.this)
	if isinstance(e,(exp.Literal,exp.Boolean)):return e.this
	return e
def interpret_key_value_pairs(e:exp.Tuple)->t.Dict[str,exp.Expression|str|int|float|bool]:return{i.this.name:interpret_expression(i.expression)for i in e.expressions}
def extract_func_call(v:exp.Expression,allow_tuples:bool=_C)->t.Tuple[str,t.Dict[str,exp.Expression]]:
	kwargs={}
	if isinstance(v,exp.Anonymous):func=v.name;args=v.expressions
	elif isinstance(v,exp.Func):func=v.sql_name();args=list(v.args.values())
	elif isinstance(v,exp.Paren):func='';args=[v.this]
	elif isinstance(v,exp.Tuple):
		if not allow_tuples:raise ConfigError('Audit name is missing (eg. MY_AUDIT())')
		func='';args=v.expressions
	else:return v.name.lower(),{}
	for arg in args:
		if not isinstance(arg,(exp.PropertyEQ,exp.EQ)):raise ConfigError(f"Function '{func}' must be called with key-value arguments like {func}(arg := value).")
		kwargs[arg.left.name.lower()]=arg.right
	return func.lower(),kwargs
def extract_function_calls(func_calls:t.Any,allow_tuples:bool=_C)->t.Any:
	if isinstance(func_calls,(exp.Tuple,exp.Array)):return[extract_func_call(i,allow_tuples=allow_tuples)for i in func_calls.expressions]
	if isinstance(func_calls,exp.Paren):return[extract_func_call(func_calls.this,allow_tuples=allow_tuples)]
	if isinstance(func_calls,exp.Expression):return[extract_func_call(func_calls,allow_tuples=allow_tuples)]
	if isinstance(func_calls,list):
		function_calls=[]
		for entry in func_calls:
			if isinstance(entry,dict):args=entry;name=''if allow_tuples else entry.pop(_H)
			elif isinstance(entry,(tuple,list)):name,args=entry
			else:raise ConfigError(f"Audit must be a dictionary or named tuple. Got {entry}.")
			function_calls.append((name.lower(),{key:parse_one(value)if isinstance(value,str)else value for(key,value)in args.items()}))
		return function_calls
	return func_calls or[]
def is_meta_expression(v:t.Any)->bool:return isinstance(v,(Audit,Metric,Model))
def replace_merge_table_aliases(expression:exp.Expression,dialect:t.Optional[str]=_A)->exp.Expression:
	from vulcan.core.engine_adapter.base import MERGE_SOURCE_ALIAS,MERGE_TARGET_ALIAS
	if isinstance(expression,exp.Column)and(first_part:=expression.parts[0]):
		if first_part.this.lower()in('target','dbt_internal_dest','__merge_target__'):first_part.replace(exp.to_identifier(MERGE_TARGET_ALIAS,quoted=_B))
		elif first_part.this.lower()in('source','dbt_internal_source','__merge_source__'):first_part.replace(exp.to_identifier(MERGE_SOURCE_ALIAS,quoted=_B))
	return expression
@dataclass(frozen=_B)
class ParsedColumn:
	col:exp.Column;braced:bool
	@property
	def model(self)->str:return str(self.col.table)
	@property
	def member(self)->str:return str(self.col.name)
@dataclass(frozen=_B)
class ParsedSemanticExpression:columns:t.Tuple[ParsedColumn,...];tree:t.Optional[exp.Expression]
_UNSUPPORTED_SEMANTIC_SQL:t.Tuple[t.Type[exp.Expression],...]=(exp.Subquery,exp.Exists,exp.With,exp.Alias,exp.Lateral)
def reject_unsupported_expressions(tree:exp.Expression,*,context:str)->_A:
	for node in tree.walk():
		if isinstance(node,_UNSUPPORTED_SEMANTIC_SQL):raise_config_error(f"{context}: subqueries (including EXISTS), CTEs, lateral joins, and aliases are not supported",error_type=ConfigError)
def parse_semantic_expression(expression:str,dialect:str,*,owning_model:t.Optional[str]=_A,into:t.Optional[t.Type[exp.Expression]]=_A,context:str=_V)->ParsedSemanticExpression:
	sql=(expression or'').strip()
	if not sql:return ParsedSemanticExpression(columns=(),tree=_A)
	try:
		parse_dialect='databricks2'if dialect=='databricks'else dialect;kwargs:t.Dict[str,t.Any]={'dialect':parse_dialect}
		if into:kwargs['into']=into
		tree=parse_one(sql,**kwargs)
	except(ParseError,VulcanError,ValueError)as exc:raise_config_error(f"{context} could not be parsed: {exc}",error_type=ConfigError)
	reject_unsupported_expressions(tree,context=context);refs:t.List[ParsedColumn]=[];seen:t.Set[t.Tuple[str,str]]=set();consumed_columns:t.Set[int]=set()
	def add_column(*,model_name:str,column_name:str,braced:bool)->_A:
		key=model_name,column_name
		if key in seen:return
		seen.add(key);refs.append(ParsedColumn(col=exp.column(column_name,table=model_name,quoted=_C),braced=braced))
	def is_dot_model_struct(node:exp.Struct)->bool:parent=node.parent;return isinstance(parent,exp.Dot)and parent.left is node
	def is_dot_model_qualifier_column(node:exp.Column)->bool:
		parent=node.parent
		if isinstance(parent,exp.Struct)and is_dot_model_struct(parent):return _B
		return _C
	def reject_disqualified_column(node:exp.Column)->_A:fragment=node.sql(dialect=parse_dialect);model=owning_model or _R;raise_config_error(f"{context}: disqualified column reference {fragment!r}; use bare {node.name!r} or '{{{model}.{node.name}}}'",error_type=ConfigError)
	def reject_braced_catalog_path(col:exp.Column)->_A:
		if col.catalog or col.db:fragment=col.sql(dialect=parse_dialect);raise_config_error(f"{context}: braced reference {fragment!r} must be {{model.member}} with exactly two parts",error_type=ConfigError)
	def reject_reserved_braced_model(model_name:str)->_A:
		if model_name.upper()in frozenset({'TABLE','CUBE'}):raise_config_error(f"{context}: braced reference uses reserved model name {model_name!r}; use bare columns or a semantic model name",error_type=ConfigError)
	def add_braced_member_ref(col:exp.Column)->_A:
		reject_braced_catalog_path(col);table=col.table
		if not table or not col.name:raise_config_error(f"{context}: braced reference must be {{model.member}}",error_type=ConfigError)
		model_name=table if isinstance(table,str)else str(table.name);reject_reserved_braced_model(model_name);add_column(model_name=model_name,column_name=str(col.name),braced=_B);consumed_columns.add(id(col))
	for node in tree.walk():
		if isinstance(node,exp.Dot):
			left=node.left;right=node.right
			if isinstance(left,exp.Struct)and len(left.expressions)==1:
				inner=left.expressions[0];model_name:t.Optional[str]=_A
				if isinstance(inner,exp.Identifier):model_name=inner.name
				elif isinstance(inner,exp.Column)and inner.name and not inner.table:model_name=inner.name
				if model_name and isinstance(right,exp.Identifier)and right.name:raise_config_error(f"{context}: braced qualifier '{{{model_name}}}.{right.name}' is not supported; use bare {right.name!r} or '{{{model_name}.{right.name}}}'",error_type=ConfigError)
			continue
		if isinstance(node,exp.Struct):
			if is_dot_model_struct(node):continue
			struct_cols=[c for c in node.find_all(exp.Column)if c.name and c.table]
			if not struct_cols:fragment=node.sql(dialect=parse_dialect);raise_config_error(f"{context}: braced span {fragment!r} is not a valid {{model.member}} reference",error_type=ConfigError)
			if len(struct_cols)>1:fragment=node.sql(dialect=parse_dialect);raise_config_error(f"{context}: braced span {fragment!r} must contain exactly one {{model.member}} reference",error_type=ConfigError)
			add_braced_member_ref(struct_cols[0]);continue
		if isinstance(node,exp.Column)and node.name and not node.table:
			if is_dot_model_qualifier_column(node):continue
			if not owning_model:raise_config_error(f"{context}: bare column {node.name!r} requires owning_model",error_type=ConfigError)
			consumed_columns.add(id(node));add_column(model_name=owning_model,column_name=str(node.name),braced=_C)
	for node in tree.find_all(exp.Column):
		if id(node)in consumed_columns:continue
		if is_dot_model_qualifier_column(node):continue
		if node.catalog or node.db or node.table:reject_disqualified_column(node)
	return ParsedSemanticExpression(columns=tuple(refs),tree=tree)
def parse_semantic_member_refs(expression:str,dialect:str,*,owning_model:t.Optional[str]=_A,into:t.Optional[t.Type[exp.Expression]]=_A,context:str=_V)->t.Tuple[ParsedColumn,...]:return parse_semantic_expression(expression,dialect,owning_model=owning_model,into=into,context=context).columns
_BOOLEAN_PREDICATE_TYPES:t.Tuple[t.Type[exp.Expression],...]=(exp.And,exp.Or,exp.Not,exp.EQ,exp.NEQ,exp.GT,exp.GTE,exp.LT,exp.LTE,exp.Is,exp.In,exp.Between,exp.Like,exp.ILike,exp.SimilarTo,exp.Boolean)
def is_semantic_boolean_predicate(node:exp.Expression)->bool:
	if isinstance(node,exp.Paren):return is_semantic_boolean_predicate(node.this)
	if isinstance(node,exp.Not):return is_semantic_boolean_predicate(node.this)
	if isinstance(node,exp.And):return is_semantic_boolean_predicate(node.left)and is_semantic_boolean_predicate(node.right)
	if isinstance(node,exp.Or):return is_semantic_boolean_predicate(node.left)and is_semantic_boolean_predicate(node.right)
	if isinstance(node,_BOOLEAN_PREDICATE_TYPES):return _B
	return _C
def wrap_query_with_alias_mapping(sql:str,alias_mapping:dict[str,str],dialect:t.Optional[str]=_A)->str:
	A='_wrapped'
	if not alias_mapping:return sql
	try:original_query=parse_one(sql,dialect=dialect)
	except Exception as e:raise VulcanError(f"Failed to parse SQL: {e}")
	select_expressions=[exp.Alias(this=exp.Column(this=exp.Identifier(this=old_name,quoted=_B)),alias=exp.Identifier(this=new_name,quoted=_B))for(old_name,new_name)in alias_mapping.items()];wrapped_query=exp.select(*select_expressions).from_(A);wrapped_query=wrapped_query.with_(A,original_query)
	try:return wrapped_query.sql(dialect=dialect,pretty=_B)
	except Exception as e:raise VulcanError(f"Failed to generate SQL: {e}")
def outer_select(expression:exp.Expression)->t.Optional[exp.Select]:
	if isinstance(expression,exp.Select):query_expr:t.Optional[exp.Expression]=expression
	elif isinstance(expression,exp.Query):query_expr=expression.args.get(_E)
	else:found=expression.find(exp.Select);return found if isinstance(found,exp.Select)else _A
	if query_expr is _A:return
	select_stmt=query_expr.this if isinstance(query_expr,exp.Alias)and isinstance(query_expr.this,exp.Select)else query_expr;return select_stmt if isinstance(select_stmt,exp.Select)else _A
def map_result_column_projections(result_columns:t.List[str],projections:t.List[exp.Expression],qual_projections:t.List[exp.Expression])->t.Dict[str,exp.Column]:
	if not projections or len(projections)!=len(qual_projections):return{col:exp.column(col,quoted=_B)for col in result_columns}
	alias_to_index={key:index for(index,projection)in enumerate(projections)for key in(projection.alias_or_name,projection.alias_or_name.casefold())};targets:t.Dict[str,exp.Column]={}
	for(col_index,col_name)in enumerate(result_columns):
		index=alias_to_index.get(col_name)or alias_to_index.get(col_name.casefold())
		if index is _A and col_index<len(projections):index=col_index
		alias=qual_projections[index].alias_or_name if index is not _A and index<len(qual_projections)else col_name;targets[col_name]=exp.column(alias,quoted=_B)
	return targets
def remove_outer_limit(expression:exp.Expression)->exp.Expression:
	limit=expression.args.get('limit')
	if limit is not _A:limit.pop()
	return expression
def remove_outer_order(expression:exp.Expression)->exp.Expression:
	order=expression.args.get('order')
	if order is not _A:order.pop()
	return expression
def is_compatible(expected:exp.DataType,inferred:exp.DataType)->bool:
	if expected.this==exp.DataType.Type.UNKNOWN or inferred.this==exp.DataType.Type.UNKNOWN:return _B
	if expected.this==inferred.this:return _B
	compatible_families:tuple[frozenset[exp.DataType.Type],...]=(frozenset({exp.DataType.Type.VARCHAR,exp.DataType.Type.TEXT}),frozenset(exp.DataType.INTEGER_TYPES),frozenset(exp.DataType.REAL_TYPES));return any(expected.this in family and inferred.this in family for family in compatible_families)
def build_expression_probe_query(expressions:t.Mapping[str,str],columns_to_types:t.Mapping[str,exp.DataType],*,dialect:str,source_alias:str='_vulcan_expr_src')->exp.Query:
	from sqlglot import parse_one as sqlglot_parse_one
	if not expressions:raise ValueError('expressions must not be empty')
	column_refs:set[str]=set()
	for sql in expressions.values():column_refs|={column.name for column in sqlglot_parse_one(sql,dialect=dialect).find_all(exp.Column)if column.name and not column.table}
	inner=exp.select(*[exp.alias_(exp.cast(exp.Null(),to=columns_to_types[col_name].copy()),col_name)for col_name in sorted(column_refs)])if column_refs else exp.select(exp.Literal.number(1).as_('__dummy'));query=exp.select(*[exp.alias_(sqlglot_parse_one(parsed_sql,dialect=dialect),output_name)for(output_name,parsed_sql)in sorted(expressions.items())]).from_(inner.subquery(source_alias));schema={source_alias:{col:columns_to_types[col].sql(dialect=dialect)for col in column_refs}}
	if schema[source_alias]:query=qualify(query,dialect=dialect,schema=schema,infer_schema=_C)
	return t.cast(exp.Query,annotate_types(query,schema=schema if schema[source_alias]else _A,dialect=dialect))