from __future__ import annotations
class BiExportError(Exception):
	def __init__(self,*,error_code:str,msg:str)->None:self.error_code=error_code;self.msg=msg;super().__init__(msg)