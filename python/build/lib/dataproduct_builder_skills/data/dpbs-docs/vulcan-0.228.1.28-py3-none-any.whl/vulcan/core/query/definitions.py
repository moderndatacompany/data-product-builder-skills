from __future__ import annotations
_E='before'
_D='transpiler'
_C='rewriter'
_B=True
_A=None
import typing as t
from datetime import datetime,timezone
from enum import Enum
from typing import TYPE_CHECKING,Literal
from pydantic import BaseModel,ConfigDict,Field,computed_field,field_validator,model_validator
from schema.filters.policy import PolicyFilterExpression,humanize_policy_filters
from schema.metadata import Metadata
if TYPE_CHECKING:from vulcan.core.lineage import ColumnLineageRef;from vulcan.core.query.rewriter import RewriteResult;from vulcan.core.query.transpiler.types import SemanticQueryContext
class QueryStrategy(str,Enum):REUSE_RESULT='REUSE_RESULT';AWAIT_PRIMARY='AWAIT_PRIMARY';EXECUTE='EXECUTE'
class QueryType(str,Enum):SOURCE_SQL='SOURCE_SQL';SEMANTIC_SQL='SEMANTIC_SQL';SEMANTIC_REST='SEMANTIC_REST';SEMANTIC_GRAPHQL='SEMANTIC_GRAPHQL';SEMANTIC_METRIC='SEMANTIC_METRIC'
SEMANTIC_QUERY_TYPES:frozenset[QueryType]=frozenset({QueryType.SEMANTIC_REST,QueryType.SEMANTIC_SQL,QueryType.SEMANTIC_GRAPHQL,QueryType.SEMANTIC_METRIC})
class ModelPolicyRule(BaseModel):
	model:str=Field(description='Model name (warehouse FQN or semantic model name).');filter:list[PolicyFilterExpression]|_A=Field(default=_A,description='Row-level filter expressions enforced for the caller group.');mask:list[str]|_A=Field(default=_A,description='Member or column names masked for the caller group.')
	@computed_field
	@property
	def filter_display(self)->str|_A:return humanize_policy_filters(self.filter)
class QueryPolicyAudit(BaseModel):
	policy_enforcer:Literal[_C,_D]=Field(description='Subsystem that applied access control: rewriter for warehouse SOURCE_SQL CTE injection; transpiler for semantic query compilation.');group:str=Field(description='Caller security group used for policy lookup.');applied:bool=Field(description='Whether material policy (filter or mask) applied for at least one model.');rules:list[ModelPolicyRule]=Field(description='Per-model filter and mask snapshots for the caller group at submit time.');ctes:list[str]|_A=Field(default=_A,description='Rewriter-only policy CTE names injected into warehouse SQL. Omitted when empty.')
	@model_validator(mode=_E)
	@classmethod
	def _coerce_legacy_type_field(cls,data:t.Any)->t.Any:
		B='policy_enforcer';A='type'
		if isinstance(data,dict)and A in data and B not in data:updated=dict(data);updated[B]=updated.pop(A);return updated
		return data
	@staticmethod
	def _material_rules_for_group(*,model_names:t.Iterable[str],metadata:Metadata,protected_index:t.Mapping[str,t.AbstractSet[str]]|_A,group:str)->list[ModelPolicyRule]:
		normalized_group=(group or'').strip();rules:list[ModelPolicyRule]=[]
		for model_name in sorted(model_names):
			if protected_index is not _A:
				allowed_groups=protected_index.get(model_name)
				if allowed_groups is _A:continue
				if not normalized_group or normalized_group not in allowed_groups:continue
			entry=metadata.require_entry(model_name);policy=next((p for p in entry.policies if p.group==normalized_group),_A)
			if policy and(policy.filter or policy.mask):rules.append(ModelPolicyRule(model=model_name,filter=policy.filter,mask=policy.mask))
		return rules
	@classmethod
	def from_rewrite_result(cls,result:RewriteResult,*,metadata:Metadata)->QueryPolicyAudit:rules=cls._material_rules_for_group(model_names=result.protected_models,metadata=metadata,protected_index=_A,group=result.group);return cls(policy_enforcer=_C,group=result.group,applied=bool(rules),rules=rules,ctes=list(result.policy_ctes)if result.policy_ctes else _A)
	@classmethod
	def from_semantic_query_context(cls,ctx:SemanticQueryContext)->QueryPolicyAudit:rules=cls._material_rules_for_group(model_names=ctx.flattened_models,metadata=ctx.metadata,protected_index=ctx.index.protected_models,group=ctx.group);return cls(policy_enforcer=_D,group=ctx.group,applied=bool(rules),rules=rules)
	def dump_stored(self)->dict[str,t.Any]:
		data=self.model_dump(exclude_none=_B)
		for rule in data.get('rules',[]):
			if isinstance(rule,dict):rule.pop('filter_display',_A)
		return data
class QueryStatus(str,Enum):ACCEPTED='ACCEPTED';QUEUED='QUEUED';IN_PROGRESS='IN_PROGRESS';SUCCESS='SUCCESS';FAILED='FAILED';CANCELLED='CANCELLED'
ACTIVE_STATUSES:frozenset[QueryStatus]=frozenset({QueryStatus.ACCEPTED,QueryStatus.QUEUED,QueryStatus.IN_PROGRESS})
TERMINAL_STATUSES:frozenset[QueryStatus]=frozenset({QueryStatus.SUCCESS,QueryStatus.FAILED,QueryStatus.CANCELLED})
class QueryDependsOn(BaseModel):model_config=ConfigDict(frozen=_B,from_attributes=_B);model:str=Field(description='Model name.');column:str=Field(description='Upstream model column.');expression:str|_A=Field(default=_A,description='Hop-level SQL expression between the upstream column and the result column. Omitted when the column is passed through unchanged.')
class QueryResultLineage(BaseModel):
	model_config=ConfigDict(frozen=_B);columns:dict[str,list[QueryDependsOn]]=Field(default_factory=dict,description='Map of result column name to upstream model column dependencies. Each value lists refs tracing that result column back to source models.')
	@classmethod
	def from_lineage_sql(cls,result_lineage:t.Mapping[str,t.Sequence[ColumnLineageRef]])->QueryResultLineage:return cls.model_validate({'columns':{col:[QueryDependsOn.model_validate(ref,from_attributes=_B)for ref in refs]for(col,refs)in result_lineage.items()}})
class QueryResult(BaseModel):
	result_id:str;object_store_path:str;row_count:int;size_bytes:int;columns:t.List[t.Dict[str,str]];sql:t.Optional[str]=_A;lineage:QueryResultLineage|_A=_A;created_ts:int
	@field_validator('lineage',mode=_E)
	@classmethod
	def _coerce_lineage(cls,value:t.Any)->QueryResultLineage|_A:
		if value is _A or value=={}:return
		if isinstance(value,QueryResultLineage):return value
		return QueryResultLineage.model_validate(value)
	@computed_field
	@property
	def age_seconds(self)->int:now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return int((now_ts-self.created_ts)/1000)
	@computed_field
	@property
	def size_mb(self)->float:return round(self.size_bytes/1048576,2)
class QueryFingerprintResult(BaseModel):
	fingerprint:str;result_id:str;depends_on:t.Optional[t.List[str]]=_A;cached_at_ts:int;expires_ts:t.Optional[int]=_A;invalidated_by_run_id:t.Optional[str]=_A;invalidated_ts:t.Optional[int]=_A;object_store_path:str;row_count:int;size_bytes:int;columns:t.List[t.Dict[str,str]];result_created_ts:int
	@computed_field
	@property
	def is_expired(self)->bool:
		if self.expires_ts is _A:return False
		now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return now_ts>self.expires_ts
	@computed_field
	@property
	def cache_age_seconds(self)->int:now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return int((now_ts-self.cached_at_ts)/1000)
	@computed_field
	@property
	def result_age_seconds(self)->int:now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return int((now_ts-self.result_created_ts)/1000)
	@computed_field
	@property
	def ttl_seconds(self)->t.Optional[int]:
		if self.expires_ts is _A:return
		return int((self.expires_ts-self.cached_at_ts)/1000)
	@computed_field
	@property
	def size_mb(self)->float:return round(self.size_bytes/1048576,2)
	def to_result(self)->QueryResult:return QueryResult(result_id=self.result_id,object_store_path=self.object_store_path,row_count=self.row_count,size_bytes=self.size_bytes,columns=self.columns,created_ts=self.result_created_ts)
class QueryRequest(BaseModel):
	request_id:str;strategy:QueryStrategy;fingerprint:str;sql_query:str;normalized_sql:str;params:t.Optional[t.Union[t.Dict,t.List]]=_A;depends_on:t.Optional[t.List[str]]=_A;gateway:t.Optional[str]=_A;submitted_by:t.Optional[str]=_A;submitted_ts:int;ttl:int=0;meta:t.Optional[t.Dict]=_A;policy:QueryPolicyAudit|_A=_A;query_type:QueryType;semantic_query:t.Optional[str]=_A;rest_query:t.Optional[t.Dict]=_A;graphql_query:t.Optional[str]=_A;source_query:t.Optional[str]=_A;perspective_id:t.Optional[str]=_A;execution_status:t.Optional[QueryStatus]=_A;pgq_job_id:t.Optional[int]=_A;execution_start_ts:t.Optional[int]=_A;execution_end_ts:t.Optional[int]=_A;primary_request_id:t.Optional[str]=_A;cached_at_ts:t.Optional[int]=_A;result_id:t.Optional[str]=_A;error_message:t.Optional[str]=_A
	@computed_field
	@property
	def execution_duration_ms(self)->t.Optional[int]:
		if self.execution_start_ts is _A or self.execution_end_ts is _A:return
		return self.execution_end_ts-self.execution_start_ts
	@computed_field
	@property
	def queue_wait_time_ms(self)->t.Optional[int]:
		if self.execution_start_ts is _A:return
		return self.execution_start_ts-self.submitted_ts
	@computed_field
	@property
	def total_duration_ms(self)->t.Optional[int]:
		if self.execution_end_ts is _A:return
		return self.execution_end_ts-self.submitted_ts
	@computed_field
	@property
	def age_seconds(self)->int:now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return int((now_ts-self.submitted_ts)/1000)
class Perspective(BaseModel):perspective_id:str;slug:str;name:str;description:t.Optional[str]=_A;tags:t.List[str]=[];terms:t.List[str]=[];owner:str;request_id:t.Optional[str]=_A;fingerprint:str;sql_query:t.Optional[str]=_A;normalized_sql:t.Optional[str]=_A;params:t.Optional[t.Union[t.Dict,t.List]]=_A;gateway:t.Optional[str]=_A;ttl:int=0;meta:t.Optional[t.Dict]=_A;policy:QueryPolicyAudit|_A=_A;query_type:QueryType;semantic_query:t.Optional[str]=_A;rest_query:t.Optional[t.Dict]=_A;graphql_query:t.Optional[str]=_A;source_query:t.Optional[str]=_A;depends_on:t.Optional[t.List[str]]=_A;auto_refresh:bool=_B;is_public:bool=False;allowed_user_ids:t.List[str]=[];created_at:int;updated_at:int;created_by:t.Optional[str]=_A;updated_by:t.Optional[str]=_A