from __future__ import annotations
_K='Requires backfill'
_J='Breaking or non-breaking change category'
_I='SQL or text diff'
_H='before'
_G='BREAKING'
_F='Plan'
_E='INDIRECT_BREAKING'
_D='ignore'
_C=True
_B=False
_A=None
import threading,typing as t
from pathlib import Path
from typing import Any,Literal
from pydantic import ConfigDict,Field
import logging,time
_activity_logger=logging.getLogger(__name__)
from vulcan.core.types import RunDqCounts
from vulcan.core import constants as c
from vulcan.core.node import NodeType,SchemaDrift
from vulcan.core.model.kind import ModelKindName
from vulcan.core.snapshot.definition import Intervals
from vulcan.core.model.definition import AuditResult
from vulcan.core.snapshot import SnapshotChangeCategory,Snapshot,SnapshotIntervals,SnapshotTableInfo
from vulcan.core.soda3.spec import CheckOutcome,QualitySummary,CheckResult,ModelProfile
from vulcan.utils import get_executor
SnapshotChangeCategoryLiteral=Literal[_G,'NON_BREAKING','FORWARD_ONLY',_E,'INDIRECT_NON_BREAKING','METADATA']
from vulcan.utils.pydantic import PydanticModel,model_validator
from vulcan.utils.errors import NodeAuditsErrors
from vulcan.utils.concurrency import NodeExecutionFailedError
from vulcan.utils.date import TimeLike,to_timestamp
from sqlglot import exp
if t.TYPE_CHECKING:from vulcan.core.plan import Plan;from vulcan.core.context_diff import ContextDiff;from vulcan.core.environment import EnvironmentNamingInfo;from vulcan.core.snapshot import Snapshot;from vulcan.core.snapshot.definition import Interval;from vulcan.core.snapshot.execution_tracker import QueryExecutionStats;from vulcan.utils.git import GitClient
class ErrorExec(PydanticModel):
	model_config=ConfigDict(exclude_none=_C,extra=_D);model_fqn:t.Optional[str]=_A;model_name:t.Optional[str]=_A;error_class:str;message:str;is_audit_error:bool=_B;audit_name:t.Optional[str]=_A;audit_failed_rows:t.Optional[int]=_A;audit_sql:t.Optional[str]=_A;audit_args:t.Optional[t.Dict[str,t.Any]]=_A;audit_adapter_dialect:t.Optional[str]=_A
	@staticmethod
	def serialize_audit_args(audit_args:t.Optional[t.Dict[str,t.Any]],dialect:t.Optional[str]=_A)->t.Optional[t.Dict[str,t.Any]]:
		if audit_args is _A or not audit_args:return audit_args
		def _serialize_value(value:t.Any)->t.Any:
			if isinstance(value,exp.Expression):return value.sql(dialect=dialect)if dialect else value.sql()
			elif isinstance(value,dict):return{k:_serialize_value(v)for(k,v)in value.items()}
			elif isinstance(value,(list,tuple)):serialized_list=[_serialize_value(item)for item in value];return tuple(serialized_list)if isinstance(value,tuple)else serialized_list
			else:return value
		serialized={}
		for(key,value)in audit_args.items():serialized[key]=_serialize_value(value)
		return serialized
	@model_validator(mode=_H)
	@classmethod
	def _serialize_audit_args_on_init(cls,data:t.Any)->t.Any:
		A='audit_args'
		if isinstance(data,dict):
			dialect=data.get('audit_adapter_dialect')
			if A in data and data[A]is not _A:data[A]=cls.serialize_audit_args(data[A],dialect=dialect)
		return data
class EnvironmentChange(PydanticModel):environment:str;has_plan:bool=_B;has_run:bool=_B
class BackfillInfo(PydanticModel):
	model_config=ConfigDict(extra=_D);name:str;fqn:str;node_type:NodeType;snapshot_id:str;version:str;model_kind:t.Optional[ModelKindName]=_A;intervals:Intervals;is_directly_modified:bool=_B
	@property
	def merged_intervals(self)->Intervals:from vulcan.core.snapshot.definition import merge_intervals;return merge_intervals(self.intervals)
	def format_intervals(self,unit:t.Optional[str]=_A)->str:from vulcan.core.snapshot.definition import format_intervals;return format_intervals(self.merged_intervals,unit)
	@classmethod
	def from_plan(cls,plan:_F,default_catalog:t.Optional[str]=_A)->t.List['BackfillInfo']:
		context_diff=plan.context_diff;environment_naming_info=plan.environment_naming_info;backfills=[]
		for snapshot_intervals in plan.missing_intervals or[]:
			snapshot_id=snapshot_intervals.snapshot_id
			if not snapshot_intervals.intervals or snapshot_id not in context_diff.snapshots:continue
			snapshot=context_diff.snapshots[snapshot_id];is_directly_modified=snapshot.name in context_diff.modified_snapshots and context_diff.directly_modified(snapshot.name);name=plan.get_snapshot_display_name(snapshot,default_catalog);model_kind=snapshot.model_kind_name if snapshot.node_type==NodeType.MODEL else _A;backfills.append(cls(name=name,fqn=snapshot.name,node_type=snapshot.node_type,snapshot_id=snapshot.identifier,version=snapshot.version,model_kind=model_kind,intervals=snapshot_intervals.intervals,is_directly_modified=is_directly_modified))
		return backfills
class ChangeDisplay(PydanticModel):model_config=ConfigDict(extra=_D);name:str=Field(description='Display name');fqn:str=Field(description='Fully qualified model name');snapshot_id:str=Field(description='Snapshot identifier');version:str=Field(description='Snapshot version hash');node_type:NodeType=Field(description='Changed asset type (model, audit, seed, …)');model_kind:t.Optional[ModelKindName]=Field(default=_A,description='Model materialization kind');source_type:t.Optional[str]=Field(default=_A,description='Authoring layer (sql, semantic, rollup, metric, …)');parents:t.Set[str]=Field(default_factory=set,description='Parent model names within the modified set');diff:str=Field(default='',description=_I)
class ChangeDirect(ChangeDisplay):diff:str=Field(default='',description=_I);indirect:t.List[ChangeDisplay]=Field(default_factory=list,description='Nested indirectly affected models');direct:t.List[ChangeDisplay]=Field(default_factory=list,description='Nested directly modified models');change_category:t.Optional[SnapshotChangeCategoryLiteral]=Field(default=_A,description=_J);data_hash_changed:bool=Field(default=_B,description='Data fingerprint changed');metadata_hash_changed:bool=Field(default=_B,description='Metadata fingerprint changed');parent_data_hash_changed:bool=Field(default=_B,description='Parent data fingerprint changed');old_version:str=Field(default='',description='Prior snapshot version');old_snapshot_id:str=Field(default='',description='Prior snapshot ID');schema_diff:t.Optional['SchemaDrift']=Field(default=_A,description='Schema drift detail');needs_backfill:bool=Field(default=_B,description=_K)
class ChangeIndirect(ChangeDisplay):change_category:t.Optional[SnapshotChangeCategoryLiteral]=Field(default=_A,description=_J);needs_backfill:bool=Field(default=_B,description=_K)
class ChangeAdded(ChangeDisplay):0
class ChangeRemoved(ChangeDisplay):0
class ModelsDiff(PydanticModel):
	model_config=ConfigDict(extra=_D);direct:t.List[ChangeDirect]=Field(default_factory=list,description='Directly modified models');indirect:t.List[ChangeIndirect]=Field(default_factory=list,description='Indirectly affected models');added:t.List[ChangeAdded]=Field(default_factory=list,description='Newly added models');removed:t.List[ChangeRemoved]=Field(default_factory=list,description='Removed models');metadata:t.List[ChangeDisplay]=Field(default_factory=list,description='Metadata-only model changes')
	@classmethod
	def from_plan(cls,plan:_F,default_catalog:t.Optional[str]=_A)->'ModelsDiff':
		A='diff';from vulcan.core.snapshot.definition import SnapshotId;context_diff=plan.context_diff;environment_naming_info=plan.environment_naming_info;modified_snapshots=context_diff.modified_snapshots.items()
		def model_kind(snapshot:Snapshot)->t.Optional[ModelKindName]:
			if snapshot.node_type==NodeType.MODEL:return snapshot.model_kind_name
		def source_type(snapshot:Snapshot)->t.Optional[str]:return snapshot.node.source_type
		def _get_parents(current:Snapshot,visited:t.Optional[t.Dict[str,t.Set[str]]]=_A)->t.Set[str]:
			current_fqn=current.name;visited=visited or{current_fqn:{p.name for p in current.parents}};parents:t.Set[str]=set()
			for parent in current.parents:
				parent_fqn=parent.name
				if parent.name not in context_diff.modified_snapshots:continue
				snapshot,_=context_diff.modified_snapshots[parent.name];parents=parents|{parent_fqn}|visited.get(parent_fqn,_get_parents(snapshot,visited))
			return parents
		def _build_change_display(snapshot:Snapshot,parents:t.Set[str])->ChangeDisplay:return ChangeDisplay(name=plan.get_snapshot_display_name(snapshot,default_catalog),fqn=snapshot.name,snapshot_id=snapshot.identifier,version=snapshot.version,node_type=snapshot.node_type,model_kind=model_kind(snapshot),source_type=source_type(snapshot),parents=parents)
		metadata:t.List[ChangeDisplay]=[];direct:t.List[ChangeDirect]=[];indirect:t.List[ChangeIndirect]=[];added:t.List[ChangeAdded]=[];removed:t.List[ChangeRemoved]=[]
		for(name,(current,old_snap))in modified_snapshots:
			parents=_get_parents(current);base_change=_build_change_display(current,parents)
			if context_diff.directly_modified(name):change_direct=ChangeDirect(**{**base_change.model_dump(),A:context_diff.text_diff(name)or''},change_category=current.change_category.name if current.change_category else _A,data_hash_changed=old_snap.fingerprint.data_hash!=current.fingerprint.data_hash if old_snap else _B,metadata_hash_changed=old_snap.fingerprint.metadata_hash!=current.fingerprint.metadata_hash if old_snap else _B,parent_data_hash_changed=old_snap.fingerprint.parent_data_hash!=current.fingerprint.parent_data_hash if old_snap else _B,old_version=old_snap.version or''if old_snap else'',old_snapshot_id=old_snap.identifier if old_snap else'',schema_diff=context_diff.schema_diff(name),needs_backfill=current.is_new_version);direct.append(change_direct)
			elif context_diff.indirectly_modified(name):change_indirect=ChangeIndirect(**base_change.model_dump(),change_category=current.change_category.name if current.change_category else _A,needs_backfill=current.is_new_version);indirect.append(change_indirect)
			elif context_diff.metadata_updated(name):metadata.append(ChangeDisplay(**{**base_change.model_dump(),A:context_diff.text_diff(name)or''}))
		for snapshot_id in context_diff.added:
			if snapshot_id in context_diff.snapshots:snapshot=context_diff.snapshots[snapshot_id];parents=_get_parents(snapshot);base_change=_build_change_display(snapshot,parents);added.append(ChangeAdded(**base_change.model_dump()))
		for(snapshot_id,snapshot_info)in context_diff.removed_snapshots.items():name=snapshot_info.display_name(environment_naming_info,default_catalog,dialect=_A);removed.append(ChangeRemoved(name=name,fqn=snapshot_info.name,snapshot_id=snapshot_info.identifier,version=snapshot_info.version or'',node_type=snapshot_info.node_type,model_kind=snapshot_info.kind_name,parents=set()))
		for change_direct in direct:change_direct.indirect=[ChangeDisplay(**c.model_dump())for c in indirect if change_direct.fqn in c.parents];change_direct.direct=[ChangeDisplay(**c.model_dump())for c in direct if change_direct.fqn in c.parents]
		return cls(direct=direct,indirect=indirect,added=added,removed=removed,metadata=metadata)
class PlanActivity(PydanticModel):
	model_config=ConfigDict(extra=_D,frozen=_C);plan_id:str;environment:str;start_ts:int;end_ts:int;executor:str='unknown';git_commit_sha:t.Optional[str]=_A;git_commit_url:t.Optional[str]=_A;prev_plan_id:t.Optional[str]=_A;plan_seq:int=0;version:str=c.DEFAULT_VERSION;requirements_diff:t.Optional[str]=_A;env_statements_diff:t.Optional[str]=_A;has_requirements_changes:bool=_B;has_environment_changes:bool=_B;changes:ModelsDiff=Field(default_factory=ModelsDiff,description='Hierarchical plan changes by model');backfills:t.List[BackfillInfo]=Field(default_factory=list);errors:t.List[ErrorExec]=Field(default_factory=list);success:bool=_C
	@model_validator(mode=_H)
	@classmethod
	def _infer_change_flags_from_legacy_diffs(cls,data:t.Any)->t.Any:
		B='has_environment_changes';A='has_requirements_changes'
		if not isinstance(data,dict):return data
		if A not in data:
			req=(data.get('requirements_diff')or'').strip()
			if req:data[A]=_C
		if B not in data:
			env=(data.get('env_statements_diff')or'').strip()
			if env:data[B]=_C
		return data
	@property
	def apply_duration_ts(self)->float:return float(self.end_ts-self.start_ts)
	@property
	def has_changes(self)->bool:return bool(self.changes.direct or self.changes.indirect or self.changes.added or self.changes.removed or self.changes.metadata or self.backfills or self.has_requirements_changes or self.has_environment_changes)
	@property
	def has_breaking_changes(self)->bool:
		for change in self.changes.direct:
			if change.change_category in(_G,_E):return _C
		for change in self.changes.indirect:
			if change.change_category==_E:return _C
		return _B
	@property
	def requires_backfill(self)->bool:return len(self.backfills)>0
	@property
	def models_affected_directly(self)->t.List[str]:
		models=set()
		for change in self.changes.direct+self.changes.added+self.changes.removed:
			if change.node_type==NodeType.MODEL:models.add(change.name)
		return sorted(models)
	@property
	def models_affected_indirectly(self)->t.List[str]:
		models=set()
		for change in self.changes.indirect:
			if change.node_type==NodeType.MODEL:models.add(change.name)
		return sorted(models)
	@property
	def models_affected_metadata(self)->t.List[str]:
		models=set()
		for change in self.changes.metadata:
			if change.node_type==NodeType.MODEL:models.add(change.name)
		return sorted(models)
class AuditOutcomeItem(PydanticModel):model_config=ConfigDict(extra=_D);audit_name:str;skipped:bool;blocking:bool;failed_row_count:t.Optional[int]=_A;passed:bool;query_sql:t.Optional[str]=_A
class ModelIntervalAudits(PydanticModel):model_config=ConfigDict(extra=_D);model_fqn:str;model_name:t.Optional[str]=_A;interval_start:t.Optional[str]=_A;interval_end:t.Optional[str]=_A;outcomes:t.List[AuditOutcomeItem]=Field(default_factory=list)
class IntervalExec(PydanticModel):model_config=ConfigDict(extra=_D);start_ts:int;end_ts:int;evaluation_ms:int=0;rows_affected:int
class ModelExec(PydanticModel):name:str;fqn:str;model_kind:t.Optional[ModelKindName]=_A;source_type:t.Optional[str]=_A;start_ts:int;end_ts:int=0;total_batches:int=0;evaluation_ms:int=0;rows_affected:int=0;bytes_processed:int=0;intervals:t.List[IntervalExec]=Field(default_factory=list)
class RunActivity(PydanticModel):
	model_config=ConfigDict(extra=_D,frozen=_C);run_id:str;run_seq:int=0;plan_id:str;plan_seq:t.Optional[int]=_A;environment:str;start_ts:int;end_ts:int;models_affected:t.List[ModelExec];errors:t.List[ErrorExec]=Field(default_factory=list);audits:t.List[ModelIntervalAudits]=Field(default_factory=list);success:bool
	@property
	def run_duration_ts(self)->float:return float(self.end_ts-self.start_ts)
	@property
	def total_evaluation_ms(self)->int:return sum(m.evaluation_ms for m in self.models_affected)
	@property
	def parallelism_factor(self)->t.Optional[float]:
		if self.run_duration_ts==0:return
		return self.total_evaluation_ms/self.run_duration_ts
	@property
	def rows_affected(self)->int:return sum(m.rows_affected for m in self.models_affected)
	@property
	def bytes_processed(self)->int:return sum(m.bytes_processed for m in self.models_affected)
class RunActivityWithChecksAndProfile(RunActivity):
	plan_version:t.Optional[str]=_A;quality:t.List[CheckResult]=Field(default_factory=list,description='DQ check results');profile:t.List[ModelProfile]=Field(default_factory=list,description='Column profile metrics by model')
	def is_healthy(self)->bool:
		if not self.quality:return _C
		for check_result in self.quality:
			if check_result.outcome==CheckOutcome.FAIL:return _B
		return _C
def build_run_activity(run_id:str,plan_id:str,environment:str,start_ts:int,end_ts:int,models:t.List[ModelExec],errors:t.List[ErrorExec],success:bool,audits:t.Optional[t.List[ModelIntervalAudits]]=_A)->RunActivity:return RunActivity(run_id=run_id,plan_id=plan_id,environment=environment,start_ts=start_ts,end_ts=end_ts,models_affected=models,errors=errors,audits=audits or[],success=success)
def build_plan_activity(plan:_F,start_ts:int,end_ts:int,git_client:'GitClient',default_catalog:t.Optional[str]=_A,errors:t.Optional[t.List[ErrorExec]]=_A,success:bool=_C,version:str=c.DEFAULT_VERSION)->PlanActivity:
	context_diff=plan.context_diff;req_diff:t.Optional[str]=_A
	if context_diff.has_requirement_changes:req_raw=context_diff.requirements_diff();req_diff=req_raw.strip()if req_raw.strip()else _A
	env_diff:t.Optional[str]=_A
	if context_diff.has_environment_statements_changes:env_raw=context_diff.environment_statements_diff_text(include_python_env=not context_diff.is_new_environment);env_diff=env_raw.strip()if env_raw.strip()else _A
	commit_info=git_client.commit_info();git_commit_sha=commit_info.sha;git_commit_url=commit_info.url
	if not git_commit_sha:_activity_logger.warning('Plan activity recorded without git commit SHA (plan_id=%s, work_dir=%s)',plan.plan_id,getattr(git_client,'_work_dir',_A))
	changes=ModelsDiff.from_plan(plan,default_catalog);backfills=BackfillInfo.from_plan(plan,default_catalog);return PlanActivity(plan_id=plan.plan_id,environment=plan.environment.name,start_ts=start_ts,end_ts=end_ts,executor=get_executor(),git_commit_sha=git_commit_sha,git_commit_url=git_commit_url,prev_plan_id=plan.previous_plan_id,changes=changes,backfills=backfills,errors=errors or[],success=success,version=version,requirements_diff=req_diff,env_statements_diff=env_diff,has_requirements_changes=bool(req_diff),has_environment_changes=bool(env_diff))
class RunActivityCaptureMixin:
	_MAX_ERROR_MESSAGE_LEN=2000
	def _init_run_capture_state(self)->_A:self._capture_lock=threading.Lock();(self._model_exec_by_fqn):t.Dict[str,ModelExec]={};(self._interval_audit_records):t.List[ModelIntervalAudits]=[];(self._run_errors):t.List[ErrorExec]=[];self._run_succeeded=_C
	def reset_run_capture(self)->_A:
		with self._capture_lock:self._init_run_capture_state()
	def get_run_capture(self)->t.Tuple[t.List[ModelExec],t.List[ModelIntervalAudits],t.List[ErrorExec],bool]:
		with self._capture_lock:return list(self._model_exec_by_fqn.values()),list(self._interval_audit_records),list(self._run_errors),self._run_succeeded
	def _record_model_started(self,snapshot:Snapshot,*,audit_only:bool)->_A:
		del audit_only
		if not snapshot.is_model:return
		with self._capture_lock:self._model_exec_by_fqn[snapshot.name]=ModelExec(name=snapshot.node.name,fqn=snapshot.name,model_kind=snapshot.model_kind_name,source_type=snapshot.model.source_type,start_ts=int(time.time()))
	def _record_batch_completed(self,snapshot:Snapshot,interval:'Interval',*,evaluation_duration_ms:t.Optional[int],execution_stats:t.Optional['QueryExecutionStats'])->_A:
		if not snapshot.is_model:return
		with self._capture_lock:
			model_exec=self._model_exec_by_fqn.get(snapshot.name)
			if model_exec is _A:return
			model_exec.total_batches+=1
			if evaluation_duration_ms:model_exec.evaluation_ms+=evaluation_duration_ms
			if execution_stats:
				if execution_stats.total_rows_processed is not _A:model_exec.rows_affected+=execution_stats.total_rows_processed
				if execution_stats.total_bytes_processed is not _A:model_exec.bytes_processed+=execution_stats.total_bytes_processed
			model_exec.intervals.append(IntervalExec(start_ts=int(to_timestamp(interval[0]))if interval else 0,end_ts=int(to_timestamp(interval[1]))if interval else 0,evaluation_ms=evaluation_duration_ms if evaluation_duration_ms else 0,rows_affected=execution_stats.total_rows_processed if execution_stats and execution_stats.total_rows_processed is not _A else 0));model_exec.end_ts=int(time.time())
	def _record_audits_completed(self,snapshot:Snapshot,audit_results:t.List[AuditResult],*,start:t.Optional[TimeLike],end:t.Optional[TimeLike],adapter_dialect:str)->_A:
		outcomes:t.List[AuditOutcomeItem]=[]
		for audit_result in audit_results:
			if audit_result.skipped or audit_result.count is _A:passed=_B
			else:passed=audit_result.count==0
			outcomes.append(AuditOutcomeItem(audit_name=audit_result.audit.name,skipped=audit_result.skipped,blocking=audit_result.blocking,failed_row_count=audit_result.count,passed=passed,query_sql=audit_result.query.sql(dialect=adapter_dialect)if audit_result.query is not _A else _A))
		record=ModelIntervalAudits(model_fqn=snapshot.name,model_name=snapshot.node.name if snapshot.is_model else _A,interval_start=str(start)if start is not _A else _A,interval_end=str(end)if end is not _A else _A,outcomes=outcomes)
		with self._capture_lock:self._interval_audit_records.append(record)
		summary='; '.join(f"{item.audit_name}:{'skip'if item.skipped else'pass'if item.passed else f'fail({item.failed_row_count})'}"for item in record.outcomes)or'none';_activity_logger.info('[audits] %s | %s [%s..%s] %s',record.model_name or'-',record.model_fqn,record.interval_start or'?',record.interval_end or'?',summary)
	def _record_run_finished(self,*,succeeded:bool)->_A:
		with self._capture_lock:self._run_succeeded=succeeded
	def _record_execution_failures(self,errors:t.List[NodeExecutionFailedError])->_A:
		from vulcan.core.snapshot import SnapshotId
		with self._capture_lock:
			for error in errors:
				model_fqn:t.Optional[str]=_A;model_name:t.Optional[str]=_A
				if isinstance(error.node,SnapshotId):model_fqn=error.node.name
				elif hasattr(error.node,'snapshot_name'):model_fqn=error.node.snapshot_name
				if model_fqn and model_fqn in self._model_exec_by_fqn:model_name=self._model_exec_by_fqn[model_fqn].name
				if isinstance(error.__cause__,NodeAuditsErrors):
					for audit_error in error.__cause__.errors:self._run_errors.append(ErrorExec(model_fqn=model_fqn,model_name=model_name,error_class='AuditError',message=str(audit_error),is_audit_error=_C,audit_name=audit_error.audit_name,audit_failed_rows=audit_error.count,audit_sql=audit_error.query.sql()if audit_error.query else _A,audit_args=audit_error.audit_args,audit_adapter_dialect=audit_error.adapter_dialect))
				else:
					cause=error.__cause__ if error.__cause__ else error;error_msg=str(cause)
					if len(error_msg)>self._MAX_ERROR_MESSAGE_LEN:error_msg=error_msg[:self._MAX_ERROR_MESSAGE_LEN]+'... (truncated)'
					self._run_errors.append(ErrorExec(model_fqn=model_fqn,model_name=model_name,error_class=cause.__class__.__name__,message=error_msg,is_audit_error=_B))
			if errors:self._run_succeeded=_B