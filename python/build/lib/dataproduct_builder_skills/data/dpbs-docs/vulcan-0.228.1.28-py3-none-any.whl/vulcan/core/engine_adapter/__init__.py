from __future__ import annotations
_B='postgres'
_A=None
import typing as t
from vulcan.core.engine_adapter.base import EngineAdapter,EngineAdapterWithIndexSupport
from vulcan.core.engine_adapter.bigquery import BigQueryEngineAdapter
from vulcan.core.engine_adapter.clickhouse import ClickhouseEngineAdapter
from vulcan.core.engine_adapter.databricks import DatabricksEngineAdapter
from vulcan.core.engine_adapter.duckdb import DuckDBEngineAdapter
from vulcan.core.engine_adapter.mssql import MSSQLEngineAdapter
from vulcan.core.engine_adapter.mysql import MySQLEngineAdapter
from vulcan.core.engine_adapter.postgres import PostgresEngineAdapter
from vulcan.core.engine_adapter.redshift import RedshiftEngineAdapter
from vulcan.core.engine_adapter.snowflake import SnowflakeEngineAdapter
from vulcan.core.engine_adapter.spark import SparkEngineAdapter
from vulcan.core.engine_adapter.trino import TrinoEngineAdapter
from vulcan.core.engine_adapter.athena import AthenaEngineAdapter
from vulcan.core.engine_adapter.risingwave import RisingwaveEngineAdapter
from vulcan.core.engine_adapter.fabric import FabricEngineAdapter
from vulcan.core.config.common import TableNamingConvention
DIALECT_TO_ENGINE_ADAPTER={'hive':SparkEngineAdapter,'spark':SparkEngineAdapter,'bigquery':BigQueryEngineAdapter,'clickhouse':ClickhouseEngineAdapter,'duckdb':DuckDBEngineAdapter,'snowflake':SnowflakeEngineAdapter,'databricks':DatabricksEngineAdapter,'redshift':RedshiftEngineAdapter,_B:PostgresEngineAdapter,'mysql':MySQLEngineAdapter,'mssql':MSSQLEngineAdapter,'trino':TrinoEngineAdapter,'athena':AthenaEngineAdapter,'risingwave':RisingwaveEngineAdapter,'fabric':FabricEngineAdapter}
DIALECT_ALIASES={'postgresql':_B}
DIALECT_TO_ADAPTER_KEY={'tsql':'mssql'}
_MATERIALIZATION_SUFFIX_RESERVE=15
_PORTABLE_BASE_IDENTIFIER_LENGTH=63-_MATERIALIZATION_SUFFIX_RESERVE
_ROLLUP_SCHEMA_TMP_SUFFIX_LEN=11
_ROLLUP_VERSION_MAX_LEN=10
_ROLLUP_PHYSICAL_PART_SEP_LEN=2
_POSTGRES_IDENTIFIER_LIMIT=63
def _engine_raw_identifier_length(dialect:str)->int:d=dialect.lower();d=DIALECT_ALIASES.get(d,d);d=DIALECT_TO_ADAPTER_KEY.get(d,d);adapter_cls=DIALECT_TO_ENGINE_ADAPTER.get(d);raw=getattr(adapter_cls,'MAX_IDENTIFIER_LENGTH',_A)if adapter_cls else _A;return raw if raw is not _A else _POSTGRES_IDENTIFIER_LIMIT
def max_base_table_identifier_length_for_dialect(dialect:str)->int:raw=_engine_raw_identifier_length(dialect);return min(raw-_MATERIALIZATION_SUFFIX_RESERVE,_PORTABLE_BASE_IDENTIFIER_LENGTH)
def max_materialized_rollup_base_length(*,dialect:str,rollup_schema:str,naming_convention:t.Optional[TableNamingConvention]=_A)->int:
	naming_convention=naming_convention or TableNamingConvention.SCHEMA_AND_TABLE;engine_limit=_engine_raw_identifier_length(dialect)
	if naming_convention==TableNamingConvention.HASH_MD5:return engine_limit
	fixed=_ROLLUP_SCHEMA_TMP_SUFFIX_LEN+_ROLLUP_VERSION_MAX_LEN+_ROLLUP_PHYSICAL_PART_SEP_LEN
	if naming_convention==TableNamingConvention.SCHEMA_AND_TABLE:fixed+=len(rollup_schema)+_ROLLUP_PHYSICAL_PART_SEP_LEN
	return min(engine_limit-fixed,_POSTGRES_IDENTIFIER_LIMIT-fixed)
def create_engine_adapter(connection_factory:t.Callable[[],t.Any],dialect:str,**kwargs:t.Any)->EngineAdapter:
	dialect=dialect.lower();dialect=DIALECT_ALIASES.get(dialect,dialect);engine_adapter=DIALECT_TO_ENGINE_ADAPTER.get(dialect)
	if engine_adapter is _A:return EngineAdapter(connection_factory,dialect,**kwargs)
	if engine_adapter is EngineAdapterWithIndexSupport:return EngineAdapterWithIndexSupport(connection_factory,dialect,**kwargs)
	return engine_adapter(connection_factory,**kwargs)