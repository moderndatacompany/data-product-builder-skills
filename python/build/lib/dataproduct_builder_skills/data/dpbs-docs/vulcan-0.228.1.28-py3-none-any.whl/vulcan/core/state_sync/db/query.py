from __future__ import annotations
_V='boolean'
_U='source_query'
_T='graphql_query'
_S='rest_query'
_R='semantic_query'
_Q='query_type'
_P='policy'
_O='gateway'
_N='params'
_M='normalized_sql'
_L='sql_query'
_K='created_ts'
_J='perspective_id'
_I='request_id'
_H='depends_on'
_G='fingerprint'
_F='result_id'
_E='text[]'
_D='jsonb'
_C='bigint'
_B=True
_A='text'
import typing as t
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils.migration import ColumnSpec,TableSpec
QUERY_RESULTS=TableSpec(name='_query_results',primary_key=(_F,),description='Query result metadata with Parquet references in object store',columns=(ColumnSpec(_F,_A,indexed=_B),ColumnSpec('object_store_path',_A),ColumnSpec('row_count',_C),ColumnSpec('size_bytes',_C),ColumnSpec('columns',_D),ColumnSpec('sql',_A),ColumnSpec('lineage',_D),ColumnSpec(_K,_C)))
QUERY_FINGERPRINTS=TableSpec(name='_query_fingerprints',primary_key=(_G,),description='Query fingerprint registry mapping fingerprints to results with TTL and run-based invalidation',columns=(ColumnSpec(_G,_A,indexed=_B),ColumnSpec(_F,_A,indexed=_B),ColumnSpec(_H,_E),ColumnSpec(_K,_C),ColumnSpec('expires_ts',_C),ColumnSpec('invalidated_by_run_id',_A,indexed=_B),ColumnSpec('invalidated_ts',_C)))
QUERY_REQUESTS=TableSpec(name='_query_requests',primary_key=(_I,),description='Audit log of query requests with strategy and execution tracking',columns=(ColumnSpec(_I,_A,indexed=_B),ColumnSpec('strategy',_A),ColumnSpec('execution_status',_A),ColumnSpec('primary_request_id',_A,indexed=_B),ColumnSpec(_G,_A,indexed=_B),ColumnSpec(_L,_A),ColumnSpec(_M,_A),ColumnSpec(_N,_D),ColumnSpec(_H,_E),ColumnSpec(_O,_A,indexed=_B),ColumnSpec('submitted_by',_A),ColumnSpec('submitted_ts',_C),ColumnSpec('ttl','int'),ColumnSpec('meta',_D),ColumnSpec(_P,_D),ColumnSpec(_Q,_A),ColumnSpec(_R,_A),ColumnSpec(_S,_D),ColumnSpec(_T,_A),ColumnSpec(_U,_A),ColumnSpec(_J,_A,indexed=_B),ColumnSpec('pgq_job_id',_C),ColumnSpec('execution_start_ts',_C),ColumnSpec('execution_end_ts',_C),ColumnSpec('cached_at_ts',_C),ColumnSpec(_F,_A,indexed=_B),ColumnSpec('error_message',_A)))
QUERY_PERSPECTIVE=TableSpec(name='_query_perspective',primary_key=(_J,),description='Saved queries with auto-refresh capabilities',columns=(ColumnSpec(_J,_A,indexed=_B),ColumnSpec('slug',_A),ColumnSpec('name',_A),ColumnSpec('description',_A),ColumnSpec('tags',_E),ColumnSpec('terms',_E),ColumnSpec('owner',_A),ColumnSpec(_I,_A,indexed=_B),ColumnSpec(_G,_A,indexed=_B),ColumnSpec(_L,_A),ColumnSpec(_M,_A),ColumnSpec(_N,_D),ColumnSpec(_O,_A),ColumnSpec('ttl','int'),ColumnSpec('meta',_D),ColumnSpec(_P,_D),ColumnSpec(_Q,_A),ColumnSpec(_R,_A),ColumnSpec(_S,_D),ColumnSpec(_T,_A),ColumnSpec(_U,_A),ColumnSpec(_H,_E),ColumnSpec('auto_refresh',_V),ColumnSpec('is_public',_V),ColumnSpec('allowed_user_ids',_E),ColumnSpec('created_at',_C),ColumnSpec('updated_at',_C),ColumnSpec('created_by',_A),ColumnSpec('updated_by',_A)))
class QueryState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=None):self.engine_adapter=engine_adapter;self.schema=schema;dialect=engine_adapter.dialect;self.results_table=exp.table_(QUERY_RESULTS.name,db=schema);self.fingerprints_table=exp.table_(QUERY_FINGERPRINTS.name,db=schema);self.requests_table=exp.table_(QUERY_REQUESTS.name,db=schema);self.perspectives_table=exp.table_(QUERY_PERSPECTIVE.name,db=schema);self._results_columns_to_types=QUERY_RESULTS.columns_to_types(dialect);self._fingerprints_columns_to_types=QUERY_FINGERPRINTS.columns_to_types(dialect);self._requests_columns_to_types=QUERY_REQUESTS.columns_to_types(dialect);self._perspectives_columns_to_types=QUERY_PERSPECTIVE.columns_to_types(dialect)