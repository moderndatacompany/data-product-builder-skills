from __future__ import annotations
_R='(unknown path)'
_Q='metrics'
_P='audits'
_O='variables'
_N='gateways'
_M='dialect'
_L='rules'
_K='.sql'
_J=False
_I='.yml'
_H='.py'
_G='.yaml'
_F='project'
_E='utf-8'
_D='r'
_C='models'
_B=True
_A=None
import abc,glob,itertools,logging,linecache,os,re,typing as t
from collections import Counter,defaultdict
from dataclasses import dataclass
from pathlib import Path
from pydantic import TypeAdapter,ValidationError
import concurrent.futures
from ruamel.yaml import YAMLError
from sqlglot.errors import SqlglotError
from sqlglot import exp
from sqlglot.helper import subclasses
from vulcan.core import constants as c
from vulcan.core.audit import Audit,ModelAudit,StandaloneAudit,load_multiple_audits
from vulcan.core.console import Console
from vulcan.core.dialect import parse
from vulcan.core.config.before_after import resolve_after,resolve_before
from vulcan.core.environment import EnvironmentStatements
from vulcan.core.linter.rule import Rule
from vulcan.core.linter.definition import RuleSet
from vulcan.core.macros import MacroRegistry,macro
from vulcan.core.metric import Metric,MetricMeta,expand_metrics,load_metric_ddl
from vulcan.core.model import Model,ModelCache,create_external_model,load_sql_based_models,validate_models
from vulcan.core.model import model as model_registry
from vulcan.core.model.common import make_python_env
from vulcan.core.model.semantic import MetricSpec,SemanticModelSpec
from vulcan.core.signal import signal
from vulcan.core.test import ModelTestMetadata
from vulcan.utils import UniqueKeyDict,sys_path
from vulcan.utils.errors import ConfigError
from vulcan.utils.jinja import JinjaMacroRegistry,MacroExtractor
from vulcan.utils.metaprogramming import Executable,import_python_file
from vulcan.utils.pydantic import validation_error_message
from vulcan.utils.process import create_process_pool_executor
from vulcan.utils.yaml import YAML,load as yaml_load
logger=logging.getLogger(__name__)
_SEMANTIC_YAML_SPEC_ADAPTER:TypeAdapter[SemanticModelSpec]=TypeAdapter[SemanticModelSpec](SemanticModelSpec)
_METRIC_YAML_SPEC_ADAPTER:TypeAdapter[MetricSpec]=TypeAdapter[MetricSpec](MetricSpec)
if t.TYPE_CHECKING:from vulcan.core.context import GenericContext
GATEWAY_PATTERN=re.compile('gateway:\\s*([^\\s]+)')
@dataclass
class LoadedProject:macros:MacroRegistry;jinja_macros:JinjaMacroRegistry;models:UniqueKeyDict[str,Model];standalone_audits:UniqueKeyDict[str,StandaloneAudit];audits:UniqueKeyDict[str,ModelAudit];metrics:UniqueKeyDict[str,Metric];requirements:t.Dict[str,str];excluded_requirements:t.Set[str];environment_statements:t.List[EnvironmentStatements];user_rules:RuleSet;model_test_metadata:t.List[ModelTestMetadata]
class CacheBase(abc.ABC):
	@abc.abstractmethod
	def get_or_load_models(self,target_path:Path,loader:t.Callable[[],t.List[Model]])->t.List[Model]:0
	@abc.abstractmethod
	def put(self,models:t.List[Model],path:Path)->bool:0
	@abc.abstractmethod
	def get(self,path:Path)->t.List[Model]:0
_defaults:t.Optional[t.Dict[str,t.Any]]=_A
_cache:t.Optional[CacheBase]=_A
_config_essentials:t.Optional[t.Dict[str,t.Any]]=_A
_selected_gateway:t.Optional[str]=_A
def _init_model_defaults(config_essentials:t.Dict[str,t.Any],selected_gateway:t.Optional[str],model_loading_defaults:t.Optional[t.Dict[str,t.Any]]=_A,cache:t.Optional[CacheBase]=_A,console:t.Optional[Console]=_A)->_A:
	global _defaults,_cache,_config_essentials,_selected_gateway;_defaults=model_loading_defaults;_cache=cache;_config_essentials=config_essentials;_selected_gateway=selected_gateway
	if console is not _A:from vulcan.core.console import set_console;set_console(console)
def load_sql_models(path:Path)->t.List[Model]:
	assert _defaults;assert _cache
	with open(path,_D,encoding=_E)as file:expressions=parse(file.read(),default_dialect=_defaults[_M])
	models=load_sql_based_models(expressions,path=Path(path).absolute(),**_defaults);return[]if _cache.put(models,path)else models
def get_variables(gateway_name:t.Optional[str]=_A)->t.Dict[str,t.Any]:
	assert _config_essentials;gateway_name=gateway_name or _selected_gateway
	try:gateway=_config_essentials[_N].get(gateway_name)
	except ConfigError:from vulcan.core.console import get_console;get_console().log_warning(f"Gateway '{gateway_name}' not found in project '{_config_essentials[_F]}'.");gateway=_A
	return{**_config_essentials[_O],**(gateway.variables if gateway else{}),c.GATEWAY:gateway_name}
class Loader(abc.ABC):
	def __init__(self,context:GenericContext,path:Path)->_A:import pandas as pd;from vulcan.core.console import get_console;(self._path_mtimes):t.Dict[Path,float]={};self.context=context;self.config_path=path;self.config=self.context.configs[self.config_path];(self._variables_by_gateway):t.Dict[str,t.Dict[str,t.Any]]={};self._console=get_console();self.config_essentials={_F:self.config.project,_O:self.config.variables,_N:self.config.gateways};_init_model_defaults(self.config_essentials,self.context.selected_gateway)
	def load(self,*,validate_models:bool=_B)->LoadedProject:
		A='config.*'
		with sys_path(self.config_path):
			linecache.clearcache();self._path_mtimes.clear();self._load_materializations();signals=self._load_signals();config_mtimes:t.Dict[Path,t.List[float]]=defaultdict(list)
			for config_file in self.config_path.glob(A):self._track_file(config_file);config_mtimes[self.config_path].append(self._path_mtimes[config_file])
			for usage_file in self.config_path.glob('usage.*'):self._track_file(usage_file);config_mtimes[self.config_path].append(self._path_mtimes[usage_file])
			for config_file in c.SQLMESH_PATH.glob(A):self._track_file(config_file);config_mtimes[c.SQLMESH_PATH].append(self._path_mtimes[config_file])
			self._config_mtimes={path:max(mtimes)for(path,mtimes)in config_mtimes.items()};macros,jinja_macros=self._load_scripts();audits:UniqueKeyDict[str,ModelAudit]=UniqueKeyDict(_P);standalone_audits:UniqueKeyDict[str,StandaloneAudit]=UniqueKeyDict('standalone_audits')
			for(name,audit)in self._load_audits(macros=macros,jinja_macros=jinja_macros).items():
				if isinstance(audit,ModelAudit):audits[name]=audit
				else:standalone_audits[name]=audit
			models=self._load_models(macros,jinja_macros,self.context.selected_gateway,audits,signals,should_validate=validate_models);metrics=self._load_metrics();requirements,excluded_requirements=self._load_requirements();environment_statements=self._load_environment_statements(macros=macros);user_rules=self._load_linting_rules();model_test_metadata=self.load_model_tests();project=LoadedProject(macros=macros,jinja_macros=jinja_macros,models=models,audits=audits,standalone_audits=standalone_audits,metrics=expand_metrics(metrics),requirements=requirements,excluded_requirements=excluded_requirements,environment_statements=environment_statements,user_rules=user_rules,model_test_metadata=model_test_metadata);return project
	def reload_needed(self)->bool:return any(not path.exists()or path.stat().st_mtime>initial_mtime for(path,initial_mtime)in self._path_mtimes.copy().items())
	@abc.abstractmethod
	def _load_scripts(self)->t.Tuple[MacroRegistry,JinjaMacroRegistry]:0
	@abc.abstractmethod
	def _load_models(self,macros:MacroRegistry,jinja_macros:JinjaMacroRegistry,gateway:t.Optional[str],audits:UniqueKeyDict[str,ModelAudit],signals:UniqueKeyDict[str,signal],should_validate:bool=_B)->UniqueKeyDict[str,Model]:0
	@abc.abstractmethod
	def _load_audits(self,macros:MacroRegistry,jinja_macros:JinjaMacroRegistry)->UniqueKeyDict[str,Audit]:0
	def _load_environment_statements(self,macros:MacroRegistry)->t.List[EnvironmentStatements]:return[]
	def load_materializations(self)->_A:0
	def _load_materializations(self)->_A:0
	def _load_signals(self)->UniqueKeyDict[str,signal]:return UniqueKeyDict('signals')
	def _load_metrics(self)->UniqueKeyDict[str,MetricMeta]:return UniqueKeyDict(_Q)
	def _load_external_models(self,audits:UniqueKeyDict[str,ModelAudit],cache:CacheBase,gateway:t.Optional[str]=_A)->UniqueKeyDict[str,Model]:
		models:UniqueKeyDict[str,Model]=UniqueKeyDict(_C);inputs_yaml=Path(self.config_path/c.EXTERNAL_MODELS_YAML);external_models_yaml=Path(self.config_path/c.EXTERNAL_MODELS_DEPRECATED_YAML);inputs_dir=self.config_path/c.EXTERNAL_MODELS;external_models_dir=self.config_path/c.EXTERNAL_MODELS_DEPRECATED;paths_to_load=[]
		if inputs_yaml.exists():
			paths_to_load.append(inputs_yaml)
			if external_models_yaml.exists():self._console.log_warning(f"Both '{c.EXTERNAL_MODELS_YAML}' and '{c.EXTERNAL_MODELS_DEPRECATED_YAML}' exist. Only '{c.EXTERNAL_MODELS_YAML}' will be loaded. Remove or merge '{c.EXTERNAL_MODELS_DEPRECATED_YAML}'.")
		elif external_models_yaml.exists():self._console.log_warning(f"'{c.EXTERNAL_MODELS_DEPRECATED_YAML}' is deprecated. Rename it to '{c.EXTERNAL_MODELS_YAML}'.");paths_to_load.append(external_models_yaml)
		if inputs_dir.exists()and inputs_dir.is_dir():paths_to_load.extend(self._glob_paths(inputs_dir,extension=_G))
		if external_models_dir.exists()and external_models_dir.is_dir():self._console.log_warning(f"The '{c.EXTERNAL_MODELS_DEPRECATED}/' directory is deprecated. Move definitions to '{c.EXTERNAL_MODELS}/'.");paths_to_load.extend(self._glob_paths(external_models_dir,extension=_G))
		def _load(path:Path)->t.List[Model]:
			try:
				with open(path,_D,encoding=_E)as file:
					yaml=YAML().load(file)
					if yaml is _A:return[]
					return[create_external_model(defaults=self.config.model_defaults.dict(),path=path,project=self.config.project,audit_definitions=audits,**{_M:self.config.model_defaults.dialect,'default_catalog':self.context.default_catalog,**row})for row in yaml]
			except Exception as ex:raise ConfigError(self._failed_to_load_model_error(path,ex),path)
		for path in paths_to_load:
			self._track_file(path);external_models=cache.get_or_load_models(path,lambda:_load(path))
			for model in external_models:
				if model.gateway is _A:
					if model.fqn in models:raise ConfigError(self._failed_to_load_model_error(path,f"Duplicate external model name: '{model.name}'."),path)
					models[model.fqn]=model
			if gateway:
				gateway=gateway.lower()
				for model in external_models:
					if model.gateway==gateway:
						if model.fqn in models and models[model.fqn].gateway==gateway:raise ConfigError(self._failed_to_load_model_error(path,f"Duplicate external model name: '{model.name}'."),path)
						models.update({model.fqn:model})
		return models
	def _load_requirements(self)->t.Tuple[t.Dict[str,str],t.Set[str]]:
		requirements:t.Dict[str,str]={};excluded_requirements:t.Set[str]=set();requirements_path=self.config_path/c.REQUIREMENTS
		if requirements_path.is_file():
			with open(requirements_path,_D,encoding=_E)as file:
				for line in file:
					line=line.strip()
					if line.startswith('^'):excluded_requirements.add(line[1:]);continue
					args=[k.strip()for k in line.split('==')]
					if len(args)!=2:raise ConfigError(f"Invalid lock file entry '{line.strip()}'. Only 'dep==ver' is supported",requirements_path)
					dep,ver=args;other_ver=requirements.get(dep,ver)
					if ver!=other_ver:raise ConfigError(f"Conflicting requirement {dep}: {ver} != {other_ver}. Fix your {c.REQUIREMENTS} file.",requirements_path)
					requirements[dep]=ver
		return requirements,excluded_requirements
	def _load_linting_rules(self)->RuleSet:return RuleSet()
	def load_model_tests(self)->t.List[ModelTestMetadata]:return[]
	def _model_roots(self)->t.Tuple[Path,...]:return self.config_path/c.MODELS,self.config_path/c.ASSETS
	def _glob_paths(self,path:t.Union[Path,t.Sequence[Path]],ignore_patterns:t.Optional[t.List[str]]=_A,extension:t.Optional[t.Union[str,t.Sequence[str]]]=_A)->t.Generator[Path,_A,_A]:
		ignore_patterns=ignore_patterns or[];paths=(path,)if isinstance(path,Path)else tuple(path)
		if extension is _A:ext_patterns:t.Tuple[str,...]=('',)
		elif isinstance(extension,str):ext_patterns=('',)if extension==''else(extension,)
		else:ext_patterns=tuple(extension)
		ignored_filepaths=set(ignore_patterns)|{ignored_path for ignore_pattern in ignore_patterns for ignored_path in glob.glob(str(self.config_path/ignore_pattern),recursive=_B)}
		for root in paths:
			for ext in ext_patterns:
				for filepath in root.glob(f"**/*{ext}"):
					if any(filepath.match(ignored_filepath)for ignored_filepath in ignored_filepaths):continue
					yield filepath
	def _track_file(self,path:Path)->_A:self._path_mtimes[path]=path.stat().st_mtime
	def _failed_to_load_model_error(self,path:Path,error:t.Union[str,Exception])->str:
		base_message=f"Failed to load model from file '{path}':"
		if isinstance(error,ValidationError):return validation_error_message(error,base_message)
		error_message=str(error).replace('\n','\n  ');return f"{base_message}\n\n  {error_message}"
class SqlMeshLoader(Loader):
	@staticmethod
	def _read_yaml_payload(data:dict,*,accepted_kinds:t.AbstractSet[str],canonical_kind:str,path:t.Optional[Path]=_A)->t.Optional[dict]:
		B='type';A='kind';raw_kind=data.get(A);raw_type=data.get(B);kind=raw_kind.strip().lower()if isinstance(raw_kind,str)and raw_kind.strip()else _A;doc_type=raw_type.strip().lower()if isinstance(raw_type,str)and raw_type.strip()else _A
		if kind and doc_type and kind!=doc_type:location=f" in {path}"if path is not _A else'';raise ConfigError(f"YAML document{location} has conflicting kind/type: kind={raw_kind!r}, type={raw_type!r}.")
		resolved=kind or doc_type
		if resolved not in accepted_kinds:return
		payload=dict(data);payload[A]=canonical_kind;payload.pop(B,_A);return payload
	def _load_and_merge_soda3_dq(self,models:UniqueKeyDict[str,Model])->_A:
		from vulcan.core.soda3.spec import DataQualitySpec,build_dq_rules;from vulcan.core.soda3.runner import validate_dq_spec_sodacl_parses;project=self.config.project;registry:t.Dict[str,DataQualitySpec]={};name_to_fqn:t.Dict[str,str]={m.name:fqn for(fqn,m)in models.items()}
		for yml_path in self._glob_paths(self.config_path,ignore_patterns=self.config.ignore_patterns,extension=(_I,_G)):
			self._track_file(yml_path)
			try:data=yaml_load(yml_path,render_jinja=_B,variables={_F:project},to_snake_case=_J)
			except YAMLError as e:raise ConfigError(f"YAML error in {yml_path}: {e}")from e
			except Exception as e:raise ConfigError(f"Error loading {yml_path}: {e}")from e
			if not data or not isinstance(data,dict):continue
			payload=self._read_yaml_payload(data,accepted_kinds={c.DATA_QUALITY_KIND,c.DATA_QUALITY_KIND_ALIAS},canonical_kind=c.DATA_QUALITY_KIND,path=yml_path)
			if payload is _A:continue
			try:
				raw_rules=payload.get(_L)
				if raw_rules is not _A:
					if not isinstance(raw_rules,list):raise ValueError("'rules' must be a list")
					payload[_L]=build_dq_rules(raw_rules)
				spec=DataQualitySpec.model_validate(payload);spec=spec.model_copy(update={'_path':yml_path,'_rel_path':yml_path.relative_to(self.config_path)})
			except Exception as e:raise ConfigError(f"Invalid kind: dq file {yml_path}: {e}")from e
			dep=spec.depends_on;target_fqn=name_to_fqn.get(dep)
			if target_fqn is _A:raise ConfigError(f"Data quality file {yml_path}: unknown model {dep!r}.")
			if target_fqn in registry:raise ConfigError(f"Duplicate depends_on for model {dep!r} in data quality YAML:\n  First: {registry[target_fqn]._path}\n  Second: {yml_path}")
			validate_dq_spec_sodacl_parses(spec,dep);registry[target_fqn]=spec
		for(name,spec)in registry.items():dict.__setitem__(models,name,models[name].model_copy(update={'dq':spec}));src=spec._path.relative_to(self.config_path);logger.debug('[soda3: loader] %s <<- DQ <<- %s',name,src if src is not _A else _R)
	def _load_and_merge_policy_rules(self,models:UniqueKeyDict[str,Model])->_A:
		from vulcan.core.model.definition import MetricModel,SemanticModel;from vulcan.core.model.policy import PolicyAssetSpec;project=self.config.project;model_to_path:t.Dict[str,Path]={};name_to_fqn:t.Dict[str,str]={m.name:fqn for(fqn,m)in models.items()}
		for yml_path in self._glob_paths(self.config_path,ignore_patterns=self.config.ignore_patterns,extension=(_I,_G)):
			self._track_file(yml_path)
			try:data=yaml_load(yml_path,render_jinja=_B,variables={_F:project},to_snake_case=_J)
			except YAMLError as e:raise ConfigError(f"YAML error in {yml_path}: {e}")from e
			except Exception as e:raise ConfigError(f"Error loading {yml_path}: {e}")from e
			if not data or not isinstance(data,dict):continue
			payload=self._read_yaml_payload(data,accepted_kinds={c.POLICY_KIND},canonical_kind=c.POLICY_KIND,path=yml_path)
			if payload is _A:continue
			try:spec=PolicyAssetSpec.model_validate(payload);spec._path=yml_path;spec._rel_path=yml_path.relative_to(self.config_path)
			except Exception as e:raise ConfigError(f"Invalid kind: policy file {yml_path}: {e}")from e
			for dep in spec.depends_on:
				target_fqn=name_to_fqn.get(dep)
				if target_fqn is _A:raise ConfigError(f"Policy file {yml_path}: unknown model {dep!r}.")
				target_model=models[target_fqn]
				if isinstance(target_model,(MetricModel,SemanticModel)):raise ConfigError(f"Policy file {yml_path} depends_on {dep!r}: attach policy to a physical model only.")
				if dep in model_to_path:raise ConfigError(f"Duplicate depends_on for model {dep!r} in policy YAML:\n  First: {model_to_path[dep]}\n  Second: {yml_path}")
				model_to_path[dep]=yml_path;policy=spec.to_policy_spec();dict.__setitem__(models,target_fqn,target_model.model_copy(update={'policy':policy}));src=spec._path.relative_to(self.config_path);logger.debug('[policy: loader] %s <<- POLICY <<- %s',dep,src if src is not _A else _R)
	def _load_scripts(self)->t.Tuple[MacroRegistry,JinjaMacroRegistry]:
		standard_macros=macro.get_registry();jinja_macros=JinjaMacroRegistry();extractor=MacroExtractor();macros_max_mtime:t.Optional[float]=_A
		for path in self._glob_paths(self.config_path/c.MACROS,ignore_patterns=self.config.ignore_patterns,extension=_H):
			if import_python_file(path,self.config_path):self._track_file(path);macro_file_mtime=self._path_mtimes[path];macros_max_mtime=max(macros_max_mtime,macro_file_mtime)if macros_max_mtime else macro_file_mtime
		for path in self._glob_paths(self.config_path/c.MACROS,ignore_patterns=self.config.ignore_patterns,extension=_K):
			self._track_file(path);macro_file_mtime=self._path_mtimes[path];macros_max_mtime=max(macros_max_mtime,macro_file_mtime)if macros_max_mtime else macro_file_mtime
			with open(path,_D,encoding=_E)as file:jinja_macros.add_macros(extractor.extract(file.read(),dialect=self.config.model_defaults.dialect))
		self._macros_max_mtime=macros_max_mtime;macros=macro.get_registry();macro.set_registry(standard_macros);return macros,jinja_macros
	def _load_semantic_models(self,physical_models:UniqueKeyDict[str,Model])->UniqueKeyDict[str,Model]:
		A='semantic';from vulcan.core.model.definition import create_semantic_model;dialect=self.config.model_defaults.dialect;default_catalog=self.context.default_catalog;project=self.config.project;semantic_specs:t.List[t.Tuple[Path,SemanticModelSpec]]=[]
		for path in self._glob_paths(self._model_roots(),ignore_patterns=self.config.ignore_patterns,extension=(_I,_G)):
			self._track_file(path)
			try:data=yaml_load(path,render_jinja=_B,variables={_F:project},to_snake_case=_J)
			except YAMLError as e:raise ConfigError(f"YAML error in {path}: {e}")from e
			except Exception as e:raise ConfigError(f"Error loading {path}: {e}")from e
			if not isinstance(data,dict):continue
			payload=self._read_yaml_payload(data,accepted_kinds={A},canonical_kind=A,path=path)
			if payload is _A:continue
			try:doc=_SEMANTIC_YAML_SPEC_ADAPTER.validate_python(payload);semantic_specs.append((path,doc))
			except ValidationError as e:raise ConfigError(validation_error_message(e,f"Invalid semantic YAML document in {path}:"),location=path)from e
			except Exception as e:raise ConfigError(f"Invalid semantic YAML document in {path}: {e}",location=path)from e
		all_names=[s.name for(_,s)in semantic_specs]+[m.name for m in physical_models.values()];dupes=[n for(n,c)in Counter(all_names).items()if c>1]
		if dupes:raise ConfigError(f"Duplicate model name(s) found: {', '.join(sorted(dupes))}.",location=self.config_path/c.MODELS)
		physical_by_name:t.Dict[str,Model]={m.name:m for m in physical_models.values()};semantic_models:t.Dict[str,Model]={}
		for(path,spec)in semantic_specs:
			physical=physical_by_name.get(spec.depends_on)
			if physical is _A:raise ConfigError(f"Semantic model {spec.name!r} depends_on unknown physical model {spec.depends_on!r}. depends_on must be a loaded SQL model name.",location=path)
			try:model=create_semantic_model(spec.name,default_catalog=default_catalog,defaults=self.config.model_defaults.dict(),depends_on=physical,dialect=dialect,path=path,module_path=self.config_path,project=project,spec=spec)
			except ValidationError as e:raise ConfigError(validation_error_message(e,f"Invalid semantic model in {path}:"),location=path)from e
			semantic_models[model.fqn]=model
		return UniqueKeyDict(_C,**semantic_models)
	def _load_metric_models(self,semantic_models:UniqueKeyDict[str,Model])->UniqueKeyDict[str,Model]:
		A='metric';from vulcan.core.model.definition import SemanticModel,create_metric_model;dialect=self.config.model_defaults.dialect;default_catalog=self.context.default_catalog;project=self.config.project;metric_specs:t.List[t.Tuple[Path,MetricSpec]]=[]
		for path in self._glob_paths(self.config_path,ignore_patterns=self.config.ignore_patterns,extension=(_I,_G)):
			self._track_file(path)
			try:data=yaml_load(path,render_jinja=_B,variables={_F:project},to_snake_case=_J)
			except YAMLError as e:raise ConfigError(f"YAML error in {path}: {e}")from e
			except Exception as e:raise ConfigError(f"Error loading {path}: {e}")from e
			if not isinstance(data,dict):continue
			payload=self._read_yaml_payload(data,accepted_kinds={A},canonical_kind=A,path=path)
			if payload is _A:continue
			try:doc=_METRIC_YAML_SPEC_ADAPTER.validate_python(payload);metric_specs.append((path,doc))
			except Exception as e:raise ConfigError(f"Invalid semantic YAML document in {path}: {e}",location=path)from e
		all_names=[s.name for(_,s)in metric_specs]+[m.name for m in semantic_models.values()];dupes=[n for(n,c)in Counter(all_names).items()if c>1]
		if dupes:raise ConfigError(f"Duplicate model name(s) found: {', '.join(sorted(dupes))}.",location=self.config_path)
		semantic_by_name:t.Dict[str,SemanticModel]={sm.name:t.cast(SemanticModel,sm)for sm in semantic_models.values()};metric_models:t.Dict[str,Model]={}
		for(path,spec)in metric_specs:
			depends_on_nodes=[semantic_by_name[semantic_name]for semantic_name in sorted(spec.depends_on_semantic_names)if semantic_name in semantic_by_name]
			try:model=create_metric_model(spec.name,default_catalog=default_catalog,defaults=self.config.model_defaults.dict(),depends_on=depends_on_nodes,description=spec.description or _A,dialect=dialect,path=path,module_path=self.config_path,project=project,spec=spec)
			except ValidationError as e:raise ConfigError(validation_error_message(e,f"Invalid metric model in {path}:"),location=path)from e
			metric_models[model.fqn]=model
		return UniqueKeyDict(_C,**metric_models)
	def _load_rollup_models(self,models:UniqueKeyDict[str,Model],gateway:t.Optional[str]=_A)->UniqueKeyDict[str,Model]:
		from vulcan.core.export.cube import build_cube_schema_for_rollups;from vulcan.core.model.definition import SemanticModel,create_rollup_model;from vulcan.core.model.rollup import normalize_rollup_query,transpile_rollup_sql,validate_rollup_query_physical_table_refs,write_rollup_debug_model;from vulcan.utils.errors import TranspilerError;semantics=[m for m in models.values()if isinstance(m,SemanticModel)]
		if not any(semantic.rollups for semantic in semantics):return UniqueKeyDict(_C)
		semantic_models={semantic.name:semantic for semantic in semantics};cfg=self.config;dialect=cfg.model_defaults.dialect;default_catalog=self.context.default_catalog;rollup_schema=cfg.get_rollup_schema(gateway);transpile_schema=build_cube_schema_for_rollups(semantics).model_dump(mode='json',exclude_none=_B);rollup_models:t.Dict[str,Model]={}
		for semantic in semantics:
			for spec in semantic.rollups:
				if spec.is_composite:continue
				involved=spec.involved_semantic_names(semantic.name);depends_on={semantic_models[name].fqn for name in involved};cron_nodes:t.List[Model]=[]
				for name in involved:
					involved_semantic=semantic_models[name];cron_nodes.append(involved_semantic)
					for physical_fqn in involved_semantic.depends_on or():cron_nodes.append(models[physical_fqn])
				rollup_name=f"{rollup_schema}.{semantic.name}_{spec.name}"
				try:raw_sql,params=transpile_rollup_sql(spec=spec,semantic=semantic,transpile_schema=transpile_schema,config=cfg,gateway=gateway);query=normalize_rollup_query(raw_sql,dialect=dialect,params=params);logger.info('Rollup Query <-- %s :: %s',f"{semantic.name}/{spec.name}",' '.join(query.sql(dialect=dialect).split()))
				except TranspilerError as exc:raise ConfigError(f"Failed to transpile rollup {spec.name!r} for semantic model {semantic.name!r}: {exc}",location=semantic._path)from exc
				except ConfigError:raise
				except Exception as exc:raise ConfigError(f"Failed to build rollup {spec.name!r} for semantic model {semantic.name!r}: {exc}",location=semantic._path)from exc
				physical_depends_on=validate_rollup_query_physical_table_refs(query,models=models,default_catalog=default_catalog,dialect=dialect,rollup_name=rollup_name);depends_on|=physical_depends_on
				try:model=create_rollup_model(name=rollup_name,default_catalog=default_catalog,defaults=cfg.model_defaults.dict(),depends_on=depends_on,cron_nodes=cron_nodes,description=spec.description or _A,dialect=dialect,module_path=self.config_path,owner=semantic.owner,path=semantic._path,project=cfg.project,query=query,source_path=semantic.source_path)
				except ValidationError as e:raise ConfigError(validation_error_message(e,f"Invalid rollup model in {semantic._path}:"),location=semantic._path)from e
				write_rollup_debug_model(self.context.cache_dir,model);rollup_models[model.fqn]=model
		return UniqueKeyDict(_C,**rollup_models)
	def _load_models(self,macros:MacroRegistry,jinja_macros:JinjaMacroRegistry,gateway:t.Optional[str],audits:UniqueKeyDict[str,ModelAudit],signals:UniqueKeyDict[str,signal],should_validate:bool=_B)->UniqueKeyDict[str,Model]:
		def _raise_on_duplicates(models:UniqueKeyDict[str,Model])->_A:
			if(dupes:=sorted(k for(k,v)in Counter(m.name for m in models.values()).items()if v>1)):raise ConfigError(f"Duplicate model name(s) found: {', '.join(dupes)}.")
		cache=SqlMeshLoader._Cache(self,self.config_path);sql_models=self._load_sql_models(macros,jinja_macros,audits,signals,cache,gateway);external_models=self._load_external_models(audits,cache,gateway);python_models=self._load_python_models(macros,jinja_macros,audits,signals);physical_models=UniqueKeyDict(_C,**sql_models,**external_models,**python_models);self._load_and_merge_policy_rules(physical_models);semantic_models=self._load_semantic_models(physical_models);metric_models=self._load_metric_models(semantic_models);models:UniqueKeyDict[str,Model]=UniqueKeyDict(_C,**physical_models,**semantic_models,**metric_models);_raise_on_duplicates(models);self._load_and_merge_soda3_dq(models)
		if should_validate:validate_models(models,dialect=self.config.model_defaults.dialect,config_path=self.config_path,default_catalog=self.context.default_catalog,allow_reciprocal_joins=self.config.allow_reciprocal_joins,strict_semantic_validation=self.config.strict_semantic_validation,metric_join_path=self.config.metric_join_path,rollup_schema=self.config.get_rollup_schema(gateway),physical_table_naming_convention=self.config.physical_table_naming_convention)
		if self.config.enable_rollup:
			rollup_models=self._load_rollup_models(models,gateway)
			for(fqn,model)in rollup_models.items():models[fqn]=model
			_raise_on_duplicates(models)
		return models
	def _load_sql_models(self,macros:MacroRegistry,jinja_macros:JinjaMacroRegistry,audits:UniqueKeyDict[str,ModelAudit],signals:UniqueKeyDict[str,signal],cache:CacheBase,gateway:t.Optional[str])->UniqueKeyDict[str,Model]:
		models:UniqueKeyDict[str,Model]=UniqueKeyDict(_C);paths:t.Set[Path]=set();cached_paths:UniqueKeyDict[Path,t.List[Model]]=UniqueKeyDict('cached_paths')
		for path in self._glob_paths(self._model_roots(),ignore_patterns=self.config.ignore_patterns,extension=_K):
			if not os.path.getsize(path):continue
			self._track_file(path);paths.add(path)
			if(cached_models:=cache.get(path)):cached_paths[path]=cached_models
		for(path,cached_models)in cached_paths.items():
			paths.remove(path)
			for model in cached_models:
				if model.enabled:models[model.fqn]=model
		if paths:
			model_loading_defaults=dict(get_variables=get_variables,defaults=self.config.model_defaults.dict(),macros=macros,jinja_macros=jinja_macros,audit_definitions=audits,module_path=self.config_path,dialect=self.config.model_defaults.dialect,time_column_format=self.config.time_column_format,physical_schema_mapping=self.config.physical_schema_mapping,project=self.config.project,default_catalog=self.context.default_catalog,infer_names=self.config.model_naming.infer_names,signal_definitions=signals,default_catalog_per_gateway=self.context.default_catalog_per_gateway,virtual_environment_mode=self.config.virtual_environment_mode)
			with create_process_pool_executor(initializer=_init_model_defaults,initargs=(self.config_essentials,gateway,model_loading_defaults,cache,self._console),max_workers=c.MAX_FORK_WORKERS)as pool:
				futures_to_paths={pool.submit(load_sql_models,path):path for path in paths}
				for future in concurrent.futures.as_completed(futures_to_paths):
					path=futures_to_paths[future]
					try:
						loaded=future.result()
						for model in loaded or cache.get(path):
							if model.fqn in models:raise ConfigError(self._failed_to_load_model_error(path,f"Duplicate SQL model name: '{model.name}'."),path)
							elif model.enabled:model._path=path;models[model.fqn]=model
					except Exception as ex:raise ConfigError(self._failed_to_load_model_error(path,ex),path)
		return models
	def _load_python_models(self,macros:MacroRegistry,jinja_macros:JinjaMacroRegistry,audits:UniqueKeyDict[str,ModelAudit],signals:UniqueKeyDict[str,signal])->UniqueKeyDict[str,Model]:
		models:UniqueKeyDict[str,Model]=UniqueKeyDict(_C);registry=model_registry.registry();registry.clear();registered:t.Set[str]=set();model_registry._dialect=self.config.model_defaults.dialect
		try:
			for path in self._glob_paths(self._model_roots(),ignore_patterns=self.config.ignore_patterns,extension=_H):
				if not os.path.getsize(path):continue
				self._track_file(path)
				try:
					import_python_file(path,self.config_path);new=registry.keys()-registered;registered|=new
					for name in new:
						for model in registry[name].models(get_variables,path=path,module_path=self.config_path,defaults=self.config.model_defaults.dict(),macros=macros,jinja_macros=jinja_macros,dialect=self.config.model_defaults.dialect,time_column_format=self.config.time_column_format,physical_schema_mapping=self.config.physical_schema_mapping,project=self.config.project,default_catalog=self.context.default_catalog,infer_names=self.config.model_naming.infer_names,audit_definitions=audits,signal_definitions=signals,default_catalog_per_gateway=self.context.default_catalog_per_gateway,virtual_environment_mode=self.config.virtual_environment_mode):
							if model.enabled:models[model.fqn]=model
				except Exception as ex:raise ConfigError(self._failed_to_load_model_error(path,ex),path)
		finally:model_registry._dialect=_A
		return models
	def load_materializations(self)->_A:
		with sys_path(self.config_path):self._load_materializations()
	def _load_materializations(self)->_A:
		for path in self._glob_paths(self.config_path/c.MATERIALIZATIONS,ignore_patterns=self.config.ignore_patterns,extension=_H):
			if os.path.getsize(path):import_python_file(path,self.config_path)
	def _load_signals(self)->UniqueKeyDict[str,signal]:
		base_signals=signal.get_registry();signals_max_mtime:t.Optional[float]=_A
		for path in self._glob_paths(self.config_path/c.SIGNALS,ignore_patterns=self.config.ignore_patterns,extension=_H):
			if os.path.getsize(path):self._track_file(path);signal_file_mtime=self._path_mtimes[path];signals_max_mtime=max(signals_max_mtime,signal_file_mtime)if signals_max_mtime else signal_file_mtime;import_python_file(path,self.config_path)
		self._signals_max_mtime=signals_max_mtime;signals=signal.get_registry();signal.set_registry(base_signals);return signals
	def _load_audits(self,macros:MacroRegistry,jinja_macros:JinjaMacroRegistry)->UniqueKeyDict[str,Audit]:
		audits_by_name:UniqueKeyDict[str,Audit]=UniqueKeyDict(_P);audits_max_mtime:t.Optional[float]=_A;variables=get_variables()
		for path in self._glob_paths(self.config_path/c.AUDITS,ignore_patterns=self.config.ignore_patterns,extension=_K):
			self._track_file(path)
			with open(path,_D,encoding=_E)as file:
				audits_file_mtime=self._path_mtimes[path];audits_max_mtime=max(audits_max_mtime,audits_file_mtime)if audits_max_mtime else audits_file_mtime;expressions=parse(file.read(),default_dialect=self.config.model_defaults.dialect);audits=load_multiple_audits(expressions=expressions,path=path,module_path=self.config_path,macros=macros,jinja_macros=jinja_macros,dialect=self.config.model_defaults.dialect,default_catalog=self.context.default_catalog,variables=variables,project=self.config.project)
				for audit in audits:audits_by_name[audit.name]=audit
		self._audits_max_mtime=audits_max_mtime;return audits_by_name
	def _load_metrics(self)->UniqueKeyDict[str,MetricMeta]:
		metrics:UniqueKeyDict[str,MetricMeta]=UniqueKeyDict(_Q)
		for path in self._glob_paths(self.config_path/c.METRICS,ignore_patterns=self.config.ignore_patterns,extension=_K):
			if not os.path.getsize(path):continue
			self._track_file(path)
			with open(path,_D,encoding=_E)as file:
				dialect=self.config.model_defaults.dialect
				try:
					for expression in parse(file.read(),default_dialect=dialect):metric=load_metric_ddl(expression,path=path,dialect=dialect);metrics[metric.name]=metric
				except SqlglotError as ex:raise ConfigError(f"Failed to parse metric definitions at '{path}': {ex}.",path)
		return metrics
	def _load_environment_statements(self,macros:MacroRegistry)->t.List[EnvironmentStatements]:
		product_details=dict(domain=self.config.domain,discoverable=self.config.discoverable,version=self.config.version,alignment=self.config.alignment,status=self.config.status);before_all:t.List[str]=[];after_all:t.List[str]=[];python_env:t.Dict[str,Executable]={}
		if self.config.before_all or self.config.after_all:before_all=resolve_before(self.config_path,self.config.before_all);after_all=resolve_after(self.config_path,self.config.after_all);dialect=self.config.model_defaults.dialect;python_env=make_python_env([exp.maybe_parse(stmt,dialect=dialect)for stmts in(before_all,after_all)for stmt in stmts],module_path=self.config_path,jinja_macro_references=_A,macros=macros,variables=get_variables(),path=self.config_path)
		return[EnvironmentStatements(before_all=before_all,after_all=after_all,python_env=python_env,project=self.config.project or _A,**product_details)]
	def _load_linting_rules(self)->RuleSet:
		user_rules:UniqueKeyDict[str,type[Rule]]=UniqueKeyDict(_L)
		for path in self._glob_paths(self.config_path/c.LINTER,ignore_patterns=self.config.ignore_patterns,extension=_H):
			if os.path.getsize(path):
				self._track_file(path);module=import_python_file(path,self.config_path);module_rules=subclasses(module.__name__,Rule,(Rule,))
				for user_rule in module_rules:user_rules[user_rule.name]=user_rule
		return RuleSet(user_rules.values())
	def _load_model_test_file(self,path:Path)->dict[str,ModelTestMetadata]:
		model_test_metadata={}
		with open(path,_D,encoding=_E)as file:source=file.read();gateway_line=GATEWAY_PATTERN.search(source);gateway=YAML().load(gateway_line.group(0))['gateway']if gateway_line else _A
		contents=yaml_load(source,variables=get_variables(gateway))
		for(test_name,value)in contents.items():model_test_metadata[test_name]=ModelTestMetadata(path=path,test_name=test_name,body=value)
		return model_test_metadata
	def load_model_tests(self)->t.List[ModelTestMetadata]:
		test_meta_list:t.List[ModelTestMetadata]=[];search_path=Path(self.config_path)/c.TESTS
		for yaml_file in itertools.chain(search_path.glob('**/test*.yaml'),search_path.glob('**/test*.yml')):
			if any(yaml_file.match(ignore_pattern)for ignore_pattern in self.config.ignore_patterns or[]):continue
			test_meta_list.extend(self._load_model_test_file(yaml_file).values())
		return test_meta_list
	class _Cache(CacheBase):
		def __init__(self,loader:SqlMeshLoader,config_path:Path):self._loader=loader;self.config_path=config_path;self._model_cache=ModelCache(self._loader.context.cache_dir)
		def get_or_load_models(self,target_path:Path,loader:t.Callable[[],t.List[Model]])->t.List[Model]:
			models=self._model_cache.get_or_load(self._cache_entry_name(target_path),self._model_cache_entry_id(target_path),loader=loader)
			for model in models:model._path=target_path
			return models
		def put(self,models:t.List[Model],path:Path)->bool:return self._model_cache.put(models,self._cache_entry_name(path),self._model_cache_entry_id(path))
		def get(self,path:Path)->t.List[Model]:
			models=self._model_cache.get(self._cache_entry_name(path),self._model_cache_entry_id(path))
			for model in models:model._path=path
			return models
		def _cache_entry_name(self,target_path:Path)->str:return'__'.join(target_path.relative_to(self.config_path).parts).replace(target_path.suffix,'')
		def _model_cache_entry_id(self,model_path:Path)->str:mtimes=[self._loader._path_mtimes[model_path],self._loader._macros_max_mtime,self._loader._signals_max_mtime,self._loader._audits_max_mtime,self._loader._config_mtimes.get(self.config_path),self._loader._config_mtimes.get(c.SQLMESH_PATH)];return'__'.join([str(max(m for m in mtimes if m is not _A)),self._loader.config.fingerprint,self._loader.context.default_catalog or'',self._loader.context.gateway or self._loader.config.default_gateway_name])