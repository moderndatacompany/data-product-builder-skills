from __future__ import annotations
_C='measure'
_B='dimension'
_A=None
import asyncio,concurrent.futures,typing as t
from pathlib import Path
import sqlglot
from sqlglot import exp
from schema.auth import SecurityContext
from schema.cube import CubeSchema
from schema.rest_query import RestQuery,RestTimeDimension
from vulcan.core import dialect as d
from vulcan.core.dialect import remove_outer_limit,remove_outer_order
from vulcan.core.model.semantic import RollupSpec
from vulcan.core.query.fingerprint import sql_fingerprint
from vulcan.core.query.transpiler import transpile
from vulcan.core.query.transpiler.params import inline_query_params
from vulcan.utils.errors import ConfigError
if t.TYPE_CHECKING:from vulcan.core.config import Config;from vulcan.core.model.definition import Model,RollupModel,SemanticModel
class _RollupMember(t.NamedTuple):
	kind:str;model:str;column:str;time_grain:str|_A
	def warehouse_column_name(self)->str:
		name=f"{self.model}__{self.column}"
		if self.time_grain:return f"{name}_{self.time_grain}"
		return name
def _iter_build_members(spec:RollupSpec,owning_model:str)->t.Iterator[_RollupMember]:
	for ref in spec.dimensions:model,column=_parse_member_ref(ref,owning_model);yield _RollupMember(_B,model,column,_A)
	if spec.time_dimension:model,column=_parse_member_ref(spec.time_dimension,owning_model);yield _RollupMember('time',model,column,spec.granularity or'day')
	for column in spec.measures:yield _RollupMember(_C,owning_model,column,_A)
def _parse_member_ref(ref:str,default_model:str)->tuple[str,str]:
	if'.'not in ref:return default_model,ref
	model,_,column=ref.partition('.');return model,column
def _member_query_id(model:str,column:str)->str:return f"{model}.{column}"
def _qualify_segment_ref(ref:str,owning_model:str)->str:return ref if'.'in ref else f"{owning_model}.{ref}"
def transpile_rollup_sql(*,spec:RollupSpec,semantic:SemanticModel,transpile_schema:t.Dict[str,t.Any],config:Config,gateway:t.Optional[str]=_A)->tuple[str,list[t.Any]|_A]:
	owning_model=semantic.name;build_members=list(_iter_build_members(spec,owning_model));time_dimensions=[RestTimeDimension(dimension=_member_query_id(member.model,member.column),granularity=member.time_grain or'day',dateRange=spec.date_range)for member in build_members if member.kind=='time'];rest_query=RestQuery(measures=[_member_query_id(member.model,member.column)for member in build_members if member.kind==_C],dimensions=[_member_query_id(member.model,member.column)for member in build_members if member.kind==_B],segments=[_qualify_segment_ref(segment,owning_model)for segment in spec.segments]or _A,timeDimensions=time_dimensions or _A)
	async def _fetch_build_sql()->tuple[str,list[t.Any]|_A]:result=await transpile(query=rest_query,catalog=CubeSchema.model_validate(transpile_schema),config=config,gateway=gateway,include_rollups=False,security_context=SecurityContext());return result.sql,result.params
	with concurrent.futures.ThreadPoolExecutor(max_workers=1)as executor:return executor.submit(lambda:asyncio.run(_fetch_build_sql())).result()
def normalize_rollup_query(sql:str,*,dialect:str,params:t.Optional[t.Sequence[t.Any]]=_A)->exp.Query:
	try:inlined_query=inline_query_params(sql,params,dialect=dialect);_,normalized_sql=sql_fingerprint(sql=inlined_query.sql(dialect=dialect),dialect=dialect)
	except Exception as exc:raise ConfigError(f"Failed to normalize rollup build SQL: {exc}")from exc
	query=t.cast(exp.Query,sqlglot.parse_one(normalized_sql,read=dialect));query=t.cast(exp.Query,remove_outer_limit(query));query=t.cast(exp.Query,remove_outer_order(query));return query
def validate_rollup_query_physical_table_refs(query:exp.Query,*,models:t.Mapping[str,Model],default_catalog:t.Optional[str],dialect:str,rollup_name:str)->frozenset[str]:
	from vulcan.core.model.definition import RollupModel,normalize_model_name;allowed={model.fqn for model in models.values()if not(model.is_semantic or model.is_metric or model.kind.is_embedded or isinstance(model,RollupModel))};referenced={normalize_model_name(table,default_catalog=default_catalog,dialect=dialect)for table in d.find_tables(query,default_catalog=default_catalog,dialect=dialect)}
	if not referenced:raise ConfigError(f"rollup model {rollup_name!r}: build SQL must reference at least one table")
	unexpected=referenced-allowed
	if unexpected:raise ConfigError(f"rollup model {rollup_name!r}: build SQL references unknown or non-physical table(s): {', '.join(sorted(unexpected))}")
	return frozenset(referenced)
def write_rollup_debug_model(cache_dir:Path,model:RollupModel)->_A:
	output_dir=cache_dir/'rollups';output_dir.mkdir(parents=True,exist_ok=True);safe_name=model.name.replace('.','__');expressions=model.render_definition(include_python=False);text=d.format_model_expressions(expressions,dialect=model.dialect);header_lines=['-- AUTO-GENERATED — DO NOT EDIT','--','-- Produced at load time from the semantic rollup declaration in the source YAML.','-- This file is a debug artifact under .cache/rollups/; it is not an authored model.','-- Safe to delete; it will be rewritten on the next load.']
	if model.description and model.description.strip():
		header_lines.append('--')
		for line in model.description.strip().splitlines():header_lines.append(f"-- {line}")
	header='\n'.join(header_lines);output=f"{header}\n\n{text.strip()}\n";(output_dir/f"{safe_name}.sql").write_text(output,encoding='utf-8')