from __future__ import annotations
_K='payload'
_J='summary'
_I='username'
_H='plan_id'
_G='run_id'
_F='environment'
_E='status'
_D='created_ts_ns'
_C='text'
_B=None
_A=True
import json,logging,time,typing as t,pandas as pd
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.notification import NotificationEvent,NotificationStatus
from vulcan.utils import sortable_id
from vulcan.utils.migration import ColumnSpec,TableSpec
logger=logging.getLogger(__name__)
NOTIFICATIONS=TableSpec(name='_notifications',primary_key=('id',),description='Persisted notification events for in-app feed',columns=(ColumnSpec('id',indexed=_A),ColumnSpec(_D,'bigint'),ColumnSpec('event',indexed=_A),ColumnSpec(_E,_C),ColumnSpec(_F,indexed=_A,nullable=_A),ColumnSpec(_G,indexed=_A,nullable=_A),ColumnSpec(_H,indexed=_A,nullable=_A),ColumnSpec(_I,_C,nullable=_A),ColumnSpec(_J,_C),ColumnSpec(_K,'jsonb')))
class NotificationState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_B)->_B:self.engine_adapter=engine_adapter;self.schema=schema;self.notifications_table=exp.table_(NOTIFICATIONS.name,db=schema);self._notification_columns_to_types=NOTIFICATIONS.columns_to_types(engine_adapter.dialect)
	def store_notification(self,*,event:NotificationEvent,status:NotificationStatus,summary:str,payload:t.Dict[str,t.Any],environment:t.Optional[str]=_B,run_id:t.Optional[str]=_B,plan_id:t.Optional[str]=_B,username:t.Optional[str]=_B)->str:notification_id=sortable_id();created_ts_ns=time.time_ns();df=pd.DataFrame([{'id':notification_id,_D:created_ts_ns,'event':event.value,_E:status.value,_F:environment,_G:run_id,_H:plan_id,_I:username,_J:summary,_K:json.dumps(payload)}]);self.engine_adapter.insert_append(self.notifications_table,df,target_columns_to_types=self._notification_columns_to_types,track_rows_processed=False);return notification_id