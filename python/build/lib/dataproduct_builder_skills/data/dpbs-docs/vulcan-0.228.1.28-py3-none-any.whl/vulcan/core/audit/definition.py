from __future__ import annotations
_L='default_catalog'
_K='expressions'
_J='dialect'
_I='query'
_H='standalone'
_G='dimension'
_F='before'
_E='name'
_D='description'
_C=True
_B=False
_A=None
import pathlib,typing as t
from functools import cached_property
from pathlib import Path
from pydantic import Field
from sqlglot import exp
from sqlglot.optimizer.simplify import gen
from schema.types import DQDimension
from vulcan.core import dialect as d
from vulcan.core.macros import MacroRegistry,macro
from vulcan.core.model.common import bool_validator,default_catalog_validator,depends_on_validator,sort_python_env,sorted_python_env_payloads
from vulcan.core.model.common import make_python_env,single_value_or_tuple,ParsableSql
from vulcan.core.node import _Node,DbtInfoMixin,DbtNodeInfo,str_or_exp_to_str
from vulcan.core.renderer import QueryRenderer
from vulcan.core.soda3.spec import _FALLBACK_DIMENSION,validate_dq_dimension
from vulcan.utils.date import TimeLike
from vulcan.utils.errors import AuditConfigError,VulcanError,raise_config_error
from vulcan.utils.hashing import hash_data
from vulcan.utils.jinja import JinjaMacroRegistry,extract_macro_references_and_variables
from vulcan.utils.metaprogramming import Executable
from vulcan.utils.pydantic import PydanticModel,field_validator,model_validator
if t.TYPE_CHECKING:from vulcan.core._typing import Self;from vulcan.core.snapshot import DeployabilityIndex,Node,Snapshot
class AuditCommonMetaMixin:name:str;dialect:str;skip:bool;blocking:bool;standalone:bool
class AuditMixin(AuditCommonMetaMixin):
	query_:ParsableSql;defaults:t.Dict[str,exp.Expression];expressions_:t.Optional[t.List[ParsableSql]];jinja_macros:JinjaMacroRegistry;formatting:t.Optional[bool]
	@property
	def query(self)->t.Union[exp.Query,d.JinjaQuery]:return t.cast(t.Union[exp.Query,d.JinjaQuery],self.query_.parse(self.dialect))
	@property
	def expressions(self)->t.List[exp.Expression]:
		if not self.expressions_:return[]
		result=[]
		for e in self.expressions_:
			parsed=e.parse(self.dialect)
			if not isinstance(parsed,exp.Semicolon):result.append(parsed)
		return result
	@property
	def macro_definitions(self)->t.List[d.MacroDef]:return[s for s in self.expressions if isinstance(s,d.MacroDef)]
@field_validator(_E,_J,mode=_F,check_fields=_B)
def audit_string_validator(cls:t.Type,v:t.Any)->t.Optional[str]:
	if isinstance(v,exp.Expression):return v.name.lower()
	return str(v).lower()if v is not _A else _A
@field_validator('defaults',mode=_F,check_fields=_B)
def audit_map_validator(cls:t.Type,v:t.Any,values:t.Any)->t.Dict[str,t.Any]:
	from vulcan.utils.pydantic import get_dialect
	if isinstance(v,exp.Paren):return dict([_maybe_parse_arg_pair(v.unnest())])
	if isinstance(v,(exp.Tuple,exp.Array)):return dict(map(_maybe_parse_arg_pair,v.expressions))
	if isinstance(v,dict):dialect=get_dialect(values);return{key:value if isinstance(value,exp.Expression)else d.parse_one(str(value),dialect=dialect)for(key,value)in v.items()}
	raise_config_error('Defaults must be a tuple of exp.EQ or a dict',error_type=AuditConfigError);return{}
@field_validator(_D,mode=_F,check_fields=_B)
def audit_description_validator(cls:t.Type,v:t.Any)->t.Optional[str]:return str_or_exp_to_str(v)
@field_validator(_G,mode=_F,check_fields=_B)
def audit_dimension_validator(cls:t.Type,v:t.Any)->DQDimension:
	if v is _A:return _FALLBACK_DIMENSION
	if isinstance(v,exp.Expression):v=v.name
	return validate_dq_dimension(v)
class ModelAudit(PydanticModel,AuditMixin,DbtInfoMixin,frozen=_C):
	name:str;dialect:str='';skip:bool=_B;blocking:bool=_C;standalone:t.Literal[_B]=_B;description:t.Optional[str]=_A;dimension:DQDimension=_FALLBACK_DIMENSION;query_:ParsableSql=Field(alias=_I);defaults:t.Dict[str,exp.Expression]={};expressions_:t.Optional[t.List[ParsableSql]]=Field(default=_A,alias=_K);jinja_macros:JinjaMacroRegistry=JinjaMacroRegistry();formatting:t.Optional[bool]=Field(default=_A,exclude=_C);dbt_node_info_:t.Optional[DbtNodeInfo]=Field(alias='dbt_node_info',default=_A);_path:t.Optional[Path]=_A;_query_validator=ParsableSql.validator();_bool_validator=bool_validator;_string_validator=audit_string_validator;_description_validator=audit_description_validator;_dimension_validator=audit_dimension_validator;_map_validator=audit_map_validator
	@property
	def meta_fields(self)->t.Iterable[str]:return set(AuditCommonMetaMixin.__annotations__)|{_D,_G}
	def render_definition(self,include_defaults:bool=_B,render_query:bool=_B)->t.List[exp.Expression]:
		expressions:t.List[exp.Expression]=[];comment=_A
		for field_name in sorted(self.meta_fields):
			field_value=getattr(self,field_name);field_info=self.all_field_infos()[field_name];meta_field=field_info.alias or field_name
			if field_name==_H or include_defaults and field_value or field_value!=field_info.default:
				if field_name==_D:comment=field_value
				else:
					expression=exp.Property(this=meta_field,value=meta_field_converter(meta_field,field_name)(field_value))
					if field_name==_E:expressions.insert(0,expression)
					else:expressions.append(expression)
		audit=d.Audit(expressions=expressions);audit.comments=[comment]if comment else _A;return[audit,*self.expressions,self.query if not render_query else self.query]
	def __str__(self)->str:path=f": {self._path.name}"if self._path else'';return f"{self.__class__.__name__}<{self.name}{path}>"
	@property
	def dbt_node_info(self)->t.Optional[DbtNodeInfo]:return self.dbt_node_info_
class StandaloneAudit(_Node,AuditMixin):
	name:str;dialect:str='';skip:bool=_B;blocking:bool=_C;standalone:t.Literal[_C]=_C;dimension:DQDimension=_FALLBACK_DIMENSION;query_:ParsableSql=Field(alias=_I);defaults:t.Dict[str,exp.Expression]={};expressions_:t.Optional[t.List[ParsableSql]]=Field(default=_A,alias=_K);jinja_macros:JinjaMacroRegistry=JinjaMacroRegistry();default_catalog:t.Optional[str]=_A;depends_on_:t.Optional[t.Set[str]]=Field(default=_A,alias='depends_on');python_env:t.Dict[str,Executable]={};formatting:t.Optional[bool]=Field(default=_A,exclude=_C);source_type:t.Literal['audit']='audit';_query_validator=ParsableSql.validator();_bool_validator=bool_validator;_string_validator=audit_string_validator;_description_validator=audit_description_validator;_dimension_validator=audit_dimension_validator;_map_validator=audit_map_validator;_default_catalog_validator=default_catalog_validator;_depends_on_validator=depends_on_validator
	def render_audit_query(self,*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,deployability_index:t.Optional[DeployabilityIndex]=_A,**kwargs:t.Any)->exp.Query:
		query_renderer=QueryRenderer(self.query,self.dialect,self.macro_definitions,path=self._path or Path(),jinja_macro_registry=self.jinja_macros,python_env=self.python_env,default_catalog=self.default_catalog);rendered_query=query_renderer.render(start=start,end=end,execution_time=execution_time,snapshots=snapshots,deployability_index=deployability_index,**{**self.defaults,**kwargs})
		if rendered_query is _A:raise VulcanError(f"Failed to render query for audit '{self.name}'.")
		return rendered_query
	@cached_property
	def depends_on(self)->t.Set[str]:
		depends_on=self.depends_on_ or set();query=self.render_audit_query()
		if query is not _A:depends_on|=d.find_tables(query,default_catalog=self.default_catalog,dialect=self.dialect)
		depends_on-={self.name};return depends_on
	@property
	def sorted_python_env(self)->t.List[t.Tuple[str,Executable]]:return sort_python_env(self.python_env)
	@property
	def data_hash(self)->str:return hash_data('')
	@property
	def metadata_hash(self)->str:
		if self._metadata_hash is _A:data=[self.owner,self.description,*sorted(self.tags),str(self.sorted_python_env),self.stamp,self.cron,self.cron_tz.key if self.cron_tz else _A];data.append(self.query_.sql);data.extend([e.sql for e in self.expressions_ or[]]);self._metadata_hash=hash_data(data)
		return self._metadata_hash
	def text_diff(self,other:Node,rendered:bool=_B)->str:
		if not isinstance(other,StandaloneAudit):raise VulcanError(f"Cannot diff audit '{self.name} against a non-audit node '{other.name}'")
		return d.text_diff(self.render_definition(render_query=rendered),other.render_definition(render_query=rendered),self.dialect,other.dialect).strip()
	def render_definition(self,include_python:bool=_C,include_defaults:bool=_B,render_query:bool=_B)->t.List[exp.Expression]:
		expressions:t.List[exp.Expression]=[];comment=_A
		for field_name in sorted(self.meta_fields):
			field_value=getattr(self,field_name);field_info=self.all_field_infos()[field_name];meta_field=field_info.alias or field_name
			if field_name==_H or include_defaults and field_value or field_value!=field_info.default:
				if field_name==_D:comment=field_value
				else:
					expression=exp.Property(this=meta_field,value=meta_field_converter(meta_field,field_name)(field_value))
					if field_name==_E:expressions.insert(0,expression)
					else:expressions.append(expression)
		audit=d.Audit(expressions=expressions);audit.comments=[comment]if comment else _A;jinja_expressions=[];python_expressions=[]
		if include_python:
			python_env=d.PythonCode(expressions=sorted_python_env_payloads(self.python_env))
			if python_env.expressions:python_expressions.append(python_env)
			jinja_expressions=self.jinja_macros.to_expressions()
		return[audit,*python_expressions,*jinja_expressions,*self.expressions,self.render_audit_query()if render_query else self.query]
	@property
	def is_audit(self)->bool:return _C
	@property
	def meta_fields(self)->t.Iterable[str]:return set(AuditCommonMetaMixin.__annotations__)|set(_Node.all_field_infos())|{_G}
	@property
	def audits_with_args(self)->t.List[t.Tuple[Audit,t.Dict[str,exp.Expression]]]:return[(self,{})]
Audit=t.Union[ModelAudit,StandaloneAudit]
def load_audit(expressions:t.List[exp.Expression],*,path:Path=Path(),module_path:Path=Path(),macros:t.Optional[MacroRegistry]=_A,jinja_macros:t.Optional[JinjaMacroRegistry]=_A,dialect:t.Optional[str]=_A,default_catalog:t.Optional[str]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,project:t.Optional[str]=_A)->Audit:
	if len(expressions)<2:_raise_config_error('Incomplete audit definition, missing AUDIT or ASSERTION or QUERY',path)
	meta,*statements,query=expressions
	if not isinstance(meta,d.Audit):_raise_config_error('AUDIT or ASSERTION statement is required as the first statement in the definition',path);raise
	meta_fields={p.name:p.args.get('value')for p in meta.expressions if p};description_from_comments='\n'.join(comment.strip()for comment in meta.comments)if meta.comments else _A
	if _D not in meta_fields and description_from_comments:meta_fields[_D]=description_from_comments
	standalone_field=meta_fields.pop(_H,_A)
	if standalone_field and not isinstance(standalone_field,exp.Boolean):_raise_config_error(f"Standalone must be a boolean for '{meta_fields.get(_E)}'",path);raise
	is_standalone=standalone_field and standalone_field.this;audit_class:t.Union[t.Type[StandaloneAudit],t.Type[ModelAudit]]=StandaloneAudit if is_standalone else ModelAudit;missing_required_fields=audit_class.missing_required_fields(set(meta_fields));missing_required_fields-={_I}
	if missing_required_fields:_raise_config_error(f"Missing required fields {missing_required_fields} in the audit definition",path)
	extra_fields=audit_class.extra_fields(set(meta_fields))
	if extra_fields:_raise_config_error(f"Invalid extra fields {extra_fields} in the audit definition",path)
	if not isinstance(query,exp.Query)and not isinstance(query,d.JinjaQuery):_raise_config_error('Missing SELECT query in the audit definition',path);raise
	extra_kwargs:t.Dict[str,t.Any]={}
	if is_standalone:
		jinja_macro_refrences,referenced_variables=extract_macro_references_and_variables(*(gen(s)for s in statements),gen(query));jinja_macros=(jinja_macros or JinjaMacroRegistry()).trim(jinja_macro_refrences)
		for jinja_macro in jinja_macros.root_macros.values():referenced_variables.update(extract_macro_references_and_variables(jinja_macro.definition)[1])
		extra_kwargs['jinja_macros']=jinja_macros;extra_kwargs['python_env']=make_python_env([*statements,query],jinja_macro_refrences,module_path,macros or macro.get_registry(),variables=variables,referenced_variables=referenced_variables);extra_kwargs[_L]=default_catalog
		if project is not _A:extra_kwargs['project']=project
	dialect=meta_fields.pop(_J,dialect)or'';parsable_query=ParsableSql.from_parsed_expression(query,dialect,use_meta_sql=_C);parsable_statements=[ParsableSql.from_parsed_expression(s,dialect,use_meta_sql=_C)for s in statements]
	try:audit=audit_class(query=parsable_query,expressions=parsable_statements,dialect=dialect,**extra_kwargs,**meta_fields)
	except Exception as ex:_raise_config_error(str(ex),path)
	audit._path=path;return audit
def load_multiple_audits(expressions:t.List[exp.Expression],*,path:Path=Path(),module_path:Path=Path(),macros:t.Optional[MacroRegistry]=_A,jinja_macros:t.Optional[JinjaMacroRegistry]=_A,dialect:t.Optional[str]=_A,default_catalog:t.Optional[str]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,project:t.Optional[str]=_A)->t.Generator[Audit,_A,_A]:
	audit_block:t.List[exp.Expression]=[]
	for expression in expressions:
		if isinstance(expression,d.Audit):
			if audit_block:yield load_audit(expressions=audit_block,path=path,module_path=module_path,macros=macros,jinja_macros=jinja_macros,dialect=dialect,default_catalog=default_catalog,variables=variables,project=project);audit_block.clear()
		audit_block.append(expression)
	yield load_audit(expressions=audit_block,path=path,dialect=dialect,default_catalog=default_catalog,variables=variables,project=project)
def _raise_config_error(msg:str,path:pathlib.Path)->_A:raise_config_error(msg,location=path,error_type=AuditConfigError)
@t.no_type_check
def _maybe_parse_arg_pair(e:exp.Expression)->t.Tuple[str,exp.Expression]:
	if isinstance(e,exp.EQ):return e.left.name,e.right
def meta_field_converter(meta_field:str,field_name:str)->t.Callable[[t.Any],exp.Expression]:
	for key in(meta_field,field_name):
		converter=META_FIELD_CONVERTER.get(key)
		if converter is not _A:return converter
	return exp.to_identifier
META_FIELD_CONVERTER:t.Dict[str,t.Callable]={'start':lambda value:exp.Literal.string(value),'cron':lambda value:exp.Literal.string(value),'skip':exp.convert,'blocking':exp.convert,_H:exp.convert,'depends_on_':lambda value:exp.Tuple(expressions=sorted(value)),'tags':single_value_or_tuple,'terms':single_value_or_tuple,'tags_':single_value_or_tuple,'terms_':single_value_or_tuple,_L:exp.to_identifier,_G:exp.to_identifier,'dbt_node_info_':lambda value:value.to_expression()}