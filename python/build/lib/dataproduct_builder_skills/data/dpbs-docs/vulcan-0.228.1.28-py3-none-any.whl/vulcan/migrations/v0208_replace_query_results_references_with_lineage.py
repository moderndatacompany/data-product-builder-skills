import typing as t
from sqlglot import exp
def _results_table(schema:t.Optional[str])->str:return f"{schema}._query_results"if schema else'_query_results'
def migrate_schemas(engine_adapter,schema,**kwargs):
	C='references';B='TABLE';A='lineage';table=_results_table(schema)
	if not engine_adapter.table_exists(table):return
	columns=engine_adapter.columns(table)
	if A not in columns:engine_adapter.execute(exp.Alter(this=exp.to_table(table),kind=B,actions=[exp.ColumnDef(this=exp.to_column(A),kind=exp.DataType.build('jsonb'))]))
	columns=engine_adapter.columns(table)
	if C in columns:engine_adapter.execute(exp.Alter(this=exp.to_table(table),kind=B,actions=[exp.Drop(this=exp.to_column(C),exists=True,kind='COLUMN')]))
def migrate_rows(engine_adapter,schema,**kwargs):0