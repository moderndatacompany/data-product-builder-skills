from __future__ import annotations
_A2='Environment (default: from config)'
_A1='pretty or compact'
_A0='Caller id (default: vulcan-cli)'
_z='--user'
_y="File path ('-' = stdin)"
_x='vulcan-cli'
_w='Empty SQL query is not allowed.'
_v='No input provided.'
_u='--no-confirm'
_t='--format'
_s='models'
_r='--model'
_q='--overwrite'
_p='--ignore-cron'
_o='--limit'
_n='--name'
_m='engine'
_l='import_semantic_view'
_k='rewrite'
_j='transpile'
_i='table_name'
_h='rollback'
_g='metadata'
_f='janitor'
_e='invalidate'
_d='environments'
_c='destroy'
_b='create_external_models'
_a='--file'
_Z='sql'
_Y='--migrate'
_X='select_model'
_W='api'
_V='export'
_U='run'
_T='create_deploy_yaml'
_S='Environment to export (defaults to config default_target_environment). Requires the environment to exist in state (after plan).'
_R='compact'
_Q='name'
_P='-o'
_O='migrate'
_N='--select-model'
_M='environment'
_L='model'
_K='utf-8'
_J='[FILE]'
_I='file'
_H='-e'
_G='--env'
_F='pretty'
_E='--environment'
_D='spark'
_C=False
_B=True
_A=None
import asyncio,json,logging,os,sys,typing as t
from pathlib import Path
import click
from schema.auth import SecurityContext
from vulcan import configure_logging,remove_excess_logs
from vulcan.cli import error_handler
from vulcan.cli import options as opt
from vulcan.cli.project_init import InitCliMode,ProjectTemplate,init_example_project,interactive_init
from vulcan.core.config import load_configs
from vulcan.core.console import configure_console,get_console
from vulcan.core.context import Context
from schema.rest_query import RestQuery
from vulcan.utils.pydantic import pydantic_to_yaml
from vulcan.utils import Verbosity
from vulcan.utils.date import TimeLike
from vulcan.utils.errors import MissingDependencyError,VulcanError
logger=logging.getLogger(__name__)
SKIP_LOAD_COMMANDS='clean',_T,_b,_c,_d,_e,_f,_g,_O,_h,_U,_i,_V,'cube',_W,_j,_k,_l
SKIP_CONTEXT_COMMANDS='init','ui',_T
def _vulcan_version()->str:
	try:from vulcan import __version__;return __version__
	except ImportError:return'0.0.0'
def _ensure_models_loaded(context:Context)->_A:
	if not context._loaded:context.load()
def _write_to_file(path_str:str,text:str)->Path:
	out=Path(path_str).expanduser()
	try:out.write_text(text,encoding=_K)
	except OSError as e:raise click.ClickException(str(e))from e
	return out
@click.group(no_args_is_help=_B)
@click.version_option(version=_vulcan_version(),message='%(version)s')
@opt.paths
@opt.config
@click.option('--gateway',type=str,help='The name of the gateway.',envvar='VULCAN_GATEWAY')
@click.option('--ignore-warnings',is_flag=_B,help='Ignore warnings.',envvar='VULCAN_IGNORE_WARNINGS')
@click.option('--debug',is_flag=_B,help='Enable debug mode.')
@click.option('--log-to-stdout',is_flag=_B,help='Display logs in stdout.')
@click.option('--log-file-dir',type=str,help='The directory to write log files to.')
@click.option('--dotenv',type=click.Path(exists=_B,path_type=Path),help='Path to a custom .env file to load environment variables.',envvar='VULCAN_DOTENV_PATH')
@click.pass_context
@error_handler
def cli(ctx:click.Context,paths:t.List[str],config:t.Optional[str]=_A,gateway:t.Optional[str]=_A,ignore_warnings:bool=_C,debug:bool=_C,log_to_stdout:bool=_B,log_file_dir:t.Optional[str]=_A,dotenv:t.Optional[Path]=_A)->_A:
	if'--help'in sys.argv:return
	configure_logging(debug,log_to_stdout,log_file_dir=log_file_dir,ignore_warnings=ignore_warnings);configure_console(ignore_warnings=ignore_warnings);load=_B
	if len(paths)==1:
		path=os.path.abspath(paths[0])
		if ctx.invoked_subcommand in SKIP_CONTEXT_COMMANDS:ctx.obj=path;return
		if ctx.invoked_subcommand in SKIP_LOAD_COMMANDS:load=_C
	configs=load_configs(config,Context.CONFIG_TYPE,paths,dotenv_path=dotenv);log_limit=list(configs.values())[0].log_limit;remove_excess_logs(log_file_dir,log_limit)
	try:context=Context(paths=paths,config=configs,gateway=gateway,load=load)
	except Exception:
		if debug:logger.exception('Failed to initialize Vulcan context')
		raise
	if load and not context.models:raise click.ClickException(f"`{paths}` doesn't seem to have any models... cd into the proper directory or specify the path(s) with -p.")
	ctx.obj=context
@cli.command('init')
@click.argument(_m,required=_C)
@click.option('-t','--template',type=str,help='Project template. Supported values: default, empty.')
@click.option('--tenant',type=str,help='Project tenant to write into config.yaml.')
@click.option(_n,'project_name',type=str,help='Project name to write into config.yaml.')
@click.option('--description',type=str,help='Project description to write into config.yaml.')
@click.pass_context
@error_handler
def init(ctx:click.Context,engine:t.Optional[str]=_A,template:t.Optional[str]=_A,tenant:t.Optional[str]=_A,project_name:t.Optional[str]=_A,description:t.Optional[str]=_A)->_A:
	project_template=_A
	if template:
		try:project_template=ProjectTemplate(template.lower())
		except ValueError:template_strings="', '".join([template.value for template in ProjectTemplate]);raise click.ClickException(f"Invalid project template '{template}'. Please specify one of '{template_strings}'.")
	if engine:init_example_project(path=ctx.obj,template=project_template or ProjectTemplate.DEFAULT,engine_type=engine,tenant=tenant,name=project_name,description=description);return
	import vulcan.utils.rich as srich;console=srich.console;project_template,engine_type,cli_mode=interactive_init(ctx.obj,console,project_template);config_path=init_example_project(path=ctx.obj,template=project_template,engine_type=engine_type,cli_mode=cli_mode or InitCliMode.DEFAULT,tenant=tenant,name=project_name,description=description);engine_install_text=''
	if engine_type and engine_type not in('duckdb','motherduck'):install_text='pyspark'if engine_type==_D else f"vulcan\\[{engine_type.replace('_','')}]"
	next_step_text=f"{engine_install_text}• Update your gateway connection settings (e.g., username/password) in the project configuration file:\n    {config_path}";console.print(f"""──────────────────────────────

Your Vulcan project is ready!

Next steps:
{next_step_text}
• Run command in CLI: vulcan plan
• (Optional) Explain a plan: vulcan plan --explain

Guide: https://tmdc-io.github.io/vulcan-book/guides

""")
@cli.command('render')
@click.argument(_L)
@opt.start_time
@opt.end_time
@opt.execution_time
@opt.expand
@click.option('--dialect',type=str,help='The SQL dialect to render the query as.')
@click.option('--no-format',is_flag=_B,help='Disable fancy formatting of the query.')
@opt.format_options
@click.pass_context
@error_handler
def render(ctx:click.Context,model:str,start:TimeLike,end:TimeLike,execution_time:t.Optional[TimeLike]=_A,expand:t.Optional[t.Union[bool,t.Iterable[str]]]=_A,dialect:t.Optional[str]=_A,no_format:bool=_C,**format_kwargs:t.Any)->_A:
	model=ctx.obj.get_model(model,raise_if_missing=_B);rendered=ctx.obj.render(model,start=start,end=end,execution_time=execution_time,expand=expand);format_config=ctx.obj.config_for_node(model).format;format_kwargs={**format_config.generator_options,**{k:v for(k,v)in format_kwargs.items()if v is not _A}};sql=rendered.sql(pretty=_B,dialect=ctx.obj.config.dialect if dialect is _A else dialect,**format_kwargs)
	if no_format:print(sql)
	else:ctx.obj.console.show_sql(sql)
@cli.command('evaluate')
@click.argument(_L)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option(_o,type=int,help='The number of rows which the query should be limited to.')
@click.pass_context
@error_handler
def evaluate(ctx:click.Context,model:str,start:TimeLike,end:TimeLike,execution_time:t.Optional[TimeLike]=_A,limit:t.Optional[int]=_A)->_A:
	df=ctx.obj.evaluate(model,start=start,end=end,execution_time=execution_time,limit=limit)
	if hasattr(df,'show'):df.show(limit)
	else:ctx.obj.console.log_success(df)
@cli.command('format')
@click.argument('paths',nargs=-1)
@click.option('-t','--transpile',type=str,help='Transpile project models to the specified dialect.')
@click.option('--check',is_flag=_B,help='Whether or not to check formatting (but not actually format anything).',default=_A)
@click.option('--rewrite-casts/--no-rewrite-casts',is_flag=_B,help='Rewrite casts to use the :: syntax.',default=_A)
@click.option('--append-newline',is_flag=_B,help='Include a newline at the end of each file.',default=_A)
@opt.format_options
@click.pass_context
@error_handler
def format(ctx:click.Context,paths:t.Optional[t.Tuple[str,...]]=_A,**kwargs:t.Any)->_A:
	if not ctx.obj.format(**{k:v for(k,v)in kwargs.items()if v is not _A},paths=paths):ctx.exit(1)
@cli.command('diff')
@click.argument(_M)
@click.pass_context
@error_handler
def diff(ctx:click.Context,environment:t.Optional[str]=_A)->_A:
	if ctx.obj.diff(environment,detailed=_B):exit(1)
@cli.command('plan')
@click.argument(_M,required=_C)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option('--create-from',type=str,help="The environment to create the target environment from if it doesn't exist. Default: prod.")
@click.option('--skip-tests',is_flag=_B,help='Skip tests prior to generating the plan if they are defined.',default=_A)
@click.option('--skip-linter',is_flag=_B,help='Skip linting prior to generating the plan if the linter is enabled.',default=_A)
@click.option('--restate-model','-r',type=str,multiple=_B,help='Restate data for specified models and models downstream from the one specified. For production environment, all related model versions will have their intervals wiped, but only the current versions will be backfilled. For development environment, only the current model versions will be affected.')
@click.option('--no-gaps',is_flag=_B,help='Ensure that new snapshots have no data gaps when comparing to existing snapshots for matching models in the target environment.',default=_A)
@click.option('--skip-backfill','--dry-run',is_flag=_B,help='Skip the backfill step and only create a virtual update for the plan.',default=_A)
@click.option('--empty-backfill',is_flag=_B,help='Produce empty backfill. Like --skip-backfill no models will be backfilled, unlike --skip-backfill missing intervals will be recorded as if they were backfilled.',default=_A)
@click.option('--forward-only',is_flag=_B,help='Create a plan for forward-only changes.',default=_A)
@click.option('--allow-destructive-model',type=str,multiple=_B,help='Allow destructive forward-only changes to models whose names match the expression.')
@click.option('--allow-additive-model',type=str,multiple=_B,help='Allow additive forward-only changes to models whose names match the expression.')
@click.option('--effective-from',type=str,required=_C,help='The effective date from which to apply forward-only changes on production.')
@click.option('--no-prompts',is_flag=_B,help='Disable interactive prompts for the backfill time range. Please note that if this flag is set and there are uncategorized changes, plan creation will fail.',default=_A)
@click.option('--auto-apply',is_flag=_B,help='Automatically apply the new plan after creation.',default=_A)
@click.option('--no-auto-categorization',is_flag=_B,help='Disable automatic change categorization.',default=_A)
@click.option('--include-unmodified',is_flag=_B,help='Include unmodified models in the target environment.',default=_A)
@click.option(_N,type=str,multiple=_B,help='Select specific model changes that should be included in the plan.')
@click.option('--backfill-model',type=str,multiple=_B,help='Backfill only the models whose names match the expression.')
@click.option('--no-diff',is_flag=_B,help='Hide text differences for changed models.',default=_A)
@click.option('--run',is_flag=_B,help='Run latest intervals as part of the plan application (prod environment only).',default=_A)
@click.option('--enable-preview',is_flag=_B,help='Enable preview for forward-only models when targeting a development environment.',default=_A)
@click.option('--diff-rendered',is_flag=_B,help='Output text differences for the rendered versions of the models and standalone audits.',default=_A)
@click.option('--explain',is_flag=_B,help='Explain the plan instead of applying it.',default=_A)
@click.option(_p,is_flag=_B,help='Run all missing intervals, ignoring individual cron schedules. Only applies if --run is set.',default=_A)
@click.option('--min-intervals',default=0,help='For every model, ensure at least this many intervals are covered by a missing intervals check regardless of the plan start date')
@click.option(_Y,is_flag=_B,help='Run state migration before planning.')
@opt.verbose
@click.pass_context
@error_handler
def plan(ctx:click.Context,verbose:int,environment:t.Optional[str]=_A,**kwargs:t.Any)->_A:
	context=ctx.obj
	try:
		restate_models=kwargs.pop('restate_model')or _A;select_models=kwargs.pop(_X)or _A;allow_destructive_models=kwargs.pop('allow_destructive_model')or _A;allow_additive_models=kwargs.pop('allow_additive_model')or _A;backfill_models=kwargs.pop('backfill_model')or _A;ignore_cron=kwargs.pop('ignore_cron')or _A;setattr(get_console(),'verbosity',Verbosity(verbose))
		if kwargs.pop(_O,_C):context.migrate()
		context.plan(environment,restate_models=restate_models,select_models=select_models,allow_destructive_models=allow_destructive_models,allow_additive_models=allow_additive_models,backfill_models=backfill_models,ignore_cron=ignore_cron,**kwargs)
	finally:context.close()
@cli.command(_U)
@click.argument(_M,required=_C)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option('--skip-janitor',is_flag=_B,help='Skip the janitor task.')
@click.option(_p,is_flag=_B,help='Run for all missing intervals, ignoring individual cron schedules.')
@click.option(_N,type=str,multiple=_B,help='Select specific models to run. Note: this always includes upstream dependencies.')
@click.option('--exit-on-env-update',type=int,help='If set, the command will exit with the specified code if the run is interrupted by an update to the target environment.')
@click.option('--no-auto-upstream',is_flag=_B,help='Do not automatically include upstream models. Only applicable when --select-model is used. Note: this may result in missing / invalid data for the selected models.')
@click.option(_Y,is_flag=_B,help='Run state migration before run.')
@click.pass_context
@error_handler
def run(ctx:click.Context,environment:t.Optional[str]=_A,**kwargs:t.Any)->_A:
	context=ctx.obj
	try:
		select_models=kwargs.pop(_X)or _A
		if kwargs.pop(_O,_C):context.migrate()
		completion_status=context.run(environment,select_models=select_models,**kwargs)
		if completion_status.is_failure:raise click.ClickException('Run failed.')
	finally:context.close()
@cli.command(_e)
@click.argument(_M,required=_B)
@click.option('--sync','-s',is_flag=_B,help='Wait for the environment to be deleted before returning. If not specified, the environment will be deleted asynchronously by the janitor process. This option requires a connection to the data warehouse.')
@click.pass_context
@error_handler
def invalidate(ctx:click.Context,environment:str,**kwargs:t.Any)->_A:context=ctx.obj;context.invalidate_environment(environment,**kwargs)
@cli.command(_f,hidden=_B)
@click.option('--ignore-ttl',is_flag=_B,help="Cleanup snapshots that are not referenced in any environment, regardless of when they're set to expire")
@click.pass_context
@error_handler
def janitor(ctx:click.Context,ignore_ttl:bool,**kwargs:t.Any)->_A:ctx.obj.run_janitor(ignore_ttl,**kwargs)
@cli.command(_c)
@click.pass_context
@error_handler
def destroy(ctx:click.Context,**kwargs:t.Any)->_A:ctx.obj.destroy(**kwargs)
@cli.command('create_test')
@click.argument(_L)
@click.option('-q','--query','queries',type=(str,str),multiple=_B,default=[],help="Queries that will be used to generate data for the model's dependencies.")
@click.option(_P,_q,'overwrite',is_flag=_B,default=_C,help='When true, the fixture file will be overwritten in case it already exists.')
@click.option('-v','--var','variables',type=(str,str),multiple=_B,help='Key-value pairs that will define variables needed by the model.')
@click.option('-p','--path','path',help="The file path corresponding to the fixture, relative to the test directory. By default, the fixture will be created under the test directory and the file name will be inferred based on the test's name.")
@click.option('-n',_n,_Q,help="The name of the test that will be created. By default, it's inferred based on the model's name.")
@click.option('--include-ctes','include_ctes',is_flag=_B,default=_C,help='When true, CTE fixtures will also be generated.')
@click.pass_obj
@error_handler
def create_test(obj:Context,model:str,queries:t.List[t.Tuple[str,str]],overwrite:bool=_C,variables:t.Optional[t.List[t.Tuple[str,str]]]=_A,path:t.Optional[str]=_A,name:t.Optional[str]=_A,include_ctes:bool=_C)->_A:obj.create_test(model,input_queries=dict(queries),overwrite=overwrite,variables=dict(variables)if variables else _A,path=path,name=name,include_ctes=include_ctes)
@cli.command('test')
@opt.match_pattern
@opt.verbose
@click.option('--preserve-fixtures',is_flag=_B,default=_C,help='Preserve the fixture tables in the testing database, useful for debugging.')
@click.argument('tests',nargs=-1)
@click.pass_obj
@error_handler
def test(obj:Context,k:t.List[str],verbose:int,preserve_fixtures:bool,tests:t.List[str])->_A:
	result=obj.test(match_patterns=k,tests=tests,verbosity=Verbosity(verbose),preserve_fixtures=preserve_fixtures)
	if not result.wasSuccessful():exit(1)
@cli.command('audit')
@click.option(_r,_s,multiple=_B,help='A model to audit. Multiple models can be audited.')
@opt.start_time
@opt.end_time
@opt.execution_time
@click.pass_obj
@error_handler
def audit(obj:Context,models:t.Iterator[str],start:TimeLike,end:TimeLike,execution_time:t.Optional[TimeLike]=_A)->_A:
	if not obj.audit(models=models,start=start,end=end,execution_time=execution_time):exit(1)
@cli.command('check_intervals')
@click.option('--no-signals',is_flag=_B,help='Disable signal checks and only show missing intervals.',default=_C)
@click.argument(_M,required=_C)
@click.option(_N,type=str,multiple=_B,help='Select specific models to show missing intervals for.')
@opt.start_time
@opt.end_time
@click.pass_context
@error_handler
def check_intervals(ctx:click.Context,environment:t.Optional[str],no_signals:bool,select_model:t.List[str],start:TimeLike,end:TimeLike)->_A:context=ctx.obj;context.console.show_intervals(context.check_intervals(environment,no_signals=no_signals,select_models=select_model,start=start,end=end))
@cli.command('fetchdf',short_help='Run a SQL query (no policy enforcement).')
@click.argument(_Z,required=_C)
@click.option(_a,'-f',type=click.File('r'),default=_A,help="Read SQL from file. Use '-' to read from stdin.")
@click.option(_t,'output_format',type=click.Choice(['table','csv','json','raw'],case_sensitive=_C),default='table',help="Output format: 'table' (formatted table), 'csv' (CSV), 'json' (JSON), 'raw' (simple table).")
@click.pass_context
@error_handler
def fetchdf(ctx:click.Context,sql:t.Optional[str],file:t.Optional[t.TextIO],output_format:str)->_A:
	import sys,pandas as pd;context=ctx.obj
	if file:sql_query=file.read()
	elif sql:sql_query=sql
	else:sql_query=sys.stdin.read()
	if not sql_query or not sql_query.strip():raise click.ClickException('No SQL query provided. Provide SQL as argument, --file, or via stdin.')
	df=context.fetchdf(sql_query);is_piped=not sys.stdout.isatty()
	if output_format.lower()=='csv':df.to_csv(sys.stdout,index=_C)
	elif output_format.lower()=='json':df.to_json(sys.stdout,orient='records',indent=2,date_format='iso')
	elif output_format.lower()=='raw':context.console.log_success(df)
	elif is_piped:df.to_csv(sys.stdout,index=_C)
	else:
		from rich.table import Table as RichTable;console=get_console();table=RichTable(show_header=_B,header_style='bold magenta')
		for col in df.columns:table.add_column(str(col))
		def _format_table_cell(val:t.Any)->str:
			A='NULL'
			if val is _A:return A
			if pd.api.types.is_list_like(val)and not isinstance(val,(str,bytes,dict)):return str(val)
			return str(val)if pd.notna(val)else A
		max_rows=1000
		for(idx,row)in df.head(max_rows).iterrows():table.add_row(*[_format_table_cell(val)for val in row])
		console.console.print(table)
		if len(df)>max_rows:console.console.print(f"\n[dim]Showing {max_rows} of {len(df)} rows. Use --format raw|csv|json to export all rows.[/dim]")
@cli.command('info')
@click.option('--skip-connection',is_flag=_B,help='Skip the connection test.')
@opt.verbose
@click.pass_obj
@error_handler
def info(obj:Context,skip_connection:bool,verbose:int)->_A:obj.print_info(skip_connection=skip_connection,verbosity=Verbosity(verbose))
@cli.command(_O)
@click.pass_context
@error_handler
def migrate(ctx:click.Context)->_A:ctx.obj.migrate()
@cli.command(_h)
@click.pass_obj
@error_handler
def rollback(obj:Context)->_A:obj.rollback()
@cli.command(_b)
@click.option('--strict',is_flag=_B,help='Raise an error if the external model is missing in the database')
@click.pass_obj
@error_handler
def create_external_models(obj:Context,**kwargs:t.Any)->_A:obj.create_external_models(**kwargs)
@cli.command('table_diff')
@click.argument('source_to_target',required=_B,metavar='SOURCE:TARGET')
@click.argument(_L,required=_C)
@click.option(_P,'--on',type=str,multiple=_B,help='The column to join on. Can be specified multiple times. The model grain will be used if not specified.')
@click.option('-s','--skip-columns',type=str,multiple=_B,help='The column(s) to skip when comparing the source and target table.')
@click.option('--where',type=str,help='An optional where statement to filter results.')
@click.option(_o,type=int,default=20,help='The limit of the sample dataframe.')
@click.option('--show-sample',is_flag=_B,help='Show a sample of the rows that differ. With many columns, the output can be very wide.')
@click.option('-d','--decimals',type=int,default=3,help='The number of decimal places to keep when comparing floating point columns. Default: 3')
@click.option('--skip-grain-check',is_flag=_B,help='Disable the check for a primary key (grain) that is missing or is not unique.')
@click.option('--warn-grain-check',is_flag=_B,help='Warn if any selected model is missing a grain, and compute diffs for the remaining models.')
@click.option('--temp-schema',type=str,help='Schema used for temporary tables. It can be `CATALOG.SCHEMA` or `SCHEMA`. Default: `vulcan_temp`')
@click.option(_N,'-m',type=str,multiple=_B,help="Specify one or more models to data diff. Use wildcards to diff multiple models. Ex: '*' (all models with applied plan diffs), 'demo.model+' (this and downstream models), 'git:feature_branch' (models with direct modifications in this branch only)")
@click.option('--schema-diff-ignore-case',is_flag=_B,help="If set, when performing a schema diff the case of column names is ignored when matching between the two schemas. For example, 'col_a' in the source schema and 'COL_A' in the target schema will be treated as the same column.")
@click.pass_obj
@error_handler
def table_diff(obj:Context,source_to_target:str,model:t.Optional[str],**kwargs:t.Any)->_A:
	source,target=source_to_target.split(':');select_model=kwargs.pop(_X,_A)
	if model and select_model:raise VulcanError('The --select-model option cannot be used together with a model argument. Please choose one of them.')
	select_models={model}if model else select_model;obj.table_diff(source=source,target=target,select_models=select_models,**kwargs)
@cli.command('clean')
@click.pass_obj
@error_handler
def clean(obj:Context)->_A:obj.clear_caches()
@cli.command(_i)
@click.argument('model_name',required=_B)
@click.option(_E,_G,help='The environment to source the model version from.')
@click.option('--prod',is_flag=_B,default=_C,help='If set, return the name of the physical table that will be used in production for the model version promoted in the target environment.')
@click.pass_obj
@error_handler
def table_name(obj:Context,model_name:str,environment:t.Optional[str]=_A,prod:bool=_C)->_A:print(obj.table_name(model_name,environment,prod))
@cli.command(_d)
@click.pass_obj
@error_handler
def environments(obj:Context)->_A:obj.print_environment_names()
@cli.command('lint')
@click.option('--models',_r,multiple=_B,help='A model to lint. Multiple models can be linted. If no models are specified, every model will be linted.')
@click.pass_obj
@error_handler
def lint(obj:Context,models:t.Iterator[str])->_A:obj.lint_models(models)
@cli.group(no_args_is_help=_B,hidden=_B)
def state()->_A:0
@state.command(_V)
@click.option(_P,'--output-file',required=_B,help='Path to write the state export to',type=click.Path(dir_okay=_C,writable=_B,path_type=Path))
@click.option(_E,multiple=_B,help='Name of environment to export. Specify multiple --environment arguments to export multiple environments')
@click.option('--local',is_flag=_B,help='Export local state only. Note that the resulting file will not be importable')
@click.option(_u,is_flag=_B,help='Do not prompt for confirmation before exporting existing state')
@click.pass_obj
@error_handler
def state_export(obj:Context,output_file:Path,environment:t.Optional[t.Tuple[str]],local:bool,no_confirm:bool)->_A:
	confirm=not no_confirm
	if environment and local:raise click.ClickException('Cannot specify both --environment and --local')
	environment_names=list(environment)if environment else _A;obj.export_state(output_file=output_file,environment_names=environment_names,local_only=local,confirm=confirm)
@state.command('import')
@click.option('-i','--input-file',help='Path to the state file',required=_B,type=click.Path(exists=_B,dir_okay=_C,readable=_B,path_type=Path))
@click.option('--replace',is_flag=_B,help='Clear the remote state before loading the file. If omitted, a merge is performed instead')
@click.option(_u,is_flag=_B,help='Do not prompt for confirmation before updating existing state')
@click.pass_obj
@error_handler
def state_import(obj:Context,input_file:Path,replace:bool,no_confirm:bool)->_A:confirm=not no_confirm;obj.import_state(input_file=input_file,clear=replace,confirm=confirm)
@cli.command(_W,hidden=_B)
@click.option('--host',type=str,default='0.0.0.0',help='Bind socket to this host. Default: 0.0.0.0')
@click.option('--port',type=int,default=8000,help='Bind socket to this port. Default: 8000')
@click.option('--reload',is_flag=_B,default=_C,help='Enable auto-reload on file changes. Default: False')
@click.option(_Y,is_flag=_B,default=_C,help='Run state migration before starting the API server.')
@click.pass_context
@error_handler
def api(ctx:click.Context,host:str,port:int,reload:bool,migrate:bool)->_A:
	A='debug';from vulcan.core.console import get_console
	try:import uvicorn
	except ModuleNotFoundError as e:raise MissingDependencyError("Missing API dependencies. Run `pip install -e '.[api]'` to install them.")from e
	if isinstance(ctx.obj,Context):project_path=str(ctx.obj.path);console=ctx.obj.console
	else:project_path=str(ctx.obj);console=get_console()
	parent_params=ctx.parent.params if ctx.parent else{};config=parent_params.get('config');gateway=parent_params.get('gateway');log_level=A if parent_params.get(A,_C)else'info';os.environ['PROJECT_PATH']=project_path;os.environ['LOG_LEVEL']=log_level.upper()
	if config:os.environ['CONFIG']=config
	if gateway:os.environ['GATEWAY']=gateway
	if migrate:
		if not isinstance(ctx.obj,Context):raise click.ClickException('--migrate requires a fully initialized context.')
		ctx.obj.migrate()
	console.log_success(f"Starting API server on http://{host}:{port} \n"+f"OpenAPI docs available at http://{host}:{port}/redoc and http://{host}:{port}/scalar");uvicorn.run('api.app:app',host=host,port=port,log_level=log_level,reload=reload,workers=1,timeout_keep_alive=300,ws='none')
@cli.command(_j)
@click.argument('query',required=_C)
@click.option(_t,'fmt',type=click.Choice([_Z,'rest'],case_sensitive=_C),required=_B,help='sql or rest')
@click.option(_a,'query_file',type=str,help=_y)
@click.option(_z,type=str,default=_A,help=_A0)
@opt.security_context
@click.option('--disable-post-processing',is_flag=_B,default=_C,help='Skip transpiler post-processing')
@click.option('--inline-params/--no-inline-params',default=_B,help='Inline bound parameters into SQL (default: enabled).')
@click.option('--style',type=click.Choice([_F,_R],case_sensitive=_C),default=_F,help=_A1)
@click.option(_E,_G,_H,type=str,default=_A,help=_A2)
@click.pass_obj
@error_handler
def transpile_command(context:Context,query:t.Optional[str],fmt:str,query_file:t.Optional[str],user:t.Optional[str],security_context:tuple[str,...],disable_post_processing:bool,inline_params:bool,style:t.Optional[str],environment:t.Optional[str])->_A:
	if query_file and query:raise click.ClickException('Provide either QUERY or --file, not both.')
	if not query_file and not query:raise click.ClickException('Provide either QUERY or --file/STDIN.')
	raw:t.Optional[str]
	if query_file:
		if query_file=='-':raw=sys.stdin.read()
		else:
			path=Path(query_file)
			if not path.exists():raise click.ClickException(f"File not found: {query_file}")
			raw=path.read_text(encoding=_K)
	else:raw=query
	if raw is _A:raise click.ClickException(_v)
	if fmt.lower()=='rest':
		try:payload_dict=t.cast(t.Dict[str,t.Any],json.loads(raw));rest_query=RestQuery(**payload_dict);query_obj:t.Union[RestQuery,str]=rest_query
		except Exception as e:raise click.ClickException(f"Invalid REST payload for --format rest: {e}")from e
	else:
		if not raw.strip():raise click.ClickException(_w)
		query_obj=raw
	user_id=user or _x;env=environment or context.config.default_target_environment
	try:security_ctx=SecurityContext.from_pairs(security_context)
	except(ValueError,TypeError)as exc:raise click.ClickException(str(exc))from exc
	async def _run()->_A:
		reply=await context.transpile(query_obj,user=user_id,security_context=security_ctx,environment=env,disable_post_processing=disable_post_processing);sql=reply.sql_statement;params=reply.sql_params
		if inline_params and params:
			from vulcan.core.query.transpiler.params import inline_query_params;from vulcan.utils.errors import VulcanError
			try:sql=inline_query_params(sql,params,dialect=reply.dialect).sql(dialect=reply.dialect);params=_A
			except VulcanError as exc:raise click.ClickException(str(exc))from exc
		if style and style.lower()in(_F,_R):from vulcan.utils.sql import format_sql_for_display;sql=format_sql_for_display(sql,dialect=context.config.dialect,pretty=style.lower()==_F)
		if params:comment_lines=['\n','-- @params',*[f"-- {index}. {value}"for(index,value)in enumerate(params,1)],''];sql=sql.rstrip()+'\n'.join(comment_lines)
		try:
			if sys.stdout.isatty():console=get_console();console.show_sql(sql)
			else:print(sql,end='')
		except BrokenPipeError:sys.stdout.close();sys.exit(0)
	asyncio.run(_run())
@cli.command(_k)
@click.argument(_Z,required=_C)
@click.option(_a,'sql_file',type=str,help=_y)
@click.option(_z,type=str,default=_A,help=_A0)
@opt.security_context
@click.option('--style',type=click.Choice([_F,_R],case_sensitive=_C),default=_F,help=_A1)
@click.option(_E,_G,_H,type=str,default=_A,help=_A2)
@click.pass_obj
@error_handler
def rewrite_command(context:Context,sql:t.Optional[str],sql_file:t.Optional[str],user:t.Optional[str],security_context:tuple[str,...],style:t.Optional[str],environment:t.Optional[str])->_A:
	if sql_file and sql:raise click.ClickException('Provide either SQL or --file, not both.')
	if not sql_file and not sql:raise click.ClickException('Provide either SQL or --file/STDIN.')
	raw:t.Optional[str]
	if sql_file:
		if sql_file=='-':raw=sys.stdin.read()
		else:
			path=Path(sql_file)
			if not path.exists():raise click.ClickException(f"File not found: {sql_file}")
			raw=path.read_text(encoding=_K)
	else:raw=sql
	if raw is _A:raise click.ClickException(_v)
	if not raw.strip():raise click.ClickException(_w)
	user_id=user or _x;env=environment or context.config.default_target_environment
	try:security_ctx=SecurityContext.from_pairs(security_context)
	except(ValueError,TypeError)as exc:raise click.ClickException(str(exc))
	result=context.rewrite(raw,user=user_id,security_context=security_ctx,environment=env);output_sql=result.rewritten_sql
	if style and style.lower()in(_F,_R):from vulcan.utils.sql import format_sql_for_display;output_sql=format_sql_for_display(output_sql,dialect=context.config.dialect,pretty=style.lower()==_F)
	try:
		if sys.stdout.isatty():get_console().show_sql(output_sql)
		else:print(output_sql,end='')
	except BrokenPipeError:sys.stdout.close();sys.exit(0)
@cli.group(_V)
def export_group()->_A:0
@export_group.command('dag')
@click.argument(_I,required=_C,metavar=_J)
@click.option(_N,type=str,multiple=_B,help='Limit the graph to these model selection expressions.')
@click.pass_obj
@error_handler
def export_dag(obj:Context,file:t.Optional[str],select_model:t.Tuple[str,...])->_A:
	_ensure_models_loaded(obj);outfile=file or'dag.html';rendered=obj.render_dag(outfile,select_model if select_model else _A)
	if rendered:obj.console.log_success(f"Generated Lineage DAG to [bold]{rendered}[/bold]")
@export_group.command('joins')
@click.argument(_I,required=_C,metavar=_J)
@click.pass_obj
@error_handler
def export_joins(obj:Context,file:t.Optional[str])->_A:
	_ensure_models_loaded(obj);outfile=file or'joins.html';rendered=obj.render_joins_graph(outfile)
	if rendered:obj.console.log_success(f"Generated the Semantic Joins Graph to [bold]{rendered}[/bold]")
@export_group.command(_g)
@click.option(_H,_E,_G,type=str,default=_A,help=_S)
@click.argument(_I,required=_C,metavar=_J)
@click.pass_obj
@error_handler
def export_metadata(context:Context,environment:t.Optional[str],file:t.Optional[str])->_A:
	try:schema=context.metadata_for_environment(environment=environment);out=_write_to_file(file or'metadata.yml',pydantic_to_yaml(schema,lean=_B,json_dump=_B,omit_false_booleans=_B));context.console.log_success(f"Generated metadata to [bold]{out}[/bold]")
	except VulcanError as e:raise click.ClickException(str(e))from e
@export_group.command('contract')
@click.option(_H,_E,_G,type=str,default=_A,help=_S)
@click.argument(_L,required=_C,metavar='[MODEL]')
@click.argument(_I,required=_C,metavar=_J)
@click.pass_obj
@error_handler
def export_contract(context:Context,environment:t.Optional[str],model:t.Optional[str],file:t.Optional[str])->_A:
	if model is _A:click.echo(click.get_current_context().get_help());return
	try:contract=context.odcs_contract_for_environment(model,environment=environment);out=_write_to_file(file or f"{model.replace('.','__')}.contract.yml",pydantic_to_yaml(contract,lean=_B,json_dump=_B));context.console.log_success(f"Generated ODCS v3.1.0 contract for {model} to [bold]{out}[/bold]")
	except VulcanError as e:raise click.ClickException(str(e))from e
@export_group.command('product')
@click.option(_H,_E,_G,type=str,default=_A,help=_S)
@click.argument(_I,required=_C,metavar=_J)
@click.pass_obj
@error_handler
def export_product(context:Context,environment:t.Optional[str],file:t.Optional[str])->_A:
	try:product=context.odps_product_for_environment(environment=environment);out=_write_to_file(file or'product.yml',pydantic_to_yaml(product,lean=_B,json_dump=_B));context.console.log_success(f"Generated ODPS v1.0.0 product spec to [bold]{out}[/bold]")
	except VulcanError as e:raise click.ClickException(str(e))from e
@cli.command('cube',hidden=_B)
@click.option(_H,_E,_G,type=str,default=_A,help=_S)
@click.argument(_I,required=_C,metavar=_J)
@click.pass_obj
@error_handler
def export_cube_schema(context:Context,environment:t.Optional[str],file:t.Optional[str])->_A:
	try:schema=context.cube_schema_for_environment(environment);out=_write_to_file(file or'cube.yml',pydantic_to_yaml(schema,lean=_B,omit_defaults=_B));context.console.log_success(f"Generated transpiler schema to [bold]{out}[/bold]")
	except VulcanError as e:raise click.ClickException(str(e))from e
@cli.command(_l)
@click.argument('view_name')
@click.option('--connection','-c',type=str,default=_A,help='Snowflake gateway/connection name to fetch the view from. Required when VIEW_NAME is a fully-qualified Snowflake identifier (e.g. ECOMMERCE_PLATFORM.GOLD.MY_VIEW). If omitted the view is resolved from local managed/imported YAML files.')
@click.option('--output-dir',type=str,default=_A,help='Base output directory for the imported semantic model YAMLs. A subfolder named after the semantic view is always created inside this directory (e.g. models/TPCH_DEEP_CHAIN/). Defaults to models/snowflake_semantic/.')
@click.pass_obj
@error_handler
def import_semantic_view(context:Context,view_name:str,connection:t.Optional[str],output_dir:t.Optional[str])->_A:
	from vulcan.core.export.snowflake_semantic import fetch_definition,project_root as _project_root,write_model_files;from vulcan.utils.errors import ConfigError;console=context.console;root=_project_root(context)
	if connection:console.log_status_update(f"Fetching '{view_name}' from Snowflake via connection '{connection}'…")
	try:definition=fetch_definition(context,view_name,connection)
	except ConfigError as exc:raise click.ClickException(str(exc))from exc
	written=write_model_files(definition,root,output_dir);out_dir=written[0].parent if written else root;source_label=f"via connection '{connection}'"if connection else f"({definition.source})";console.log_success(f"Imported {len(written)} semantic model(s) from '{definition.name}' {source_label} → {out_dir}")
	for p in written:
		try:display=p.resolve().relative_to(root.resolve())
		except ValueError:display=p
		console.log_status_update(f"  {display}")
@cli.command(_T)
@click.option('--output',_P,type=str,default=_A,help="Output path for the generated DataOS Vulcan resource YAML. Defaults to '<project_name>-deploy.yaml' in the project root.")
@click.option(_q,is_flag=_B,help='Overwrite the output file if it already exists.')
@click.pass_obj
@error_handler
def create_deploy_yaml(context:t.Union[Context,str],output:t.Optional[str],overwrite:bool)->_A:
	N='tags';M='description';L='arguments';K='command';J='sparkConf';I='resource';H='logLevel';G='memory';F='depot';E='type';D='mssql';C='postgres';B='0 0 * * *';A='trino';from pathlib import Path;import re;from vulcan.core.config.loader import load_config_from_yaml;from vulcan.core.config.deployment import ComputeResource,DeploymentConfig,ResourceQuota,SparkResourceQuota;from vulcan.utils.yaml import dump as yaml_dump;from ruamel.yaml.scalarstring import SingleQuotedScalarString;from pydantic import BaseModel;from pydantic.alias_generators import to_camel;engine_enum={C,_D,'bigquery',D,'mysql','snowflake','databricks','fabric',A};connection_type_to_engine:t.Dict[str,str]={'azuresql':D,'gcp_postgres':C};spark_conf_defaults={'spark.sql.shuffle.partitions':'16','spark.sql.adaptive.coalescePartitions.enabled':'true'};project_root=Path(context.path).absolute()if isinstance(context,Context)else Path(str(context)).absolute();raw_config=load_config_from_yaml(project_root/'config.yaml');raw_deployment=raw_config.get('deployment')
	if not raw_deployment:raise click.ClickException("Missing 'deployment:' section in config.yaml. See the Vulcan documentation for the required fields.")
	try:deployment=DeploymentConfig(**raw_deployment)
	except Exception as e:raise click.ClickException(f"Invalid 'deployment:' section in config.yaml:\n{e}")
	to_stdout=output=='-';out_path:t.Optional[Path]=_A
	if not to_stdout:
		out_path=Path(output).expanduser()if output else project_root/f"{raw_config.get(_Q)}-deploy.yaml"
		if not out_path.is_absolute():out_path=project_root/out_path
		if out_path.exists()and not overwrite:raise click.ClickException(f"Output file already exists: {out_path}. Use --overwrite to replace it.")
	resource_name=str(raw_config.get(_Q)or'').strip();poros_entity_name_fmt='^[a-z]([-a-z0-9]*[a-z0-9])?$'
	if len(resource_name)>60 or not re.fullmatch(poros_entity_name_fmt,resource_name):raise click.ClickException(f"Invalid DataOS resource name derived from config.yaml `name`.\nGot: {resource_name!r}\nRule: must be <= 60 chars, lowercase, start with a letter, and only contain letters/digits plus '-'; must end with a letter or digit.\nRegex: {poros_entity_name_fmt}\nAction: Correct `name` in config.yaml and re-run `vulcan create_deploy_yaml`.")
	def _to_k8s_cron(expr:str)->str:A='0 0 1 1 *';mapping={'@hourly':'0 * * * *','@daily':B,'@midnight':B,'@weekly':'0 0 * * 0','@monthly':'0 0 1 * *','@yearly':A,'@annually':A};return mapping.get((expr or'').strip().lower(),expr)
	crons:t.Set[str]=set();models_dir=project_root/_s;model_file_count=0;models_inherit_default=_C
	if models_dir.exists():
		for path in models_dir.rglob('*'):
			if not path.is_file()or path.suffix.lower()not in{'.sql','.py'}:continue
			model_file_count+=1;found=re.findall('cron\\s*[=(]?\\s*[\'\\"]([^\'\\"]+)[\'\\"]',path.read_text(encoding=_K))
			if found:crons.update(_to_k8s_cron(c)for c in found)
			else:models_inherit_default=_B
	default_cron=(raw_config.get('model_defaults')or{}).get('cron')
	if default_cron and(models_inherit_default or model_file_count==0):crons.add(_to_k8s_cron(str(default_cron)))
	if not crons:crons.add(B)
	cron_list=sorted(crons);gateways=raw_config.get('gateways')or{};default_gateway_name=str(raw_config.get('default_gateway')or'default');default_gateway=gateways.get(default_gateway_name)if isinstance(gateways,dict)else{};connection=default_gateway.get('connection')if isinstance(default_gateway,dict)else{};connection=connection if isinstance(connection,dict)else{};connection_type=str(connection.get(E)or'').strip()
	if connection_type==_D:engine=_D
	elif connection_type!=F:engine=connection_type_to_engine.get(connection_type,connection_type)
	else:
		if not deployment.engine:raise click.ClickException(f"Gateway connection type is 'depot' but 'engine' is not set in the 'deployment:' section of config.yaml. Add 'engine: <value>' under 'deployment:'. Allowed: {', '.join(sorted(engine_enum))}.")
		engine=deployment.engine
	def _derive_depot_address()->t.Optional[str]:
		if connection_type!=F:return
		from urllib.parse import urlparse;raw_address=str(connection.get('address')or'').strip();parsed=urlparse(raw_address)
		if parsed.scheme and parsed.netloc and not parsed.query:return f"{parsed.scheme}://{parsed.netloc}?purpose=rw"
		return raw_address or _A
	if deployment.depots:depots=list(deployment.depots)
	else:derived_depot=_derive_depot_address();depots=[derived_depot]if derived_depot else[]
	if engine not in engine_enum:raise click.ClickException(f"Could not resolve a supported engine (got {engine!r}). Set a supported gateway connection type. Allowed: {', '.join(sorted(engine_enum))}.")
	if depots and engine not in{_D,A}and len(depots)!=1:raise click.ClickException(f"engine '{engine}' allows exactly one depot; got {len(depots)}.")
	if deployment.spark_conf and engine!=_D:raise click.ClickException("`sparkConf` is only allowed when engine is 'spark'.")
	if deployment.trino and engine!=A:raise click.ClickException("`trino` config is only allowed when engine is 'trino'.")
	def _quota(q:ResourceQuota)->t.Dict[str,t.Any]:return{k:v for(k,v)in(('cpu',q.cpu),(G,q.memory))if v is not _A}
	def _spark_quota(q:SparkResourceQuota)->t.Dict[str,t.Any]:pairs=('coreLimit',q.core_limit),('cores',q.cores),(G,q.memory),('instances',q.instances);return{k:v for(k,v)in pairs if v is not _A}
	def _resource(res:ComputeResource)->t.Dict[str,t.Any]:
		out:t.Dict[str,t.Any]={}
		if res.request is not _A:out['request']=_quota(res.request)
		if res.limit is not _A:out['limit']=_quota(res.limit)
		if res.driver is not _A:out['driver']=_spark_quota(res.driver)
		if res.executor is not _A:out['executor']=_spark_quota(res.executor)
		return out
	repo_spec:t.Dict[str,t.Any]={'url':deployment.repo.url,'syncFlags':list(deployment.repo.sync_flags),'baseDir':deployment.repo.base_dir}
	if deployment.repo.secret_id:repo_spec['secretId']=deployment.repo.secret_id
	spec:t.Dict[str,t.Any]={'runAsUser':deployment.run_as_user,'compute':deployment.compute,_m:engine}
	if deployment.state_store_connection:spec['stateStoreConnection']=deployment.state_store_connection
	if deployment.object_store_connection:spec['objectStoreConnection']=deployment.object_store_connection
	spec['repo']=repo_spec
	if depots:spec['depots']=depots
	if deployment.use is not _A:
		projection:t.Dict[str,t.Any]={}
		if deployment.use.secrets:projection['secrets']=[{'id':s.id,'contextAlias':s.context_alias}for s in deployment.use.secrets]
		if deployment.use.env_vars:projection['projections']={'envVars':[{'key':e.key,'template':e.template}for e in deployment.use.env_vars]}
		spec['use']={'projection':projection}
	schedule:t.Dict[str,t.Any]={'crons':[SingleQuotedScalarString(c)for c in cron_list]}
	if deployment.schedule.end_on:schedule['endOn']=deployment.schedule.end_on
	schedule['timezone']=deployment.schedule.timezone;schedule['concurrencyPolicy']='Forbid';workflow:t.Dict[str,t.Any]={'schedule':schedule,H:deployment.workflow.log_level}
	if deployment.workflow.resource is not _A:workflow[I]=_resource(deployment.workflow.resource)
	if engine==_D:workflow[J]={**spark_conf_defaults,**(deployment.spark_conf or{})}
	workflow['plan']={K:list(deployment.workflow.plan.command),L:list(deployment.workflow.plan.arguments)};workflow[_U]={K:list(deployment.workflow.run.command),L:list(deployment.workflow.run.arguments)};api:t.Dict[str,t.Any]={'replicas':deployment.api.replicas,H:deployment.api.log_level}
	if deployment.api.resource is not _A:api[I]=_resource(deployment.api.resource)
	if engine==_D:api[J]={**spark_conf_defaults,**(deployment.spark_conf or{})}
	spec['workflow']=workflow;spec[_W]=api
	def _dump_camel(obj:t.Any)->t.Any:
		if isinstance(obj,BaseModel):return{to_camel(name):_dump_camel(value)for name in type(obj).model_fields if(value:=getattr(obj,name))is not _A}
		if isinstance(obj,list):return[_dump_camel(item)for item in obj]
		return obj
	if engine==A and deployment.trino:spec[A]=_dump_camel(deployment.trino)
	manifest={'version':'v1alpha',E:deployment.type,_Q:resource_name,M:str(raw_config.get(M)or''),N:[str(tag)for tag in raw_config.get(N)or[]],'spec':spec};payload=yaml_dump(manifest)
	if to_stdout:click.echo(payload,nl=_C)
	else:assert out_path is not _A;out_path.parent.mkdir(parents=_B,exist_ok=_B);out_path.write_text(payload,encoding=_K);click.echo(f"Generated deploy YAML: {out_path}")