from __future__ import annotations
_R='sqlserver'
_Q='athena'
_P='clickhouse'
_O='duckdb'
_N='redshift'
_M='databricks'
_L='bigquery'
_K='snowflake'
_J='description'
_I='implementation'
_H='engine'
_G='dimension'
_F='external'
_E='postgresql'
_D='min'
_C='custom'
_B='1'
_A=None
import typing as t,uuid
from vulcan.core import constants as c
from schema.metadata import AuditEntry,ColumnEntry,GatewayInfo,Metadata,ModelEntry
from schema.odcs_contract import OdcsContract,OdcsContractDescription,OdcsContractSummary,OdcsCustomProperty,OdcsRelationship,OdcsSchemaObject,OdcsSchemaProperty,OdcsServer,OdcsSlaProperty,OdcsSupportItem,OdcsTeam,OdcsTeamMember
from schema.odps_spec import OdpsCustomProperty,OdpsDescription,OdpsInputPort,OdpsOutputPort,OdpsProduct,OdpsSupport,OdpsTeam,OdpsTeamMember
from schema.product import ComplianceSpec,SupportChannel
_VULCAN_SPEC_NAMESPACE=uuid.UUID('f47ac10b-58cc-4372-a567-0e02b2c3d479')
class ContractExportError(Exception):0
class ModelNotFoundError(ContractExportError):0
def odcs_contract_id(*,tenant:str,model_name:str)->str:key=f"odcs:{tenant}:{model_name}";return str(uuid.uuid5(_VULCAN_SPEC_NAMESPACE,key))
def odps_product_id(*,tenant:str,product_name:str)->str:key=f"odps:{tenant}:{product_name}";return str(uuid.uuid5(_VULCAN_SPEC_NAMESPACE,key))
def contract_status(metadata:Metadata)->str:return'active'if metadata.env==c.PROD else'draft'
def _find_model(metadata:Metadata,model_name:str)->ModelEntry:
	for entry in metadata.models:
		if entry.name==model_name:return entry
	raise ModelNotFoundError(f"Model {model_name!r} not found in metadata")
def _is_output_port_model(entry:ModelEntry)->bool:return entry.source_type!=_F
def _compliance_custom_properties(compliance:t.Optional[ComplianceSpec])->t.List[OdcsCustomProperty]:
	if compliance is _A:return[]
	props:t.List[OdcsCustomProperty]=[]
	if compliance.regimes:props.append(OdcsCustomProperty(property='vulcan.compliance.regimes',value=list(compliance.regimes)))
	if compliance.data_residency:props.append(OdcsCustomProperty(property='vulcan.compliance.data_residency',value=compliance.data_residency))
	if compliance.legal_contact:props.append(OdcsCustomProperty(property='vulcan.compliance.legal_contact',value=compliance.legal_contact))
	return props
def _odcs_support_items(channels:t.List[SupportChannel])->t.List[OdcsSupportItem]:return[OdcsSupportItem(channel=channel.channel,url=channel.url,tool=channel.tool,scope=channel.scope)for channel in channels]
def _odps_support_items(channels:t.List[SupportChannel])->t.List[OdpsSupport]:
	items:t.List[OdpsSupport]=[]
	for channel in channels:
		if not channel.url:continue
		items.append(OdpsSupport(channel=channel.channel,url=channel.url,tool=channel.tool,scope=channel.scope))
	return items
def _odcs_logical_type(column:ColumnEntry)->str:
	dtype=(column.dtype or'').upper()
	if column.ltype=='time':
		if'TIMESTAMP'in dtype or'DATETIME'in dtype:return'timestamp'
		if'DATE'in dtype:return'date'
	return column.ltype
def _column_mask_expression(column:ColumnEntry)->t.Optional[str]:
	details=column.details
	if details is _A:return
	return getattr(details,'mask_expression',_A)
def _effective_classification(column:ColumnEntry)->t.Optional[str]:
	A='restricted'
	if column.classification:return column.classification
	if _column_mask_expression(column):return A
	if any(tag.lower()=='pii'for tag in column.tags):return A
def _primary_key_positions(entry:ModelEntry)->t.Dict[str,int]:
	if not entry.grains:return{}
	return{grain:index for(index,grain)in enumerate(entry.grains,start=1)}
def _transform_source_objects(column:ColumnEntry)->t.Optional[t.List[str]]:models=sorted({dep.model for dep in column.depends_on});return models or _A
def _transform_logic(column:ColumnEntry)->t.Optional[str]:
	if not column.depends_on:return
	parts:t.List[str]=[]
	for dep in column.depends_on:
		if dep.column:parts.append(f"{dep.model}.{dep.column}")
		else:parts.append(dep.model)
	return', '.join(parts)
def _column_custom_properties(column:ColumnEntry,*,model_name:str)->t.Optional[t.List[OdcsCustomProperty]]:
	props:t.List[OdcsCustomProperty]=[]
	if column.depends_on:props.append(OdcsCustomProperty(property='vulcan.lineage.from',value=[f"{dep.model}.{dep.column}"if dep.column else dep.model for dep in column.depends_on]));props.append(OdcsCustomProperty(property='vulcan.lineage.to',value=f"{model_name}.{column.name}"))
	mask_expression=_column_mask_expression(column)
	if mask_expression:props.append(OdcsCustomProperty(property='vulcan.mask_expression',value=mask_expression))
	return props or _A
def _schema_property(column:ColumnEntry,*,model_name:str,primary_key_positions:t.Dict[str,int])->OdcsSchemaProperty:business_name=column.terms[0]if column.terms else _A;primary_key_position=primary_key_positions.get(column.name);return OdcsSchemaProperty(name=column.name,logical_type=_odcs_logical_type(column),physical_type=column.dtype or _A,description=column.description,primary_key=column.primary_key or _A,primary_key_position=primary_key_position,classification=_effective_classification(column),business_name=business_name,tags=list(column.tags),transform_source_objects=_transform_source_objects(column),transform_logic=_transform_logic(column),transform_description=column.description,custom_properties=_column_custom_properties(column,model_name=model_name))
def _odcs_quality_dimension(dimension:str)->str:
	if dimension=='validity':return'conformity'
	return dimension
def _audit_quality_check(audit:AuditEntry)->t.Dict[str,t.Any]:
	check:t.Dict[str,t.Any]={'type':_C,_G:_odcs_quality_dimension(audit.dimension),'name':audit.name,_H:'vulcan',_I:audit.name}
	if audit.description:check[_J]=audit.description
	return check
def _quality_checks(entry:ModelEntry)->t.Optional[t.List[t.Dict[str,t.Any]]]:
	checks:t.List[t.Dict[str,t.Any]]=[]
	if entry.dq and entry.dq.rules:checks.extend({'type':_C,_G:_odcs_quality_dimension(rule.dimension),'name':rule.name,_H:'soda',_I:rule.expression,**({_J:rule.description}if rule.description else{})}for rule in entry.dq.rules)
	checks.extend(_audit_quality_check(audit)for audit in entry.audits);return checks or _A
def _schema_relationships(entry:ModelEntry)->t.Optional[t.List[OdcsRelationship]]:
	if not entry.joins:return
	return[OdcsRelationship(type='foreignKey',from_=join.expression,to=join.model)for join in entry.joins]
def _data_granularity_description(entry:ModelEntry)->t.Optional[str]:
	if not entry.grains:return
	return f"One row per {', '.join(entry.grains)}"
def _contract_tags(entry:ModelEntry)->t.List[str]:
	tags:t.List[str]=[];seen:t.Set[str]=set()
	for tag in[*entry.tags,*entry.terms]:
		if tag in seen:continue
		seen.add(tag);tags.append(tag)
	return tags
def _schema_object(entry:ModelEntry)->OdcsSchemaObject:
	physical_name=_A
	if entry.table:
		if entry.table.virtual:physical_name=entry.table.virtual.name
		else:physical_name=entry.table.physical.name
	primary_key_positions=_primary_key_positions(entry);return OdcsSchemaObject(name=entry.name,physical_type='table',physical_name=physical_name,description=entry.description,tags=_contract_tags(entry),data_granularity_description=_data_granularity_description(entry),properties=[_schema_property(column,model_name=entry.name,primary_key_positions=primary_key_positions)for column in entry.columns],relationships=_schema_relationships(entry),quality=_quality_checks(entry))
_SLA_FREQUENCY_UNITS:t.Dict[str,t.Tuple[str,str]]={'year':(_B,'y'),'month':(_B,'mo'),'day':(_B,'d'),'hour':(_B,'h'),'half_hour':('30',_D),'quarter_hour':('15',_D),'five_minute':('5',_D)}
def _sla_frequency_value_unit(entry:ModelEntry)->t.Tuple[str,str]:
	E='@yearly';D='@monthly';C='@weekly';B='@hourly';A='@daily'
	if entry.interval_unit:
		unit_key=str(entry.interval_unit)
		if unit_key in _SLA_FREQUENCY_UNITS:return _SLA_FREQUENCY_UNITS[unit_key]
	if entry.cron.strip()in{A,B,C,D,E}:presets={A:(_B,'d'),B:(_B,'h'),C:(_B,'w'),D:(_B,'mo'),E:(_B,'y')};return presets[entry.cron.strip()]
	return _B,'d'
def _sla_element(entry:ModelEntry)->str:
	if entry.table and entry.table.virtual:return entry.table.virtual.name
	return entry.name
def _sla_properties(entry:ModelEntry)->t.Optional[t.List[OdcsSlaProperty]]:
	if not entry.cron:return
	value,unit=_sla_frequency_value_unit(entry);return[OdcsSlaProperty(property='frequency',value=value,unit=unit,element=_sla_element(entry),scheduler='cron',schedule=entry.cron)]
_ODCS_SERVER_DIALECT_LABELS:t.Dict[str,str]={'postgres':_E,_E:_E,'mysql':'mysql',_K:_K,_L:_L,_M:_M,_N:_N,_O:_O,_P:_P,'trino':'trino',_Q:_Q,'tsql':_R,'mssql':_R,'spark':'spark','hive':'hive'}
def _odcs_server_description(gateway:GatewayInfo)->str:
	dialect=(gateway.dialect or gateway.connection_type or'unknown').lower();label=_ODCS_SERVER_DIALECT_LABELS.get(dialect,dialect)
	if gateway.host:
		endpoint=gateway.host if gateway.port is _A else f"{gateway.host}:{gateway.port}"
		if gateway.database:endpoint=f"{endpoint}/{gateway.database}"
		return f"{label} gateway ({endpoint})"
	if gateway.account:return f"{label} gateway (account: {gateway.account})"
	if gateway.connection_uri:return f"{label} gateway ({gateway.connection_uri})"
	return f"{label} gateway"
def _odcs_servers(gateway:GatewayInfo,gateways:t.Optional[t.List[GatewayInfo]],*,environment:str)->t.List[OdcsServer]:
	all_gateways=[gateway]
	if gateways:all_gateways.extend(gateways)
	return[OdcsServer(server=gw.name,type=_C,environment=environment,description=_odcs_server_description(gw),host=gw.host,port=gw.port,database=gw.database)for gw in all_gateways]
def _odcs_team(entry:ModelEntry,product_users:t.List[t.Any])->t.Optional[OdcsTeam]:
	members:t.List[OdcsTeamMember]=[]
	if entry.owner:members.append(OdcsTeamMember(username=entry.owner,role='owner'))
	for user in product_users:
		if entry.owner and user.username==entry.owner:continue
		members.append(OdcsTeamMember(username=user.username,role=user.type or _A))
	if not members:return
	return OdcsTeam(members=members)
def build_odcs_contract(metadata:Metadata,model_name:str)->OdcsContract:
	entry=_find_model(metadata,model_name);tenant=metadata.tenant or'';status=contract_status(metadata);contract_id=odcs_contract_id(tenant=tenant,model_name=entry.name);custom_properties=_compliance_custom_properties(metadata.product.compliance);schema_object=_schema_object(entry);description=_A
	if entry.description:description=OdcsContractDescription(purpose=entry.description)
	team=_odcs_team(entry,metadata.product.users);support=_odcs_support_items(metadata.product.support)or _A;return OdcsContract(version=metadata.product.version,id=contract_id,status=status,name=entry.name,tenant=tenant or _A,domain=metadata.product.domain,data_product=metadata.name or _A,tags=_contract_tags(entry),description=description,schema_=[schema_object],support=support,team=team,servers=_odcs_servers(metadata.gateway,metadata.gateways,environment=metadata.env),sla_properties=_sla_properties(entry),custom_properties=custom_properties or _A)
def list_contract_summaries(metadata:Metadata)->t.List[OdcsContractSummary]:
	if not metadata.product.discoverable:return[]
	tenant=metadata.tenant or'';status=contract_status(metadata);return[OdcsContractSummary(id=odcs_contract_id(tenant=tenant,model_name=entry.name),name=entry.name,version=metadata.product.version,status=status)for entry in sorted(metadata.models,key=lambda m:m.name)if _is_output_port_model(entry)]
def _input_port_fqn(entry:ModelEntry)->str:return entry.fqn
def _input_port_contract_id(*,tenant:str,entry:ModelEntry)->str:return odcs_contract_id(tenant=tenant,model_name=_input_port_fqn(entry))
def _input_port_contract_version(entry:ModelEntry)->str:return _input_port_fqn(entry)
def _input_port_product(entry:ModelEntry)->str:return _input_port_fqn(entry)
def _input_ports(metadata:Metadata)->t.List[OdpsInputPort]:
	ports:t.List[OdpsInputPort]=[];tenant=metadata.tenant or''
	for entry in metadata.models:
		if entry.source_type!=_F:continue
		ports.append(OdpsInputPort(name=entry.name,version=_input_port_contract_version(entry),contract_id=_input_port_contract_id(tenant=tenant,entry=entry),tags=list(entry.tags)))
	return sorted(ports,key=lambda p:p.name)
def _output_ports(metadata:Metadata)->t.List[OdpsOutputPort]:
	if not metadata.product.discoverable:return[]
	tenant=metadata.tenant or'';ports:t.List[OdpsOutputPort]=[]
	for entry in sorted(metadata.models,key=lambda m:m.name):
		if not _is_output_port_model(entry):continue
		ports.append(OdpsOutputPort(name=entry.name,version=metadata.product.version,contract_id=odcs_contract_id(tenant=tenant,model_name=entry.name),description=entry.description,type=str(entry.kind).lower(),tags=list(entry.tags)))
	return ports
def build_odps_product(metadata:Metadata)->OdpsProduct:
	tenant=metadata.tenant or'';product_name=metadata.name;status=contract_status(metadata);custom_properties=[OdpsCustomProperty(property=prop.property,value=prop.value)for prop in _compliance_custom_properties(metadata.product.compliance)];description=_A
	if metadata.product.description:description=OdpsDescription(purpose=metadata.product.description)
	team=_A
	if metadata.product.users:team=OdpsTeam(members=[OdpsTeamMember(username=user.username,role=user.type or _A)for user in metadata.product.users])
	return OdpsProduct(id=odps_product_id(tenant=tenant,product_name=product_name),status=status,name=product_name,version=metadata.product.version,domain=metadata.product.domain,tenant=tenant or _A,description=description,tags=list(metadata.product.tags),input_ports=_input_ports(metadata)or _A,output_ports=_output_ports(metadata)or _A,support=_odps_support_items(metadata.product.support)or _A,team=team,custom_properties=custom_properties or _A)