import typing as t
from sqlglot import exp
def _plans_table(schema:t.Optional[str])->str:return f"{schema}._plans"if schema else'_plans'
def _add_boolean_column(engine_adapter:t.Any,table:str,column:str)->None:engine_adapter.execute(exp.Alter(this=exp.to_table(table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column(column),kind=exp.DataType.build('boolean'))]))
def migrate_schemas(engine_adapter,schema,**kwargs):
	plans_table=_plans_table(schema)
	for column in('has_requirements_changes','has_environment_changes'):_add_boolean_column(engine_adapter,plans_table,column)
def migrate_rows(engine_adapter,schema,**kwargs):
	if engine_adapter.dialect!='postgres':return
	plans_table=_plans_table(schema);engine_adapter.execute(f"""
        UPDATE {plans_table} SET
          has_requirements_changes = (
            plan_diff->>'requirements_diff' IS NOT NULL
            AND LENGTH(TRIM(plan_diff->>'requirements_diff')) > 0
          ),
          has_environment_changes = (
            plan_diff->>'env_statements_diff' IS NOT NULL
            AND LENGTH(TRIM(plan_diff->>'env_statements_diff')) > 0
          )
        """)