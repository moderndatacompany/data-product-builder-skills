from __future__ import annotations
_B='vulcan'
_A=None
import typing as t,pydantic
from pydantic import Field,model_validator
from vulcan.core.config.base import BaseConfig
class _DeploymentBase(BaseConfig):model_config=pydantic.ConfigDict(extra='forbid')
class RepoConfig(_DeploymentBase):url:str;base_dir:str;secret_id:t.Optional[str]=_A;sync_flags:t.List[str]=Field(default_factory=lambda:['--ref=main','--submodules=off'])
class ScheduleConfig(_DeploymentBase):end_on:t.Optional[str]=_A;timezone:str='UTC'
class CommandConfig(_DeploymentBase):command:t.List[str]=Field(default_factory=lambda:[_B]);arguments:t.List[str]=Field(default_factory=list)
class ResourceQuota(_DeploymentBase):cpu:t.Optional[str]=_A;memory:t.Optional[str]=_A
class SparkResourceQuota(_DeploymentBase):core_limit:t.Optional[str]=_A;cores:t.Optional[int]=_A;memory:t.Optional[str]=_A;instances:t.Optional[int]=_A
class ComputeResource(_DeploymentBase):
	request:t.Optional[ResourceQuota]=_A;limit:t.Optional[ResourceQuota]=_A;driver:t.Optional[SparkResourceQuota]=_A;executor:t.Optional[SparkResourceQuota]=_A
	@model_validator(mode='after')
	def _validate_resource_shape(self)->'ComputeResource':
		has_generic=self.request is not _A or self.limit is not _A;has_spark=self.driver is not _A or self.executor is not _A
		if has_generic and has_spark:raise ValueError('resource cannot mix request/limit with driver/executor; use the generic shape (request/limit) or the spark shape (driver/executor), not both.')
		if has_spark and not(self.driver is not _A and self.executor is not _A):raise ValueError('spark resource requires both `driver` and `executor`.')
		return self
class WorkflowConfig(_DeploymentBase):log_level:str='INFO';resource:t.Optional[ComputeResource]=_A;plan:CommandConfig=Field(default_factory=lambda:CommandConfig(command=[_B],arguments=['plan','--auto-apply']));run:CommandConfig=Field(default_factory=lambda:CommandConfig(command=[_B],arguments=['run']))
class ApiConfig(_DeploymentBase):replicas:int=1;log_level:str='INFO';resource:t.Optional[ComputeResource]=_A
class SecretProjection(_DeploymentBase):id:str;context_alias:str
class EnvVarProjection(_DeploymentBase):key:str;template:str
class UseConfig(_DeploymentBase):secrets:t.List[SecretProjection]=Field(default_factory=list);env_vars:t.List[EnvVarProjection]=Field(default_factory=list)
class TrinoCatalog(_DeploymentBase):config:t.Optional[t.List[str]]=_A
class TrinoOverrideCatalog(_DeploymentBase):name:str;properties:t.Dict[str,t.Union[str,int,float,bool]]
class TrinoServerConfig(_DeploymentBase):jvm_config:t.Optional[str]=_A;config_properties:t.Optional[str]=_A;node_properties:t.Optional[str]=_A;log_properties:t.Optional[str]=_A
class TrinoRoleResource(_DeploymentBase):request:t.Optional[ResourceQuota]=_A;limit:t.Optional[ResourceQuota]=_A
class TrinoAutoscale(_DeploymentBase):min_replicas:t.Optional[int]=Field(default=_A,ge=1);max_replicas:t.Optional[int]=Field(default=_A,ge=1);cpu_target:t.Optional[int]=Field(default=_A,ge=1,le=100)
class TrinoCoordinator(_DeploymentBase):resource:t.Optional[TrinoRoleResource]=_A;trino_server_config:t.Optional[TrinoServerConfig]=_A;options:t.Optional[t.Dict[str,t.Any]]=_A
class TrinoWorkers(_DeploymentBase):replicas:t.Optional[int]=Field(default=_A,ge=1);resource:t.Optional[TrinoRoleResource]=_A;trino_server_config:t.Optional[TrinoServerConfig]=_A;autoscale:t.Optional[TrinoAutoscale]=_A;options:t.Optional[t.Dict[str,t.Any]]=_A
class TrinoConfig(_DeploymentBase):catalog:t.Optional[TrinoCatalog]=_A;overide_catalog_config:t.Optional[t.List[TrinoOverrideCatalog]]=_A;coordinator:t.Optional[TrinoCoordinator]=_A;workers:t.Optional[TrinoWorkers]=_A
class DeploymentConfig(_DeploymentBase):type:str=_B;repo:RepoConfig;compute:str;run_as_user:str;engine:t.Optional[str]=_A;state_store_connection:t.Optional[str]=_A;object_store_connection:t.Optional[str]=_A;depots:t.Optional[t.List[str]]=_A;schedule:ScheduleConfig=Field(default_factory=ScheduleConfig);workflow:WorkflowConfig=Field(default_factory=WorkflowConfig);api:ApiConfig=Field(default_factory=ApiConfig);use:t.Optional[UseConfig]=_A;spark_conf:t.Optional[t.Dict[str,t.Any]]=_A;trino:t.Optional[TrinoConfig]=_A