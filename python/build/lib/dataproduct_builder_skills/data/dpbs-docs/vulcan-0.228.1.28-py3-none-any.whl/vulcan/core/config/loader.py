from __future__ import annotations
_C=True
_B='config'
_A=None
import glob,os,typing as t
from pathlib import Path
from pydantic import ValidationError
from dotenv import load_dotenv
from ruamel.yaml.error import YAMLError
from sqlglot.helper import ensure_list
from vulcan.core import constants as c
from vulcan.core.config.common import ALL_CONFIG_FILENAMES,USAGE_FILENAMES,YAML_CONFIG_FILENAMES,DBT_PROJECT_FILENAME
from vulcan.core.config.model import ModelDefaultsConfig
from vulcan.core.config.root import DEFAULT_AGREEMENT_PATH,Config
from vulcan.core.console import get_console
from vulcan.utils import env_vars,merge_dicts,sys_path
from vulcan.utils.errors import ConfigError
from vulcan.utils.metaprogramming import import_python_file
from vulcan.utils.pydantic import validation_error_message
from vulcan.utils.yaml import load as yaml_load
C=t.TypeVar('C',bound=Config)
def load_configs(config:t.Optional[t.Union[str,C]],config_type:t.Type[C],paths:t.Union[str|Path,t.Iterable[str|Path]],vulcan_path:t.Optional[Path]=_A,dotenv_path:t.Optional[Path]=_A,**kwargs:t.Any)->t.Dict[Path,C]:
	vulcan_path=vulcan_path or c.SQLMESH_PATH;config=config or _B;absolute_paths=[Path(t.cast(t.Union[str,Path],p)).absolute()for path in ensure_list(paths)for p in glob.glob(str(path))or[str(path)]]
	if dotenv_path and dotenv_path.exists()and dotenv_path.is_file():load_dotenv(dotenv_path=dotenv_path,override=_C)
	else:
		for path in absolute_paths:
			env_file=path/'.env'
			if env_file.exists()and env_file.is_file():load_dotenv(dotenv_path=env_file,override=_C)
	if not isinstance(config,str):
		if type(config)!=config_type:config=convert_config_type(config,config_type)
		return{path:config for path in absolute_paths}
	config_env_vars=_A;personal_paths=[vulcan_path/name for name in YAML_CONFIG_FILENAMES]
	for path in personal_paths:
		if path.exists():
			config_env_vars=load_config_from_yaml(path).get('env_vars')
			if config_env_vars:break
	with env_vars(config_env_vars if config_env_vars else{}):return{path:load_config_from_paths(config_type,project_paths=[path/name for name in ALL_CONFIG_FILENAMES],personal_paths=personal_paths,config_name=config,**kwargs)for path in absolute_paths}
def load_config_from_paths(config_type:t.Type[C],project_paths:t.Optional[t.List[Path]]=_A,personal_paths:t.Optional[t.List[Path]]=_A,config_name:str=_B,load_from_env:bool=_C,variables:t.Optional[t.Dict[str,t.Any]]=_A,**kwargs:t.Any)->C:
	A="Vulcan config could not be found. Point the cli to the right path with `vulcan -p`. If you haven't set up Vulcan, run `vulcan init`.";project_paths=project_paths or[];personal_paths=personal_paths or[];visited_folders:t.Set[Path]=set();python_config:t.Optional[C]=_A;non_python_configs=[]
	if not project_paths or not any(path.exists()for path in project_paths):raise ConfigError("Vulcan project config could not be found. Point the cli to the project path with `vulcan -p`. If you haven't set up the Vulcan project, run `vulcan init`.")
	yaml_config_path:t.Optional[Path]=_A;project_root:t.Optional[Path]=_A
	for path in[*project_paths,*personal_paths]:
		if not path.exists():continue
		if not path.is_file():raise ConfigError(f"Path '{path}' must be a file.")
		parent_path=path.parent
		if parent_path in visited_folders:raise ConfigError(f"Multiple configuration files found in folder '{parent_path}'.")
		visited_folders.add(parent_path);extension=path.name.split('.')[-1].lower()
		if extension in('yml','yaml'):
			if config_name!=_B and not python_config:raise ConfigError('YAML configs do not support multiple configs. Use Python instead.')
			yaml_config_path=path.resolve()
			if path in project_paths:project_root=parent_path
			non_python_configs.append(load_config_from_yaml(path,variables))
		elif extension=='py':
			try:python_config=load_config_from_python_module(config_type,path,config_name=config_name)
			except ValidationError as e:raise ConfigError(validation_error_message(e,f"Invalid project config '{config_name}':")+'\n\nVerify your config.py.')
		else:raise ConfigError(f"Unsupported config file extension '{extension}' in config file '{path}'.")
	if project_root is _A and python_config is not _A:project_root=next((path.parent for path in project_paths if path.exists()and path.suffix=='.py'),_A)
	if load_from_env:
		env_config=load_config_from_env()
		if env_config:non_python_configs.append(env_config)
	if not non_python_configs and not python_config:raise ConfigError(A)
	no_dialect_err_msg='Default model SQL dialect is a required configuration parameter. Set it in the `model_defaults` `dialect` key in your config file.';non_python_config_dict=merge_dicts(*non_python_configs)
	if project_root and non_python_config_dict:_apply_usage_from_path(project_root,non_python_config_dict);_apply_agreement_from_path(project_root,non_python_config_dict)
	if not non_python_config_dict:
		if not python_config:raise ConfigError(A)
		if python_config.model_defaults.dialect is _A:raise ConfigError(no_dialect_err_msg)
		return python_config
	supported_model_defaults=ModelDefaultsConfig.all_fields()
	for default in non_python_config_dict.get('model_defaults',{}):
		if default not in supported_model_defaults:raise ConfigError(f"'{default}' is not a valid model default configuration key. Please remove it from the `model_defaults` specification in your config file.")
	try:non_python_config=config_type.parse_obj(non_python_config_dict)
	except ValidationError as e:raise ConfigError(validation_error_message(e,'Invalid project config:')+'\n\nVerify your config.yaml and environment variables.',location=yaml_config_path)
	if not python_config:
		potential_project_files=[f/DBT_PROJECT_FILENAME for f in visited_folders];dbt_project_file=next((f for f in potential_project_files if f.exists()),_A)
		if dbt_project_file:
			from vulcan.dbt.loader import vulcan_config;infer_state_schema_name=False
			if(dbt:=non_python_config.dbt):infer_state_schema_name=dbt.infer_state_schema_name
			dbt_python_config=vulcan_config(project_root=dbt_project_file.parent,profiles_dir=kwargs.pop('profiles_dir',_A),dbt_profile_name=kwargs.pop('profile',_A),dbt_target_name=kwargs.pop('target',_A),variables=variables,threads=kwargs.pop('threads',_A),infer_state_schema_name=infer_state_schema_name)
			if type(dbt_python_config)!=config_type:dbt_python_config=convert_config_type(dbt_python_config,config_type)
			python_config=dbt_python_config
	if python_config:
		model_defaults=python_config.model_defaults
		if model_defaults.dialect is _A:raise ConfigError(no_dialect_err_msg)
		return python_config.update_with(non_python_config)
	model_defaults=non_python_config.model_defaults
	if model_defaults.dialect is _A:raise ConfigError(no_dialect_err_msg)
	return non_python_config
def load_config_from_yaml(path:Path,variables:t.Optional[t.Dict[str,t.Any]]=_A)->t.Dict[str,t.Any]:
	content=yaml_load(path,variables=variables,to_snake_case=_C,to_snake_case_preserve_paths=frozenset({'gateways/**'}))
	if not isinstance(content,dict):raise ConfigError(f"Invalid YAML configuration: expected a dictionary but got {type(content).__name__}. Please check the YAML syntax in your config file.",location=path)
	return content
def _coerce_numeric_key_dicts_to_lists(value:t.Any)->t.Any:
	if isinstance(value,dict):
		if value and all(str(key).isdigit()for key in value):items=[_coerce_numeric_key_dicts_to_lists(value[key])for key in sorted(value,key=lambda k:int(k))];return items
		return{key:_coerce_numeric_key_dicts_to_lists(nested)for(key,nested)in value.items()}
	if isinstance(value,list):return[_coerce_numeric_key_dicts_to_lists(item)for item in value]
	return value
def _resolve_project_relative_path(project_root:Path,path_value:t.Any,*,field_name:str)->Path:
	if not isinstance(path_value,str)or not path_value.strip():raise ConfigError(f"{field_name} must be a non-empty string.")
	normalized=path_value.strip();project_root_resolved=project_root.resolve();candidate=Path(normalized);resolved=candidate.resolve()if candidate.is_absolute()else(project_root/candidate).resolve()
	try:resolved.relative_to(project_root_resolved)
	except ValueError as error:raise ConfigError(f"{field_name} '{normalized}' must resolve inside the project root '{project_root_resolved}'.")from error
	return resolved
def _apply_usage_from_path(project_root:Path,config_dict:t.Dict[str,t.Any])->_A:
	B='usage';A='usage_path';explicit=A in config_dict
	if explicit:candidates=[config_dict[A]]
	else:candidates=[f"./{name}"for name in USAGE_FILENAMES]
	resolved_candidates=[(candidate,_resolve_project_relative_path(project_root,candidate,field_name=A))for candidate in candidates];usage_file=resolved_candidates[0][1]
	for(candidate,resolved)in resolved_candidates:
		if resolved.exists():usage_file=resolved;config_dict[A]=candidate;break
	overrides=config_dict.pop(B,_A)or{}
	if not isinstance(overrides,dict):raise ConfigError('usage must be a mapping when provided inline in config.')
	overrides=_coerce_numeric_key_dicts_to_lists(overrides)
	if usage_file.exists():
		try:baseline=load_config_from_yaml(usage_file)
		except(ConfigError,YAMLError)as error:raise ConfigError(f"Failed to load usage file '{usage_file}': expected a YAML mapping of usage guidance. {error}")from error
	else:
		if explicit:get_console().log_warning(f"Usage file not found at '{usage_file}'; continuing with empty usage. Set usage_path in config.yaml or VULCAN__USAGE_PATH to point at your file.")
		baseline={}
	config_dict[B]=merge_dicts(baseline,overrides)
def _apply_agreement_from_path(project_root:Path,config_dict:t.Dict[str,t.Any])->_A:
	B='agreement_path';A='agreement';explicit=B in config_dict;agreement_file=_resolve_project_relative_path(project_root,config_dict.get(B,DEFAULT_AGREEMENT_PATH),field_name=B);inline_agreement=config_dict.pop(A,_A)
	if agreement_file.exists():
		try:config_dict[A]=agreement_file.read_text(encoding='utf-8')
		except(OSError,UnicodeDecodeError)as error:raise ConfigError(f"Failed to read agreement file '{agreement_file}' as UTF-8 text: {error}")from error
	else:
		if explicit:get_console().log_warning(f"Agreement file not found at '{agreement_file}'; continuing without agreement text. Set agreement_path in config.yaml or VULCAN__AGREEMENT_PATH to point at your file.")
		config_dict[A]=''
	if inline_agreement is not _A:
		if not isinstance(inline_agreement,str):raise ConfigError('agreement must be a string when provided inline in config.')
		config_dict[A]=inline_agreement
def load_config_from_python_module(config_type:t.Type[C],module_path:Path,config_name:str=_B)->C:
	try:
		with sys_path(module_path.parent):config_module=import_python_file(module_path,module_path.parent)
	except Exception as e:raise ConfigError(f"Failed to load config file: {e}",location=module_path)
	try:config_obj=getattr(config_module,config_name)
	except AttributeError:raise ConfigError(f"Config '{config_name}' was not found.")
	if config_obj is _A or not isinstance(config_obj,Config):raise ConfigError(f"Config needs to be a valid object of type vulcan.core.config.Config. Found `{config_obj}` instead at '{module_path}'.",module_path)
	return config_obj if type(config_obj)==config_type else convert_config_type(config_obj,config_type)
def load_config_from_env()->t.Dict[str,t.Any]:
	config_dict:t.Dict[str,t.Any]={}
	for(key,value)in os.environ.items():
		key=key.lower()
		if key.startswith(f"{c.SQLMESH}__")and key!=c.DISABLE_SQLMESH_STATE_MIGRATION.lower():
			segments=key.split('__')[1:]
			if not segments or not segments[-1]:raise ConfigError(f"Invalid Vulcan configuration variable '{key}'.")
			target_dict=config_dict
			for config_key in segments[:-1]:
				if config_key not in target_dict:target_dict[config_key]={}
				target_dict=target_dict[config_key]
			target_dict[segments[-1]]=value
	return config_dict
def convert_config_type(config_obj:Config,config_type:t.Type[C])->C:return config_type.parse_obj(config_obj.dict())