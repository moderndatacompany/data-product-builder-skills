from vulcan.core.query.definitions import QueryType
def migrate_schemas(engine_adapter,schema,**kwargs):
	requests_table='_query_requests';perspectives_table='_query_perspective'
	if schema:requests_table=f"{schema}.{requests_table}";perspectives_table=f"{schema}.{perspectives_table}"
	if engine_adapter.dialect!='postgres':return
	default_type=QueryType.SEMANTIC_REST.value;query_type_values=', '.join(f"'{t.value}'"for t in QueryType)
	for table in(requests_table,perspectives_table):
		if not engine_adapter.table_exists(table):continue
		engine_adapter.execute(f"\n            UPDATE {table}\n            SET query_type = '{default_type}'\n            WHERE query_type IS NULL\n            ");engine_adapter.execute(f"\n            ALTER TABLE {table}\n            DROP CONSTRAINT IF EXISTS check_query_type\n            ");engine_adapter.execute(f"\n            ALTER TABLE {table}\n            ALTER COLUMN query_type SET NOT NULL\n            ");engine_adapter.execute(f"\n            ALTER TABLE {table}\n            ADD CONSTRAINT check_query_type\n            CHECK (query_type IN ({query_type_values}))\n            ")
def migrate_rows(engine_adapter,schema,**kwargs):0