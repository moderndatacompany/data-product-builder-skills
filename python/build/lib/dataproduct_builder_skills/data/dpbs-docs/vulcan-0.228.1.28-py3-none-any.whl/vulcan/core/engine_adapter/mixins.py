from __future__ import annotations
_D='iceberg'
_C=True
_B=False
_A=None
import abc,logging,time,typing as t
from dataclasses import dataclass
from sqlglot import exp,parse_one
from sqlglot.helper import seq_get
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from vulcan.core.engine_adapter.base import EngineAdapter
from vulcan.core.engine_adapter.shared import DataObjectType
from vulcan.core.node import IntervalUnit
from vulcan.core.dialect import schema_
from vulcan.core.schema_diff import TableAlterOperation
from vulcan.utils.errors import VulcanError
if t.TYPE_CHECKING:from vulcan.core._typing import TableName;from vulcan.core.engine_adapter._typing import DCL,DF,GrantsConfig,QueryOrDF;from vulcan.core.engine_adapter.base import QueryOrDF
logger=logging.getLogger(__name__)
NORMALIZED_DATE_FORMAT='%Y-%m-%d'
NORMALIZED_TIMESTAMP_FORMAT='%Y-%m-%d %H:%M:%S.%f'
class LogicalMergeMixin(EngineAdapter):
	def merge(self,target_table:TableName,source_table:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],unique_key:t.Sequence[exp.Expression],when_matched:t.Optional[exp.Whens]=_A,merge_filter:t.Optional[exp.Expression]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:logical_merge(self,target_table,source_table,target_columns_to_types,unique_key,when_matched=when_matched,merge_filter=merge_filter,source_columns=source_columns)
class PandasNativeFetchDFSupportMixin(EngineAdapter):
	def _pandas_read_sql_with_query_history(self,sql:str,read_sql:t.Callable[[],DF])->DF:
		from warnings import catch_warnings,filterwarnings;logger.debug(f"[{self.dialect}] Executing SQL:\n{sql}");started_at=time.monotonic();error:t.Optional[BaseException]=_A
		with catch_warnings(),self.transaction():
			filterwarnings('ignore',category=UserWarning,message='.*pandas only supports SQLAlchemy connectable.*')
			try:return read_sql()
			except BaseException as exc:error=exc;raise
			finally:self._finalize_execute(sql,started_at=started_at,track_rows_processed=_B,error=error)
	def _fetch_native_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_B)->DF:from pandas.io.sql import read_sql_query;sql=self._to_sql(query,quote=quote_identifiers)if isinstance(query,exp.Expression)else query;sql=self._attach_correlation_id(sql);return self._pandas_read_sql_with_query_history(sql,lambda:read_sql_query(sql,self._connection_pool.get()))
	def _fetch_native_df_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_B)->DF:
		B='format';A='qmark';from pandas.io.sql import read_sql_query;sql=self._to_sql(query,quote=quote_identifiers)if isinstance(query,exp.Expression)else query;from vulcan.core.engine_adapter._parameter_utils import normalize_query_params;out_style=self._dbapi_paramstyle()
		if out_style is _A:dialect_paramstyle_defaults={'duckdb':A,'trino':A,'fabric':A,'databricks':A,'mysql':B};out_style=dialect_paramstyle_defaults.get(self.dialect,B)
		sql,params=normalize_query_params(sql,params,output_style=out_style);sql=self._attach_correlation_id(sql);return self._pandas_read_sql_with_query_history(sql,lambda:read_sql_query(sql,self._connection_pool.get(),params=params))
class HiveMetastoreTablePropertiesMixin(EngineAdapter):
	MAX_TABLE_COMMENT_LENGTH=4000;MAX_COLUMN_COMMENT_LENGTH=4000
	def _build_partitioned_by_exp(self,partitioned_by:t.List[exp.Expression],*,catalog_name:t.Optional[str]=_A,**kwargs:t.Any)->t.Union[exp.PartitionedByProperty,exp.Property]:
		if self.dialect=='trino'and self.get_catalog_type(catalog_name or self.get_current_catalog())==_D:return exp.Property(this=exp.var('PARTITIONING'),value=exp.array(*(exp.Literal.string(e.sql(dialect=self.dialect))for e in partitioned_by)))
		for expr in partitioned_by:
			if not isinstance(expr,exp.Column):raise VulcanError(f"PARTITIONED BY contains non-column value '{expr.sql(dialect=self.dialect)}'.")
		return exp.PartitionedByProperty(this=exp.Schema(expressions=partitioned_by))
	def _build_table_properties_exp(self,catalog_name:t.Optional[str]=_A,table_format:t.Optional[str]=_A,storage_format:t.Optional[str]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,partition_interval_unit:t.Optional[IntervalUnit]=_A,clustered_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties:t.List[exp.Expression]=[]
		if table_format and self.dialect=='spark':
			properties.append(exp.FileFormatProperty(this=exp.Var(this=table_format)))
			if storage_format:properties.append(exp.Property(this='write.format.default',value=exp.Literal.string(storage_format)))
		elif storage_format:properties.append(exp.FileFormatProperty(this=exp.Var(this=storage_format)))
		if partitioned_by:properties.append(self._build_partitioned_by_exp(partitioned_by,partition_interval_unit=partition_interval_unit,catalog_name=catalog_name))
		if table_description:properties.append(exp.SchemaCommentProperty(this=exp.Literal.string(self._truncate_table_comment(table_description))))
		properties.extend(self._table_or_view_properties_to_expressions(table_properties))
		if properties:return exp.Properties(expressions=properties)
	def _build_view_properties_exp(self,view_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,table_description:t.Optional[str]=_A,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties:t.List[exp.Expression]=[]
		if table_description:properties.append(exp.SchemaCommentProperty(this=exp.Literal.string(self._truncate_table_comment(table_description))))
		properties.extend(self._table_or_view_properties_to_expressions(view_properties))
		if properties:return exp.Properties(expressions=properties)
	def _truncate_comment(self,comment:str,length:t.Optional[int])->str:
		if self.current_catalog_type in(_D,'delta_lake'):return comment
		return super()._truncate_comment(comment,length)
class GetCurrentCatalogFromFunctionMixin(EngineAdapter):
	CURRENT_CATALOG_EXPRESSION:exp.Expression=exp.func('current_catalog')
	def get_current_catalog(self)->t.Optional[str]:
		result=self.fetchone(exp.select(self.CURRENT_CATALOG_EXPRESSION))
		if result:return result[0]
class NonTransactionalTruncateMixin(EngineAdapter):
	def _truncate_table(self,table_name:TableName)->_A:
		if self._connection_pool.is_transaction_active:return self.execute(exp.Delete(this=exp.to_table(table_name)))
		super()._truncate_table(table_name)
class VarcharSizeWorkaroundMixin(EngineAdapter):
	def _default_precision_to_max(self,columns_to_types:t.Dict[str,exp.DataType])->t.Dict[str,exp.DataType]:
		types_with_max_default_param={k:[self.schema_differ.parameterized_type_defaults[k][0][0]]for k in self.schema_differ.max_parameter_length if k in self.schema_differ.parameterized_type_defaults}
		for(col_name,col_type)in columns_to_types.items():
			if col_type.this in types_with_max_default_param and col_type.expressions:
				parameter=self.schema_differ.get_type_parameters(col_type);type_default=types_with_max_default_param[col_type.this]
				if parameter==type_default:col_type.set('expressions',[exp.DataTypeParam(this=exp.var('max'))])
		return columns_to_types
	def _build_create_table_exp(self,table_name_or_schema:t.Union[exp.Schema,TableName],expression:t.Optional[exp.Expression],exists:bool=_C,replace:bool=_B,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,**kwargs:t.Any)->exp.Create:
		A='limit';statement=super()._build_create_table_exp(table_name_or_schema,expression=expression,exists=exists,replace=replace,target_columns_to_types=target_columns_to_types,table_description=table_description,table_kind=table_kind,**kwargs)
		if statement.expression and statement.expression.args.get(A)is not _A and statement.expression.args[A].expression.this=='0':
			assert not isinstance(table_name_or_schema,exp.Schema);select_statement=statement.expression.copy()
			for select_or_union in select_statement.find_all(exp.Select,exp.SetOperation):
				limit=select_or_union.args.get(A)
				if limit is not _A and limit.expression.this=='0':limit.pop()
				select_or_union.set('where',_A)
			temp_view_name=self._get_temp_table('ctas');self.create_view(temp_view_name,select_statement,replace=_B)
			try:columns_to_types_from_view=self._default_precision_to_max(self.columns(temp_view_name));schema=self._build_schema_exp(exp.to_table(table_name_or_schema),columns_to_types_from_view);statement=super()._build_create_table_exp(schema,_A,exists=exists,replace=replace,target_columns_to_types=columns_to_types_from_view,table_description=table_description,**kwargs)
			finally:self.drop_view(temp_view_name)
		return statement
@dataclass(frozen=_C)
class TableAlterClusterByOperation(TableAlterOperation,abc.ABC):0
@dataclass(frozen=_C)
class TableAlterChangeClusterKeyOperation(TableAlterClusterByOperation):
	clustering_key:str;dialect:str
	@property
	def is_additive(self)->bool:return _B
	@property
	def is_destructive(self)->bool:return _B
	@property
	def _alter_actions(self)->t.List[exp.Expression]:return[exp.Cluster(expressions=self.cluster_key_expressions)]
	@property
	def cluster_key_expressions(self)->t.List[exp.Expression]:parsed_cluster_key=parse_one(self.clustering_key,dialect=self.dialect);return parsed_cluster_key.expressions or[parsed_cluster_key.this]
@dataclass(frozen=_C)
class TableAlterDropClusterKeyOperation(TableAlterClusterByOperation):
	@property
	def is_additive(self)->bool:return _B
	@property
	def is_destructive(self)->bool:return _B
	@property
	def _alter_actions(self)->t.List[exp.Expression]:return[exp.Command(this='DROP',expression='CLUSTERING KEY')]
class ClusteredByMixin(EngineAdapter):
	def _build_clustered_by_exp(self,clustered_by:t.List[exp.Expression],**kwargs:t.Any)->t.Optional[exp.Cluster]:return exp.Cluster(expressions=[c.copy()for c in clustered_by])
	def get_alter_operations(self,current_table_name:TableName,target_table_name:TableName,*,ignore_destructive:bool=_B,ignore_additive:bool=_B)->t.List[TableAlterOperation]:
		operations=super().get_alter_operations(current_table_name,target_table_name,ignore_destructive=ignore_destructive,ignore_additive=ignore_additive);current_table=exp.to_table(current_table_name);target_table=exp.to_table(target_table_name);current_table_schema=schema_(current_table.db,catalog=current_table.catalog);target_table_schema=schema_(target_table.db,catalog=target_table.catalog);current_table_info=seq_get(self.get_data_objects(current_table_schema,{current_table.name}),0);target_table_info=seq_get(self.get_data_objects(target_table_schema,{target_table.name}),0)
		if current_table_info and target_table_info:
			if target_table_info.is_clustered:
				if target_table_info.clustering_key and current_table_info.clustering_key!=target_table_info.clustering_key:operations.append(TableAlterChangeClusterKeyOperation(target_table=current_table,clustering_key=target_table_info.clustering_key,dialect=self.dialect))
			elif current_table_info.is_clustered:operations.append(TableAlterDropClusterKeyOperation(target_table=current_table))
		return operations
def logical_merge(engine_adapter:EngineAdapter,target_table:TableName,source_table:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],unique_key:t.Sequence[exp.Expression],when_matched:t.Optional[exp.Whens]=_A,merge_filter:t.Optional[exp.Expression]=_A,source_columns:t.Optional[t.List[str]]=_A)->_A:
	if when_matched or merge_filter:prop='when_matched'if when_matched else'merge_filter';raise VulcanError(f"This engine does not support MERGE expressions and therefore `{prop}` is not supported.")
	engine_adapter._replace_by_key(target_table,source_table,target_columns_to_types,unique_key,is_unique_key=_C,source_columns=source_columns)
class RowDiffMixin(EngineAdapter):
	MAX_TIMESTAMP_PRECISION=6
	def concat_columns(self,columns_to_types:t.Dict[str,exp.DataType],decimal_precision:int=3,timestamp_precision:int=MAX_TIMESTAMP_PRECISION,delimiter:str=',')->exp.Expression:
		expressions_to_concat:t.List[exp.Expression]=[]
		for(idx,(column,type))in enumerate(columns_to_types.items()):
			expressions_to_concat.append(exp.func('COALESCE',self.normalize_value(exp.to_column(column),type,decimal_precision,timestamp_precision),exp.Literal.string('')))
			if idx<len(columns_to_types)-1:expressions_to_concat.append(exp.Literal.string(delimiter))
		return exp.func('CONCAT',*expressions_to_concat)
	def normalize_value(self,expr:exp.Expression,type:exp.DataType,decimal_precision:int=3,timestamp_precision:int=MAX_TIMESTAMP_PRECISION)->exp.Expression:
		if type.is_type(exp.DataType.Type.BOOLEAN):value=self._normalize_boolean_value(expr)
		elif type.is_type(*exp.DataType.INTEGER_TYPES):value=self._normalize_integer_value(expr)
		elif type.is_type(*exp.DataType.REAL_TYPES):
			type_params=list(type.find_all(exp.DataTypeParam))
			if len(type_params)==2 and type_params[-1].this.to_py()==0:value=self._normalize_integer_value(expr)
			else:value=self._normalize_decimal_value(expr,decimal_precision)
		elif type.is_type(*exp.DataType.TEMPORAL_TYPES):value=self._normalize_timestamp_value(expr,type,timestamp_precision)
		elif type.is_type(*exp.DataType.NESTED_TYPES):value=self._normalize_nested_value(expr)
		else:value=expr
		return exp.cast(value,to=exp.DataType.build('VARCHAR'))
	def _normalize_nested_value(self,expr:exp.Expression)->exp.Expression:return expr
	def _normalize_timestamp_value(self,expr:exp.Expression,type:exp.DataType,precision:int)->exp.Expression:
		if precision>self.MAX_TIMESTAMP_PRECISION:raise ValueError(f"Requested timestamp precision '{precision}' exceeds maximum supported precision: {self.MAX_TIMESTAMP_PRECISION}")
		is_date=type.is_type(exp.DataType.Type.DATE,exp.DataType.Type.DATE32);format=NORMALIZED_DATE_FORMAT if is_date else NORMALIZED_TIMESTAMP_FORMAT
		if type.is_type(exp.DataType.Type.TIMESTAMPTZ,exp.DataType.Type.TIMESTAMPLTZ,exp.DataType.Type.TIMESTAMPNTZ):expr=exp.AtTimeZone(this=expr,zone=exp.Literal.string('UTC'))
		digits_to_chop_off=6-precision;expr=exp.TimeToStr(this=expr,format=exp.Literal.string(format))
		if digits_to_chop_off>0:expr=exp.func('SUBSTRING',expr,1,len('2023-01-01 12:13:14.000000')-digits_to_chop_off)
		return expr
	def _normalize_integer_value(self,expr:exp.Expression)->exp.Expression:return exp.cast(expr,'BIGINT')
	def _normalize_decimal_value(self,expr:exp.Expression,precision:int)->exp.Expression:return exp.cast(expr,f"DECIMAL(38,{precision})")
	def _normalize_boolean_value(self,expr:exp.Expression)->exp.Expression:return exp.cast(expr,'INT')
class GrantsFromInfoSchemaMixin(EngineAdapter):
	CURRENT_USER_OR_ROLE_EXPRESSION:exp.Expression=exp.func('current_user');SUPPORTS_MULTIPLE_GRANT_PRINCIPALS=_B;USE_CATALOG_IN_GRANTS=_B;GRANT_INFORMATION_SCHEMA_TABLE_NAME='table_privileges'
	@staticmethod
	@abc.abstractmethod
	def _grant_object_kind(table_type:DataObjectType)->t.Optional[str]:0
	@abc.abstractmethod
	def _get_current_schema(self)->str:0
	def _dcl_grants_config_expr(self,dcl_cmd:t.Type[DCL],table:exp.Table,grants_config:GrantsConfig,table_type:DataObjectType=DataObjectType.TABLE)->t.List[exp.Expression]:
		A='principals';expressions:t.List[exp.Expression]=[]
		if not grants_config:return expressions
		object_kind=self._grant_object_kind(table_type)
		for(privilege,principals)in grants_config.items():
			args:t.Dict[str,t.Any]={'privileges':[exp.GrantPrivilege(this=exp.Var(this=privilege))],'securable':table.copy()}
			if object_kind:args['kind']=exp.Var(this=object_kind)
			if self.SUPPORTS_MULTIPLE_GRANT_PRINCIPALS:args[A]=[normalize_identifiers(parse_one(principal,into=exp.GrantPrincipal,dialect=self.dialect),dialect=self.dialect)for principal in principals];expressions.append(dcl_cmd(**args))
			else:
				for principal in principals:args[A]=[normalize_identifiers(parse_one(principal,into=exp.GrantPrincipal,dialect=self.dialect),dialect=self.dialect)];expressions.append(dcl_cmd(**args))
		return expressions
	def _apply_grants_config_expr(self,table:exp.Table,grants_config:GrantsConfig,table_type:DataObjectType=DataObjectType.TABLE)->t.List[exp.Expression]:return self._dcl_grants_config_expr(exp.Grant,table,grants_config,table_type)
	def _revoke_grants_config_expr(self,table:exp.Table,grants_config:GrantsConfig,table_type:DataObjectType=DataObjectType.TABLE)->t.List[exp.Expression]:return self._dcl_grants_config_expr(exp.Revoke,table,grants_config,table_type)
	def _get_grant_expression(self,table:exp.Table)->exp.Expression:
		B='catalog';A='grantee';schema_identifier=table.args.get('db')or normalize_identifiers(exp.to_identifier(self._get_current_schema(),quoted=_C),dialect=self.dialect);schema_name=schema_identifier.this;table_name=table.args.get('this').this;grant_conditions=[exp.column('table_schema').eq(exp.Literal.string(schema_name)),exp.column('table_name').eq(exp.Literal.string(table_name)),exp.column('grantor').eq(self.CURRENT_USER_OR_ROLE_EXPRESSION),exp.column(A).neq(self.CURRENT_USER_OR_ROLE_EXPRESSION)];info_schema_table=normalize_identifiers(exp.table_(self.GRANT_INFORMATION_SCHEMA_TABLE_NAME,db='information_schema'),dialect=self.dialect)
		if self.USE_CATALOG_IN_GRANTS:
			catalog_identifier=table.args.get(B)
			if not catalog_identifier:
				catalog_name=self.get_current_catalog()
				if not catalog_name:raise VulcanError('Current catalog could not be determined for fetching grants. This is unexpected.')
				catalog_identifier=normalize_identifiers(exp.to_identifier(catalog_name,quoted=_C),dialect=self.dialect)
			catalog_name=catalog_identifier.this;info_schema_table.set(B,catalog_identifier.copy());grant_conditions.insert(0,exp.column('table_catalog').eq(exp.Literal.string(catalog_name)))
		return exp.select('privilege_type',A).from_(info_schema_table).where(exp.and_(*grant_conditions))
	def _get_current_grants_config(self,table:exp.Table)->GrantsConfig:
		grant_expr=self._get_grant_expression(table);results=self.fetchall(grant_expr);grants_dict:GrantsConfig={}
		for(privilege_raw,grantee_raw)in results:
			if privilege_raw is _A or grantee_raw is _A:continue
			privilege=str(privilege_raw);grantee=str(grantee_raw)
			if not privilege or not grantee:continue
			grantees=grants_dict.setdefault(privilege,[])
			if grantee not in grantees:grantees.append(grantee)
		return grants_dict