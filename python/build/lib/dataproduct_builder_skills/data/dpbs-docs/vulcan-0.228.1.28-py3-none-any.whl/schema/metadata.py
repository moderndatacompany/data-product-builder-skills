from __future__ import annotations

import typing as t
from datetime import datetime

from pydantic import ConfigDict, Field, model_serializer, model_validator

from schema import _PydanticModel
from schema.product import (
    ComplianceSpec,
    DataHolder,
    IssueTracker,
    LicenseRef,
    ProductStrategyStatusValue,
    SlaDimensionDetail,
    SupportChannel,
    Usage,
)
from schema.filters import PolicyEntry
from schema.joins import JoinOnTree
from schema.types import (
    AiContextSpec,
    ColumnBehavior,
    ColumnClassificationValue,
    DQDimension,
    IntervalUnit,
    JoinRelationshipValue,
    LogicalTypeValue,
    MeasureTypeValue,
    MetricGranularityValue,
    MetricJoinPathValue,
    RollingWindowSpec,
    TimeGranularitySpec,
)


ModelKindValue = t.Literal[
    "FULL",
    "VIEW",
    "INCREMENTAL_BY_TIME_RANGE",
    "INCREMENTAL_BY_UNIQUE_KEY",
    "INCREMENTAL_BY_PARTITION",
    "INCREMENTAL_UNMANAGED",
    "SCD_TYPE_2",
    "SCD_TYPE_2_BY_TIME",
    "SCD_TYPE_2_BY_COLUMN",
    "EMBEDDED",
    "SEED",
    "EXTERNAL",
    "CUSTOM",
    "MANAGED",
    "DBT_CUSTOM",
    "SEMANTIC",
    "METRIC",
]
ModelSourceType = t.Literal["sql", "seed", "python", "external", "semantic", "metric", "rollup"]
ColumnKind = t.Literal["physical", "dimension", "measure", "segment"]
ProductAlignmentValue = t.Literal["source_aligned", "consumer_aligned"]
QueryableModelKind = t.Literal["semantic", "metric", "physical"]


class UserEntry(_PydanticModel):
    type: str = "MEMBER"
    username: str


class TableDetail(_PydanticModel):
    connection_uri: str
    name: str


class Table(_PydanticModel):
    physical: TableDetail
    virtual: t.Optional[TableDetail] = None


class DependsOn(_PydanticModel):
    model_config = ConfigDict(frozen=True)

    column: t.Optional[str] = None
    expression: t.Optional[str] = None
    model: str


class JoinDetail(_PydanticModel):
    ai_context: t.Optional[AiContextSpec] = None
    expression: str
    model: str
    on: JoinOnTree | None = None
    relationship: JoinRelationshipValue
    skip_for_bi: bool = False


class LineageUpstream(_PydanticModel):
    columns: t.List[str] = Field(default_factory=list)
    expressions: t.Dict[str, str] = Field(default_factory=dict)
    node: str


# `from` is a reserved keyword; Python field is `from_`, wire key is "from" (Field alias).
class ColumnLineage(_PydanticModel):
    to: str
    from_: t.List[LineageUpstream] = Field(
        alias="from",
        default_factory=list,
    )


class GraphEdge(_PydanticModel):
    from_: str = Field(alias="from")
    to: str


class JoinEdge(_PydanticModel):
    from_: str = Field(alias="from")
    skip_for_bi: bool = False
    to: str
    type_: JoinRelationshipValue = Field(alias="type")


class GraphColumn(_PydanticModel):
    name: str
    kind: ColumnKind
    ltype: LogicalTypeValue


class GraphNode(_PydanticModel):
    children: t.List[str] = Field(default_factory=list)
    column_lineage: t.List[ColumnLineage] = Field(default_factory=list)
    columns: t.List[GraphColumn] = Field(default_factory=list)
    kind: ModelKindValue
    name: str
    parents: t.List[str] = Field(default_factory=list)
    source_type: ModelSourceType


class Graph(_PydanticModel):
    child_map: t.Dict[str, t.List[str]] = Field(default_factory=dict)
    edges: t.List[GraphEdge] = Field(default_factory=list)
    nodes: t.List[GraphNode] = Field(default_factory=list)
    parent_map: t.Dict[str, t.List[str]] = Field(default_factory=dict)
    relationships: t.List[JoinEdge] = Field(default_factory=list)


MaskValue = str


class DimensionDetails(_PydanticModel):
    mask_expression: t.Optional[MaskValue] = None
    time_format: t.Optional[str] = None
    time_granularities: t.Optional[t.List[TimeGranularitySpec]] = None


class PhysicalDetails(_PydanticModel):
    mask_expression: t.Optional[MaskValue] = None


class MeasureDetails(_PydanticModel):
    expression: t.Optional[str] = None
    agg_type: MeasureTypeValue
    filters: t.List[str] = []
    rolling_window: t.Optional[RollingWindowSpec] = None


class SegmentDetails(_PydanticModel):
    expression: t.Optional[str] = None


ColumnDetails = t.Union[DimensionDetails, PhysicalDetails, MeasureDetails, SegmentDetails]


class RollupDetails(_PydanticModel):
    """A pre-aggregation (rollup) declared on a semantic model. Not a column —
    carried as a separate list on the ModelEntry and exported as a pre-aggregation at serve time."""

    description: t.Optional[str] = None
    dimensions: t.List[str] = []
    granularity: t.Optional[MetricGranularityValue] = None
    measures: t.List[str] = []
    name: str
    rollups: t.Optional[t.List[str]] = None
    segments: t.List[str] = []
    time_dimension: t.Optional[str] = None

    @property
    def is_composite(self) -> bool:
        return self.rollups is not None


class ColumnEntry(_PydanticModel):
    name: str
    kind: ColumnKind = "physical"
    dtype: str
    ltype: LogicalTypeValue
    description: t.Optional[str] = None
    depends_on: t.List[DependsOn] = []
    classification: t.Optional[ColumnClassificationValue] = None
    primary_key: bool = False
    public: bool = True
    tags: t.List[str] = []
    terms: t.List[str] = []

    behavior: t.Optional[ColumnBehavior] = None
    ai_context: t.Optional[AiContextSpec] = None
    details: t.Optional[ColumnDetails] = None


_DQ_RULE_CORE_FIELDS = frozenset({"name", "expression", "dimension", "description", "extra"})


class DqRuleEntry(_PydanticModel):
    name: str
    dimension: DQDimension
    description: t.Optional[str] = None
    expression: str
    extra: t.Dict[str, t.Any] = Field(default_factory=dict)

    @model_validator(mode="before")
    @classmethod
    def _unflatten_wire_extra(cls, data: t.Any) -> t.Any:
        """
        Fold exported Soda keys back into ``extra`` for round-trip validation.

        Export flattens ``extra`` to top-level keys (``fail query``, ``samples limit``,
        etc.); this validator is the inverse of :meth:`_flatten_extra_wire`.
        """
        if not isinstance(data, dict):
            return data
        payload = dict(data)
        extra = dict(payload.pop("extra", None) or {})
        for key in list(payload.keys()):
            if key not in _DQ_RULE_CORE_FIELDS:
                extra[key] = payload.pop(key)
        if extra:
            payload["extra"] = extra
        return payload

    @model_serializer(mode="wrap")
    def _flatten_extra_wire(
        self,
        handler: t.Callable[..., t.Dict[str, t.Any]],
    ) -> t.Dict[str, t.Any]:
        data = handler(self)
        loose = data.pop("extra", None) or {}
        return {**loose, **data}


class ModelDataQuality(_PydanticModel):
    filter: t.Optional[str] = None
    profiles: t.List[str] = Field(default_factory=list)
    rules: t.List[DqRuleEntry] = Field(default_factory=list)


class AuditEntry(_PydanticModel):
    name: str
    dimension: DQDimension
    description: t.Optional[str] = None
    columns: t.Optional[t.List[str]] = None
    args: t.Dict[str, str] = {}


class GatewayInfo(_PydanticModel):
    name: str
    dialect: str
    database: t.Optional[str] = None
    host: t.Optional[str] = None
    port: t.Optional[int] = None
    account: t.Optional[str] = None
    connection_type: str
    connection_uri: t.Optional[str] = None


class ProductInfo(_PydanticModel):
    domain: t.Optional[str] = None
    display_name: t.Optional[str] = None
    alignment: ProductAlignmentValue = "consumer_aligned"
    discoverable: bool = True
    version: str = "0.0.0"
    description: t.Optional[str] = None
    status: ProductStrategyStatusValue = "Draft"
    tags: t.List[str] = []
    terms: t.List[str] = []
    users: t.List[UserEntry] = Field(default_factory=list)
    issue_tracker: t.Optional[IssueTracker] = None
    repository: t.Optional[str] = None
    sla: t.Dict[str, SlaDimensionDetail] = Field(default_factory=dict)
    support: t.List[SupportChannel] = Field(default_factory=list)
    usage: Usage = Field(default_factory=Usage)
    compliance: t.Optional[ComplianceSpec] = None
    data_holder: t.Optional[DataHolder] = Field(default=None, alias="dataHolder")
    license: t.Optional[LicenseRef] = None


class NominalRun(_PydanticModel):
    is_pending: bool = False
    next: t.Optional[datetime] = None
    prev: t.Optional[datetime] = None


class ModelEntry(_PydanticModel):
    name: str
    display_name: t.Optional[str] = None
    kind: ModelKindValue
    source_type: ModelSourceType
    description: t.Optional[str] = None
    dialect: str = Field(default="")
    model_name: t.Optional[str] = None
    fqn: str

    grains: t.List[str] = Field(default_factory=list)
    references: t.List[str] = Field(default_factory=list)

    cron: str = Field(default="")
    cron_tz: t.Optional[str] = None
    interval_unit: t.Optional[IntervalUnit] = None

    join_map: t.Dict[str, str] = Field(default_factory=dict)
    joins: t.List[JoinDetail] = []

    depends_on: t.List[str] = []

    owner: t.Optional[str] = None
    tags: t.List[str] = []
    terms: t.List[str] = []

    batch_size: t.Optional[int] = None
    clustered_by: t.Optional[str] = None
    default_granularity: t.Optional[MetricGranularityValue] = None
    metric_join_path: t.Optional[MetricJoinPathValue] = None

    columns: t.List[ColumnEntry] = []

    audits: t.List[AuditEntry] = []

    dq: t.Optional[ModelDataQuality] = None
    evaluatable: bool = False
    lookback: t.Optional[int] = None
    partitioned_by: t.Optional[str] = None

    path: t.Optional[str] = None
    policies: t.List[PolicyEntry] = Field(default_factory=list)
    rollups: t.List[RollupDetails] = Field(default_factory=list)

    storage_format: t.Optional[str] = None
    table: t.Optional[Table] = None
    table_format: t.Optional[str] = None
    ai_context: t.Optional[AiContextSpec] = None


class Index(_PydanticModel):
    """
    Serve-time lookup indexes derived from exported metadata.

    Attributes:
        protected_models: Allowed policy groups per protected model.
        protected_models_by_group: Protected models per policy group.
        queryable_models: Queryable model kind per model name (semantic, metric, physical; not rollups).
        queryable_tables: Physical warehouse model name per resolved table name or logical model name.
        rollup_tables: Pre-aggregation model name per resolved table name or logical model name.
        members: Column kind per ``model.field`` member ref.
    """

    model_config = ConfigDict(frozen=True)

    protected_models: t.Mapping[str, frozenset[str]] = Field(default_factory=dict)
    protected_models_by_group: t.Mapping[str, frozenset[str]] = Field(default_factory=dict)
    queryable_models: t.Mapping[str, QueryableModelKind] = Field(default_factory=dict)
    queryable_tables: t.Mapping[str, str] = Field(default_factory=dict)
    rollup_tables: t.Mapping[str, str] = Field(default_factory=dict)
    members: t.Mapping[str, ColumnKind] = Field(default_factory=dict)

    def parse_qualified_member_ref(self, qualified_ref: str) -> t.Optional[t.Tuple[str, str]]:
        """
        Resolve ``model.field`` (optional ``.granularity`` suffix) to model and column names.

        Model names may contain dots (for example ``b2b_saas.users``); the longest matching
        ``queryable_models`` prefix wins (by splitting on ``.``, not scanning all models).
        A trailing segment is REST time granularity when the model is ``semantic`` or
        ``metric``, the two-part ref is in ``members``, and the full ref is not.

        Args:
            qualified_ref: ``model.field`` or ``model.time_field.granularity``.

        Returns:
            ``(model_name, column_name)`` when the ref resolves, else ``None``.
        """
        parts = qualified_ref.split(".")
        if len(parts) < 2:
            return None
        # Longest model prefix first: model names may contain dots (b2b_saas.users).
        for i in range(len(parts) - 1, 0, -1):
            model_name = ".".join(parts[:i])
            if model_name not in self.queryable_models:
                continue
            column_part = ".".join(parts[i:])
            if not column_part:
                continue
            member_key = f"{model_name}.{column_part}"
            if member_key in self.members:
                return model_name, column_part
            # REST only: users.signup_date.month → users.signup_date (not warehouse refs).
            if (
                "." in column_part
                and self.queryable_models[model_name] in ("semantic", "metric")
            ):
                base_column = column_part.rsplit(".", 1)[0]
                if f"{model_name}.{base_column}" in self.members:
                    return model_name, base_column
        return None


class Metadata(_PydanticModel):
    name: str
    tenant: str
    version: str = Field(
        default="0.0.0",
        deprecated=True,
        description="Deprecated. Read ``product.version`` instead.",
    )
    fingerprint: str
    product: ProductInfo
    alignment: ProductAlignmentValue = Field(
        default="consumer_aligned",
        deprecated=True,
        description="Deprecated. Read ``product.alignment`` instead.",
    )
    discoverable: bool = Field(
        default=True,
        deprecated=True,
        description="Deprecated. Read ``product.discoverable`` instead.",
    )
    as_of: datetime
    env: str
    gateway: GatewayInfo
    gateways: t.Optional[t.List[GatewayInfo]] = None
    models: t.List[ModelEntry] = Field(default_factory=list)
    has_reciprocal_joins: bool = False
    missing_intervals: t.Dict[str, t.List[t.Tuple[str, str]]] = Field(default_factory=dict)
    graph: Graph
    nominal_runs: t.Dict[str, NominalRun] = Field(default_factory=dict)
    index: Index = Field(default_factory=Index)

    @model_validator(mode="after")
    def _attach_index(self) -> Metadata:
        protected_models: dict[str, frozenset[str]] = {}
        queryable_models: dict[str, QueryableModelKind] = {}
        queryable_tables: dict[str, str] = {}
        rollup_tables: dict[str, str] = {}
        members: dict[str, ColumnKind] = {}

        for entry in self.models:
            if entry.kind == "SEMANTIC":
                queryable_models[entry.name] = "semantic"
                for column in entry.columns:
                    members[f"{entry.name}.{column.name}"] = column.kind

            elif entry.kind == "METRIC":
                queryable_models[entry.name] = "metric"
                for column in entry.columns:
                    members[f"{entry.name}.{column.name}"] = column.kind

            elif (
                entry.kind != "EMBEDDED"
                and entry.source_type != "rollup"
                and entry.table is not None
                and bool(entry.table.physical.name)
            ):
                queryable_models[entry.name] = "physical"
                queryable_tables[entry.name] = entry.name
                queryable_tables[entry.table.physical.name] = entry.name
                if entry.table.virtual is not None and entry.table.virtual.name:
                    queryable_tables[entry.table.virtual.name] = entry.name
                for column in entry.columns:
                    if column.kind == "physical":
                        members[f"{entry.name}.{column.name}"] = column.kind

            elif (
                entry.source_type == "rollup"
                and entry.table is not None
                and bool(entry.table.physical.name)
            ):
                rollup_tables[entry.name] = entry.name
                rollup_tables[entry.table.physical.name] = entry.name
                if entry.table.virtual is not None and entry.table.virtual.name:
                    rollup_tables[entry.table.virtual.name] = entry.name

            if entry.policies:
                protected_models[entry.name] = frozenset(policy.group for policy in entry.policies)

        protected_models_by_group = {
            group: frozenset(model for model, groups in protected_models.items() if group in groups)
            for group in {g for groups in protected_models.values() for g in groups}
        }

        self.index = Index(
            protected_models=dict(sorted(protected_models.items())),
            protected_models_by_group=dict(sorted(protected_models_by_group.items())),
            queryable_models=dict(sorted(queryable_models.items())),
            queryable_tables=dict(sorted(queryable_tables.items())),
            rollup_tables=dict(sorted(rollup_tables.items())),
            members=dict(sorted(members.items())),
        )
        return self

    def entry_for(self, name: str) -> t.Optional[ModelEntry]:
        """
        Return the model entry named ``name``, scanning :attr:`models` linearly.

        Args:
            name: Logical model name (for example ``users`` or ``cohort_retention``).

        Returns:
            The matching :class:`ModelEntry`, or ``None`` when no model has that name.
        """
        for entry in self.models:
            if entry.name == name:
                return entry
        return None

    def require_entry(self, name: str) -> ModelEntry:
        """
        Return the model entry named ``name`` or raise :class:`KeyError`.

        Args:
            name: Logical model name.

        Returns:
            The matching :class:`ModelEntry`.

        Raises:
            KeyError: If ``name`` is not present in :attr:`models`.
        """
        entry = self.entry_for(name)
        if entry is None:
            raise KeyError(name)
        return entry

    def column_for(self, model_name: str, column_name: str) -> t.Optional[ColumnEntry]:
        """
        Return the column on ``model_name`` named ``column_name``.

        Args:
            model_name: Logical model name.
            column_name: Column name on that model.

        Returns:
            The matching :class:`ColumnEntry`, or ``None`` when the model or column is missing.
        """
        entry = self.entry_for(model_name)
        if entry is None:
            return None
        for column in entry.columns:
            if column.name == column_name:
                return column
        return None

    def require_column(self, model_name: str, column_name: str) -> ColumnEntry:
        """
        Return the column on ``model_name`` named ``column_name`` or raise :class:`KeyError`.

        Args:
            model_name: Logical model name.
            column_name: Column name on that model.

        Returns:
            The matching :class:`ColumnEntry`.

        Raises:
            KeyError: If the model or column is missing (key ``model_name.column_name``).
        """
        column = self.column_for(model_name, column_name)
        if column is None:
            raise KeyError(f"{model_name}.{column_name}")
        return column

    def member_for(self, qualified_ref: str) -> t.Optional[ColumnEntry]:
        """
        Return the column for a qualified member ref such as ``users.total_users``.

        Supports dotted model names (``b2b_saas.users.user_id``) and time-dimension
        granularity suffixes (``users.signup_date.month`` → column ``signup_date``).

        Args:
            qualified_ref: ``model.field`` or ``model.time_field.granularity``.

        Returns:
            The matching :class:`ColumnEntry`, or ``None`` when the ref does not resolve.
        """
        parsed = self.index.parse_qualified_member_ref(qualified_ref)
        if parsed is None:
            return None
        model_name, column_name = parsed
        return self.column_for(model_name, column_name)

    def require_member(self, qualified_ref: str) -> ColumnEntry:
        """
        Return the column for ``qualified_ref`` or raise :class:`KeyError`.

        Args:
            qualified_ref: ``model.field`` or ``model.time_field.granularity``.

        Returns:
            The matching :class:`ColumnEntry`.

        Raises:
            KeyError: If ``qualified_ref`` does not resolve to a known member.
        """
        column = self.member_for(qualified_ref)
        if column is None:
            raise KeyError(qualified_ref)
        return column

    def to_json_dict(self) -> t.Dict[str, t.Any]:
        return self.model_dump(mode="json", exclude_none=True, by_alias=True)
