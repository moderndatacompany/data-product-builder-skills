"""
Pydantic wire models for Open Data Product Standard (ODPS) v1.0.0 documents.

These types describe emitted product JSON/YAML; they are not authoring models
for ``config.yaml``.

Spec:
https://bitol-io.github.io/open-data-product-standard/v1.0.0/

JSON Schema (validation companion; standard takes precedence on conflict):
https://github.com/bitol-io/open-data-product-standard/blob/main/schema/odps-json-schema-v1.0.0.json
"""

from __future__ import annotations

import typing as t

from pydantic import Field

from schema import _PydanticModel

OdpsApiVersionValue = t.Literal["v1.0.0"]
OdpsProductKindValue = t.Literal["DataProduct"]
OdpsProductStatusValue = t.Literal["proposed", "draft", "active", "deprecated", "retired"]


class OdpsCustomProperty(_PydanticModel):
    property: str
    value: t.Any
    description: t.Optional[str] = None


class OdpsAuthoritativeDefinition(_PydanticModel):
    type: str
    url: str
    description: t.Optional[str] = None


class OdpsDescription(_PydanticModel):
    purpose: t.Optional[str] = None
    limitations: t.Optional[str] = None
    usage: t.Optional[str] = None
    custom_properties: t.Optional[t.List[OdpsCustomProperty]] = Field(
        default=None,
        alias="customProperties",
    )


class OdpsSupport(_PydanticModel):
    channel: str
    url: str
    description: t.Optional[str] = None
    tool: t.Optional[str] = None
    scope: t.Optional[str] = None
    invitation_url: t.Optional[str] = Field(default=None, alias="invitationUrl")


class OdpsInputPort(_PydanticModel):
    name: str
    version: str
    contract_id: str = Field(alias="contractId")
    tags: t.List[str] = []
    custom_properties: t.Optional[t.List[OdpsCustomProperty]] = Field(
        default=None,
        alias="customProperties",
    )


class OdpsOutputPort(_PydanticModel):
    name: str
    version: str
    contract_id: t.Optional[str] = Field(default=None, alias="contractId")
    description: t.Optional[str] = None
    type: t.Optional[str] = None
    tags: t.List[str] = []
    custom_properties: t.Optional[t.List[OdpsCustomProperty]] = Field(
        default=None,
        alias="customProperties",
    )


class OdpsTeamMember(_PydanticModel):
    username: str
    role: t.Optional[str] = None
    name: t.Optional[str] = None
    description: t.Optional[str] = None


class OdpsTeam(_PydanticModel):
    name: t.Optional[str] = None
    description: t.Optional[str] = None
    members: t.List[OdpsTeamMember] = []


class OdpsProduct(_PydanticModel):
    """
    Root ODPS v1.0.0 data product document.

    Required fields per the published JSON schema: ``apiVersion``, ``kind``,
    ``id``, and ``status``.

    Spec: https://bitol-io.github.io/open-data-product-standard/v1.0.0/
    """

    api_version: OdpsApiVersionValue = Field(default="v1.0.0", alias="apiVersion")
    kind: OdpsProductKindValue = "DataProduct"
    id: str
    status: OdpsProductStatusValue
    name: t.Optional[str] = None
    version: t.Optional[str] = None
    domain: t.Optional[str] = None
    tenant: t.Optional[str] = None
    description: t.Optional[OdpsDescription] = None
    tags: t.List[str] = []
    input_ports: t.Optional[t.List[OdpsInputPort]] = Field(default=None, alias="inputPorts")
    output_ports: t.Optional[t.List[OdpsOutputPort]] = Field(default=None, alias="outputPorts")
    support: t.Optional[t.List[OdpsSupport]] = None
    team: t.Optional[OdpsTeam] = None
    custom_properties: t.Optional[t.List[OdpsCustomProperty]] = Field(
        default=None,
        alias="customProperties",
    )
