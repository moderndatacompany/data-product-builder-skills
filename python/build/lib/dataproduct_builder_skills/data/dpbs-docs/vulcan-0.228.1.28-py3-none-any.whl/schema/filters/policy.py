from __future__ import annotations

import typing as t

from pydantic import Field, computed_field, field_validator, model_validator

from schema import _PydanticModel
from schema.filters.operators import (
    POLICY_FILTER_OPERATORS,
    FilterOperator,
    FilterValue,
    _OPERATOR_PHRASES,
    _OPERATORS_WITHOUT_VALUES,
    validate_operator_values,
    validate_policy_field,
    validate_policy_group,
)

# Wire-only policy filter and entry types. Authoring/validation lives in
# ``vulcan.core.model.policy``; keep JSON shapes aligned via export round-trip tests.


class PolicyUnaryFilter(_PydanticModel):
    member: str = Field(min_length=1)
    operator: FilterOperator
    values: list[FilterValue] | None = None

    @field_validator("operator")
    @classmethod
    def _reject_measure_filter(cls, value: FilterOperator) -> FilterOperator:
        if value not in POLICY_FILTER_OPERATORS:
            raise ValueError(
                f"operator '{value.value}' is not allowed in policy filters "
                "(row-level only; measureFilter is forbidden)"
            )
        return value

    @field_validator("member")
    @classmethod
    def _validate_short_field(cls, value: str) -> str:
        return validate_policy_field(value)

    @model_validator(mode="after")
    def _validate_shape(self) -> PolicyUnaryFilter:
        validate_operator_values(operator=self.operator, values=self.values)
        return self

    @property
    def field_name(self) -> str:
        return self.member


class PolicyLogicalFilter(_PydanticModel):
    and_: list["PolicyFilterExpression"] | None = Field(default=None, alias="and")
    or_: list["PolicyFilterExpression"] | None = Field(default=None, alias="or")

    @model_validator(mode="after")
    def _validate_group(self) -> PolicyLogicalFilter:
        if bool(self.and_) == bool(self.or_):
            raise ValueError("logical filter requires exactly one of 'and' or 'or'")
        children = self.and_ or self.or_ or []
        if not children:
            raise ValueError("'and'/'or' must contain at least one filter")
        return self


PolicyFilterExpression = t.Union[PolicyUnaryFilter, PolicyLogicalFilter]


class PolicyEntry(_PydanticModel):
    group: str
    filter: list[PolicyFilterExpression] | None = None
    mask: list[str] | None = None

    @computed_field  # type: ignore[prop-decorator]
    @property
    def filter_display(self) -> str | None:
        """
        Markdown row-filter summary for API read responses.

        Returns:
            Humanized filter text, or ``None`` when no row filter is configured.
        """
        return humanize_policy_filters(self.filter)

    @field_validator("group")
    @classmethod
    def _validate_group_field(cls, value: str) -> str:
        return validate_policy_group(value)

    @field_validator("mask", mode="before")
    @classmethod
    def _coerce_mask_names(cls, value: t.Any) -> t.Any:
        if value is None:
            return None
        if value == "*":
            raise ValueError("mask wildcard '*' is not supported; list explicit member names")
        if not isinstance(value, list):
            raise ValueError("mask must be a list of member names")
        out: list[str] = []
        for entry in value:
            if isinstance(entry, dict):
                raise ValueError(
                    "mask entries must be member names only; move mask expressions to "
                    "dimension mask_expression or column_mask_expressions on the model"
                )
            out.append(validate_policy_field(str(entry).strip()))
        return out


def humanize_policy_filters(
    filters: list[PolicyFilterExpression] | None,
) -> str | None:
    """
    Render a policy rule filter list as markdown.

    Top-level siblings are ANDed, matching warehouse policy compilation.

    Args:
        filters: Policy filter AST nodes from metadata or audit snapshots.

    Returns:
        Markdown sentence, or ``None`` when ``filters`` is empty or absent.
    """
    if not filters:
        return None
    parts = [_humanize_policy_filter_expr(expr, grouped=False) for expr in filters]
    return _join_with_logic(parts, "and")


def _humanize_policy_filter_expr(expr: PolicyFilterExpression, *, grouped: bool) -> str:
    if isinstance(expr, PolicyUnaryFilter):
        return _humanize_unary_filter(expr)
    if isinstance(expr, PolicyLogicalFilter):
        return _humanize_logical_filter(expr, grouped=grouped)
    # New PolicyFilterExpression union member; extend this dispatcher and add a renderer.
    raise TypeError(f"unsupported policy filter expression: {type(expr).__name__}")


def _humanize_logical_filter(logical: PolicyLogicalFilter, *, grouped: bool) -> str:
    children = logical.and_ or logical.or_ or []
    joiner = "and" if logical.and_ else "or"
    parts = [_humanize_policy_filter_expr(child, grouped=True) for child in children]
    inner = _join_with_logic(parts, joiner)
    if grouped and len(children) > 1:
        return f"({inner})"
    return inner


def _humanize_unary_filter(unary: PolicyUnaryFilter) -> str:
    member = _md_member(unary.member)
    operator = unary.operator
    phrase = _OPERATOR_PHRASES.get(operator)
    if phrase is None:
        # New FilterOperator enum member without a matching _OPERATOR_PHRASES entry;
        # test_operator_phrases_cover_all_filter_operators guards completeness.
        raise ValueError(f"unsupported policy filter operator: {operator.value}")

    if operator in _OPERATORS_WITHOUT_VALUES:
        return f"{member} {phrase}"

    values = unary.values or []

    if operator == FilterOperator.EQUALS:
        if len(values) == 1:
            return f"{member} {phrase} {_md_value(values[0])}"
        value_part = _join_with_logic([_md_value(value) for value in values], "or")
        return f"{member} {phrase} {value_part}"

    if operator == FilterOperator.NOT_EQUALS:
        if len(values) == 1:
            return f"{member} {phrase} {_md_value(values[0])}"
        parts = [f"{member} {phrase} {_md_value(value)}" for value in values]
        return _join_with_logic(parts, "and")

    if operator in {FilterOperator.IN, FilterOperator.NOT_IN}:
        listed = ", ".join(_md_value(value) for value in values)
        return f"{member} {phrase} ({listed})"

    if operator in {
        FilterOperator.IN_DATE_RANGE,
        FilterOperator.NOT_IN_DATE_RANGE,
    }:
        return _humanize_date_range_values(member, phrase, values)

    return f"{member} {phrase} {_md_value(values[0])}"


def _humanize_date_range_values(member: str, phrase: str, values: list[FilterValue]) -> str:
    # validate_operator_values allows one or two bounds; rewriter treats one value as a
    # single-day range and uses the first two when both are present.
    if len(values) == 1:
        bound = _md_value(values[0])
        return f"{member} {phrase} {bound} and {bound}"
    return f"{member} {phrase} {_md_value(values[0])} and {_md_value(values[1])}"


def _md_member(member: str) -> str:
    return f"**{member}**"


def _md_value(value: FilterValue) -> str:
    if value is None:
        text = "null"
    elif isinstance(value, bool):
        text = "true" if value else "false"
    else:
        text = str(value)
    if "`" in text:
        return f"`` {text} ``"
    return f"`{text}`"


def _join_with_logic(parts: list[str], joiner: str) -> str:
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    return f" {joiner} ".join(parts)
