from __future__ import annotations

import typing as t
from typing import get_args

from pydantic import AnyHttpUrl, Field, model_validator

from schema import _PydanticModel

CaveatSeverity = t.Literal["low", "medium", "high"]

IssueTrackerProviderValue = t.Literal[
    "jira",
    "github",
    "gitlab",
    "linear",
    "asana",
    "azure_devops",
    "other",
]

ProductStrategyStatusValue = t.Literal["Draft", "Active"]

SlaDimensionValue = t.Literal[
    "uptime",
    "latency",
    "response_time",
    "error_rate",
    "update_frequency",
    "time_to_detect",
    "time_to_notify",
    "time_to_repair",
    "email_response_time",
    "end_of_support",
    "end_of_life",
]

SupportChannelScopeValue = t.Literal["interactive", "announcements", "issues"]
SupportChannelToolValue = t.Literal["slack", "teams", "email", "ticket", "other"]

UsageReferenceType = t.Literal["doc", "design", "dashboard", "runbook", "other"]


def normalize_sla_dimension_keys(
    value: t.Any,
) -> t.Any:
    """
    Normalize SLA dimension dict keys to canonical snake_case.

    Args:
        value: Raw ``sla`` mapping from config input.

    Returns:
        Mapping keyed by :data:`SlaDimensionValue` literals.

    Raises:
        ValueError: When a dimension key is not recognized.
    """
    if not isinstance(value, dict):
        return value
    allowed = frozenset(get_args(SlaDimensionValue))
    normalized: t.Dict[SlaDimensionValue, t.Any] = {}
    for key, detail in value.items():
        key_str = str(key)
        canonical = "".join(
            f"_{c.lower()}" if c.isupper() and idx != 0 else c.lower()
            for idx, c in enumerate(key_str)
        )
        if canonical not in allowed:
            raise ValueError(f"Unknown SLA dimension {key!r}")
        normalized[t.cast(SlaDimensionValue, canonical)] = detail
    return normalized


def _coerce_title_string(data: t.Any) -> t.Any:
    if isinstance(data, str):
        return {"title": data}
    return data


class UsageItem(_PydanticModel):
    title: str
    details: t.Optional[str] = None

    @model_validator(mode="before")
    @classmethod
    def _accept_title_string(cls, data: t.Any) -> t.Any:
        return _coerce_title_string(data)


class Caveat(_PydanticModel):
    title: str
    details: t.Optional[str] = None
    severity: CaveatSeverity = "medium"

    @model_validator(mode="before")
    @classmethod
    def _accept_title_string(cls, data: t.Any) -> t.Any:
        return _coerce_title_string(data)


class Reference(_PydanticModel):
    title: str
    url: str
    type: UsageReferenceType = "doc"


class PricingPlan(_PydanticModel):
    name: str
    unit: str
    price: t.Optional[float] = None
    price_currency: t.Optional[str] = Field(default=None, alias="priceCurrency")
    billing_duration: t.Optional[str] = Field(default=None, alias="billingDuration")
    notes: t.Optional[str] = None


def default_pricing_plans() -> t.List[PricingPlan]:
    """
    Return the default display-only pricing plan when none is authored.

    Returns:
        A single internal-analytics plan suitable for catalog listings.
    """
    return [
        PricingPlan(
            name="Internal Usage",
            unit="free",
            notes="Employee and partner use only; not allowed for external share",
        )
    ]


class Usage(_PydanticModel):
    good_for: t.List[UsageItem] = Field(default_factory=list)
    not_for: t.List[UsageItem] = Field(default_factory=list)
    caveats: t.List[Caveat] = Field(default_factory=list)
    references: t.List[Reference] = Field(default_factory=list)
    objectives: t.List[str] = Field(default_factory=list)
    alignments: t.List[str] = Field(default_factory=list)
    pricing_plans: t.List[PricingPlan] = Field(
        default_factory=default_pricing_plans,
        alias="pricingPlans",
    )


def default_usage() -> Usage:
    """
    Return a usage spec with empty guidance lists and the default pricing plan.

    Returns:
        Usage with empty ``good_for``, ``not_for``, ``caveats``, ``references``,
        ``objectives``, and ``alignments``, plus :func:`default_pricing_plans`.
    """
    return Usage()


class ComplianceSpec(_PydanticModel):
    regimes: t.List[str] = []
    data_residency: t.Optional[str] = None
    legal_contact: t.Optional[str] = None


class DataHolder(_PydanticModel):
    legal_name: t.Optional[str] = Field(default=None, alias="legalName")
    logo_url: t.Optional[str] = Field(default=None, alias="logoUrl")
    url: t.Optional[str] = None


class IssueTracker(_PydanticModel):
    provider: IssueTrackerProviderValue
    url: AnyHttpUrl


class LicenseRef(_PydanticModel):
    url: str


class SlaMonitoring(_PydanticModel):
    system: str
    docs: t.Optional[str] = None
    queries: t.Optional[t.List[str]] = None


class SlaDimensionDetail(_PydanticModel):
    target: t.Union[int, float, str]
    unit: t.Optional[str] = None
    monitoring: t.Optional[SlaMonitoring] = None


class SupportChannel(_PydanticModel):
    channel: str
    tool: SupportChannelToolValue
    scope: SupportChannelScopeValue
    url: t.Optional[str] = None
    hours: t.Optional[str] = None
