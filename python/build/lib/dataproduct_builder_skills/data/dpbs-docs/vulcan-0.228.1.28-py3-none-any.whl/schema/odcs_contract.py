"""
Pydantic wire models for Open Data Contract Standard (ODCS) v3.1.0 documents.

These types describe emitted contract JSON/YAML; they are not authoring models
for ``config.yaml`` or MODEL blocks.

Spec:
https://bitol-io.github.io/open-data-contract-standard/v3.1.0/

JSON Schema (validation companion; standard takes precedence on conflict):
https://github.com/bitol-io/open-data-contract-standard/blob/main/schema/odcs-json-schema-v3.1.0.json
"""

from __future__ import annotations

import typing as t

from pydantic import Field

from schema import _PydanticModel

OdcsApiVersionValue = t.Literal["v3.1.0"]
OdcsContractKindValue = t.Literal["DataContract"]
OdcsContractStatusValue = t.Literal["proposed", "draft", "active", "deprecated", "retired"]


class OdcsCustomProperty(_PydanticModel):
    property: str
    value: t.Any
    description: t.Optional[str] = None


class OdcsSupportItem(_PydanticModel):
    channel: str
    url: t.Optional[str] = None
    description: t.Optional[str] = None
    tool: t.Optional[str] = None
    scope: t.Optional[str] = None
    invitation_url: t.Optional[str] = Field(default=None, alias="invitationUrl")


class OdcsContractDescription(_PydanticModel):
    usage: t.Optional[str] = None
    purpose: t.Optional[str] = None
    limitations: t.Optional[str] = None
    custom_properties: t.Optional[t.List[OdcsCustomProperty]] = Field(
        default=None,
        alias="customProperties",
    )


class OdcsSchemaProperty(_PydanticModel):
    name: str
    logical_type: t.Optional[str] = Field(default=None, alias="logicalType")
    physical_type: t.Optional[str] = Field(default=None, alias="physicalType")
    description: t.Optional[str] = None
    primary_key: t.Optional[bool] = Field(default=None, alias="primaryKey")
    primary_key_position: t.Optional[int] = Field(default=None, alias="primaryKeyPosition")
    classification: t.Optional[str] = None
    business_name: t.Optional[str] = Field(default=None, alias="businessName")
    tags: t.List[str] = []
    transform_source_objects: t.Optional[t.List[str]] = Field(
        default=None,
        alias="transformSourceObjects",
    )
    transform_logic: t.Optional[str] = Field(default=None, alias="transformLogic")
    transform_description: t.Optional[str] = Field(default=None, alias="transformDescription")
    custom_properties: t.Optional[t.List[OdcsCustomProperty]] = Field(
        default=None,
        alias="customProperties",
    )


class OdcsSchemaObject(_PydanticModel):
    name: str
    logical_type: t.Optional[str] = Field(default="object", alias="logicalType")
    physical_type: t.Optional[str] = Field(default=None, alias="physicalType")
    physical_name: t.Optional[str] = Field(default=None, alias="physicalName")
    description: t.Optional[str] = None
    tags: t.List[str] = []
    data_granularity_description: t.Optional[str] = Field(
        default=None,
        alias="dataGranularityDescription",
    )
    properties: t.List[OdcsSchemaProperty] = []
    relationships: t.Optional[t.List["OdcsRelationship"]] = None
    quality: t.Optional[t.List[t.Dict[str, t.Any]]] = None


class OdcsServer(_PydanticModel):
    server: t.Optional[str] = None
    type: t.Optional[str] = None
    environment: t.Optional[str] = None
    description: t.Optional[str] = None
    host: t.Optional[str] = None
    port: t.Optional[int] = None
    database: t.Optional[str] = None
    schema_: t.Optional[str] = Field(default=None, alias="schema")


class OdcsTeamMember(_PydanticModel):
    username: str
    role: t.Optional[str] = None
    name: t.Optional[str] = None
    description: t.Optional[str] = None


class OdcsTeam(_PydanticModel):
    name: t.Optional[str] = None
    description: t.Optional[str] = None
    members: t.List[OdcsTeamMember] = []


class OdcsSlaProperty(_PydanticModel):
    property: str
    value: t.Union[str, int, float]
    unit: t.Optional[str] = None
    element: t.Optional[str] = None
    scheduler: t.Optional[str] = None
    schedule: t.Optional[str] = None


class OdcsRelationship(_PydanticModel):
    name: t.Optional[str] = None
    type: t.Optional[str] = None
    from_: t.Optional[str] = Field(default=None, alias="from")
    to: t.Optional[str] = None


class OdcsContractSummary(_PydanticModel):
    """Summary entry for ODCS contract discovery lists."""

    id: str
    name: str
    version: str
    status: OdcsContractStatusValue


class OdcsContract(_PydanticModel):
    """
    Root ODCS v3.1.0 data contract document.

    Required fields per the published JSON schema: ``version``, ``apiVersion``,
    ``kind``, ``id``, and ``status``.

    Spec: https://bitol-io.github.io/open-data-contract-standard/v3.1.0/
    """

    api_version: OdcsApiVersionValue = Field(default="v3.1.0", alias="apiVersion")
    kind: OdcsContractKindValue = "DataContract"
    id: str
    status: OdcsContractStatusValue
    name: t.Optional[str] = None
    tenant: t.Optional[str] = None
    domain: t.Optional[str] = None
    data_product: t.Optional[str] = Field(default=None, alias="dataProduct")
    tags: t.List[str] = []
    description: t.Optional[OdcsContractDescription] = None
    schema_: t.Optional[t.List[OdcsSchemaObject]] = Field(default=None, alias="schema")
    support: t.Optional[t.List[OdcsSupportItem]] = None
    team: t.Optional[OdcsTeam] = None
    servers: t.Optional[t.List[OdcsServer]] = None
    sla_properties: t.Optional[t.List[OdcsSlaProperty]] = Field(
        default=None,
        alias="slaProperties",
    )
    version: str
    custom_properties: t.Optional[t.List[OdcsCustomProperty]] = Field(
        default=None,
        alias="customProperties",
    )
