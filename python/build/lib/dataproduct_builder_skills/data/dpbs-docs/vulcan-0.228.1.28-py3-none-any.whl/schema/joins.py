"""
Join ``on`` trees for semantic models.

This module sits between semantic YAML and the join predicate strings the rest of the
stack consumes (validation, metadata export, serve compilation). Start here for join
loading or export work.

## What authors write

Each item under ``joins:`` must declare exactly one of:

- ``on`` — structured equi-join (the usual case)
- ``expression`` — raw SQL when structured form is not enough

Structured ``on`` compiles into ``expression``; expression-only joins are normalized
at load and stored as authored SQL.

## Load-time flow

```
on         -> JoinSpec.resolve -> JoinOnTree + compiled expression
expression -> JoinSpec.resolve -> stored expression (no self-dim normalization)
```

## How ``on`` is shaped

Think of ``on`` as a small boolean tree in YAML.

- **String leaf** — same dimension on both sides (``user_id`` ->
  ``{users.user_id} = {subscriptions.user_id}``)
- **Nested two-item list** — asymmetric pair (source column, then target column)
- **Nested group** — ``{ and: [...] }`` or ``{ or: [...] }``

Bare lists at the root imply AND. See examples below.

## Examples

```yaml
# simple
# -> {users.user_id} = {subscriptions.user_id}
joins:
  - name: subscriptions
    type: one_to_many
    on: user_id

# composite AND
# -> {users.tenant_id} = {subscriptions.tenant_id} AND {users.user_id} = {subscriptions.user_id}
on:
  - tenant_id
  - user_id

# OR alternates
# -> {users.user_id} = {subscriptions.user_id} OR {users.legacy_id} = {subscriptions.legacy_id}
on:
  or:
    - user_id
    - legacy_id

# renamed column on one side
# -> {users.tenant_id} = {subscriptions.tenant_id} AND {users.plan_id} = {subscriptions.subscription_plan_id}
on:
  and:
    - tenant_id
    - - plan_id
      - subscription_plan_id

# expression escape hatch (authored as-is, not compiled from on)
expression: "DATE({users.signup_date}) = DATE({subscriptions.start_date})"
```

## Module functions

- ``compile_join_on`` — normalize structured ``on`` and compile to predicate SQL
- ``JoinSpec.resolve`` in ``vulcan/core/model/semantic.py`` — load-time join resolution
- ``collect_source_dimensions`` / ``collect_target_dimensions`` — dimension sets for tooling

See also ``JoinSpec`` in ``vulcan/core/model/semantic.py`` and ``JoinDetail`` in
``schema/metadata.py``.
"""

from __future__ import annotations

import typing as t

from pydantic import Field, field_validator, model_validator
from pydantic.functional_validators import BeforeValidator

from schema import _PydanticModel
from schema.types import NamingError, _validate_name


# ---------------------------------------------------------------------------
# Name validation helpers
# ---------------------------------------------------------------------------


def _validate_dimension_name(value: str, *, context: str) -> str:
    """Apply shared semantic naming rules to a join ``on`` leaf or pair field."""
    return _validate_name(value, context=context)


def _validate_pair_list(value: object) -> list[str]:
    """
    Coerce YAML ``[source, target]`` list input before ``JoinOnPair`` construction.

    Authors must use block list syntax in YAML; inline flow lists are rejected here.
    """
    if not isinstance(value, list) or len(value) != 2:
        raise ValueError("join on pair must be a two-item list")
    return [
        _validate_dimension_name(str(value[0]), context="join on pair source"),
        _validate_dimension_name(str(value[1]), context="join on pair target"),
    ]


# Wire type for a two-item YAML list before it becomes JoinOnPair.
JoinOnPairInput = t.Annotated[list[str], BeforeValidator(_validate_pair_list)]


# ---------------------------------------------------------------------------
# Structured ``on`` AST (normalized in memory after load)
# ---------------------------------------------------------------------------


class JoinOnPair(_PydanticModel):
    """Asymmetric equi-join: one source dimension maps to a differently named target dimension."""

    source: str
    target: str

    @field_validator("source", "target")
    @classmethod
    def _validate_fields(cls, value: str) -> str:
        return _validate_dimension_name(value, context="join on pair")


class JoinOnGroup(_PydanticModel):
    """
    Boolean group node: exactly one of ``and`` or ``or``, each holding child leaves.

    After normalization the tree root is always a ``JoinOnGroup`` (even for a single
    scalar ``on: user_id`` — that becomes ``and: [user_id]``).
    """

    and_: list["JoinOnNode"] | None = Field(default=None, alias="and")
    or_: list["JoinOnNode"] | None = Field(default=None, alias="or")

    @field_validator("and_", "or_", mode="before")
    @classmethod
    def _coerce_children(cls, value: object) -> object:
        # Recursively normalize each list item while YAML is still loose dicts/lists.
        if value is None:
            return None
        if not isinstance(value, list):
            raise ValueError("join on group children must be a list")
        return [_normalize_on_item(item) for item in value]

    @model_validator(mode="after")
    def _validate_group(self) -> JoinOnGroup:
        if bool(self.and_) == bool(self.or_):
            raise ValueError("join on requires exactly one of 'and' or 'or'")
        children = self.and_ or self.or_ or []
        if not children:
            raise ValueError("'and'/'or' must contain at least one item")
        return self


# Author-facing shapes (YAML can still be str | list | dict).
JoinOnItem = t.Union[str, JoinOnPairInput, JoinOnGroup]
JoinOnInput = t.Union[str, list[JoinOnItem], JoinOnGroup]

# Normalized in-memory node after _normalize_on_item.
JoinOnNode = t.Union[str, JoinOnPair, JoinOnGroup]

# Normalized tree root — always a JoinOnGroup with one boolean operator.
JoinOnTree = JoinOnGroup

# Union accepted by compile_join_on (wire input or already-normalized tree).
JoinOn = JoinOnInput | JoinOnTree


# ---------------------------------------------------------------------------
# Normalization: YAML -> JoinOnTree
# ---------------------------------------------------------------------------


def _normalize_on_item(item: JoinOnItem | JoinOnNode) -> JoinOnNode:
    """
    Normalize one ``on`` list entry to a leaf string, ``JoinOnPair``, or nested group.

    Args:
        item: Scalar dimension name, pair list, group dict, or already-built node.

    Returns:
        A normalized node ready to hang under a ``JoinOnGroup``.
    """
    if isinstance(item, str):
        _validate_dimension_name(item, context="join on")
        return item
    if isinstance(item, dict):
        return JoinOnGroup.model_validate(item)
    if isinstance(item, JoinOnPair):
        return item
    if isinstance(item, list):
        source, target = item
        return JoinOnPair(source=source, target=target)
    if isinstance(item, JoinOnGroup):
        # Re-walk children so nested groups are fully normalized.
        if item.and_:
            return JoinOnGroup(and_=[_normalize_on_item(child) for child in item.and_])
        return JoinOnGroup(or_=[_normalize_on_item(child) for child in item.or_ or []])
    raise ValueError(f"invalid join on item: {item!r}")


def _normalize_on(raw: JoinOnInput | JoinOnTree) -> JoinOnTree:
    """
    Normalize any author ``on`` root form to a single ``JoinOnTree``.

    Scalar ``user_id`` becomes ``and: [user_id]``. Bare lists become implicit AND.
    Explicit ``and`` / ``or`` maps become nested ``JoinOnGroup`` nodes.
    """
    if isinstance(raw, str):
        _validate_dimension_name(raw, context="join on")
        return JoinOnGroup(and_=[raw])
    if isinstance(raw, list):
        return JoinOnGroup(and_=[_normalize_on_item(item) for item in raw])
    if isinstance(raw, dict):
        return JoinOnGroup.model_validate(raw)
    if isinstance(raw, JoinOnGroup):
        if raw.and_:
            return JoinOnGroup(and_=[_normalize_on_item(item) for item in raw.and_])
        return JoinOnGroup(or_=[_normalize_on_item(item) for item in raw.or_ or []])
    raise ValueError(f"invalid join on root: {raw!r}")


# ---------------------------------------------------------------------------
# Compilation: JoinOnTree -> predicate SQL
# ---------------------------------------------------------------------------


def _compile_on_node(
    node: JoinOnNode,
    *,
    source_model: str,
    target_model: str,
    parent: str | None = None,
) -> str:
    """
    Recursively render one tree node as equi-join predicate SQL.

    Leaf strings compile to ``{source.col} = {target.col}``. Parentheses are added
    when AND sits under OR (or OR under AND) so operator precedence stays correct.
    """
    if isinstance(node, str):
        return f"{{{source_model}.{node}}} = {{{target_model}.{node}}}"
    if isinstance(node, JoinOnPair):
        return f"{{{source_model}.{node.source}}} = {{{target_model}.{node.target}}}"
    if node.and_:
        parts = [
            _compile_on_node(child, source_model=source_model, target_model=target_model, parent="and")
            for child in node.and_
        ]
        joined = " AND ".join(parts)
        # OR group containing multiple AND branches needs explicit grouping.
        if parent == "or" and len(parts) > 1:
            joined = f"({joined})"
        return joined
    parts = [
        _compile_on_node(child, source_model=source_model, target_model=target_model, parent="or")
        for child in node.or_ or []
    ]
    joined = " OR ".join(parts)
    # AND group containing multiple OR branches needs explicit grouping.
    if parent == "and" and len(parts) > 1:
        joined = f"({joined})"
    return joined


def compile_join_on(
    on: JoinOn,
    *,
    source_model: str,
    target_model: str,
) -> tuple[JoinOnTree, str]:
    """
    Normalize structured join ``on`` input and compile to predicate SQL.

    Args:
        on: Author ``on`` YAML (scalar, list, or boolean tree).
        source_model: Declaring semantic model name (join source).
        target_model: Join target semantic model name.

    Returns:
        Normalized ``JoinOnTree`` and compiled ``{source.col} = {target.col}`` expression.
    """
    tree = _normalize_on(on)
    expression = _compile_on_node(tree, source_model=source_model, target_model=target_model)
    return tree, expression


# ---------------------------------------------------------------------------
# Dimension collection (metadata and tooling)
# ---------------------------------------------------------------------------


def _walk_on_nodes(tree: JoinOnTree) -> t.Iterable[JoinOnNode]:
    """Depth-first walk of group nodes and their leaves (includes the root group)."""
    yield tree
    children = tree.and_ or tree.or_ or []
    for child in children:
        if isinstance(child, JoinOnGroup):
            yield from _walk_on_nodes(child)
        else:
            yield child


def collect_source_dimensions(tree: JoinOnTree) -> set[str]:
    """
    Collect dimension names referenced on the declaring (source) side of the join tree.

    Symmetric leaves contribute one name; ``JoinOnPair`` leaves contribute ``source`` only.
    """
    out: set[str] = set()
    for node in _walk_on_nodes(tree):
        if isinstance(node, str):
            out.add(node)
        elif isinstance(node, JoinOnPair):
            out.add(node.source)
    return out


def collect_target_dimensions(tree: JoinOnTree) -> set[str]:
    """
    Collect dimension names referenced on the join target side of the tree.

    Symmetric leaves contribute one name; ``JoinOnPair`` leaves contribute ``target`` only.
    """
    out: set[str] = set()
    for node in _walk_on_nodes(tree):
        if isinstance(node, str):
            out.add(node)
        elif isinstance(node, JoinOnPair):
            out.add(node.target)
    return out
