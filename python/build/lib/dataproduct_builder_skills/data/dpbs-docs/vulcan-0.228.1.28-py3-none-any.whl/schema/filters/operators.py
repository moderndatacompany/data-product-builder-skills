from __future__ import annotations

import re
import typing as t
from enum import Enum


MEMBER_PATTERN = re.compile(r"^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+$")
DIMENSION_PATTERN = re.compile(r"^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+(\.[a-zA-Z0-9_]+)?$")
POLICY_FIELD_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$")
GROUP_PATTERN = re.compile(r"^[a-z][a-z0-9_]{0,63}$")


class FilterOperator(str, Enum):
    EQUALS = "equals"
    NOT_EQUALS = "notEquals"
    CONTAINS = "contains"
    NOT_CONTAINS = "notContains"
    STARTS_WITH = "startsWith"
    NOT_STARTS_WITH = "notStartsWith"
    ENDS_WITH = "endsWith"
    NOT_ENDS_WITH = "notEndsWith"
    IN = "in"
    NOT_IN = "notIn"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    SET = "set"
    NOT_SET = "notSet"
    IN_DATE_RANGE = "inDateRange"
    NOT_IN_DATE_RANGE = "notInDateRange"
    ON_THE_DATE = "onTheDate"
    BEFORE_DATE = "beforeDate"
    BEFORE_OR_ON_DATE = "beforeOrOnDate"
    AFTER_DATE = "afterDate"
    AFTER_OR_ON_DATE = "afterOrOnDate"
    MEASURE_FILTER = "measureFilter"


RestFilterOperator = FilterOperator

_OPERATORS_WITHOUT_VALUES = frozenset(
    {
        FilterOperator.SET,
        FilterOperator.NOT_SET,
        FilterOperator.MEASURE_FILTER,
    }
)

POLICY_FILTER_OPERATORS = frozenset(FilterOperator) - {
    FilterOperator.MEASURE_FILTER,
}

_OPERATORS_WITH_ONE_VALUE = frozenset(
    {
        FilterOperator.GT,
        FilterOperator.GTE,
        FilterOperator.LT,
        FilterOperator.LTE,
        FilterOperator.CONTAINS,
        FilterOperator.NOT_CONTAINS,
        FilterOperator.STARTS_WITH,
        FilterOperator.NOT_STARTS_WITH,
        FilterOperator.ENDS_WITH,
        FilterOperator.NOT_ENDS_WITH,
        FilterOperator.ON_THE_DATE,
        FilterOperator.BEFORE_DATE,
        FilterOperator.BEFORE_OR_ON_DATE,
        FilterOperator.AFTER_DATE,
        FilterOperator.AFTER_OR_ON_DATE,
    }
)

_OPERATORS_WITH_DATE_RANGE_VALUES = frozenset(
    {
        FilterOperator.IN_DATE_RANGE,
        FilterOperator.NOT_IN_DATE_RANGE,
    }
)

_OPERATOR_PHRASES: dict[FilterOperator, str] = {
    FilterOperator.EQUALS: "is",
    FilterOperator.NOT_EQUALS: "is not",
    FilterOperator.IN: "is in",
    FilterOperator.NOT_IN: "is not in",
    FilterOperator.CONTAINS: "contains",
    FilterOperator.NOT_CONTAINS: "does not contain",
    FilterOperator.STARTS_WITH: "starts with",
    FilterOperator.NOT_STARTS_WITH: "does not start with",
    FilterOperator.ENDS_WITH: "ends with",
    FilterOperator.NOT_ENDS_WITH: "does not end with",
    FilterOperator.GT: "is greater than",
    FilterOperator.GTE: "is at least",
    FilterOperator.LT: "is less than",
    FilterOperator.LTE: "is at most",
    FilterOperator.SET: "is set",
    FilterOperator.NOT_SET: "is not set",
    FilterOperator.IN_DATE_RANGE: "is between",
    FilterOperator.NOT_IN_DATE_RANGE: "is not between",
    FilterOperator.ON_THE_DATE: "is on",
    FilterOperator.BEFORE_DATE: "is before",
    FilterOperator.BEFORE_OR_ON_DATE: "is on or before",
    FilterOperator.AFTER_DATE: "is after",
    FilterOperator.AFTER_OR_ON_DATE: "is on or after",
    FilterOperator.MEASURE_FILTER: "uses built-in filter",
}

FilterValue = t.Union[str, int, float, bool, None]
RestFilterValue = FilterValue


def validate_qualified_member(value: str) -> str:
    if not MEMBER_PATTERN.match(value):
        raise ValueError(f"invalid member format: {value!r}")
    return value


def validate_qualified_dimension(value: str) -> str:
    if not DIMENSION_PATTERN.match(value):
        raise ValueError(f"invalid dimension format: {value!r}")
    return value


def validate_policy_field(value: str) -> str:
    if not POLICY_FIELD_PATTERN.match(value):
        raise ValueError(f"invalid policy filter field: {value!r}")
    return value


def validate_policy_group(value: str) -> str:
    group = value.strip()
    if not GROUP_PATTERN.match(group):
        raise ValueError(f"invalid policy group: {group!r}")
    return group


def validate_operator_values(*, operator: FilterOperator, values: list[FilterValue] | None) -> None:
    if operator in _OPERATORS_WITHOUT_VALUES:
        if values is not None:
            raise ValueError(f"operator '{operator.value}' must not include values")
        return
    if not values:
        raise ValueError(f"operator '{operator.value}' requires values")
    if operator in _OPERATORS_WITH_ONE_VALUE and len(values) != 1:
        raise ValueError(f"operator '{operator.value}' requires exactly one value")
    if operator in _OPERATORS_WITH_DATE_RANGE_VALUES and len(values) > 2:
        raise ValueError(f"operator '{operator.value}' accepts at most two values")
