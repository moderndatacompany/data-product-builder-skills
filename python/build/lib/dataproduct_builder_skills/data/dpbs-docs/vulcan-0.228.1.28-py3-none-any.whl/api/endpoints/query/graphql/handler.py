from __future__ import annotations
_H='timezone'
_G='Request failed'
_F='original_error'
_E='message'
_D='errors'
_C='data'
_B=True
_A=None
import asyncio,json,logging,time,typing as t
from dataclasses import dataclass,field
from fastapi import HTTPException,Request
from graphql import GraphQLError,GraphQLResolveInfo,graphql
from pgqueuer import QueueManager
from starlette import status
from api.context import EnvContext
from api.endpoints.query.graphql.format import build_result_annotation,columnar_to_rows,missing_result_columns,nest_table_rows,format_row_dates_in_place
from api.endpoints.query.graphql.query import get_json_query_from_info,uncapitalize
from api.endpoints.query.graphql.schema import GraphQLArtifacts
from api.pool import run_blocking_heavy
from api.query.results import staleness_headers,to_json
from api.query.submit import make_statement_links,submit_sql_via_flow
from api.query.transpile import get_filtered_request_headers,transpile_or_http_error
from api.schemas.query import GraphQLExecutionExtensions,GraphQLPendingExtensions,QueryType
from api.state import AsyncStateClient
from api.utils.commons import timestamp_to_iso
from schema.auth import SecurityContext
from schema.rest_query import RestQuery
from api.config import Settings,get_settings
from vulcan.core.query import ObjectStoreClient
from vulcan.core.query.definitions import QueryPolicyAudit,QueryStatus,QueryStrategy
logger=logging.getLogger(__name__)
_GRAPHQL_SERVER_META:dict[str,str]={'graphql_engine':'in_process','graphql_route':'semantic/graphql'}
def serialize_graphql_request_body(query:str,variables:dict[str,t.Any]|_A=_A,operation_name:str|_A=_A)->str:
	payload:dict[str,t.Any]={'query':query}
	if variables:payload['variables']=variables
	if operation_name:payload['operationName']=operation_name
	return json.dumps(payload,separators=(',',':'),sort_keys=_B)
@dataclass(frozen=_B,slots=_B)
class GraphQLExecutionSettings:
	poll_interval_ms:int;poll_timeout_ms:int;retry_after_seconds:int;default_timezone:str|_A
	@classmethod
	def from_settings(cls,settings:Settings)->GraphQLExecutionSettings:return cls(poll_interval_ms=settings.graphql_poll_interval_ms,poll_timeout_ms=settings.graphql_poll_timeout_ms,retry_after_seconds=settings.graphql_retry_after_seconds,default_timezone=settings.graphql_default_timezone)
ExecuteResult=tuple[dict[str,t.Any],int,dict[str,str]]
class GraphQLExecutionError(Exception):
	def __init__(self,message:str,*,status_code:int=500,is_timeout:bool=False,extensions:dict[str,t.Any]|_A=_A,missing_errors:list[dict[str,t.Any]]|_A=_A)->_A:super().__init__(message);self.status_code=status_code;self.is_timeout=is_timeout;self.extensions=extensions or{};self.missing_errors=missing_errors
def is_client_graphql_error(error:GraphQLError)->bool:msg=error.message or'';return any(token in msg for token in('Cannot query field','Syntax Error','Unknown argument','Unknown type','Expected type','must be a string','must have a selection of subfields',"Field '",'Unknown fragment'))
def error_message(error:GraphQLError)->str:
	original=getattr(error,_F,_A)
	if isinstance(original,GraphQLExecutionError):return str(original)
	if isinstance(original,HTTPException):
		detail=original.detail
		if isinstance(detail,str):return detail
		return str(detail)
	return error.message or _G
def _validation_error_payload(errors:t.Sequence[GraphQLError],data:t.Any)->dict[str,t.Any]:
	payload:dict[str,t.Any]={_D:[{_E:error_message(err)}for err in errors]}
	if data is not _A:payload[_C]=data
	return payload
@dataclass(slots=_B)
class GraphQLRequestContext:
	artifacts:GraphQLArtifacts;env_ctx:EnvContext;settings:GraphQLExecutionSettings;request:Request;user:dict[str,t.Any];state:AsyncStateClient;qm:QueueManager;object_store:ObjectStoreClient;gateway:str|_A;retry_on_recent_failure:bool;query:str;variables:dict[str,t.Any]|_A;operation_name:str|_A;response_headers:dict[str,str]=field(default_factory=dict);response_extensions:dict[str,t.Any]=field(default_factory=dict)
	async def load_table(self,info:GraphQLResolveInfo,args:dict[str,t.Any])->list[dict[str,t.Any]]:
		B='user_id';A='Authorization'
		if not self.artifacts.queryables:raise GraphQLExecutionError('Semantic catalog has no queryable models for GraphQL',status_code=500)
		try:payload=get_json_query_from_info(self.artifacts.queryables,args,info);payload.setdefault(_H,'UTC');payload.setdefault('order',{});rest_query=RestQuery.model_validate(payload)
		except ValueError as exc:raise GraphQLExecutionError(str(exc),status_code=400)from exc
		exec_gateway=self.env_ctx.gateway(self.gateway);auth_headers={A:auth}if(auth:=self.request.headers.get(A))else _A
		try:transpiler_response=await transpile_or_http_error(rest_query,invalid_msg='Invalid REST semantic query',disable_post_processing=_B,user=self.user[B],security_context=SecurityContext.from_dict(self.user['security_context']),env_ctx=self.env_ctx,gateway=exec_gateway,auth_headers=auth_headers)
		except HTTPException as exc:detail=exc.detail if isinstance(exc.detail,str)else str(exc.detail);status_code=exc.status_code if 400<=exc.status_code<600 else 500;raise GraphQLExecutionError(detail,status_code=status_code)from exc
		policy=QueryPolicyAudit.from_semantic_query_context(transpiler_response.context)if transpiler_response.context is not _A else _A;accepted=await submit_sql_via_flow(sql=transpiler_response.wrapped_sql_statement,params=transpiler_response.sql_params,ttl=0,request_meta=_A,headers_meta=get_filtered_request_headers(self.request),server_meta=dict(_GRAPHQL_SERVER_META),gateway=exec_gateway,qm=self.qm,query_state=self.state.query,env_ctx=self.env_ctx,retry_on_recent_failure=self.retry_on_recent_failure,query_type=QueryType.SEMANTIC_GRAPHQL,rest_query=rest_query,graphql_query=serialize_graphql_request_body(self.query,self.variables,self.operation_name),submitted_by=self.user[B],policy=policy);flat_rows,annotation,query_timezone=await _poll_statement_result(statement_id=accepted.id,state=self.state,object_store=self.object_store,env_ctx=self.env_ctx,poll_interval_ms=self.settings.poll_interval_ms,poll_timeout_ms=self.settings.poll_timeout_ms);format_row_dates_in_place(flat_rows,annotation,query_timezone,fallback_timezone=_A,default_timezone=self.settings.default_timezone);missing=missing_result_columns(rest_query,annotation)
		if missing:errors=[{_E:f"Column '{column}' was not returned by the query",'path':['table',*uncapitalize(column).split('.')]}for column in missing];raise GraphQLExecutionError('Missing result columns',status_code=200,missing_errors=errors)
		is_stale=accepted.is_stale;primary_request_id=accepted.primary.request_id if accepted.primary is not _A else _A;self.response_extensions.update(GraphQLExecutionExtensions.from_statement_accepted(accepted,is_stale=is_stale,links=make_statement_links(request_id=accepted.id,primary_request_id=primary_request_id,include_result=_B)).model_dump(mode='json',exclude_none=_B));self.response_headers.update(staleness_headers(is_stale=is_stale));return nest_table_rows(flat_rows,annotation)
async def resolve_table(_root:t.Any,info:GraphQLResolveInfo,**args:t.Any)->list[dict[str,t.Any]]:
	ctx=info.context;load_table=getattr(ctx,'load_table',_A)
	if not callable(load_table):raise GraphQLExecutionError('GraphQL request context is unavailable',status_code=500)
	return await load_table(info,args)
async def _load_statement_rows(*,statement_id:str,state:AsyncStateClient,object_store:ObjectStoreClient)->tuple[list[dict[str,t.Any]],dict[str,dict[str,dict[str,str]]],str|_A]:
	C='type';B='name';A='Query succeeded but result metadata is missing';ctx=await state.query.get_statement_context(statement_id)
	if ctx is _A:raise GraphQLExecutionError(f"Statement '{statement_id}' not found",status_code=404)
	req=ctx.request;result_ctx=ctx
	if req.strategy==QueryStrategy.AWAIT_PRIMARY and ctx.primary_request is not _A:
		primary_ctx=await state.query.get_statement_context(ctx.primary_request.request_id)
		if primary_ctx is _A or primary_ctx.result is _A:raise GraphQLExecutionError(A,status_code=500)
		result_ctx=primary_ctx
	elif req.strategy==QueryStrategy.REUSE_RESULT:
		if ctx.result is _A:raise GraphQLExecutionError(A,status_code=500)
	elif ctx.result is _A:raise GraphQLExecutionError(A,status_code=500)
	df=await run_blocking_heavy(object_store.get_result,result_ctx.result.result_id);statement_result=to_json(df,result_ctx.result.columns or[],statement_id);flat_rows=columnar_to_rows(statement_result.cols,statement_result.rows);annotation=build_result_annotation([{B:col[B],C:col[C]}for col in statement_result.types]);timezone=_A
	if req.rest_query and isinstance(req.rest_query,dict):timezone=req.rest_query.get(_H)
	return flat_rows,annotation,timezone
async def _poll_statement_result(*,statement_id:str,state:AsyncStateClient,object_store:ObjectStoreClient,env_ctx:EnvContext,poll_interval_ms:int,poll_timeout_ms:int)->tuple[list[dict[str,t.Any]],dict[str,dict[str,dict[str,str]]],str|_A]:
	A='Query execution failed';polling_start=time.monotonic();poll_count=0;last_status:QueryStatus|_A=_A
	while(time.monotonic()-polling_start)*1000<poll_timeout_ms:
		if poll_count:await asyncio.sleep(poll_interval_ms/1000)
		poll_count+=1;ctx=await state.query.get_statement_context(statement_id)
		if ctx is _A:raise GraphQLExecutionError(f"Statement '{statement_id}' not found",status_code=404)
		req=ctx.request
		if req.strategy==QueryStrategy.AWAIT_PRIMARY and ctx.primary_request is not _A:status_value=ctx.primary_request.execution_status
		elif req.strategy==QueryStrategy.REUSE_RESULT:status_value=QueryStatus.SUCCESS
		else:status_value=req.execution_status
		last_status=status_value
		if status_value==QueryStatus.SUCCESS:return await _load_statement_rows(statement_id=statement_id,state=state,object_store=object_store)
		if status_value==QueryStatus.FAILED:error_message_text=req.error_message or A;raise GraphQLExecutionError(f"Query Execution Error: {error_message_text}",status_code=400)
	try:
		ctx=await state.query.get_statement_context(statement_id)
		if ctx is not _A:
			if ctx.request.strategy==QueryStrategy.AWAIT_PRIMARY and ctx.primary_request:last_status=ctx.primary_request.execution_status
			elif ctx.request.strategy==QueryStrategy.REUSE_RESULT:last_status=QueryStatus.SUCCESS
			else:last_status=ctx.request.execution_status
			if last_status==QueryStatus.SUCCESS:return await _load_statement_rows(statement_id=statement_id,state=state,object_store=object_store)
			if last_status==QueryStatus.FAILED:error_message_text=ctx.request.error_message or A;raise GraphQLExecutionError(f"Query Execution Error: {error_message_text}",status_code=400)
	except GraphQLExecutionError:raise
	except Exception:logger.warning('Final GraphQL poll failed for statement %s',statement_id,exc_info=_B)
	last_ctx=await state.query.get_statement_context(statement_id);depends_on=list(last_ctx.request.depends_on or[])if last_ctx is not _A else[];is_stale=env_ctx.models_have_missing_intervals(depends_on);pending_extensions=GraphQLPendingExtensions(statement_id=statement_id,status=last_status or QueryStatus.IN_PROGRESS,message='Query still processing, please retry after some time.',fingerprint=last_ctx.request.fingerprint if last_ctx is not _A else _A,submitted_at=timestamp_to_iso(last_ctx.request.submitted_ts)if last_ctx is not _A else _A,is_stale=is_stale,links=make_statement_links(request_id=statement_id)if last_ctx is not _A else _A);raise GraphQLExecutionError('Query processing timeout',status_code=202,is_timeout=_B,extensions=pending_extensions.model_dump(mode='json',exclude_none=_B))
def _graphql_result_to_http_response(result:t.Any,*,settings:GraphQLExecutionSettings,response_headers:dict[str,str]|_A=_A,response_extensions:dict[str,t.Any]|_A=_A)->ExecuteResult:
	A='extensions';extra_headers=dict(response_headers or{});extra_extensions=dict(response_extensions or{})
	if result.errors:
		first=result.errors[0];original=getattr(first,_F,_A)
		if isinstance(original,GraphQLExecutionError):
			if original.is_timeout:
				headers={'Retry-After':str(max(1,settings.retry_after_seconds))}
				if original.extensions.get('is_stale'):headers.update(staleness_headers(is_stale=_B))
				return{_C:_A,A:original.extensions},status.HTTP_202_ACCEPTED,headers
			if original.missing_errors:return{_C:_A,_D:original.missing_errors},status.HTTP_200_OK,extra_headers
			return{_C:result.data,_D:[{_E:str(original)}]},original.status_code,extra_headers
		if isinstance(original,HTTPException):detail=original.detail if isinstance(original.detail,str)else json.dumps(original.detail);status_code=original.status_code if 400<=original.status_code<600 else 500;return{_C:result.data,_D:[{_E:detail}]},status_code,{}
		status_code=400 if is_client_graphql_error(first)else 500
		if original is not _A:
			code=getattr(original,'status_code',_A)
			if isinstance(code,int)and 400<=code<600:status_code=code
		return _validation_error_payload(result.errors,result.data),status_code,extra_headers
	payload:dict[str,t.Any]={_C:result.data}
	if extra_extensions:payload[A]=extra_extensions
	return payload,status.HTTP_200_OK,extra_headers
async def execute(*,query:str,variables:dict[str,t.Any]|_A,operation_name:str|_A,artifacts:GraphQLArtifacts,env_ctx:EnvContext,request:Request,user:dict[str,t.Any],state:AsyncStateClient,qm:QueueManager,object_store:ObjectStoreClient,retry_on_recent_failure:bool=False,gateway:str|_A=_A)->ExecuteResult:
	A='error'
	if artifacts.schema is _A:return{A:'GraphQL schema is unavailable for this environment'},status.HTTP_500_INTERNAL_SERVER_ERROR,{}
	ctx=GraphQLRequestContext(artifacts=artifacts,env_ctx=env_ctx,settings=GraphQLExecutionSettings.from_settings(get_settings()),request=request,user=user,state=state,qm=qm,object_store=object_store,gateway=gateway,retry_on_recent_failure=retry_on_recent_failure,query=query,variables=variables,operation_name=operation_name)
	try:result=await graphql(schema=artifacts.schema,source=query,variable_values=variables,operation_name=operation_name,context_value=ctx);return _graphql_result_to_http_response(result,settings=ctx.settings,response_headers=ctx.response_headers,response_extensions=ctx.response_extensions)
	except Exception as exc:logger.exception('Unexpected GraphQL execution error');return{A:str(exc)or _G},status.HTTP_500_INTERNAL_SERVER_ERROR,{}