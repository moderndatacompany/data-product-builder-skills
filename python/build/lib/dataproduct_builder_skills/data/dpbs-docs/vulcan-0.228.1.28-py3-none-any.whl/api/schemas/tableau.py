from __future__ import annotations
_B='published'
_A=None
import typing as t
from pydantic import SecretStr,model_validator
from pydantic import Field as PydanticField
from vulcan.utils.pydantic import PydanticModel
class TableauPublishRequest(PydanticModel):
	server_address:str=PydanticField(min_length=1,description='Tableau server URL (e.g. https://10ax.online.tableau.com)');site_id:str=PydanticField(default='',description='Tableau site content URL (empty for default site)');project_name:t.Optional[str]=PydanticField(default=_A,description='Target project (created if missing; defaults to product key)');username:t.Optional[str]=PydanticField(default=_A,description='Tableau username (username/password auth)');password:t.Optional[SecretStr]=PydanticField(default=_A,description='Tableau password (username/password auth)');token_name:t.Optional[str]=PydanticField(default=_A,description='Personal access token name (PAT auth)');personal_access_token:t.Optional[SecretStr]=PydanticField(default=_A,description='Personal access token secret (PAT auth)')
	@model_validator(mode='after')
	def _validate_auth(self)->TableauPublishRequest:
		has_pat=bool(self.token_name)and self.personal_access_token is not _A;has_user_pass=bool(self.username)and self.password is not _A
		if not(has_pat or has_user_pass):raise ValueError("Provide either 'token_name' and 'personal_access_token', or 'username' and 'password'.")
		return self
class TableauPublishResponse(PydanticModel):server_address:str=PydanticField(description='Tableau server published to');site_id:str=PydanticField(description='Tableau site content URL used');project_name:str=PydanticField(description='Tableau project published into');datasource:str=PydanticField(description='Published data source name');id:t.Optional[str]=PydanticField(default=_A,description='Tableau data source ID');status:t.Literal[_B]=PydanticField(default=_B,description='Publish status (always published on success)')