from __future__ import annotations
_A=None
import typing as t
from pydantic import Field as PydanticField
from schema.filters import RestFilterExpression
from schema.rest_query import RestOrder
from schema.types import MetricGranularityValue
from vulcan.utils.pydantic import PydanticModel
class MetricQueryRequest(PydanticModel):dimensions:t.Optional[t.List[str]]=PydanticField(default=_A,description='Metric dimension aliases to return');granularity:t.Optional[MetricGranularityValue]=PydanticField(default=_A,description='Time granularity for the metric time dimension');timezone:t.Optional[str]=PydanticField(default=_A,description='Timezone for time bucketing (default UTC)');filters:t.Optional[t.List[RestFilterExpression]]=PydanticField(default=_A,description='Ad-hoc REST filters applied to the query');order:t.Optional[RestOrder]=PydanticField(default=_A,description='Qualified RestQuery ordering by the metric time dimension or selected dimensions');limit:int=PydanticField(default=10000,ge=1,le=50000,description='Maximum rows to return');offset:int=PydanticField(default=0,ge=0,description='Rows to skip before returning results');model_config={'extra':'ignore'}