from __future__ import annotations
_C='request'
_B='asyncio.Future[t.Any]'
_A=None
import asyncio,functools,hashlib,inspect,json,logging,typing as t
from enum import Enum
from fastapi import Request
from api.cache.storage import LRUCacheStorage,_MISSING,_cache_storage
from api.dependencies import get_env_context_manager,get_environment
logger=logging.getLogger(__name__)
_inflight:t.Dict[str,_B]={}
_inflight_lock:t.Optional[asyncio.Lock]=_A
def _get_inflight_lock()->asyncio.Lock:
	global _inflight_lock
	if _inflight_lock is _A:_inflight_lock=asyncio.Lock()
	return _inflight_lock
class CachePolicy(str,Enum):PLAN_CHANGE='plan_change';RUN_CHANGE='run_change';TTL='ttl';LRU_ONLY='lru_only'
CACHE_KEY_NAMESPACE='cache'
CACHE_KEY_VERSION='v1'
def _normalized_cache_environment(environment:str|_A)->str:return environment or'default'
def _cache_key_head(policy:CachePolicy,environment:str|_A)->list[str]:return[CACHE_KEY_NAMESPACE,CACHE_KEY_VERSION,policy.value,_normalized_cache_environment(environment)]
def cache_key_prefix(policy:CachePolicy,environment:str|_A)->str:return':'.join(_cache_key_head(policy,environment))+':'
def _change_counters_for_policy(manager:t.Any,environment:str,policy:CachePolicy)->tuple[int|_A,int|_A]:
	if policy==CachePolicy.PLAN_CHANGE:return manager.get_plan_change_counter(environment),_A
	if policy==CachePolicy.RUN_CHANGE:return _A,manager.get_run_change_counter(environment)
	return _A,_A
def _change_counter_segment(policy:CachePolicy,plan_change_counter:int|_A,run_change_counter:int|_A)->str|_A:
	if policy==CachePolicy.PLAN_CHANGE:return str(plan_change_counter or 0)
	if policy==CachePolicy.RUN_CHANGE:return str(run_change_counter or 0)
def _extract_cache_params(kwargs:dict,key_params:t.List[str]|_A)->t.Dict[str,t.Any]:
	if key_params:return{name:kwargs[name]for name in key_params if name in kwargs}
	return{k:v for(k,v)in kwargs.items()if k!=_C and not isinstance(v,Request)}
def _log_cache_lookup(cache_key:str,is_hit:bool)->_A:logger.info('[cache] status=%s key=%s','HIT'if is_hit else'MISS',cache_key)
def _bind_cache_request_state(request:Request,policy:CachePolicy,cache_key:str,is_hit:bool)->_A:request.state.cache_policy=policy.value.upper();request.state.cache_key=cache_key;request.state.cache_status='HIT'if is_hit else'MISS';_log_cache_lookup(cache_key,is_hit)
def _make_cache_key(policy:CachePolicy,endpoint_path:str,environment:str|_A,plan_change_counter:int|_A,run_change_counter:int|_A,params:t.Dict[str,t.Any])->str:
	params_str=json.dumps(params,sort_keys=True,default=str);params_hash=hashlib.md5(params_str.encode()).hexdigest()[:8];parts=_cache_key_head(policy,environment);counter_segment=_change_counter_segment(policy,plan_change_counter,run_change_counter)
	if counter_segment is not _A:parts.extend([counter_segment,endpoint_path,params_hash])
	else:parts.extend([endpoint_path,params_hash])
	return':'.join(parts)
def _extract_request(*args,**kwargs)->Request|_A:
	request:Request|_A=kwargs.get(_C)
	if not request:
		for arg in args:
			if isinstance(arg,Request):return arg
	return request
def _build_cache_key_and_check(request:Request,policy:CachePolicy,key_params:t.List[str]|_A,kwargs:dict,func_name:str,ttl:t.Optional[float]=_A)->tuple[str,t.Any]|_A:
	try:manager=get_env_context_manager(request);environment=get_environment(request)
	except Exception as e:logger.warning('Cache decorator on %s failed to get manager/environment: %s, skipping cache',func_name,e);return
	plan_change_counter,run_change_counter=_change_counters_for_policy(manager,environment,policy);cache_key=_make_cache_key(policy=policy,endpoint_path=request.url.path,environment=environment,plan_change_counter=plan_change_counter,run_change_counter=run_change_counter,params=_extract_cache_params(kwargs,key_params));cached_value=_cache_storage.get(cache_key,ttl=ttl);return cache_key,cached_value
async def _await_or_compute_singleflight(cache_key:str,ttl:t.Optional[float],compute:t.Callable[[],t.Awaitable[t.Any]])->t.Any:
	loop=asyncio.get_running_loop();lock=_get_inflight_lock()
	async with lock:
		pending=_inflight.get(cache_key)
		if pending is _A:future:_B=loop.create_future();_inflight[cache_key]=future;is_primary=True
		else:future=pending;is_primary=False
	if not is_primary:return await future
	try:result=await compute()
	except BaseException as exc:
		async with lock:_inflight.pop(cache_key,_A)
		if not future.done():future.set_exception(exc)
		raise
	else:
		_cache_storage.set(cache_key,result,ttl=ttl)
		async with lock:_inflight.pop(cache_key,_A)
		if not future.done():future.set_result(result)
		return result
def cached(policy:CachePolicy=CachePolicy.PLAN_CHANGE,key_params:t.List[str]|_A=_A,ttl:t.Optional[float]=_A):
	if policy==CachePolicy.TTL and ttl is _A:raise ValueError('ttl parameter is required when policy=CachePolicy.TTL')
	def decorator(func):
		def _execute_with_cache(*args,**kwargs):
			request=_extract_request(*args,**kwargs)
			if not request:logger.warning('Cache decorator on %s but no Request found, skipping cache',func.__name__);return _A,_A,_A
			cache_result=_build_cache_key_and_check(request=request,policy=policy,key_params=key_params,kwargs=kwargs,func_name=func.__name__,ttl=ttl)
			if cache_result is _A:return _A,_A,_A
			cache_key,cached_value=cache_result;_bind_cache_request_state(request,policy,cache_key,cached_value is not _MISSING);return request,cache_key,cached_value
		@functools.wraps(func)
		async def async_wrapper(*args,**kwargs):
			request,cache_key,cached_value=_execute_with_cache(*args,**kwargs)
			if request is _A:return await func(*args,**kwargs)
			if cached_value is not _MISSING:return cached_value
			return await _await_or_compute_singleflight(cache_key,ttl,lambda:func(*args,**kwargs))
		@functools.wraps(func)
		def sync_wrapper(*args,**kwargs):
			request,cache_key,cached_value=_execute_with_cache(*args,**kwargs)
			if request is _A:return func(*args,**kwargs)
			if cached_value is not _MISSING:return cached_value
			result=func(*args,**kwargs);_cache_storage.set(cache_key,result,ttl=ttl);return result
		if inspect.iscoroutinefunction(func):return async_wrapper
		return sync_wrapper
	return decorator
def get_cache_storage()->LRUCacheStorage:return _cache_storage