from __future__ import annotations
_B=None
_A=True
import mimetypes,os
from pathlib import Path
from fastapi import APIRouter,Depends,HTTPException,Request
from starlette.status import HTTP_404_NOT_FOUND
from vulcan.core import constants as c
from api.config import Settings,get_settings
from api.dependencies import get_env_context
from api.context import EnvContext
from api.schemas.files import Directory,File
from api.cache import cached,CachePolicy
router=APIRouter()
def validate_path(path:str,settings:Settings,env_ctx:EnvContext)->str:
	resolved_path=settings.project_path.resolve();full_path=(resolved_path/path).resolve()
	try:full_path.relative_to(resolved_path)
	except ValueError:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail='Path outside project directory')
	ignore_patterns=env_ctx.context.config.ignore_patterns if env_ctx.context.config else c.IGNORE_PATTERNS
	if any(full_path.match(pattern)for pattern in ignore_patterns):raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail='Path matches ignore patterns')
	return path
@router.get('',summary='List project files',response_model=Directory,response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
@cached(policy=CachePolicy.PLAN_CHANGE)
def get_files(settings:Settings=Depends(get_settings),env_ctx:EnvContext=Depends(get_env_context),request:Request=_B)->Directory:return _get_directory(settings.project_path,settings,env_ctx)
@router.get('/{path:path}',summary='Get file contents',response_model=File,response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
@cached(policy=CachePolicy.PLAN_CHANGE)
def get_file(path:str,settings:Settings=Depends(get_settings),env_ctx:EnvContext=Depends(get_env_context),request:Request=_B)->File:
	validated_path=validate_path(path,settings,env_ctx)
	try:
		file_path=Path(validated_path);full_path=settings.project_path/file_path
		if full_path.is_dir():raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail='Path is a directory, use GET /files to list directories')
		try:content=full_path.read_text(encoding='utf-8')
		except FileNotFoundError:raise
		except Exception:content=_B
		file=_build_file(full_path.name,str(file_path),content=content)
	except FileNotFoundError:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail='File not found')
	return file
def _get_directory(path:str|Path,settings:Settings,env_ctx:EnvContext)->Directory:
	ignore_patterns=env_ctx.context.config.ignore_patterns if env_ctx.context.config else c.IGNORE_PATTERNS
	def walk_path(path:str|Path)->tuple[list[Directory],list[File]]:
		A=False;directories=[];files=[]
		with os.scandir(path)as entries:
			for entry in entries:
				entry_path=Path(entry.path)
				if entry.name=='__pycache__'or entry.name.startswith('.')or any(entry_path.match(pattern)for pattern in ignore_patterns):continue
				relative_path=entry_path.relative_to(settings.project_path)
				if entry.is_dir(follow_symlinks=A):_directories,_files=walk_path(entry.path);directories.append(Directory(name=entry.name,path=str(relative_path.as_posix()),directories=_directories,files=_files))
				elif entry.is_file(follow_symlinks=A):files.append(_build_file(entry.name,str(relative_path.as_posix())))
		return sorted(directories,key=lambda x:x.name),sorted(files,key=lambda x:x.name)
	directories,files=walk_path(path);relative_path=str(Path(path).relative_to(settings.project_path));return Directory(name=os.path.basename(path),path=''if relative_path=='.'else relative_path,directories=directories,files=files)
def _build_file(name:str,path:str,*,content:str|_B=_B)->File:return File(name=name,path=path,extension=Path(name).suffix,mime_type=mimetypes.guess_type(name)[0]or'application/octet-stream',content=content)