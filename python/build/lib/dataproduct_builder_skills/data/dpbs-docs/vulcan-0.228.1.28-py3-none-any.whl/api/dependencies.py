from __future__ import annotations
_A=None
import typing as t
from fastapi import HTTPException,Request
from api.config import DEFAULT_ENVIRONMENT
from api.exceptions import ApiException
from api.state import AsyncStateClient
from pgqueuer import QueueManager
from schema.auth import SecurityContext
from vulcan.core.query import ObjectStoreClient
if t.TYPE_CHECKING:from api.context import EnvContext,EnvContextManager
def get_env_context_manager(request:Request)->EnvContextManager:
	manager=getattr(request.app.state,'env_context_manager',_A)
	if manager is _A:raise ApiException(message='Environment context manager not initialized (application startup may have failed)',origin='API -> dependencies -> get_env_context_manager',status_code=503)
	return manager
def get_environment(request:Request)->str:return request.query_params.get('env')or request.headers.get('x-environment')or DEFAULT_ENVIRONMENT
def get_env_context(request:Request)->EnvContext:
	manager=get_env_context_manager(request);environment=get_environment(request)
	try:return manager.get_env_context(environment)
	except ValueError:raise ApiException(message=f"Environment '{environment}' not found. Run 'vulcan plan {environment}' to create it.",origin='API -> dependencies -> get_env_context',status_code=404)
def get_user(request:Request)->t.Dict[str,t.Any]:C='security_context';B='user_tags';A='user_id';user_id=getattr(request.state,A,_A)or'anonymous';user_tags=getattr(request.state,B,[]);raw_context=getattr(request.state,C,_A);security_context=raw_context if isinstance(raw_context,SecurityContext)else SecurityContext();return{A:user_id,B:user_tags,C:security_context.to_dict()}
def get_client_dialect(request:Request)->t.Optional[str]:return request.headers.get('x-client-dialect')
def get_object_store(request:Request)->ObjectStoreClient:
	store=getattr(request.app.state,'object_store',_A)
	if store is _A:raise HTTPException(status_code=503,detail='Object store not configured')
	return store
def get_queue_manager(request:Request)->QueueManager:
	qm=getattr(request.app.state,'qm',_A)
	if qm is _A:raise HTTPException(status_code=503,detail='QueueManager not available')
	return qm
def get_statestore_client(request:Request)->AsyncStateClient:
	statestore_client=getattr(request.app.state,'statestore_client',_A)
	if statestore_client is _A:raise ApiException(message='Async state store client not initialized (application startup may have failed)',origin='API -> dependencies -> get_statestore_client',status_code=503)
	return statestore_client