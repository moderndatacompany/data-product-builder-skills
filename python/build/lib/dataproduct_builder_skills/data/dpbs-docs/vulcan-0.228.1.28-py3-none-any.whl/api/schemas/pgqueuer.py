from __future__ import annotations
_J='Jobs in this bucket'
_I='Job priority bucket'
_H='Job status bucket'
_G='Aggregated log entry count'
_F='Exception traceback when status is exception'
_E='Job priority'
_D='Log entry time (ISO-8601)'
_C='Job ID'
_B='Worker entrypoint'
_A=None
import typing as t
from pydantic import BaseModel,Field
class JobStatusResponse(BaseModel):job_id:int=Field(...,description=_C);status:str=Field(...,description='Current status (queued, picked, successful, canceled, exception)')
class JobLogEntry(BaseModel):created:t.Optional[str]=Field(_A,description=_D);status:str=Field(...,description='Job status at this log entry');priority:int=Field(...,description=_E);entrypoint:str=Field(...,description=_B);traceback:t.Optional[dict]=Field(_A,description=_F);aggregated:t.Optional[int]=Field(_A,description=_G)
class JobHistoryResponse(BaseModel):job_id:int=Field(...,description=_C);logs:t.List[JobLogEntry]=Field(...,description='Log entries oldest to newest');count:int=Field(...,description='Number of log entries returned')
class QueueStatistic(BaseModel):entrypoint:str=Field(...,description=_B);status:str=Field(...,description=_H);priority:int=Field(...,description=_I);count:int=Field(...,description=_J)
class QueueLogEntry(BaseModel):job_id:int=Field(...,description=_C);created:t.Optional[str]=Field(_A,description=_D);status:str=Field(...,description='Job status');priority:int=Field(...,description=_E);entrypoint:str=Field(...,description=_B);traceback:t.Optional[dict]=Field(_A,description=_F);aggregated:t.Optional[int]=Field(_A,description=_G)
class LogStatistic(BaseModel):created:t.Optional[str]=Field(_A,description='Statistic snapshot time (ISO-8601)');entrypoint:str=Field(...,description=_B);status:str=Field(...,description=_H);priority:int=Field(...,description=_I);count:int=Field(...,description=_J)
class EntrypointInfo(BaseModel):name:str=Field(...,description='Entrypoint name');concurrency_limit:int=Field(...,description='Max concurrent jobs');requests_per_second:float=Field(...,description='Max job pickup rate');retry_timer_seconds:t.Optional[float]=Field(_A,description='Retry delay in seconds when configured')