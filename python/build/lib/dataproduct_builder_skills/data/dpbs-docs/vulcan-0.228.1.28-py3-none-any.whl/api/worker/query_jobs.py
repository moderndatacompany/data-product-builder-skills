from __future__ import annotations
_E='SUCCESS'
_D='status'
_C='utf-8'
_B=True
_A=None
import logging,typing as t
from contextlib import contextmanager
from datetime import datetime,timezone
from pgqueuer.models import Job
from pydantic import BaseModel,Field,field_validator
from vulcan import Context
from vulcan.core.config.pgq import PGQConfig
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.query import ObjectStoreClient
from vulcan.core.query.definitions import QueryResultLineage
from vulcan.utils import CorrelationId
from api import prometheus
from api.pool import run_blocking_heavy
from api.state.query import AsyncQueryState
from api.worker import EnqueueQueueManager,WorkerQueueManager
logger=logging.getLogger(__name__)
QUERY_EXECUTION_ENTRYPOINT='query_execution'
@contextmanager
def request_engine_adapter(context:Context,gateway:str,correlation_id:CorrelationId)->t.Iterator[EngineAdapter]:
	adapter=context.config.get_connection(gateway).create_engine_adapter().with_settings(correlation_id=correlation_id,query_history_recorder=context.query_history_recorder)
	try:yield adapter
	finally:adapter.close()
class QueryJobPayload(BaseModel):
	request_id:str;fingerprint:str;gateway:str;sql:str;params:t.Optional[t.Union[t.List[t.Any],t.Dict[str,t.Any]]]=_A;ttl_minutes:int=Field(default=0,ge=0,le=43200);depends_on:t.Optional[t.List[str]]=_A;environment:str;perspective_id:t.Optional[str]=_A;submitted_by:t.Optional[str]=_A
	@field_validator('ttl_minutes')
	@classmethod
	def validate_ttl_minutes(cls,v:int)->int:
		if v==0 or 5<=v<=43200:return v
		raise ValueError('ttl_minutes must be 0 (never expires) or between 5 and 43200 minutes')
async def enqueue_query_execution(qm:EnqueueQueueManager,payload:QueryJobPayload)->t.Optional[int]:job_ids=await qm.queries.enqueue([QUERY_EXECUTION_ENTRYPOINT],[payload.model_dump_json().encode(_C)]);return job_ids[0]if job_ids else _A
class QueryExecutor:
	def __init__(self,context:Context,query_state:AsyncQueryState,object_store:ObjectStoreClient|_A=_A):self.context=context;self.query_state=query_state;self.object_store=object_store
	def _extract_columns(self,df)->list:
		def map_dtype(dtype_str:str)->str:
			if any(x in dtype_str for x in['int','Int']):return'integer'
			if any(x in dtype_str for x in['float','Float']):return'decimal'
			if'bool'in dtype_str:return'boolean'
			if'datetime64'in dtype_str:return'timestamp'
			if'timedelta'in dtype_str:return'duration'
			return'string'
		return[{'name':col,'type':map_dtype(str(dtype))}for(col,dtype)in df.dtypes.items()]
	def _lineage(self,sql:str,result_columns:t.List[str],*,dialect:str)->QueryResultLineage|_A:
		from vulcan.core.lineage import lineage_sql
		try:
			result_lineage=lineage_sql(sql,result_columns,context=self.context,dialect=dialect)
			if not result_lineage:return
			return QueryResultLineage.from_lineage_sql(result_lineage)
		except Exception:logger.warning('Failed to compute result lineage',exc_info=_B);return
	async def execute_query(self,request_id:str,sql:str,environment:str,fingerprint:str,gateway:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=_A,ttl_minutes:int=0,depends_on_models:t.Optional[list]=_A,submitted_by:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		logger.info('Starting query execution: request_id=%s',request_id);logger.debug('Query SQL: request_id=%s sql=%s',request_id,sql);logger.debug('Query Params: request_id=%s params=%s',request_id,params);await self.query_state.mark_request_in_progress(request_id)
		try:
			import time as _time;_start=_time.perf_counter()
			if not gateway:raise ValueError(f"[{request_id}] Query job missing required gateway")
			def _execute()->t.Tuple[t.Any,str]:
				with request_engine_adapter(self.context,gateway,CorrelationId.from_query_id(request_id,submitted_by))as engine_adapter:
					if params is not _A:df_result=engine_adapter.fetchdf_with_params(sql,params)
					else:df_result=engine_adapter.fetchdf(sql)
					return df_result,engine_adapter.dialect
			df,dialect=await run_blocking_heavy(_execute);duration_s=_time.perf_counter()-_start;_engine=dialect
			try:prometheus.registry.on_gateway_query(gateway=gateway,engine=_engine,duration_s=duration_s)
			except Exception as metric_err:logger.warning('Failed to record gateway query metric: %s',metric_err)
			row_count=len(df);logger.debug('Warehouse fetch complete: request_id=%s, row_count=%d',request_id,row_count);lineage=self._lineage(sql,list(df.columns),dialect=dialect)
			if self.object_store:
				try:columns=self._extract_columns(df);logger.debug('Extracted schema: request_id=%s column_count=%d',request_id,len(columns));result_info=await self._finalize_success(request_id=request_id,df=df,columns=columns,row_count=row_count,fingerprint=fingerprint,depends_on_models=depends_on_models,ttl_minutes=ttl_minutes,sql=sql,lineage=lineage)
				except Exception as storage_error:logger.error('Failed to upload query result: request_id=%s error=%s',request_id,storage_error,exc_info=_B);raise storage_error
			else:logger.warning('No object storage configured, returning in-memory result: request_id=%s',request_id);raise Exception('No object storage configured')
			return{_D:_E,**result_info}
		except Exception as e:
			logger.error('Query execution failed: request_id=%s error=%s',request_id,e,exc_info=_B)
			try:prometheus.registry.on_gateway_error(gateway=gateway,error=e)
			except Exception as metric_err:logger.warning('Failed to record gateway error metric: %s',metric_err)
			try:await self.query_state.mark_request_failed(request_id,error_message=str(e))
			except Exception as mark_failed_error:logger.error('Failed to persist FAILED status: request_id=%s error=%s',request_id,mark_failed_error,exc_info=_B)
			return{_D:'FAILED','error':str(e)}
	async def _finalize_success(self,*,request_id:str,df:t.Any,columns:list,row_count:int,fingerprint:str,depends_on_models:t.Optional[list],ttl_minutes:int,sql:str,lineage:QueryResultLineage|_A)->t.Dict[str,t.Any]:
		object_store=self.object_store
		def _upload()->int:return object_store.upload_result(df,result_id=request_id)
		size_bytes=await run_blocking_heavy(_upload);object_store_path=f"results/{request_id}.parquet";logger.info('Result uploaded to object store: request_id=%s, size_bytes=%d',request_id,size_bytes)
		try:await self.query_state.mark_request_completed(request_id=request_id,result_id=request_id,object_store_path=object_store_path,row_count=row_count,size_bytes=size_bytes,columns=columns,fingerprint=fingerprint,depends_on=depends_on_models,ttl_minutes=ttl_minutes,sql=sql,lineage=lineage)
		except Exception as db_error:
			logger.error('Failed to mark query completed: request_id=%s error=%s',request_id,db_error,exc_info=_B);logger.info('Cleaning up uploaded result file: request_id=%s',request_id)
			try:self.object_store.delete_result(request_id);logger.info('Cleanup completed: request_id=%s',request_id)
			except Exception as cleanup_error:logger.warning('Failed to clean up uploaded result: request_id=%s error=%s',request_id,cleanup_error)
			raise db_error
		return{'result_id':request_id,'object_store_path':object_store_path,'row_count':row_count,'size_bytes':size_bytes}
	async def process_job(self,job:Job,*,payload:t.Optional[QueryJobPayload]=_A)->t.Dict[str,t.Any]:
		try:wait_seconds=max((datetime.now(timezone.utc)-job.created).total_seconds(),.0);prometheus.registry.on_queue_wait(entrypoint=job.entrypoint,wait_seconds=wait_seconds)
		except Exception as metric_err:logger.warning('Failed to record query queue wait metric: %s',metric_err)
		if payload is _A:payload=QueryJobPayload.model_validate_json(job.payload.decode(_C))
		return await self.execute_query(request_id=payload.request_id,sql=payload.sql,params=payload.params,environment=payload.environment,fingerprint=payload.fingerprint,gateway=payload.gateway,ttl_minutes=payload.ttl_minutes,depends_on_models=payload.depends_on or[],submitted_by=payload.submitted_by)
def register_query_entrypoints(qm:WorkerQueueManager,qm_enqueue:EnqueueQueueManager,context:Context,query_state:AsyncQueryState,object_store:ObjectStoreClient|_A,pgq_config:PGQConfig)->_A:
	executor=QueryExecutor(context,query_state,object_store)
	@qm.entrypoint(QUERY_EXECUTION_ENTRYPOINT,concurrency_limit=pgq_config.concurrency_limit,requests_per_second=pgq_config.requests_per_second)
	async def handle_query_execution(job:Job)->t.Dict[str,t.Any]:
		logger.info('Handling query execution job: %s',job.payload);payload=QueryJobPayload.model_validate_json(job.payload.decode(_C));result=await executor.process_job(job,payload=payload)
		if result.get(_D)==_E and payload.perspective_id and payload.environment=='prod':
			from api.worker.hera.jobs import enqueue_hera_perspective_sync
			try:await enqueue_hera_perspective_sync(qm_enqueue,payload.environment,payload.perspective_id)
			except Exception:logger.exception('Failed to enqueue Hera perspective sync for perspective_id=%s; query result is unaffected',payload.perspective_id)
		return result