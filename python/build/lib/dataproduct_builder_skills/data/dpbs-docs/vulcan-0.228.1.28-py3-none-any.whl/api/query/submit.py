from __future__ import annotations
_D='message'
_C=True
_B=False
_A=None
import asyncio,json,logging,time,typing as t,pydantic
from fastapi import HTTPException
from pgqueuer import QueueManager
from schema.rest_query import RestQuery
from vulcan.core import constants as c
from vulcan.core.query.definitions import Perspective,QueryFingerprintResult,QueryPolicyAudit,QueryRequest,QueryStatus,QueryStrategy,QueryType,SEMANTIC_QUERY_TYPES
from vulcan.utils import sortable_id
from api import prometheus
from api.context import EnvContext
from api.exceptions import QUERY_GATEWAY_UNKNOWN,QueryExecutionError,UnknownGatewayError
from vulcan.core.query.fingerprint import sql_fingerprint
from vulcan.core.query.lineage import resolve_referenced_models
from api.schemas.common import Link
from api.schemas.query import QueryExecutionResult,StatementAccepted,StatementLinks
from api.query.results import resolve_staleness
from api.state.query import AsyncQueryState
from api.utils.commons import timestamp_to_iso
from api.urls import urls
from api.worker.query_jobs import QueryJobPayload,enqueue_query_execution
logger=logging.getLogger(__name__)
_META_SIZE_LIMIT_BYTES=102400
def build_stored_meta(*,request_meta:t.Optional[t.Dict[str,t.Any]]=_A,headers_meta:t.Optional[t.Dict[str,t.Any]]=_A,server_meta:t.Optional[t.Dict[str,t.Any]]=_A)->t.Optional[t.Dict[str,t.Any]]:
	stored:dict[str,t.Any]={}
	if request_meta:stored['request']=dict(request_meta)
	if headers_meta:stored['headers']=headers_meta
	if server_meta:stored['server']=dict(server_meta)
	return stored or _A
def _enforce_stored_meta_size(meta:t.Dict[str,t.Any])->t.Dict[str,t.Any]:
	meta_size=len(json.dumps(meta))
	if meta_size>_META_SIZE_LIMIT_BYTES:raise QueryExecutionError(status_code=400,detail=f"meta field exceeds 100KB limit (got {meta_size} bytes)")
	return meta
def make_statement_links(*,request_id:str,primary_request_id:t.Optional[str]=_A,include_result:bool=_B)->StatementLinks:return StatementLinks(self=Link(href=urls.query_statement_detail(request_id)),primary=Link(href=urls.query_statement_detail(primary_request_id))if primary_request_id else _A,result=Link(href=urls.query_statement_result(request_id))if include_result else _A)
def build_statement_accepted(req:QueryRequest,exec_result:QueryExecutionResult,*,env_ctx:EnvContext|_A=_A)->StatementAccepted:
	from api.schemas.query import PrimaryReq,ReuseInfo;current_ts=time.time();primary_req:t.Optional[PrimaryReq]=_A;reuse_info:t.Optional[ReuseInfo]=_A;primary_request_id:t.Optional[str]=_A;include_result=_B
	if exec_result.strategy==QueryStrategy.REUSE_RESULT:
		status=QueryStatus.SUCCESS;include_result=_C
		if exec_result.reuse_metadata:reuse_info=ReuseInfo(computed_at=timestamp_to_iso(int(exec_result.reuse_metadata.computed_at*1000)),age_seconds=exec_result.reuse_metadata.age_seconds)
	elif exec_result.strategy==QueryStrategy.AWAIT_PRIMARY:
		primary_meta=exec_result.primary_metadata;status=primary_meta.status if primary_meta else QueryStatus.QUEUED
		if primary_meta:primary_req=PrimaryReq(request_id=primary_meta.request_id,status=primary_meta.status,submitted_at=timestamp_to_iso(int(primary_meta.submitted_at*1000)),submitted_by=primary_meta.submitted_by,started_at=timestamp_to_iso(int(primary_meta.started_at*1000))if primary_meta.started_at else _A,elapsed_ms=int((current_ts-primary_meta.submitted_at)*1000));primary_request_id=primary_meta.request_id
	else:status=QueryStatus.QUEUED
	depends_on=req.depends_on or exec_result.depends_on or[];is_stale=_B
	if env_ctx is not _A:is_stale,_=resolve_staleness(env_ctx,depends_on)
	return StatementAccepted(id=req.request_id,status=status,strategy=exec_result.strategy,fingerprint=exec_result.fingerprint,sql=req.sql_query,source_query=req.source_query,semantic_query=req.semantic_query,rest_query=req.rest_query,graphql_query=req.graphql_query,params=req.params,depends_on=depends_on or _A,submitted_at=timestamp_to_iso(req.submitted_ts),meta=req.meta,policy=req.policy,query_type=req.query_type,job_id=exec_result.job_id,primary=primary_req,reuse=reuse_info,is_stale=is_stale,links=make_statement_links(request_id=req.request_id,primary_request_id=primary_request_id,include_result=include_result))
async def submit_sql_via_flow(*,sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],ttl:int=0,request_meta:t.Optional[t.Dict[str,t.Any]]=_A,headers_meta:t.Optional[t.Dict[str,t.Any]]=_A,server_meta:t.Optional[t.Dict[str,t.Any]]=_A,stored_meta:t.Optional[t.Dict[str,t.Any]]=_A,stored_policy:QueryPolicyAudit|_A=_A,gateway:str,qm:QueueManager,query_state:AsyncQueryState,env_ctx:EnvContext,query_type:QueryType,retry_on_recent_failure:bool=_B,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[RestQuery]=_A,graphql_query:t.Optional[str]=_A,source_query:t.Optional[str]=_A,perspective_id:t.Optional[str]=_A,submitted_by:t.Optional[str]=_A,policy:QueryPolicyAudit|_A=_A)->StatementAccepted:
	if stored_meta is not _A:merged_meta:t.Optional[t.Dict[str,t.Any]]=stored_meta;resolved_policy=stored_policy
	else:merged_meta=build_stored_meta(request_meta=request_meta,headers_meta=headers_meta,server_meta=server_meta);resolved_policy=policy
	if merged_meta is not _A:merged_meta=_enforce_stored_meta_size(merged_meta)
	rest_query_wire:t.Optional[t.Dict[str,t.Any]]=rest_query.model_dump(exclude_none=_C,by_alias=_C)if rest_query is not _A else _A;exec_result=await _execute_or_reuse_query(sql=sql,params=params,gateway=gateway,ttl=ttl,meta=merged_meta,policy=resolved_policy,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query_wire,graphql_query=graphql_query,source_query=source_query,perspective_id=perspective_id,query_state=query_state,qm=qm,env_ctx=env_ctx,submitted_by=submitted_by,retry_on_recent_failure=retry_on_recent_failure);req=await query_state.get_request_by_id(exec_result.request_id)
	if not req:raise HTTPException(500,'Failed to create statement')
	return build_statement_accepted(req,exec_result,env_ctx=env_ctx)
async def _execute_or_reuse_query(sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],gateway:str,ttl:int,meta:t.Optional[t.Dict],policy:QueryPolicyAudit|_A,query_state:AsyncQueryState,qm:QueueManager,env_ctx:EnvContext,query_type:QueryType,submitted_by:t.Optional[str]=_A,retry_on_recent_failure:bool=_B,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[t.Dict[str,t.Any]]=_A,graphql_query:t.Optional[str]=_A,source_query:t.Optional[str]=_A,perspective_id:t.Optional[str]=_A)->QueryExecutionResult:
	B='on_cache_event failed: %s';A='query';qv=env_ctx.query_validator(gateway);allow_rollups=query_type in SEMANTIC_QUERY_TYPES;qv.validate(sql,allow_rollups=allow_rollups);depends_on_models=resolve_referenced_models(sql,metadata=qv.metadata,dialect=qv.dialect,default_catalog=qv.default_catalog,allow_rollups=allow_rollups);fingerprint,normalized_sql=sql_fingerprint(gateway=gateway,sql=sql,dialect=qv.dialect,params=params);depends_on=list(depends_on_models);fingerprint_result=await query_state.get_fingerprint_result(fingerprint)
	if fingerprint_result:
		depends_on=fingerprint_result.depends_on or depends_on;is_stale=env_ctx.models_have_missing_intervals(model_names=depends_on)
		if not is_stale:
			try:prometheus.registry.on_cache_event(api=A,hit=_C)
			except Exception as e:logger.debug(B,e)
			return await _handle_reuse_result(fingerprint_result=fingerprint_result,fingerprint=fingerprint,sql=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,policy=policy,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,source_query=source_query,perspective_id=perspective_id,query_state=query_state)
		logger.debug('Fingerprint found but stale: fingerprint=%s...',fingerprint[:16])
	in_flight=await query_state.get_in_flight_request_by_fingerprint(fingerprint)
	if in_flight:return await _handle_in_flight(in_flight=in_flight,fingerprint=fingerprint,sql=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,policy=policy,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,source_query=source_query,perspective_id=perspective_id,query_state=query_state)
	await _check_recent_failures(fingerprint=fingerprint,retry_on_recent_failure=retry_on_recent_failure,query_state=query_state)
	try:prometheus.registry.on_cache_event(api=A,hit=_B)
	except Exception as e:logger.debug(B,e)
	return await _handle_new_execution(fingerprint=fingerprint,sql=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,policy=policy,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,source_query=source_query,perspective_id=perspective_id,query_state=query_state,qm=qm,env_ctx=env_ctx)
async def _handle_reuse_result(fingerprint_result:QueryFingerprintResult,fingerprint:str,sql:str,normalized_sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],gateway:str,submitted_by:t.Optional[str],depends_on:t.Optional[t.List[str]],ttl:int,meta:t.Optional[t.Dict],policy:QueryPolicyAudit|_A,query_type:QueryType,semantic_query:t.Optional[str],rest_query:t.Optional[t.Dict[str,t.Any]],graphql_query:t.Optional[str],source_query:t.Optional[str],perspective_id:t.Optional[str],query_state:AsyncQueryState)->QueryExecutionResult:request_id=sortable_id();current_ts=time.time();await query_state.create_request(request_id=request_id,strategy=QueryStrategy.REUSE_RESULT,fingerprint=fingerprint,sql_query=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,policy=policy,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,source_query=source_query,perspective_id=perspective_id,cached_at_ts=fingerprint_result.cached_at_ts,result_id=fingerprint_result.result_id);logger.info('Fingerprint hit: fingerprint=%s..., request_id=%s...',fingerprint[:16],request_id[:16]);from api.schemas.query import ReuseMetadata;return QueryExecutionResult(strategy=QueryStrategy.REUSE_RESULT,request_id=request_id,fingerprint=fingerprint,normalized_sql=normalized_sql,depends_on=depends_on,job_id=_A,reuse_metadata=ReuseMetadata(computed_at=fingerprint_result.cached_at_ts/1e3,age_seconds=int(current_ts-fingerprint_result.cached_at_ts/1e3)))
async def _handle_in_flight(in_flight:QueryRequest,fingerprint:str,sql:str,normalized_sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],gateway:str,submitted_by:t.Optional[str],depends_on:t.Optional[t.List[str]],ttl:int,meta:t.Optional[t.Dict],policy:QueryPolicyAudit|_A,query_type:QueryType,semantic_query:t.Optional[str],rest_query:t.Optional[t.Dict[str,t.Any]],graphql_query:t.Optional[str],source_query:t.Optional[str],perspective_id:t.Optional[str],query_state:AsyncQueryState)->QueryExecutionResult:request_id=sortable_id();await query_state.create_request(request_id=request_id,strategy=QueryStrategy.AWAIT_PRIMARY,fingerprint=fingerprint,sql_query=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,policy=policy,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,source_query=source_query,perspective_id=perspective_id,primary_request_id=in_flight.request_id);logger.info('Request deduplicated: fingerprint=%s..., request_id=%s..., primary=%s...',fingerprint[:16],request_id[:16],in_flight.request_id[:16]);from api.schemas.query import PrimaryMetadata;return QueryExecutionResult(strategy=QueryStrategy.AWAIT_PRIMARY,request_id=request_id,fingerprint=fingerprint,normalized_sql=normalized_sql,depends_on=depends_on,job_id=_A,primary_metadata=PrimaryMetadata(request_id=in_flight.request_id,status=in_flight.execution_status,submitted_at=in_flight.submitted_ts/1e3,submitted_by=in_flight.submitted_by,started_at=in_flight.execution_start_ts/1e3 if in_flight.execution_start_ts else _A))
async def _check_recent_failures(fingerprint:str,retry_on_recent_failure:bool,query_state:AsyncQueryState)->_A:
	D='submitted_by';C='age_seconds';B='last_failed_at';A='error'
	if retry_on_recent_failure:return
	recent_failed=await query_state.get_recent_failed_execution_by_fingerprint(fingerprint,window_seconds=300)
	if not recent_failed:return
	current_ts=time.time();last_failed_at_ms=recent_failed.execution_end_ts;age_seconds=int(current_ts-last_failed_at_ms/1e3)if last_failed_at_ms is not _A else _A;error_message=recent_failed.error_message or'';_AUTH_PATTERNS='Authentication token has expired','authentication token has expired'
	if any(pat in error_message for pat in _AUTH_PATTERNS):raise QueryExecutionError(status_code=400,detail={A:'AUTHENTICATION_EXPIRED',_D:error_message,B:last_failed_at_ms,C:age_seconds,D:recent_failed.submitted_by})
	raise QueryExecutionError(status_code=400,detail={A:'RECENT_FAILURE',_D:'An identical query failed recently. Fix the error before retrying or set retry_on_recent_failure=true to override.',B:last_failed_at_ms,C:age_seconds,D:recent_failed.submitted_by,'last_error':error_message[:512]})
async def _handle_new_execution(fingerprint:str,sql:str,normalized_sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],gateway:str,submitted_by:t.Optional[str],depends_on:t.Optional[t.List[str]],ttl:int,meta:t.Optional[t.Dict],policy:QueryPolicyAudit|_A,query_type:QueryType,semantic_query:t.Optional[str],rest_query:t.Optional[t.Dict[str,t.Any]],graphql_query:t.Optional[str],source_query:t.Optional[str],perspective_id:t.Optional[str],query_state:AsyncQueryState,qm:QueueManager,env_ctx:EnvContext)->QueryExecutionResult:
	request_id=sortable_id();await query_state.create_request(request_id=request_id,strategy=QueryStrategy.EXECUTE,fingerprint=fingerprint,sql_query=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,policy=policy,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,source_query=source_query,perspective_id=perspective_id,execution_status=QueryStatus.ACCEPTED);payload=QueryJobPayload(request_id=request_id,fingerprint=fingerprint,gateway=gateway,sql=sql,params=params,ttl_minutes=ttl,depends_on=depends_on,environment=env_ctx.environment,perspective_id=perspective_id,submitted_by=submitted_by)
	try:job_id=await enqueue_query_execution(qm,payload);await query_state.mark_request_queued(request_id,job_id);logger.info('Query enqueued: request_id=%s..., job_id=%s',request_id[:16],job_id)
	except Exception as e:logger.exception('Failed to enqueue job');await query_state.mark_request_failed(request_id,f"Enqueue failed: {str(e)}");raise QueryExecutionError(status_code=500,detail='Failed to enqueue query for execution')
	return QueryExecutionResult(strategy=QueryStrategy.EXECUTE,request_id=request_id,fingerprint=fingerprint,normalized_sql=normalized_sql,depends_on=depends_on,job_id=job_id)
async def _fire_hera_perspective_sync(qm:QueueManager,perspective_id:str,environment:str)->_A:
	try:from api.worker.hera.jobs import enqueue_hera_perspective_sync;await enqueue_hera_perspective_sync(qm,environment,perspective_id)
	except Exception as exc:logger.warning('Hera perspective sync failed (id=%s): %s',perspective_id[:16],exc)
async def submit_perspective_refresh_by_id(perspective_id:str,env_ctx:EnvContext,query_state:AsyncQueryState,qm:QueueManager)->StatementAccepted:
	perspective=await query_state.get_perspective_by_id(perspective_id)
	if not perspective:raise QueryExecutionError(status_code=404,detail=f"Perspective '{perspective_id}' not found")
	return await submit_perspective_refresh(perspective=perspective,env_ctx=env_ctx,query_state=query_state,qm=qm)
async def submit_perspective_refresh(perspective:Perspective,env_ctx:EnvContext,query_state:AsyncQueryState,qm:QueueManager)->StatementAccepted:
	logger.info('Refreshing perspective: slug=%s',perspective.slug)
	if not perspective.sql_query:raise QueryExecutionError(status_code=400,detail='Perspective has no query definition')
	try:rest_query=RestQuery.from_storage(perspective.rest_query)
	except pydantic.ValidationError as e:raise QueryExecutionError(status_code=400,detail=f"Perspective '{perspective.slug}' has invalid stored rest_query: {e}")from e
	try:exec_gateway=env_ctx.gateway(perspective.gateway)
	except UnknownGatewayError as exc:
		message=f"Unknown gateway '{exc.requested}'."
		if exc.allowed:message=f"{message} Allowed: {', '.join(exc.allowed)}."
		raise QueryExecutionError(status_code=400,detail={'code':QUERY_GATEWAY_UNKNOWN,_D:message,'allowed':exc.allowed})from exc
	accepted=await submit_sql_via_flow(sql=perspective.sql_query,params=perspective.params,ttl=perspective.ttl,stored_meta=perspective.meta,stored_policy=perspective.policy,gateway=exec_gateway,qm=qm,query_state=query_state,env_ctx=env_ctx,retry_on_recent_failure=_B,query_type=perspective.query_type,semantic_query=perspective.semantic_query,rest_query=rest_query,graphql_query=perspective.graphql_query,source_query=perspective.source_query,perspective_id=perspective.perspective_id)
	if accepted.strategy==QueryStrategy.REUSE_RESULT and perspective.perspective_id:
		try:
			await query_state.update_request_id_for_perspective(perspective_id=perspective.perspective_id,request_id=accepted.id)
			if env_ctx.environment==c.PROD:asyncio.create_task(_fire_hera_perspective_sync(qm,perspective.perspective_id,env_ctx.environment))
		except Exception as e:logger.warning('Failed to update perspective request_id: %s',e)
	return accepted