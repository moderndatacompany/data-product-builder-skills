from __future__ import annotations
_A=None
import logging,threading,typing as t
from datetime import datetime
from functools import cached_property,lru_cache
from typing import TYPE_CHECKING
from schema.metadata import Metadata,ModelEntry as MetadataModelEntry,NominalRun
from vulcan.core import constants as c
from vulcan.core.context import Context
from vulcan.core.environment import Environment
from vulcan.core.export.bi_artifacts import ExportArtifact,build_export_artifacts
from vulcan.core.export.metadata import build_metadata
from vulcan.utils.date import now
from api.exceptions import ModelNotFoundAssertion,UnknownGatewayError
from api.openapi.postman import openapi_to_postman
from api.openapi.schema import build_env_openapi_spec
if TYPE_CHECKING:from vulcan.core.query.validator import QueryValidator;from api.endpoints.query.graphql.schema import GraphQLArtifacts
logger=logging.getLogger(__name__)
RuntimeMetadataFields=tuple[datetime,dict[str,list[tuple[str,str]]],dict[str,NominalRun]]
class EnvContext:
	def __init__(self,context:Context,environment:str,*,product:str,tenant:str,plan_id:t.Optional[str],snapshots:t.Any,metadata:Metadata,export_artifacts:dict[str,ExportArtifact],openapi_spec:dict[str,t.Any],postman_spec:dict[str,t.Any],graphql:'GraphQLArtifacts')->_A:self.context=context;self.environment=environment;self.product=product;self.tenant=tenant;self.plan_id=plan_id;self.snapshots=snapshots;self._metadata=metadata;self.export_artifacts=export_artifacts;self.openapi_spec=openapi_spec;self.postman_spec=postman_spec;self.graphql=graphql
	@classmethod
	def create(cls,context:Context,environment:str='prod')->EnvContext:
		env_name=Environment.sanitize_name(environment);env=context.state_sync.get_environment(env_name)
		if not env:available=[e.name for e in context.state_sync.get_environments()];raise ValueError(f"Environment '{env_name}' not found. Available: {', '.join(available)}")
		plan_id=getattr(env,'plan_id',_A);snapshots=context.state_sync.get_snapshots(env.finalized_or_current_snapshots);stmts=context.state_sync.get_environment_statements(env_name);metadata=build_metadata(context,environment=env_name,env=env,stmts=stmts,snapshots=snapshots);export_artifacts=cls._build_artifacts(metadata,env_name);openapi_spec,postman_spec=cls._build_api_specs(metadata);from api.endpoints.query.graphql.schema import build_artifacts as build_graphql_artifacts;graphql=build_graphql_artifacts(metadata);return cls(context=context,environment=env_name,product=context.config.project,tenant=context.config.tenant,plan_id=plan_id,snapshots=snapshots,metadata=metadata,export_artifacts=export_artifacts,openapi_spec=openapi_spec,postman_spec=postman_spec,graphql=graphql)
	def query_validator(self,gateway:str)->QueryValidator:from vulcan.core.query.validator import QueryValidator;connection=self.context.config.get_connection(gateway);return QueryValidator(metadata=self._metadata,dialect=self.dialect(gateway),default_catalog=connection.get_catalog())
	def gateway(self,requested:t.Optional[str])->str:
		if not requested:return self._metadata.gateway.name
		gateways=[self._metadata.gateway,*(self._metadata.gateways or[])];key=requested.lower();match=next((g.name for g in gateways if g.name.lower()==key),_A)
		if match is _A:raise UnknownGatewayError(requested,sorted(g.name for g in gateways))
		return match
	def dialect(self,gateway:str)->str:
		gateways=[self._metadata.gateway,*(self._metadata.gateways or[])];match=next((g for g in gateways if g.name==gateway),_A)
		if match is _A:raise ValueError(f"Gateway '{gateway}' not found in environment metadata")
		dialect=(match.dialect or match.connection_type or'').strip()
		if not dialect:raise ValueError(f"Gateway '{gateway}' has no dialect in environment metadata")
		logger.debug("Resolved dialect '%s' for gateway '%s'",dialect,gateway);return dialect
	@property
	def metadata(self)->Metadata:as_of,missing_intervals,nominal_runs=self._runtime_metadata_fields(self._minute_bucket());return self._metadata.model_copy(update={'as_of':as_of,'missing_intervals':missing_intervals,'nominal_runs':nominal_runs})
	def stale_models(self,model_names:t.Optional[t.List[str]])->list[str]:
		if not model_names:return[]
		missing=self.metadata.missing_intervals;return sorted(name for name in model_names if missing.get(name))
	def models_have_missing_intervals(self,model_names:t.Optional[t.List[str]])->bool:return bool(self.stale_models(model_names))
	@cached_property
	def models_by_name(self)->dict[str,MetadataModelEntry]:return{entry.name:entry for entry in self._metadata.models or[]}
	@cached_property
	def metrics_by_name(self)->dict[str,MetadataModelEntry]:return{name:entry for(name,entry)in self.models_by_name.items()if entry.kind=='METRIC'}
	def assert_model(self,model_name:str)->MetadataModelEntry:
		entry=self.models_by_name.get(model_name)
		if entry is not _A:return entry
		raise ModelNotFoundAssertion(model_name)
	@staticmethod
	def _build_artifacts(metadata:Metadata,environment:str)->dict[str,ExportArtifact]:
		if metadata.env!=c.PROD:return{}
		try:return build_export_artifacts(metadata)
		except Exception as e:logger.error('Export artifact pre-generation failed during EnvContext load (env=%s): %s',environment,e,exc_info=True);return{}
	@staticmethod
	def _build_api_specs(metadata:Metadata)->tuple[dict[str,t.Any],dict[str,t.Any]]:
		try:openapi_spec=build_env_openapi_spec(metadata);postman_spec=openapi_to_postman(openapi_spec,env_ctx=metadata);return openapi_spec,postman_spec
		except Exception as e:logger.error('API spec artifact generation failed during EnvContext load (env=%s): %s',metadata.env,e,exc_info=True);return{},{}
	@staticmethod
	def _minute_bucket()->int:return int(now().timestamp())//60
	@lru_cache(maxsize=4)
	def _runtime_metadata_fields(self,_minute_key:int)->RuntimeMetadataFields:from vulcan.core.export.metadata import missing_intervals_by_model,nominal_runs_by_model;execution_time=now();missing_intervals=missing_intervals_by_model(self.snapshots.values(),env_name=self.environment,execution_time=execution_time);nominal_runs=nominal_runs_by_model(self._metadata.models,as_of=execution_time,missing_intervals=missing_intervals);return execution_time,missing_intervals,nominal_runs
	def refresh(self)->_A:self._invalidate_runtime_metadata_fields_cache()
	def _invalidate_runtime_metadata_fields_cache(self)->_A:self._runtime_metadata_fields.cache_clear()
class EnvContextManager:
	def __init__(self,context:Context)->_A:self.context=context;(self._env_contexts):dict[str,EnvContext]={};(self._plan_change_counter):dict[str,int]={};(self._run_change_counter):dict[str,int]={};(self._lock):threading.Lock=threading.Lock()
	def get_env_context(self,environment:str)->EnvContext:
		env_ctx=self._env_contexts.get(environment)
		if env_ctx is not _A:return env_ctx
		return self._get_or_create_env_context(environment)
	def _get_or_create_env_context(self,environment:str)->EnvContext:
		with self._lock:
			env_ctx=self._env_contexts.get(environment)
			if env_ctx is not _A:return env_ctx
			env_obj=self.context.state_sync.get_environment(environment)
			if env_obj is _A:available_envs=[e.name for e in self.context.state_sync.get_environments_summary()];raise ValueError(f"Environment '{environment}' not found. Available environments: {', '.join(available_envs)if available_envs else'none'}")
			built=EnvContext.create(self.context,environment);self._env_contexts[environment]=built;return built
	def get_plan_change_counter(self,environment:str)->int:return self._plan_change_counter.get(environment,0)
	def get_run_change_counter(self,environment:str)->int:return self._run_change_counter.get(environment,0)
	async def on_plan_change(self,environment:str)->_A:from api.cache import get_cache_storage;from api.pool import run_blocking_heavy;await run_blocking_heavy(self._apply_plan_change,environment);get_cache_storage().invalidate_environment(environment);logger.info("Plan change for '%s' (counter=%s): invalidated plan, run, and ttl cache namespaces",environment,self._plan_change_counter[environment])
	async def on_run_change(self,environment:str)->_A:from api.cache import CachePolicy,cache_key_prefix,get_cache_storage;from api.pool import run_blocking_heavy;await run_blocking_heavy(self._apply_run_change,environment);get_cache_storage().invalidate_pattern(cache_key_prefix(CachePolicy.RUN_CHANGE,environment));logger.info("Run change for '%s' (counter=%s): invalidated run cache namespace",environment,self._run_change_counter[environment])
	def _apply_plan_change(self,environment:str)->_A:
		with self._lock:self.context.refresh();self._env_contexts[environment]=EnvContext.create(self.context,environment);self._plan_change_counter[environment]=self._plan_change_counter.get(environment,0)+1
	def _apply_run_change(self,environment:str)->_A:
		with self._lock:
			if environment in self._env_contexts:env_ctx=self._env_contexts[environment];self.context.state_sync.refresh_snapshot_intervals(env_ctx.snapshots.values());env_ctx.refresh()
			self._run_change_counter[environment]=self._run_change_counter.get(environment,0)+1