_T='no-store'
_S='Cache-Control'
_R='Tableau artifact not found at EnvContext path.'
_Q='Tableau artifact path not available on EnvContext.'
_P='tableau'
_O='Tableau artifacts are only generated for prod.'
_N='content'
_M='expected_local_path'
_L='Artifact not found'
_K='Exports'
_J='Metadata'
_I='TABLEAU_ARTIFACT_NOT_FOUND'
_H='application/zip'
_G=True
_F=None
_E='description'
_D='plan_id'
_C='environment'
_B='message'
_A='error'
from pathlib import Path
from fastapi import APIRouter,Depends,HTTPException,Query,Response
from fastapi.responses import FileResponse,PlainTextResponse
from starlette.status import HTTP_404_NOT_FOUND,HTTP_502_BAD_GATEWAY
import zipfile
from api.context import EnvContext
from api.dependencies import get_env_context
from api.schemas.tableau import TableauPublishRequest,TableauPublishResponse
from api.tableau import TableauPublishError,publish_tableau_datasource
from schema.metadata import Metadata
from schema.semantic import SemanticSchema
from vulcan.core import constants as c
router=APIRouter()
@router.get('',summary='Get metadata',description='Full data-product catalog: product info, models, dependency graph, gateways, and live scheduler readiness (missing intervals and nominal run boundaries). The fingerprint changes when a new plan is applied.',tags=[_J],response_model=Metadata,response_model_by_alias=_G,response_model_exclude_none=_G,response_model_exclude_unset=_G)
async def get_metadata(minimal:bool=Query(False,description='When true, return a slim catalog without graph, missing_intervals, nominal_runs, or index.'),env_ctx:EnvContext=Depends(get_env_context))->Metadata:
	metadata=env_ctx.metadata
	if minimal:return Metadata.model_construct(**{name:getattr(metadata,name)for name in Metadata.model_fields if name not in{'graph','missing_intervals','nominal_runs','index'}})
	return metadata
@router.get('/agreement',summary='Get usage agreement',description='Markdown usage agreement for the data product. Returns 404 when no agreement text is configured.',tags=[_J],response_class=PlainTextResponse,responses={200:{_E:'Usage agreement markdown text.'}})
def get_agreement(env_ctx:EnvContext=Depends(get_env_context))->str:
	config=env_ctx.context.config;agreement=config.agreement.strip()
	if not agreement:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_A:'AGREEMENT_NOT_FOUND',_B:'Agreement text is not configured for this data product.'})
	return config.agreement
@router.get('/semantic',summary='Get semantic schema',description='Semantic models and metrics for catalog and wire-protocol consumers. A lightweight projection of metadata — query execution uses the semantic query API. The fingerprint changes when a new plan is applied.',tags=[_J],response_model=SemanticSchema)
def get_semantic_schema(env_ctx:EnvContext=Depends(get_env_context))->SemanticSchema:return SemanticSchema.from_metadata(env_ctx.metadata)
@router.get('/exports/powerbi',summary='Download Power BI artifact',description='ZIP of Power BI connection files from the last prod deployment. Available only in prod; returns 404 for other environments or when the artifact was not generated.',tags=[_K],responses={200:{_N:{_H:{}}},404:{_E:_L}})
async def download_powerbi_artifact(env_ctx:EnvContext=Depends(get_env_context)):
	A='POWERBI_ARTIFACT_NOT_FOUND'
	if env_ctx.metadata.env!=c.PROD:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_A:A,_B:'Power BI artifacts are only generated for prod.',_C:env_ctx.environment,_D:env_ctx.plan_id})
	artifact=env_ctx.export_artifacts.get('powerbi')
	if artifact is _F:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_A:A,_B:'Power BI artifact path not available on EnvContext.',_C:env_ctx.environment,_D:env_ctx.plan_id})
	path=artifact.path
	if path.exists():return FileResponse(path,media_type=_H,filename=path.name)
	raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_A:A,_B:'Power BI artifact not found at EnvContext path.',_M:str(path),_C:env_ctx.environment,_D:env_ctx.plan_id})
@router.get('/exports/tableau',summary='Download Tableau artifact',description='ZIP of Tableau connection files from the last prod deployment. Available only in prod; returns 404 for other environments or when the artifact was not generated.',tags=[_K],responses={200:{_N:{_H:{}}},404:{_E:_L}})
async def download_tableau_artifact(env_ctx:EnvContext=Depends(get_env_context)):
	if env_ctx.metadata.env!=c.PROD:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_A:_I,_B:_O,_C:env_ctx.environment,_D:env_ctx.plan_id})
	artifact=env_ctx.export_artifacts.get(_P)
	if artifact is _F:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_A:_I,_B:_Q,_C:env_ctx.environment,_D:env_ctx.plan_id})
	path=artifact.path
	if path.exists():return FileResponse(path,media_type=_H,filename=path.name)
	raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_A:_I,_B:_R,_M:str(path),_C:env_ctx.environment,_D:env_ctx.plan_id})
_NO_STORE={_S:_T}
_TABLEAU_TABLES_TDS_PREFIX='data_sources/tables/'
def _tableau_artifact_not_found(env_ctx:EnvContext,message:str)->HTTPException:return HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_A:_I,_B:message,_C:env_ctx.environment,_D:env_ctx.plan_id},headers=_NO_STORE)
def _tableau_tables_tds(env_ctx:EnvContext)->str:
	if env_ctx.metadata.env!=c.PROD:raise _tableau_artifact_not_found(env_ctx,_O)
	artifact=env_ctx.export_artifacts.get(_P)
	if artifact is _F:raise _tableau_artifact_not_found(env_ctx,_Q)
	if not artifact.path.exists():raise _tableau_artifact_not_found(env_ctx,_R)
	with zipfile.ZipFile(artifact.path)as zf:
		for name in zf.namelist():
			if name.startswith(_TABLEAU_TABLES_TDS_PREFIX)and name.endswith('.tds'):return zf.read(name).decode('utf-8')
	raise _tableau_artifact_not_found(env_ctx,'Tableau artifact has no tables data source.')
@router.post('/exports/tableau/publish',operation_id='publish_tableau',summary='Publish Tableau data source',description="Publish the product's semantic models to Tableau Cloud or Tableau Server as a single data source, using the Tableau artifact from the last prod deployment. Authenticates with a Personal Access Token or username/password supplied in the request body; credentials are used only for this request and are never stored, logged, or cached. The target project is created when missing and an existing data source is overwritten. Available only in prod.",tags=[_K],response_model=TableauPublishResponse,response_model_exclude_none=_G,responses={404:{_E:_L},502:{_E:'Tableau authentication, connection, or publish failed'}})
def publish_tableau_datasource_endpoint(request:TableauPublishRequest,response:Response,env_ctx:EnvContext=Depends(get_env_context))->TableauPublishResponse:
	response.headers[_S]=_T;tds_content=_tableau_tables_tds(env_ctx);metadata=env_ctx.metadata;datasource_name=f"{metadata.tenant}-{metadata.name}"
	try:project_name,datasource_id=publish_tableau_datasource(tds_content,datasource_name=datasource_name,server_address=request.server_address,site_id=request.site_id,project_name=request.project_name,username=request.username,password=request.password.get_secret_value()if request.password else _F,token_name=request.token_name,personal_access_token=request.personal_access_token.get_secret_value()if request.personal_access_token else _F)
	except TableauPublishError as e:raise HTTPException(status_code=HTTP_502_BAD_GATEWAY,detail={_A:'TABLEAU_PUBLISH_FAILED',_B:str(e),_C:env_ctx.environment,_D:env_ctx.plan_id},headers=_NO_STORE)
	return TableauPublishResponse(server_address=request.server_address,site_id=request.site_id,project_name=project_name,datasource=datasource_name,id=datasource_id)