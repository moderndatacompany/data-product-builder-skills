from __future__ import annotations
_D='VULCAN_PG_POOL_MAX'
_C='VULCAN_PG_POOL_MIN'
_B=True
_A=None
from dataclasses import dataclass
from functools import lru_cache
import logging,os
from types import TracebackType
import typing as t,asyncpg
from pgqueuer import QueueManager
from pgqueuer.db import AsyncpgPoolDriver
from vulcan import Context,configure_logging as configure_vulcan_logging
from vulcan.core import constants as c
from vulcan.core.config.connection import PostgresConnectionConfig
from vulcan.core.query import ObjectStoreClient
from vulcan.utils import debug_mode_enabled
from api.context import EnvContextManager
from api.utils.commons import parse_positive_float_env,parse_positive_int_env
logger=logging.getLogger(__name__)
class AsyncClosable(t.Protocol):
	async def __aenter__(self)->t.Self:...
	async def __aexit__(self,exc_type:type[BaseException]|_A,exc:BaseException|_A,tb:TracebackType|_A)->_A:...
@dataclass(frozen=_B,slots=_B)
class StatePostgres:
	connection:PostgresConnectionConfig;schema:str
	@property
	def dsn(self)->str:conn=self.connection;return f"postgresql://{conn.user}:{conn.password}@{conn.host}:{conn.port}/{conn.database}"
@dataclass(frozen=_B,slots=_B)
class AsyncpgPoolSettings:min_size:int;max_size:int;command_timeout:float
@dataclass(frozen=_B,slots=_B)
class SharedHttpClients:heimdall:t.Any|_A
def configure_logging()->_A:
	A=False;root_logger=logging.getLogger();from vulcan import CustomFormatter
	if not any(isinstance(h.formatter,CustomFormatter)for h in root_logger.handlers):
		log_level_env=os.getenv('LOG_LEVEL','INFO').upper();parsed_level=logging._nameToLevel.get(log_level_env,logging.INFO);force_debug=log_level_env=='DEBUG';configure_vulcan_logging(force_debug=force_debug,write_to_stdout=_B,write_to_file=A,ignore_warnings=A,log_level=log_level_env);debug=force_debug or debug_mode_enabled();uvicorn_level=logging.DEBUG if debug else parsed_level;logging.getLogger('uvicorn').setLevel(uvicorn_level);logging.getLogger('uvicorn.error').setLevel(uvicorn_level);logging.getLogger('uvicorn.access').setLevel(uvicorn_level)
		if not debug:logging.getLogger('soda').setLevel(logging.WARNING);logging.getLogger('soda.scan').setLevel(logging.WARNING);logging.getLogger('soda.telemetry').setLevel(logging.WARNING);logging.getLogger('soda.telemetry.soda_telemetry').setLevel(logging.WARNING);logging.getLogger('vulcan.core.soda3').setLevel(logging.WARNING)
	state_sql_debug=os.getenv('VULCAN_STATE_SQL_DEBUG','').strip().lower()
	if state_sql_debug in{'1','true','yes','on'}:state_connection_logger='api.state.connection';logging.getLogger(state_connection_logger).setLevel(logging.DEBUG);logger.info('State SQL debug logging enabled for %s',state_connection_logger)
configure_logging()
@lru_cache
def get_env_context_manager(path:str,config:str)->EnvContextManager:context=Context(paths=path,config=config,load=_B);return EnvContextManager(context)
def resolve_state_postgres(ctx:Context)->StatePostgres:
	gateway=ctx.config.default_gateway_name;state_conn=ctx.config.get_state_connection(gateway)or ctx.config.get_connection(gateway)
	if not state_conn:raise ValueError(f"❌ No connection configured for gateway '{gateway}'. Query service requires a PostgreSQL connection for metadata storage.")
	if state_conn.type_!='postgres':raise ValueError(f"❌ Query service requires PostgreSQL connection, got: {state_conn.type_}. The query service uses this connection for metadata storage (job queue and audit tables).")
	state_schema=ctx.config.get_state_schema(gateway)or c.SQLMESH
	if not state_schema:raise ValueError(f"❌ No state_schema configured for gateway '{gateway}'. Query service requires a schema for metadata tables.")
	return StatePostgres(connection=t.cast(PostgresConnectionConfig,state_conn),schema=state_schema)
def parse_asyncpg_pool_settings()->AsyncpgPoolSettings:
	pool_min=parse_positive_int_env(_C,default=2,floor=1,ceiling=100);pool_max=parse_positive_int_env(_D,default=10,floor=1,ceiling=500);command_timeout=parse_positive_float_env('VULCAN_PG_COMMAND_TIMEOUT_S',default=3e1,floor=1.,ceiling=3e2)
	if pool_min>pool_max:logger.warning('VULCAN_PG_POOL_MIN=%d > VULCAN_PG_POOL_MAX=%d; clamping min to max',pool_min,pool_max);pool_min=pool_max
	return AsyncpgPoolSettings(min_size=pool_min,max_size=pool_max,command_timeout=command_timeout)
async def close_async_client(client:AsyncClosable,*,label:str)->_A:
	try:await client.__aexit__(_A,_A,_A)
	except Exception:logger.debug('Error closing %s client',label,exc_info=_B)
async def init_heimdall_client(ctx:Context)->t.Any:
	from api.heimdall import HeimdallClient;heimdall_cfg=ctx.config.heimdall
	if not heimdall_cfg.enabled:return
	client=HeimdallClient(base_url=heimdall_cfg.base_url,timeout=heimdall_cfg.timeout);await client.__aenter__();return client
async def init_shared_http_clients(ctx:Context)->SharedHttpClients:heimdall=await init_heimdall_client(ctx);return SharedHttpClients(heimdall=heimdall)
def init_object_store(ctx:Context)->ObjectStoreClient|_A:
	if not ctx.config.object_store:return
	object_store_config=ctx.config.object_store;object_store=ObjectStoreClient(object_store_config,tenant=getattr(ctx.config,'tenant',_A),project=getattr(ctx.config,'name',_A))
	try:object_store.validate_connection()
	except Exception as exc:logger.error('Object store validation failed: %s',exc);raise RuntimeError(f"Failed to initialize object store. Query API cannot start without valid object store. Error: {exc}")from exc
	return object_store
async def log_postgres_max_connections(db_pool:asyncpg.Pool,*,pool_min:int,pool_max:int)->_A:
	A='<unset>'
	try:
		async with db_pool.acquire()as conn:row=await conn.fetchrow('SHOW max_connections')
		max_conn_raw=row['max_connections']if row else _A
		try:max_conn:int|str=int(max_conn_raw)if max_conn_raw is not _A else'<unknown>'
		except(TypeError,ValueError):max_conn=str(max_conn_raw)
		logger.info('Postgres state pool ready: max_connections=%s, pool_min=%s, pool_max=%s, configured VULCAN_PG_POOL_{MIN=%s, MAX=%s}',max_conn,pool_min,pool_max,os.getenv(_C,A),os.getenv(_D,A))
	except Exception as exc:logger.warning('Failed to probe Postgres max_connections (pool_min=%s, pool_max=%s): %s',pool_min,pool_max,exc)
async def init_pgqueuer(db_pool:asyncpg.Pool,schema:str)->QueueManager:
	from pgqueuer.queries import Queries;driver=AsyncpgPoolDriver(db_pool);channel_name=f"ch_pgqueuer_api_{schema}";qm=QueueManager(driver,channel=channel_name);qm.queries=Queries(driver)
	try:await qm.queries.install();logger.info('PGQueuer initialized successfully in schema: %s (channel: %s)',schema,channel_name)
	except Exception as exc:logger.debug('PGQueuer schema already exists: %s',exc)
	return qm