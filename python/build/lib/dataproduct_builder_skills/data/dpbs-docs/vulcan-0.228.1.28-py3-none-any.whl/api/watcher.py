from __future__ import annotations
_C='plan_id'
_B=True
_A=None
import asyncio,logging
from fastapi import FastAPI
from pgqueuer import QueueManager
from vulcan.core import constants as c
from vulcan.core.activity import EnvironmentChange
import api.worker.hera.jobs as hera_jobs
from api.context import EnvContextManager
from api.state.activity import AsyncActivityState
from api.worker.perspective_jobs import enqueue_perspective_refresh_sweep
logger=logging.getLogger(__name__)
_NS_TO_MS=1000000
async def _maybe_enqueue_hera_catalog_reconcile(manager:EnvContextManager,qm:QueueManager)->_A:
	from api.worker.hera.jobs import enqueue_hera_full_sync,should_sync_data_product;context=manager.context
	if not should_sync_data_product(context):logger.debug('Skipping Hera catalog reconcile; product not discoverable or no domain');return
	hera_cfg=context.config.hera
	if not hera_cfg or not hera_cfg.enabled:logger.debug('Skipping Hera catalog reconcile; Hera sync disabled');return
	env=c.PROD;env_ctx=manager.get_env_context(env);plan_id=getattr(env_ctx,_C,_A)
	if not plan_id:logger.warning('Skipping Hera catalog reconcile; no plan_id for env=%s',env);return
	result=await enqueue_hera_full_sync(qm,env,plan_id=plan_id,update_run_status=_B,trigger='reconcile');logger.info('hera catalog reconcile enqueued (env=%s): %s',env,result)
async def env_change_watcher_task(manager:EnvContextManager,activity:AsyncActivityState,app:FastAPI,sleep:int=5)->_A:
	A=False;last_ts_ns=0;startup_reconciled=A;logger.info('Environment change watcher started (polling every %ds)',sleep)
	while _B:
		try:
			if not startup_reconciled and getattr(app.state,'worker_healthy',A):
				qm:QueueManager|_A=getattr(app.state,'qm',_A)
				if qm is not _A:
					try:await _maybe_enqueue_hera_catalog_reconcile(manager,qm);startup_reconciled=_B
					except Exception:logger.exception('Hera catalog reconcile enqueue failed; will retry on next poll')
			changes,max_ts_ns=await activity.fetch_plan_run_activity_since(last_ts_ns);checkpoint_ts_ns=last_ts_ns;queue_manager:QueueManager|_A=getattr(app.state,'qm',_A)
			for change in changes:await _handle_environment_change(change,manager=manager,queue_manager=queue_manager,checkpoint_ts_ns=checkpoint_ts_ns,max_ts_ns=max_ts_ns,last_ts_ns=last_ts_ns)
			if changes:last_ts_ns=max_ts_ns;logger.debug('Updated checkpoint: last_ts_ns=%s',last_ts_ns)
		except Exception as exc:logger.error('Failed to process environment change poll: %s',exc,exc_info=_B)
		await asyncio.sleep(sleep)
async def _handle_environment_change(change:EnvironmentChange,*,manager:EnvContextManager,queue_manager:QueueManager|_A,checkpoint_ts_ns:int,max_ts_ns:int,last_ts_ns:int)->_A:
	if change.has_plan:await _handle_plan_change(change,manager=manager,queue_manager=queue_manager)
	if change.has_run:await _handle_run_change(change,manager=manager,queue_manager=queue_manager)
	if not change.has_plan and not change.has_run:return
	await _maybe_enqueue_perspective_sweep(change,queue_manager=queue_manager,checkpoint_ts_ns=checkpoint_ts_ns);logger.info('Processed environment change: env=%s has_plan=%s has_run=%s last_ts_ns=%s max_ts_ns=%s checkpoint_ts_ns=%s',change.environment,change.has_plan,change.has_run,last_ts_ns,max_ts_ns,checkpoint_ts_ns)
async def _handle_plan_change(change:EnvironmentChange,*,manager:EnvContextManager,queue_manager:QueueManager|_A)->_A:
	env=change.environment;logger.debug('Rebuilding environment cache: env=%s reason=plan',env);await manager.on_plan_change(env)
	if env!=c.PROD:return
	env_ctx=manager.get_env_context(env);plan_id=getattr(env_ctx,_C,_A)
	if queue_manager is _A:logger.debug('Skipping hera_full_sync enqueue: env=%s reason=no_queue_manager',env);return
	if not plan_id:logger.warning('Skipping hera_full_sync: env=%s reason=no_plan_id',env);return
	update_run_status=bool(change.has_run);result=await hera_jobs.enqueue_hera_full_sync(queue_manager,env,plan_id=plan_id,update_run_status=update_run_status);logger.info('hera_full_sync enqueued: env=%s plan_id=%s update_run_status=%s result=%s',env,plan_id,update_run_status,result)
async def _handle_run_change(change:EnvironmentChange,*,manager:EnvContextManager,queue_manager:QueueManager|_A)->_A:
	env=change.environment;logger.debug('Updating run cache: env=%s',env);await manager.on_run_change(env)
	if env!=c.PROD or change.has_plan:return
	if queue_manager is _A:logger.debug('Skipping hera_run_status enqueue: env=%s reason=no_queue_manager',env);return
	result=await hera_jobs.enqueue_hera_run_status(queue_manager,env);logger.info('hera_run_status enqueued: env=%s result=%s',env,result)
async def _maybe_enqueue_perspective_sweep(change:EnvironmentChange,*,queue_manager:QueueManager|_A,checkpoint_ts_ns:int)->_A:
	env=change.environment
	if checkpoint_ts_ns==0:logger.debug('Skipping perspective_refresh_sweep: env=%s reason=cold_start',env);return
	if queue_manager is _A:logger.debug('Skipping perspective_refresh_sweep enqueue: env=%s reason=no_queue_manager',env);return
	since_ts_ms=checkpoint_ts_ns//_NS_TO_MS;result=await enqueue_perspective_refresh_sweep(queue_manager,environment=env,since_ts_ms=since_ts_ms);logger.info('perspective_refresh_sweep enqueued: env=%s since_ts_ms=%d result=%s',env,since_ts_ms,result)