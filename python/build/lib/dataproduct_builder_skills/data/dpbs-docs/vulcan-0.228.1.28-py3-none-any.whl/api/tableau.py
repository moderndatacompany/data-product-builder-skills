from __future__ import annotations
_A=None
import logging,tempfile,typing as t
from pathlib import Path
logger=logging.getLogger(__name__)
class TableauPublishError(Exception):0
def _find_or_create_project(server:t.Any,tsc:t.Any,project_name:str)->str:
	if hasattr(tsc,'Pager'):projects:t.Iterable[t.Any]=tsc.Pager(server.projects)
	else:projects,_=server.projects.get()
	for project in projects:
		if project.name==project_name:return project.id
	created=server.projects.create(tsc.ProjectItem(name=project_name,description=project_name));logger.info("Created Tableau project '%s'",project_name);return created.id
def publish_tableau_datasource(tds_content:str,*,datasource_name:str,server_address:str,site_id:str='',project_name:t.Optional[str]=_A,username:t.Optional[str]=_A,password:t.Optional[str]=_A,token_name:t.Optional[str]=_A,personal_access_token:t.Optional[str]=_A)->t.Tuple[str,t.Optional[str]]:
	try:import tableauserverclient as tsc
	except ImportError as e:raise TableauPublishError("The 'tableauserverclient' package is required to publish to Tableau. Install it with: pip install tableauserverclient")from e
	effective_project=project_name or datasource_name
	if token_name and personal_access_token:auth=tsc.PersonalAccessTokenAuth(token_name,personal_access_token,site_id=site_id)
	else:auth=tsc.TableauAuth(username,password,site_id=site_id)
	server=tsc.Server(server_address,use_server_version=True)
	try:
		with server.auth.sign_in(auth):
			project_id=_find_or_create_project(server,tsc,effective_project)
			with tempfile.TemporaryDirectory(prefix='tableau_publish_')as tmp_dir:tds_path=Path(tmp_dir)/f"{datasource_name}.tds";tds_path.write_text(tds_content);item=tsc.DatasourceItem(project_id=project_id,name=datasource_name);published=server.datasources.publish(item,str(tds_path),tsc.Server.PublishMode.Overwrite)
	except TableauPublishError:raise
	except Exception as e:raise TableauPublishError(str(e))from e
	logger.info("Published Tableau datasource '%s' to project '%s'",datasource_name,effective_project);return effective_project,published.id