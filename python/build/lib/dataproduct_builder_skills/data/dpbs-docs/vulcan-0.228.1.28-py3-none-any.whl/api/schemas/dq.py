from __future__ import annotations
_E='Related resource links'
_D='self'
_C=None
_B=True
_A='_links'
import typing as t
from pydantic import ConfigDict,Field as PydanticField
from api.schemas.common import Link,SelfLink
from schema.types import DQDimension
from vulcan.core.soda3.spec import CheckOutcome
from vulcan.utils.pydantic import PydanticModel
class RuleRunLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_B);run:Link=PydanticField(description='Link to the pipeline run')
class RuleRun(PydanticModel):model_config=ConfigDict(populate_by_name=_B);outcome:CheckOutcome=PydanticField(description='Check outcome');outcome_reasons:t.Optional[t.Dict[str,t.Any]]=PydanticField(default=_C,description='Structured reasons for the outcome');diagnostics:t.Dict[str,t.Any]=PydanticField(default_factory=dict,description='Soda diagnostics payload');run_id:str=PydanticField(description='Pipeline run ID');start_ts:int=PydanticField(description='Execution start (Unix ms)');end_ts:t.Optional[int]=PydanticField(default=_C,description='Execution end (Unix ms)');links:RuleRunLinks=PydanticField(alias=_A,serialization_alias=_A,description=_E)
class RuleDefLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_B);self_link:Link=PydanticField(alias=_D,serialization_alias=_D,description='Link to rule detail')
class RuleDef(PydanticModel):model_config=ConfigDict(populate_by_name=_B,protected_namespaces=());identity:str=PydanticField(description='Stable rule ID');name:t.Optional[str]=PydanticField(default=_C,description='Rule display name');type:t.Optional[str]=PydanticField(default=_C,description='Rule type (e.g. freshness)');column:t.Optional[str]=PydanticField(default=_C,description='Target column');dimension:DQDimension=PydanticField(description='DQ dimension');definition:t.Optional[str]=PydanticField(default=_C,description='Rule definition text');model:t.Optional[str]=PydanticField(default=_C,description='Hosting model FQN');runs:t.List[RuleRun]=PydanticField(default_factory=list,description='Recent executions');links:RuleDefLinks=PydanticField(alias=_A,serialization_alias=_A,description=_E)
class RulesResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_B);rules:t.List[RuleDef]=PydanticField(description='Rules on this page');total:int=PydanticField(description='Total rules across all pages');links:SelfLink=PydanticField(alias=_A,serialization_alias=_A,description='Collection self link')
class RuleDetailLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_B);self_link:Link=PydanticField(alias=_D,serialization_alias=_D,description='Link to this rule');rules:Link=PydanticField(description='Link to rules collection')
class RuleDetailResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_B);rule:RuleDef=PydanticField(description='Rule definition and recent runs');links:RuleDetailLinks=PydanticField(alias=_A,serialization_alias=_A,description=_E)