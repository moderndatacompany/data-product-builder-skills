from __future__ import annotations
_B='/metadata'
_A=False
from fastapi import APIRouter
from api.endpoints._internal import router as internal_router
from api.endpoints.activity import router as activity_router
from api.endpoints.dq import router as dq_router
from api.endpoints.files import router as files_router
from api.endpoints.followers import router as followers_router
from api.endpoints.health import router as health_router
from api.endpoints.contracts import router as contracts_router
from api.endpoints.metadata import router as metadata_router
from api.endpoints.notifications import router as notifications_router
from api.endpoints.pgqueuer import router as pgqueuer_router
from api.endpoints.postman import router as postman_router
from api.endpoints.query import router as query_router
from api.endpoints.query.perspectives import router as perspectives_router
root_router=APIRouter()
root_router.include_router(health_router)
root_router.include_router(postman_router,include_in_schema=_A)
api_router=APIRouter()
api_router.include_router(metadata_router,prefix=_B)
api_router.include_router(contracts_router,prefix=_B)
api_router.include_router(dq_router,prefix='/dq',tags=['Data Quality'])
api_router.include_router(activity_router,prefix='/activity')
api_router.include_router(notifications_router,prefix='/notifications',tags=['Notifications'])
api_router.include_router(followers_router,prefix='/followers',tags=['Followers'])
api_router.include_router(query_router,prefix='/query')
api_router.include_router(perspectives_router,prefix='/perspectives',tags=['Perspectives'])
api_router.include_router(files_router,prefix='/files',tags=['Files'],include_in_schema=_A)
api_router.include_router(pgqueuer_router,prefix='/queue',tags=['Task Queue'],include_in_schema=_A)
api_router.include_router(internal_router,prefix='/_internal',tags=['Internal'],include_in_schema=_A)