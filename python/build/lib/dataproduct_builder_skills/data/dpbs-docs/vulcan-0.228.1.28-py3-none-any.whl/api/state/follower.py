from __future__ import annotations
_K='metadata'
_J='updated_at'
_I='followed_at'
_H='user_id'
_G='period_start'
_F='active'
_E='bucket_index'
_D='period_end'
_C=True
_B='b'
_A=None
import json,time,typing as t
from calendar import monthrange
from dataclasses import dataclass
from datetime import datetime,timedelta,timezone
from sqlglot import exp
from vulcan.core.follower import Follower,FollowerAnalytics,FollowerAnalyticsPagination,FollowerAnalyticsPeriod,FollowerGranularity
from api.state import ParamBinder,_col_eq_param,_pg,_table
from api.state.connection import StateConnection
from vulcan.core.state_sync.db.follower import FOLLOWERS,MAX_ANALYTICS_LIMIT
_FOLLOWER_COLS=FOLLOWERS.column_names()
@dataclass(frozen=_C)
class FollowerBucketSpec:bucket_index:int;period_start:int;period_end:int
def _ts_from_utc(dt:datetime)->int:return int(dt.timestamp())
def _floor_day(dt:datetime)->datetime:return dt.replace(hour=0,minute=0,second=0,microsecond=0)
def _floor_week(dt:datetime)->datetime:floored=_floor_day(dt);return floored-timedelta(days=floored.weekday())
def _floor_month(dt:datetime)->datetime:return dt.replace(day=1,hour=0,minute=0,second=0,microsecond=0)
def _add_months(dt:datetime,months:int)->datetime:month_index=dt.month-1+months;year=dt.year+month_index//12;month=month_index%12+1;day=min(dt.day,monthrange(year,month)[1]);return dt.replace(year=year,month=month,day=day)
def _bucket_bounds_for_index(bucket_index:int,granularity:FollowerGranularity,now:datetime)->t.Tuple[datetime,datetime]:
	if bucket_index<0:raise ValueError('bucket_index must be non-negative')
	if granularity==FollowerGranularity.DAY:
		if bucket_index==0:return _floor_day(now),now
		today=_floor_day(now);period_end=today-timedelta(days=bucket_index-1);return period_end-timedelta(days=1),period_end
	if granularity==FollowerGranularity.WEEK:
		if bucket_index==0:return _floor_week(now),now
		week_start=_floor_week(now);period_end=week_start-timedelta(weeks=bucket_index-1);return period_end-timedelta(weeks=1),period_end
	if bucket_index==0:return _floor_month(now),now
	month_start=_floor_month(now);period_end=_add_months(month_start,-(bucket_index-1));period_start=_add_months(month_start,-bucket_index);return period_start,period_end
def _build_analytics_bucket_specs(*,granularity:FollowerGranularity,offset:int,limit:int,now:t.Optional[datetime]=_A)->t.List[FollowerBucketSpec]:
	anchor=now or datetime.now(timezone.utc);specs:t.List[FollowerBucketSpec]=[]
	for bucket_index in range(offset,offset+limit):period_start,period_end=_bucket_bounds_for_index(bucket_index,granularity,anchor);specs.append(FollowerBucketSpec(bucket_index=bucket_index,period_start=_ts_from_utc(period_start),period_end=_ts_from_utc(period_end)))
	return specs
def _analytics_active_at_period_end_condition()->exp.Expression:return exp.and_(exp.LTE(this=exp.column(_I,'f'),expression=exp.column(_D,_B)),exp.or_(exp.column(_F,'f').eq(exp.true()),exp.GT(this=exp.column(_J,'f'),expression=exp.column(_D,_B))))
def _analytics_buckets_subquery(bucket_specs:t.Sequence[FollowerBucketSpec])->exp.Subquery:return exp.select(exp.column(_E),exp.column(_G),exp.column(_D)).from_(exp.values([(spec.bucket_index,spec.period_start,spec.period_end)for spec in bucket_specs],alias='buckets',columns=[_E,_G,_D])).subquery(_B)
class AsyncFollowerState:
	def __init__(self,conn:StateConnection)->_A:self._conn=conn;self._schema=conn.schema;self._followers_table=_table(FOLLOWERS.name,self._schema)
	async def get_follower(self,user_id:str)->t.Optional[Follower]:
		binder=ParamBinder();query=exp.select(*[exp.column(c)for c in _FOLLOWER_COLS]).from_(self._followers_table).where(_col_eq_param(_H,user_id,binder));row=await self._conn.fetch_row(_pg(query),*binder.values)
		if row is _A:return
		return self._row_to_follower(row)
	async def follow(self,user_id:str,metadata:t.Optional[t.Dict[str,t.Any]]=_A)->Follower:
		existing=await self.get_follower(user_id);now_ts=int(time.time())
		if existing is _A:payload_metadata=metadata or{};binder=ParamBinder();insert_stmt=exp.Insert(this=self._followers_table,columns=[exp.to_identifier(c)for c in _FOLLOWER_COLS],expression=exp.Values(expressions=[exp.Tuple(expressions=binder.add_all([user_id,_C,now_ts,now_ts,json.dumps(payload_metadata)]))]));await self._conn.execute(_pg(insert_stmt),*binder.values);return Follower(user_id=user_id,active=_C,followed_at=now_ts,updated_at=now_ts,metadata=payload_metadata)
		if existing.active:return existing
		merged_metadata=existing.metadata
		if metadata:merged_metadata={**existing.metadata,**metadata}
		await self._update_follower(user_id,active=_C,updated_at=now_ts,metadata=merged_metadata);return Follower(user_id=user_id,active=_C,followed_at=existing.followed_at,updated_at=now_ts,metadata=merged_metadata)
	async def unfollow(self,user_id:str)->Follower:
		A=False;existing=await self.get_follower(user_id)
		if existing is _A:raise ValueError(f"User {user_id!r} is not a follower")
		if not existing.active:return existing
		now_ts=int(time.time());await self._update_follower(user_id,active=A,updated_at=now_ts);return Follower(user_id=user_id,active=A,followed_at=existing.followed_at,updated_at=now_ts,metadata=existing.metadata)
	async def list_followers(self,*,active_only:bool=_C,limit:int=50,offset:int=0)->t.Tuple[t.List[Follower],bool]:
		binder=ParamBinder();conditions:t.List[exp.Expression]=[]
		if active_only:conditions.append(exp.column(_F).eq(exp.true()))
		query=exp.select(*[exp.column(c)for c in _FOLLOWER_COLS]).from_(self._followers_table).where(exp.and_(*conditions)if conditions else _A).order_by(exp.Ordered(this=exp.column(_I),desc=_C)).limit(binder.add(limit+1)).offset(binder.add(offset));rows=await self._conn.fetch_rows(_pg(query),*binder.values);has_more=len(rows)>limit
		if has_more:rows=rows[:limit]
		return[self._row_to_follower(r)for r in rows],has_more
	async def get_follower_analytics(self,*,granularity:t.Optional[FollowerGranularity]=_A,limit:int=30,offset:int=0)->FollowerAnalytics:
		if limit<1 or limit>MAX_ANALYTICS_LIMIT:raise ValueError(f"limit must be between 1 and {MAX_ANALYTICS_LIMIT}")
		if offset<0:raise ValueError('offset must be non-negative')
		total_active=await self._count_active_followers()
		if granularity is _A:return FollowerAnalytics(total_active=total_active)
		bucket_specs=_build_analytics_bucket_specs(granularity=granularity,offset=offset,limit=limit);series=await self._query_active_followers_by_buckets(bucket_specs);return FollowerAnalytics(total_active=total_active,granularity=granularity,offset=offset,limit=limit,series=series,pagination=FollowerAnalyticsPagination(offset=offset,limit=limit,has_more=_C))
	async def _count_active_followers(self)->int:query=exp.select(exp.Count(this=exp.Star()).as_('count')).from_(self._followers_table).where(exp.column(_F).eq(exp.true()));val=await self._conn.fetchval(_pg(query));return int(val or 0)
	async def _query_active_followers_by_buckets(self,bucket_specs:t.Sequence[FollowerBucketSpec])->t.List[FollowerAnalyticsPeriod]:
		A='active_followers'
		if not bucket_specs:return[]
		buckets=_analytics_buckets_subquery(bucket_specs);followers=self._followers_table.as_('f');query=exp.select(exp.column(_E,_B),exp.column(_G,_B),exp.column(_D,_B),exp.Count(this=exp.column(_H,'f')).as_(A)).from_(buckets).join(followers,on=_analytics_active_at_period_end_condition(),join_type='left').group_by(exp.column(_E,_B),exp.column(_G,_B),exp.column(_D,_B)).order_by(exp.column(_E,_B));rows=await self._conn.fetch_rows(_pg(query));counts_by_index={int(row[_E]):int(row[A])for row in rows};return[FollowerAnalyticsPeriod(period_start=spec.period_start,period_end=spec.period_end,active_followers=counts_by_index.get(spec.bucket_index,0))for spec in bucket_specs]
	async def _update_follower(self,user_id:str,*,active:bool,updated_at:int,metadata:t.Optional[t.Dict[str,t.Any]]=_A)->_A:
		binder=ParamBinder();updates:t.Dict[str,exp.Expression]={_F:binder.add(active),_J:binder.add(updated_at)}
		if metadata is not _A:updates[_K]=binder.add(json.dumps(metadata))
		update_stmt=exp.update(self._followers_table,updates,where=exp.column(_H).eq(binder.add(user_id)));await self._conn.execute(_pg(update_stmt),*binder.values)
	def _row_to_follower(self,row:t.Dict[str,t.Any])->Follower:
		metadata=row.get(_K)
		if isinstance(metadata,str):
			try:metadata=json.loads(metadata)
			except(json.JSONDecodeError,TypeError):metadata={}
		elif metadata is _A:metadata={}
		return Follower(user_id=row[_H],active=bool(row[_F]),followed_at=int(row[_I]),updated_at=int(row[_J]),metadata=metadata)