from __future__ import annotations
_B=None
_A=True
import typing as t
from pydantic import ConfigDict,Field as PydanticField,model_serializer
from vulcan.utils.pydantic import PydanticModel
class WireResponseModel(PydanticModel):
	@model_serializer(mode='plain',when_used='json')
	def _serialize_wire_json(self):return self.model_dump(by_alias=_A,exclude_none=_A)
class Link(PydanticModel):model_config=ConfigDict(populate_by_name=_A,exclude_none=_A);href:str=PydanticField(description='Target URI');method:t.Optional[str]=PydanticField(default=_B,description='HTTP method (defaults to GET)');type:t.Optional[str]=PydanticField(default=_B,description='Expected response media type');title:t.Optional[str]=PydanticField(default=_B,description='Short link label');templated:t.Optional[bool]=PydanticField(default=_B,description='True when href uses URI templates')
class SelfLink(PydanticModel):
	model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias='self',serialization_alias='self',description='Link to this resource')
	@classmethod
	def from_href(cls,href:str)->'SelfLink':return cls.model_construct(self_link=Link(href=href))
class Pagination(PydanticModel):model_config=ConfigDict(populate_by_name=_A);limit:int=PydanticField(description='Max items in this page');offset:int=PydanticField(description='Items skipped before this page');has_more:bool=PydanticField(description='True when more items exist');order_by:str=PydanticField(description='Sort field');order_direction:str=PydanticField(description='Sort direction (asc or desc)')