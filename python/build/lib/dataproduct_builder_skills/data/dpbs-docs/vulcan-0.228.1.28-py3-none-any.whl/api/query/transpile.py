from __future__ import annotations
_P='unknown'
_O='alias_or_name'
_N='PostgreSQL'
_M='databricks'
_L='clickhouse'
_K='redshift'
_J='sqlite'
_I='duckdb'
_H='snowflake'
_G='postgresql'
_F='error'
_E=False
_D='bigquery'
_C='postgres'
_B=None
_A='mysql'
import logging,time,typing as t
from decimal import Decimal,InvalidOperation
from fastapi import Request
from schema.auth import SecurityContext
from schema.metadata import Metadata
from schema.rest_query import RestQuery
from sqlglot import exp,parse_one,transpile
from sqlglot.errors import ParseError
from vulcan.core.query.transpiler import TranspileResult,transpile as transpile_semantic
from vulcan.utils.errors import TranspilerError
from api import prometheus
from api.context import EnvContext
from api.exceptions import SQLTranspilationError
logger=logging.getLogger(__name__)
API_QUERY_POST_PROCESSING_REQUIRED='API.QUERY.POST_PROCESSING_REQUIRED'
DEFAULT_HEADER_FILTER_LIST=frozenset({'authorization','apikey','api-key','cookie','proxy-authorization','set-cookie','x-api-key'})
def get_filtered_request_headers(request:Request,filter_list:t.AbstractSet[str]=DEFAULT_HEADER_FILTER_LIST)->t.Dict[str,str]:return{k.lower():v for(k,v)in request.headers.items()if k.lower()not in filter_list}
SUPPORTED_DIALECTS={_A:'MySQL',_C:_N,_G:_N,_D:'BigQuery',_H:'Snowflake',_I:'DuckDB',_J:'SQLite',_K:'Redshift',_L:'ClickHouse',_M:'Databricks'}
DIALECT_ALIASES={_G:_C,'bq':_D,'gcp':_D}
def normalize_dialect(dialect:str)->str:dialect_lower=dialect.lower().strip();return DIALECT_ALIASES.get(dialect_lower,dialect_lower)
def is_supported_dialect(dialect:str)->bool:normalized=normalize_dialect(dialect);return normalized in SUPPORTED_DIALECTS
def get_supported_dialects()->t.List[str]:return list(SUPPORTED_DIALECTS.keys())
def convert_sql_dialect(query:str,source:str,target:str,pretty:bool=_E)->str:
	C='query_preview';B='target_dialect';A='source_dialect';source_normalized=normalize_dialect(source);target_normalized=normalize_dialect(target)
	if not is_supported_dialect(source_normalized):supported=', '.join(get_supported_dialects());raise SQLTranspilationError(f"Unsupported source dialect: '{source}'. Supported dialects: {supported}")
	if not is_supported_dialect(target_normalized):supported=', '.join(get_supported_dialects());raise SQLTranspilationError(f"Unsupported target dialect: '{target}'. Supported dialects: {supported}")
	if source_normalized==target_normalized:logger.debug('Source and target dialects are the same (%s), skipping conversion',source_normalized);return query
	try:logger.debug('Transpiling SQL: %s → %s',source_normalized,target_normalized,extra={A:source_normalized,B:target_normalized,C:query[:100]if len(query)>100 else query});converted=transpile(query,read=source_normalized,write=target_normalized,pretty=pretty)[0];logger.debug('SQL transpilation successful',extra={A:source_normalized,B:target_normalized,'original_length':len(query),'converted_length':len(converted)});return converted
	except ParseError as e:logger.error('SQL parsing failed during transpilation',extra={A:source_normalized,B:target_normalized,_F:str(e),C:query[:200]if len(query)>200 else query});raise SQLTranspilationError(f"Failed to parse SQL query as {SUPPORTED_DIALECTS[source_normalized]}: {str(e)}",original_error=e)
	except Exception as e:logger.error('Unexpected error during SQL transpilation',extra={A:source_normalized,B:target_normalized,_F:str(e),'error_type':type(e).__name__});raise SQLTranspilationError(f"SQL transpilation failed: {str(e)}",original_error=e)
def get_gateway_dialect(gateway:t.Optional[str])->str:
	if not gateway:return _C
	gateway_dialect_map={_C:_C,_G:_C,_I:_I,_D:_D,_H:_H,_K:_K,_L:_L,_M:_M,_J:_J};gateway_lower=gateway.lower().strip();return gateway_dialect_map.get(gateway_lower,_C)
def prepare_client_sql(sql:str,client_dialect:t.Optional[str],metadata:Metadata)->str:fixed=fix_powerbi_single_value_query(sql,client_dialect);fixed=fix_powerbi_boolean_dimension_query(fixed,client_dialect,metadata);return normalize_scientific_numeric_literals(fixed,client_dialect)
def fix_powerbi_single_value_query(sql:str,client_dialect:t.Optional[str])->str:
	if client_dialect!=_A:return sql
	if'`C1`'not in sql and'`c1`'not in sql and' C1'not in sql and' c1'not in sql:return sql
	try:parsed=parse_one(sql,dialect=_A)
	except Exception:return sql
	select=parsed.find(exp.Select)
	if not isinstance(select,exp.Select):return sql
	projections=list(select.expressions)
	if len(projections)!=1:return sql
	col=projections[0];name=getattr(col,_O,_B)
	if not isinstance(name,str):name=getattr(col,'name',_B)
	if not isinstance(name,str)or name.upper()!='C1':return sql
	select.set('expressions',[exp.Star()])
	try:return parsed.sql(dialect=_A)
	except Exception:return sql
def normalize_scientific_numeric_literals(sql:str,client_dialect:t.Optional[str])->str:
	if client_dialect!=_A:return sql
	try:parsed=parse_one(sql,dialect=_A)
	except Exception:return sql
	changed=_E
	for node in parsed.walk():
		if not isinstance(node,exp.Literal)or not node.is_number:continue
		literal=node.this
		if'e'not in literal.lower():continue
		try:
			plain=format(Decimal(literal),'f')
			if'.'in plain:plain=plain.rstrip('0').rstrip('.')
		except(InvalidOperation,ValueError):continue
		if plain in{'','-'}:plain='0'
		if plain!=literal:node.replace(exp.Literal.number(plain));changed=True
	if not changed:return sql
	try:return parsed.sql(dialect=_A)
	except Exception:return sql
def _boolean_dimension_names(metadata:Metadata)->t.Set[str]:
	names:t.Set[str]=set()
	for model in metadata.models:
		if model.source_type!='semantic':continue
		for col in model.columns:
			if col.kind!='dimension'or col.ltype!='boolean':continue
			names.add(col.name.lower());names.add(f"{model.name}.{col.name}".lower())
			for dep in col.depends_on:
				if dep.column:names.add(dep.column.lower())
	return names
def fix_powerbi_boolean_dimension_query(sql:str,client_dialect:t.Optional[str],metadata:Metadata)->str:
	if client_dialect!=_A:return sql
	boolean_dimension_names=_boolean_dimension_names(metadata)
	if not boolean_dimension_names:return sql
	try:parsed=parse_one(sql,dialect=_A)
	except Exception:return sql
	select=parsed.find(exp.Select)
	if not isinstance(select,exp.Select):return sql
	has_boolean_projection=_E
	for proj in select.expressions:
		name=getattr(proj,_O,_B)or getattr(proj,'name',_B)
		if isinstance(name,str)and name.lower()in boolean_dimension_names:has_boolean_projection=True;break
	if not has_boolean_projection:return sql
	boolean_c_aliases:t.Set[str]=set()
	for node in parsed.walk():
		if not isinstance(node,exp.Alias):continue
		alias_name=node.alias;source=node.this
		if isinstance(source,exp.Column)and isinstance(alias_name,str)and len(alias_name)>=2 and alias_name[0].upper()=='C'and alias_name[1:].isdigit()and source.name.lower()in boolean_dimension_names:boolean_c_aliases.add(alias_name.upper())
	if not boolean_c_aliases:return sql
	changed=_E
	for node in list(parsed.walk()):
		if isinstance(node,exp.Cast)and isinstance(node.this,exp.Column)and node.this.name.upper()in boolean_c_aliases and isinstance(node.args.get('to'),exp.DataType)and node.args['to'].is_type(exp.DataType.Type.DOUBLE,exp.DataType.Type.FLOAT,exp.DataType.Type.UDOUBLE):
			try:col_sql=node.this.sql(dialect=_A);replacement=parse_one(f"CASE WHEN {col_sql} THEN 1 ELSE 0 END",dialect=_A);node.replace(replacement);changed=True
			except Exception:continue
	if not changed:return sql
	try:return parsed.sql(dialect=_A)
	except Exception:return sql
def _record_semantic_compilation(dialect:t.Optional[str],status:str,duration_s:float)->_B:
	try:prometheus.registry.on_semantic_compilation(engine=dialect or _P,status=status,duration_s=duration_s)
	except Exception as e:logger.debug('on_semantic_compilation failed: %s',e)
def _record_transpiler_error(dialect:t.Optional[str],api:str,error:Exception)->_B:
	try:prometheus.registry.on_transpiler_error(engine=dialect or _P,api=api,error=error)
	except Exception as e:logger.debug('on_transpiler_error failed: %s',e)
async def transpile_or_http_error(query:RestQuery|str,*,invalid_msg:str,disable_post_processing:bool,user:str,security_context:SecurityContext|_B=_B,env_ctx:EnvContext,gateway:str,auth_headers:t.Optional[t.Dict[str,str]]=_B)->TranspileResult:
	del invalid_msg;compile_start=time.perf_counter();dialect=env_ctx.dialect(env_ctx.metadata.gateway.name)
	try:result=await transpile_semantic(query=query,catalog=env_ctx.metadata,config=env_ctx.context.config,gateway=gateway,user=user,security_context=security_context or SecurityContext(),disable_cube_post_processing=disable_post_processing,headers=auth_headers);_record_semantic_compilation(dialect,'success',time.perf_counter()-compile_start);return result
	except TranspilerError as e:
		api_label='rest'if not isinstance(query,str)else'sql';_record_transpiler_error(dialect,api_label,e);_record_semantic_compilation(dialect,_F,time.perf_counter()-compile_start)
		if e.is_post_processing_error:
			if disable_post_processing:msg=f"Query requires post-processing, but post-processing is currently disabled. Set query parameter `disable_post_processing=false` to enable post-processing. Error: {e}"
			else:msg=f"Query requires post-processing, but enabling it failed. Error: {e}"
			raise TranspilerError(message=msg,code=400,response_data={'status':400,_F:{'code':API_QUERY_POST_PROCESSING_REQUIRED,'message':msg}})
		raise