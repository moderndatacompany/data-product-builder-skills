from __future__ import annotations
_N='user_id'
_M='schema'
_L='application/json'
_K='Query Result'
_J='Statement ID returned from any query submission'
_I='stmt_abc123'
_H='Primary request not found'
_G='is_stale'
_F='type'
_E='Is-Stale'
_D='headers'
_C='description'
_B=True
_A=None
import time,typing as t
from starlette.requests import Request
from fastapi import APIRouter,HTTPException,Path,Query,Header,Depends,Response
from fastapi.responses import RedirectResponse
from vulcan.core.query import ObjectStoreClient
from vulcan.core.query.definitions import QueryRequest,QueryResult,QueryStatus,QueryStrategy,TERMINAL_STATUSES
from vulcan.utils.errors import ObjectStoreError
from api.context import EnvContext
from api.dependencies import get_env_context,get_object_store,get_statestore_client
from api.pool import run_blocking_heavy
from api.query.results import IS_STALE_OPENAPI_HEADER,apply_filtering,is_request_stale,resolve_format,resolve_staleness,staleness_headers,to_csv,to_json,to_yaml
from api.query.submit import make_statement_links
from api.schemas.query import PrimaryReq,ReuseInfo,StatementDetail,StatementResult
from api.state import AsyncStateClient
from api.state.query import StatementContext
from api.utils.commons import timestamp_to_iso
router=APIRouter()
def _classify_object_store_error(*,error:Exception,action:str,result_id:str)->HTTPException:
	message=str(error).lower()
	if isinstance(error,FileNotFoundError)or'not found'in message or'no such file'in message:return HTTPException(404,f"Result artifact not found for '{result_id}'")
	if any(token in message for token in('timeout','timed out','connection','temporarily unavailable','throttle','too many requests')):return HTTPException(503,f"Object store unavailable while {action}")
	if isinstance(error,ObjectStoreError):return HTTPException(502,f"Object store error while {action}")
	return HTTPException(500,f"Failed to {action}")
def _resolve_statement_timing(query_request:QueryRequest,*,status:QueryStatus,primary_query_request:QueryRequest|_A=_A)->tuple[t.Optional[str],t.Optional[str],t.Optional[int],t.Optional[int]]:
	if query_request.strategy==QueryStrategy.REUSE_RESULT:submitted_at_iso=timestamp_to_iso(query_request.submitted_ts);return _A,submitted_at_iso,0,0
	if query_request.strategy==QueryStrategy.AWAIT_PRIMARY:
		primary_execution_duration_ms=primary_query_request.execution_duration_ms if primary_query_request is not _A else _A
		if status in TERMINAL_STATUSES and query_request.execution_end_ts is not _A:return _A,timestamp_to_iso(query_request.execution_end_ts),query_request.execution_end_ts-query_request.submitted_ts,primary_execution_duration_ms
		return _A,_A,_A,primary_execution_duration_ms
	started_at=timestamp_to_iso(query_request.execution_start_ts)if query_request.execution_start_ts else _A
	if query_request.execution_end_ts is not _A:completed_at=timestamp_to_iso(query_request.execution_end_ts)
	else:completed_at=_A
	return started_at,completed_at,query_request.queue_wait_time_ms,query_request.execution_duration_ms
def _build_statement_detail(query_request:QueryRequest,*,query_result:QueryResult|_A=_A,primary_query_request:QueryRequest|_A=_A)->StatementDetail:
	now=time.time();primary_info:PrimaryReq|_A=_A;reuse_info:ReuseInfo|_A=_A
	if query_request.strategy==QueryStrategy.REUSE_RESULT:status=QueryStatus.SUCCESS;has_result=bool(query_request.result_id);computed_at_seconds=query_request.cached_at_ts/1e3;reuse_info=ReuseInfo(computed_at=timestamp_to_iso(query_request.cached_at_ts),age_seconds=int(now-computed_at_seconds))
	elif query_request.strategy==QueryStrategy.AWAIT_PRIMARY:
		if primary_query_request is _A:raise ValueError('primary_query_request required for await_primary strategy')
		status=primary_query_request.execution_status;has_result=status==QueryStatus.SUCCESS;primary_info=PrimaryReq(request_id=primary_query_request.request_id,status=primary_query_request.execution_status,submitted_at=timestamp_to_iso(primary_query_request.submitted_ts),submitted_by=primary_query_request.submitted_by,started_at=timestamp_to_iso(primary_query_request.execution_start_ts)if primary_query_request.execution_start_ts else _A,elapsed_ms=int((now-primary_query_request.submitted_ts/1e3)*1000))
	else:status=query_request.execution_status;has_result=status==QueryStatus.SUCCESS
	started_at,completed_at,queue_wait_ms,execution_duration_ms=_resolve_statement_timing(query_request,status=status,primary_query_request=primary_query_request);lineage=_A
	if query_result and query_result.lineage:lineage=query_result.lineage
	return StatementDetail(id=query_request.request_id,status=status,strategy=query_request.strategy,fingerprint=query_request.fingerprint,depends_on=query_request.depends_on,sql=query_request.sql_query,params=query_request.params,submitted_at=timestamp_to_iso(query_request.submitted_ts),started_at=started_at,completed_at=completed_at,queue_wait_ms=queue_wait_ms,execution_duration_ms=execution_duration_ms,row_count=query_result.row_count if query_result else _A,size_bytes=query_result.size_bytes if query_result else _A,columns=query_result.columns if query_result else _A,lineage=lineage,error=query_request.error_message,meta=query_request.meta,policy=query_request.policy,query_type=query_request.query_type,semantic_query=query_request.semantic_query,rest_query=query_request.rest_query,graphql_query=query_request.graphql_query,source_query=query_request.source_query,primary=primary_info,reuse=reuse_info,links=make_statement_links(request_id=query_request.request_id,primary_request_id=primary_query_request.request_id if primary_query_request else _A,include_result=has_result))
def _apply_statement_staleness(detail:StatementDetail,env_ctx:EnvContext,response:Response)->StatementDetail:is_stale,stale_info=resolve_staleness(env_ctx,detail.depends_on,check=detail.status==QueryStatus.SUCCESS and detail.completed_at is not _A and bool(detail.depends_on));response.headers.update(staleness_headers(is_stale=is_stale));return detail.model_copy(update={_G:is_stale,'stale':stale_info})
async def _load_statement_context(state:AsyncStateClient,statement_id:str)->StatementContext:
	statement_context=await state.query.get_statement_context(statement_id)
	if statement_context is _A:raise HTTPException(404,f"Statement {statement_id} not found")
	return statement_context
def _resolve_result_id(query_request:QueryRequest,primary_query_request:QueryRequest|_A)->str:
	if query_request.strategy==QueryStrategy.AWAIT_PRIMARY:
		if primary_query_request is _A:raise HTTPException(500,_H)
		if primary_query_request.execution_status!=QueryStatus.SUCCESS or not primary_query_request.result_id:raise HTTPException(404,f"Result not available. Primary status: {primary_query_request.execution_status}")
		return primary_query_request.result_id
	if query_request.strategy==QueryStrategy.REUSE_RESULT:
		if not query_request.result_id:raise HTTPException(500,'Cache result not found')
		return query_request.result_id
	if query_request.execution_status!=QueryStatus.SUCCESS or not query_request.result_id:raise HTTPException(404,f"Result not available. Statement status: {query_request.execution_status}")
	return query_request.result_id
@router.get('/statement/{id}',summary='Get Statement Status',tags=[_K],operation_id='get_statement',response_model=StatementDetail,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Statement metadata and current status',_D:{_E:IS_STALE_OPENAPI_HEADER}},404:{_C:'Statement not found'}})
async def get_statement(id:str=Path(...,examples=[_I],description=_J),response:Response=Response(),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client)):
	statement_context=await _load_statement_context(state,id);query_request=statement_context.request
	if query_request.strategy==QueryStrategy.AWAIT_PRIMARY:
		if statement_context.primary_request is _A:raise HTTPException(500,_H)
		detail=_build_statement_detail(query_request,query_result=statement_context.result,primary_query_request=statement_context.primary_request)
	else:detail=_build_statement_detail(query_request,query_result=statement_context.result)
	return _apply_statement_staleness(detail,env_ctx,response)
@router.get('/statement/{id}/result',summary='Get Statement Result',tags=[_K],operation_id='get_statement_result',response_model=StatementResult,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={307:{_C:'Redirect to presigned Parquet URL (format=parquet)',_D:{'Location':{_M:{_F:'string'}},_E:IS_STALE_OPENAPI_HEADER}},200:{_C:'Result in requested text format (json/yaml/csv)',_D:{_E:IS_STALE_OPENAPI_HEADER},'content':{_L:{_M:StatementResult.model_json_schema(),'examples':{'json_result':{'summary':'JSON result with cols/rows/types','value':{'cols':[_N,'email'],'rows':[[1,'alice@example.com'],[2,'bob@example.com']],'types':[{'name':_N,_F:'INT'},{'name':'email',_F:'VARCHAR'}],'row_count':2,'size_bytes':128,_G:False,'_links':{'self':{'href':'/api/v1/query/statement/stmt_abc123/result'}}}}}}}},400:{_C:'Invalid columns requested'},404:{_C:'Result not available'},406:{_C:'Unsupported format'}})
async def get_statement_result(request:Request,id:str=Path(...,examples=[_I],description=_J),format:t.Optional[str]=Query(default=_A,examples=['json'],description="Response format: 'parquet' (default), 'json', 'yaml', or 'csv'"),limit:t.Optional[int]=Query(default=_A,ge=0,examples=[100],description='Max rows to return (text formats only)'),offset:t.Optional[int]=Query(default=0,ge=0,examples=[0],description='Skip first N rows (text formats only)'),columns:t.Optional[str]=Query(default=_A,examples=['col1,col2'],description='Comma-separated column names (text formats only)'),accept:str=Header(default='application/octet-stream'),env_ctx:EnvContext=Depends(get_env_context),object_store:ObjectStoreClient=Depends(get_object_store),state:AsyncStateClient=Depends(get_statestore_client)):
	statement_context=await _load_statement_context(state,id);query_request=statement_context.request;result_id=_resolve_result_id(query_request,statement_context.primary_request);query_result=statement_context.result
	if query_result is _A or query_result.result_id!=result_id:query_result=await state.query.get_result_by_id(result_id)
	if query_result is _A:raise HTTPException(404,'Result metadata not found')
	staleness_request_id=query_request.primary_request_id if query_request.strategy==QueryStrategy.AWAIT_PRIMARY and query_request.primary_request_id else query_request.request_id;is_stale,_=await is_request_stale(request_id=staleness_request_id,query_state=state.query,env_ctx=env_ctx);resolved_format=resolve_format(format,accept)
	if resolved_format=='parquet':
		try:url=await run_blocking_heavy(object_store.generate_presigned_url,result_id=query_result.result_id,expiry_mins=60)
		except Exception as exc:raise _classify_object_store_error(error=exc,action='generate presigned URL',result_id=query_result.result_id)from exc
		return RedirectResponse(url=url,status_code=307,headers=staleness_headers(is_stale=is_stale))
	try:df=await run_blocking_heavy(object_store.get_result,query_result.result_id)
	except Exception as exc:raise _classify_object_store_error(error=exc,action='read result from object store',result_id=query_result.result_id)from exc
	filtered=await run_blocking_heavy(apply_filtering,df,limit,offset,columns,query_result.columns)
	if resolved_format=='json':
		body=await run_blocking_heavy(to_json,filtered,query_result.columns,id,is_stale=is_stale)
		if is_stale:return Response(content=body.model_dump_json(exclude_none=_B,by_alias=_B),media_type=_L,headers=staleness_headers(is_stale=_B))
		return body
	if resolved_format=='yaml':return await run_blocking_heavy(to_yaml,filtered,is_stale=is_stale)
	if resolved_format=='csv':return await run_blocking_heavy(to_csv,filtered,is_stale=is_stale)
	raise HTTPException(500,f"Unexpected format: {resolved_format}")