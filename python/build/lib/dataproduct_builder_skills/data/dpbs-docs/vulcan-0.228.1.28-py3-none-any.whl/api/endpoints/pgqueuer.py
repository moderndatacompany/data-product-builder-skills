_D='Filter statistics by entrypoint name'
_C='Job ID'
_B=None
_A=True
import logging,typing as t
from datetime import timedelta
from fastapi import APIRouter,Depends,HTTPException,Query,Request,Path
from pgqueuer import QueueManager
from pgqueuer.models import JOB_STATUS
from api.dependencies import get_queue_manager
from api.schemas.pgqueuer import EntrypointInfo,JobHistoryResponse,JobLogEntry,JobStatusResponse,LogStatistic,QueueLogEntry,QueueStatistic
logger=logging.getLogger(__name__)
router=APIRouter()
@router.get('/jobs/{job_id}',summary='Get job status',response_model=JobStatusResponse,response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
async def get_job_status(job_id:int=Path(...,description=_C,ge=1),qm:QueueManager=Depends(get_queue_manager))->JobStatusResponse:
	try:
		from pgqueuer.models import JobId;statuses=await qm.queries.job_status([JobId(job_id)])
		if not statuses:raise HTTPException(status_code=404,detail=f"Job {job_id} not found")
		job_id_result,status=statuses[0];return JobStatusResponse(job_id=job_id,status=status)
	except HTTPException:raise
	except Exception as e:raise HTTPException(status_code=500,detail=f"Failed to get job status: {e}")
@router.get('/jobs/{job_id}/history',summary='Get job history',response_model=JobHistoryResponse,response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
async def get_job_history(job_id:int=Path(...,description=_C,ge=1),qm:QueueManager=Depends(get_queue_manager))->JobHistoryResponse:
	try:logs=await qm.queries.queue_log();job_logs=[JobLogEntry(created=log.created.isoformat()if log.created else _B,status=log.status,priority=log.priority,entrypoint=log.entrypoint,traceback=log.traceback.model_dump()if log.traceback else _B,aggregated=log.aggregated)for log in logs if log.job_id==job_id];return JobHistoryResponse(job_id=job_id,logs=job_logs,count=len(job_logs))
	except Exception as e:raise HTTPException(status_code=500,detail=f"Failed to get job history: {e}")
@router.get('/stats',summary='List queue statistics',response_model=t.List[QueueStatistic],response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
async def get_queue_statistics(entrypoint:t.Optional[str]=Query(_B,description=_D),qm:QueueManager=Depends(get_queue_manager))->t.List[QueueStatistic]:
	try:
		stats=await qm.queries.queue_size()
		if entrypoint:stats=[s for s in stats if s.entrypoint==entrypoint]
		return[QueueStatistic(entrypoint=stat.entrypoint,status=stat.status,priority=stat.priority,count=stat.count)for stat in stats]
	except Exception as e:raise HTTPException(status_code=500,detail=f"Failed to get queue statistics: {e}")
@router.get('/logs',summary='List queue logs',response_model=t.List[QueueLogEntry],response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
async def get_queue_logs(entrypoint:t.Optional[str]=Query(_B,description='Filter logs by entrypoint name'),status:t.Optional[str]=Query(_B,description='Filter logs by status',pattern=f"^(?i)({'|'.join(JOB_STATUS.__args__)})$"),limit:int=Query(100,ge=1,le=1000,description='Maximum number of logs to return'),qm:QueueManager=Depends(get_queue_manager))->t.List[QueueLogEntry]:
	try:
		logs=await qm.queries.queue_log();filtered_logs=logs
		if entrypoint:filtered_logs=[log for log in filtered_logs if log.entrypoint==entrypoint]
		if status:status_lower=status.lower();filtered_logs=[log for log in filtered_logs if log.status.lower()==status_lower]
		filtered_logs=filtered_logs[:limit];return[QueueLogEntry(job_id=log.job_id,created=log.created.isoformat()if log.created else _B,status=log.status,priority=log.priority,entrypoint=log.entrypoint,traceback=log.traceback.model_dump()if log.traceback else _B,aggregated=log.aggregated)for log in filtered_logs]
	except Exception as e:raise HTTPException(status_code=500,detail=f"Failed to get queue logs: {e}")
@router.get('/logs/statistics',summary='List log statistics',response_model=t.List[LogStatistic],response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
async def get_log_statistics(entrypoint:t.Optional[str]=Query(_B,description=_D),tail:t.Optional[int]=Query(_B,ge=1,description='Number of recent entries to retrieve'),last_hours:t.Optional[int]=Query(_B,ge=1,description='Time window in hours (e.g., 24 for last 24 hours)'),qm:QueueManager=Depends(get_queue_manager))->t.List[LogStatistic]:
	try:
		last=timedelta(hours=last_hours)if last_hours else _B;stats=await qm.queries.log_statistics(tail=tail,last=last)
		if entrypoint:stats=[s for s in stats if s.entrypoint==entrypoint]
		return[LogStatistic(created=stat.created.isoformat()if stat.created else _B,entrypoint=stat.entrypoint,status=stat.status,priority=stat.priority,count=stat.count)for stat in stats]
	except Exception as e:raise HTTPException(status_code=500,detail=f"Failed to get log statistics: {e}")
@router.get('/entrypoints',summary='List entrypoints',response_model=t.List[EntrypointInfo],response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
async def get_entrypoints(qm:QueueManager=Depends(get_queue_manager))->t.List[EntrypointInfo]:
	try:
		entrypoints=[]
		for(name,executor)in qm.entrypoint_registry.items():
			params=executor.parameters;retry_timer_seconds=_B
			if hasattr(params,'retry_timer')and params.retry_timer:retry_timer_seconds=params.retry_timer.total_seconds()
			entrypoints.append(EntrypointInfo(name=name,concurrency_limit=params.concurrency_limit,requests_per_second=params.requests_per_second,retry_timer_seconds=retry_timer_seconds))
		return entrypoints
	except Exception as e:raise HTTPException(status_code=500,detail=f"Failed to get entrypoints: {e}")
@router.get('/pending',summary='List pending jobs',response_model=dict[str,int],response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
async def get_pending_jobs(entrypoints:t.Optional[t.List[str]]=Query(_B,description='List of entrypoint names to check (defaults to all registered entrypoints)'),qm:QueueManager=Depends(get_queue_manager))->dict[str,int]:
	try:
		if not entrypoints:entrypoints=list(qm.entrypoint_registry.keys())
		pending_counts={}
		for ep in entrypoints:
			try:count=await qm.queries.queued_work([ep]);pending_counts[ep]=count
			except Exception as e:logger.warning('Failed to get pending jobs for entrypoint=%s: %s',ep,e);pending_counts[ep]=0
		return pending_counts
	except Exception as e:raise HTTPException(status_code=500,detail=f"Failed to get pending jobs: {e}")