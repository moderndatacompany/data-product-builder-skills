from __future__ import annotations
_A='DATAOS_FQDN'
import os,typing as t
from functools import lru_cache
from pathlib import Path
from pydantic import Field
from vulcan.utils.pydantic import PydanticModel
from vulcan.core import constants as c
from api.utils.commons import parse_positive_int_env
DEFAULT_ENVIRONMENT=c.PROD
_CORS_ALLOW_HEADERS='Accept','Authorization','Content-Type','X-Environment','X-Client-Dialect'
_CORS_ALLOW_METHODS='GET','POST','PUT','PATCH','DELETE','OPTIONS','HEAD'
def _default_cors_allow_origins()->list[str]:
	raw=os.getenv('CORS_ALLOW_ORIGINS','').strip()
	if raw:return[origin.strip()for origin in raw.split(',')if origin.strip()]
	from api.urls import is_localhost
	if is_localhost():return['http://127.0.0.1:8000','http://localhost:8000']
	fqdn=os.getenv(_A,'').strip()
	if fqdn:return[f"https://{fqdn}"]
	return[]
class Settings(PydanticModel):project_path:Path=Field(default_factory=lambda:Path(os.getenv('PROJECT_PATH','examples/b2b_saas')));config:str=Field(default_factory=lambda:os.getenv('CONFIG',''));gateway:t.Optional[str]=Field(default_factory=lambda:os.getenv('GATEWAY'));cors_allow_origins:list[str]=Field(default_factory=_default_cors_allow_origins);dataplane_name:str=Field(default_factory=lambda:os.getenv('DATAOS_DATAPLANE_NAME',''));dataplane_network_type:str=Field(default_factory=lambda:os.getenv('DATAOS_DATAPLANE_NETWORK_TYPE',''));dataplane_type:str=Field(default_factory=lambda:os.getenv('DATAOS_DATAPLANE_TYPE',''));dataos_fqdn:str=Field(default_factory=lambda:os.getenv(_A,''));resource_id:str=Field(default_factory=lambda:os.getenv('DATAOS_RESOURCE_ID',''));resource_type:str=Field(default_factory=lambda:os.getenv('DATAOS_TYPE',''));instance_name:str=Field(default_factory=lambda:os.getenv('DATAOS_INSTANCE_TENANT_ID',''));user_name:str=Field(default_factory=lambda:os.getenv('DATAOS_RUN_AS_USER',''));graphql_poll_interval_ms:int=Field(default_factory=lambda:parse_positive_int_env('GRAPHQL_POLL_INTERVAL_MS',default=5000,floor=100,ceiling=60000));graphql_poll_timeout_ms:int=Field(default_factory=lambda:parse_positive_int_env('GRAPHQL_POLL_TIMEOUT_MS',default=55000,floor=1000,ceiling=600000));graphql_retry_after_seconds:int=Field(default_factory=lambda:parse_positive_int_env('GRAPHQL_RETRY_AFTER_SECONDS',default=30,floor=1,ceiling=3600));graphql_default_timezone:t.Optional[str]=Field(default_factory=lambda:os.getenv('GRAPHQL_DEFAULT_TIMEZONE')or None)
@lru_cache()
def get_settings()->Settings:return Settings()
def cors_allow_headers()->list[str]:return list(_CORS_ALLOW_HEADERS)
def cors_allow_methods()->list[str]:return list(_CORS_ALLOW_METHODS)