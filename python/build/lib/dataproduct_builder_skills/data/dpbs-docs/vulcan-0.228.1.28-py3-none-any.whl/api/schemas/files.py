from __future__ import annotations
_A='Path relative to project root'
import typing as t
from pathlib import Path
from pydantic import ConfigDict,Field as PydanticField,field_validator
from vulcan.utils.pydantic import PydanticModel,ValidationInfo
class File(PydanticModel):
	model_config=ConfigDict(validate_default=True);name:str=PydanticField(description='File name');path:str=PydanticField(description=_A);extension:str=PydanticField(default='',description='File extension (e.g. .sql)');mime_type:str=PydanticField(default='application/octet-stream',description='MIME type inferred from the file name');content:t.Optional[str]=PydanticField(default=None,description='UTF-8 content (null for binary files)')
	@field_validator('extension',mode='before')
	@classmethod
	def default_extension(cls,v:str,info:ValidationInfo)->str:
		A='name'
		if A in info.data:return Path(info.data[A]).suffix
		return v
class Directory(PydanticModel):name:str=PydanticField(description='Directory name');path:str=PydanticField(description=_A);directories:t.List['Directory']=PydanticField(default_factory=list,description='Child directories');files:t.List[File]=PydanticField(default_factory=list,description='Files in this directory')