from __future__ import annotations
_H='plan_id'
_G='end_ts'
_F=True
_E='success'
_D='environment'
_C='plan_seq'
_B='start_ts'
_A=None
import typing as t
from sqlglot import exp
from vulcan.core.activity import EnvironmentChange,PlanActivity
from api.schemas.activity import PlanChangeCounts,PlanSummaryBase,RunSqlStatement
from api.state import ParamBinder,_col_eq_param,_pg,_table
from api.state.connection import StateConnection
from vulcan.core.state_sync.db.activity import ACTIVITY_PLANS,ACTIVITY_RUNS
from vulcan.core.state_sync.db.query_history import QUERY_HISTORY
def _plan_model_impact_overlap(model_names:t.List[str],impact:str,binder:ParamBinder)->exp.Expression:
	models_expr=binder.add(model_names);direct=exp.ArrayOverlaps(this=exp.column('models_affected_directly'),expression=models_expr);indirect=exp.ArrayOverlaps(this=exp.column('models_affected_indirectly'),expression=models_expr);metadata=exp.ArrayOverlaps(this=exp.column('models_affected_metadata'),expression=models_expr)
	if impact=='direct':return direct
	if impact=='indirect':return indirect
	if impact=='metadata':return metadata
	return exp.or_(direct,indirect,metadata)
class AsyncActivityState:
	def __init__(self,conn:StateConnection)->_A:self._conn=conn;self._schema=conn.schema;self._plans_table=_table(ACTIVITY_PLANS.name,self._schema);self._runs_table=_table(ACTIVITY_RUNS.name,self._schema);self._sql_history_table=_table(QUERY_HISTORY.name,self._schema)
	async def list_run_sql_statements(self,*,run_id:str,kind:t.Optional[str]=_A,status:t.Optional[str]=_A,limit:int=100,offset:int=0)->t.Tuple[t.List[RunSqlStatement],int,bool]:
		L='sql_text';K='normalized_sql';J='executor';I='error_message';H='row_count';G='duration_ms';F='dialect';E='component';D='total';C='id';B='status';A='statement_kind';binder=ParamBinder();conditions:t.List[exp.Expression]=[_col_eq_param('run_id',run_id,binder)]
		if kind is not _A:conditions.append(_col_eq_param(A,kind.upper(),binder))
		if status is not _A:conditions.append(_col_eq_param(B,status,binder))
		where=exp.and_(*conditions);count_query=exp.select(exp.Count(this=exp.Star()).as_(D)).from_(self._sql_history_table).where(where);count_row=await self._conn.fetch_row(_pg(count_query),*binder.values);total=int(count_row[D])if count_row else 0;list_query=exp.select(C,E,A,F,B,G,H,I,J,K,L).from_(self._sql_history_table).where(where).order_by(exp.Ordered(this=exp.column(C),desc=False)).limit(binder.add(limit+1)).offset(binder.add(offset));rows=await self._conn.fetch_rows(_pg(list_query),*binder.values);has_more=len(rows)>limit
		if has_more:rows=rows[:limit]
		statements=[RunSqlStatement(id=row[C],component=row.get(E),kind=row.get(A),dialect=row[F],status=row[B],duration_ms=row.get(G),row_count=row.get(H),error=row.get(I),executor=row[J],sql=row.get(K)or row.get(L)or'')for row in rows];return statements,total,has_more
	async def list_plans(self,plan_id:t.Optional[str]=_A,environment:t.Optional[str]=_A,plan_seq:t.Optional[int]=_A,model_names:t.Optional[t.List[str]]=_A,impact:str='all',success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[PlanActivity]:
		A='plan_diff';order=exp.Ordered(this=exp.column(_B),desc=_F);binder=ParamBinder()
		if plan_id:query=exp.select(exp.column(A),exp.column(_C)).from_(self._plans_table).where(_col_eq_param(_H,plan_id,binder)).order_by(order)
		else:
			if environment is _A:return[]
			conditions:t.List[exp.Expression]=[_col_eq_param(_D,environment,binder)]
			if plan_seq is not _A:conditions.append(_col_eq_param(_C,plan_seq,binder))
			if model_names:conditions.append(_plan_model_impact_overlap(model_names,impact,binder))
			if success is not _A:conditions.append(exp.column(_E).eq(exp.true()if success else exp.false()))
			start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A
			if start_ms is not _A:conditions.append(exp.GTE(this=exp.column(_B),expression=binder.add(start_ms)))
			if end_ms is not _A:conditions.append(exp.LTE(this=exp.column(_B),expression=binder.add(end_ms)))
			query=exp.select(exp.column(A),exp.column(_C)).from_(self._plans_table).where(exp.and_(*conditions)).order_by(order).limit(binder.add(limit)).offset(binder.add(offset))
		rows=await self._conn.fetch_rows(_pg(query),*binder.values);plans:t.List[PlanActivity]=[]
		for row in rows:
			plan_diff_json=row.get(A);plan_seq_val=row.get(_C)
			if not plan_diff_json:continue
			if isinstance(plan_diff_json,str):plan_activity=PlanActivity.parse_raw(plan_diff_json)
			else:plan_activity=PlanActivity.model_validate(plan_diff_json)
			plans.append(plan_activity.model_copy(update={_C:plan_seq_val}))
		return plans
	async def get_plan(self,plan_id:str)->t.Optional[PlanActivity]:plans=await self.list_plans(plan_id=plan_id);return plans[0]if plans else _A
	async def get_plan_by_seq(self,environment:str,plan_seq:int)->t.Optional[PlanActivity]:plans=await self.list_plans(environment=environment,plan_seq=plan_seq,limit=1);return plans[0]if plans else _A
	async def list_plan_summaries(self,environment:str,model_names:t.Optional[t.List[str]]=_A,impact:str='all',success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[PlanSummaryBase]:
		I='has_environment_changes';H='has_requirements_changes';G='count_backfills';F='count_metadata';E='count_removed';D='count_indirect';C='count_added';B='count_direct';A='version';order=exp.Ordered(this=exp.column(_B),desc=_F);binder=ParamBinder();conditions:t.List[exp.Expression]=[_col_eq_param(_D,environment,binder)]
		if model_names:conditions.append(_plan_model_impact_overlap(model_names,impact,binder))
		if success is not _A:conditions.append(exp.column(_E).eq(exp.true()if success else exp.false()))
		start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A
		if start_ms is not _A:conditions.append(exp.GTE(this=exp.column(_B),expression=binder.add(start_ms)))
		if end_ms is not _A:conditions.append(exp.LTE(this=exp.column(_B),expression=binder.add(end_ms)))
		select_columns=[_H,_C,A,_B,_G,_E,B,C,D,E,F,G,H,I];query=exp.select(*select_columns).from_(self._plans_table).where(exp.and_(*conditions)).order_by(order).limit(binder.add(limit)).offset(binder.add(offset));rows=await self._conn.fetch_rows(_pg(query),*binder.values);return[PlanSummaryBase(plan_id=row[_H],plan_seq=int(row.get(_C)or 0),version=row.get(A)or'',start_ts=int(row[_B]),end_ts=int(row[_G]),success=bool(row[_E]),changes=PlanChangeCounts(direct=int(row.get(B)or 0),added=int(row.get(C)or 0),indirect=int(row.get(D)or 0),removed=int(row.get(E)or 0),metadata=int(row.get(F)or 0)),count_backfills=int(row.get(G)or 0),has_requirements_changes=bool(row.get(H)),has_environment_changes=bool(row.get(I)))for row in rows]
	async def fetch_plan_run_activity_since(self,since_ts_ns:int=0)->t.Tuple[t.List[EnvironmentChange],int]:
		B='action_type';A='created_ts_ns';binder=ParamBinder();watermark=binder.add(since_ts_ns);plans_query=exp.select(_D,exp.Literal.string('plan').as_(B),A).from_(self._plans_table).where(exp.GT(this=exp.column(A),expression=watermark));runs_query=exp.select(_D,exp.Literal.string('run').as_(B),A).from_(self._runs_table).where(exp.GT(this=exp.column(A),expression=watermark));combined_query=exp.union(plans_query,runs_query,distinct=False);combined_query=combined_query.order_by(exp.Ordered(this=exp.column(A),desc=_F));rows=await self._conn.fetch_rows(_pg(combined_query),*binder.values)
		if not rows:return[],since_ts_ns
		changes_dict:t.Dict[str,EnvironmentChange]={};max_ts_ns=since_ts_ns
		for row in rows:
			env_name=row[_D];action_type=row[B];ts=row[A];change=changes_dict.setdefault(env_name,EnvironmentChange(environment=env_name));setattr(change,f"has_{action_type}",_F)
			if ts>max_ts_ns:max_ts_ns=ts
		return list(changes_dict.values()),max_ts_ns
	async def get_last_successful_run_end_ts_by_model(self,environment:str)->t.Dict[str,int]:runs_table_str=_table_sql('_runs',self._schema);sql=f"""
            SELECT
                model_name,
                MAX(end_ts) AS ts
            FROM {runs_table_str} r
            CROSS JOIN LATERAL unnest(r.models_affected) AS model_name
            WHERE r.environment = $1
                AND r.success = true
                AND r.models_affected IS NOT NULL
            GROUP BY model_name
        """;rows=await self._conn.fetch_rows(sql,environment);return{row['model_name']:row['ts']for row in rows}
	async def get_latest_run_for_environment(self,environment:str)->t.Optional[t.Tuple[bool,t.Optional[int]]]:
		binder=ParamBinder();query=exp.select(exp.column(_E),exp.column(_G)).from_(self._runs_table).where(_col_eq_param(_D,environment,binder)).order_by(exp.Ordered(this=exp.column(_B),desc=_F)).limit(1);row=await self._conn.fetch_row(_pg(query),*binder.values)
		if row is _A:return
		success_raw=row.get(_E)
		if success_raw is _A:return
		end_ts_raw=row.get(_G);return bool(success_raw),end_ts_raw