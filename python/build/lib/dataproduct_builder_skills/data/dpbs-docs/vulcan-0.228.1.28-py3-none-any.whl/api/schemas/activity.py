from __future__ import annotations
_S='Model name'
_R='Total plans across all pages'
_Q='Run completed without errors'
_P='Run end (Unix ms)'
_O='Run start (Unix ms)'
_N='Run sequence in environment'
_M='Link to associated plan'
_L='Link to previous plan'
_K='Total runs across all pages'
_J='Run ID'
_I=False
_H='Plan sequence in environment'
_G='Pagination metadata'
_F='Target environment'
_E='Related resource links'
_D='self'
_C='_links'
_B=None
_A=True
import typing as t
from pydantic import ConfigDict,Field as PydanticField
from api.schemas.common import Link,Pagination
from vulcan.core.activity import PlanActivity,RunActivityWithChecksAndProfile
from vulcan.utils.pydantic import PydanticModel
class PlanLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias=_D,serialization_alias=_D,description='Link to this plan');previous:t.Optional[Link]=PydanticField(default=_B,description=_L);commit:t.Optional[Link]=PydanticField(default=_B,description='Link to Git commit');git_diff:t.Optional[Link]=PydanticField(default=_B,description='Link to plan git diff')
class PlanGitDiffLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias=_D,serialization_alias=_D,description='Link to this git diff');current_plan:Link=PydanticField(description='Link to current plan');previous_plan:t.Optional[Link]=PydanticField(default=_B,description=_L)
class GitCommitDetail(PydanticModel):model_config=ConfigDict(populate_by_name=_A);sha:str=PydanticField(description='Commit SHA');message:str=PydanticField(description='Commit message subject');author_name:str=PydanticField(description='Author display name');author_email:str=PydanticField(description='Author email');authored_at:str=PydanticField(description='Authorship time (ISO-8601)');commit_url:t.Optional[str]=PydanticField(default=_B,description='External commit URL')
class Plan(PlanActivity):
	model_config=ConfigDict(populate_by_name=_A);links:PlanLinks=PydanticField(alias=_C,serialization_alias=_C,description=_E)
	@classmethod
	def from_core(cls,plan_activity:PlanActivity,links:PlanLinks)->'Plan':return cls(**plan_activity.model_dump(exclude_none=_A),links=links)
class PlanChangeCounts(PydanticModel):model_config=ConfigDict(populate_by_name=_A);direct:int=PydanticField(default=0,description='Directly modified models');added:int=PydanticField(default=0,description='Newly added models');indirect:int=PydanticField(default=0,description='Indirectly affected models');removed:int=PydanticField(default=0,description='Removed models');metadata:int=PydanticField(default=0,description='Metadata-only changes')
class PlanSummaryBase(PydanticModel):model_config=ConfigDict(populate_by_name=_A);plan_id:str=PydanticField(description='Plan ID');plan_seq:int=PydanticField(description=_H);version:str=PydanticField(description='Data product SemVer at apply');start_ts:int=PydanticField(description='Plan start (Unix ms)');end_ts:int=PydanticField(description='Plan end (Unix ms)');changes:PlanChangeCounts=PydanticField(description='Change counts by category');count_backfills:int=PydanticField(default=0,description='Backfills required');has_requirements_changes:bool=PydanticField(default=_I,description='Python requirements changed');has_environment_changes:bool=PydanticField(default=_I,description='SQL/Python environment statements changed');success:bool=PydanticField(description='Plan applied successfully')
class PlanSummary(PlanSummaryBase):
	model_config=ConfigDict(populate_by_name=_A);links:PlanLinks=PydanticField(alias=_C,serialization_alias=_C,description=_E)
	@classmethod
	def with_links(cls,base:PlanSummaryBase,links:PlanLinks)->'PlanSummary':return cls(**base.model_dump(),links=links)
class PlanGitDiffResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);git_diff:t.Optional[str]=PydanticField(default=_B,description='Unified diff text when available');commits:t.List[GitCommitDetail]=PydanticField(default_factory=list,description='Commits in the diff range');message:t.Optional[str]=PydanticField(default=_B,description='Status or error message');truncated:bool=PydanticField(default=_I,description='True when diff was trimmed to the size cap');links:PlanGitDiffLinks=PydanticField(alias=_C,serialization_alias=_C,description=_E)
class RunLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias=_D,serialization_alias=_D,description='Link to this run');plan:t.Optional[Link]=PydanticField(default=_B,description=_M);sql:t.Optional[Link]=PydanticField(default=_B,description='Link to warehouse SQL statements for this run')
class RunDetail(RunActivityWithChecksAndProfile):model_config=ConfigDict(populate_by_name=_A);links:RunLinks=PydanticField(alias=_C,serialization_alias=_C,description=_E)
class RunDqCounts(PydanticModel):model_config=ConfigDict(populate_by_name=_A);total:int=PydanticField(default=0,description='Checks evaluated');pass_:int=PydanticField(default=0,serialization_alias='pass',description='Checks passed');fail:int=PydanticField(default=0,description='Checks failed or errored');warn:int=PydanticField(default=0,description='Checks warned');not_evaluated:int=PydanticField(default=0,description='Checks not evaluated')
class RunSummaryBase(PydanticModel):model_config=ConfigDict(populate_by_name=_A);run_id:str=PydanticField(description=_J);run_seq:int=PydanticField(description=_N);plan_id:str=PydanticField(description='Associated plan ID');plan_seq:t.Optional[int]=PydanticField(default=_B,description=_H);plan_version:t.Optional[str]=PydanticField(default=_B,description='Data product SemVer at plan apply');start_ts:int=PydanticField(description=_O);end_ts:int=PydanticField(description=_P);models_affected_count:int=PydanticField(default=0,description='Models executed');errors_count:int=PydanticField(default=0,description='Errors recorded');dq:RunDqCounts=PydanticField(default_factory=RunDqCounts,description='DQ check counts');success:bool=PydanticField(description=_Q)
class RunSummary(RunSummaryBase):
	model_config=ConfigDict(populate_by_name=_A);links:RunLinks=PydanticField(alias=_C,serialization_alias=_C,description=_E)
	@classmethod
	def with_links(cls,base:RunSummaryBase,links:RunLinks)->'RunSummary':return cls(**base.model_dump(),links=links)
class RunsListResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);environment:str=PydanticField(description=_F);runs:t.List[RunDetail]=PydanticField(description='Run detail rows on this page');total:int=PydanticField(description=_K);pagination:Pagination=PydanticField(description=_G)
class PlansListSummaryResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);environment:str=PydanticField(description=_F);plans:t.List[PlanSummary]=PydanticField(description='Plan summaries on this page');total:int=PydanticField(description=_R);pagination:Pagination=PydanticField(description=_G)
class RunsListSummaryResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);environment:str=PydanticField(description=_F);runs:t.List[RunSummary]=PydanticField(description='Run summaries on this page');total:int=PydanticField(description=_K);pagination:Pagination=PydanticField(description=_G)
class RunWallClock(PydanticModel):model_config=ConfigDict(populate_by_name=_A);start_ts:int=PydanticField(description=_O);end_ts:int=PydanticField(description=_P)
class ModelRunMetrics(PydanticModel):model_config=ConfigDict(populate_by_name=_A);start_ts:int=PydanticField(description='Model execution start (Unix ms)');end_ts:int=PydanticField(description='Model execution end (Unix ms)');total_batches:int=PydanticField(default=0,description='Interval batches executed');evaluation_ms:int=PydanticField(default=0,description='Total SQL evaluation time (ms)');rows_affected:int=PydanticField(default=0,description='Rows processed');bytes_processed:int=PydanticField(default=0,description='Bytes processed')
class ModelRunInterval(PydanticModel):model_config=ConfigDict(populate_by_name=_A);start_ts:int=PydanticField(description='Interval start (Unix ms)');end_ts:int=PydanticField(description='Interval end (Unix ms)');evaluation_ms:int=PydanticField(default=0,description='SQL evaluation time for batch (ms)');rows_affected:int=PydanticField(default=0,description='Rows processed in batch')
def wall_clock_seconds_to_ms(ts:int)->int:
	if ts<=0:return ts
	return ts if ts>=0xe8d4a51000 else ts*1000
class ModelRunActivityLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_A);run:Link=PydanticField(description='Link to full run detail');plan:t.Optional[Link]=PydanticField(default=_B,description=_M)
class ModelRunActivityBase(PydanticModel):model_config=ConfigDict(populate_by_name=_A);run_id:str=PydanticField(description=_J);run_seq:int=PydanticField(description=_N);plan_id:str=PydanticField(description='Plan that triggered this run');plan_seq:t.Optional[int]=PydanticField(default=_B,description=_H);success:bool=PydanticField(description=_Q);run:RunWallClock=PydanticField(description='Full run wall-clock timing');model:ModelRunMetrics=PydanticField(description="This model's execution metrics");intervals:t.List[ModelRunInterval]=PydanticField(default_factory=list,description='Per-batch interval metrics')
class ModelRunActivity(ModelRunActivityBase):
	model_config=ConfigDict(populate_by_name=_A);links:ModelRunActivityLinks=PydanticField(alias=_C,serialization_alias=_C,description=_E)
	@classmethod
	def with_links(cls,base:ModelRunActivityBase,links:ModelRunActivityLinks)->'ModelRunActivity':return cls(**base.model_dump(),links=links)
class ModelRunActivitiesResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);model_name:str=PydanticField(description=_S);environment:str=PydanticField(description=_F);runs:t.List[ModelRunActivity]=PydanticField(description='Model-scoped runs on this page');total:int=PydanticField(description=_K);pagination:Pagination=PydanticField(description=_G)
class ModelLatestRun(PydanticModel):model_config=ConfigDict(populate_by_name=_A);model_name:str=PydanticField(description=_S);run:t.Optional[RunDetail]=PydanticField(default=_B,description='Most recent run detail (null if never executed)')
class ModelsLatestRunsResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);environment:str=PydanticField(description=_F);models:t.List[ModelLatestRun]=PydanticField(description='Latest run per model')
class PlansListResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);environment:str=PydanticField(description=_F);plans:t.List[Plan]=PydanticField(description='Plan detail rows on this page');total:int=PydanticField(description=_R);pagination:Pagination=PydanticField(description=_G)
RunSqlStatementStatus=t.Literal['SUCCESS','FAILED']
class RunSqlStatement(PydanticModel):model_config=ConfigDict(populate_by_name=_A);id:str=PydanticField(description='Sortable statement id');component:t.Optional[str]=PydanticField(default=_B,description='Emitting subsystem when set (for example DQ or PROFILE)');kind:t.Optional[str]=PydanticField(default=_B,description='Statement type inferred from SQL (for example SELECT, INSERT, MERGE)');dialect:str=PydanticField(description='Warehouse dialect');status:RunSqlStatementStatus=PydanticField(description='Execution outcome');duration_ms:t.Optional[int]=PydanticField(default=_B,description='Wall duration in milliseconds');row_count:t.Optional[int]=PydanticField(default=_B,description='Rows affected when known');error:t.Optional[str]=PydanticField(default=_B,description='Failure message when status is FAILED');executor:str=PydanticField(description='Acting user principal');sql:str=PydanticField(description='Normalized warehouse SQL (sqlglot-canonical). Correlation comments and formatting are stripped. When normalization was unavailable at write time, this falls back to executed SQL.')
class RunSqlStatementLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias=_D,serialization_alias=_D,description='Link to this SQL statement list');run:Link=PydanticField(description='Link to the parent run')
class RunSqlStatementResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);run_id:str=PydanticField(description=_J);environment:str=PydanticField(description=_F);statements:t.List[RunSqlStatement]=PydanticField(description='Warehouse SQL statements in execution order');total:int=PydanticField(description='Total matching statements across all pages');pagination:Pagination=PydanticField(description=_G);links:RunSqlStatementLinks=PydanticField(alias=_C,serialization_alias=_C,description=_E)