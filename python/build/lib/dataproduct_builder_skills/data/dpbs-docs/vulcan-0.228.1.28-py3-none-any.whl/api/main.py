from __future__ import annotations
_A=None
from contextlib import AsyncExitStack,asynccontextmanager
from collections.abc import AsyncIterator
import asyncio,logging,json,asyncpg
from fastapi import FastAPI
from api import prometheus
from api.pool import configure_thread_pools,shutdown_thread_pools
from api.startup import close_async_client,configure_logging,get_env_context_manager,init_heimdall_client,init_object_store,init_pgqueuer,log_postgres_max_connections,parse_asyncpg_pool_settings,resolve_state_postgres
from api.state import AsyncStateClient
from api.watcher import env_change_watcher_task
from api.worker.queue_depth import start_queue_depth_poller
from api.worker.supervisor import start_supervised_worker
logger=logging.getLogger(__name__)
async def _cancel_background_task(task:asyncio.Task[_A],*,label:str)->_A:
	logger.info('Shutting down %s...',label);task.cancel()
	try:await task
	except asyncio.CancelledError:pass
@asynccontextmanager
async def lifespan(app:FastAPI)->AsyncIterator[_A]:
	from api.config import get_settings;configure_logging();configure_thread_pools();settings=get_settings();manager=get_env_context_manager(str(settings.project_path),settings.config);ctx=manager.context;pgq_config=ctx.config.pgq;state_postgres=resolve_state_postgres(ctx);pool_cfg=parse_asyncpg_pool_settings()
	async with AsyncExitStack()as http_clients:
		heimdall_client=await init_heimdall_client(ctx);app.state.heimdall_client=heimdall_client
		if heimdall_client is not _A:http_clients.push_async_callback(close_async_client,heimdall_client,label='Heimdall')
		object_store=init_object_store(ctx)
		async def _init_conn(conn:asyncpg.Connection)->_A:await conn.set_type_codec('jsonb',encoder=json.dumps,decoder=json.loads,schema='pg_catalog')
		async with asyncpg.create_pool(state_postgres.dsn,min_size=pool_cfg.min_size,max_size=pool_cfg.max_size,command_timeout=pool_cfg.command_timeout,server_settings={'search_path':state_postgres.schema},init=_init_conn)as db_pool:
			await log_postgres_max_connections(db_pool,pool_min=pool_cfg.min_size,pool_max=pool_cfg.max_size);qm=await init_pgqueuer(db_pool,state_postgres.schema);app.state.env_context_manager=manager;app.state.qm=qm;app.state.object_store=object_store;app.state.statestore_client=AsyncStateClient(db_pool,state_postgres.schema);statestore_client=app.state.statestore_client;default_env=ctx.config.default_target_environment;env_ctx=manager.get_env_context(default_env);app.state.default_env_context=env_ctx;prometheus.init(tenant=env_ctx.tenant,data_product=env_ctx.product,version=ctx.config.version,dataplane_name=settings.dataplane_name,dataplane_network_type=settings.dataplane_network_type,dataplane_type=settings.dataplane_type,dataos_fqdn=settings.dataos_fqdn,resource_id=settings.resource_id,resource_type=settings.resource_type,instance_name=settings.instance_name,user_name=settings.user_name);app.state.worker_task=start_supervised_worker(app,context=ctx,queue_manager=qm,query_state=statestore_client.query,activity=statestore_client.activity,object_store=object_store,pgq_config=pgq_config,manager=manager,dsn=state_postgres.dsn,schema=state_postgres.schema);app.state.watcher_task=asyncio.create_task(env_change_watcher_task(manager,statestore_client.activity,app,sleep=5));app.state.queue_depth_task=asyncio.create_task(start_queue_depth_poller(queue_manager=qm));logger.info('Background tasks started')
			try:yield
			finally:
				await _cancel_background_task(app.state.worker_task,label='worker task');await _cancel_background_task(app.state.watcher_task,label='activity watcher');await _cancel_background_task(app.state.queue_depth_task,label='queue depth poller');prometheus.shutdown()
				try:shutdown_thread_pools()
				except Exception:logger.warning('Failed to shutdown thread pools',exc_info=True)