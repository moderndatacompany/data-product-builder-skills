from __future__ import annotations
_X='profile_metrics'
_W='quality_checks'
_V='success'
_U='plan_id'
_T='not_evaluated'
_S='run_data'
_R='models_affected'
_Q='plan_version'
_P=' AND '
_O='end_ts'
_N='start_ts'
_M='check_identity'
_L='check_name'
_K='dimension'
_J='column_name'
_I='diagnostics'
_H='outcome_reasons'
_G='run_id'
_F=True
_E='outcome'
_D='model_name'
_C='plan_seq'
_B='run_seq'
_A=None
import json,logging,typing as t
from sqlglot import exp
from vulcan.core.activity import ModelExec,RunActivity,RunActivityWithChecksAndProfile
from api.schemas.activity import ModelRunActivityBase,ModelRunInterval,ModelRunMetrics,RunDqCounts,RunSummaryBase,RunWallClock,wall_clock_seconds_to_ms
from vulcan.core.soda3.spec import CheckOutcome,CheckResult,CheckResultWithRunId,CheckRuns,FieldStatistics,ModelProfile,ProductQualitySummary,QualitySummary
from api.state import ParamBinder,_col_eq_param,_pg,_table,_table_sql
from api.state.connection import StateConnection
from vulcan.core.state_sync.db.activity import ACTIVITY_PLANS,ACTIVITY_RUNS
from vulcan.core.state_sync.db.dq import DQ_DEFINITIONS,DQ_PROFILES,DQ_RESULTS
logger=logging.getLogger(__name__)
def _parse_outcome_reasons(outcome_reasons:t.Any)->t.Optional[t.Dict[str,t.Any]]:
	A='message'
	if not outcome_reasons:return
	try:
		if isinstance(outcome_reasons,str):parsed=json.loads(outcome_reasons)
		else:parsed=outcome_reasons
		if isinstance(parsed,list):return{'messages':[item.get(A,str(item))if isinstance(item,dict)else str(item)for item in parsed]}
		return parsed if isinstance(parsed,dict)else{A:str(parsed)}
	except Exception:return{A:str(outcome_reasons)}
def _parse_diagnostics(raw:t.Any)->t.Dict[str,t.Any]:
	if not raw:return{}
	if isinstance(raw,dict):return raw
	try:return json.loads(raw)if isinstance(raw,str)else{}
	except Exception:return{}
def _parse_metric_value(m:t.Dict[str,t.Any])->t.Any:
	vt=m.get('value_type')
	if vt=='number':
		v=m.get('value_number')
		if v is _A:return
		try:f=float(v);return int(f)if f==int(f)else f
		except(ValueError,TypeError):return v
	if vt=='json':
		raw=m.get('value_json')
		if not raw:return
		try:return json.loads(raw)if isinstance(raw,str)else raw
		except Exception:return raw
	return m.get('value_text')
def _build_quality_list(checks:t.List[t.Any])->t.List[CheckResult]:
	result:t.List[CheckResult]=[]
	for d in checks:
		data=dict(d);data[_H]=_parse_outcome_reasons(data.get(_H));data[_I]=_parse_diagnostics(data.get(_I))
		try:data[_E]=CheckOutcome(data.get(_E)or _T)
		except ValueError:data[_E]=CheckOutcome.NOT_EVALUATED
		result.append(CheckResult.model_validate(data))
	return result
def _build_profile_list(metrics:t.List[t.Any])->t.List[ModelProfile]:
	A='columns';from collections import defaultdict
	if not metrics:return[]
	by_model:t.Dict[str,t.Dict[str,t.Any]]=defaultdict(lambda:{A:defaultdict(dict)})
	for m in metrics:
		model_name=m[_D];col=m.get(_J);ptype=m['profile_type'];value=_parse_metric_value(m)
		if col is _A:by_model[model_name][ptype]=value
		else:by_model[model_name][A][col][ptype]=value
	return[ModelProfile(model_name=name,columns={c:FieldStatistics.model_validate(dict(d))for(c,d)in data[A].items()},**{k:v for(k,v)in data.items()if k!=A})for(name,data)in by_model.items()]
def _json_list(raw:t.Any)->t.List[t.Any]:
	if raw is _A:return[]
	if isinstance(raw,list):return raw
	try:return json.loads(raw)
	except Exception:return[]
class AsyncQualityState:
	def __init__(self,conn:StateConnection)->_A:self._conn=conn;self._schema=conn.schema
	def _tbl(self,name:str)->str:return _table_sql(name,self._schema)
	async def get_quality_summary(self,environment:str,as_of_ts:t.Optional[int]=_A)->t.Optional[ProductQualitySummary]:
		defs_tbl=self._tbl(DQ_DEFINITIONS.name);results_tbl=self._tbl(DQ_RESULTS.name);as_of_ms=as_of_ts*1000 if as_of_ts is not _A else _A;sql=f"""
        WITH latest_with_dimension AS (
            SELECT DISTINCT ON (cd.check_identity, cd.environment)
                cd.check_identity,
                cr.outcome,
                cr.end_ts,
                cd.dimension
            FROM {defs_tbl} cd
            INNER JOIN {results_tbl} cr
                ON cr.check_identity = cd.check_identity
               AND cr.environment = cd.environment
            WHERE cd.environment = $1
              AND ($2::bigint IS NULL OR cr.start_ts <= $2)
            ORDER BY cd.check_identity, cd.environment, cr.start_ts DESC
        ),
        stats AS (
            SELECT
                dimension,
                COUNT(*) FILTER (WHERE outcome = 'pass') AS pass_count,
                COUNT(*) FILTER (WHERE outcome = 'fail') AS fail_count,
                COUNT(*) FILTER (WHERE outcome = 'warn') AS warn_count,
                COUNT(*) FILTER (WHERE outcome = 'error') AS error_count,
                COUNT(*) FILTER (WHERE outcome = 'not_evaluated') AS not_evaluated_count,
                COUNT(*) AS total_count,
                MAX(end_ts) AS latest_evaluated_at,
                COUNT(*) AS checks_count
            FROM latest_with_dimension
            GROUP BY GROUPING SETS ((dimension), ())
        )
        SELECT
            COALESCE(MAX(s.latest_evaluated_at) FILTER (WHERE s.dimension IS NULL), 0) AS latest_evaluated_at,
            COALESCE(MAX(s.checks_count) FILTER (WHERE s.dimension IS NULL), 0)::int AS checks_count,
            COALESCE(
                jsonb_object_agg(
                    s.dimension,
                    jsonb_build_object(
                        'pass', s.pass_count, 'fail', s.fail_count,
                        'warn', s.warn_count, 'error', s.error_count,
                        'not_evaluated', s.not_evaluated_count,
                        'total', s.total_count,
                        'pass_rate', ROUND(s.pass_count::NUMERIC / NULLIF(s.total_count, 0) * 100, 1)
                    )
                ) FILTER (WHERE s.dimension IS NOT NULL),
                '{{}}'::jsonb
            ) AS dimensions,
            COALESCE(SUM(s.pass_count) FILTER (WHERE s.dimension IS NULL), 0)::int AS total_pass,
            COALESCE(SUM(s.fail_count) FILTER (WHERE s.dimension IS NULL), 0)::int AS total_fail,
            COALESCE(SUM(s.warn_count) FILTER (WHERE s.dimension IS NULL), 0)::int AS total_warn,
            COALESCE(SUM(s.error_count) FILTER (WHERE s.dimension IS NULL), 0)::int AS total_error,
            COALESCE(SUM(s.not_evaluated_count) FILTER (WHERE s.dimension IS NULL), 0)::int AS total_not_evaluated,
            COALESCE(SUM(s.total_count) FILTER (WHERE s.dimension IS NULL), 0)::int AS total_checks
        FROM stats s
        """
		try:row=await self._conn.fetch_row(sql,environment,as_of_ms)
		except Exception as e:logger.error('Failed to execute get_quality_summary: %s',e,exc_info=_F);raise
		if not row:return
		checks_count=int(row['checks_count']or 0)
		if checks_count==0:return
		dimensions_raw=row.get('dimensions');dimensions:t.Dict[str,QualitySummary]={}
		if dimensions_raw:
			dim_dict=dimensions_raw if isinstance(dimensions_raw,dict)else json.loads(dimensions_raw)
			try:dimensions={dim:QualitySummary(**stats)for(dim,stats)in dim_dict.items()}
			except Exception as e:logger.warning('Failed to parse dimensions: %s',e)
		total_pass=int(row.get('total_pass')or 0);total_fail=int(row.get('total_fail')or 0);total_warn=int(row.get('total_warn')or 0);total_error=int(row.get('total_error')or 0);total_not_evaluated=int(row.get('total_not_evaluated')or 0);total_checks=int(row.get('total_checks')or 0);pass_rate=round(float(total_pass)/total_checks*100,1)if total_checks>0 else .0;summary=QualitySummary(pass_=total_pass,fail=total_fail,warn=total_warn,error=total_error,not_evaluated=total_not_evaluated,total=total_checks,pass_rate=pass_rate);return ProductQualitySummary(environment=environment,as_of_ts=as_of_ts,latest_evaluated_at=int(row.get('latest_evaluated_at')or 0),checks_count=checks_count,dimensions=dimensions,summary=summary)
	async def get_check_identity_by_natural_key(self,environment:str,model_name:str,dimension:str,check_name:str)->t.Optional[str]:binder=ParamBinder();where=exp.and_(_col_eq_param('environment',environment,binder),_col_eq_param(_D,model_name,binder),_col_eq_param(_K,dimension,binder),_col_eq_param(_L,check_name,binder));query=exp.select(exp.column(_M)).from_(_table(DQ_DEFINITIONS.name,self._schema)).where(where).limit(1);return await self._conn.fetchval(_pg(query),*binder.values)
	async def list_checks(self,environment:str,check_identity:t.Optional[str]=_A,model_names:t.Optional[t.List[str]]=_A,column_name:t.Optional[str]=_A,dimension:t.Optional[str]=_A,runs_per_check:int=10,limit:int=100,offset:int=0,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A)->t.List[CheckRuns]:
		B='definition';A='check_type'
		if not environment:return[]
		defs_tbl=self._tbl(DQ_DEFINITIONS.name);results_tbl=self._tbl(DQ_RESULTS.name);start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A
		if check_identity:rn_min,rn_max=offset,offset+limit;out_limit,out_offset=1,0
		else:rn_min,rn_max=0,runs_per_check;out_limit,out_offset=limit,offset
		sql=f"""
        WITH checks_from_def AS (
            SELECT check_identity, check_name, check_type, column_name,
                   dimension, definition, model_name
            FROM {defs_tbl}
            WHERE environment = $1
              AND ($2::text IS NULL OR check_identity = $3)
              AND ($4::text[] IS NULL OR model_name = ANY($5))
              AND ($6::text IS NULL OR column_name = $7)
              AND ($8::text IS NULL OR dimension = $9)
            ORDER BY model_name NULLS LAST, column_name NULLS LAST, check_name
            LIMIT $10 OFFSET $11
        ),
        ranked AS (
            SELECT cr.*,
                ROW_NUMBER() OVER (PARTITION BY cr.check_identity ORDER BY cr.start_ts DESC) AS rn
            FROM {results_tbl} cr
            WHERE cr.environment = $12
              AND cr.check_identity IN (SELECT check_identity FROM checks_from_def)
              AND ($13::bigint IS NULL OR cr.start_ts >= $14)
              AND ($15::bigint IS NULL OR cr.start_ts <= $16)
        )
        SELECT
            d.check_identity, d.check_name, d.check_type, d.column_name,
            d.dimension, d.definition, d.model_name,
            COALESCE(
                jsonb_agg(
                    jsonb_build_object(
                        'run_id', r.run_id, 'start_ts', r.start_ts, 'end_ts', r.end_ts,
                        'check_identity', d.check_identity, 'check_name', d.check_name,
                        'check_type', d.check_type, 'model_name', d.model_name,
                        'column_name', d.column_name, 'dimension', d.dimension,
                        'definition', d.definition, 'outcome', r.outcome,
                        'outcome_reasons', r.outcome_reasons, 'diagnostics', r.diagnostics
                    ) ORDER BY r.start_ts DESC
                ) FILTER (WHERE r.rn > $17 AND r.rn <= $18),
                '[]'::jsonb
            ) AS runs_json
        FROM checks_from_def d
        LEFT JOIN ranked r ON r.check_identity = d.check_identity
        GROUP BY d.check_identity, d.check_name, d.check_type, d.column_name,
                 d.dimension, d.definition, d.model_name
        ORDER BY d.model_name NULLS LAST, d.column_name NULLS LAST, d.check_name
        """;params=[environment,check_identity,check_identity,model_names,model_names,column_name,column_name,dimension,dimension,out_limit,out_offset,environment,start_ms,start_ms,end_ms,end_ms,rn_min,rn_max]
		try:rows=await self._conn.fetch_rows(sql,*params)
		except Exception as e:logger.error('Failed to list checks: %s',e,exc_info=_F);return[]
		result:t.List[CheckRuns]=[]
		for row in rows:
			metadata={_M:row[_M],_L:row[_L],A:row[A],_J:row[_J],_K:row[_K],B:row[B],_D:row[_D]};runs_list=_json_list(row['runs_json']);runs=[]
			for r in runs_list:
				if not isinstance(r,dict):continue
				try:outcome=CheckOutcome(r.get(_E)or _T)
				except ValueError:outcome=CheckOutcome.NOT_EVALUATED
				runs.append(CheckResultWithRunId(**metadata,outcome=outcome,outcome_reasons=_parse_outcome_reasons(r.get(_H)),diagnostics=_parse_diagnostics(r.get(_I))if outcome!=CheckOutcome.PASS else{},run_id=r.get(_G),start_ts=r.get(_N),end_ts=r.get(_O)))
			result.append(CheckRuns(**metadata,runs=runs))
		return result
	async def list_run_summaries(self,environment:str,model_names:t.Optional[t.List[str]]=_A,success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,plan_id:t.Optional[str]=_A,plan_seq:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[RunSummaryBase]:
		runs_tbl=self._tbl(ACTIVITY_RUNS.name);plans_tbl=self._tbl(ACTIVITY_PLANS.name);start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A;params:t.List[t.Any]=[];idx=1;where_parts:t.List[str]=[f"r.environment = ${idx}"];params.append(environment);idx+=1
		if model_names:where_parts.append(f"r.models_affected && ${idx}");params.append(model_names);idx+=1
		if success is not _A:where_parts.append(f"r.success = ${idx}");params.append(success);idx+=1
		if start_ms is not _A:where_parts.append(f"r.start_ts >= ${idx}");params.append(start_ms);idx+=1
		if end_ms is not _A:where_parts.append(f"r.start_ts <= ${idx}");params.append(end_ms);idx+=1
		if plan_id is not _A:where_parts.append(f"r.plan_id = ${idx}");params.append(plan_id);idx+=1
		if plan_seq is not _A:where_parts.append(f"r.plan_id IN (SELECT plan_id FROM {plans_tbl} WHERE environment = ${idx} AND plan_seq = ${idx+1})");params.extend([environment,plan_seq]);idx+=2
		limit_sql=f"LIMIT ${idx} OFFSET ${idx+1}";params.extend([limit,offset]);where_sql=_P.join(where_parts);query=f"""
        SELECT
            r.run_id,
            r.run_seq,
            r.plan_id,
            r.start_ts,
            r.end_ts,
            r.success,
            r.count_models,
            r.count_errors,
            r.count_dq_total,
            r.count_dq_pass,
            r.count_dq_fail,
            r.count_dq_warn,
            r.count_dq_not_evaluated,
            p.plan_seq,
            p.version AS plan_version
        FROM {runs_tbl} r
        LEFT JOIN {plans_tbl} p
            ON r.plan_id = p.plan_id
        WHERE {where_sql}
        ORDER BY r.start_ts DESC
        {limit_sql}
        """;rows=await self._conn.fetch_rows(query,*params);return[RunSummaryBase(run_id=row[_G],run_seq=int(row.get(_B)or 0),plan_id=row[_U],plan_seq=row.get(_C),plan_version=row.get(_Q),start_ts=int(row[_N]),end_ts=int(row[_O]),success=bool(row[_V]),models_affected_count=int(row.get('count_models')or 0),errors_count=int(row.get('count_errors')or 0),dq=RunDqCounts(total=int(row.get('count_dq_total')or 0),pass_=int(row.get('count_dq_pass')or 0),fail=int(row.get('count_dq_fail')or 0),warn=int(row.get('count_dq_warn')or 0),not_evaluated=int(row.get('count_dq_not_evaluated')or 0)))for row in rows]
	@staticmethod
	def _model_exec_for_name(run_data:t.Any,model_name:str)->t.Optional[ModelExec]:
		if isinstance(run_data,str):run_data=json.loads(run_data)
		models=(run_data or{}).get(_R)or[]
		for raw in models:
			if not isinstance(raw,dict):continue
			if raw.get('name')==model_name or raw.get('fqn')==model_name:return ModelExec.model_validate(raw)
	async def list_model_run_activities(self,environment:str,model_name:str,*,success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,plan_id:t.Optional[str]=_A,plan_seq:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[ModelRunActivityBase]:
		runs_tbl=self._tbl(ACTIVITY_RUNS.name);plans_tbl=self._tbl(ACTIVITY_PLANS.name);start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A;params:t.List[t.Any]=[];idx=1;where_parts:t.List[str]=[f"r.environment = ${idx}"];params.append(environment);idx+=1;where_parts.append(f"r.models_affected && ${idx}");params.append([model_name]);idx+=1
		if success is not _A:where_parts.append(f"r.success = ${idx}");params.append(success);idx+=1
		if start_ms is not _A:where_parts.append(f"r.start_ts >= ${idx}");params.append(start_ms);idx+=1
		if end_ms is not _A:where_parts.append(f"r.start_ts <= ${idx}");params.append(end_ms);idx+=1
		if plan_id is not _A:where_parts.append(f"r.plan_id = ${idx}");params.append(plan_id);idx+=1
		if plan_seq is not _A:where_parts.append(f"r.plan_id IN (SELECT plan_id FROM {plans_tbl} WHERE environment = ${idx} AND plan_seq = ${idx+1})");params.extend([environment,plan_seq]);idx+=2
		limit_sql=f"LIMIT ${idx} OFFSET ${idx+1}";params.extend([limit,offset]);where_sql=_P.join(where_parts);query=f"""
        SELECT
            r.run_id,
            r.run_seq,
            r.plan_id,
            r.start_ts,
            r.end_ts,
            r.success,
            r.run_data,
            p.plan_seq
        FROM {runs_tbl} r
        LEFT JOIN {plans_tbl} p
            ON r.plan_id = p.plan_id
        WHERE {where_sql}
        ORDER BY r.start_ts DESC
        {limit_sql}
        """;rows=await self._conn.fetch_rows(query,*params);activities:t.List[ModelRunActivityBase]=[]
		for row in rows:
			model_exec=self._model_exec_for_name(row.get(_S),model_name)
			if model_exec is _A:logger.warning('Skipping run_id=%s: model %s in models_affected but missing from run_data',row.get(_G),model_name);continue
			activities.append(ModelRunActivityBase(run_id=row[_G],run_seq=int(row.get(_B)or 0),plan_id=row[_U],plan_seq=row.get(_C),success=bool(row[_V]),run=RunWallClock(start_ts=int(row[_N]),end_ts=int(row[_O])),model=ModelRunMetrics(start_ts=wall_clock_seconds_to_ms(model_exec.start_ts),end_ts=wall_clock_seconds_to_ms(model_exec.end_ts),total_batches=model_exec.total_batches,evaluation_ms=model_exec.evaluation_ms,rows_affected=model_exec.rows_affected,bytes_processed=model_exec.bytes_processed),intervals=[ModelRunInterval(start_ts=interval.start_ts,end_ts=interval.end_ts,evaluation_ms=interval.evaluation_ms,rows_affected=interval.rows_affected)for interval in model_exec.intervals]))
		return activities
	async def list_runs(self,run_id:t.Optional[str]=_A,environment:t.Optional[str]=_A,model_names:t.Optional[t.List[str]]=_A,success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,plan_id:t.Optional[str]=_A,plan_seq:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[RunActivityWithChecksAndProfile]:
		runs_tbl=self._tbl(ACTIVITY_RUNS.name);plans_tbl=self._tbl(ACTIVITY_PLANS.name);checks_tbl=self._tbl(DQ_RESULTS.name);defs_tbl=self._tbl(DQ_DEFINITIONS.name);profiles_tbl=self._tbl(DQ_PROFILES.name);start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A;params:t.List[t.Any]=[];idx=1;where_parts:t.List[str]=[];limit_sql=''
		if run_id:where_parts.append(f"r.run_id = ${idx}");params.append(run_id);idx+=1
		else:
			if environment is _A:return[]
			where_parts.append(f"r.environment = ${idx}");params.append(environment);idx+=1
			if model_names:where_parts.append(f"r.models_affected && ${idx}");params.append(model_names);idx+=1
			if success is not _A:where_parts.append(f"r.success = ${idx}");params.append(success);idx+=1
			if start_ms is not _A:where_parts.append(f"r.start_ts >= ${idx}");params.append(start_ms);idx+=1
			if end_ms is not _A:where_parts.append(f"r.start_ts <= ${idx}");params.append(end_ms);idx+=1
			if plan_id is not _A:where_parts.append(f"r.plan_id = ${idx}");params.append(plan_id);idx+=1
			if plan_seq is not _A:where_parts.append(f"r.plan_id IN (SELECT plan_id FROM {plans_tbl} WHERE environment = ${idx} AND plan_seq = ${idx+1})");params.extend([environment,plan_seq]);idx+=2
			limit_sql=f"LIMIT ${idx} OFFSET ${idx+1}";params.extend([limit,offset]);idx+=2
		where_sql=_P.join(where_parts);qc_model_filter=f" AND cd.model_name = ANY(${idx})"if model_names else'';pm_model_filter=f" AND model_name = ANY(${idx+(1 if model_names else 0)})"if model_names else''
		if model_names:params.extend([model_names,model_names])
		query=f"""
        WITH runs AS (
            SELECT r.run_data, r.run_seq, r.run_id, r.start_ts, p.plan_seq, p.version AS plan_version
            FROM {runs_tbl} r
            LEFT JOIN {plans_tbl} p
                ON r.plan_id = p.plan_id
            WHERE {where_sql}
            ORDER BY r.start_ts DESC
            {limit_sql}
        ),
        quality_checks AS (
            SELECT cr.run_id, cd.model_name, cd.dimension, cr.check_identity,
                   cd.check_name, cd.check_type, cd.column_name,
                   cr.outcome, cr.outcome_reasons, cr.diagnostics, cd.definition
            FROM {checks_tbl} cr
            INNER JOIN {defs_tbl} cd
                ON cr.check_identity = cd.check_identity AND cr.environment = cd.environment
            WHERE cr.run_id IN (SELECT run_id FROM runs){qc_model_filter}
            ORDER BY cr.run_id, cd.model_name, cd.dimension, cd.check_name
        ),
        profile_metrics AS (
            SELECT run_id, model_name, column_name, profile_type,
                   value_text, value_number, value_json, value_type
            FROM {profiles_tbl}
            WHERE run_id IN (SELECT run_id FROM runs){pm_model_filter}
            ORDER BY run_id, model_name, column_name, profile_type
        )
        SELECT
            r.run_data,
            r.run_seq,
            r.plan_seq,
            r.plan_version,
            (
                SELECT COALESCE(
                    jsonb_agg(jsonb_build_object(
                        'model_name', qc.model_name, 'dimension', qc.dimension,
                        'check_identity', qc.check_identity, 'check_name', qc.check_name,
                        'check_type', qc.check_type, 'column_name', qc.column_name,
                        'outcome', qc.outcome, 'outcome_reasons', qc.outcome_reasons,
                        'diagnostics', qc.diagnostics, 'definition', qc.definition
                    ) ORDER BY qc.model_name, qc.dimension, qc.check_name),
                    '[]'::jsonb
                )
                FROM quality_checks qc WHERE qc.run_id = r.run_id
            ) AS quality_checks,
            (
                SELECT COALESCE(
                    jsonb_agg(jsonb_build_object(
                        'model_name', pm.model_name, 'column_name', pm.column_name,
                        'profile_type', pm.profile_type, 'value_text', pm.value_text,
                        'value_number', pm.value_number, 'value_json', pm.value_json,
                        'value_type', pm.value_type
                    ) ORDER BY pm.model_name, pm.column_name, pm.profile_type),
                    '[]'::jsonb
                )
                FROM profile_metrics pm WHERE pm.run_id = r.run_id
            ) AS profile_metrics
        FROM runs r
        ORDER BY r.start_ts DESC
        """;rows=await self._conn.fetch_rows(query,*params)
		if not rows:return[]
		result=[]
		for row in rows:
			run_data=row[_S];seq=row[_B];quality_data=_json_list(row[_W]);profile_data=_json_list(row[_X]);run=RunActivity.model_validate(run_data).model_copy(update={_B:seq,_C:row.get(_C)})
			if model_names:models_set=set(model_names);run=run.model_copy(update={_R:[m for m in run.models_affected if m.name in models_set]})
			result.append(RunActivityWithChecksAndProfile(**run.model_dump(exclude_none=_F),plan_version=row.get(_Q),quality=_build_quality_list(quality_data),profile=_build_profile_list(profile_data)))
		return result
	async def get_run(self,run_id:str)->t.Optional[RunActivityWithChecksAndProfile]:runs=await self.list_runs(run_id=run_id);return runs[0]if runs else _A
	async def list_latest_runs_by_model(self,environment:str,model_names:t.List[str])->t.Dict[str,RunActivityWithChecksAndProfile]:
		if not environment or not model_names:return{}
		runs_tbl=self._tbl(ACTIVITY_RUNS.name);plans_tbl=self._tbl(ACTIVITY_PLANS.name);checks_tbl=self._tbl(DQ_RESULTS.name);defs_tbl=self._tbl(DQ_DEFINITIONS.name);profiles_tbl=self._tbl(DQ_PROFILES.name);query=f"""
        WITH expanded AS (
            SELECT r.run_data, r.run_seq, r.run_id, r.start_ts, model_name, p.plan_seq,
                p.version AS plan_version,
                ROW_NUMBER() OVER (PARTITION BY model_name ORDER BY r.start_ts DESC) AS rn
            FROM {runs_tbl} r
            LEFT JOIN {plans_tbl} p
                ON r.plan_id = p.plan_id
            CROSS JOIN LATERAL unnest(r.models_affected) AS model_name
            WHERE r.environment = $1
              AND r.models_affected IS NOT NULL
              AND model_name = ANY($2)
        ),
        latest AS (
            SELECT run_data, run_seq, run_id, model_name, plan_seq, plan_version FROM expanded WHERE rn = 1
        ),
        quality_checks AS (
            SELECT cr.run_id, cd.model_name, cd.dimension, cr.check_identity,
                   cd.check_name, cd.check_type, cd.column_name,
                   cr.outcome, cr.outcome_reasons, cr.diagnostics, cd.definition
            FROM {checks_tbl} cr
            INNER JOIN {defs_tbl} cd
                ON cr.check_identity = cd.check_identity AND cr.environment = cd.environment
            WHERE cr.run_id IN (SELECT run_id FROM latest) AND cd.model_name = ANY($3)
            ORDER BY cr.run_id, cd.model_name, cd.dimension, cd.check_name
        ),
        profile_metrics AS (
            SELECT run_id, model_name, column_name, profile_type,
                   value_text, value_number, value_json, value_type
            FROM {profiles_tbl}
            WHERE run_id IN (SELECT run_id FROM latest) AND model_name = ANY($4)
            ORDER BY run_id, model_name, column_name, profile_type
        )
        SELECT
            l.model_name, l.run_data, l.run_seq, l.plan_seq, l.plan_version,
            (
                SELECT COALESCE(
                    jsonb_agg(jsonb_build_object(
                        'model_name', qc.model_name, 'dimension', qc.dimension,
                        'check_identity', qc.check_identity, 'check_name', qc.check_name,
                        'check_type', qc.check_type, 'column_name', qc.column_name,
                        'outcome', qc.outcome, 'outcome_reasons', qc.outcome_reasons,
                        'diagnostics', qc.diagnostics, 'definition', qc.definition
                    ) ORDER BY qc.dimension, qc.check_name),
                    '[]'::jsonb
                )
                FROM quality_checks qc
                WHERE qc.run_id = l.run_id AND qc.model_name = l.model_name
            ) AS quality_checks,
            (
                SELECT COALESCE(
                    jsonb_agg(jsonb_build_object(
                        'model_name', pm.model_name, 'column_name', pm.column_name,
                        'profile_type', pm.profile_type, 'value_text', pm.value_text,
                        'value_number', pm.value_number, 'value_json', pm.value_json,
                        'value_type', pm.value_type
                    ) ORDER BY pm.column_name, pm.profile_type),
                    '[]'::jsonb
                )
                FROM profile_metrics pm
                WHERE pm.run_id = l.run_id AND pm.model_name = l.model_name
            ) AS profile_metrics
        FROM latest l
        """;rows=await self._conn.fetch_rows(query,environment,model_names,model_names,model_names)
		if not rows:return{}
		result:t.Dict[str,RunActivityWithChecksAndProfile]={}
		for row in rows:model_name=row[_D];run_data=row[_S];seq=row[_B];quality_data=_json_list(row[_W]);profile_data=_json_list(row[_X]);run=RunActivity.model_validate(run_data).model_copy(update={_B:seq,_C:row.get(_C)});run=run.model_copy(update={_R:[m for m in run.models_affected or[]if m.name==model_name]});result[model_name]=RunActivityWithChecksAndProfile(**run.model_dump(exclude_none=_F),plan_version=row.get(_Q),quality=_build_quality_list(quality_data),profile=_build_profile_list(profile_data))
		return result