from __future__ import annotations
_C='Stored follow metadata'
_B='Follow time (Unix ms)'
_A=None
import typing as t
from pydantic import Field as PydanticField
from api.schemas.common import Pagination
from vulcan.utils.pydantic import PydanticModel
class FollowRequest(PydanticModel):metadata:t.Optional[t.Dict[str,t.Any]]=PydanticField(default=_A,description='Optional metadata stored with the follow')
class FollowStatus(PydanticModel):is_follower:bool=PydanticField(description='True when the user follows this product');user_id:str=PydanticField(description='Subject user ID');active:t.Optional[bool]=PydanticField(default=_A,description='Whether follow is active');followed_at:t.Optional[int]=PydanticField(default=_A,description=_B);metadata:t.Optional[t.Dict[str,t.Any]]=PydanticField(default=_A,description=_C)
class FollowerListItem(PydanticModel):user_id:str=PydanticField(description='Follower user ID');followed_at:int=PydanticField(description=_B);metadata:t.Dict[str,t.Any]=PydanticField(default_factory=dict,description=_C)
class FollowersListResponse(PydanticModel):followers:t.List[FollowerListItem]=PydanticField(description='Followers on this page');total:int=PydanticField(description='Total followers across all pages');pagination:Pagination=PydanticField(description='Pagination metadata')