from __future__ import annotations
_G='measures'
_F='UTC'
_E='time'
_D='type'
_C='timeDimensions'
_B='dimensions'
_A=None
import datetime as dt,typing as t
from zoneinfo import ZoneInfo,ZoneInfoNotFoundError
from api.endpoints.query.graphql.query import _TIMEZONE_ALIASES,uncapitalize
from schema.rest_query import RestQuery
_timezone_cache:dict[str,str|_A]={}
def validate_and_normalize_timezone(timezone:str)->str|_A:
	if not timezone or not isinstance(timezone,str):return
	trimmed=timezone.strip()
	if trimmed in _timezone_cache:return _timezone_cache[trimmed]
	alias=_TIMEZONE_ALIASES.get(trimmed.upper())
	if alias:_timezone_cache[trimmed]=alias;return alias
	try:ZoneInfo(trimmed);_timezone_cache[trimmed]=trimmed;return trimmed
	except ZoneInfoNotFoundError:_timezone_cache[trimmed]=_A;return
def format_datetime_iso_z(value:dt.datetime)->str:utc=value.astimezone(dt.timezone.utc);millis=utc.microsecond//1000;return utc.strftime('%Y-%m-%dT%H:%M:%S.')+f"{millis:03d}Z"
def resolve_timezone(query_timezone:str|_A,fallback_timezone:str|_A,default_timezone:str|_A)->str:
	for candidate in(query_timezone,fallback_timezone,default_timezone,_F):
		if not candidate:continue
		valid=validate_and_normalize_timezone(candidate)
		if valid:return valid
	return _F
def format_row_dates_in_place(rows:list[dict[str,t.Any]],annotation:dict[str,dict[str,t.Any]],query_timezone:str|_A,fallback_timezone:str|_A,default_timezone:str|_A)->_A:
	if not rows:return
	timezone_name=resolve_timezone(query_timezone,fallback_timezone,default_timezone);tz=ZoneInfo(timezone_name);date_keys=[key for(key,meta)in{**annotation.get(_B,{}),**annotation.get(_G,{}),**annotation.get(_C,{})}.items()if meta.get(_D)==_E]
	if not date_keys:return
	for row in rows:
		for key in date_keys:
			value=row.get(key)
			if value is _A:continue
			try:
				if isinstance(value,str):from dateutil import parser as date_parser;parsed=date_parser.isoparse(value)
				else:parsed=value
				if getattr(parsed,'tzinfo',_A)is _A:parsed=parsed.replace(tzinfo=ZoneInfo(_F))
				row[key]=format_datetime_iso_z(parsed.astimezone(tz))
			except Exception:continue
def build_result_annotation(types:list[dict[str,str]])->dict[str,dict[str,dict[str,str]]]:
	C='boolean';B='number';A='string';annotation:dict[str,dict[str,dict[str,str]]]={_B:{},_G:{},_C:{}};granularities='second','minute','hour','day','week','month','quarter','year'
	for type_info in types:
		name=type_info['name'];sql_type=type_info.get(_D,A).lower()
		if sql_type in('integer','bigint','float','double','decimal',B):graphql_type=B
		elif sql_type in('timestamp','datetime','date'):graphql_type=_E
		elif sql_type in(C,'bool'):graphql_type=C
		else:graphql_type=A
		has_granularity=graphql_type==_E and any(name.endswith(f".{g}")for g in granularities);bucket=_C if has_granularity else _B;annotation[bucket][name]={_D:graphql_type,'title':name}
	return annotation
def columnar_to_rows(cols:list[str],rows:list[list[t.Any]])->list[dict[str,t.Any]]:return[dict(zip(cols,row))for row in rows]
def expected_result_columns(rest_query:RestQuery)->list[str]:
	columns:list[str]=[];columns.extend(rest_query.measures or[]);columns.extend(rest_query.dimensions or[])
	for td in rest_query.timeDimensions or[]:
		dimension=td.dimension;granularity=td.granularity
		if granularity:columns.append(f"{dimension}.{granularity}")
		else:columns.append(dimension)
	return columns
def missing_result_columns(rest_query:RestQuery,annotation:dict[str,dict[str,dict[str,str]]])->list[str]:annotated={**annotation.get(_B,{}),**annotation.get(_G,{}),**annotation.get(_C,{})};return[column for column in expected_result_columns(rest_query)if column not in annotated]
def nest_table_rows(flat_rows:list[dict[str,t.Any]],annotation:dict[str,dict[str,dict[str,str]]])->list[dict[str,t.Any]]:
	dimensions=annotation.get(_B,{});nested:list[dict[str,t.Any]]=[]
	for entry in flat_rows:
		result:dict[str,t.Any]={}
		for(key,value)in entry.items():
			path=key.split('.')if'.'in key else[key]
			if path:path[0]=uncapitalize(path[0])
			if dimensions.get(key,{}).get(_D)==_E:path=[*path,'value']
			target=result
			for segment in path[:-1]:target=target.setdefault(segment,{})
			target[path[-1]]=value
		nested.append(result)
	return nested