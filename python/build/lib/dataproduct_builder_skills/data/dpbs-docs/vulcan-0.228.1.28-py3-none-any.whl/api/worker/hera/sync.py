from __future__ import annotations
_V='prod_only'
_U='environment'
_T='query_type'
_S='columns'
_R='description'
_Q='table'
_P='tags'
_O='unknown'
_N='prod'
_M='reason'
_L='semantic'
_K='schema.type.basic'
_J='name'
_I='metric'
_H=False
_G='schema.type.entityLineage'
_F='_EntriesIndex'
_E='skipped'
_D='_HeraDomainInfo'
_C='.'
_B=True
_A=None
import logging,os,typing as t
from collections import defaultdict
from schema.metadata import ColumnEntry,Metadata,ModelEntry
from api.pool import run_blocking_fast,run_blocking_heavy
from api.state.activity import AsyncActivityState
from api.state.query import AsyncQueryState
from vulcan.core.config import Config
from vulcan.core.config.hera import HeraConfig
from vulcan.core.context import Context
from vulcan.core.query.definitions import QueryResultLineage,QueryType,SEMANTIC_QUERY_TYPES
from.utils import _column_tag_labels,_hera_generated_schema,_logical_to_wire_dtype,_schema_mod,attach_column_tags,attach_data_product_assets,attach_tenant_to_data_product,attach_tags,attach_tenant_to_service,data_product_name,collect_column_tags,create_hera_client,ensure_alignment_tags,ensure_data_product,ensure_db_schema,ensure_domain,ensure_source_service,ensure_vulcan_service,is_prod,normalize,parse_fqn,resolve_connection_kind_for_hera,resolve_owner_refs,resolve_user_owner_ref,result_columns_for_hera,sanitize,source_depot_name,source_service_name,step,update_data_product_status,associate_domain,entity_tags,vulcan_service_name
logger=logging.getLogger(__name__)
def canonical_dep_ref(dep:t.Any)->t.Optional[str]:
	raw=sanitize(str(dep or''))
	if not raw:return
	return raw.replace('"','').replace("'",'')
def _entry_dep_fqns(entry:ModelEntry,mctx:_F)->list[str]:return[mctx._name_fqn.get(dep,dep)for dep in entry.depends_on if dep]
def _is_semantic_query(query_type:QueryType)->bool:return query_type in SEMANTIC_QUERY_TYPES
class _EntriesIndex:
	def __init__(self,entries:t.Sequence[ModelEntry])->_A:self._by_name={e.name:e for e in entries if e.name};self._by_fqn={e.fqn:e for e in entries if e.fqn};self._name_fqn={e.name:e.fqn for e in entries if e.name and e.fqn}
	@classmethod
	def from_entries(cls,entries:t.Sequence[ModelEntry])->_F:return cls(entries)
	def by_name(self,name:str)->t.Optional[ModelEntry]:return self._by_name.get(name)
	def by_fqn(self,fqn:str)->t.Optional[ModelEntry]:return self._by_fqn.get(fqn)
	def resolve_fqn(self,name:str)->str:return self._name_fqn.get(name,name)
def _column_entry_to_hera(col:ColumnEntry,ordinal:int,*,emit_pk:bool=_B)->dict[str,t.Any]:
	data_type,data_length=_logical_to_wire_dtype(col.ltype);result:dict[str,t.Any]={_J:col.name or _O,'dataType':data_type,'ordinalPosition':ordinal}
	if data_length is not _A:result['dataLength']=data_length
	if emit_pk and col.primary_key:result['constraint']='PRIMARY_KEY'
	if col.description:result[_R]=col.description
	tags=_column_tag_labels(col.tags,col.terms)
	if tags:result[_P]=tags
	return result
def _columns_to_hera(entry:ModelEntry)->list[dict[str,t.Any]]:cols=entry.columns;pk_count=sum(1 for c in cols if c.primary_key);emit_pk=pk_count<=1;return[_column_entry_to_hera(c,idx,emit_pk=emit_pk)for(idx,c)in enumerate(cols,start=1)]
def _lineage_identity_keys(node:t.Any)->list[str]:
	try:fqn=node.fqn
	except AttributeError:logger.warning('Hera lineage: %s has no fqn attribute; lineage may miss edges for this node',type(node).__name__);return[]
	except Exception:logger.warning('Hera lineage: failed to read fqn from %s',type(node).__name__,exc_info=_B);return[]
	if not fqn:return[]
	return _lineage_ref_keys(fqn)
def _connection_info(context:Context)->tuple[t.Optional[str],t.Optional[str]]:
	try:conn=context.config.get_connection()
	except Exception:return _A,_A
	connection_type=getattr(conn,'type_',_A)or getattr(conn,'type',_A);connection_uri=_A
	try:
		if hasattr(conn,'get_connection_uri'):connection_uri=conn.get_connection_uri()or _A
	except Exception:connection_uri=_A
	return connection_type,connection_uri
def _lineage_ref_keys(*values:t.Any)->list[str]:
	keys:list[str]=[]
	for value in values:
		key=canonical_dep_ref(value)
		if key and key not in keys:keys.append(key)
	return keys
def _phys_view_column_lineage(phys_fqn:str,view_fqn:str,entry:ModelEntry)->list[t.Any]:
	hr=_hera_generated_schema();mod=_schema_mod(_G);ColumnLineage=mod.ColumnLineage;FullyQualifiedEntityName=_schema_mod(_K).FullyQualifiedEntityName;lineages:list[t.Any]=[]
	for col in entry.columns:
		col_name=sanitize(col.name)
		if not col_name:continue
		lineages.append(ColumnLineage(fromColumns=[FullyQualifiedEntityName(root=f"{phys_fqn}.{col_name}")],toColumn=FullyQualifiedEntityName(root=f"{view_fqn}.{col_name}")))
	return lineages
async def _perspective_column_lineage_refs(query_state:AsyncQueryState,perspective:t.Any)->tuple[list[t.Any],QueryResultLineage,list[str]]:
	raw_columns:list[t.Any]=[];lineage=QueryResultLineage();output_columns:list[str]=[]
	if not getattr(perspective,'request_id',_A):return raw_columns,lineage,output_columns
	slug=getattr(perspective,'slug','perspective')
	try:
		request=await query_state.get_request_by_id(perspective.request_id)
		if request and getattr(request,'result_id',_A):
			result=await query_state.get_result_by_id(request.result_id)
			if result:raw_columns=result_columns_for_hera(result.columns);lineage=result.lineage or QueryResultLineage();output_columns=[str(col.get(_J))for col in getattr(result,_S,_A)or[]if isinstance(col,dict)and col.get(_J)];logger.debug('Loaded perspective result for %s: %d raw_columns, %d lineage columns, %d output_columns',slug,len(raw_columns),len(lineage.columns),len(output_columns));logger.debug('Output column names: %s',output_columns)
	except Exception as exc:logger.warning('Could not load perspective result for %s: %s',slug,exc)
	return raw_columns,lineage,output_columns
def _parse_member(name:str)->t.Optional[tuple[str,str]]:
	raw=sanitize(name)
	if not raw or _C not in raw:return
	model,_,field=raw.partition(_C);model,field=model.strip(),field.strip()
	if not model or not field:return
	return model,field
def _members_from_rest_query(rest_query:dict)->dict[str,tuple[str,str]]:
	mapping:dict[str,tuple[str,str]]={}
	for key in('measures','dimensions'):
		for member in rest_query.get(key)or[]:
			member_str=str(member)
			if _C in member_str:
				model,_,field=member_str.partition(_C);field_name=field.rpartition(_C)[-1]if _C in field else field;model,field_name=model.strip(),field_name.strip()
				if model and field_name:mapping[member_str]=model,field_name
	return mapping
def _members_from_semantic_sql(sql:str)->dict[str,tuple[str,str]]:
	A=' ';_SQL_KEYWORDS={'SELECT','FROM','WHERE','GROUP','BY','HAVING','ORDER','JOIN','ON','AND','OR','NOT','IN','AS','MEASURE','LIMIT','OFFSET','WITH','INNER','LEFT','RIGHT','OUTER'};mapping:dict[str,tuple[str,str]]={}
	for token in sql.replace('(',A).replace(')',A).replace(',',A).replace(';',A).split():
		token=token.strip().strip('"').strip("'")
		if _C in token and not token.startswith(_C)and not token.endswith(_C):
			model,_,field=token.partition(_C);field_name=field.rpartition(_C)[-1]if _C in field else field;model,field_name=model.strip(),field_name.strip()
			if model and field_name and model.upper()not in _SQL_KEYWORDS:mapping[token]=model,field_name
	return mapping
def _members_from_graphql(graphql:str)->dict[str,tuple[str,str]]:
	B='}';A='{';_SKIP={_Q,'query','mutation','subscription','limit','offset'};mapping:dict[str,tuple[str,str]]={};tokens=graphql.replace(A,' { ').replace(B,' } ').replace('(',' ( ').replace(')',' ) ').split();current_model:t.Optional[str]=_A
	for(i,tok)in enumerate(tokens):
		if tok==A and i>0:
			prev=tokens[i-1].strip()
			if prev and prev.lower()not in _SKIP and prev.isidentifier():current_model=prev
		elif tok==B:current_model=_A
		elif current_model and tok not in(A,B)and tok.lower()not in _SKIP and tok.isidentifier():mapping[f"{current_model}.{tok}"]=current_model,tok
	return mapping
def _get_member_mapping_from_perspective(perspective:t.Any)->dict[str,tuple[str,str]]:
	query_type=getattr(perspective,_T,_A)
	if query_type in(QueryType.SEMANTIC_REST,QueryType.SEMANTIC_METRIC):return _members_from_rest_query(getattr(perspective,'rest_query',_A)or{})
	if query_type==QueryType.SEMANTIC_SQL:return _members_from_semantic_sql(getattr(perspective,'semantic_query',_A)or'')
	if query_type==QueryType.SEMANTIC_GRAPHQL:return _members_from_graphql(getattr(perspective,'graphql_query',_A)or'')
	return{}
def _physical_parent_fqn(context:t.Any,info:_D,model_name:str)->t.Optional[str]:
	if not model_name or not info.source_svc_fqn:return
	try:model=context.get_model(model_name,raise_if_missing=_H)
	except Exception:model=_A
	physical_name=getattr(model,'fqn',_A)or model_name;db,schema,table=parse_fqn(physical_name,info.tenant,info.project);table=sanitize(table)
	if not table:return
	return f"{info.source_svc_fqn}.{sanitize(db)}.{sanitize(schema)}.{table}"
def _accumulate_physical_edges(grouped:'defaultdict[str, defaultdict[str, set[str]]]',depends_on:t.Optional[list[str]],lineage:QueryResultLineage,context:t.Any,info:_D)->_A:
	physical_cache:dict[str,t.Optional[str]]={}
	for dep in depends_on or[]:
		if not dep:continue
		if dep not in physical_cache:physical_cache[dep]=_physical_parent_fqn(context,info,dep)
		from_fqn=physical_cache[dep]
		if not from_fqn:continue
		if from_fqn not in grouped:grouped[from_fqn]
	for(to_col_name,upstreams)in lineage.columns.items():
		to_col=sanitize(to_col_name)
		if not to_col:continue
		for upstream in upstreams or[]:
			parent_name,parent_col=upstream.model,upstream.column
			if not parent_name or not parent_col:continue
			if parent_name not in physical_cache:physical_cache[parent_name]=_physical_parent_fqn(context,info,parent_name)
			from_fqn=physical_cache[parent_name]
			if not from_fqn:continue
			grouped[from_fqn][to_col].add(sanitize(str(parent_col)))
def _perspective_lineage_edges(query_type:QueryType,*,perspective_fqn:str,schema_fqn:str,output_columns:list[str],lineage:QueryResultLineage,depends_on:t.Optional[list[str]],member_mapping:dict[str,tuple[str,str]],context:t.Any,info:_D)->dict[str,list[t.Any]]:
	FullyQualifiedEntityName=_schema_mod(_K).FullyQualifiedEntityName;ColumnLineage=_schema_mod(_G).ColumnLineage;grouped:dict[str,dict[str,set[str]]]=defaultdict(lambda:defaultdict(set))
	if _is_semantic_query(query_type):
		if not schema_fqn:logger.debug('Semantic query but no schema_fqn provided');return{}
		if not member_mapping:logger.debug('No member mapping for semantic perspective %s (query_type=%s); no column edges',perspective_fqn,query_type);return{}
		logger.debug('Semantic lineage: schema_fqn=%s, member_mapping=%s',schema_fqn,member_mapping);covered_to_cols:set[str]=set()
		if query_type==QueryType.SEMANTIC_REST:member_to_output=list(member_mapping.items())
		else:members=list(member_mapping.values());member_to_output=[(output_col,members[i])for(i,output_col)in enumerate(output_columns)if i<len(members)]
		for(output_col,(model,field))in member_to_output:
			from_fqn=f"{schema_fqn}.{model}";to_col=f'"{output_col}"'if _C in output_col else sanitize(output_col);from_col=sanitize(field)
			if to_col and from_col:grouped[from_fqn][to_col].add(from_col);covered_to_cols.add(to_col)
		for(to_col_name,upstreams)in lineage.columns.items():
			to_col=f'"{to_col_name}"'if _C in to_col_name else sanitize(to_col_name)
			if not to_col or to_col in covered_to_cols:continue
			for upstream in upstreams or[]:
				parent_name,parent_col=upstream.model,upstream.column
				if not parent_name or not parent_col:continue
				from_fqn=f"{schema_fqn}.{parent_name}";grouped[from_fqn][to_col].add(sanitize(str(parent_col)))
	elif query_type==QueryType.SOURCE_SQL:_accumulate_physical_edges(grouped,depends_on,lineage,context,info)
	else:logger.debug('Skipping perspective lineage for unknown query_type=%s',query_type);return{}
	edges:dict[str,list[t.Any]]={}
	for(from_fqn,cols)in grouped.items():
		col_lineages:list[t.Any]=[]
		for(to_col,from_cols)in cols.items():
			from_col_fqns=[f"{from_fqn}.{c}"for c in sorted(from_cols)if c]
			if not from_col_fqns:continue
			col_lineages.append(ColumnLineage(fromColumns=[FullyQualifiedEntityName(root=c)for c in from_col_fqns],toColumn=FullyQualifiedEntityName(root=f"{perspective_fqn}.{to_col}")))
		edges[from_fqn]=col_lineages
	return edges
def _emit_perspective_lineage(hera:t.Any,*,perspective_fqn:str,query_type:QueryType,output_columns:list[str],lineage:QueryResultLineage,depends_on:t.Optional[list[str]],member_mapping:dict[str,tuple[str,str]],schema_fqn:str,context:t.Any,info:_D,entity_id_cache:t.Optional[dict[str,t.Optional[str]]]=_A)->_A:
	if not perspective_fqn:return
	logger.debug('Emitting perspective lineage: perspective_fqn=%s, query_type=%s, member_mapping=%s',perspective_fqn,query_type,member_mapping);edges=_perspective_lineage_edges(query_type,perspective_fqn=perspective_fqn,schema_fqn=schema_fqn,output_columns=output_columns,lineage=lineage,depends_on=depends_on,member_mapping=member_mapping,context=context,info=info);logger.debug('Perspective lineage edges: %s',{k:len(v)for(k,v)in edges.items()});cache=entity_id_cache if entity_id_cache is not _A else{}
	for(from_fqn,col_lineages)in edges.items():logger.debug('Adding lineage: %s -> %s (%d column lineages)',from_fqn,perspective_fqn,len(col_lineages)if col_lineages else 0);_add_lineage(hera,from_fqn,perspective_fqn,cache,columns_lineage=col_lineages or _A)
class _LineageCollector:
	def __init__(self,hera:t.Any,mctx:t.Optional[_F]=_A)->_A:self._hera=hera;(self._mctx):_EntriesIndex=mctx or _EntriesIndex.from_entries([]);(self._ref_to_fqn):dict[str,str]={};(self._disabled_keys):set[str]=set();(self._pending):list[tuple[str,list[str]]]=[];(self._entity_id_cache):dict[str,t.Optional[str]]={};(self._entries_for_columns):list[tuple[ModelEntry,str]]=[];(self._metrics_for_columns):list[tuple[ModelEntry,str]]=[]
	def register_entity(self,ref_keys:list[str],fqn:str)->_A:
		for ref_key in ref_keys:
			key=canonical_dep_ref(ref_key)
			if not key or key in self._disabled_keys:continue
			existing=self._ref_to_fqn.get(key)
			if existing and existing!=fqn:logger.warning('Lineage key collision for %s: %s vs %s; disabling key',key,existing,fqn);self._disabled_keys.add(key);self._ref_to_fqn.pop(key,_A);continue
			self._ref_to_fqn[key]=fqn
	def queue_edges(self,to_fqn:str,depends_on:t.Iterable[str])->_A:
		refs=[key for key in(canonical_dep_ref(dep)for dep in depends_on or[])if key]
		if refs:self._pending.append((to_fqn,refs))
	def queue_entry_column_lineage(self,entry:ModelEntry,hera_table_fqn:str)->_A:self._entries_for_columns.append((entry,hera_table_fqn))
	def queue_metric_column_lineage(self,entry:ModelEntry,hera_table_fqn:str)->_A:self._metrics_for_columns.append((entry,hera_table_fqn))
	def _column_lineage_maps_by_edge(self)->dict[tuple[str,str],list[t.Any]]:
		FullyQualifiedEntityName=_schema_mod(_K).FullyQualifiedEntityName;ColumnLineage=_schema_mod(_G).ColumnLineage;by_edge:dict[tuple[str,str],list[t.Any]]={}
		for(entry,to_hera)in self._entries_for_columns:
			allowed_parents=set(_entry_dep_fqns(entry,self._mctx))
			for col in entry.columns:
				merged:dict[str,set[str]]=defaultdict(set)
				for ref in col.depends_on:
					parent_name=ref.model;parent_col=ref.column
					if not parent_name or not parent_col:continue
					parent_fqn=self._mctx._name_fqn.get(parent_name,parent_name)
					if allowed_parents and parent_fqn not in allowed_parents:continue
					parent_key=canonical_dep_ref(parent_fqn);from_hera=self._ref_to_fqn.get(parent_key)if parent_key else _A
					if not from_hera:continue
					merged[from_hera].add(parent_col)
				to_col=sanitize(col.name)
				if not to_col:continue
				for(from_hera,parent_cols)in merged.items():
					from_col_fqns=[f"{from_hera}.{sanitize(pc)}"for pc in parent_cols if sanitize(str(pc))]
					if not from_col_fqns:continue
					entry_lineage=ColumnLineage(fromColumns=[FullyQualifiedEntityName(root=c)for c in from_col_fqns],toColumn=FullyQualifiedEntityName(root=f"{to_hera}.{to_col}"));by_edge.setdefault((from_hera,to_hera),[]).append(entry_lineage)
		self._merge_metric_column_lineage(by_edge);return by_edge
	def _merge_metric_column_lineage(self,by_edge:dict[tuple[str,str],list[t.Any]])->_A:
		FullyQualifiedEntityName=_schema_mod(_K).FullyQualifiedEntityName;ColumnLineage=_schema_mod(_G).ColumnLineage
		for(entry,to_hera)in self._metrics_for_columns:
			for col in entry.columns:
				col_name=sanitize(col.name)
				if not col_name:continue
				emitted=_H;fallback_sem_hera:t.Optional[str]=_A;fallback_sem_col:t.Optional[str]=_A
				for dep in col.depends_on:
					sem_name=dep.model;sem_col=dep.column
					if not sem_name or not sem_col:continue
					sem_fqn=self._mctx._name_fqn.get(sem_name,sem_name);sem_key=canonical_dep_ref(sem_fqn);sem_hera=self._ref_to_fqn.get(sem_key)if sem_key else _A
					if not sem_hera:continue
					fallback_sem_hera=sem_hera;fallback_sem_col=str(sem_col);sem_entry=self._mctx.by_name(sem_name)
					if sem_entry is _A:continue
					sem_col_entry=next((c for c in sem_entry.columns if c.name==sem_col),_A)
					if sem_col_entry is _A:continue
					for phys_dep in sem_col_entry.depends_on:
						phys_model=phys_dep.model;phys_col=phys_dep.column
						if not phys_model or not phys_col:continue
						phys_fqn=self._mctx._name_fqn.get(str(phys_model),str(phys_model));pk=canonical_dep_ref(phys_fqn);phys_hera=self._ref_to_fqn.get(pk)if pk else _A
						if not phys_hera:continue
						edge=ColumnLineage(fromColumns=[FullyQualifiedEntityName(root=f"{phys_hera}.{sanitize(str(phys_col))}")],toColumn=FullyQualifiedEntityName(root=f"{to_hera}.{col_name}"));by_edge.setdefault((phys_hera,to_hera),[]).append(edge);emitted=_B
				if not emitted and fallback_sem_hera and fallback_sem_col:edge=ColumnLineage(fromColumns=[FullyQualifiedEntityName(root=f"{fallback_sem_hera}.{sanitize(fallback_sem_col)}")],toColumn=FullyQualifiedEntityName(root=f"{to_hera}.{col_name}"));by_edge.setdefault((fallback_sem_hera,to_hera),[]).append(edge)
	def _entity_id_for_fqn(self,fqn:str)->t.Optional[str]:
		if fqn in self._entity_id_cache:return self._entity_id_cache[fqn]
		hr=_hera_generated_schema()
		try:entity=self._hera.get_by_name(entity=hr.Table,fqn=fqn)
		except Exception:entity=_A
		if not entity or not getattr(entity,'id',_A):self._entity_id_cache[fqn]=_A;return
		entity_id=entity.id.root if hasattr(entity.id,'root')else entity.id;self._entity_id_cache[fqn]=entity_id;return entity_id
	def flush(self)->_A:
		edge_columns=self._column_lineage_maps_by_edge();emitted_pairs:set[tuple[str,str]]=set()
		def _emit(from_fqn:str,to_fqn:str,col_maps:t.Optional[list[t.Any]])->_A:emitted_pairs.add((from_fqn,to_fqn));_add_lineage(self._hera,from_fqn,to_fqn,self._entity_id_cache,columns_lineage=col_maps)
		for(to_fqn,refs)in self._pending:
			to_id=self._entity_id_for_fqn(to_fqn)
			if not to_id:logger.warning('Lineage downstream not created: %s',to_fqn);continue
			for ref in refs:
				from_fqn=self._ref_to_fqn.get(ref)
				if not from_fqn:logger.warning('Lineage upstream ref unresolvable: %s -> %s',ref,to_fqn);continue
				from_id=self._entity_id_for_fqn(from_fqn)
				if not from_id:logger.warning('Lineage upstream table not present in Hera: %s (edge to %s)',from_fqn,to_fqn);continue
				col_maps=edge_columns.get((from_fqn,to_fqn));_emit(from_fqn,to_fqn,col_maps)
		for(from_fqn,to_fqn)in sorted(edge_columns.keys()):
			if(from_fqn,to_fqn)in emitted_pairs:continue
			col_maps=edge_columns[from_fqn,to_fqn]
			if not col_maps:continue
			if not self._entity_id_for_fqn(from_fqn)or not self._entity_id_for_fqn(to_fqn):logger.warning('Lineage column-only upstream/downstream missing for %s -> %s',from_fqn,to_fqn);continue
			_emit(from_fqn,to_fqn,col_maps)
def _hera_table_entity_id(hera:t.Any,hr:t.Any,table_fqn:str,entity_id_cache:dict[str,t.Optional[str]])->t.Optional[str]:
	if table_fqn not in entity_id_cache:
		table=hera.get_by_name(entity=hr.Table,fqn=table_fqn);tid=_A
		if table and getattr(table,'id',_A):tid=table.id.root if hasattr(table.id,'root')else table.id
		entity_id_cache[table_fqn]=tid
	return entity_id_cache.get(table_fqn)
def _add_lineage(hera:t.Any,from_fqn:str,to_fqn:str,entity_id_cache:t.Optional[dict[str,t.Optional[str]]]=_A,*,columns_lineage:t.Optional[list[t.Any]]=_A)->_A:
	mod_el=_schema_mod(_G);LineageDetails,Source=mod_el.LineageDetails,mod_el.Source;hr=_hera_generated_schema();cache=entity_id_cache or{};from_table_id=_hera_table_entity_id(hera,hr,from_fqn,cache);to_table_id=_hera_table_entity_id(hera,hr,to_fqn,cache)
	if not from_table_id:return
	if not to_table_id:return
	lineage_kwargs:dict[str,t.Any]={'fromEntity':hr.EntityReference(id=from_table_id,type=_Q),'toEntity':hr.EntityReference(id=to_table_id,type=_Q)}
	if columns_lineage:lineage_kwargs['lineageDetails']=LineageDetails(columnsLineage=columns_lineage,source=Source.Manual)
	try:hera.add_lineage(data=hr.AddLineageRequest(edge=hr.EntitiesEdge(**lineage_kwargs)),check_patch=_H)
	except Exception as exc:logger.warning('Lineage %s -> %s failed: %s',from_fqn,to_fqn,exc)
def _create_table(hera:t.Any,*,entry:t.Optional[ModelEntry]=_A,table_name:t.Optional[str]=_A,schema_fqn:str,columns:t.Optional[list[t.Any]]=_A,description:str='',table_type:t.Any=_A,display_name:t.Optional[str]=_A,owners:t.Optional[list[t.Any]]=_A,is_public:t.Optional[bool]=_A)->t.Optional[tuple[str,t.Any]]:
	A='isPublic';hr=_hera_generated_schema()
	def _column_payload(item:t.Any)->dict[str,t.Any]:
		if isinstance(item,dict):return dict(item)
		if hasattr(item,'model_dump'):return t.cast(dict[str,t.Any],item.model_dump())
		if hasattr(item,'dict'):return t.cast(dict[str,t.Any],item.dict())
		return{k:v for(k,v)in getattr(item,'__dict__',{}).items()if not k.startswith('_')}
	if entry is not _A:columns=_columns_to_hera(entry);table_name=entry.name or table_name;description=(entry.description or description)or''
	else:columns=[_column_payload(col)for col in columns or[]]
	try:
		kwargs:dict[str,t.Any]={_J:hr.EntityName(sanitize(table_name or _O)),'databaseSchema':hr.FullyQualifiedEntityName(schema_fqn),_S:[hr.Column(**{k:v for(k,v)in column.items()if k!=_P})for column in columns],_R:description or''}
		if table_type is not _A:kwargs['tableType']=table_type
		if display_name and table_type==_hera_generated_schema().TableType.Perspective:kwargs['displayName']=display_name
		if owners:kwargs['owners']=owners
		if is_public is not _A:kwargs[A]=is_public
		entity=hera.create_or_update(data=hr.CreateTableRequest(**kwargs))
		if not owners:
			try:hera.patch_owner(entity=hr.Table,source=entity,owners=_A,force=_B)
			except Exception as exc:logger.debug("Could not clear owner on '%s': %s",table_name,exc)
		if is_public is not _A:
			current_is_public=getattr(entity,A,_A)
			if current_is_public!=is_public:
				try:destination=entity.model_copy(update={A:is_public});hera.patch(entity=hr.Table,source=entity,destination=destination,allowed_fields={A:_B},override_metadata=_B)
				except Exception as exc:logger.debug("Could not patch isPublic on '%s': %s",table_name,exc)
		return entity.fullyQualifiedName.root,entity
	except Exception as exc:logger.warning("Failed to create table '%s' in %s: %s",table_name or(entry.name if entry else _O),schema_fqn,exc);return
def _sync_source_tables(hera:t.Any,mctx:_F,entries:t.Sequence[ModelEntry],service_fqn:str,default_db:str,default_schema:str,domain_fqn:t.Optional[str]=_A,lineage:t.Optional[_LineageCollector]=_A)->tuple[list[str],dict[str,str],dict[str,ModelEntry]]:
	fqns:list[str]=[];phys_to_view:dict[str,str]={};phys_to_entry:dict[str,ModelEntry]={};schema_cache:dict[tuple[str,str,str],str]={}
	for entry in entries:
		table=entry.table;owner_ref=resolve_user_owner_ref(hera,entry.owner);lineage_fqn=_A
		if table and table.physical:
			phys_db,phys_schema,phys_table=parse_fqn(table.physical.name,default_db,default_schema);phys_cache_key=service_fqn,phys_db,phys_schema
			if phys_cache_key not in schema_cache:
				schema_fqn=step('source_schema_physical',lambda:ensure_db_schema(hera,service_fqn,database_name=phys_db,schema_name=phys_schema,domain_fqn=domain_fqn))
				if not schema_fqn:continue
				schema_cache[phys_cache_key]=schema_fqn
			phys_schema_fqn=schema_cache[phys_cache_key];phys_table_fqn=f"{phys_schema_fqn}.{sanitize(phys_table)}"
			if entry.kind=='EXTERNAL':
				try:existing=hera.get_by_name(entity=_hera_generated_schema().Table,fqn=phys_table_fqn)
				except Exception as exc:logger.debug("Could not fetch external table '%s' from Hera: %s",phys_table_fqn,exc);existing=_A
				if existing:phys_fqn=phys_table_fqn;phys_entity=existing
				else:
					created=_create_table(hera,table_name=phys_table,schema_fqn=phys_schema_fqn,columns=_columns_to_hera(entry),description=entry.description or'',owners=owner_ref)
					if not created:continue
					phys_fqn,phys_entity=created
			else:
				created=_create_table(hera,table_name=phys_table,schema_fqn=phys_schema_fqn,columns=_columns_to_hera(entry),description=entry.description or'',owners=owner_ref)
				if not created:continue
				phys_fqn,phys_entity=created
			fqns.append(phys_fqn);phys_to_entry[phys_fqn]=entry;attach_tags(hera,phys_entity,entity_tags(entry.tags,entry.terms));attach_column_tags(hera,phys_entity,collect_column_tags(phys_fqn,_columns_to_hera(entry)))
			if table.virtual:
				view_db,view_schema,view_table=parse_fqn(table.virtual.name,default_db,default_schema);view_cache_key=service_fqn,view_db,view_schema
				if view_cache_key not in schema_cache:
					schema_fqn=step('source_schema_virtual',lambda:ensure_db_schema(hera,service_fqn,database_name=view_db,schema_name=view_schema,domain_fqn=domain_fqn))
					if not schema_fqn:continue
					schema_cache[view_cache_key]=schema_fqn
				created=_create_table(hera,table_name=view_table,schema_fqn=schema_cache[view_cache_key],columns=_columns_to_hera(entry),description=entry.description or'',table_type=_hera_generated_schema().TableType.View,owners=owner_ref)
				if not created:continue
				view_fqn,view_entity=created;fqns.append(view_fqn);phys_to_view[phys_fqn]=view_fqn;lineage_fqn=view_fqn;attach_tags(hera,view_entity,entity_tags(entry.tags,entry.terms));attach_column_tags(hera,view_entity,collect_column_tags(view_fqn,_columns_to_hera(entry)))
			else:lineage_fqn=phys_fqn
		else:logger.warning("Skipping entry '%s': no table.physical metadata available.",entry.name);continue
		if lineage and lineage_fqn:lineage.register_entity(_lineage_ref_keys(entry.fqn),lineage_fqn);lineage.queue_edges(lineage_fqn,_entry_dep_fqns(entry,mctx));lineage.queue_entry_column_lineage(entry,lineage_fqn)
	return fqns,phys_to_view,phys_to_entry
def _sync_physical_to_view_lineage(hera:t.Any,phys_to_view:dict[str,str],phys_to_entry:dict[str,ModelEntry])->_A:
	if not phys_to_view:return
	for(phys_fqn,view_fqn)in phys_to_view.items():
		entry=phys_to_entry.get(phys_fqn)
		if not entry:continue
		lineage=_phys_view_column_lineage(phys_fqn,view_fqn,entry)
		if lineage:_add_lineage(hera,phys_fqn,view_fqn,columns_lineage=lineage)
_TABLE_TYPE_MAP:dict[str,str]={_L:'Semantic',_I:'BusinessMetric'}
def _sync_typed_entries(hera:t.Any,mctx:_F,schema_fqn:str,entries:t.Sequence[ModelEntry],*,source_type:str,lineage:t.Optional[_LineageCollector]=_A)->list[str]:
	hr=_hera_generated_schema();table_type=getattr(hr.TableType,_TABLE_TYPE_MAP[source_type]);fqns:list[str]=[]
	for entry in entries:
		created=_create_table(hera,entry=entry,schema_fqn=schema_fqn,table_type=table_type,owners=resolve_user_owner_ref(hera,entry.owner))
		if not created:continue
		fqn,entity=created;fqns.append(fqn)
		if lineage:
			lineage.register_entity(_lineage_ref_keys(entry.fqn),fqn);lineage.queue_edges(fqn,_entry_dep_fqns(entry,mctx))
			if source_type==_I:lineage.queue_metric_column_lineage(entry,fqn)
			else:lineage.queue_entry_column_lineage(entry,fqn)
		attach_tags(hera,entity,entity_tags(entry.tags,entry.terms));attach_column_tags(hera,entity,collect_column_tags(fqn,_columns_to_hera(entry)))
	return fqns
async def _sync_perspectives(hera:t.Any,schema_fqn:str,query_state:AsyncQueryState,context:t.Any,info:_D,current_user_id:str='',entity_id_cache:t.Optional[dict[str,t.Optional[str]]]=_A)->list[str]:
	fqns:list[str]=[]
	if not hasattr(query_state,'list_perspectives'):return fqns
	offset=0;_MAX_PAGES=1000;page=0
	while _B:
		if page>=_MAX_PAGES:logger.warning('Perspective pagination exceeded %d pages (offset=%d); aborting to prevent runaway loop — check Hera state.',_MAX_PAGES,offset);break
		page+=1
		try:perspectives,has_more=await query_state.list_perspectives(current_user_id=current_user_id or'',is_public=_A,limit=100,offset=offset)
		except Exception as exc:logger.warning('Could not list perspectives for Hera sync: %s',exc);break
		if not perspectives:break
		for perspective in perspectives:
			fqn=await _sync_one_perspective(hera,context,query_state,perspective,schema_fqn,info,entity_id_cache)
			if fqn:fqns.append(fqn)
		if not has_more:break
		offset+=len(perspectives)
	return fqns
def _hera_client(hera_cfg:HeraConfig)->t.Any:return create_hera_client(url=hera_cfg.url,token=hera_cfg.token.get_secret_value(),verify_ssl=hera_cfg.verify_ssl)
class _HeraDomainInfo(t.NamedTuple):tenant:str;project:str;domain_fqn:t.Optional[str];source_svc_fqn:t.Optional[str];vulcan_svc_fqn:t.Optional[str];schema_fqn:t.Optional[str]
def _hera_domain_and_vulcan_schema(hera:t.Any,product:Config,connection_type:t.Optional[str],connection_uri:t.Optional[str])->_D:
	tenant=normalize(product.tenant);project=normalize(product.project or product.name);domain_name=normalize(product.domain);ensure_alignment_tags(hera);domain_fqn=step('domain',lambda:ensure_domain(hera,domain_name))if domain_name else _A;vulcan_api_url=os.getenv('VULCAN_API_URL','http://localhost:8000');source_svc_fqn=_A
	if connection_uri:
		source_svc_fqn=step('source_service',lambda:ensure_source_service(hera,source_service_name(connection_uri,connection_type),resolve_connection_kind_for_hera(connection_type),tenant_name=tenant,depot=source_depot_name()))
		if source_svc_fqn:step('source_service_tenant',lambda:attach_tenant_to_service(hera,source_svc_fqn,tenant))
	vulcan_svc_fqn=step('vulcan_service',lambda:ensure_vulcan_service(hera,tenant,project,vulcan_api_url,display_name=product.display_name,tenant_name=tenant));schema_fqn=_A
	if vulcan_svc_fqn:schema_fqn=step('vulcan_schema',lambda:ensure_db_schema(hera,vulcan_svc_fqn,database_name=tenant,schema_name=project,domain_fqn=domain_fqn))
	return _HeraDomainInfo(tenant=tenant,project=project,domain_fqn=domain_fqn,source_svc_fqn=source_svc_fqn,vulcan_svc_fqn=vulcan_svc_fqn,schema_fqn=schema_fqn)
async def _snapshot_catalog(hera:t.Any,context:Context,environment:str,*,metadata:Metadata,query_state:t.Optional[AsyncQueryState]=_A)->dict[str,t.Any]:
	D='metrics';C='semantic_models';B='data_product';A='tenants';connection_type,connection_uri=_connection_info(context);md_env=metadata.env or''
	if md_env and md_env!=environment:logger.warning('Hera sync metadata.env (%s) does not match environment argument (%s); continuing with caller metadata',md_env,environment)
	models=metadata.models;mctx=_EntriesIndex.from_entries(models);source_entries=[e for e in models if e.source_type not in(_L,_I)];semantic_entries=[e for e in models if e.source_type==_L];metric_entries=[e for e in models if e.source_type==_I];product=context.config;info=_hera_domain_and_vulcan_schema(hera,product,connection_type,connection_uri);sync_user=normalize(product.username or info.tenant or info.project);lineage=_LineageCollector(hera,mctx);data_product_fqn=_A;product_meta=metadata.product;scoped_data_product_name=data_product_name(info.tenant,product.name);data_product_tenants=_A
	if product_meta.domain and product_meta.discoverable:
		try:data_product=hera.get_by_name(entity=_hera_generated_schema().DataProduct,fqn=scoped_data_product_name,fields=[A]);data_product_tenants=getattr(data_product,A,_A)if data_product else _A
		except Exception:data_product_tenants=_A
	if product_meta.domain and product_meta.discoverable:
		data_product_fqn=step(B,lambda:ensure_data_product(hera,product_name=scoped_data_product_name,domain_fqn=product_meta.domain,description=product_meta.description or'',display_name=product_meta.display_name,owners=resolve_owner_refs(hera,product_meta.users),category=product_meta.alignment,product_tags=list(product_meta.tags)or _A))
		if data_product_fqn and info.tenant:step('data_product_tenant',lambda:attach_tenant_to_data_product(hera,data_product_fqn,info.tenant,current_tenants=data_product_tenants))
	source_fqns:list[str]=[];semantic_fqns:list[str]=[];metric_fqns:list[str]=[];perspective_fqns:list[str]=[];phys_to_view:dict[str,str]={};phys_to_entry:dict[str,ModelEntry]={}
	if info.source_svc_fqn:source_result=await run_blocking_heavy(lambda:step('source_tables',lambda:_sync_source_tables(hera,mctx,source_entries,info.source_svc_fqn,default_db=info.tenant,default_schema=info.project,domain_fqn=info.domain_fqn,lineage=lineage))or([],{},{}));source_fqns,phys_to_view,phys_to_entry=source_result
	if info.schema_fqn:
		semantic_fqns=await run_blocking_heavy(lambda:step(C,lambda:_sync_typed_entries(hera,mctx,info.schema_fqn,semantic_entries,source_type=_L,lineage=lineage))or[]);metric_fqns=await run_blocking_heavy(lambda:step(D,lambda:_sync_typed_entries(hera,mctx,info.schema_fqn,metric_entries,source_type=_I,lineage=lineage))or[])
		if query_state:
			try:perspective_fqns=await _sync_perspectives(hera,info.schema_fqn,query_state,context,info,current_user_id=sync_user,entity_id_cache=lineage._entity_id_cache)
			except Exception:logger.exception("Hera step 'perspectives' failed");perspective_fqns=[]
	_sync_physical_to_view_lineage(hera,phys_to_view,phys_to_entry);all_assets=[*source_fqns,*semantic_fqns,*metric_fqns,*perspective_fqns]
	def _flush_lineage_and_assets()->_A:
		lineage.flush()
		if info.domain_fqn and all_assets:step('domain_assoc',lambda:associate_domain(hera,info.domain_fqn,all_assets))
		if data_product_fqn:step('data_product_assets',lambda:attach_data_product_assets(hera,data_product_fqn,all_assets))
	await run_blocking_heavy(_flush_lineage_and_assets);return{_U:environment,'tables_synced':len(all_assets),'models':len(source_entries),C:len(semantic_entries),D:len(metric_entries),B:data_product_fqn}
async def sync_to_hera(context:Context,environment:str,*,metadata:Metadata,query_state:t.Optional[AsyncQueryState]=_A)->dict[str,t.Any]:
	if not is_prod(environment):return{_E:_B,_M:_V}
	hera_cfg=context.config.hera
	if not hera_cfg or not hera_cfg.enabled:return{_E:_B}
	hera=_hera_client(hera_cfg);return await _snapshot_catalog(hera,context,environment,metadata=metadata,query_state=query_state)
async def sync_latest_run_status(context:Context,environment:str,activity:AsyncActivityState)->dict[str,t.Any]:
	if not is_prod(environment):return{_E:_B,_M:_V}
	hera_cfg=context.config.hera
	if not hera_cfg or not hera_cfg.enabled:return{_E:_B}
	run_record=await activity.get_latest_run_for_environment(environment)
	if run_record is _A:return{_E:_B,_M:'no_run_record'}
	run_succeeded,last_run_at=run_record;last_run_status='PASS'if run_succeeded else'FAIL';product_name=data_product_name(context.config.tenant,context.config.name)
	def _patch_run_status()->bool:hera=_hera_client(hera_cfg);return update_data_product_status(hera=hera,product_name=product_name,last_run_status=last_run_status,last_run_at=last_run_at,quality_status=last_run_status)
	if not await run_blocking_fast(_patch_run_status):return{_E:_B,_M:'data_product_missing'}
	return{_U:environment,'last_run_status':last_run_status,'last_run_at':last_run_at}
async def _sync_one_perspective(hera:t.Any,context:t.Any,query_state:AsyncQueryState,perspective:t.Any,schema_fqn:str,info:_D,entity_id_cache:t.Optional[dict[str,t.Optional[str]]]=_A)->t.Optional[str]:
	raw_columns,lineage,output_columns=await _perspective_column_lineage_refs(query_state,perspective);query_type=getattr(perspective,_T,_A);member_mapping=_get_member_mapping_from_perspective(perspective);depends_on=getattr(perspective,'depends_on',_A)or[];created=_create_table(hera,table_name=sanitize(perspective.slug),schema_fqn=schema_fqn,columns=raw_columns,description=perspective.description or'',table_type=_hera_generated_schema().TableType.Perspective,display_name=perspective.name,owners=resolve_user_owner_ref(hera,getattr(perspective,'owner',_A)),is_public=getattr(perspective,'is_public',_A))
	if not created:return
	perspective_fqn,table=created;_emit_perspective_lineage(hera,perspective_fqn=perspective_fqn,query_type=query_type,output_columns=output_columns,lineage=lineage,depends_on=depends_on,member_mapping=member_mapping,schema_fqn=schema_fqn,context=context,info=info,entity_id_cache=entity_id_cache);attach_tags(hera,table,entity_tags(getattr(perspective,_P,[])or[],getattr(perspective,'terms',[])or[]));return perspective_fqn
async def _sync_single_perspective(hera:t.Any,context:Context,query_state:AsyncQueryState,perspective:t.Any,environment:str=_N)->_A:
	if not is_prod(environment):return
	connection_type,connection_uri=_connection_info(context);product=context.config;info=_hera_domain_and_vulcan_schema(hera,product,connection_type,connection_uri)
	if not info.schema_fqn:return
	fqn=await _sync_one_perspective(hera,context,query_state,perspective,info.schema_fqn,info)
	if fqn:
		scoped_data_product_name=data_product_name(info.tenant,context.config.name)
		try:attach_data_product_assets(hera,scoped_data_product_name,[fqn])
		except Exception as exc:logger.debug("Could not attach perspective '%s' to data product '%s': %s",fqn,scoped_data_product_name,exc)
async def sync_perspective_by_id_to_hera(context:Context,query_state:AsyncQueryState,perspective_id:str,environment:str=_N)->bool:
	if not perspective_id:return _H
	perspective=await query_state.get_perspective_by_id(perspective_id)
	if not perspective:return _H
	await sync_perspective_to_hera(context,query_state,perspective,environment=environment);return _B
async def sync_perspective_to_hera(context:Context,query_state:AsyncQueryState,perspective:t.Any,environment:str=_N)->_A:
	if not is_prod(environment):return
	hera_cfg=context.config.hera
	if not hera_cfg or not hera_cfg.enabled:return
	hera=_hera_client(hera_cfg);await _sync_single_perspective(hera,context,query_state,perspective,environment)
def delete_perspective_from_hera(context:Context,slug:str,environment:str=_N)->_A:
	if not is_prod(environment):return
	hera_cfg=context.config.hera
	if not hera_cfg or not hera_cfg.enabled:return
	hera=_hera_client(hera_cfg);hr=_hera_generated_schema();fqn=f"{vulcan_service_name(context.config.tenant,context.config.project)}.{normalize(context.config.tenant)}.{normalize(context.config.project)}.{sanitize(slug)}"
	try:
		table=hera.get_by_name(entity=hr.Table,fqn=fqn)
		if table and getattr(table,'id',_A):hera.delete(entity=hr.Table,entity_id=table.id.root)
	except Exception as exc:logger.warning("Failed to delete perspective '%s' from Hera: %s",slug,exc)