_b='start_ts'
_a='offset'
_Z='run_id'
_Y='Run not found'
_X='Run ID from the list response'
_W='run_789'
_V='Max runs to return'
_U='Plan sequence (digits only) or plan ID'
_T='c8852cdc210e43e4bf261c9983c8f3d6'
_S='Include runs with start time <= this (Unix seconds)'
_R='Include runs with start time >= this (Unix seconds)'
_Q='plan_id'
_P='Plan not found'
_O='Plan ID from the list response'
_N='plan_abc123'
_M='Unknown model in filter'
_L='Deprecated alias for ``models``.'
_K='Plans'
_J='Filter by success. Omit for all.'
_I='my_product.my_model'
_H='Pagination offset'
_G='all'
_F='Runs'
_E='Internal server error'
_D=False
_C='description'
_B=True
_A=None
import logging,typing as t
from fastapi import APIRouter,Depends,HTTPException,Path,Query,Request
from api.context import EnvContext
from api.schemas.common import Link,Pagination
from api.schemas.activity import GitCommitDetail,ModelLatestRun,ModelRunActivitiesResponse,ModelRunActivity,ModelRunActivityBase,ModelRunActivityLinks,ModelsLatestRunsResponse,Plan,PlanGitDiffLinks,PlanGitDiffResponse,PlanLinks,PlanSummary,PlansListResponse,PlansListSummaryResponse,RunDetail,RunLinks,RunSqlStatementLinks,RunSqlStatementResponse,RunSqlStatementStatus,RunSummary,RunsListResponse,RunsListSummaryResponse
from api.exceptions import ApiException
from api.dependencies import get_env_context,get_statestore_client
from api.state import AsyncStateClient
from api.pool import run_blocking_fast
from api.urls import urls
from api.cache import cached,CachePolicy
from vulcan.core.activity import PlanActivity,RunActivityWithChecksAndProfile
from vulcan.utils.git import GitClient
logger=logging.getLogger(__name__)
MAX_GIT_DIFF_SIZE=512000
router=APIRouter()
@router.get('/plans',summary='List Plans',tags=[_K],response_model=PlansListResponse|PlansListSummaryResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Plans list'},404:{_C:_M},500:{_C:_E}})
@cached(policy=CachePolicy.PLAN_CHANGE)
async def list_plans(models:t.Optional[str]=Query(_A,examples=[_I],description='Comma-separated models a plan affected. Omit for all.'),model_names:t.Optional[str]=Query(_A,include_in_schema=_D,description=_L),limit:int=Query(20,ge=1,le=100,description='Max plans to return'),offset:int=Query(0,ge=0,description=_H),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description='Include plans with start time >= this (Unix seconds)'),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description='Include plans with start time <= this (Unix seconds)'),success:t.Optional[bool]=Query(_A,description=_J),summary:bool=Query(_D,description='Compact rows with change counts only (for timelines).'),impact:t.Literal['direct','indirect','metadata',_G]=Query(_G,description='When ``models`` is set, filter by how the model was affected. ``all`` matches direct, indirect, or metadata changes.'),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->PlansListResponse|PlansListSummaryResponse:
	parsed_models=_parse_model_names_query(env_ctx,models or model_names)
	try:return await _list_plans(state,env_ctx.environment,summary=summary,model_names=parsed_models,impact=impact if parsed_models else _G,limit=limit,offset=offset,start_ts=start_ts,end_ts=end_ts,success=success)
	except Exception as e:raise ApiException(message=f"Failed to fetch plans: {e}",origin='API -> activity -> list_plans')
@router.get('/plans/{plan_id}',summary='Get Plan Detail',tags=[_K],response_model=Plan,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Plan detail'},404:{_C:_P}})
@cached(policy=CachePolicy.LRU_ONLY,key_params=[_Q])
async def get_plan(plan_id:str=Path(...,examples=[_N],description=_O),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A):
	plan_row=await state.activity.get_plan(plan_id)
	if not plan_row:raise HTTPException(404,f"Plan '{plan_id}' not found")
	return Plan.from_core(plan_row,_build_plan_links(plan_row))
@router.get('/plans/{plan_id}/git-diff',summary='Get Plan Git Diff',tags=[_K],response_model=PlanGitDiffResponse,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Git diff'},404:{_C:_P},500:{_C:_E}})
@cached(policy=CachePolicy.PLAN_CHANGE)
async def get_plan_git_diff(plan_id:str=Path(...,examples=[_N],description=_O),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->PlanGitDiffResponse:
	A='Failed to generate git diff for plan_id=%s: %s'
	try:
		current_plan_row=await state.activity.get_plan(plan_id)
		if not current_plan_row:raise HTTPException(404,f"Plan '{plan_id}' not found")
		previous_plan_row=_A
		if current_plan_row.plan_seq>1:previous_plan_row=await state.activity.get_plan_by_seq(current_plan_row.environment,current_plan_row.plan_seq-1)
		if not previous_plan_row:return PlanGitDiffResponse(git_diff=_A,commits=[],message='no previous plan found',links=_build_plan_git_diff_links(current_plan_row))
		git_diff:t.Optional[str]=_A;commits:t.List[GitCommitDetail]=[];message:t.Optional[str]=_A;truncated=_D
		try:
			if not current_plan_row.git_commit_sha or not previous_plan_row.git_commit_sha:message='Git diff unavailable: missing commit SHA'
			else:
				commits,git_diff,truncated,diff_error=await run_blocking_fast(_collect_git_diff_payload,env_ctx.context.git_client,previous_plan_row.git_commit_sha,current_plan_row.git_commit_sha)
				if diff_error is not _A:logger.warning(A,plan_id,diff_error);message=f"Git diff unavailable: {diff_error}"
				elif truncated:message='Git diff truncated'
		except Exception as e:logger.error(A,plan_id,e,exc_info=_B);message=f"Git diff unavailable: {e}"
		return PlanGitDiffResponse(git_diff=git_diff,commits=commits,message=message,truncated=truncated,links=_build_plan_git_diff_links(current_plan_row,previous_plan_row.plan_id))
	except HTTPException:raise
	except Exception as e:raise ApiException(message=f"Failed to fetch git diff for plan {plan_id}: {e}",origin='API -> activity -> get_plan_git_diff')
@router.get('/runs',summary='List Runs',tags=[_F],response_model=RunsListResponse|RunsListSummaryResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Runs list'},404:{_C:_M},500:{_C:_E}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_runs(models:t.Optional[str]=Query(_A,examples=[_I],description='Comma-separated models executed in the run. Omit for all.'),model_names:t.Optional[str]=Query(_A,include_in_schema=_D,description=_L),success:t.Optional[bool]=Query(_A,description=_J),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description=_R),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description=_S),plan:t.Optional[str]=Query(_A,examples=['42',_T],description=_U),limit:int=Query(20,ge=1,le=100,description=_V),offset:int=Query(0,ge=0,description=_H),summary:bool=Query(_D,description='Compact rows with model, error, and DQ counts only (for timelines).'),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->RunsListResponse|RunsListSummaryResponse:
	parsed_models=_parse_model_names_query(env_ctx,models or model_names);plan_id,plan_seq=_parse_plan_query(plan)
	try:return await _list_runs(state,env_ctx.environment,summary=summary,model_names=parsed_models,success=success,start_ts=start_ts,end_ts=end_ts,plan_id=plan_id,plan_seq=plan_seq,limit=limit,offset=offset)
	except Exception as e:raise ApiException(message=f"Failed to fetch runs: {e}",origin='API -> activity -> list_runs')
@router.get('/runs/{run_id}',summary='Get Run Detail',tags=[_F],response_model=RunDetail,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Run detail'},404:{_C:_Y}})
@cached(policy=CachePolicy.LRU_ONLY,key_params=[_Z])
async def get_run(run_id:str=Path(...,examples=[_W],description=_X),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->RunDetail:
	run_activity_with_checks=await state.dq.get_run(run_id)
	if not run_activity_with_checks:raise HTTPException(404,f"Run '{run_id}' not found")
	return _run_detail_from_core(run_activity_with_checks)
@router.get('/runs/{run_id}/sql',summary='List Run SQL Statements',tags=[_F],response_model=RunSqlStatementResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Run SQL statements'},404:{_C:_Y}})
@cached(policy=CachePolicy.LRU_ONLY,key_params=[_Z,'kind','status','limit',_a])
async def get_run_sql_statements(run_id:str=Path(...,examples=[_W],description=_X),kind:t.Optional[str]=Query(_A,examples=['MERGE'],description='Filter by statement kind (for example SELECT, MERGE)'),status:t.Optional[RunSqlStatementStatus]=Query(_A,description='Filter by execution outcome'),limit:int=Query(100,ge=1,le=200,description='Max statements to return'),offset:int=Query(0,ge=0,description=_H),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->RunSqlStatementResponse:
	run_activity_with_checks=await state.dq.get_run(run_id)
	if not run_activity_with_checks:raise HTTPException(404,f"Run '{run_id}' not found")
	try:statements,total,has_more=await state.activity.list_run_sql_statements(run_id=run_id,kind=kind,status=status,limit=limit,offset=offset)
	except Exception as e:raise ApiException(message=f"Failed to fetch run SQL statements: {e}",origin='API -> activity -> get_run_sql_statements')
	return RunSqlStatementResponse(run_id=run_id,environment=env_ctx.environment,statements=statements,total=total,pagination=Pagination(limit=limit,offset=offset,has_more=has_more,order_by='id',order_direction='asc'),links=RunSqlStatementLinks(self_link=Link(href=urls.run_sql(run_id,kind=kind,status=status,limit=limit,offset=offset)),run=Link(href=urls.run(run_id))))
@router.get('/models/{model_name}/runs',summary='List Model Run History',tags=[_F],response_model=ModelRunActivitiesResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Model run history'},400:{_C:'Invalid query parameters'},404:{_C:'Model not found'},500:{_C:_E}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_model_runs(model_name:str=Path(...,examples=[_I],description='Fully qualified model name'),limit:int=Query(20,ge=1,le=100,description=_V),offset:int=Query(0,ge=0,description=_H),success:t.Optional[bool]=Query(_A,description=_J),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description=_R),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description=_S),plan:t.Optional[str]=Query(_A,examples=['42',_T],description=_U),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->ModelRunActivitiesResponse:
	model_entry=env_ctx.assert_model(model_name);plan_id,plan_seq=_parse_plan_query(plan)
	try:rows=await state.dq.list_model_run_activities(environment=env_ctx.environment,model_name=model_entry.name,success=success,start_ts=start_ts,end_ts=end_ts,plan_id=plan_id,plan_seq=plan_seq,limit=limit,offset=offset);return ModelRunActivitiesResponse(model_name=model_entry.name,environment=env_ctx.environment,runs=[ModelRunActivity.with_links(row,_build_model_run_activity_links(row))for row in rows],total=len(rows),pagination=_list_pagination(limit,offset,len(rows)))
	except ValueError as e:raise HTTPException(status_code=400,detail=str(e))
	except Exception as e:raise ApiException(message=f"Failed to fetch runs for model '{model_name}': {e}",origin='API -> activity -> list_model_runs')
@router.get('/models',summary='List Models with Latest Run',tags=[_F],response_model=ModelsLatestRunsResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Models with latest run'},500:{_C:_E}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_models_latest_runs(env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->ModelsLatestRunsResponse:
	all_models=sorted({m.name for m in env_ctx.metadata.models})
	try:
		latest_map=await state.dq.list_latest_runs_by_model(environment=env_ctx.environment,model_names=all_models);items:t.List[ModelLatestRun]=[]
		for model_name in all_models:run=latest_map.get(model_name);run_detail=_run_detail_from_core(run)if run else _A;items.append(ModelLatestRun(model_name=model_name,run=run_detail))
		items.sort(key=lambda x:x.model_name);items.sort(key=lambda x:x.run.start_ts if x.run else-1,reverse=_B);return ModelsLatestRunsResponse(environment=env_ctx.environment,models=items)
	except Exception as e:raise ApiException(message=f"Failed to fetch latest runs by model: {e}",origin='API -> activity -> list_models_latest_runs')
def _list_pagination(limit:int,offset:int,row_count:int)->Pagination:return Pagination(limit=limit,offset=offset,has_more=row_count==limit,order_by=_b,order_direction='desc')
def _parse_plan_query(plan:t.Optional[str])->t.Tuple[t.Optional[str],t.Optional[int]]:
	if not plan:return _A,_A
	if plan.isascii()and plan.isdigit():return _A,int(plan)
	return plan,_A
def _parse_model_names_query(env_ctx:EnvContext,model_names:t.Optional[str])->t.Optional[t.List[str]]:
	if not model_names:return
	parsed=[name.strip()for name in model_names.split(',')if name.strip()]
	if not parsed:return
	return[env_ctx.assert_model(name).name for name in parsed]
def _build_plan_summary_links(plan_id:str)->PlanLinks:return PlanLinks(self_link=Link(href=urls.plan(plan_id)),git_diff=Link(href=urls.plan_git_diff(plan_id)))
def _build_model_run_activity_links(row:ModelRunActivityBase)->ModelRunActivityLinks:return ModelRunActivityLinks(run=Link(href=urls.run(row.run_id)),plan=Link(href=urls.plan(row.plan_id))if row.plan_id else _A)
def _build_plan_links(plan_row:PlanActivity)->PlanLinks:return PlanLinks(self_link=Link(href=urls.plan(plan_row.plan_id)),previous=Link(href=urls.plan(plan_row.prev_plan_id))if plan_row.prev_plan_id else _A,commit=Link(href=plan_row.git_commit_url)if plan_row.git_commit_url else _A,git_diff=Link(href=urls.plan_git_diff(plan_row.plan_id)))
def _build_plan_git_diff_links(plan_row:PlanActivity,previous_plan_id:t.Optional[str]=_A)->PlanGitDiffLinks:return PlanGitDiffLinks(self_link=Link(href=urls.plan_git_diff(plan_row.plan_id)),current_plan=Link(href=urls.plan(plan_row.plan_id)),previous_plan=Link(href=urls.plan(previous_plan_id))if previous_plan_id else _A)
def _build_run_links(run_id:str,plan_id:t.Optional[str]=_A)->RunLinks:return RunLinks(self_link=Link(href=urls.run(run_id)),plan=Link(href=urls.plan(plan_id))if plan_id else _A,sql=Link(href=urls.run_sql(run_id)))
def _run_detail_from_core(run:RunActivityWithChecksAndProfile)->RunDetail:return RunDetail(**run.model_dump(exclude_none=_B),links=_build_run_links(run.run_id,run.plan_id))
async def _list_plans(state:AsyncStateClient,environment:str,*,summary:bool,model_names:t.Optional[t.List[str]],impact:str=_G,limit:int,offset:int,start_ts:t.Optional[int],end_ts:t.Optional[int],success:t.Optional[bool])->PlansListResponse|PlansListSummaryResponse:
	if summary:plans=await state.activity.list_plan_summaries(environment=environment,model_names=model_names,impact=impact,limit=limit,offset=offset,start_ts=start_ts,end_ts=end_ts,success=success);return PlansListSummaryResponse(environment=environment,plans=[PlanSummary.with_links(plan,_build_plan_summary_links(plan.plan_id))for plan in plans],total=len(plans),pagination=_list_pagination(limit,offset,len(plans)))
	plans=await state.activity.list_plans(environment=environment,model_names=model_names,impact=impact,limit=limit,offset=offset,start_ts=start_ts,end_ts=end_ts,success=success);return PlansListResponse(environment=environment,plans=[Plan.from_core(p,_build_plan_links(p))for p in plans],total=len(plans),pagination=_list_pagination(limit,offset,len(plans)))
async def _list_runs(state:AsyncStateClient,environment:str,*,summary:bool,model_names:t.Optional[t.List[str]],success:t.Optional[bool],start_ts:t.Optional[int],end_ts:t.Optional[int],plan_id:t.Optional[str],plan_seq:t.Optional[int],limit:int,offset:int)->RunsListResponse|RunsListSummaryResponse:
	fetch_kwargs={'environment':environment,'model_names':model_names,'success':success,_b:start_ts,'end_ts':end_ts,_Q:plan_id,'plan_seq':plan_seq,'limit':limit,_a:offset}
	if summary:runs=await state.dq.list_run_summaries(**fetch_kwargs);return RunsListSummaryResponse(environment=environment,runs=[RunSummary.with_links(run,_build_run_links(run.run_id,run.plan_id))for run in runs],total=len(runs),pagination=_list_pagination(limit,offset,len(runs)))
	runs=await state.dq.list_runs(**fetch_kwargs);return RunsListResponse(environment=environment,runs=[_run_detail_from_core(run)for run in runs],total=len(runs),pagination=_list_pagination(limit,offset,len(runs)))
def _collect_git_diff_payload(git_client:GitClient,prev_sha:str,curr_sha:str)->t.Tuple[t.List[GitCommitDetail],t.Optional[str],bool,t.Optional[str]]:
	try:commits=[GitCommitDetail(sha=c.sha,message=c.message,author_name=c.author_name,author_email=c.author_email,authored_at=c.authored_at,commit_url=git_client.commit_url(c.sha))for c in git_client.list_commits(prev_sha,curr_sha)]
	except Exception as exc:return[],_A,_D,str(exc)
	try:git_diff=git_client.diff(prev_sha,curr_sha)
	except Exception as exc:return commits,_A,_D,str(exc)
	truncated=_D
	if len(git_diff)>MAX_GIT_DIFF_SIZE:git_diff=f"{git_diff[:MAX_GIT_DIFF_SIZE]}\n... (truncated)";truncated=_B
	return commits,git_diff,truncated,_A