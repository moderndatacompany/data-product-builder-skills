from __future__ import annotations
_F='metric'
_E='FloatFilter'
_D='DateTimeFilter'
_C='StringFilter'
_B=True
_A=None
import logging,re,typing as t
from dataclasses import dataclass
from graphql import GraphQLArgument,GraphQLBoolean,GraphQLEnumType,GraphQLField,GraphQLFloat,GraphQLInputField,GraphQLInputObjectType,GraphQLInt,GraphQLList,GraphQLNonNull,GraphQLObjectType,GraphQLScalarType,GraphQLSchema,GraphQLString,GraphQLType
from schema.metadata import Metadata
logger=logging.getLogger(__name__)
_GRAPHQL_NAME_RE=re.compile('^[_a-zA-Z][_a-zA-Z0-9]*$')
@dataclass(frozen=_B,slots=_B)
class QueryableMember:name:str;type:str
@dataclass(frozen=_B,slots=_B)
class QueryableModel:name:str;source:t.Literal['model',_F];measures:tuple[QueryableMember,...];dimensions:tuple[QueryableMember,...];description:str=''
@dataclass(frozen=_B,slots=_B)
class GraphQLArtifacts:schema:GraphQLSchema|_A;queryables:tuple[QueryableModel,...]
DateTime=GraphQLScalarType('DateTime',serialize=lambda value:value,parse_value=lambda value:value)
OrderBy=GraphQLEnumType('OrderBy',{'asc':'asc','desc':'desc'})
def validate_graphql_name(name:str,context:str|_A=_A)->_A:
	if not name or not isinstance(name,str):suffix=f" for {context}"if context else'';raise ValueError(f"Name is required (null or undefined){suffix}")
	if not _GRAPHQL_NAME_RE.match(name):suffix=f" in {context}"if context else'';raise ValueError(f'Name "{name}" is not valid for GraphQL (must match ^[_a-zA-Z][_a-zA-Z0-9]*$){suffix}')
def format_description(description:str|_A,tags:t.Sequence[str]|_A,terms:t.Sequence[str]|_A)->str:
	desc=(description or'').strip()
	def _block(tokens:t.Sequence[str]|_A)->str:
		if not tokens:return''
		cleaned=[f"#{t.strip()}"for t in tokens if(t or'').strip()];return f"[{' '.join(cleaned)}]"if cleaned else''
	parts=[p for p in(desc,_block(tags),_block(terms))if p];return' '.join(parts)
def _to_member_type(ltype:str)->str:
	if not ltype or not isinstance(ltype,str):raise ValueError(f"Schema type is required (got {ltype}). Fail fast: schema must deliver type.")
	return ltype.lower()
def build_queryables(metadata:Metadata)->tuple[QueryableModel,...]:
	B='dimension';A='measure';result:list[QueryableModel]=[];semantic_entries=[m for m in metadata.models if m.kind=='SEMANTIC'];metric_entries=[m for m in metadata.models if m.kind=='METRIC']
	for entry in semantic_entries:
		validate_graphql_name(entry.name,f'semantic model "{entry.name}"');measures:list[QueryableMember]=[];dimensions:list[QueryableMember]=[]
		for col in entry.columns:
			if not col.public:continue
			if col.kind==A:validate_graphql_name(col.name,f'measure "{col.name}" in semantic model "{entry.name}"');measures.append(QueryableMember(name=col.name,type=_to_member_type(str(col.ltype))))
			elif col.kind==B:validate_graphql_name(col.name,f'dimension "{col.name}" in semantic model "{entry.name}"');dimensions.append(QueryableMember(name=col.name,type=_to_member_type(str(col.ltype))))
		if not measures and not dimensions:continue
		result.append(QueryableModel(name=entry.name,source='model',measures=tuple(measures),dimensions=tuple(dimensions),description=format_description(entry.description,entry.tags,entry.terms)))
	model_names={r.name for r in result}
	for entry in metric_entries:
		validate_graphql_name(entry.name,f'metric "{entry.name}"')
		if entry.name in model_names:continue
		model_names.add(entry.name);measure_col=next((c for c in entry.columns if c.kind==A),_A);dim_cols=[c for c in entry.columns if c.kind==B];measures=[QueryableMember(name=A,type=_to_member_type(str(measure_col.ltype)))]if measure_col else[QueryableMember(name=A,type='number')];dimensions=[]
		for col in dim_cols:validate_graphql_name(col.name,f'dimension "{col.name}" in metric "{entry.name}"');dimensions.append(QueryableMember(name=col.name,type=_to_member_type(str(col.ltype))))
		result.append(QueryableModel(name=entry.name,source=_F,measures=tuple(measures),dimensions=tuple(dimensions),description=format_description(entry.description,entry.tags,entry.terms)))
	return tuple(result)
def build_artifacts(metadata:Metadata)->GraphQLArtifacts:
	try:queryables=build_queryables(metadata);schema=build_graphql_schema(queryables);return GraphQLArtifacts(schema=schema,queryables=queryables)
	except Exception as exc:logger.error('GraphQL artifact generation failed during EnvContext load (env=%s): %s',metadata.env,exc,exc_info=_B);return GraphQLArtifacts(schema=_A,queryables=())
def _builtin_filter(name:str):
	E='set';D='notIn';C='in';B='notEquals';A='equals'
	if name==_C:return GraphQLInputObjectType(_C,{A:GraphQLInputField(GraphQLString),B:GraphQLInputField(GraphQLString),C:GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),D:GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'contains':GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'notContains':GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'startsWith':GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'notStartsWith':GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'endsWith':GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'notEndsWith':GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),E:GraphQLInputField(GraphQLBoolean)})
	if name==_D:return GraphQLInputObjectType(_D,{A:GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),B:GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),C:GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),D:GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'inDateRange':GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'notInDateRange':GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLString))),'beforeDate':GraphQLInputField(GraphQLString),'beforeOrOnDate':GraphQLInputField(GraphQLString),'afterDate':GraphQLInputField(GraphQLString),'afterOrOnDate':GraphQLInputField(GraphQLString),E:GraphQLInputField(GraphQLBoolean)})
	return GraphQLInputObjectType(_E,{A:GraphQLInputField(GraphQLFloat),B:GraphQLInputField(GraphQLFloat),C:GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLFloat))),D:GraphQLInputField(GraphQLList(GraphQLNonNull(GraphQLFloat))),E:GraphQLInputField(GraphQLBoolean),'gt':GraphQLInputField(GraphQLFloat),'lt':GraphQLInputField(GraphQLFloat),'gte':GraphQLInputField(GraphQLFloat),'lte':GraphQLInputField(GraphQLFloat)})
def build_graphql_schema(queryables:t.Sequence[QueryableModel])->GraphQLSchema:
	G='orderBy';F='where';E='AND';D='Result';C='RootOrderByInput';B='RootWhereInput';A='TimeDimension';from api.endpoints.query.graphql.handler import resolve_table;from api.endpoints.query.graphql.query import map_type,object_name,uncapitalize;types:dict[str,GraphQLType]={};time_fields={g:GraphQLField(DateTime)for g in('value','second','minute','hour','day','week','month','quarter','year')};types[A]=GraphQLObjectType(A,time_fields);types[_C]=_builtin_filter(_C);types[_D]=_builtin_filter(_D);types[_E]=_builtin_filter(_E)
	def output_type(name:str)->GraphQLType:
		if name==A:return types[A]
		if name=='String':return GraphQLString
		return GraphQLFloat
	for item in queryables:prefix=object_name(item.name);members_name=f"{prefix}Members";where_name=f"{prefix}WhereInput";order_name=f"{prefix}OrderByInput";types[members_name]=GraphQLObjectType(members_name,{**{m.name:GraphQLField(output_type(map_type(m.type)))for m in item.measures},**{d.name:GraphQLField(output_type(map_type(d.type)))for d in item.dimensions}},description=item.description or _A);types[where_name]=GraphQLInputObjectType(where_name,lambda model=item,wn=where_name:{E:GraphQLInputField(GraphQLList(GraphQLNonNull(types[wn]))),'OR':GraphQLInputField(GraphQLList(GraphQLNonNull(types[wn]))),**{m.name:GraphQLInputField(types[f"{map_type(m.type,_B)}Filter"])for m in model.measures},**{d.name:GraphQLInputField(types[f"{map_type(d.type,_B)}Filter"])for d in model.dimensions}});types[order_name]=GraphQLInputObjectType(order_name,{**{m.name:GraphQLInputField(OrderBy)for m in item.measures},**{d.name:GraphQLInputField(OrderBy)for d in item.dimensions}})
	root_where=GraphQLInputObjectType(B,lambda:{E:GraphQLInputField(GraphQLList(GraphQLNonNull(root_where))),'OR':GraphQLInputField(GraphQLList(GraphQLNonNull(root_where))),**{uncapitalize(item.name):GraphQLInputField(types[f"{object_name(item.name)}WhereInput"])for item in queryables}});types[B]=root_where;types[C]=GraphQLInputObjectType(C,{uncapitalize(item.name):GraphQLInputField(types[f"{object_name(item.name)}OrderByInput"])for item in queryables});types[D]=GraphQLObjectType(D,{uncapitalize(item.name):GraphQLField(types[f"{object_name(item.name)}Members"],args={F:GraphQLArgument(types[f"{object_name(item.name)}WhereInput"]),G:GraphQLArgument(types[f"{object_name(item.name)}OrderByInput"])})for item in queryables});query_type=GraphQLObjectType('Query',{'table':GraphQLField(GraphQLNonNull(GraphQLList(GraphQLNonNull(types[D]))),args={F:GraphQLArgument(types[B]),'limit':GraphQLArgument(GraphQLInt),'offset':GraphQLArgument(GraphQLInt),'timezone':GraphQLArgument(GraphQLString),'renewQuery':GraphQLArgument(GraphQLBoolean),'ungrouped':GraphQLArgument(GraphQLBoolean),G:GraphQLArgument(types[C])},resolve=resolve_table)});extra=[OrderBy,DateTime,*types.values()];return GraphQLSchema(query=query_type,types=extra)