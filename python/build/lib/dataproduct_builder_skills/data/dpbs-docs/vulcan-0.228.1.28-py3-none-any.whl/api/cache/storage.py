from __future__ import annotations
_A=None
import time,typing as t
from collections import OrderedDict
from api.utils.commons import parse_positive_int_env
_MISSING=object()
class LRUCacheStorage:
	def __init__(self,maxsize:int=1000):(self._cache):OrderedDict[str,t.Tuple[t.Any,float,t.Optional[float]]]=OrderedDict();self.maxsize=maxsize;self._hits=0;self._misses=0
	def get(self,key:str,ttl:t.Optional[float]=_A)->t.Any:
		if key in self._cache:
			value,timestamp,stored_ttl=self._cache[key];ttl_to_check=ttl if ttl is not _A else stored_ttl
			if ttl_to_check is not _A:
				age=time.time()-timestamp
				if age>ttl_to_check:del self._cache[key];self._misses+=1;return _MISSING
			self._cache.move_to_end(key);self._hits+=1;return value
		self._misses+=1;return _MISSING
	def set(self,key:str,value:t.Any,ttl:t.Optional[float]=_A)->_A:
		timestamp=time.time()
		if key in self._cache:self._cache.move_to_end(key)
		elif len(self._cache)>=self.maxsize:self._cache.popitem(last=False)
		self._cache[key]=value,timestamp,ttl
	def invalidate_pattern(self,pattern:str)->int:
		keys_to_delete=[k for k in self._cache.keys()if k.startswith(pattern)]
		for key in keys_to_delete:del self._cache[key]
		return len(keys_to_delete)
	def invalidate_environment(self,environment:str|_A)->_A:
		from api.cache import CachePolicy,cache_key_prefix
		for policy in CachePolicy:
			if policy.value!=CachePolicy.LRU_ONLY.value:self.invalidate_pattern(cache_key_prefix(policy,environment))
	def clear(self)->_A:self._cache.clear();self._hits=0;self._misses=0
	def stats(self)->dict:total=self._hits+self._misses;hit_rate=self._hits/total*100 if total>0 else 0;return{'size':len(self._cache),'maxsize':self.maxsize,'hits':self._hits,'misses':self._misses,'hit_rate':f"{hit_rate:.1f}%"}
_cache_storage=LRUCacheStorage(maxsize=parse_positive_int_env('VULCAN_CACHE_MAXSIZE',default=10000,floor=256,ceiling=1000000))