from __future__ import annotations
_N='METRIC'
_M='SEMANTIC'
_L='measure'
_K='examples'
_J='public'
_I='sql'
_H='value'
_G=True
_F='limit'
_E='dimensions'
_D='dimension'
_C='example'
_B='query'
_A=None
import re,typing as t
from schema.metadata import Metadata,ModelEntry
from schema.rest_query import RestQuery
if t.TYPE_CHECKING:from api.context import EnvContext
MetadataOrContext=t.Union[Metadata,'EnvContext']
ExampleBuilder=t.Callable[[Metadata],'OpenApiExample']
def parameter_example(param:dict)->t.Any:
	if not isinstance(param,dict):return
	if _C in param:return param[_C]
	schema=param.get('schema',{})
	if not isinstance(schema,dict):return
	if _C in schema:return schema[_C]
	examples=schema.get(_K)
	if isinstance(examples,list)and examples:return examples[0]
	if isinstance(examples,dict)and examples:
		first=next(iter(examples.values()))
		if isinstance(first,dict)and _H in first:return first[_H]
		return first
	return schema.get('default')
class OpenApiExample(t.NamedTuple):body:dict;summary:str
class PostmanCatalogContext(t.NamedTuple):display_name:str;product_name:str;tenant:str
def postman_catalog_context(metadata_or_ctx:MetadataOrContext)->PostmanCatalogContext:metadata=_as_metadata(metadata_or_ctx);prod=metadata.product;return PostmanCatalogContext(display_name=getattr(prod,'display_name',_A)or'',product_name=metadata.name or'',tenant=metadata.tenant or'')
def iter_operations(schema:dict)->t.Iterator[dict]:
	for path_item in schema.get('paths',{}).values():
		for operation in path_item.values():
			if isinstance(operation,dict):yield operation
def apply_metadata_examples_to_openapi(schema:dict,metadata:Metadata)->_A:
	for operation in iter_operations(schema):
		operation_id=operation.get('operationId')
		if not operation_id:continue
		builder=_METADATA_EXAMPLE_BUILDERS.get(operation_id)
		if builder is _A:continue
		example=builder(metadata);envelope=_to_openapi_examples_dict(example);request_body=operation.setdefault('requestBody',{});content=request_body.setdefault('content',{});content.setdefault('application/json',{})[_K]=envelope
def example_submit_raw_sql(metadata:Metadata)->OpenApiExample:physical=_first_physical(metadata);model_name=physical.name if physical else'model';return OpenApiExample(body={_I:f"SELECT * FROM {model_name} LIMIT 1"},summary=f"Source SQL on {model_name}")
def example_submit_semantic_rest_query(metadata:Metadata)->OpenApiExample:
	A='measures';semantic,short,measures,dims=_semantic_model_example(metadata)
	if semantic is _A:return OpenApiExample(body={_B:{A:['<model>.<measure>'],_E:['<model>.<dimension>'],_F:10}},summary='semantic rest example')
	measure_member=f"{short}.{measures[0]}"if measures else f"{short}.measure";dim_member=f"{short}.{dims[0]}"if dims else f"{short}.dimension";dim_col=dims[0]if dims else _D;rest_query=RestQuery.model_validate({A:[measure_member],_E:[dim_member],_F:10});return OpenApiExample(body={_B:rest_query.model_dump(mode='json',exclude_none=_G)},summary=f"{short} by {dim_col}")
def example_submit_semantic_sql_query(metadata:Metadata)->OpenApiExample:
	semantic,short,measures,dims=_semantic_model_example(metadata)
	if semantic is _A:return OpenApiExample(body={_I:'SELECT <dimension>, MEASURE(<measure>) FROM <model> GROUP BY 1 LIMIT 10'},summary='semantic sql example')
	measure_member=f"{short}.{measures[0]}"if measures else f"{short}.measure";dim_member=f"{short}.{dims[0]}"if dims else f"{short}.dimension"
	if measures and dims:sql=f"SELECT {dim_member}, MEASURE({measure_member}) FROM {short} GROUP BY {dim_member} LIMIT 10"
	elif measures:sql=f"SELECT MEASURE({measure_member}) FROM {short} LIMIT 10"
	elif dims:sql=f"SELECT {dim_member} FROM {short} LIMIT 10"
	else:sql=f"SELECT * FROM {short} LIMIT 10"
	return OpenApiExample(body={_I:sql},summary=f"{short} semantic SQL")
def example_execute_semantic_graphql(metadata:Metadata)->OpenApiExample:
	semantic,short,measures,dims=_semantic_model_example(metadata)
	if semantic is _A:return OpenApiExample(body={_B:'query {\n  table(limit: 10) {\n    <model> {\n      <measure>\n      <dimension>\n    }\n  }\n}'},summary='semantic graphql example')
	dim_col=dims[0]if dims else _D;measure_col=measures[0]if measures else _L;query=f"""query {{
  table(limit: 10) {{
    {short} {{
      {measure_col}
      {dim_col}
    }}
  }}
}}""";return OpenApiExample(body={_B:query},summary=f"{short} GraphQL")
def example_publish_tableau(metadata:Metadata)->OpenApiExample:return OpenApiExample(body={'server_address':'https://10ax.online.tableau.com','site_id':'mysite','token_name':'vulcan-publisher','personal_access_token':'<personal-access-token>'},summary='Publish to Tableau Cloud with a Personal Access Token')
def example_submit_metric_query(metadata:Metadata)->OpenApiExample:
	C='month';B='filters';A='granularity';metric=_first_metric(metadata)
	if metric is _A:return OpenApiExample(body={_E:[],A:C,B:[],_F:1000},summary='metric query example')
	metric_dims=[col.name for col in metric.columns or[]if col.kind==_D and getattr(col,_J,_G)];default_gran=getattr(metric,'default_granularity',_A);short=_short_name(metric);return OpenApiExample(body={_E:[metric_dims[0]]if metric_dims else[],A:str(default_gran)if default_gran else C,B:[],_F:1000},summary=f"{short} metric query")
def _as_metadata(metadata_or_ctx:MetadataOrContext)->Metadata:
	metadata=getattr(metadata_or_ctx,'metadata',_A)
	if metadata is not _A:return metadata
	return metadata_or_ctx
def _first_semantic(metadata:Metadata)->t.Optional[ModelEntry]:models=sorted([m for m in metadata.models or[]if m.kind==_M],key=lambda m:m.name);return models[0]if models else _A
def _first_metric(metadata:Metadata)->t.Optional[ModelEntry]:models=sorted([m for m in metadata.models or[]if m.kind==_N],key=lambda m:m.name);return models[0]if models else _A
def _first_physical(metadata:Metadata)->t.Optional[ModelEntry]:data_models=[m for m in metadata.models or[]if m.kind not in(_N,_M,'EMBEDDED')];preferred=sorted([m for m in data_models if m.kind!='SEED']or data_models,key=lambda m:m.name);return preferred[0]if preferred else _A
def _short_name(model:ModelEntry)->str:return model.name.split('.')[-1]
def _public_measure_names(model:ModelEntry)->list[str]:return[c.name for c in model.columns if c.kind==_L and getattr(c,_J,_G)]
def _public_dimension_names(model:ModelEntry)->list[str]:return[c.name for c in model.columns if c.kind==_D and getattr(c,_J,_G)]
def _to_openapi_examples_dict(example:OpenApiExample)->dict:name=_example_slug(example.summary);return{name:{'summary':example.summary,_H:example.body}}
def _example_slug(summary:str)->str:name=re.sub('[^a-z0-9]+','_',summary.lower()).strip('_')[:50];return name or _C
def _semantic_model_example(metadata:Metadata)->tuple[t.Optional[ModelEntry],str,list[str],list[str]]:
	semantic=_first_semantic(metadata)
	if semantic is _A:return _A,'',[],[]
	return semantic,_short_name(semantic),_public_measure_names(semantic),_public_dimension_names(semantic)
def _metadata_example_builders()->dict[str,ExampleBuilder]:return{'submit_raw_sql':example_submit_raw_sql,'submit_semantic_rest_query':example_submit_semantic_rest_query,'submit_semantic_sql_query':example_submit_semantic_sql_query,'execute_semantic_graphql':example_execute_semantic_graphql,'submit_metric_query':example_submit_metric_query,'publish_tableau':example_publish_tableau}
_METADATA_EXAMPLE_BUILDERS:dict[str,ExampleBuilder]=_metadata_example_builders()
ParameterExampleBuilder=t.Callable[['Metadata'],str]
def _first_dq_dimension(metadata:Metadata)->str:
	for model in metadata.models or[]:
		dq=getattr(model,'dq',_A)
		if dq and getattr(dq,'rules',_A):return dq.rules[0].dimension
	return'completeness'
def _metric_name_parameter_example(metadata:Metadata)->str:metric=_first_metric(metadata);return _short_name(metric)if metric else'monthly_active_users'
def _physical_model_parameter_example(metadata:Metadata)->str:physical=_first_physical(metadata);return physical.name if physical else'my_product.my_model'
def _parameter_example_builders()->dict[tuple[str,str],ParameterExampleBuilder]:A='path';return{('metric_name',A):_metric_name_parameter_example,('model_name',A):_physical_model_parameter_example,('model',_B):_physical_model_parameter_example,('model_names',_B):_physical_model_parameter_example,(_D,_B):_first_dq_dimension}
_PARAMETER_EXAMPLE_BUILDERS:dict[tuple[str,str],ParameterExampleBuilder]=_parameter_example_builders()
def apply_metadata_parameter_examples_to_openapi(schema:dict,metadata:Metadata)->_A:
	for operation in iter_operations(schema):
		for param in operation.get('parameters',[]):
			if not isinstance(param,dict):continue
			key=param.get('name',''),param.get('in','');builder=_PARAMETER_EXAMPLE_BUILDERS.get(key)
			if builder is _A:continue
			param[_C]=builder(metadata)