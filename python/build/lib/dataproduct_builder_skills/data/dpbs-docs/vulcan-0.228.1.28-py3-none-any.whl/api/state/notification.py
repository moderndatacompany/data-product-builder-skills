from __future__ import annotations
_I='payload'
_H='summary'
_G='status'
_F='plan_id'
_E='run_id'
_D='event'
_C='environment'
_B='created_ts_ns'
_A=None
import json,typing as t
from sqlglot import exp
from vulcan.core import constants as c
from vulcan.core.notification import Notification,NotificationEvent
from api.state import ParamBinder,_col_eq_param,_pg,_table
from api.state.connection import StateConnection
from vulcan.core.state_sync.db.notification import NOTIFICATIONS
_NS_PER_SECOND=1000000000
NOTIFICATION_FEED_COLUMNS='id',_B,_D,_G,_H,_I,_C,_E,_F
class AsyncNotificationState:
	def __init__(self,conn:StateConnection)->_A:self._conn=conn;self._schema=conn.schema;self._notifications_table=_table(NOTIFICATIONS.name,self._schema)
	async def list_notifications(self,*,environment:t.Optional[str]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,run_id:t.Optional[str]=_A,plan_id:t.Optional[str]=_A,events:t.Optional[t.Sequence[NotificationEvent]]=_A,limit:int=50,offset:int=0)->t.Tuple[t.List[Notification],bool]:
		start_ns=start_ts*_NS_PER_SECOND if start_ts is not _A else _A;end_ns=end_ts*_NS_PER_SECOND if end_ts is not _A else _A;binder=ParamBinder();conditions:t.List[exp.Expression]=[]
		if run_id is not _A:conditions.append(_col_eq_param(_E,run_id,binder))
		elif plan_id is not _A:conditions.append(_col_eq_param(_F,plan_id,binder))
		else:conditions.append(_col_eq_param(_C,environment or c.PROD,binder))
		if start_ns is not _A:conditions.append(exp.GTE(this=exp.column(_B),expression=binder.add(start_ns)))
		if end_ns is not _A:conditions.append(exp.LTE(this=exp.column(_B),expression=binder.add(end_ns)))
		if environment is not _A and(run_id is not _A or plan_id is not _A):conditions.append(_col_eq_param(_C,environment,binder))
		if events:conditions.append(exp.column(_D).isin(*[binder.add(event.value)for event in events]))
		query=exp.select(*[exp.column(c)for c in NOTIFICATION_FEED_COLUMNS]).from_(self._notifications_table).where(exp.and_(*conditions)).order_by(exp.Ordered(this=exp.column(_B),desc=True)).limit(binder.add(limit+1)).offset(binder.add(offset));rows=await self._conn.fetch_rows(_pg(query),*binder.values);has_more=len(rows)>limit
		if has_more:rows=rows[:limit]
		return[self._row_to_notification(r)for r in rows],has_more
	def _row_to_notification(self,row:t.Dict[str,t.Any])->Notification:
		payload=row.get(_I)
		if isinstance(payload,str):
			try:payload=json.loads(payload)
			except(json.JSONDecodeError,TypeError):payload={}
		elif payload is _A:payload={}
		return Notification(id=row['id'],created_ts=int(row[_B])//_NS_PER_SECOND,event=row[_D],status=row[_G],summary=row[_H],payload=payload,environment=row.get(_C),run_id=row.get(_E),plan_id=row.get(_F))