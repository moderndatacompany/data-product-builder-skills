from __future__ import annotations
_A=True
import logging,typing as t
from fastapi import APIRouter,Depends,Query,Request,Response
from pgqueuer import QueueManager
from schema.auth import SecurityContext
from vulcan.core.query.definitions import QueryPolicyAudit,QueryType
from vulcan.core.query.transpiler import transpile
from api.context import EnvContext
from api.query.submit import submit_sql_via_flow
from api.query.transpile import convert_sql_dialect,get_filtered_request_headers,get_gateway_dialect,prepare_client_sql
from api.urls import parse_gateway_query
from api.schemas.query import SqlQueryRequest,StatementAccepted
from api.state import AsyncStateClient
from api.dependencies import get_client_dialect,get_env_context,get_statestore_client,get_queue_manager,get_user
from api.urls import urls
logger=logging.getLogger(__name__)
router=APIRouter()
@router.post('/semantic/sql',response_model=StatementAccepted,response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A,status_code=202,include_in_schema=False)
async def semantic_sql_for_mysql(request:Request,response:Response,sql_request:SqlQueryRequest,gateway:t.Optional[str]=Depends(parse_gateway_query),disable_post_processing:bool=Query(default=_A),retry_on_recent_failure:bool=Query(default=False),state:AsyncStateClient=Depends(get_statestore_client),env_ctx:EnvContext=Depends(get_env_context),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user),client_dialect:t.Optional[str]=Depends(get_client_dialect)):
	C='user_id';B='Authorization';A=None;exec_gateway=env_ctx.gateway(gateway);fixed_sql=prepare_client_sql(sql_request.sql,client_dialect,env_ctx.metadata);sql_to_transpile=fixed_sql
	if client_dialect:
		target_dialect=get_gateway_dialect(exec_gateway)
		if client_dialect.lower()!=target_dialect:sql_to_transpile=convert_sql_dialect(fixed_sql,source=client_dialect,target=target_dialect);logger.info('Internal semantic SQL: transpiled %s → %s',client_dialect,target_dialect)
	auth_headers={B:auth}if(auth:=request.headers.get(B))else A;transpiler_response=await transpile(query=sql_to_transpile,catalog=env_ctx.metadata,config=env_ctx.context.config,gateway=exec_gateway,user=user[C],security_context=SecurityContext.from_dict(user['security_context']),disable_cube_post_processing=disable_post_processing,headers=auth_headers);generated_sql=transpiler_response.wrapped_sql_statement;sql_params=transpiler_response.sql_params;policy=QueryPolicyAudit.from_semantic_query_context(transpiler_response.context)if transpiler_response.context is not A else A;accepted=await submit_sql_via_flow(sql=generated_sql,params=sql_params,ttl=0,request_meta=sql_request.meta,headers_meta=get_filtered_request_headers(request),server_meta={'via_mysql':_A,'client_dialect':client_dialect},gateway=exec_gateway,qm=qm,query_state=state.query,env_ctx=env_ctx,retry_on_recent_failure=retry_on_recent_failure,query_type=QueryType.SEMANTIC_SQL,semantic_query=sql_request.sql,submitted_by=user[C],policy=policy);response.headers['Location']=urls.query_statement_detail(accepted.id);return accepted