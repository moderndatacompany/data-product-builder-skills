from __future__ import annotations

import os
import re
import typing as t

import pydantic
from pydantic import Field, field_validator, model_validator
from typing_extensions import Literal

from schema import _PydanticModel
from schema.filters import (
    RestFilterExpression,
    validate_qualified_dimension,
    validate_qualified_member,
)
from schema.types import VALID_NAME_PATTERN

ORDER_MEMBER_PATTERN = re.compile(
    r"^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+$|^[a-zA-Z0-9_]+$|^[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+\.[a-zA-Z0-9_]+$"
)

RestOrderDirection = Literal["asc", "desc"]
RestDateRange = t.Union[str, t.List[str]]
RestOrderDict = t.Dict[str, RestOrderDirection]
RestOrderList = t.List[t.Tuple[str, RestOrderDirection]]
RestOrder = t.Union[RestOrderDict, RestOrderList]

SEMANTIC_REST_MAX_ROWS_ENV = "VULCAN_SEMANTIC_REST_MAX_ROWS"
DEFAULT_SEMANTIC_REST_MAX_ROWS = 100000
MAX_SEMANTIC_REST_MAX_ROWS = 10000000


def semantic_rest_max_rows() -> int:
    """Return the configured default and maximum semantic REST row limit."""
    raw = os.getenv(SEMANTIC_REST_MAX_ROWS_ENV)
    if raw is None:
        return DEFAULT_SEMANTIC_REST_MAX_ROWS
    try:
        return min(max(int(raw), 1), MAX_SEMANTIC_REST_MAX_ROWS)
    except ValueError:
        return DEFAULT_SEMANTIC_REST_MAX_ROWS


class RestTimeDimension(_PydanticModel):
    dimension: str
    granularity: t.Optional[str] = Field(default=None, max_length=128)
    dateRange: t.Optional[RestDateRange] = None
    compareDateRange: t.Optional[t.List[t.Any]] = None

    @field_validator("dimension")
    @classmethod
    def _validate_dimension_member(cls, value: str) -> str:
        return validate_qualified_member(value)

    @field_validator("dateRange")
    @classmethod
    def _validate_date_range(cls, value: t.Optional[RestDateRange]) -> t.Optional[RestDateRange]:
        if isinstance(value, list) and not (1 <= len(value) <= 2):
            raise ValueError("dateRange array must contain 1 or 2 values")
        return value

    @model_validator(mode="after")
    def _date_range_xor_compare(self) -> RestTimeDimension:
        if self.dateRange is not None and self.compareDateRange is not None:
            raise ValueError("provide dateRange or compareDateRange, not both")
        return self


class RestQuery(_PydanticModel):
    measures: t.Optional[t.List[str]] = None
    dimensions: t.Optional[t.List[str]] = None
    segments: t.Optional[t.List[str]] = None
    filters: t.Optional[t.List[RestFilterExpression]] = None
    timeDimensions: t.Optional[t.List[RestTimeDimension]] = None
    order: t.Optional[RestOrder] = None
    limit: int = Field(default_factory=semantic_rest_max_rows, ge=1)
    offset: t.Optional[int] = Field(default=None, ge=0)
    timezone: t.Optional[str] = "UTC"
    total: t.Optional[bool] = None
    ungrouped: t.Optional[bool] = None
    joinHints: t.Optional[t.List[t.List[str]]] = None

    model_config = pydantic.ConfigDict(extra="ignore", populate_by_name=True)

    @field_validator("measures", "segments")
    @classmethod
    def _validate_members(cls, value: t.Optional[t.List[str]]) -> t.Optional[t.List[str]]:
        if value is None:
            return value
        for item in value:
            validate_qualified_member(item)
        return value

    @field_validator("dimensions")
    @classmethod
    def _validate_dimensions(cls, value: t.Optional[t.List[str]]) -> t.Optional[t.List[str]]:
        if value is None:
            return value
        for item in value:
            validate_qualified_dimension(item)
        return value

    @field_validator("joinHints")
    @classmethod
    def _validate_join_hints(
        cls, value: t.Optional[t.List[t.List[str]]]
    ) -> t.Optional[t.List[t.List[str]]]:
        if value is None:
            return value
        for hint in value:
            if len(hint) < 2:
                raise ValueError("join hint must contain at least 2 model names")
            for name in hint:
                if not VALID_NAME_PATTERN.match(name):
                    raise ValueError(f"invalid join hint model name: {name!r}")
        return value

    @field_validator("order")
    @classmethod
    def _validate_order(cls, value: t.Optional[RestOrder]) -> t.Optional[RestOrder]:
        if value is None:
            return value
        if isinstance(value, dict):
            for key in value:
                if not ORDER_MEMBER_PATTERN.match(key):
                    raise ValueError(f"invalid order member: {key!r}")
            return value
        for item in value:
            if len(item) != 2:
                raise ValueError("order tuple must be [member, direction]")
            member, direction = item
            if not ORDER_MEMBER_PATTERN.match(member):
                raise ValueError(f"invalid order member: {member!r}")
            if direction not in ("asc", "desc"):
                raise ValueError(f"invalid order direction: {direction!r}")
        return value

    @field_validator("limit")
    @classmethod
    def _validate_limit(cls, value: int) -> int:
        maximum = semantic_rest_max_rows()
        if value > maximum:
            raise ValueError(
                f"limit must be less than or equal to {maximum} "
                f"({SEMANTIC_REST_MAX_ROWS_ENV})"
            )
        return value

    @model_validator(mode="after")
    def _at_least_one_query_member(self) -> RestQuery:
        if not any([self.measures, self.dimensions, self.timeDimensions]):
            raise ValueError(
                "query requires at least one of measures, dimensions, or timeDimensions"
            )
        return self

    @classmethod
    def from_storage(
        cls,
        raw: t.Mapping[str, t.Any] | str | None,
    ) -> RestQuery | None:
        """
        Parse a REST query from JSONB or a perspective denormalized field.

        Args:
            raw: Parsed JSON object, JSON string, or ``None`` when unset.

        Returns:
            Valid ``RestQuery``, or ``None`` when ``raw`` is missing.

        Raises:
            pydantic.ValidationError: If ``raw`` is present but not a valid query.
        """
        if raw is None:
            return None
        if isinstance(raw, str):
            if not raw.strip():
                return None
            return cls.model_validate_json(raw)
        return cls.model_validate(raw)
