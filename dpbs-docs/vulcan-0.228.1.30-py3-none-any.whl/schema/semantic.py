from __future__ import annotations

import typing as t

from pydantic import Field, model_serializer, model_validator
from typing_extensions import Literal

from schema import _PydanticModel
from schema.metadata import DimensionDetails, MeasureDetails, Metadata
from schema.types import (
    JoinRelationshipValue,
    MeasureBehaviorSpec,
    MeasureTypeValue,
    SemanticMeasureTypeValue,
)


class SemanticJoin(_PydanticModel):
    model: str
    relationship: JoinRelationshipValue
    expression: str


class SemanticColumn(_PydanticModel):
    kind: Literal["dimension", "measure"]
    name: str
    ltype: str
    dtype: str
    public: bool = True
    primary_key: bool = False
    description: t.Optional[str] = None
    tags: t.List[str] = Field(default_factory=list)
    terms: t.List[str] = Field(default_factory=list)
    queryable: bool = True
    response_field: str = ""
    aggregation: t.Optional[MeasureTypeValue] = None
    reaggregation: t.Optional[Literal["sum", "min", "max"]] = None
    semantic_type: t.Optional[SemanticMeasureTypeValue] = None
    additive: t.Optional[bool] = None
    measure_refs: t.List[str] = Field(default_factory=list)
    time_granularities: t.List[str] = Field(default_factory=list)

    @model_validator(mode="after")
    def _primary_key_only_for_dimensions(self) -> SemanticColumn:
        if self.kind == "measure" and self.primary_key:
            raise ValueError("semantic measure rows cannot use primary_key=True")
        return self

    @model_serializer(mode="wrap")
    def _semantic_column_wire(
        self,
        handler: t.Callable[..., t.Dict[str, t.Any]],
    ) -> t.Dict[str, t.Any]:
        data = dict(handler(self))
        if self.kind == "measure":
            data.pop("primary_key", None)
        else:
            data["primary_key"] = bool(self.primary_key)
        return data


def _safe_reaggregation(
    details: t.Optional[MeasureDetails],
    behavior: t.Optional[MeasureBehaviorSpec],
) -> t.Optional[Literal["sum", "min", "max"]]:
    if details is None or (behavior is not None and not behavior.is_additive):
        return None
    if details.agg_type in ("count", "sum"):
        return "sum"
    if details.agg_type in ("min", "max"):
        return details.agg_type
    return None


class SemanticEntry(_PydanticModel):
    name: str
    kind: Literal["SEMANTIC", "METRIC"]
    description: t.Optional[str] = None
    tags: t.List[str] = Field(default_factory=list)
    terms: t.List[str] = Field(default_factory=list)
    columns: t.List[SemanticColumn] = Field(default_factory=list)
    joins: t.List[SemanticJoin] = Field(default_factory=list)


class SemanticSchema(_PydanticModel):
    name: str
    tenant: str
    fingerprint: str
    models: t.List[SemanticEntry] = Field(default_factory=list)

    @classmethod
    def from_metadata(cls, metadata: Metadata) -> SemanticSchema:
        """
        Build the catalog semantic wire from exported metadata.

        Args:
            metadata: Full environment metadata document.

        Returns:
            Slim semantic schema with semantic and metric models and dimension/measure
            columns only.
        """
        models: t.List[SemanticEntry] = [
            SemanticEntry(
                name=m.name,
                kind=m.kind,
                description=m.description or None,
                tags=list(m.tags),
                terms=list(m.terms),
                columns=list(
                    SemanticColumn(
                        kind=col.kind,
                        name=col.name,
                        ltype=str(col.ltype),
                        dtype=col.dtype,
                        public=col.public,
                        primary_key=col.primary_key,
                        description=col.description,
                        tags=list(col.tags),
                        terms=list(col.terms),
                        # Queryability is a consumer-facing visibility contract.
                        # Primary keys remain present in metadata for internal
                        # pagination planning, but private keys must not become
                        # selectable merely because they identify rows.
                        queryable=col.public,
                        response_field=f"{m.name}.{col.name}",
                        aggregation=(
                            col.details.agg_type
                            if isinstance(col.details, MeasureDetails)
                            else None
                        ),
                        reaggregation=_safe_reaggregation(
                            col.details if isinstance(col.details, MeasureDetails) else None,
                            col.behavior if isinstance(col.behavior, MeasureBehaviorSpec) else None,
                        ),
                        semantic_type=(
                            col.behavior.type
                            if isinstance(col.behavior, MeasureBehaviorSpec)
                            else None
                        ),
                        additive=(
                            col.behavior.is_additive
                            if isinstance(col.behavior, MeasureBehaviorSpec)
                            else None
                        ),
                        measure_refs=(
                            list(col.behavior.measure_refs)
                            if isinstance(col.behavior, MeasureBehaviorSpec)
                            else []
                        ),
                        time_granularities=(
                            [g.name for g in col.details.time_granularities or []]
                            if isinstance(col.details, DimensionDetails)
                            else []
                        ),
                    )
                    for col in m.columns
                    if col.kind in ("measure", "dimension")
                ),
                joins=[
                    SemanticJoin(
                        model=j.model,
                        relationship=j.relationship,
                        expression=j.expression,
                    )
                    for j in m.joins
                ],
            )
            for m in metadata.models
            if m.kind in ("SEMANTIC", "METRIC")
        ]
        return cls(
            name=metadata.name,
            tenant=metadata.tenant,
            fingerprint=metadata.fingerprint,
            models=models,
        )
