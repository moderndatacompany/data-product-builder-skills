from __future__ import annotations
_L='text/markdown'
_K='content'
_J='text/markdown; charset=utf-8'
_I='application/gzip'
_H='application/zip'
_G='tar.gz'
_F='/index.md'
_E='ETag'
_D=False
_C=True
_B='Metadata'
_A='description'
import hashlib,logging,typing as t
from fastapi import APIRouter,Depends,HTTPException,Path,Query
from starlette.requests import Request
from starlette.responses import Response
from starlette.status import HTTP_400_BAD_REQUEST,HTTP_404_NOT_FOUND
from api.cache import CachePolicy,_MISSING,_make_cache_key,await_or_compute_singleflight,get_cache_storage
from api.context import EnvContext
from api.dependencies import get_env_context,get_env_context_manager,get_environment,get_statestore_client
from api.state import AsyncStateClient
from schema.odcs_contract import OdcsContract
from schema.odps_spec import OdpsProduct
from vulcan.core.export.bitol_contract import ModelNotFoundError,build_odcs_contract,build_odps_product
from vulcan.core.export.okf import build_okf,build_okf_archive
logger=logging.getLogger(__name__)
router=APIRouter(redirect_slashes=_D)
_OKF_BUNDLE_CACHE_PATH='/metadata/okf/_bundle'
_BITOL_URL='https://bitol.io/'
_ODCS_SPEC_URL='https://bitol-io.github.io/open-data-contract-standard/v3.1.0/'
_ODCS_SCHEMA_URL='https://github.com/bitol-io/open-data-contract-standard/blob/main/schema/odcs-json-schema-v3.1.0.json'
_ODPS_SPEC_URL='https://bitol-io.github.io/open-data-product-standard/v1.0.0/'
_ODPS_SCHEMA_URL='https://github.com/bitol-io/open-data-product-standard/blob/main/schema/odps-json-schema-v1.0.0.json'
_OKF_SPEC_URL='https://cloud.google.com/blog/products/data-analytics/open-knowledge-format'
@router.get('/odcs/{model_name}',summary='Get ODCS v3.1.0 data contract',description=f"Emits one model as an [Open Data Contract Standard (ODCS) v3.1.0]({_ODCS_SPEC_URL}) document, translated from the environment catalog. ODCS is an open standard from [Bitol]({_BITOL_URL}) (Linux Foundation AI & Data) for agreements between data producers and consumers.\n\nResponse is JSON aligned with the [ODCS v3.1.0 JSON Schema]({_ODCS_SCHEMA_URL}).",tags=[_B],response_model=OdcsContract,response_model_by_alias=_C,response_model_exclude_none=_C,responses={404:{_A:'Model not found'}})
async def get_contract(model_name:str=Path(...,title='Model name',examples=['customer.users']),env_ctx:EnvContext=Depends(get_env_context))->OdcsContract:
	try:return build_odcs_contract(env_ctx.metadata,model_name)
	except ModelNotFoundError as exc:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail=str(exc))from exc
@router.get('/odps/product',summary='Get ODPS v1.0.0 data product',description=f"Emits the Vulcan deployment as one [Open Data Product Standard (ODPS) v1.0.0]({_ODPS_SPEC_URL}) document, translated from the environment catalog. ODPS is an open standard from [Bitol]({_BITOL_URL}) for defining, documenting, and governing reusable data products.\n\nResponse is JSON aligned with the [ODPS v1.0.0 JSON Schema]({_ODPS_SCHEMA_URL}).",tags=[_B],response_model=OdpsProduct,response_model_by_alias=_C,response_model_exclude_none=_C)
async def get_product(env_ctx:EnvContext=Depends(get_env_context))->OdpsProduct:return build_odps_product(env_ctx.metadata)
def _okf_etag(env_ctx:EnvContext,last_run_ts_by_model:t.Dict[str,int])->str:max_run_ts=max(last_run_ts_by_model.values(),default=0);basis=f"{env_ctx.plan_id}:{max_run_ts}";return hashlib.sha256(basis.encode('utf-8')).hexdigest()
def _resolve_okf_path(path:str)->str:
	if not path or path.endswith('/'):directory=path.rstrip('/');return f"/{directory}/index.md"if directory else _F
	if not path.endswith('.md'):return f"/{path}/index.md"
	return f"/{path}"
async def _build_okf_bundle(request:Request,env_ctx:EnvContext,state:AsyncStateClient,*,base_url:str='')->t.Tuple[t.Dict[str,str],t.Dict[str,int]]:
	B='MISS';A='HIT'
	async def _compute()->t.Tuple[t.Dict[str,str],t.Dict[str,int]]:last_run_ts_by_model=await state.activity.get_last_successful_run_end_ts_by_model(env_ctx.environment);bundle=build_okf(env_ctx.metadata,last_run_ts_by_model,base_url=base_url);return bundle,last_run_ts_by_model
	try:manager=get_env_context_manager(request);environment=get_environment(request)
	except Exception:logger.info('[cache] status=SKIP reason=no_env_manager path=%s',_OKF_BUNDLE_CACHE_PATH);return await _compute()
	cache_key=_make_cache_key(policy=CachePolicy.RUN_CHANGE,endpoint_path=_OKF_BUNDLE_CACHE_PATH,environment=environment,plan_change_counter=None,run_change_counter=manager.get_run_change_counter(environment),params={'base_url':base_url});cached=get_cache_storage().get(cache_key);is_hit=cached is not _MISSING;request.state.cache_policy=CachePolicy.RUN_CHANGE.value.upper();request.state.cache_key=cache_key;request.state.cache_status=A if is_hit else B;logger.info('[cache] status=%s key=%s',A if is_hit else B,cache_key)
	if is_hit:return cached
	return await await_or_compute_singleflight(cache_key,ttl=None,compute=_compute)
@router.get('/okf',summary='Get OKF v0.2 knowledge bundle',description=f"""Serves the environment catalog as an [Open Knowledge Format (OKF) v0.2]({_OKF_SPEC_URL}) knowledge bundle — a linked tree of markdown concept files with YAML frontmatter for AI agents and humans.

**Browse (default)**

Returns the bundle root `index.md` as `text/markdown` (same document as `GET /okf/`).

**Download archive**

Pass `download=true` to download the full bundle. Optional `format`:

- `tar.gz` (default) — `application/gzip`
- `zip` — `application/zip`

For a single concept file, use `GET /okf/{{path}}` instead.""",tags=[_B],responses={200:{_A:'Bundle root `index.md` (`text/markdown`), or a full archive when `download=true`',_K:{_L:{},_I:{},_H:{}}}})
async def get_okf(request:Request,download:bool=Query(_D,description='When true, return the full bundle as a compressed archive instead of index.md'),archive_format:t.Literal[_G,'zip']=Query(_G,alias='format',description='Archive format used only when `download=true` (`tar.gz` or `zip`)'),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client))->Response:
	base_url=str(request.base_url).rstrip('/');bundle,last_run_ts_by_model=await _build_okf_bundle(request,env_ctx,state,base_url=base_url);etag=_okf_etag(env_ctx,last_run_ts_by_model)
	if download:archive_bytes=build_okf_archive(bundle,archive_format);media_type=_H if archive_format=='zip'else _I;metadata=env_ctx.metadata;filename=f"{metadata.name}-okf-{metadata.product.version}.{archive_format}";return Response(content=archive_bytes,media_type=media_type,headers={'Content-Disposition':f'attachment; filename="{filename}"',_E:etag})
	return Response(content=bundle[_F],media_type=_J,headers={_E:etag})
@router.get('/okf/{path:path}',summary='Get OKF v0.2 concept',description=f"""Returns one markdown concept from the [Open Knowledge Format (OKF) v0.2]({_OKF_SPEC_URL}) knowledge bundle for this environment.

Paths use a **directory-as-concept** layout. These all resolve to the same document:

- `semantics/users`
- `semantics/users/`
- `semantics/users/index.md`

Typical roots: `models/…`, `semantics/…`, `metrics/…`, plus nested member files such as `semantics/users/measures/count.md`.

Whole-bundle download is only available on `GET /okf?download=true` — `download=true` on this route returns `400`.""",tags=[_B],responses={200:{_A:'Concept markdown (`text/markdown`)',_K:{_L:{}}},400:{_A:'`download=true` is not valid here; use `GET /okf?download=true`'},404:{_A:'No concept exists at the resolved path'}})
async def get_okf_concept(request:Request,path:str=Path(...,title='Concept path within the OKF bundle',description='Bundle-relative path. Extensionless paths and trailing slashes resolve to `index.md` under that directory.',examples=['models/customer.users','semantics/users','metrics/arr_growth']),download:bool=Query(_D,description='Not supported on this route — use `GET /okf?download=true` for archives'),env_ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client))->Response:
	if download:raise HTTPException(status_code=HTTP_400_BAD_REQUEST,detail='download=true is only valid for GET /okf (whole-bundle download); use GET /okf?download=true')
	base_url=str(request.base_url).rstrip('/');bundle,last_run_ts_by_model=await _build_okf_bundle(request,env_ctx,state,base_url=base_url);resolved=_resolve_okf_path(path);content=bundle.get(resolved)
	if content is None:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail=f"OKF concept {resolved!r} not found")
	return Response(content=content,media_type=_J,headers={_E:_okf_etag(env_ctx,last_run_ts_by_model)})