from __future__ import annotations
_e='/api/v1/query/statement/01KXVG48FZ3QMDMK3RKJP03RPB/result'
_d='/api/v1/query/statement/01KXVG48FZ3QMDMK3RKJP03RPB'
_c='result'
_b='sha256:4a9c2e1f...'
_a='01KXVG48FZ3QMDMK3RKJP03RPB'
_Z='_links'
_Y='is_stale'
_X='fingerprint'
_W='status'
_V='statement_id'
_U='extensions'
_T='example'
_S='Is-Stale'
_R='content'
_Q='headers'
_P='schema'
_O='Transpiler unavailable'
_N='Transpiler error'
_M='application/json'
_L='Location'
_K='security_context'
_J='href'
_I='Authorization'
_H='No-Reuse-Results'
_G='Retry even if an identical query failed recently.'
_F='model'
_E='user_id'
_D=True
_C=None
_B=False
_A='description'
import json,logging,time,typing as t
from typing import TYPE_CHECKING
if TYPE_CHECKING:0
from fastapi import APIRouter,Depends,Header,HTTPException,Query,Request,Response,status
from pgqueuer import QueueManager
from api.context import EnvContext
from api.query.results import IS_STALE_OPENAPI_HEADER
from api.query.submit import submit_sql_via_flow
from api.query.transpile import get_filtered_request_headers,transpile_or_http_error
from api.schemas.query import GraphQLAcceptedResponse,GraphQLSuccessResponse,GraphQLRequest,QueryType,RestQueryRequest,SemanticQueryTranspiled,SqlQueryRequest,StatementAccepted,StatementRequest
from api.dependencies import get_env_context,get_object_store,get_queue_manager,get_statestore_client,get_user
from api.state import AsyncStateClient
from api.utils.commons import timestamp_to_iso
from api.urls import parse_gateway_query,parse_transpile_only_query,urls
from schema.auth import SecurityContext
from vulcan.core.query.definitions import QueryPolicyAudit
from vulcan.core.query.rewriter import rewrite
from vulcan.core.query import ObjectStoreClient
from vulcan.utils.errors import VulcanError
logger=logging.getLogger(__name__)
router=APIRouter()
_ACCEPTED_202='Statement accepted for async execution.\n\nPoll `GET /query/statement/{id}` until status is SUCCESS or FAILED, then fetch\nresults via `GET /query/statement/{id}/result` (see **Query Result** endpoints).\n\nThe response body includes ``is_stale`` when dependencies have pending intervals or a\nlatest failed run\n(body only on 202; no ``Is-Stale`` header on submit).\n'
_TRANSPILED_200='Semantic query transpiled successfully.\n\nNo statement was created. Use the `sql` field in the response body as the\ncompiled warehouse SQL.\n'
@router.get('/usage-metrics',summary='Get Usage Metrics',tags=['Usage Metrics'],operation_id='get_usage_metrics',responses={200:{_A:'Usage metrics for the requested week'},400:{_A:'Invalid week_start parameter'}})
async def usage_metrics(week_start:str|_C=Query(default=_C,examples=['2025-05-19'],description='Monday of the week in UTC (YYYY-MM-DD). Default: current week.'),state:AsyncStateClient=Depends(get_statestore_client))->dict[str,t.Any]:
	from datetime import datetime,timezone;week_start_dt:datetime|_C
	if week_start is _C:week_start_dt=_C
	else:
		try:week_start_dt=datetime.strptime(week_start,'%Y-%m-%d').replace(tzinfo=timezone.utc)
		except ValueError:raise HTTPException(status_code=400,detail='week_start must be YYYY-MM-DD (e.g. 2025-02-10)')
	try:return await state.query.get_usage_metrics(week_start=week_start_dt)
	except VulcanError as e:raise HTTPException(status_code=501,detail=str(e))
@router.post('/statement',summary='Submit Raw SQL Query',tags=['Data Model Query'],operation_id='submit_raw_sql',status_code=202,response_model=StatementAccepted,response_model_by_alias=_D,response_model_exclude_unset=_D,response_model_exclude_none=_D,responses={202:{_A:_ACCEPTED_202},400:{_A:'Invalid SQL, validation error, or recent identical failure'},422:{_A:'Request validation error'}})
async def submit_raw_sql(body:StatementRequest,request:Request,response:Response,env_ctx:EnvContext=Depends(get_env_context),gateway:t.Optional[str]=Depends(parse_gateway_query),retry_on_recent_failure:bool=Query(default=_B,examples=[_B],description=_G),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user),state:AsyncStateClient=Depends(get_statestore_client),no_reuse_results:bool=Header(default=_B,alias=_H,include_in_schema=_B)):exec_gateway=env_ctx.gateway(gateway);connection=env_ctx.context.config.get_connection(exec_gateway);rewritten=rewrite(sql=body.sql,user=user[_E],metadata=env_ctx.metadata,security_context=SecurityContext.from_dict(user[_K]),dialect=env_ctx.dialect(exec_gateway),default_catalog=connection.get_catalog());policy=QueryPolicyAudit.from_rewrite_result(rewritten,metadata=env_ctx.metadata);accepted=await submit_sql_via_flow(sql=rewritten.rewritten_sql,source_query=body.sql,params=body.params,request_meta=body.meta,headers_meta=get_filtered_request_headers(request),gateway=exec_gateway,qm=qm,query_state=state.query,env_ctx=env_ctx,retry_on_recent_failure=retry_on_recent_failure,query_type=QueryType.SOURCE_SQL,submitted_by=user[_E],policy=policy,no_reuse_results=no_reuse_results);response.headers[_L]=urls.query_statement_detail(accepted.id);return accepted
@router.post('/semantic/rest',summary='Submit Semantic REST Query',tags=['Semantic REST'],operation_id='submit_semantic_rest_query',response_model=_C,response_model_by_alias=_D,response_model_exclude_unset=_D,response_model_exclude_none=_D,status_code=202,responses={200:{_A:_TRANSPILED_200,_F:SemanticQueryTranspiled},202:{_A:_ACCEPTED_202,_F:StatementAccepted},400:{_A:'Invalid REST semantic query or SQL generation failed'},502:{_A:_N},503:{_A:_O}})
async def semantic_rest(request:Request,response:Response,rest_request:RestQueryRequest,env_ctx:EnvContext=Depends(get_env_context),gateway:t.Optional[str]=Depends(parse_gateway_query),disable_post_processing:bool=Query(default=_D,include_in_schema=_B),transpile_only:bool=Depends(parse_transpile_only_query),retry_on_recent_failure:bool=Query(default=_B,examples=[_B],description=_G),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user),no_reuse_results:bool=Header(default=_B,alias=_H,include_in_schema=_B))->t.Union[SemanticQueryTranspiled,StatementAccepted]:
	exec_gateway=env_ctx.gateway(gateway);auth_headers={_I:auth}if(auth:=request.headers.get(_I))else _C;transpiler_response=await transpile_or_http_error(rest_request.query,invalid_msg='Invalid REST semantic query',disable_post_processing=disable_post_processing,user=user[_E],security_context=SecurityContext.from_dict(user[_K]),env_ctx=env_ctx,gateway=exec_gateway,auth_headers=auth_headers);generated_sql=transpiler_response.wrapped_sql_statement;sql_params=transpiler_response.sql_params
	if rest_request.graphql_body:query_type=QueryType.SEMANTIC_GRAPHQL;graphql_query=rest_request.graphql_body
	else:query_type=QueryType.SEMANTIC_REST;graphql_query=_C
	if transpile_only:response.status_code=status.HTTP_200_OK;return SemanticQueryTranspiled(sql=generated_sql,params=sql_params,cols_mapping=transpiler_response.alias_mapping or _C,query_type=query_type,meta=rest_request.meta,gateway=exec_gateway,dialect=env_ctx.dialect(exec_gateway),transpiled_at=timestamp_to_iso(int(time.time()*1000)))
	policy=QueryPolicyAudit.from_semantic_query_context(transpiler_response.context)if transpiler_response.context is not _C else _C;accepted=await submit_sql_via_flow(sql=generated_sql,params=sql_params,request_meta=rest_request.meta,headers_meta=get_filtered_request_headers(request),gateway=exec_gateway,qm=qm,query_state=state.query,env_ctx=env_ctx,retry_on_recent_failure=retry_on_recent_failure,query_type=query_type,rest_query=rest_request.query,graphql_query=graphql_query,submitted_by=user[_E],policy=policy,no_reuse_results=no_reuse_results);response.status_code=status.HTTP_202_ACCEPTED;response.headers[_L]=urls.query_statement_detail(accepted.id);return accepted
@router.post('/semantic/sql',summary='Submit Semantic SQL Query',tags=['Semantic SQL'],operation_id='submit_semantic_sql_query',response_model=_C,response_model_by_alias=_D,response_model_exclude_unset=_D,response_model_exclude_none=_D,status_code=202,responses={200:{_A:_TRANSPILED_200,_F:SemanticQueryTranspiled},202:{_A:_ACCEPTED_202,_F:StatementAccepted},400:{_A:'Invalid semantic SQL query or compilation failed'},502:{_A:_N},503:{_A:_O}})
async def semantic_sql(request:Request,response:Response,sql_request:SqlQueryRequest,env_ctx:EnvContext=Depends(get_env_context),gateway:t.Optional[str]=Depends(parse_gateway_query),disable_post_processing:bool=Query(default=_D,include_in_schema=_B),transpile_only:bool=Depends(parse_transpile_only_query),retry_on_recent_failure:bool=Query(default=_B,examples=[_B],description=_G),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user),no_reuse_results:bool=Header(default=_B,alias=_H,include_in_schema=_B))->t.Union[SemanticQueryTranspiled,StatementAccepted]:
	exec_gateway=env_ctx.gateway(gateway);auth_headers={_I:auth}if(auth:=request.headers.get(_I))else _C;transpiler_response=await transpile_or_http_error(sql_request.sql,invalid_msg='Invalid semantic SQL query',disable_post_processing=disable_post_processing,user=user[_E],security_context=SecurityContext.from_dict(user[_K]),env_ctx=env_ctx,gateway=exec_gateway,auth_headers=auth_headers);generated_sql=transpiler_response.wrapped_sql_statement;sql_params=transpiler_response.sql_params
	if transpile_only:response.status_code=status.HTTP_200_OK;return SemanticQueryTranspiled(sql=generated_sql,params=sql_params,cols_mapping=transpiler_response.alias_mapping or _C,query_type=QueryType.SEMANTIC_SQL,meta=sql_request.meta,gateway=exec_gateway,dialect=env_ctx.dialect(exec_gateway),transpiled_at=timestamp_to_iso(int(time.time()*1000)))
	policy=QueryPolicyAudit.from_semantic_query_context(transpiler_response.context)if transpiler_response.context is not _C else _C;accepted=await submit_sql_via_flow(sql=generated_sql,params=sql_params,request_meta=sql_request.meta,headers_meta=get_filtered_request_headers(request),gateway=exec_gateway,qm=qm,query_state=state.query,env_ctx=env_ctx,retry_on_recent_failure=retry_on_recent_failure,query_type=QueryType.SEMANTIC_SQL,semantic_query=sql_request.sql,submitted_by=user[_E],policy=policy,no_reuse_results=no_reuse_results);response.status_code=status.HTTP_202_ACCEPTED;response.headers[_L]=urls.query_statement_detail(accepted.id);return accepted
@router.post('/semantic/graphql',summary='Execute Semantic GraphQL Query',tags=['Semantic GraphQL'],operation_id='execute_semantic_graphql',response_class=Response,include_in_schema=_D,openapi_extra={'parameters':[{'name':'X-User','in':'header','required':_B,_A:'User identity used for transpilation and query audit. Injected automatically from the authenticated user context; clients do not need to set this header.',_P:{'type':'string'}}]},responses={200:{_A:'GraphQL JSON payload returned inline. Successful queries return ``data.table`` with nested model rows and top-level ``extensions`` mirroring ``StatementAccepted`` execution fields (``statement_id``, ``strategy``, ``status``, ``fingerprint``, ``is_stale``, ``_links``, optional ``reuse``, optional ``primary``). When ``extensions.is_stale`` is true, the response also includes an ``Is-Stale: true`` header. Some resolver failures (for example missing result columns) may still use HTTP 200 with an ``errors`` array in the body.',_F:GraphQLSuccessResponse,_Q:{_S:IS_STALE_OPENAPI_HEADER},_R:{_M:{_T:{'data':{'table':[{'users':{'plan_type':'pro','total_users':42}}]},_U:{_V:_a,'strategy':'REUSE_RESULT',_W:'SUCCESS',_X:_b,_Y:_B,'reuse':{'computed_at':'2026-01-01T00:07:00.000Z','age_seconds':420},_Z:{'self':{_J:_d},_c:{_J:_e}}}}}}},202:{_A:'**Accepted** — the warehouse query is still running after the configured poll window. Body: ``{"data": null, "extensions": {"statement_id": "...", "status": "IN_PROGRESS", "message": "...", "is_stale": false, "_links": {...}}}``. Retry the same GraphQL request after the ``Retry-After`` header (seconds). Resubmitting is safe: deduplication reuses in-flight or completed warehouse work.',_F:GraphQLAcceptedResponse,_Q:{'Retry-After':{_A:'Seconds before retrying the same GraphQL request',_P:{'type':'integer'}},_S:IS_STALE_OPENAPI_HEADER},_R:{_M:{_T:{'data':_C,_U:{_V:_a,_W:'IN_PROGRESS','message':'Query still processing, please retry after some time.',_X:_b,'submitted_at':'2026-01-01T00:00:00.000Z',_Y:_B,_Z:{'self':{_J:_d},_c:{_J:_e}}}}}}},400:{_A:'Invalid GraphQL document, transpilation failure, or warehouse execution error. Body: `{"errors": [{"message": "..."}]}`.'},500:{_A:'Unexpected internal error processing the GraphQL request.'}})
async def graphql(body:GraphQLRequest,request:Request,env_ctx:EnvContext=Depends(get_env_context),gateway:t.Optional[str]=Depends(parse_gateway_query),retry_on_recent_failure:bool=Query(default=_B,examples=[_B],description=_G),no_reuse_results:bool=Header(default=_B,alias=_H,include_in_schema=_B),user:t.Dict[str,t.Any]=Depends(get_user),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),object_store:ObjectStoreClient=Depends(get_object_store))->Response:from api.endpoints.query.graphql import execute as execute_graphql;payload,status_code,headers=await execute_graphql(query=body.query,variables=body.variables,operation_name=body.operationName,artifacts=env_ctx.graphql,env_ctx=env_ctx,request=request,user=user,state=state,qm=qm,object_store=object_store,retry_on_recent_failure=retry_on_recent_failure,no_reuse_results=no_reuse_results,gateway=gateway);return Response(content=json.dumps(payload),status_code=status_code,headers=headers,media_type=_M)