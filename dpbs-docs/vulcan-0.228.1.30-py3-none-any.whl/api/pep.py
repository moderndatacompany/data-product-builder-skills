from __future__ import annotations
from api.heimdall import AuthorizationAtom
def build_dataproduct_access_atom(name:str)->AuthorizationAtom:
	name=name.strip()
	if not name:raise ValueError('data product name is required')
	return AuthorizationAtom(id='vulcan-data-product-access',predicate='read',tags=[f"dataos:dataproduct:{name}"])