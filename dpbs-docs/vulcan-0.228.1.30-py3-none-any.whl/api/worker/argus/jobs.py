from __future__ import annotations
_D='run_finished'
_C='utf-8'
_B='plan_updated'
_A=None
import logging,time,typing as t
from datetime import timedelta
from pgqueuer.errors import DuplicateJobError
from pgqueuer.models import Job
from pydantic import BaseModel
from vulcan.core import constants as c
from api.context import EnvContextManager
from api.pool import run_blocking_fast
from api.worker import EnqueueQueueManager,WorkerQueueManager
from api.worker.argus.client import post_event
logger=logging.getLogger(__name__)
ArgusNotifyEventType=t.Literal[_B,_D]
ARGUS_NOTIFY_ENTRYPOINT='argus_notify'
ARGUS_HEARTBEAT_ENTRYPOINT='argus_heartbeat'
HEARTBEAT_LOG_CLEANUP_SECONDS=3600
_DEFAULT_DELAY=timedelta(seconds=5)
MAX_RETRIES=3
class ArgusNotifyPayload(BaseModel):event_type:ArgusNotifyEventType;environment:str;plan_id:t.Optional[str]=_A;run_id:t.Optional[str]=_A;retry_count:int=0
class ArgusHeartbeatPayload(BaseModel):heartbeat_slot:int
def _is_prod(environment:str)->bool:return environment==c.PROD
def _dedupe_key(payload:ArgusNotifyPayload)->str:
	natural_id=f"plan:{payload.plan_id}"if payload.event_type==_B else f"run:{payload.run_id}";parts=[ARGUS_NOTIFY_ENTRYPOINT,payload.event_type,payload.environment,natural_id]
	if payload.retry_count:parts.append(str(payload.retry_count))
	return':'.join(parts)
async def _enqueue(qm:EnqueueQueueManager,payload:ArgusNotifyPayload,*,delay:timedelta)->t.Any:
	if not _is_prod(payload.environment):return
	try:return await qm.queries.enqueue([ARGUS_NOTIFY_ENTRYPOINT],[payload.model_dump_json().encode(_C)],execute_after=[delay],dedupe_key=[_dedupe_key(payload)])
	except DuplicateJobError:logger.debug('Argus %s already pending/running for %s; dropping duplicate',payload.event_type,payload.environment);return
async def enqueue_argus_plan_updated(qm:EnqueueQueueManager,environment:str,*,plan_id:t.Optional[str],delay:timedelta=_DEFAULT_DELAY,retry_count:int=0)->t.Any:
	if not plan_id:logger.warning('Skipping Argus plan_updated: env=%s reason=no_plan_id',environment);return
	return await _enqueue(qm,ArgusNotifyPayload(event_type=_B,environment=environment,plan_id=plan_id,retry_count=retry_count),delay=delay)
async def enqueue_argus_run_finished(qm:EnqueueQueueManager,environment:str,*,run_id:t.Optional[str],delay:timedelta=_DEFAULT_DELAY,retry_count:int=0)->t.Any:
	if not run_id:logger.warning('Skipping Argus run_finished: env=%s reason=no_run_id',environment);return
	return await _enqueue(qm,ArgusNotifyPayload(event_type=_D,environment=environment,run_id=run_id,retry_count=retry_count),delay=delay)
def _next_heartbeat_slot(interval:int)->tuple[int,timedelta]:now=time.time();slot=(int(now)//interval+1)*interval;return slot,timedelta(seconds=max(0,slot-now))
async def enqueue_argus_heartbeat(qm:EnqueueQueueManager,*,heartbeat_slot:int,delay:timedelta=timedelta(0))->t.Any:
	payload=ArgusHeartbeatPayload(heartbeat_slot=heartbeat_slot)
	try:return await qm.queries.enqueue([ARGUS_HEARTBEAT_ENTRYPOINT],[payload.model_dump_json().encode(_C)],execute_after=[delay],dedupe_key=[f"{ARGUS_HEARTBEAT_ENTRYPOINT}:{heartbeat_slot}"])
	except DuplicateJobError:logger.debug('Argus heartbeat slot %s already scheduled',heartbeat_slot);return
async def seed_argus_heartbeat(qm:EnqueueQueueManager,manager:EnvContextManager)->t.Any:
	cfg=getattr(manager.context.config,'argus',_A)
	if not cfg or not cfg.enabled:return
	slot,delay=_next_heartbeat_slot(cfg.health_heartbeat_interval_seconds)
	try:return await enqueue_argus_heartbeat(qm,heartbeat_slot=slot,delay=delay)
	except Exception:logger.warning('Failed to seed Argus heartbeat',exc_info=True);return
def register_argus_entrypoints(qm:WorkerQueueManager,manager:EnvContextManager,qm_enqueue:EnqueueQueueManager)->_A:
	C='product';B='tenant';A=b'{}'
	@qm.entrypoint(ARGUS_NOTIFY_ENTRYPOINT,concurrency_limit=1)
	async def handle_argus_notify(job:Job)->_A:
		payload=ArgusNotifyPayload.model_validate_json((job.payload or A).decode(_C));env=payload.environment;event_type=payload.event_type;cfg=getattr(manager.context.config,'argus',_A)
		if not cfg or not cfg.enabled:logger.debug('Skipping Argus %s: reason=disabled',event_type);return
		env_ctx=manager.get_env_context(env);tenant=getattr(env_ctx,B,'');product_name=getattr(env_ctx,C,'')
		if not tenant or not product_name:logger.warning('Skipping Argus %s: env=%s reason=missing_tenant_or_product',event_type,env);return
		dispatch_error:BaseException|_A=_A
		try:await run_blocking_fast(post_event,cfg,event_type=event_type,tenant=tenant,product_name=product_name,run_id=payload.run_id)
		except Exception as exc:dispatch_error=exc
		if dispatch_error is not _A:
			if payload.retry_count<MAX_RETRIES:
				backoff=_DEFAULT_DELAY*2**payload.retry_count
				if event_type==_B:await enqueue_argus_plan_updated(qm_enqueue,env,plan_id=payload.plan_id,delay=backoff,retry_count=payload.retry_count+1)
				else:await enqueue_argus_run_finished(qm_enqueue,env,run_id=payload.run_id,delay=backoff,retry_count=payload.retry_count+1)
				logger.warning('Argus %s failed, retry %d scheduled: %s',event_type,payload.retry_count+1,dispatch_error);return
			logger.error('Argus %s exhausted %d retries: %s',event_type,MAX_RETRIES,dispatch_error)
	@qm.entrypoint(ARGUS_HEARTBEAT_ENTRYPOINT,concurrency_limit=1)
	async def handle_argus_heartbeat(job:Job)->_A:
		payload=ArgusHeartbeatPayload.model_validate_json((job.payload or A).decode(_C));cfg=manager.context.config.argus
		if not cfg or not cfg.enabled:logger.debug('Stopping Argus heartbeat chain: reason=disabled');return
		interval=cfg.health_heartbeat_interval_seconds;cleanup_every_windows=max(1,HEARTBEAT_LOG_CLEANUP_SECONDS//interval)
		if payload.heartbeat_slot//interval%cleanup_every_windows==0:
			try:await qm_enqueue.queries.clear_queue_log(ARGUS_HEARTBEAT_ENTRYPOINT);await qm_enqueue.queries.clear_statistics_log(ARGUS_HEARTBEAT_ENTRYPOINT)
			except Exception:logger.warning('Failed to prune Argus heartbeat queue logs',exc_info=True)
		next_slot,delay=_next_heartbeat_slot(interval);await enqueue_argus_heartbeat(qm_enqueue,heartbeat_slot=next_slot,delay=delay);env_ctx=manager.get_env_context(c.PROD);tenant=getattr(env_ctx,B,'');product_name=getattr(env_ctx,C,'')
		if not tenant or not product_name:logger.warning('Skipping Argus heartbeat: reason=missing_tenant_or_product');return
		try:await run_blocking_fast(post_event,cfg,event_type='heartbeat',tenant=tenant,product_name=product_name)
		except Exception as exc:logger.warning('Argus heartbeat delivery failed; next heartbeat remains scheduled: %s',exc)