from __future__ import annotations
_J='run_id'
_I='end_ts'
_H='plan_id'
_G=False
_F='success'
_E='environment'
_D=True
_C='plan_seq'
_B='start_ts'
_A=None
import typing as t
from sqlglot import exp
from vulcan.core.activity import EnvironmentChange,PlanActivity
from api.schemas.activity import PlanChangeCounts,PlanSummaryBase,RunSqlStatement
from api.state import ParamBinder,_col_eq_param,_pg,_table,_table_sql
from api.state.connection import StateConnection,_ConnContext
from vulcan.core.state_sync.db.activity import ACTIVITY_PLANS,ACTIVITY_RUNS
from vulcan.core.state_sync.db.query_fingerprints import fingerprint_model_lock_key
from vulcan.core.state_sync.db.query_history import QUERY_HISTORY
def _plan_model_impact_overlap(model_names:t.List[str],impact:str,binder:ParamBinder)->exp.Expression:
	models_expr=binder.add(model_names);direct=exp.ArrayOverlaps(this=exp.column('models_affected_directly'),expression=models_expr);indirect=exp.ArrayOverlaps(this=exp.column('models_affected_indirectly'),expression=models_expr);metadata=exp.ArrayOverlaps(this=exp.column('models_affected_metadata'),expression=models_expr)
	if impact=='direct':return direct
	if impact=='indirect':return indirect
	if impact=='metadata':return metadata
	return exp.or_(direct,indirect,metadata)
class AsyncActivityState:
	def __init__(self,conn:StateConnection)->_A:self._conn=conn;self._schema=conn.schema;self._plans_table=_table(ACTIVITY_PLANS.name,self._schema);self._runs_table=_table(ACTIVITY_RUNS.name,self._schema);self._sql_history_table=_table(QUERY_HISTORY.name,self._schema);self._runs_models_index_verified=_G
	async def list_run_sql_statements(self,*,run_id:str,kind:t.Optional[str]=_A,status:t.Optional[str]=_A,limit:int=100,offset:int=0)->t.Tuple[t.List[RunSqlStatement],int,bool]:
		M='params';L='sql_text';K='normalized_sql';J='executor';I='error_message';H='row_count';G='duration_ms';F='dialect';E='component';D='total';C='id';B='status';A='statement_kind';binder=ParamBinder();conditions:t.List[exp.Expression]=[_col_eq_param(_J,run_id,binder)]
		if kind is not _A:conditions.append(_col_eq_param(A,kind.upper(),binder))
		if status is not _A:conditions.append(_col_eq_param(B,status,binder))
		where=exp.and_(*conditions);count_query=exp.select(exp.Count(this=exp.Star()).as_(D)).from_(self._sql_history_table).where(where);count_row=await self._conn.fetch_row(_pg(count_query),*binder.values);total=int(count_row[D])if count_row else 0;list_query=exp.select(C,E,A,F,B,G,H,I,J,K,L,M).from_(self._sql_history_table).where(where).order_by(exp.Ordered(this=exp.column(C),desc=_G)).limit(binder.add(limit+1)).offset(binder.add(offset));rows=await self._conn.fetch_rows(_pg(list_query),*binder.values);has_more=len(rows)>limit
		if has_more:rows=rows[:limit]
		statements=[RunSqlStatement(id=row[C],component=row.get(E),kind=row.get(A),dialect=row[F],status=row[B],duration_ms=row.get(G),row_count=row.get(H),error=row.get(I),executor=row[J],sql=row.get(K)or row.get(L)or'',params=row.get(M))for row in rows];return statements,total,has_more
	async def list_plans(self,plan_id:t.Optional[str]=_A,environment:t.Optional[str]=_A,plan_seq:t.Optional[int]=_A,model_names:t.Optional[t.List[str]]=_A,impact:str='all',success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[PlanActivity]:
		A='plan_diff';order=exp.Ordered(this=exp.column(_B),desc=_D);binder=ParamBinder()
		if plan_id:query=exp.select(exp.column(A),exp.column(_C)).from_(self._plans_table).where(_col_eq_param(_H,plan_id,binder)).order_by(order)
		else:
			if environment is _A:return[]
			conditions:t.List[exp.Expression]=[_col_eq_param(_E,environment,binder)]
			if plan_seq is not _A:conditions.append(_col_eq_param(_C,plan_seq,binder))
			if model_names:conditions.append(_plan_model_impact_overlap(model_names,impact,binder))
			if success is not _A:conditions.append(exp.column(_F).eq(exp.true()if success else exp.false()))
			start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A
			if start_ms is not _A:conditions.append(exp.GTE(this=exp.column(_B),expression=binder.add(start_ms)))
			if end_ms is not _A:conditions.append(exp.LTE(this=exp.column(_B),expression=binder.add(end_ms)))
			query=exp.select(exp.column(A),exp.column(_C)).from_(self._plans_table).where(exp.and_(*conditions)).order_by(order).limit(binder.add(limit)).offset(binder.add(offset))
		rows=await self._conn.fetch_rows(_pg(query),*binder.values);plans:t.List[PlanActivity]=[]
		for row in rows:
			plan_diff_json=row.get(A);plan_seq_val=row.get(_C)
			if not plan_diff_json:continue
			if isinstance(plan_diff_json,str):plan_activity=PlanActivity.parse_raw(plan_diff_json)
			else:plan_activity=PlanActivity.model_validate(plan_diff_json)
			plans.append(plan_activity.model_copy(update={_C:plan_seq_val}))
		return plans
	async def get_plan(self,plan_id:str)->t.Optional[PlanActivity]:plans=await self.list_plans(plan_id=plan_id);return plans[0]if plans else _A
	async def get_plan_by_seq(self,environment:str,plan_seq:int)->t.Optional[PlanActivity]:plans=await self.list_plans(environment=environment,plan_seq=plan_seq,limit=1);return plans[0]if plans else _A
	async def list_plan_summaries(self,environment:str,model_names:t.Optional[t.List[str]]=_A,impact:str='all',success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[PlanSummaryBase]:
		I='has_environment_changes';H='has_requirements_changes';G='count_backfills';F='count_metadata';E='count_removed';D='count_indirect';C='count_added';B='count_direct';A='version';order=exp.Ordered(this=exp.column(_B),desc=_D);binder=ParamBinder();conditions:t.List[exp.Expression]=[_col_eq_param(_E,environment,binder)]
		if model_names:conditions.append(_plan_model_impact_overlap(model_names,impact,binder))
		if success is not _A:conditions.append(exp.column(_F).eq(exp.true()if success else exp.false()))
		start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A
		if start_ms is not _A:conditions.append(exp.GTE(this=exp.column(_B),expression=binder.add(start_ms)))
		if end_ms is not _A:conditions.append(exp.LTE(this=exp.column(_B),expression=binder.add(end_ms)))
		select_columns=[_H,_C,A,_B,_I,_F,B,C,D,E,F,G,H,I];query=exp.select(*select_columns).from_(self._plans_table).where(exp.and_(*conditions)).order_by(order).limit(binder.add(limit)).offset(binder.add(offset));rows=await self._conn.fetch_rows(_pg(query),*binder.values);return[PlanSummaryBase(plan_id=row[_H],plan_seq=int(row.get(_C)or 0),version=row.get(A)or'',start_ts=int(row[_B]),end_ts=int(row[_I]),success=bool(row[_F]),changes=PlanChangeCounts(direct=int(row.get(B)or 0),added=int(row.get(C)or 0),indirect=int(row.get(D)or 0),removed=int(row.get(E)or 0),metadata=int(row.get(F)or 0)),count_backfills=int(row.get(G)or 0),has_requirements_changes=bool(row.get(H)),has_environment_changes=bool(row.get(I)))for row in rows]
	async def fetch_plan_run_activity_since(self,since_ts_ns:int=0)->t.Tuple[t.List[EnvironmentChange],int]:
		C='event_id';B='action_type';A='created_ts_ns';binder=ParamBinder();watermark=binder.add(since_ts_ns);plans_query=exp.select(_E,exp.Literal.string('plan').as_(B),A,exp.column(_H).as_(C)).from_(self._plans_table).where(exp.GT(this=exp.column(A),expression=watermark));runs_query=exp.select(_E,exp.Literal.string('run').as_(B),A,exp.column(_J).as_(C)).from_(self._runs_table).where(exp.GT(this=exp.column(A),expression=watermark));combined_query=exp.union(plans_query,runs_query,distinct=_G);combined_query=combined_query.order_by(exp.Ordered(this=exp.column(A),desc=_D));rows=await self._conn.fetch_rows(_pg(combined_query),*binder.values)
		if not rows:return[],since_ts_ns
		changes_dict:t.Dict[str,EnvironmentChange]={};max_ts_ns=since_ts_ns
		for row in rows:
			env_name=row[_E];action_type=row[B];ts=row[A];change=changes_dict.setdefault(env_name,EnvironmentChange(environment=env_name));setattr(change,f"has_{action_type}",_D);getattr(change,f"{action_type}_ids").append(row[C])
			if ts>max_ts_ns:max_ts_ns=ts
		return list(changes_dict.values()),max_ts_ns
	async def get_last_successful_run_end_ts_by_model(self,environment:str)->t.Dict[str,int]:runs_table_str=_table_sql('_runs',self._schema);sql=f"""
            SELECT
                model_name,
                MAX(end_ts) AS ts
            FROM {runs_table_str} r
            CROSS JOIN LATERAL unnest(r.models_affected) AS model_name
            WHERE r.environment = $1
                AND r.success = true
                AND r.models_affected IS NOT NULL
            GROUP BY model_name
        """;rows=await self._conn.fetch_rows(sql,environment);return{row['model_name']:row['ts']for row in rows}
	async def successful_run_completed_since_tx(self,txn:_ConnContext,*,environment:str,model_names:t.List[str],since_ts:int)->bool:
		if not model_names:return _G
		for model_name in sorted(set(model_names)):await txn.fetchval('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))',fingerprint_model_lock_key(environment,model_name))
		if not self._runs_models_index_verified:
			index_exists=await txn.fetchval("\n                SELECT EXISTS (\n                    SELECT 1 FROM pg_indexes\n                    WHERE schemaname = $1 AND indexname = 'idx_runs_models_gin'\n                )\n                ",self._schema)
			if not index_exists:raise RuntimeError('Required index idx_runs_models_gin is missing')
			self._runs_models_index_verified=_D
		runs_table=_table_sql(ACTIVITY_RUNS.name,self._schema);sql=f"""
            SELECT EXISTS (
                SELECT 1
                FROM {runs_table}
                WHERE environment = $1
                    AND success = true
                    AND models_affected && $2
                    AND end_ts > $3
                LIMIT 1
            )
        """;return bool(await txn.fetchval(sql,environment,model_names,since_ts))
	async def get_latest_run_for_environment(self,environment:str)->t.Optional[t.Tuple[bool,t.Optional[int]]]:
		binder=ParamBinder();query=exp.select(exp.column(_F),exp.column(_I)).from_(self._runs_table).where(_col_eq_param(_E,environment,binder)).order_by(exp.Ordered(this=exp.column(_B),desc=_D)).limit(1);row=await self._conn.fetch_row(_pg(query),*binder.values)
		if row is _A:return
		success_raw=row.get(_F)
		if success_raw is _A:return
		end_ts_raw=row.get(_I);return bool(success_raw),end_ts_raw