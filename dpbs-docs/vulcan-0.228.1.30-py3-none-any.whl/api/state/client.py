from __future__ import annotations
import asyncpg
from api.state.activity import AsyncActivityState
from api.state.connection import StateConnection
from api.state.dq import AsyncQualityState
from api.state.follower import AsyncFollowerState
from api.state.notification import AsyncNotificationState
from api.state.query import AsyncQueryState
class AsyncStateClient:
	def __init__(self,pool:asyncpg.Pool,schema:str)->None:self.conn=StateConnection(pool,schema);self.activity=AsyncActivityState(self.conn);self.query=AsyncQueryState(self.conn,activity=self.activity);self.notification=AsyncNotificationState(self.conn);self.follower=AsyncFollowerState(self.conn);self.dq=AsyncQualityState(self.conn)