from __future__ import annotations
_G='segment'
_F='measure'
_E='dimension'
_D='column'
_C=False
_B=True
_A=None
import logging,re,typing as t
from collections import deque
from pydantic import ConfigDict,Field,computed_field
from vulcan.core.model.definition import SemanticModel
from vulcan.core.snapshot import Snapshot,SnapshotTableInfo
from vulcan.utils.pydantic import PydanticModel,model_validator
if t.TYPE_CHECKING:from vulcan.core.context_diff import ContextDiff
logger=logging.getLogger(__name__)
class DagEdge(PydanticModel,frozen=_B):model:str;parent:str
class DagDiff(PydanticModel,frozen=_B):
	added:t.List[DagEdge]=Field(default_factory=list);removed:t.List[DagEdge]=Field(default_factory=list)
	@property
	def has_changes(self)->bool:return bool(self.added or self.removed)
class JoinEdge(PydanticModel,frozen=_B):source:str;target:str;join_type:str;predicate:t.Optional[str]=_A
class JoinChange(PydanticModel,frozen=_B):old:JoinEdge;new:JoinEdge
class JoinDiff(PydanticModel,frozen=_B):
	added:t.List[JoinEdge]=Field(default_factory=list);removed:t.List[JoinEdge]=Field(default_factory=list);changed:t.List[JoinChange]=Field(default_factory=list)
	@property
	def has_changes(self)->bool:return bool(self.added or self.removed or self.changed)
class ColumnMember(PydanticModel,frozen=_B):model:str;name:str;kind:str;expression:t.Optional[str]=_A
class ColumnChange(PydanticModel):
	model_config=ConfigDict(extra='ignore',frozen=_B);old:t.Optional[ColumnMember]=_A;new:t.Optional[ColumnMember]=_A;downstream:t.List[ColumnMember]=Field(default_factory=list)
	@model_validator(mode='after')
	def _require_old_or_new(self)->ColumnChange:
		if self.old is _A and self.new is _A:raise ValueError('ColumnChange requires an old or new member')
		return self
	@computed_field
	@property
	def member(self)->ColumnMember:
		if self.new is not _A:return self.new
		assert self.old is not _A;return self.old
class ColumnDiff(PydanticModel,frozen=_B):
	added:t.List[ColumnChange]=Field(default_factory=list);removed:t.List[ColumnChange]=Field(default_factory=list);changed:t.List[ColumnChange]=Field(default_factory=list)
	@property
	def has_changes(self)->bool:return bool(self.added or self.removed or self.changed)
def compute_dag_diff(diff:ContextDiff)->DagDiff:
	added:t.List[DagEdge]=[];removed:t.List[DagEdge]=[]
	for(name,new_snap,old)in _changed_nodes(diff):
		new_parents=_parent_names(new_snap);old_parents=_parent_names(old)
		for parent in sorted(new_parents-old_parents):added.append(DagEdge(model=name,parent=parent))
		for parent in sorted(old_parents-new_parents):removed.append(DagEdge(model=name,parent=parent))
	added.sort(key=lambda e:(e.model,e.parent));removed.sort(key=lambda e:(e.model,e.parent));return DagDiff(added=added,removed=removed)
def compute_join_diff(diff:ContextDiff)->JoinDiff:
	added:t.List[JoinEdge]=[];removed:t.List[JoinEdge]=[];changed:t.List[JoinChange]=[]
	for(_name,new_snap,old)in _changed_nodes(diff):
		new_joins=_joins_by_key(new_snap);old_joins=_joins_by_key(old)
		for key in sorted(set(new_joins)|set(old_joins)):
			new_edge=new_joins.get(key);old_edge=old_joins.get(key)
			if old_edge is _A and new_edge is not _A:added.append(new_edge)
			elif new_edge is _A and old_edge is not _A:removed.append(old_edge)
			elif old_edge is not _A and new_edge is not _A and(old_edge.join_type,old_edge.predicate)!=(new_edge.join_type,new_edge.predicate):changed.append(JoinChange(old=old_edge,new=new_edge))
	added.sort(key=lambda e:(e.source,e.target));removed.sort(key=lambda e:(e.source,e.target));changed.sort(key=lambda c:(c.new.source,c.new.target));return JoinDiff(added=added,removed=removed,changed=changed)
def compute_column_diff(diff:ContextDiff)->ColumnDiff:
	added_members:t.List[ColumnMember]=[];removed_members:t.List[ColumnMember]=[];changed_pairs:t.List[t.Tuple[ColumnMember,ColumnMember]]=[]
	for(_name,new_snap,old)in _changed_nodes(diff):
		if new_snap is _A:removed_members.extend(_member_recipes(old).values());continue
		if new_snap.snapshot_id not in diff.added and not diff.directly_modified(_name):continue
		new_members=_member_recipes(new_snap);old_members=_member_recipes(old)
		for key in sorted(set(new_members)|set(old_members)):
			new_member=new_members.get(key);old_member=old_members.get(key)
			if old_member is _A and new_member is not _A:added_members.append(new_member)
			elif new_member is _A and old_member is not _A:removed_members.append(old_member)
			elif old_member is not _A and new_member is not _A and old_member.expression!=new_member.expression:changed_pairs.append((old_member,new_member))
	own_keys={(member.kind,member.model,member.name)for member in(*added_members,*removed_members,*(new_member for(_old,new_member)in changed_pairs))};added=[ColumnChange(new=member,downstream=_downstream_for(diff,member,skip=own_keys))for member in added_members];removed=[ColumnChange(old=member,downstream=_downstream_for(diff,member,skip=own_keys))for member in removed_members];changed=[ColumnChange(old=old_member,new=new_member,downstream=_downstream_for(diff,new_member,skip=own_keys))for(old_member,new_member)in changed_pairs];added.sort(key=lambda c:(c.member.model,c.member.kind,c.member.name));removed.sort(key=lambda c:(c.member.model,c.member.kind,c.member.name));changed.sort(key=lambda c:(c.member.model,c.member.kind,c.member.name));return ColumnDiff(added=added,removed=removed,changed=changed)
def _changed_nodes(diff:ContextDiff)->t.Iterator[t.Tuple[str,t.Optional[Snapshot],t.Optional[t.Union[Snapshot,SnapshotTableInfo]]]]:
	for(name,(current,old_snap))in sorted(diff.modified_snapshots.items()):yield(name,current,old_snap)
	for snapshot_id in sorted(diff.added,key=lambda s:s.name):
		snapshot=diff.snapshots.get(snapshot_id)
		if snapshot is not _A:yield(snapshot.name,snapshot,_A)
	for(snapshot_id,table_info)in sorted(diff.removed_snapshots.items(),key=lambda item:item[1].name):yield(table_info.name,_A,diff.removed_nodes.get(snapshot_id,table_info))
def _parent_names(node:t.Optional[t.Union[Snapshot,SnapshotTableInfo]])->t.Set[str]:
	if node is _A:return set()
	return{parent.name for parent in node.parents}
def _joins_by_key(node:t.Optional[t.Union[Snapshot,SnapshotTableInfo]])->t.Dict[t.Tuple[str,str],JoinEdge]:
	if node is _A or not isinstance(node,Snapshot)or not node.is_model:return{}
	model=node.model
	if not isinstance(model,SemanticModel):return{}
	source=node.name;edges:t.Dict[t.Tuple[str,str],JoinEdge]={}
	for join in model.joins:target=join.fqn or join.name;edges[source,target]=JoinEdge(source=source,target=target,join_type=str(join.type),predicate=join.expression or _A)
	return edges
def _member_recipes(node:t.Optional[t.Union[Snapshot,SnapshotTableInfo]])->t.Dict[t.Tuple[str,str],ColumnMember]:
	if node is _A or not isinstance(node,Snapshot)or not node.is_model:return{}
	model=node.model
	if isinstance(model,SemanticModel):return _semantic_member_recipes(node)
	return _sql_column_recipes(node)
def _sql_column_recipes(node:Snapshot)->t.Dict[t.Tuple[str,str],ColumnMember]:
	from sqlglot import exp;from sqlglot.optimizer import qualify;from vulcan.core.dialect import normalize_mapping_schema;model=node.model
	try:query=model.render_query_or_raise().copy()
	except Exception:logger.debug('Failed to render columns for %s',node.name,exc_info=_B);return{}
	query=qualify.qualify(query,dialect=model.dialect,schema=normalize_mapping_schema(model.mapping_schema,dialect=model.dialect),validate_qualify_columns=_C,infer_schema=_B);recipes:t.Dict[t.Tuple[str,str],ColumnMember]={}
	for item in query.selects:name=item.alias_or_name;expr=item.this if isinstance(item,exp.Alias)else item;recipes[_D,name]=ColumnMember(model=node.name,name=name,kind=_D,expression=_recipe_sql(expr,dialect=model.dialect))
	return recipes
def _semantic_member_recipes(node:Snapshot)->t.Dict[t.Tuple[str,str],ColumnMember]:
	model=node.model
	if not isinstance(model,SemanticModel):return{}
	recipes:t.Dict[t.Tuple[str,str],ColumnMember]={}
	for dimension in model.dimensions:recipes[_E,dimension.name]=ColumnMember(model=node.name,name=dimension.name,kind=_E,expression=_render_member_expression(dimension))
	for measure in model.measures:recipes[_F,measure.name]=ColumnMember(model=node.name,name=measure.name,kind=_F,expression=_render_member_expression(measure))
	for segment in model.segments:recipes[_G,segment.name]=ColumnMember(model=node.name,name=segment.name,kind=_G,expression=_render_member_expression(segment))
	return recipes
def _render_member_expression(member:t.Any)->str:return member.render_exp().sql(pretty=_C,identify=_C)
def _recipe_sql(expr:t.Any,*,dialect:t.Optional[str])->str:
	from sqlglot import exp;node=expr.copy()if hasattr(expr,'copy')else expr
	if isinstance(node,exp.Expression):
		for ident in node.find_all(exp.Identifier):
			name=ident.this or''
			if name.isidentifier():ident.set('quoted',_C)
		return node.sql(dialect=dialect,pretty=_C,identify=_C)
	return str(expr)
_KIND_ORDER={_E:0,_F:1,_G:2,_D:3}
def _downstream_for(diff:ContextDiff,member:ColumnMember,*,skip:t.Set[t.Tuple[str,str,str]])->t.List[ColumnMember]:
	if member.kind!=_D:return[]
	found:t.List[ColumnMember]=[];seen:t.Set[t.Tuple[str,str,str]]=set(skip);seen.add((member.kind,member.model,member.name));frontier:deque[ColumnMember]=deque([member])
	while frontier:
		current=frontier.popleft()
		for reader in _immediate_readers(diff,current):
			key=reader.kind,reader.model,reader.name
			if key in seen:continue
			seen.add(key);found.append(reader)
			if reader.kind==_D:frontier.append(reader)
	found.sort(key=lambda m:(_KIND_ORDER.get(m.kind,9),m.model,m.name));return found
def _immediate_readers(diff:ContextDiff,member:ColumnMember)->t.List[ColumnMember]:
	readers:t.List[ColumnMember]=[];seen:t.Set[t.Tuple[str,str,str]]=set()
	for snapshot in _model_snapshots(diff):
		model=snapshot.model
		if isinstance(model,SemanticModel):
			if not _depends_on_model(model,member.model):continue
			for dimension in model.dimensions:
				if dimension.name.casefold()!=member.name.casefold():continue
				_add_member(readers,seen,ColumnMember(model=snapshot.name,name=dimension.name,kind=_E))
			for measure in model.measures:
				if not _measure_reads_column(model,measure,member):continue
				_add_member(readers,seen,ColumnMember(model=snapshot.name,name=measure.name,kind=_F))
			for segment in model.segments:
				if not _expression_reads_column(model,segment.expression,member,into_condition=_B):continue
				_add_member(readers,seen,ColumnMember(model=snapshot.name,name=segment.name,kind=_G))
			continue
		if not _snapshot_depends_on(snapshot,member.model):continue
		for column in _sql_column_recipes(snapshot).values():
			if column.model==member.model and column.name.casefold()==member.name.casefold():continue
			if not _sql_column_reads(snapshot,column.name,member):continue
			_add_member(readers,seen,ColumnMember(model=column.model,name=column.name,kind=_D))
	return readers
def _add_member(members:t.List[ColumnMember],seen:t.Set[t.Tuple[str,str,str]],member:ColumnMember)->_A:
	key=member.kind,member.model,member.name
	if key in seen:return
	seen.add(key);members.append(member)
def _model_snapshots(diff:ContextDiff)->t.List[Snapshot]:return[snapshot for snapshot in diff.snapshots.values()if snapshot.is_model]
def _snapshot_depends_on(snapshot:Snapshot,model_name:str)->bool:
	if any(_same_model_name(parent.name,model_name)for parent in snapshot.parents):return _B
	model=snapshot.model
	if isinstance(model,SemanticModel):return _depends_on_model(model,model_name)
	return _C
def _sql_column_reads(snapshot:Snapshot,column:str,member:ColumnMember)->bool:
	from sqlglot import exp;from vulcan.core.dialect import normalize_model_name;from vulcan.core.lineage import lineage;model=snapshot.model
	try:root=lineage(column,model,trim_selects=_C)
	except Exception:return _C
	for node in root.walk():
		if node.downstream:continue
		table=node.expression.find(exp.Table)
		if table is _A:continue
		if exp.to_column(node.name).name.casefold()!=member.name.casefold():continue
		name=normalize_model_name(table,default_catalog=model.default_catalog,dialect=model.dialect)
		if _same_model_name(name,member.model):return _B
	return _C
def _depends_on_model(model:SemanticModel,physical_name:str)->bool:return any(_same_model_name(dep,physical_name)for dep in model.depends_on)
def _same_model_name(left:str,right:str)->bool:
	if left==right:return _B
	from vulcan.core.dialect import fqn_to_unquoted;lu,ru=fqn_to_unquoted(left),fqn_to_unquoted(right)
	if lu==ru:return _B
	lu,ru=lu.casefold(),ru.casefold();return lu.endswith('.'+ru)or ru.endswith('.'+lu)
def _measure_reads_column(model:SemanticModel,measure:t.Any,member:ColumnMember)->bool:
	if _expression_reads_column(model,measure.expression,member,into_condition=_C):return _B
	return any(_expression_reads_column(model,filter_sql,member,into_condition=_B)for filter_sql in measure.filters)
def _expression_reads_column(model:SemanticModel,expression:str,member:ColumnMember,*,into_condition:bool)->bool:
	if not expression or not expression.strip():return _C
	from sqlglot import exp;from vulcan.core.dialect import parse_semantic_member_refs
	try:refs=parse_semantic_member_refs(expression,model.dialect,owning_model=model.name,into=exp.Condition if into_condition else _A,context='column downstream')
	except Exception:return bool(re.search(rf"(?<![\w]){re.escape(member.name)}(?![\w])",expression,flags=re.IGNORECASE))
	return any(ref.member.casefold()==member.name.casefold()and(not ref.model or _same_model_name(ref.model,model.name)or _same_model_name(ref.model,member.model))for ref in refs)