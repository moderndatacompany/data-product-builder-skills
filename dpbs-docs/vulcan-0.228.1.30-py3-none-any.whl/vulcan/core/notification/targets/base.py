from __future__ import annotations
_D='generic'
_C=False
_B=True
_A=None
import os,typing as t
from pydantic import Field
from pydantic.functional_validators import BeforeValidator
from vulcan.core.notification.events import ApplyEndPayload,ApplyFailurePayload,ApplyStartPayload,AuditFailurePayload,DqEndPayload,DqStartPayload,MigrationEndPayload,MigrationFailurePayload,MigrationStartPayload,NotificationEvent,NotificationPayload,NotificationStatus,PlanChangePayload,RunEndPayload,RunFailurePayload,RunStartPayload
from vulcan.core.notification.formatting import format_text_message
from vulcan.core.notification.plan_change import consume_plan_change_context
from vulcan.utils.errors import AuditError,rebrand
from vulcan.utils.pydantic import PydanticModel
def _vulcan_version()->str:
	try:from vulcan import __version__;return __version__
	except ImportError:return'0.0.0'
def _apply_str_env_defaults(data:dict[str,t.Any],*field_env_pairs:tuple[str,str])->_A:
	for(field,env_key)in field_env_pairs:
		if not data.get(field)and(v:=os.getenv(env_key,'').strip()):data[field]=v
def _parse_notify_on(value:t.Any)->t.FrozenSet[NotificationEvent]:
	A='notify_on must contain valid notification events'
	if isinstance(value,str):
		if value=='*':return frozenset(NotificationEvent)
		raise ValueError(A)
	if isinstance(value,list):
		if not value:return frozenset()
		return frozenset(event if isinstance(event,NotificationEvent)else NotificationEvent(event)for event in value)
	raise ValueError(A)
NotifyOn=t.Annotated[t.FrozenSet[NotificationEvent],BeforeValidator(_parse_notify_on)]
class BaseNotificationTarget(PydanticModel,frozen=_B):
	type_:str;notify_on:NotifyOn=frozenset();sync:bool=_C
	def send(self,notification_status:NotificationStatus,msg:str,*,event:NotificationEvent,payload:NotificationPayload)->_A:0
	def _send(self,notification_status:NotificationStatus,msg:str,*,event:NotificationEvent,payload:NotificationPayload)->_A:
		user_payload=payload
		if isinstance(payload,(RunFailurePayload,ApplyFailurePayload,MigrationFailurePayload)):user_payload=payload.model_copy(update={'exc':rebrand(payload.exc)})
		self.send(notification_status,rebrand(msg.strip()),event=event,payload=user_payload)
	def notify_apply_start(self,environment:str,plan_id:str,**kwargs:t.Any)->_A:self._send(NotificationStatus.INFO,f"Plan `{plan_id}` apply started for environment `{environment}`.",event=NotificationEvent.APPLY_START,payload=ApplyStartPayload(environment=environment,plan_id=plan_id,extras=kwargs))
	def notify_apply_end(self,environment:str,plan_id:str,**kwargs:t.Any)->_A:self._send(NotificationStatus.SUCCESS,f"Plan `{plan_id}` apply finished for environment `{environment}`.",event=NotificationEvent.APPLY_END,payload=ApplyEndPayload(environment=environment,plan_id=plan_id,extras=kwargs))
	def notify_run_start(self,environment:str,run_id:str,**kwargs:t.Any)->_A:self._send(NotificationStatus.INFO,f"Vulcan run `{run_id}` started for environment `{environment}`.",event=NotificationEvent.RUN_START,payload=RunStartPayload(environment=environment,run_id=run_id,extras=kwargs))
	def notify_run_end(self,environment:str,run_id:str,*,nothing_to_do:bool=_C,interrupted:bool=_C,**kwargs:t.Any)->_A:
		if nothing_to_do:msg=f"Vulcan run `{run_id}` finished for environment `{environment}` (no models ready to run)."
		elif interrupted:msg=f"Vulcan run `{run_id}` interrupted for environment `{environment}`."
		else:msg=f"Vulcan run `{run_id}` finished for environment `{environment}`."
		self._send(NotificationStatus.SUCCESS,msg,event=NotificationEvent.RUN_END,payload=RunEndPayload(environment=environment,run_id=run_id,nothing_to_do=nothing_to_do,interrupted=interrupted,extras=kwargs))
	def notify_run_failure(self,environment:str,run_id:str,exc:str,**kwargs:t.Any)->_A:self._send(NotificationStatus.FAILURE,f"Vulcan run `{run_id}` failed for environment `{environment}`.",event=NotificationEvent.RUN_FAILURE,payload=RunFailurePayload(environment=environment,run_id=run_id,exc=exc,extras=kwargs))
	def notify_migration_start(self,**kwargs:t.Any)->_A:self._send(NotificationStatus.INFO,f"Vulcan migration started (version {_vulcan_version()}).",event=NotificationEvent.MIGRATION_START,payload=MigrationStartPayload(extras=kwargs))
	def notify_migration_end(self,**kwargs:t.Any)->_A:self._send(NotificationStatus.SUCCESS,f"Vulcan migration finished (version {_vulcan_version()}).",event=NotificationEvent.MIGRATION_END,payload=MigrationEndPayload(extras=kwargs))
	def notify_apply_failure(self,environment:str,plan_id:str,exc:str,**kwargs:t.Any)->_A:self._send(NotificationStatus.FAILURE,f"Plan `{plan_id}` in environment `{environment}` apply failed.",event=NotificationEvent.APPLY_FAILURE,payload=ApplyFailurePayload(environment=environment,plan_id=plan_id,exc=exc,extras=kwargs))
	def notify_audit_failure(self,audit_error:AuditError,*,run_id:t.Optional[str]=_A,plan_id:t.Optional[str]=_A,environment:t.Optional[str]=_A,**kwargs:t.Any)->_A:
		model_name=audit_error.model_name or'unknown';row_label='row'if audit_error.count==1 else'rows';msg=f"Audit `{audit_error.audit_name}` failed on model `{model_name}` ({audit_error.count} {row_label})"
		if environment:msg+=f" in environment `{environment}`"
		if run_id:msg+=f" (run `{run_id}`)"
		elif plan_id:msg+=f" (plan `{plan_id}`)"
		msg+='.';self._send(NotificationStatus.FAILURE,msg,event=NotificationEvent.AUDIT_FAILURE,payload=AuditFailurePayload(audit_name=audit_error.audit_name,model_name=audit_error.model_name,count=audit_error.count,audit_sql=audit_error.sql(pretty=_B),run_id=run_id,plan_id=plan_id,environment=environment,extras=kwargs))
	def notify_migration_failure(self,exc:str,**kwargs:t.Any)->_A:self._send(NotificationStatus.FAILURE,f"Vulcan migration failed (version {_vulcan_version()}).",event=NotificationEvent.MIGRATION_FAILURE,payload=MigrationFailurePayload(exc=exc,extras=kwargs))
	def notify_plan_change(self,environment:str,plan_id:str,added:int,modified:int,removed:int,directly_modified:t.List[str],downstream_affected:int,has_breaking_changes:bool,requires_backfill:bool,*,applied_by:t.Optional[str]=_A,project:t.Optional[str]=_A,plan_type:t.Optional[str]=_A,models_processed:t.Optional[int]=_A,affected_models:t.Optional[int]=_A,snapshots_created:t.Optional[int]=_A,backfilled_intervals:t.Optional[int]=_A,git_commit_sha:t.Optional[str]=_A,end_ts:t.Optional[int]=_A,**kwargs:t.Any)->_A:
		enriched=consume_plan_change_context(plan_id);applied_by=applied_by or enriched.get('applied_by');project=project or enriched.get('project');plan_type=plan_type or enriched.get('plan_type')
		if models_processed is _A:models_processed=enriched.get('models_processed')
		if affected_models is _A:affected_models=enriched.get('affected_models')
		if snapshots_created is _A:snapshots_created=enriched.get('snapshots_created')
		if backfilled_intervals is _A:backfilled_intervals=enriched.get('backfilled_intervals')
		git_commit_sha=git_commit_sha or enriched.get('git_commit_sha')
		if end_ts is _A:end_ts=enriched.get('end_ts')
		msg=f"Plan change applied to `{environment}`"
		if has_breaking_changes:msg+='\n\n[WARNING] Breaking changes detected'
		if requires_backfill:msg+='\n[INFO] Backfills required'
		self._send(NotificationStatus.SUCCESS,msg,event=NotificationEvent.PLAN_CHANGE,payload=PlanChangePayload(environment=environment,plan_id=plan_id,added=added,modified=modified,removed=removed,directly_modified=directly_modified,downstream_affected=downstream_affected,has_breaking_changes=has_breaking_changes,requires_backfill=requires_backfill,applied_by=applied_by,project=project,plan_type=plan_type,models_processed=models_processed,affected_models=affected_models,snapshots_created=snapshots_created,backfilled_intervals=backfilled_intervals,git_commit_sha=git_commit_sha,end_ts=end_ts,extras=kwargs))
	def _format_check_issues(self,title:str,issues_by_dimension:t.Dict[str,t.List[str]],indent:str='  ')->t.List[str]:
		if not issues_by_dimension:return[]
		lines=['',title]
		for dimension in sorted(issues_by_dimension.keys()):
			models=issues_by_dimension[dimension];lines.append(f"{indent}- {dimension}")
			for model in sorted(models):lines.append(f"{indent}{indent}→ {model}")
		return lines
	def notify_dq_start(self,run_id:str,environment:str,model_count:int,**kwargs:t.Any)->_A:self._send(NotificationStatus.INFO,f"Data quality scan started for run `{run_id}` in environment `{environment}` ({model_count} models).",event=NotificationEvent.DQ_START,payload=DqStartPayload(run_id=run_id,environment=environment,model_count=model_count,extras=kwargs))
	def notify_dq_end(self,run_id:str,environment:str,total_checks:int,passed:int,failed:int,warned:int,not_evaluated:int,model_count:int,pass_rate:float,failures_by_dimension:t.Dict[str,t.List[str]],warnings_by_dimension:t.Dict[str,t.List[str]],**kwargs:t.Any)->_A:
		title='Data Quality Failures'if failed>0 else'Data Quality Scan Complete';lines=[f"\n\n{title}",f"Run: {run_id} | Environment: {environment}",'',f"Summary: {total_checks} checks executed",f"  - Passed: {passed}"]
		if failed>0:lines.append(f"  - Failed: {failed}")
		if warned>0:lines.append(f"  - Warned: {warned}")
		if not_evaluated>0:lines.append(f"  - Not evaluated: {not_evaluated}")
		lines.extend(['',f"Models checked: {model_count}",f"Score: {pass_rate:.2f}%"]);lines.extend(self._format_check_issues('Failures:',failures_by_dimension));lines.extend(self._format_check_issues('Warnings:',warnings_by_dimension))
		if failed>0:status=NotificationStatus.FAILURE
		elif warned>0:status=NotificationStatus.WARNING
		else:status=NotificationStatus.SUCCESS
		self._send(status,'\n'.join(lines),event=NotificationEvent.DQ_END,payload=DqEndPayload(run_id=run_id,environment=environment,total_checks=total_checks,passed=passed,failed=failed,warned=warned,not_evaluated=not_evaluated,model_count=model_count,pass_rate=pass_rate,failures_by_dimension=failures_by_dimension,warnings_by_dimension=warnings_by_dimension,extras=kwargs))
	@property
	def is_configured(self)->bool:return _B
class BaseTextBasedNotificationTarget(BaseNotificationTarget,frozen=_B):
	def send_text_message(self,notification_status:NotificationStatus,msg:str)->_A:0
	def send(self,notification_status:NotificationStatus,msg:str,*,event:NotificationEvent,payload:NotificationPayload)->_A:self.send_text_message(notification_status,format_text_message(msg,payload))
class GenericNotificationTarget(BaseNotificationTarget,frozen=_B):type_:t.Literal[_D]=Field(alias='type',default=_D)