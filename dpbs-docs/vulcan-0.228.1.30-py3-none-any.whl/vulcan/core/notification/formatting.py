from __future__ import annotations
_A='unknown'
import typing as t
from datetime import datetime,timezone
from vulcan.core.notification.events import ApplyEndPayload,ApplyFailurePayload,ApplyStartPayload,AuditFailurePayload,DqEndPayload,DqStartPayload,MigrationFailurePayload,PlanChangePayload,RunEndPayload,RunFailurePayload,RunStartPayload,NotificationPayload
ContextFact=tuple[str,str]
def format_timestamp_ms(timestamp_ms:int)->str:return datetime.fromtimestamp(timestamp_ms/1000,tz=timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')
def audit_failure_summary(payload:AuditFailurePayload)->str:model_name=payload.model_name or _A;row_label='row'if payload.count==1 else'rows';return f"'{payload.audit_name}' audit error: {payload.count} {row_label} failed on model '{model_name}'"
def context_facts(payload:NotificationPayload)->t.List[ContextFact]:
	F='Yes';E='Status';D='Plan ID';C='Run ID';B=None;A='Environment';facts:t.List[ContextFact]=[]
	if isinstance(payload,(ApplyStartPayload,ApplyEndPayload,ApplyFailurePayload)):facts.extend([(A,payload.environment),(D,payload.plan_id)])
	elif isinstance(payload,(RunStartPayload,RunEndPayload,RunFailurePayload)):
		facts.extend([(A,payload.environment),(C,payload.run_id)])
		if isinstance(payload,RunEndPayload):
			if payload.nothing_to_do:facts.append((E,'No models ready to run'))
			elif payload.interrupted:facts.append((E,'Interrupted'))
	elif isinstance(payload,AuditFailurePayload):
		if payload.environment:facts.append((A,payload.environment))
		if payload.run_id:facts.append((C,payload.run_id))
		if payload.plan_id:facts.append((D,payload.plan_id))
		facts.extend([('Audit',payload.audit_name),('Model',payload.model_name or _A),('Failed rows',str(payload.count))])
	elif isinstance(payload,PlanChangePayload):
		if payload.end_ts is not B:facts.append(('Applied at',format_timestamp_ms(payload.end_ts)))
		facts.append(('Summary',f"Added {payload.added} | Modified {payload.modified} | Removed {payload.removed} | Downstream {payload.downstream_affected}"))
		if payload.applied_by:facts.append(('Applied by',payload.applied_by))
		if payload.project:facts.append(('Project',payload.project))
		if payload.plan_type:facts.append(('Plan type',payload.plan_type))
		if payload.models_processed is not B:facts.append(('Models processed',str(payload.models_processed)))
		if payload.affected_models is not B:facts.append(('Affected models',str(payload.affected_models)))
		if payload.snapshots_created is not B:facts.append(('Snapshots created',str(payload.snapshots_created)))
		if payload.backfilled_intervals is not B:facts.append(('Backfilled intervals',str(payload.backfilled_intervals)))
		if payload.git_commit_sha:facts.append(('Commit',payload.git_commit_sha[:8]))
		facts.extend([(A,payload.environment),(D,payload.plan_id)])
		if payload.has_breaking_changes:facts.append(('Breaking changes',F))
		if payload.requires_backfill:facts.append(('Backfill required',F))
	elif isinstance(payload,DqStartPayload):facts.extend([(A,payload.environment),(C,payload.run_id),('Models',str(payload.model_count))])
	elif isinstance(payload,DqEndPayload):
		facts.extend([(A,payload.environment),(C,payload.run_id),('Checks',str(payload.total_checks)),('Passed',str(payload.passed)),('Failed',str(payload.failed)),('Score',f"{payload.pass_rate:.2f}%")])
		if payload.warned:facts.append(('Warned',str(payload.warned)))
		if payload.not_evaluated:facts.append(('Not evaluated',str(payload.not_evaluated)))
	return facts
def format_text_message(msg:str,payload:NotificationPayload)->str:
	if isinstance(payload,(RunFailurePayload,ApplyFailurePayload,MigrationFailurePayload)):return f"{msg}\n{payload.exc}"
	if isinstance(payload,AuditFailurePayload):
		lines=[msg,audit_failure_summary(payload)]
		if payload.audit_sql:lines.append(f"\nAudit SQL:\n{payload.audit_sql}")
		return'\n'.join(lines)
	if isinstance(payload,PlanChangePayload):
		lines=[msg]
		for(title,value)in context_facts(payload):lines.append(f"{title}: {value}")
		return'\n'.join(lines)
	return msg