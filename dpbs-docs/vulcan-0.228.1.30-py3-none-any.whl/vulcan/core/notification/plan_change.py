from __future__ import annotations
_A='plan_id'
import typing as t
if t.TYPE_CHECKING:from vulcan.core.activity import PlanActivity;from vulcan.core.plan import Plan
_staged_plan_change:t.Optional[t.Dict[str,t.Any]]=None
def stage_plan_change_context(plan:'Plan',plan_activity:'PlanActivity',*,project:str,models_processed:int=0)->None:
	global _staged_plan_change
	if plan.restatements:plan_type='Restatement'
	elif plan.forward_only:plan_type='Forward-only'
	else:plan_type='Regular'
	_staged_plan_change={_A:plan_activity.plan_id,'applied_by':plan_activity.executor,'project':project,'plan_type':plan_type,'models_processed':models_processed,'affected_models':len(plan_activity.changes.direct)+len(plan_activity.changes.indirect)+len(plan_activity.changes.added)+len(plan_activity.changes.removed)+len(plan_activity.changes.metadata),'snapshots_created':len(plan.new_snapshots),'backfilled_intervals':sum(len(backfill.merged_intervals)for backfill in plan_activity.backfills),'git_commit_sha':plan_activity.git_commit_sha,'end_ts':plan_activity.end_ts}
def consume_plan_change_context(plan_id:str)->t.Dict[str,t.Any]:
	global _staged_plan_change
	if not _staged_plan_change or _staged_plan_change.get(_A)!=plan_id:return{}
	return{k:v for(k,v)in _staged_plan_change.items()if k!=_A}