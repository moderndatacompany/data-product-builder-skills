from __future__ import annotations
_B=True
_A=None
from dataclasses import dataclass
from enum import Enum
import typing as t
from pydantic import ConfigDict,Field,TypeAdapter,ValidationError,field_validator
from schema.types import DQDimension
from vulcan.utils.pydantic import PydanticModel
class CheckOutcome(str,Enum):PASS='pass';WARN='warn';FAIL='fail';ERROR='error';NOT_EVALUATED='not_evaluated'
_DQ_DIMENSION_ADAPTER:TypeAdapter[DQDimension]=TypeAdapter(DQDimension)
def validate_dq_dimension(value:t.Any)->DQDimension:
	if value is _A:raise ValueError('dimension is required')
	if not isinstance(value,str):raise ValueError(f"invalid dq dimension {value!r}")
	normalized=value.lower().strip()
	if not normalized:raise ValueError('dimension cannot be empty')
	try:return _DQ_DIMENSION_ADAPTER.validate_python(normalized)
	except ValidationError as e:raise ValueError(f"invalid dq dimension {value!r}")from e
@dataclass(frozen=_B)
class DqCheckWrite:check_identity:str;check_name:str;check_type:str;model_name:str;dimension:str;outcome:str;definition:t.Optional[str]=_A;column_name:t.Optional[str]=_A;filter:t.Optional[str]=_A;diagnostics:t.Optional[t.Dict[str,t.Any]]=_A;outcome_reasons:t.Optional[t.List[t.Dict[str,str]]]=_A;metric_identities:t.Tuple[str,...]=()
@dataclass(frozen=_B)
class DqMetricWrite:metric_identity:str;metric_name:str;model_name:str;value:t.Any;column_name:t.Optional[str]=_A;measured_at:t.Optional[int]=_A
@dataclass(frozen=_B)
class DqProfileTableWrite:model_name:str;row_count:t.Optional[int]=_A;column_profiles:t.Tuple[t.Dict[str,t.Any],...]=()
@dataclass(frozen=_B)
class DqQueryWrite:sql:str;duration_ms:t.Any;name:t.Optional[str]=_A;exception:t.Optional[str]=_A
@dataclass(frozen=_B)
class DqScanWrite:scan_id:str;start_ts:int;end_ts:int;checks:t.Tuple[DqCheckWrite,...]=();metrics:t.Tuple[DqMetricWrite,...]=();profiles:t.Tuple[DqProfileTableWrite,...]=();queries:t.Tuple[DqQueryWrite,...]=()
class CheckMetadata(PydanticModel):
	model_config=ConfigDict(populate_by_name=_B);check_identity:str=Field(description='Stable check ID');check_name:t.Optional[str]=Field(default=_A,alias='name',serialization_alias='check_name',description='Check display name');check_type:t.Optional[str]=Field(default=_A,alias='type',serialization_alias='check_type',description='Check type (e.g. freshness, uniqueness)');column_name:t.Optional[str]=Field(default=_A,alias='column',serialization_alias='column_name',description='Target column');dimension:DQDimension=Field(description='DQ dimension');definition:t.Optional[str]=Field(default=_A,description='Check definition text');model_name:t.Optional[str]=Field(default=_A,description='Hosting model name')
	@field_validator('dimension',mode='before')
	@classmethod
	def _validate_dimension(cls,value:t.Any)->DQDimension:return validate_dq_dimension(value)
class CheckResult(CheckMetadata):outcome:CheckOutcome=Field(description='Check outcome');outcome_reasons:t.Optional[t.Dict[str,t.Any]]=Field(default=_A,description='Structured reasons for the outcome');diagnostics:t.Dict[str,t.Any]=Field(default_factory=dict,description='GX-native check diagnostics (format gx_v1)')
class CheckResultWithRunId(CheckResult):run_id:str=Field(description='Pipeline run ID');start_ts:int=Field(description='Check execution start (Unix ms)');end_ts:t.Optional[int]=Field(default=_A,description='Check execution end (Unix ms)')
class CheckRuns(CheckMetadata):runs:t.List[CheckResultWithRunId]=Field(default_factory=list,description='Recent check executions')
class QualitySummary(PydanticModel):model_config=ConfigDict(populate_by_name=_B);pass_:int=Field(alias='pass',description='Checks passed');fail:int=Field(description='Checks failed');warn:int=Field(description='Checks warned');error:int=Field(description='Checks errored');not_evaluated:int=Field(description='Checks not evaluated');total:int=Field(description='Total checks');pass_rate:float=Field(description='Pass rate (0–1)')
class ProductQualitySummary(PydanticModel):environment:str=Field(description='Target environment');as_of_ts:t.Optional[int]=Field(default=_A,description='Summary snapshot time (Unix ms)');latest_evaluated_at:int=Field(description='Latest check evaluation (Unix ms)');checks_count:int=Field(description='Total checks in scope');dimensions:t.Dict[DQDimension,QualitySummary]=Field(default_factory=dict,description='Counts by DQ dimension');summary:QualitySummary=Field(description='Overall check counts')