from __future__ import annotations
_J='FAILED'
_I='SUCCESS'
_H='handle_error'
_G='after_cursor_execute'
_F='before_cursor_execute'
_E='parameters'
_D='statement'
_C='Engine'
_B=True
_A=None
import logging,time,typing as t
from vulcan.core.query.fingerprint import json_safe_query_params
from vulcan.utils import CorrelationId,JobType
if t.TYPE_CHECKING:from sqlalchemy.engine import Engine;from vulcan.core.query.history import QueryHistoryComponent,QueryHistoryRecorder
logger=logging.getLogger(__name__)
_PendingExecution=t.Tuple[str,t.Optional[t.Any],float]
class SqlAlchemyQueryHistoryCapture:
	def __init__(self,recorder:'QueryHistoryRecorder',*,correlation_id:CorrelationId,dialect:str,component:'QueryHistoryComponent'='DQ')->_A:self._recorder=recorder;self._correlation_id=correlation_id;self._dialect=dialect;self._component=component;(self._pending):t.Dict[int,_PendingExecution]={};(self._attached_engines):t.List[_C]=[];(self._attached_engine_ids):t.Set[int]=set()
	@property
	def attached_engine_count(self)->int:return len(self._attached_engine_ids)
	def ensure_attached(self,engine:t.Optional[_C])->_A:
		if engine is _A:return
		if id(engine)in self._attached_engine_ids:return
		self.attach(engine)
	def attach(self,engine:_C)->_A:
		from sqlalchemy import event;engine_id=id(engine)
		if engine_id in self._attached_engine_ids:return
		event.listen(engine,_F,self._before_execute,named=_B);event.listen(engine,_G,self._after_execute,named=_B);event.listen(engine,_H,self._on_error);self._attached_engine_ids.add(engine_id);self._attached_engines.append(engine)
	def detach(self,engine:_C)->_A:
		from sqlalchemy import event
		for(handler,evt)in((self._before_execute,_F),(self._after_execute,_G),(self._on_error,_H)):
			try:event.remove(engine,evt,handler)
			except Exception:0
		if engine in self._attached_engines:self._attached_engines.remove(engine)
		self._attached_engine_ids.discard(id(engine))
	def detach_all(self)->_A:
		for engine in list(self._attached_engines):self.detach(engine)
		self._attached_engine_ids.clear()
	def dispose_all(self)->_A:
		for engine in list(self._attached_engines):
			self.detach(engine)
			try:engine.dispose()
			except Exception:logger.warning('Query history capture failed to dispose engine',exc_info=_B)
		self._attached_engine_ids.clear()
	def _before_execute(self,**kw:t.Any)->_A:
		conn=kw.get('conn');statement=kw.get(_D)or'';parameters=kw.get(_E)
		if conn is not _A:self._pending[id(conn)]=statement,parameters,time.monotonic()
	def _after_execute(self,**kw:t.Any)->_A:
		conn=kw.get('conn');statement=kw.get(_D)or''
		try:
			conn_id=id(conn)if conn is not _A else _A;start_info=self._pending.pop(conn_id,_A)if conn_id is not _A else _A
			if start_info:sql,params,started_at=start_info;duration_ms=int((time.monotonic()-started_at)*1000)
			else:sql=statement;params=kw.get(_E);duration_ms=_A
			self._emit(sql=sql,params=params,status=_I,duration_ms=duration_ms)
		except Exception:logger.warning('Query history capture failed after execute',exc_info=_B)
	def _on_error(self,exception_context:t.Any)->_A:
		try:
			conn=getattr(exception_context,'connection',_A);conn_id=id(conn)if conn is not _A else _A;start_info=self._pending.pop(conn_id,_A)if conn_id is not _A else _A
			if start_info:sql,params,started_at=start_info;duration_ms=int((time.monotonic()-started_at)*1000)
			else:sql=getattr(exception_context,_D,_A)or'';params=getattr(exception_context,_E,_A);duration_ms=_A
			orig_exc=getattr(exception_context,'original_exception',_A);error_msg=str(orig_exc)if orig_exc is not _A else _A;self._emit(sql=sql,params=params,status=_J,duration_ms=duration_ms,error_message=error_msg)
		except Exception:logger.warning('Query history capture failed on SQL error',exc_info=_B)
	def _emit(self,*,sql:str,params:t.Optional[t.Any],status:t.Literal[_I,_J],duration_ms:t.Optional[int],error_message:t.Optional[str]=_A)->_A:
		from vulcan.core.query.history import QueryHistoryRecord;correlation=self._correlation_id;run_id:t.Optional[str]=_A;request_id:t.Optional[str]=_A
		if correlation.job_type in(JobType.RUN,JobType.PLAN):run_id=correlation.job_id
		elif correlation.job_type==JobType.QUERY:request_id=correlation.job_id
		stored_params=json_safe_query_params(params)
		try:record=QueryHistoryRecord.from_execution(sql_text=sql,dialect=self._dialect,status=status,job_type=correlation.job_type,executor=correlation.principal,run_id=run_id,request_id=request_id,duration_ms=duration_ms,component=self._component,error_message=error_message,params=stored_params);self._recorder.record(record)
		except Exception:logger.warning('Query history capture failed to emit record',exc_info=_B)