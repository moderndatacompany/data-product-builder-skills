from __future__ import annotations
_B=False
_A=None
import re,typing as t
from sqlglot import exp,parse
from sqlglot.errors import OptimizeError,ParseError,SqlglotError
from sqlglot.optimizer import qualify
from typing_extensions import Self
from schema.metadata import Metadata
from vulcan.core.dialect import find_tables_unquoted,fqn_to_unquoted
from vulcan.core.query.lineage import unknown_table_refs
from vulcan.utils.errors import QueryValidationError
POLICY_CTE_PREFIX='__vulcan_'
_SGR_ESCAPE_RE=re.compile('\\x1b\\[([0-9;]*)m')
_ALLOWED_STATEMENT_TYPES=exp.Select,exp.Union,exp.Intersect,exp.Except,exp.Subquery,exp.Values
_FORBIDDEN_STATEMENT_TYPES=exp.Insert,exp.Update,exp.Delete,exp.Merge,exp.Create,exp.Drop,exp.Alter,exp.TruncateTable,exp.Replace,exp.Command
class QueryValidator:
	def __init__(self,*,metadata:Metadata,dialect:str,default_catalog:str|_A)->_A:self.metadata=metadata;self.dialect=dialect;self.default_catalog=default_catalog;self._available_tables=sorted(metadata.index.queryable_tables.keys())
	def validate(self,sql:str,*,allow_rollups:bool=_B)->_A:
		statements=self._parse_statements(sql)
		if len(statements)!=1:raise QueryValidationError('MULTIPLE_STATEMENTS',f"Only one SQL statement is allowed; found {len(statements)}")
		expression=statements[0];table_refs=self._extract_tables(expression);self._allow_rollups=allow_rollups
		for rule in self._RULES:rule(self,expression,table_refs)
	def _parse_statements(self,sql:str)->list[exp.Expression]:
		A='PARSE_ERROR'
		try:statements=parse(sql,read=self.dialect);return[statement for statement in statements if statement is not _A]
		except SqlglotError as exc:raise QueryValidationError(A,_parse_error_message(exc))from exc
		except Exception as exc:raise QueryValidationError(A,f"Unexpected parse error: {strip_sgr(str(exc))}")from exc
	def _extract_tables(self,expression:exp.Expression)->t.Set[str]:
		try:return find_tables_unquoted(expression,default_catalog=self.default_catalog,dialect=self.dialect)
		except Exception as exc:raise QueryValidationError('TABLE_EXTRACTION_ERROR',f"Failed to extract tables: {exc}")from exc
	def _check_read_only(self,expression:exp.Expression,table_refs:t.Set[str])->_A:
		A='DATA_MANIPULATION_DETECTED';del table_refs
		if not isinstance(expression,_ALLOWED_STATEMENT_TYPES):raise QueryValidationError(A,f"Only SELECT queries are allowed. Found: {type(expression).__name__}")
		for node in expression.walk():
			if isinstance(node,_FORBIDDEN_STATEMENT_TYPES):raise QueryValidationError(A,f"Data manipulation not allowed: {type(node).__name__}")
	def _check_known_tables(self,expression:exp.Expression,table_refs:t.Set[str])->_A:
		del expression
		if not table_refs:return
		allow_rollups=getattr(self,'_allow_rollups',_B);unknown=unknown_table_refs(table_refs,metadata=self.metadata,dialect=self.dialect,allow_rollups=allow_rollups)
		if not unknown:return
		if not allow_rollups:
			rollup_only=sorted(name for name in unknown if fqn_to_unquoted(name,dialect=self.dialect)in self.metadata.index.rollup_tables)
			if rollup_only:raise QueryValidationError('ROLLUP_TABLE_NOT_QUERYABLE',f"rollup tables cannot be queried directly: {rollup_only}")
		missing=', '.join(f"'{name}'"for name in unknown);available=', '.join(f"'{name}'"for name in self._available_tables);raise QueryValidationError('NOT_FOUND',f"{missing} not found.")
	def _check_query_structure(self,expression:exp.Expression,table_refs:t.Set[str])->_A:
		del table_refs
		try:qualify.qualify(expression.copy(),dialect=self.dialect,schema=self.metadata.query_mapping_schema)
		except OptimizeError as exc:raise QueryValidationError('QUERY_STRUCTURE_ERROR',strip_sgr(str(exc)))from exc
	_RULES:tuple[t.Callable[[Self,exp.Expression,t.Set[str]],_A],...]=(_check_read_only,_check_known_tables,_check_query_structure)
def strip_sgr(text:str)->str:return _SGR_ESCAPE_RE.sub('',text)
def parse_sgr_spans(text:str)->list[dict[str,t.Any]]:
	B='underline';A='text';spans:list[dict[str,t.Any]]=[];underline=_B;pos=0
	for match in _SGR_ESCAPE_RE.finditer(text):
		if match.start()>pos:spans.append({A:text[pos:match.start()],B:underline})
		underline=_sgr_codes_set_underline(match.group(1),underline);pos=match.end()
	if pos<len(text):spans.append({A:text[pos:],B:underline})
	if not spans and text:spans.append({A:text,B:_B})
	return spans
def _sgr_codes_set_underline(codes:str,current:bool)->bool:
	if not codes:return _B
	underline=current
	for code in codes.split(';'):
		if code=='0':underline=_B
		elif code=='4':underline=True
	return underline
def _parse_error_message(exc:SqlglotError)->str:
	if isinstance(exc,ParseError)and exc.errors:
		err=exc.errors[0];description=str(err.get('description')or'Failed to parse SQL');line=err.get('line');col=err.get('col');start_context=str(err.get('start_context')or'');highlight=str(err.get('highlight')or'');end_context=str(err.get('end_context')or'');location=''
		if line is not _A and col is not _A:location=f" Line {line}, Col: {col}."
		snippet=''
		if start_context or highlight or end_context:snippet=f"\n  {start_context}{highlight}{end_context}"
		return f"{description}.{location}{snippet}".strip()
	return f"Failed to parse SQL: {strip_sgr(str(exc))}"