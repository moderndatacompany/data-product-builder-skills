from __future__ import annotations
_B=True
_A=None
import json,re,typing as t
from datetime import date,datetime
from decimal import Decimal
from hashlib import sha256
from sqlglot import parse_one
from sqlglot.errors import SqlglotError
from vulcan.utils.errors import QueryValidationError
from vulcan.utils.text import collapse_whitespace
def _strip_leading_block_comments(sql:str)->str:
	stripped=sql
	while _B:
		match=re.match('\\s*/\\*.*?\\*/',stripped,flags=re.DOTALL)
		if not match:break
		stripped=stripped[match.end():]
	return stripped
def _is_comment_on_statement(sql:str)->bool:return _strip_leading_block_comments(sql).lstrip().upper().startswith('COMMENT ON')
def _normalize_comment_on_sql(sql:str)->str:
	collapsed=collapse_whitespace(sql).rstrip(';').strip();separator=re.search('\\s+IS\\s+',collapsed,flags=re.IGNORECASE)
	if separator is _A:return collapsed.upper()
	head=collapsed[:separator.start()];tail=collapsed[separator.end():];return f"{head.upper()} IS {tail}"
def _normalize_sql(sql:str,*,dialect:str)->str:
	A='PARSE_ERROR'
	try:expression=parse_one(sql,read=dialect)
	except SqlglotError as exc:raise QueryValidationError(A,f"Failed to parse SQL: {exc}")from exc
	except Exception as exc:raise QueryValidationError(A,f"Unexpected parse error: {exc}")from exc
	try:return expression.sql(dialect=dialect,pretty=_B,comments=False,normalize=_B,normalize_functions='upper')
	except Exception as exc:raise QueryValidationError('NORMALIZATION_ERROR',f"Failed to normalize SQL: {exc}")from exc
def _normalize_params(params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]])->str:
	if params is _A:return''
	return json.dumps(params,sort_keys=_B,separators=(',',':'),default=_default_json_serializer,ensure_ascii=_B)
def json_safe_query_params(params:t.Optional[t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]]])->t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]:
	if params is _A:return
	if isinstance(params,dict):
		if not params:return
		payload:t.Union[t.Dict[str,t.Any],t.List[t.Any]]=params
	elif isinstance(params,(list,tuple)):
		if not params:return
		payload=list(params)
	else:return
	return json.loads(json.dumps(payload,default=_default_json_serializer))
def sql_fingerprint(*,sql:str,dialect:str,gateway:t.Optional[str]=_A,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=_A)->tuple[str,str]:
	if _is_comment_on_statement(sql):normalized_sql=_normalize_comment_on_sql(sql)
	else:normalized_sql=_normalize_sql(sql,dialect=dialect)
	parts=[gateway,normalized_sql,_normalize_params(params)]if gateway is not _A else[normalized_sql];fingerprint=sha256(':'.join(parts).encode('utf-8')).hexdigest();return fingerprint,normalized_sql
def _default_json_serializer(obj:t.Any)->str:
	if isinstance(obj,(datetime,date)):return obj.isoformat()
	if isinstance(obj,Decimal):return str(obj)
	if isinstance(obj,bytes):return obj.hex()
	return str(obj)