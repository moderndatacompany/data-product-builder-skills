_I='storage_account'
_H='pyarrow'
_G='azure'
_F='gcs'
_E='minio'
_D='endpoint_url'
_C='s3'
_B=None
_A=False
import io,logging,time,typing as t,pandas as pd
from fsspec.spec import AbstractFileSystem
from vulcan.core.config.object_store import ObjectStoreConfig
from vulcan.utils.errors import ObjectStoreError
from vulcan.utils import random_id
if t.TYPE_CHECKING:import adlfs,gcsfs,s3fs
logger=logging.getLogger(__name__)
class ObjectStoreClient:
	def __init__(self,config:ObjectStoreConfig,*,tenant:str,project:str)->_B:
		self.config=config;tenant=tenant.strip()if isinstance(tenant,str)else'';project=project.strip()if isinstance(project,str)else''
		if not tenant or not project:raise ValueError('ObjectStoreClient requires non-empty `tenant` and `project` to build result paths. These should come from config.yaml (tenant/name).')
		self.tenant=tenant;self.project=project;base=self.config.base_path.rstrip('/');self._base_path=f"{base}/{self.tenant}/{self.project}";(self._fs):t.Optional[AbstractFileSystem]=_B
	@property
	def fs(self)->AbstractFileSystem:
		if self._fs is _B:self._fs=self._get_filesystem()
		return self._fs
	def validate_connection(self)->_B:
		test_key=f".healthcheck/test_{random_id()}_{int(time.time()*1000)}.txt";test_data=b'Object store validation test';full_path=f"{self.config.bucket}/{test_key}"
		try:
			with self.fs.open(full_path,'wb')as f:f.write(test_data)
			with self.fs.open(full_path,'rb')as f:read_data=f.read()
			if read_data!=test_data:raise ObjectStoreError('Data integrity check failed')
			self.fs.delete(full_path)
		except ObjectStoreError:raise
		except FileNotFoundError as e:raise ObjectStoreError(f"Bucket '{self.config.bucket}' not found: {e}")
		except PermissionError as e:raise ObjectStoreError(f"Permission denied for bucket '{self.config.bucket}': {e}")
		except Exception as e:hints={_C:'Check AWS credentials and bucket name',_E:'Check endpoint URL, credentials, and bucket name',_F:'Check GCS credentials and bucket name',_G:'Check Azure credentials and container name'};provider=self.config.provider;hint=hints.get(provider,'Check credentials and bucket name');raise ObjectStoreError(f"Validation failed ({provider}, {self.config.bucket}): {e}\nHint: {hint}")
	def upload_result(self,df:pd.DataFrame,result_id:str)->int:
		relative_path=self._result_id_to_path(result_id);full_path=f"{self.config.bucket}/{relative_path}"
		try:
			buffer=io.BytesIO();df.to_parquet(buffer,compression=self.config.compression,engine=_H,index=_A);buffer.seek(0);parquet_bytes=buffer.read();size_bytes=len(parquet_bytes)
			with self.fs.open(full_path,'wb')as f:f.write(parquet_bytes)
			return size_bytes
		except Exception as e:raise ObjectStoreError(f"Failed to upload result: {e}")from e
	def generate_presigned_url(self,result_id:str,expiry_mins:t.Optional[int]=_B)->str:
		relative_path=self._result_id_to_path(result_id);expiry_mins=expiry_mins or self.config.presigned_url_expiry_mins;expiry_seconds=expiry_mins*60;full_path=f"{self.config.bucket}/{relative_path}"
		try:
			if hasattr(self.fs,'url'):url=self.fs.url(full_path,expires=expiry_seconds)
			elif hasattr(self.fs,'signed_url'):url=self.fs.signed_url(full_path,expires=expiry_seconds)
			else:url=self._construct_storage_url(relative_path);logger.warning('Presigned URLs not supported for %s',self.config.provider)
			return url
		except Exception:return self._construct_storage_url(relative_path)
	def get_result(self,result_id:str)->pd.DataFrame:
		relative_path=self._result_id_to_path(result_id);full_path=f"{self.config.bucket}/{relative_path}"
		try:
			with self.fs.open(full_path,'rb')as f:return pd.read_parquet(f,engine=_H)
		except Exception as e:raise ObjectStoreError(f"Failed to download result: {e}")from e
	def delete_result(self,result_id:str)->_B:
		relative_path=self._result_id_to_path(result_id);full_path=f"{self.config.bucket}/{relative_path}"
		try:self.fs.rm(full_path)
		except FileNotFoundError:0
		except Exception as e:raise ObjectStoreError(f"Failed to delete result: {e}")from e
	def _result_id_to_path(self,result_id:str)->str:return f"{self._base_path}/results/{result_id}.parquet"
	def _construct_storage_url(self,relative_path:str)->str:
		bucket=self.config.bucket;provider=self.config.provider
		if provider in(_C,_E):return f"s3://{bucket}/{relative_path}"
		if provider==_F:return f"gs://{bucket}/{relative_path}"
		if provider==_G:
			account=self.config.credentials.get(_I);endpoint_host=self.config.credentials.get(_D)
			if not endpoint_host:endpoint_host='dfs.core.windows.net'
			return f"abfs://{bucket}@{account}.{endpoint_host}/{relative_path}"
		return f"{provider}://{bucket}/{relative_path}"
	def _get_filesystem(self)->AbstractFileSystem:
		provider=self.config.provider
		if provider in(_C,_E):return self._get_s3_filesystem()
		if provider==_F:return self._get_gcs_filesystem()
		if provider==_G:return self._get_azure_filesystem()
		raise ValueError(f"Unsupported provider: {provider}")
	def _get_s3_filesystem(self)->'s3fs.S3FileSystem':
		import s3fs;creds=self.config.credentials;endpoint=creds.get(_D);config_kwargs:t.Dict[str,t.Any]={'signature_version':'s3v4'}
		if self._should_use_virtual_addressing(endpoint):config_kwargs[_C]={'addressing_style':'virtual'}
		fs_kwargs:t.Dict[str,t.Any]={'key':creds.get('access_key_id'),'secret':creds.get('secret_access_key'),'asynchronous':_A,'client_kwargs':{'region_name':creds.get('region','us-east-1')},'config_kwargs':config_kwargs}
		if endpoint:fs_kwargs[_D]=endpoint;fs_kwargs['use_ssl']=str(endpoint).startswith('https://')
		return s3fs.S3FileSystem(**fs_kwargs)
	def _should_use_virtual_addressing(self,endpoint_url:t.Optional[str])->bool:
		if self.config.provider!=_C:return _A
		if not endpoint_url:return True
		from urllib.parse import urlparse;host=(urlparse(str(endpoint_url)).hostname or'').lower();return host=='amazonaws.com'or host.endswith('.amazonaws.com')or host=='amazonaws.com.cn'or host.endswith('.amazonaws.com.cn')
	def _get_gcs_filesystem(self)->'gcsfs.GCSFileSystem':
		import gcsfs;creds=self.config.credentials;project_id=creds.get('project_id');creds_file=creds.get('credentials_file');endpoint_url=creds.get(_D)
		if endpoint_url:endpoint_url=str(endpoint_url)
		if creds_file:return gcsfs.GCSFileSystem(token=creds_file,project=project_id,endpoint_url=endpoint_url,asynchronous=_A)
		return gcsfs.GCSFileSystem(project=project_id,endpoint_url=endpoint_url,asynchronous=_A)
	def _get_azure_filesystem(self)->'adlfs.AzureBlobFileSystem':
		D='client_secret';C='client_id';B='tenant_id';A='connection_string';import adlfs;creds=self.config.credentials
		if A in creds:return adlfs.AzureBlobFileSystem(connection_string=creds[A],asynchronous=_A)
		account_name=creds.get(_I);account_key=creds.get('storage_key');endpoint_suffix=creds.get(_D);account_host=f"{account_name}.{endpoint_suffix}"if account_name and endpoint_suffix else _B
		if account_name and account_key:return adlfs.AzureBlobFileSystem(account_name=account_name,account_key=account_key,account_host=account_host,asynchronous=_A)
		if all(k in creds for k in(B,C,D)):return adlfs.AzureBlobFileSystem(account_name=account_name,tenant_id=creds[B],client_id=creds[C],client_secret=creds[D],account_host=account_host,asynchronous=_A)
		return adlfs.AzureBlobFileSystem(account_name=account_name,account_host=account_host,asynchronous=_A)