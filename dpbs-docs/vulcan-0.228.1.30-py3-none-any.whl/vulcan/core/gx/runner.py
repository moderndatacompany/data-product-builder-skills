from __future__ import annotations
_S='ModelExec'
_R='Validator'
_Q='ExpectationValidationResult'
_P='ExpectationSuiteValidationResult'
_O='ExpectationSuite'
_N='BatchDefinition'
_M='databricks'
_L='vulcan_freshness'
_K='catalog'
_J='Engine'
_I='name'
_H='DataQualitySpec'
_G=False
_F='Context'
_E='EngineAdapter'
_D='EphemeralDataContext'
_C='Model'
_B=True
_A=None
import json,logging,typing as t
from collections import defaultdict
from dataclasses import dataclass,replace
from datetime import date,datetime,timezone
from zoneinfo import ZoneInfo
import great_expectations as gx
from sqlglot import exp
from vulcan.core.dialect import fqn_to_unquoted,parse_one
from vulcan.core.dq_types import CheckOutcome
from vulcan.core.gx.anomaly.constants import ANOMALY_EXPECTATION_TYPE
from vulcan.core.gx.adapter import parse_suite_validation_result
from vulcan.core.gx.historic.execution import is_historic_expectation,run_historic_checks
from vulcan.core.gx.diagnostics import build_referential_unexpected_rows_query,ensure_batch_in_unexpected_rows_query,resolve_reproduce_sql
from vulcan.core.gx.datasource import VulcanSQLDatasource
from vulcan.core.gx.execution_bridge import bind_vulcan_execution_engine
from vulcan.core.gx.change.constants import CHANGE_EXPECTATION_TYPE
from vulcan.core.gx.naming import sanitize_asset_name
from vulcan.core.gx.definitions import CheckExecutionSummary,DataQualitySpec,GxExceptionDetail,GxRunOptions,GxRuleResult,ProfileExecutionSummary
from vulcan.core.gx.metric_planning import freshness_request_from_expectation
from vulcan.core.gx.metric_execution import is_infrastructure_error
from vulcan.core.gx.persistence import persist_gx_scan
from vulcan.core.gx.profiling import profile_model,unprofilable_columns
from vulcan.core.query.sqlalchemy_capture import SqlAlchemyQueryHistoryCapture
from vulcan.utils import CorrelationId
from vulcan.utils.date import TimeLike,now_timestamp
from vulcan.utils.errors import ConfigError
if t.TYPE_CHECKING:from great_expectations.core.batch_definition import BatchDefinition;from great_expectations.core.expectation_suite import ExpectationSuite;from great_expectations.core.expectation_validation_result import ExpectationSuiteValidationResult,ExpectationValidationResult;from great_expectations.data_context.data_context.ephemeral_data_context import EphemeralDataContext;from great_expectations.validator.validator import Validator;from sqlalchemy.engine import Engine;from vulcan.core.activity import ModelExec;from vulcan.core.context import Context;from vulcan.core.engine_adapter.base import EngineAdapter;from vulcan.core.model import Model
logger=logging.getLogger(__name__)
_CATALOG_SCOPED_GX_DIALECTS={_M,'trino'}
_MAX_FRESHNESS_FALLBACK_QUERIES=8
def _to_utc_datetime(value:t.Any,*,naive_timezone:str='UTC')->datetime:
	from vulcan.utils.date import to_datetime
	if isinstance(value,datetime):result=value
	elif isinstance(value,date):result=datetime(value.year,value.month,value.day)
	else:result=to_datetime(value)
	if result.tzinfo is _A or result.utcoffset()is _A:result=result.replace(tzinfo=ZoneInfo(naive_timezone))
	return result.astimezone(timezone.utc)
@dataclass
class _GxGatewaySession:gateway_name:str;datasource_name:str;gx_ctx:_D;qh_hook:t.Optional[SqlAlchemyQueryHistoryCapture];dq_adapter:_E;warehouse_adapter:_E;dialect:str;is_spark:bool=_G;catalog:t.Optional[str]=_A
def _fetch_failed_row_samples(execution_adapter:_E,sql:str,*,max_items:int,dialect:str)->t.Tuple[t.Dict[str,object],...]:
	try:import sqlglot;inner=sqlglot.parse_one(sql,read=dialect);limited=exp.select('*').from_(inner.subquery('_vulcan_failed')).limit(max_items).sql(dialect=dialect);rows=execution_adapter.fetchdf(limited).to_dict('records');return tuple(dict(row)for row in rows)
	except Exception as exc:logger.warning('[gx] Could not fetch failed-row samples: %s',exc);return()
def _fail_has_row_level_evidence(result:GxRuleResult)->bool:
	if result.reproduce_query:return _B
	total=result.total_failing_rows
	if total is not _A and total>0:return _B
	observed=result.observed_value
	if isinstance(observed,(int,float))and not isinstance(observed,bool):return observed>0
	return _G
def _enrich_fail_diagnostics(model:_C,spec:_H,rule_results:t.Dict[str,GxRuleResult],*,execution_adapter:t.Optional[_E],capture_samples:bool=_B,max_items:int=20,dialect:str='postgres')->t.Dict[str,GxRuleResult]:
	if not capture_samples or execution_adapter is _A:return rule_results
	fqn=model.fqn;updated=dict(rule_results)
	for expectation in spec.expectations:
		check_name=expectation.check_name;result=updated.get(check_name)
		if result is _A or result.outcome!=CheckOutcome.FAIL:continue
		if result.failed_rows_sample:continue
		if not _fail_has_row_level_evidence(result):continue
		reproduce=resolve_reproduce_sql(expectation,result,fqn=fqn,filter_expr=spec.filter,dialect=dialect,include_catalog=execution_adapter.catalog_support.is_full_support)
		if not reproduce:continue
		samples=_fetch_failed_row_samples(execution_adapter,reproduce,max_items=max_items,dialect=dialect);total=result.total_failing_rows
		if total is _A and isinstance(result.observed_value,(int,float))and not isinstance(result.observed_value,bool):total=int(result.observed_value)
		updated[check_name]=replace(result,failed_rows_sample=samples,reproduce_query=reproduce,total_failing_rows=total)
	return updated
def _gx_datasource_name(gateway_name:str,*,catalog:t.Optional[str]=_A)->str:
	if catalog:return sanitize_asset_name(f"vulcan_{gateway_name}_{catalog}")
	return f"vulcan_{gateway_name}"
def _resolve_model_gateway(model:_C,context:_F)->str:
	if model.gateway:return model.gateway
	return context.gateway or context.config.default_gateway_name
def _gx_session_catalog(model:_C,context:_F,gateway_name:str)->t.Optional[str]:
	connection=context.config.get_connection(gateway_name);connection_type=getattr(connection,'type_',_A)
	if connection_type not in _CATALOG_SCOPED_GX_DIALECTS:return
	table=exp.to_table(model.fqn,dialect=connection_type);catalog=table.catalog or getattr(connection,_K,_A)
	if not catalog:logger.warning('[gx] No catalog configured for %s model %s; using the warehouse default',connection_type,model.fqn)
	return catalog
def _create_gx_gateway_session(context:_F,gateway_name:str,*,correlation_id:CorrelationId,catalog:t.Optional[str]=_A)->_GxGatewaySession:
	conn=context.config.get_connection(gateway_name);dq_adapter=context._get_engine_adapter(gateway_name).with_settings(correlation_id=correlation_id,query_history_recorder=context.query_history_recorder,query_history_component='DQ');warehouse_adapter=context._get_engine_adapter(gateway_name).with_settings(correlation_id=correlation_id,query_history_recorder=context.query_history_recorder,query_history_component='PROFILE');dialect=dq_adapter.dialect;is_spark=dialect=='spark';datasource_catalog=catalog if dialect in _CATALOG_SCOPED_GX_DIALECTS else _A;datasource_name=_gx_datasource_name(gateway_name,catalog=datasource_catalog);gx_ctx=gx.get_context(mode='ephemeral')
	if is_spark:gx_ctx.data_sources.add_spark(name=datasource_name,force_reuse_spark_context=_B);return _GxGatewaySession(gateway_name=gateway_name,datasource_name=datasource_name,gx_ctx=gx_ctx,qh_hook=_A,dq_adapter=dq_adapter,warehouse_adapter=warehouse_adapter,dialect=dialect,is_spark=_B)
	if datasource_catalog:conn=conn.model_copy(update={_K:datasource_catalog})
	try:connection_string=conn.gx_connection_string()
	except NotImplementedError as exc:raise ConfigError(str(exc))from exc
	datasource=VulcanSQLDatasource(name=datasource_name,connection_string=connection_string);datasource.bind_vulcan_adapter(dq_adapter,catalog=datasource_catalog);gx_ctx.data_sources.add_sql(datasource);qh_hook=SqlAlchemyQueryHistoryCapture(context.query_history_recorder,correlation_id=correlation_id,dialect=dialect,component='DQ');_ensure_gx_query_history_hooks(gx_ctx,qh_hook,datasource_name=datasource_name);return _GxGatewaySession(gateway_name=gateway_name,datasource_name=datasource_name,gx_ctx=gx_ctx,qh_hook=qh_hook,dq_adapter=dq_adapter,warehouse_adapter=warehouse_adapter,dialect=dialect,catalog=datasource_catalog)
def _gx_table_asset_kwargs(fqn:str,*,dialect:str)->t.Dict[str,str]:
	table=exp.to_table(fqn,dialect=dialect);kwargs:t.Dict[str,str]={'table_name':table.name}
	if table.db:kwargs['schema_name']=table.db
	return kwargs
def _build_filter_query(fqn:str,filter_expr:str,*,dialect:str,datasource_scoped_catalog:bool=_G,columns:t.Optional[t.Iterable[str]]=_A)->str:
	table=exp.to_table(fqn,dialect=dialect)
	if datasource_scoped_catalog:table.set(_K,_A)
	projections=[exp.to_identifier(column,quoted=_B)for column in columns]if columns is not _A else[exp.Star()]
	if not projections:raise ConfigError(f"Cannot build filtered GX query for {fqn}: no columns found")
	return exp.select(*projections).from_(table).where(parse_one(filter_expr,dialect=dialect)).sql(dialect=dialect)
def _run_validator(gx_ctx:_D,batch_def:_N,suite:_O,qh_hook:t.Optional[SqlAlchemyQueryHistoryCapture]=_A,*,datasource_name:str,execution_adapter:t.Optional[_E]=_A,table_fqn:t.Optional[str]=_A,batch_parameters:t.Optional[t.Dict[str,t.Any]]=_A)->t.Tuple[t.Union[_P,_Q],_R]:
	_ensure_gx_query_history_hooks(gx_ctx,qh_hook,datasource_name=datasource_name)
	if execution_adapter is _A:batch=batch_def.get_batch(batch_parameters=batch_parameters)if batch_parameters is not _A else batch_def.get_batch();validator=gx_ctx.get_validator(batch=batch,expectation_suite=suite);_ensure_gx_query_history_hooks(gx_ctx,qh_hook,datasource_name=datasource_name,validator=validator);return validator.validate(expectation_suite=suite),validator
	datasource=gx_ctx.data_sources.get(datasource_name);execution_engine=datasource.get_execution_engine()
	with bind_vulcan_execution_engine(execution_engine,execution_adapter,table_fqn=table_fqn):
		batch=batch_def.get_batch(batch_parameters=batch_parameters)if batch_parameters is not _A else batch_def.get_batch();validator=gx_ctx.get_validator(batch=batch,expectation_suite=suite);_ensure_gx_query_history_hooks(gx_ctx,qh_hook,datasource_name=datasource_name,validator=validator)
		with bind_vulcan_execution_engine(validator.execution_engine,execution_adapter,table_fqn=table_fqn):return validator.validate(expectation_suite=suite),validator
def _validate_with_validator(gx_ctx:_D,batch_def:_N,suite:_O,qh_hook:t.Optional[SqlAlchemyQueryHistoryCapture]=_A,*,datasource_name:str,execution_adapter:t.Optional[_E]=_A,table_fqn:t.Optional[str]=_A,batch_parameters:t.Optional[t.Dict[str,t.Any]]=_A)->t.Union[_P,_Q]:result,_=_run_validator(gx_ctx,batch_def,suite,qh_hook=qh_hook,datasource_name=datasource_name,execution_adapter=execution_adapter,table_fqn=table_fqn,batch_parameters=batch_parameters);return result
def _build_expectation(exp_type:str,kwargs:t.Dict[str,t.Any],meta:t.Dict[str,t.Any],check_name:str,run_options:GxRunOptions)->t.Any:
	A='result_format';from great_expectations.expectations.registry import get_expectation_impl
	try:impl=get_expectation_impl(exp_type)
	except Exception as exc:raise ConfigError(f"DQ check {check_name!r}: unknown expectation type {exp_type!r}")from exc
	result_format:t.Dict[str,t.Any]={A:'COMPLETE','partial_unexpected_count':run_options.max_items,'include_unexpected_rows':_B}if run_options.capture_failed_row_samples else{A:'SUMMARY'}
	try:return impl(**kwargs,notes=check_name,meta=meta,result_format=result_format)
	except Exception as exc:raise ConfigError(f"DQ check {check_name!r} ({exp_type}): invalid arguments: {exc}")from exc
def _run_freshness_checks(session:_GxGatewaySession,model:_C,spec:_H,*,scan_time:t.Any,naive_timestamp_timezone:str='UTC')->t.Dict[str,GxRuleResult]:
	A='query';results:t.Dict[str,GxRuleResult]={};freshness=[e for e in spec.expectations if e.expectation==_L]
	if not freshness:return results
	planned_freshness=[]
	for expectation in freshness:
		try:planned_freshness.append((expectation,freshness_request_from_expectation(expectation)))
		except Exception as exc:results[expectation.check_name]=GxRuleResult(check_name=expectation.check_name,outcome=CheckOutcome.ERROR,exception=GxExceptionDetail(message=str(exc)))
	if not planned_freshness:return results
	reference=_to_utc_datetime(scan_time,naive_timezone=naive_timestamp_timezone);table=exp.to_table(model.fqn,dialect=session.dialect)
	if spec.filter:table=exp.select('*').from_(table).where(parse_one(spec.filter,dialect=session.dialect)).subquery('_dq_fresh')
	columns:t.List[str]=[]
	for(_expectation,request)in planned_freshness:
		if request.column not in columns:columns.append(request.column)
	latest_by_column:t.Dict[str,t.Any]={};query_by_column:t.Dict[str,str]={};errors_by_column:t.Dict[str,Exception]={};fallback_budget=[_MAX_FRESHNESS_FALLBACK_QUERIES];infrastructure_failure:t.List[t.Optional[Exception]]=[_A]
	def execute_columns(selected:t.Sequence[str],*,fallback:bool,parent_error:t.Optional[Exception]=_A)->_A:
		if infrastructure_failure[0]is not _A:
			for column in selected:errors_by_column[column]=infrastructure_failure[0]
			return
		aliases={column:f"_freshness_{i}"for(i,column)in enumerate(selected)};sql=exp.select(*[exp.func('MAX',exp.column(column)).as_(aliases[column])for column in selected]).from_(table).sql(dialect=session.dialect)
		if fallback:
			if fallback_budget[0]<=0:
				error=RuntimeError('freshness fallback query limit reached'+(f": {parent_error}"if parent_error else''))
				for column in selected:errors_by_column[column]=error;query_by_column[column]=sql
				return
			fallback_budget[0]-=1
		try:
			row=session.dq_adapter.fetchone(sql)
			if not row:raise ValueError('freshness aggregate query returned no row')
			for(index,column)in enumerate(selected):latest_by_column[column]=row[index]if index<len(row)else _A;query_by_column[column]=sql
		except Exception as exc:
			if is_infrastructure_error(exc):
				infrastructure_failure[0]=exc
				for column in selected:errors_by_column[column]=exc;query_by_column[column]=sql
				return
			if len(selected)==1:
				for column in selected:errors_by_column[column]=exc;query_by_column[column]=sql
				return
			midpoint=len(selected)//2;execute_columns(selected[:midpoint],fallback=_B,parent_error=exc);execute_columns(selected[midpoint:],fallback=_B,parent_error=exc)
	execute_columns(columns,fallback=_G)
	for(expectation,request)in planned_freshness:
		name=request.check_name;column=request.column;sql=query_by_column.get(column,'')
		try:
			if column in errors_by_column:raise errors_by_column[column]
			latest=latest_by_column[column]
			if latest is _A:raise ValueError(f"freshness column {column!r} has no non-null values")
			latest_dt=_to_utc_datetime(latest,naive_timezone=naive_timestamp_timezone);age_seconds=(reference-latest_dt).total_seconds();threshold=request.threshold_seconds;op=request.operator;passed={'<':age_seconds<threshold,'<=':age_seconds<=threshold,'=':age_seconds==threshold,'>':age_seconds>threshold,'>=':age_seconds>=threshold}[op];results[name]=GxRuleResult(check_name=name,outcome=CheckOutcome.PASS if passed else CheckOutcome.FAIL,observed_value=age_seconds,gx_result={'observed_value':age_seconds,'max_timestamp':latest_dt.isoformat(),'threshold_seconds':threshold,'operator':op,A:sql})
		except Exception as exc:results[name]=GxRuleResult(check_name=name,outcome=CheckOutcome.ERROR,exception=GxExceptionDetail(message=str(exc)),gx_result={A:sql})
	return results
def _run_gx_scan_for_model(session:_GxGatewaySession,model:_C,spec:_H,*,run_options:GxRunOptions,scan_time:t.Optional[TimeLike]=_A,quality_state:t.Any=_A,environment:str='prod')->t.Dict[str,GxRuleResult]:
	A='unexpected_rows_query'
	if not spec.expectations:return{}
	gx_ctx=session.gx_ctx;qh_hook=session.qh_hook;datasource_name=session.datasource_name;dialect=session.dialect;asset_name=sanitize_asset_name(model.fqn);suite_name=f"vulcan_gx_{asset_name}";fqn=model.fqn;suite=gx_ctx.suites.add(gx.core.ExpectationSuite(name=suite_name));effective_scan_time=scan_time or now_timestamp();bridge_results:t.Dict[str,GxRuleResult]={};freshness=[expectation for expectation in spec.expectations if expectation.expectation==_L]
	try:bridge_results.update(_run_freshness_checks(session,model,spec,scan_time=effective_scan_time,naive_timestamp_timezone=run_options.naive_timestamp_timezone))
	except Exception as exc:logger.exception('[gx] Freshness bridge failed for %s',model.fqn);bridge_results.update({expectation.check_name:GxRuleResult(check_name=expectation.check_name,outcome=CheckOutcome.ERROR,exception=GxExceptionDetail(message=str(exc)))for expectation in freshness})
	if quality_state is not _A:
		historic=[expectation for expectation in spec.expectations if is_historic_expectation(expectation.expectation)]
		try:bridge_results.update(run_historic_checks(execution_adapter=session.dq_adapter,dialect=session.dialect,model_name=model.fqn,gateway=session.gateway_name,environment=environment,filter_sql=spec.filter,expectations=spec.expectations,scan_time=effective_scan_time,quality_state=quality_state))
		except Exception as exc:logger.exception('[gx] Historic bridge failed for %s',model.fqn);bridge_results.update({expectation.check_name:GxRuleResult(check_name=expectation.check_name,outcome=CheckOutcome.ERROR,exception=GxExceptionDetail(message=str(exc)))for expectation in historic if expectation.check_name not in bridge_results})
	notes_to_siblings:t.Dict[str,t.List[str]]={};seen_exp_keys:t.Dict[t.Tuple[str,str],str]={}
	for e in spec.expectations:
		exp_type,kwargs,meta=e.to_gx_tuple();check_name=meta.get(_I)or exp_type
		if exp_type==_L or is_historic_expectation(exp_type)or exp_type in{ANOMALY_EXPECTATION_TYPE,CHANGE_EXPECTATION_TYPE}:continue
		if exp_type=='unexpected_rows_expectation':
			if e.vulcan_referential is not _A:rewritten_q=build_referential_unexpected_rows_query(e.vulcan_referential,fqn=fqn,dialect=dialect,include_catalog=session.dq_adapter.catalog_support.is_full_support)
			else:q=kwargs.get(A,'');rewritten_q=ensure_batch_in_unexpected_rows_query(q,fqn=fqn,dialect=dialect)
			kwargs={**kwargs,A:rewritten_q}
		dedup_key=exp_type,json.dumps(kwargs,sort_keys=_B,default=str);existing_notes=seen_exp_keys.get(dedup_key)
		if existing_notes is not _A:notes_to_siblings[existing_notes].append(check_name);continue
		try:expectation_impl=_build_expectation(exp_type,kwargs,meta,check_name,run_options)
		except ConfigError as exc:logger.error('[gx] Skipping check %s on %s: %s',check_name,fqn,exc);continue
		seen_exp_keys[dedup_key]=check_name;notes_to_siblings[check_name]=[check_name];suite.add_expectation(expectation_impl)
	if not notes_to_siblings:return bridge_results
	datasource=gx_ctx.data_sources.get(datasource_name);_ensure_gx_query_history_hooks(gx_ctx,qh_hook,datasource_name=datasource_name);table_ref=exp.to_table(fqn,dialect=dialect)
	if session.is_spark:
		spark=session.dq_adapter.spark
		if spark is _A:raise ConfigError("GX Spark DQ requires Vulcan's active SparkSession")
		dataframe=spark.table(fqn_to_unquoted(fqn,dialect=dialect))
		if spec.filter:dataframe=dataframe.where(spec.filter)
		data_asset=datasource.add_dataframe_asset(name=asset_name);batch_def=data_asset.add_batch_definition_whole_dataframe(name='whole_dataframe');validation_result=_validate_with_validator(gx_ctx,batch_def,suite,datasource_name=datasource_name,batch_parameters={'dataframe':dataframe})
	else:
		catalog_scoped_dialect=dialect in _CATALOG_SCOPED_GX_DIALECTS;filtered_catalog_asset=catalog_scoped_dialect and bool(spec.filter)
		try:
			if catalog_scoped_dialect and not spec.filter:data_asset=datasource.add_table_asset(name=asset_name,**_gx_table_asset_kwargs(fqn,dialect=dialect))
			elif filtered_catalog_asset:columns=session.dq_adapter.columns(fqn).keys()if dialect==_M else _A;query=_build_filter_query(fqn,t.cast(str,spec.filter),dialect=dialect,datasource_scoped_catalog=dialect=='trino',columns=columns);data_asset=datasource.add_query_asset(name=asset_name,query=query)
			elif spec.filter or table_ref.catalog:query=_build_filter_query(fqn,spec.filter or'TRUE',dialect=dialect);data_asset=datasource.add_query_asset(name=asset_name,query=query)
			else:data_asset=datasource.add_table_asset(name=asset_name,**_gx_table_asset_kwargs(fqn,dialect=dialect))
			batch_def=data_asset.add_batch_definition_whole_table(name='whole_table');validation_result=_validate_with_validator(gx_ctx,batch_def,suite,qh_hook=qh_hook,datasource_name=datasource_name,execution_adapter=session.dq_adapter,table_fqn=fqn)
		except Exception as exc:
			if not filtered_catalog_asset:raise
			reason=f"GX could not prepare the filtered {dialect} QueryAsset: {exc}";skipped={check_name:GxRuleResult(check_name=check_name,outcome=CheckOutcome.NOT_EVALUATED,exception=GxExceptionDetail(message=reason))for sibling_names in notes_to_siblings.values()for check_name in sibling_names};return{**skipped,**bridge_results}
	max_items=0 if not run_options.capture_failed_row_samples else run_options.max_items;gx_results=parse_suite_validation_result(validation_result,notes_to_siblings=notes_to_siblings,max_items=max_items);return{**gx_results,**bridge_results}
def _warn_unprofiled_columns(model_name:str,requested:t.Set[str],table_columns:t.Dict[str,t.Any],selected:t.Dict[str,t.Any])->_A:
	missing=sorted(requested-set(table_columns));skipped=unprofilable_columns(selected)
	if not missing and not skipped:return
	from vulcan.core.console import get_console;clauses:t.List[str]=[]
	if missing:clauses.append(f"columns missing: {', '.join(missing)}")
	if skipped:detail=', '.join(f"{name} ({sql_type})"for(name,sql_type)in sorted(skipped.items()));clauses.append(f"profiles skipped (only numeric/text): {detail}")
	get_console().log_warning(f"DQ '{model_name}': {'; '.join(clauses)}")
def _build_gx_check_summary(model_name:str,spec:_H,rule_results:t.Dict[str,GxRuleResult])->CheckExecutionSummary:
	G='warned_checks';F='failed_checks';E='warned';D='failed';C='passed';B='not_evaluated_checks';A='not_evaluated';dimensions:t.Dict[str,t.Dict[str,t.Any]]=defaultdict(lambda:{C:0,D:0,E:0,A:0,F:[],G:[],B:[]})
	for e in spec.expectations:
		exp_type,_kwargs,meta=e.to_gx_tuple();dim=str(meta.get('dimension','validity'));check_name=meta.get(_I)or exp_type;result=rule_results.get(check_name)
		if result is _A:dimensions[dim][A]+=1;dimensions[dim][B].append({_I:check_name});continue
		outcome=result.outcome;reason=result.exception.message if result.exception else _A;check_detail:t.Dict[str,t.Any]={_I:check_name,'definition':exp_type,'value':result.observed_value}
		if reason:check_detail['reason']=reason
		if outcome=='pass':dimensions[dim][C]+=1
		elif outcome in('fail','error'):dimensions[dim][D]+=1;dimensions[dim][F].append(check_detail)
		elif outcome=='warn':dimensions[dim][E]+=1;dimensions[dim][G].append(check_detail)
		else:dimensions[dim][A]+=1;dimensions[dim][B].append(check_detail)
	return CheckExecutionSummary(results={model_name:{'filter':spec.filter,'dimensions':dict(dimensions)}})
def _models_by_fqn_from_environment_snapshots(context:_F,environment:str,model_execs:t.Sequence[_S])->t.Dict[str,_C]:
	if not model_execs:return{}
	exec_fqns={me.fqn for me in model_execs};env=context.state_sync.get_environment(environment)
	if not env:logger.debug('[gx] Environment %r not found in state_sync; skipping snapshot model index',environment);return{}
	wanted=[snapshot_id for snapshot_id in env.snapshots if snapshot_id.name in exec_fqns]
	if not wanted:return{}
	by_fqn:t.Dict[str,_C]={}
	for snapshot in context.state_sync.get_snapshots(wanted).values():
		if not snapshot.is_model:continue
		by_fqn[snapshot.name]=snapshot.model
	return by_fqn
def _merge_gx_summaries(summaries:t.List[CheckExecutionSummary])->t.Optional[CheckExecutionSummary]:
	if not summaries:return
	merged:t.Dict[str,t.Any]={}
	for s in summaries:merged.update(s.results)
	return CheckExecutionSummary(results=merged)
def _build_gx_profile_summary(run_id:str,environment:str,profiled_models:t.List[t.Tuple[str,t.List[str]]])->t.Optional[ProfileExecutionSummary]:
	model_profiles={fqn:sorted(cols)for(fqn,cols)in profiled_models if cols}
	if not model_profiles:return
	return ProfileExecutionSummary(run_id=run_id,environment=environment,model_profiles=model_profiles,prefix_stats={})
def _ensure_gx_query_history_hooks(gx_ctx:_D,qh_hook:t.Optional[SqlAlchemyQueryHistoryCapture],*,datasource_name:str,validator:t.Optional[_R]=_A)->_A:
	if qh_hook is _A:return
	try:
		ds=gx_ctx.data_sources.get(datasource_name)
		if ds is _A:return
		try:qh_hook.ensure_attached(ds.get_engine())
		except Exception as exc:logger.debug('[gx] Could not attach datasource engine for query history: %s',exc)
		try:qh_hook.ensure_attached(ds.get_execution_engine().engine)
		except Exception as exc:logger.debug('[gx] Could not attach execution engine for query history: %s',exc)
	except Exception as exc:logger.debug('[gx] Could not resolve GX engines for query history: %s',exc)
	if validator is _A:return
	execution_engine=getattr(validator,'execution_engine',_A);engine=getattr(execution_engine,'engine',_A)
	if engine is not _A:qh_hook.ensure_attached(engine)
def _gx_sqlalchemy_engines(gx_ctx:_D,*,datasource_name:str)->t.List[_J]:
	engines:t.List[_J]=[];seen:t.Set[int]=set()
	try:
		ds=gx_ctx.data_sources.get(datasource_name)
		if ds is _A:return engines
		candidates:t.List[t.Optional[_J]]=[]
		try:candidates.append(ds.get_engine())
		except Exception as exc:logger.debug('[gx] Could not resolve datasource engine: %s',exc)
		try:candidates.append(ds.get_execution_engine().engine)
		except Exception as exc:logger.debug('[gx] Could not resolve execution engine: %s',exc)
		for candidate in candidates:
			if candidate is _A:continue
			key=id(candidate)
			if key in seen:continue
			seen.add(key);engines.append(candidate)
	except Exception as exc:logger.warning('[gx] Could not resolve SQLAlchemy engines from GX context: %s',exc)
	return engines
def _sqlalchemy_engine_from_gx_ctx(gx_ctx:_D,*,datasource_name:str)->t.Optional[_J]:
	engines=_gx_sqlalchemy_engines(gx_ctx,datasource_name=datasource_name)
	if not engines:return
	return engines[-1]
def run_gx_for_successful_models(context:_F,successful_model_execs:t.Sequence[_S],*,run_id:str,job_type:t.Literal['PLAN','RUN'],environment:str,execution_time:t.Optional[TimeLike]=_A,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A)->t.Tuple[t.Optional[CheckExecutionSummary],t.Optional[ProfileExecutionSummary]]:
	check_summaries:t.List[CheckExecutionSummary]=[];profiled_models:t.List[t.Tuple[str,t.List[str]]]=[];models_by_fqn=_models_by_fqn_from_environment_snapshots(context,environment,successful_model_execs)
	if job_type=='PLAN':correlation_id=CorrelationId.from_plan_id(run_id)
	elif job_type=='RUN':correlation_id=CorrelationId.from_run_id(run_id)
	else:raise ValueError(f"Unexpected job_type for GX profiling adapter: {job_type!r}")
	run_options=GxRunOptions.from_config(context.config.dq)
	if not run_options.capture_failed_row_samples:logger.debug('[gx] Failed-row sample capture disabled (dq.capture_failed_row_samples=false)')
	sessions:t.Dict[t.Tuple[str,t.Optional[str]],_GxGatewaySession]={};failed_gateways:t.Set[t.Tuple[str,t.Optional[str]]]=set()
	try:
		for me in successful_model_execs:
			model=models_by_fqn.get(me.fqn)
			if model is _A:logger.debug('[gx] Skipping %s: not in environment snapshots',me.fqn);continue
			spec:t.Optional[DataQualitySpec]=getattr(model,'dq',_A)
			if spec is _A:logger.debug('[gx] Skipping %s: no dq spec',me.fqn);continue
			gateway_name=_resolve_model_gateway(model,context);catalog=_gx_session_catalog(model,context,gateway_name);session_key=gateway_name,catalog
			if session_key in failed_gateways:continue
			session=sessions.get(session_key)
			if session is _A:
				try:session=_create_gx_gateway_session(context,gateway_name,correlation_id=correlation_id,catalog=catalog)
				except ConfigError as exc:logger.error('[gx] Gateway %r does not support GX DQ for run %r: %s',gateway_name,run_id,exc);failed_gateways.add(session_key);continue
				except Exception as exc:logger.error('[gx] Could not create GX context for gateway %r run %r: %s',gateway_name,run_id,exc,exc_info=_B);continue
				sessions[session_key]=session
			try:
				scan_start_ts=now_timestamp();rule_results=_run_gx_scan_for_model(session,model,spec,run_options=run_options,scan_time=execution_time or scan_start_ts,quality_state=context.state_sync.quality_state,environment=environment);rule_results=_enrich_fail_diagnostics(model,spec,rule_results,execution_adapter=session.dq_adapter,capture_samples=run_options.capture_failed_row_samples,max_items=run_options.max_items,dialect=session.dialect);dq_model_name=fqn_to_unquoted(model.name,dialect=model.dialect);table_sql=fqn_to_unquoted(model.fqn,dialect=session.dialect);profile_data:t.Optional[t.List[t.Dict[str,t.Any]]]=_A
				if spec.profiles:requested=set(spec.profiles);table_columns=session.warehouse_adapter.columns(model.fqn);col_types={name:dtype for(name,dtype)in table_columns.items()if name in requested};_warn_unprofiled_columns(me.name,requested,table_columns,col_types);profile_entry=profile_model(session.warehouse_adapter,model_name=dq_model_name,table=table_sql,columns=col_types);profile_data=[profile_entry];profiled_models.append((dq_model_name,list(spec.profiles)))
				summary=_build_gx_check_summary(me.fqn,spec,rule_results);check_summaries.append(summary);persist_gx_scan(context.state_sync,dq_model_name,spec,rule_results,run_id=run_id,environment=environment,job_type=job_type,scan_start_ts=scan_start_ts,dialect=session.dialect,profiling=profile_data,queries=_A,capture_failed_row_samples=run_options.capture_failed_row_samples)
			except Exception as exc:logger.error('[gx] DQ failed for model %s: %s',me.fqn,exc,exc_info=_B);context.state_sync.engine_adapter.recover_failed_connection()
	finally:
		for session in sessions.values():
			if session.qh_hook is not _A:session.qh_hook.dispose_all()
	profile_summary=_build_gx_profile_summary(run_id,environment,profiled_models);return _merge_gx_summaries(check_summaries),profile_summary