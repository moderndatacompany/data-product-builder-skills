from __future__ import annotations
import typing as t
from sqlglot import exp
from vulcan.core.dialect import parse_one
from vulcan.core.dq_types import CheckOutcome
from vulcan.core.gx.anomaly.execution import is_anomaly_expectation,run_anomaly_checks
from vulcan.core.gx.change.execution import is_change_expectation,run_change_checks
from vulcan.core.gx.definitions import GxExceptionDetail,GxRuleResult
from vulcan.core.gx.metric_execution import execute_metric_requests
from vulcan.core.gx.metric_planning import isolated_requests_from_expectations
from vulcan.utils.date import TimeLike
if t.TYPE_CHECKING:from vulcan.core.engine_adapter.base import EngineAdapter;from vulcan.core.gx.definitions import DqExpectation
def is_historic_expectation(expectation_type:str)->bool:return is_anomaly_expectation(expectation_type)or is_change_expectation(expectation_type)
def run_historic_checks(*,execution_adapter:'EngineAdapter',dialect:str,model_name:str,gateway:str,environment:str,filter_sql:t.Optional[str],expectations:t.Sequence['DqExpectation'],scan_time:TimeLike,quality_state:t.Any)->t.Dict[str,GxRuleResult]:
	anomaly_requests,anomaly_request_errors=isolated_requests_from_expectations(expectations,predicate=is_anomaly_expectation);change_requests,change_request_errors=isolated_requests_from_expectations(expectations,predicate=is_change_expectation);requests=[*anomaly_requests,*change_requests];request_errors={**anomaly_request_errors,**change_request_errors}
	if not requests and not request_errors:return{}
	table:exp.Expression=exp.to_table(model_name,dialect=dialect)
	if filter_sql:table=exp.select('*').from_(table).where(parse_one(filter_sql,dialect=dialect)).subquery('_dq_historic')
	metric_results,metric_errors=execute_metric_requests(execution_adapter=execution_adapter,requests=requests,table=table,dialect=dialect)if requests else({},{});invalid_results={check_name:GxRuleResult(check_name=check_name,outcome=CheckOutcome.ERROR,exception=GxExceptionDetail(message=str(error)))for(check_name,error)in request_errors.items()};common:t.Dict[str,t.Any]={'execution_adapter':execution_adapter,'dialect':dialect,'model_name':model_name,'gateway':gateway,'environment':environment,'filter_sql':filter_sql,'expectations':expectations,'scan_time':scan_time,'quality_state':quality_state};return{**invalid_results,**run_anomaly_checks(**common,requests=anomaly_requests,metric_results=metric_results,metric_errors=metric_errors),**run_change_checks(**common,requests=change_requests,metric_results=metric_results,metric_errors=metric_errors)}