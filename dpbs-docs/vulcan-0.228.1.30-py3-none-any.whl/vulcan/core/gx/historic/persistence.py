from __future__ import annotations
import typing as t
from vulcan.core.gx.anomaly.constants import ANOMALY_EXPECTATION_TYPE
from vulcan.core.gx.change.constants import CHANGE_EXPECTATION_TYPE
if t.TYPE_CHECKING:from vulcan.core.gx.definitions import GxRuleResult
def should_persist_historic_diagnostics(expectation_type:str,result:t.Optional['GxRuleResult'])->bool:return expectation_type in{ANOMALY_EXPECTATION_TYPE,CHANGE_EXPECTATION_TYPE}and result is not None