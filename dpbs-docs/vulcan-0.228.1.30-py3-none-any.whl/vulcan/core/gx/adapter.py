from __future__ import annotations
_G='unexpected_list'
_F='details'
_E='unexpected_rows'
_D='raised_exception'
_C='exception_traceback'
_B='exception_message'
_A=None
import logging,typing as t
from vulcan.core.dq_types import CheckOutcome
from vulcan.core.gx.definitions import GxExceptionDetail,GxRuleResult
from vulcan.utils.redaction import redact_secrets
if t.TYPE_CHECKING:from collections.abc import Mapping,Sequence;from great_expectations.core.expectation_validation_result import ExpectationSuiteValidationResult,ExpectationValidationResult
logger=logging.getLogger(__name__)
_DEFAULT_EXCEPTION_MESSAGE='GX expectation raised an exception'
_MAX_TRACEBACK_CHARS=4096
def _exception_detail(message:object,traceback:object,*,metric_id:t.Optional[str]=_A)->GxExceptionDetail:safe_message=redact_secrets(str(message))if message else _A;safe_traceback=redact_secrets(str(traceback))if traceback else _A;return GxExceptionDetail(message=safe_message or _DEFAULT_EXCEPTION_MESSAGE,traceback=safe_traceback[:_MAX_TRACEBACK_CHARS]if safe_traceback else _A,metric_id=metric_id)
def parse_exception_info(exception_info:object)->t.Optional[GxExceptionDetail]:
	if exception_info is _A:return
	if not isinstance(exception_info,dict):
		raised=getattr(exception_info,_D,False)
		if not raised:return
		return _exception_detail(getattr(exception_info,_B,_A),getattr(exception_info,_C,_A))
	if not exception_info:return
	if _D in exception_info or _B in exception_info:
		if exception_info.get(_D):return _exception_detail(exception_info.get(_B),exception_info.get(_C))
		return
	raised_payloads:t.List[t.Tuple[str,t.Dict[str,t.Any]]]=[]
	for(key,value)in exception_info.items():
		if isinstance(value,dict):
			if value.get(_D):raised_payloads.append((str(key),value))
			continue
		nested=parse_exception_info(value)
		if nested is not _A:raised_payloads.append((str(key),{_D:True,_B:nested.message,_C:nested.traceback}))
	if not raised_payloads:return
	if len(raised_payloads)==1:metric_id,payload=raised_payloads[0];return _exception_detail(payload.get(_B),payload.get(_C),metric_id=metric_id)
	first_metric_id,_=raised_payloads[0];combined_msg='; '.join(str(p.get(_B)or _DEFAULT_EXCEPTION_MESSAGE)for(_,p)in raised_payloads);combined_tb_parts=[p.get(_C)for(_,p)in raised_payloads if p.get(_C)];combined_tb='\n---\n'.join(str(tb_part)for tb_part in combined_tb_parts)if combined_tb_parts else _A;return _exception_detail(combined_msg,combined_tb,metric_id=first_metric_id)
def resolve_check_name(expectation_config:object)->t.Optional[str]:
	meta=getattr(expectation_config,'meta',_A)
	if isinstance(meta,dict):
		meta_name=meta.get('name')
		if isinstance(meta_name,str)and meta_name.strip():return meta_name.strip()
	notes=getattr(expectation_config,'notes',_A)
	if isinstance(notes,str)and notes.strip():return notes.strip()
	if isinstance(notes,(list,tuple)):
		for item in notes:
			if isinstance(item,str)and item.strip():return item.strip()
def extract_observed_value(result_dict:object)->object:
	if not isinstance(result_dict,dict):return
	return result_dict.get('observed_value')
def extract_reproduce_query(result_dict:object)->t.Optional[str]:
	if not isinstance(result_dict,dict):return
	query=result_dict.get('unexpected_index_query')
	if isinstance(query,str)and query.strip():return query.strip()
def extract_total_failing_rows(result_dict:object,observed_value:object)->t.Optional[int]:
	if not isinstance(result_dict,dict):return
	unexpected_count=result_dict.get('unexpected_count')
	if isinstance(unexpected_count,(int,float))and not isinstance(unexpected_count,bool):return int(unexpected_count)
	if isinstance(observed_value,(int,float))and not isinstance(observed_value,bool):return int(observed_value)
def extract_failed_rows_sample(result_dict:object,max_items:int)->t.Tuple[t.Dict[str,object],...]:
	A='value'
	if not isinstance(result_dict,dict):return()
	details=result_dict.get(_F);details_rows=_A
	if isinstance(details,dict):details_rows=details.get(_E)
	unexpected=details_rows or result_dict.get(_E)or result_dict.get(_G)or result_dict.get('partial_unexpected_list')
	if not unexpected:return()
	rows:t.List[t.Dict[str,object]]=[]
	for r in unexpected[:max_items]:
		if hasattr(r,'__iter__')and not isinstance(r,(str,bytes)):
			try:rows.append(dict(r))
			except Exception:rows.append({A:r})
		else:rows.append({A:r})
	return tuple(rows)
def extract_gx_exception_snapshot(exception_info:object)->t.Optional[t.Dict[str,object]]:
	detail=parse_exception_info(exception_info)
	if detail is _A:return
	snapshot:t.Dict[str,object]={_D:True,_B:detail.message}
	if detail.traceback:snapshot[_C]=detail.traceback
	if detail.metric_id:snapshot['metric_id']=detail.metric_id
	return snapshot
def extract_gx_result_snapshot(result_dict:object,*,max_items:int=20)->t.Optional[t.Dict[str,object]]:
	if not isinstance(result_dict,dict)or not result_dict:return
	skip_keys=frozenset({_E,_G});snapshot:t.Dict[str,object]={}
	for(key,value)in result_dict.items():
		if key in skip_keys or value is _A:continue
		if isinstance(value,list):
			if not value:continue
			snapshot[key]=value[:max_items]
			if len(value)>max_items:snapshot[f"{key}_truncated_count"]=len(value)-max_items
		else:snapshot[key]=value
	details=snapshot.pop(_F,_A)
	if isinstance(details,dict):
		details_snapshot={key:val for(key,val)in details.items()if key!=_E and val is not _A}
		if details_snapshot:snapshot[_F]=details_snapshot
	return snapshot or _A
def parse_expectation_validation_result(result:'ExpectationValidationResult',*,max_items:int)->t.Optional[GxRuleResult]:
	check_name=resolve_check_name(getattr(result,'expectation_config',_A))
	if check_name is _A:return
	raw_exception_info=getattr(result,'exception_info',_A);exception_detail=parse_exception_info(raw_exception_info)
	if exception_detail is not _A:gx_result=extract_gx_exception_snapshot(raw_exception_info);return GxRuleResult(check_name=check_name,outcome=CheckOutcome.ERROR,exception=exception_detail,gx_result=gx_result)
	raw_result=result.result if isinstance(getattr(result,'result',_A),dict)else{};observed_value=extract_observed_value(raw_result);reproduce_query=extract_reproduce_query(raw_result);total_failing_rows=extract_total_failing_rows(raw_result,observed_value);gx_result=extract_gx_result_snapshot(raw_result,max_items=max_items)
	if getattr(result,'success',False):return GxRuleResult(check_name=check_name,outcome=CheckOutcome.PASS,observed_value=observed_value,reproduce_query=reproduce_query,total_failing_rows=total_failing_rows)
	failed_rows=extract_failed_rows_sample(raw_result,max_items=max_items);return GxRuleResult(check_name=check_name,outcome=CheckOutcome.FAIL,observed_value=observed_value,failed_rows_sample=failed_rows,reproduce_query=reproduce_query,total_failing_rows=total_failing_rows,gx_result=gx_result)
def parse_suite_validation_result(suite_result:'ExpectationSuiteValidationResult',*,notes_to_siblings:'Mapping[str, Sequence[str]]',max_items:int)->t.Dict[str,GxRuleResult]:
	rule_results:t.Dict[str,GxRuleResult]={}
	for evr in suite_result.results:
		rule_result=parse_expectation_validation_result(evr,max_items=max_items)
		if rule_result is _A:logger.warning('[gx] Validation result has no resolvable check name; skipping');continue
		primary=rule_result.check_name
		for sibling in notes_to_siblings.get(primary,[primary]):
			if sibling==primary:rule_results[sibling]=rule_result
			else:rule_results[sibling]=GxRuleResult(check_name=sibling,outcome=rule_result.outcome,observed_value=rule_result.observed_value,failed_rows_sample=rule_result.failed_rows_sample,reproduce_query=rule_result.reproduce_query,total_failing_rows=rule_result.total_failing_rows,exception=rule_result.exception,gx_result=rule_result.gx_result)
	return rule_results