from __future__ import annotations
_A=None
import statistics,typing as t
from vulcan.core.dq_types import CheckOutcome
from vulcan.core.gx.change.types import ChangeEvaluation
def aggregate_history(measurements:t.Sequence[t.Mapping[str,t.Any]],*,aggregation:str,count:int)->t.Optional[float]:
	A='value';values=[float(measurement[A])for measurement in measurements[:count]if measurement.get(A)is not _A]
	if not values:return
	if aggregation=='avg':return float(statistics.fmean(values))
	if aggregation=='min':return min(values)
	if aggregation=='max':return max(values)
	raise ValueError(f"unsupported historic aggregation: {aggregation}")
def _passes(value:float,*,operator:str,threshold:float,threshold_upper:t.Optional[float])->bool:
	if operator=='>':return value>threshold
	if operator=='>=':return value>=threshold
	if operator=='<':return value<threshold
	if operator=='<=':return value<=threshold
	if operator=='=':return value==threshold
	if operator=='!=':return value!=threshold
	if operator=='between':assert threshold_upper is not _A;return threshold<=value<=threshold_upper
	raise ValueError(f"unsupported change operator: {operator}")
def evaluate_change(*,current_value:float,historic_value:t.Optional[float],percent:bool,operator:str,threshold:float,threshold_upper:t.Optional[float]=_A)->ChangeEvaluation:
	current=float(current_value)
	if historic_value is _A:return ChangeEvaluation(outcome=CheckOutcome.NOT_EVALUATED,current_value=current,historic_value=_A,change_value=_A,reason='Change-over-time needs at least one historic measurement.')
	historic=float(historic_value);difference=current-historic
	if percent:
		if historic==0:
			if difference==0:difference=.0
			else:return ChangeEvaluation(outcome=CheckOutcome.NOT_EVALUATED,current_value=current,historic_value=historic,change_value=_A,reason='Percentage change is undefined when the historic value is zero.')
		else:difference=difference/historic*100
	passed=_passes(difference,operator=operator,threshold=threshold,threshold_upper=threshold_upper);return ChangeEvaluation(outcome=CheckOutcome.PASS if passed else CheckOutcome.FAIL,current_value=current,historic_value=historic,change_value=float(difference))