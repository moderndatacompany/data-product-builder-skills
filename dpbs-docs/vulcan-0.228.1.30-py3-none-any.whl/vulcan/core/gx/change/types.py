from __future__ import annotations
import typing as t
from dataclasses import dataclass
from vulcan.core.dq_types import CheckOutcome
@dataclass(frozen=True)
class ChangeTranslation:matched:bool;expectation:t.Optional[t.Dict[str,t.Any]]=None
@dataclass(frozen=True)
class ChangeEvaluation:outcome:CheckOutcome;current_value:float;historic_value:t.Optional[float];change_value:t.Optional[float];reason:t.Optional[str]=None