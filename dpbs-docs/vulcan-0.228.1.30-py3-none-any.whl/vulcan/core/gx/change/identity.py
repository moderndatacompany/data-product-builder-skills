from __future__ import annotations
from vulcan.core.gx.metric_planning import MetricRequest
from vulcan.core.gx.metric_identity import stable_uuid
def change_check_identity(request:MetricRequest,metric_identity:str)->str:G='threshold_upper';F='threshold';E='operator';D='percent';C='history_count';B='history_aggregation';A='history_mode';options=request.options;payload={'version':1,'metric_identity':metric_identity,A:options[A],B:options[B],C:options[C],D:options.get(D,False),E:options[E],F:options[F],G:options.get(G)};return stable_uuid(payload)