from __future__ import annotations
_D='vulcan_sql'
_C='vulcan_table'
_B='EngineAdapter'
_A=None
import typing as t
from great_expectations.datasource.fluent.interfaces import TestConnectionError
from great_expectations.datasource.fluent.sql_datasource import SQLDatasource,TableAsset
from pydantic.v1 import PrivateAttr
from sqlglot import exp
if t.TYPE_CHECKING:from vulcan.core.engine_adapter.base import EngineAdapter
class VulcanTableAsset(TableAsset):
	type:t.Literal[_C]=_C
	def test_connection(self)->_A:
		datasource=self.datasource
		if not isinstance(datasource,VulcanSQLDatasource):raise TypeError('VulcanTableAsset requires a VulcanSQLDatasource')
		datasource.test_table_connection(table_name=self.table_name,schema_name=self._effective_schema_name)
class VulcanSQLDatasource(SQLDatasource):
	type:t.Literal[_D]=_D;_vulcan_adapter:t.Optional[_B]=PrivateAttr(default=_A);_vulcan_catalog:t.Optional[str]=PrivateAttr(default=_A);_TableAsset=PrivateAttr(default=VulcanTableAsset)
	def bind_vulcan_adapter(self,adapter:_B,*,catalog:t.Optional[str]=_A)->_A:self._vulcan_adapter=adapter;self._vulcan_catalog=catalog
	def _adapter(self)->_B:
		if self._vulcan_adapter is _A:raise RuntimeError('GX datasource is not bound to a Vulcan EngineAdapter')
		return self._vulcan_adapter
	def test_connection(self,test_assets:bool=True)->_A:
		try:self._adapter().fetchone(exp.select(exp.Literal.number(1)))
		except Exception as exc:raise TestConnectionError(cause=exc)from exc
		if test_assets:
			for asset in self.assets:asset._datasource=self;asset.test_connection()
	def test_table_connection(self,*,table_name:str,schema_name:t.Optional[str])->_A:
		table=exp.table_(table_name,db=schema_name,catalog=self._vulcan_catalog);query=exp.select(exp.Literal.number(1)).from_(table).limit(1)
		try:self._adapter().fetchone(query)
		except Exception as exc:raise TestConnectionError(cause=exc)from exc