from __future__ import annotations
_U='unexpected_rows_expectation'
_T='unexpected_rows_query'
_S='fail_query'
_R='fail query'
_Q='row_count'
_P='expectations'
_O='between'
_N='description'
_M='failed rows'
_L='percentile'
_K='name'
_J=False
_I=True
_H='dimension'
_G=']'
_F='max_value'
_E='min_value'
_D='meta'
_C='column'
_B='expectation'
_A=None
import re,typing as t,logging
from dataclasses import dataclass,field
from schema.types import DQDimension
from vulcan.core.gx.anomaly.translation import translate_anomaly_rule
from vulcan.core.gx.change.translation import translate_change_rule
from vulcan.utils.errors import ConfigError
logger=logging.getLogger(__name__)
_ROW_COUNT_RE=re.compile('^\\s*row_count\\s*(>=|<=|>|<|=)\\s*(\\d+)\\s*$',re.IGNORECASE)
_ROW_COUNT_BETWEEN_RE=re.compile('^\\s*row_count\\s+between\\s+(\\d+)\\s+and\\s+(\\d+)\\s*$',re.IGNORECASE)
_MISSING_COUNT_RE=re.compile('^\\s*missing_count\\s*\\(\\s*(.+?)\\s*\\)\\s*(!=|>=|<=|>|<|=)\\s*(\\d+)\\s*$',re.IGNORECASE)
_DUPLICATE_COUNT_RE=re.compile('^\\s*duplicate_count\\s*\\(\\s*(.+?)\\s*\\)\\s*(!=|>=|<=|>|<|=)\\s*(\\d+)\\s*$',re.IGNORECASE)
_INVALID_COUNT_RE=re.compile('^\\s*invalid_count\\s*\\(\\s*(.+?)\\s*\\)\\s*(!=|>=|<=|>|<|=)\\s*(\\d+)\\s*$',re.IGNORECASE)
_INVALID_PERCENT_RE=re.compile('^\\s*invalid_percent\\s*\\(\\s*(.+?)\\s*\\)\\s*(!=|>=|<=|>|<|=)\\s*(\\d+(?:\\.\\d+)?)\\s*$',re.IGNORECASE)
_VALID_COUNT_RE=re.compile('^\\s*valid_count\\s*\\(\\s*(.+?)\\s*\\)\\s*(!=|>=|<=|>|<|=)\\s*(\\d+)\\s*$',re.IGNORECASE)
_FRESHNESS_RE=re.compile('^\\s*freshness\\s*\\(\\s*(.+?)\\s*\\)\\s*(>=|<=|>|<|=)\\s*(\\d+(?:\\.\\d+)?)\\s*(s|m|h|d|w)\\s*$',re.IGNORECASE)
_MISSING_PERCENT_RE=re.compile('^\\s*missing_percent\\s*\\(\\s*(.+?)\\s*\\)\\s*(!=|>=|<=|>|<|=)\\s*(\\d+(?:\\.\\d+)?)\\s*$',re.IGNORECASE)
_DUPLICATE_PERCENT_RE=re.compile('^\\s*duplicate_percent\\s*\\(\\s*(.+?)\\s*\\)\\s*(!=|>=|<=|>|<|=)\\s*(\\d+(?:\\.\\d+)?)\\s*$',re.IGNORECASE)
_BARE_COLUMN_METRIC_RE=re.compile('^\\s*(?:missing_count|missing_percent|duplicate_count|duplicate_percent|invalid_count|invalid_percent|valid_count|avg|min|max|sum|percentile|min_length|max_length|avg_length|stddev|stddev_pop|stddev_samp|variance|var_pop|var_samp)\\s*\\([^)]*\\)\\s*$',re.IGNORECASE)
_BARE_FRESHNESS_RE=re.compile('^\\s*freshness\\s*\\([^)]*\\)\\s*$',re.IGNORECASE)
_BARE_CHANGE_RE=re.compile('^\\s*change(?:\\s+(?:(?:avg|min|max)\\s+last\\s+\\d+|same\\s+day\\s+last\\s+week))?(?:\\s+percent)?\\s+for\\s+[a-zA-Z_][a-zA-Z0-9_]*(?:\\s*\\([^)]*\\))?\\s*$',re.IGNORECASE)
_STATIC_METRICS='avg|min|max|sum|min_length|max_length|avg_length|stddev|stddev_pop|stddev_samp|variance|var_pop|var_samp'
_STATIC_METRIC_RE=re.compile(rf"^\s*(?P<metric>{_STATIC_METRICS})\s*\(\s*(?P<column>.+?)\s*\)\s*(?P<operator>!=|>=|<=|>|<|=)\s*(?P<threshold>[+-]?\d+(?:\.\d+)?)\s*$",re.IGNORECASE)
_STATIC_METRIC_BETWEEN_RE=re.compile(rf"^\s*(?P<metric>{_STATIC_METRICS})\s*\(\s*(?P<column>.+?)\s*\)\s+between\s+(?P<lower>[+-]?\d+(?:\.\d+)?)\s+and\s+(?P<upper>[+-]?\d+(?:\.\d+)?)\s*$",re.IGNORECASE)
_PERCENTILE_RE=re.compile('^\\s*percentile\\s*\\(\\s*(?P<column>.+?)\\s*,\\s*(?P<percentile>\\d+(?:\\.\\d+)?)\\s*\\)\\s*(?P<operator>!=|>=|<=|>|<|=)\\s*(?P<threshold>[+-]?\\d+(?:\\.\\d+)?)\\s*$',re.IGNORECASE)
_PERCENTILE_BETWEEN_RE=re.compile('^\\s*percentile\\s*\\(\\s*(?P<column>.+?)\\s*,\\s*(?P<percentile>\\d+(?:\\.\\d+)?)\\s*\\)\\s+between\\s+(?P<lower>[+-]?\\d+(?:\\.\\d+)?)\\s+and\\s+(?P<upper>[+-]?\\d+(?:\\.\\d+)?)\\s*$',re.IGNORECASE)
_REFERENTIAL_RE=re.compile('^\\s*values\\s+in\\s*\\((?P<source>[^)]+)\\)\\s+must\\s+exist\\s+in\\s+(?P<table>[a-zA-Z_][a-zA-Z0-9_.]*)\\s*\\((?P<target>[^)]+)\\)\\s*$',re.IGNORECASE)
class UnsupportedDQExpressionError(ConfigError):
	def __init__(self,expression:str,rule_name:t.Optional[str]=_A,hint:t.Optional[str]=_A)->_A:label=f" (rule {rule_name!r})"if rule_name else'';hint_text=f" {hint}"if hint else'';super().__init__(f"GX translator: unsupported DQ expression{label}: {expression!r}.{hint_text}");self.expression=expression;self.rule_name=rule_name;self.hint=hint
@dataclass
class _QualityRule:name:t.Optional[str];expression:str;dimension:DQDimension;description:t.Optional[str]=_A;extra:t.Dict[str,t.Any]=field(default_factory=dict)
@dataclass
class _TranslationReport:
	skipped:t.List[t.Tuple[str,str]]=field(default_factory=list);notes:t.List[t.Tuple[str,str]]=field(default_factory=list)
	def skip(self,rule_name:str,reason:str)->_A:self.skipped.append((rule_name,reason))
	def note(self,rule_name:str,reason:str)->_A:self.notes.append((rule_name,reason))
def _dq_optional_str(v:t.Any)->t.Optional[str]:
	if v is _A:return
	s=str(v).strip();return s or _A
def _resolve_dimension(expression:str,dimension_by_author:t.Any)->DQDimension:
	D='uniqueness';C='completeness';B='validity';A='accuracy';from pydantic import TypeAdapter,ValidationError;from schema.types import DQDimension as _DQDim;adapter:TypeAdapter[_DQDim]=TypeAdapter(_DQDim);METRIC_DEFAULTS:t.Dict[str,_DQDim]={_Q:C,'missing_count':C,'missing_percent':C,'duplicate_count':D,'duplicate_percent':D,'invalid_count':B,'invalid_percent':B,'valid_count':B,'avg':A,'min':A,'max':A,'sum':A,'min_length':A,'max_length':A,'avg_length':A,'stddev':A,'stddev_pop':A,'stddev_samp':A,'variance':A,'var_pop':A,'var_samp':A,_L:A};LEADING_RE=re.compile('^([a-z][a-z0-9_]*)\\s*(?:\\(|(?=\\s*[<>=!]))',re.IGNORECASE);explicit=_dq_optional_str(dimension_by_author)
	if explicit is not _A:
		try:return adapter.validate_python(explicit.lower())
		except ValidationError as e:raise ValueError(f"invalid dq dimension {dimension_by_author!r}")from e
	stripped=expression.strip()
	if re.match('^row_count\\s+between\\b',stripped,re.IGNORECASE):return C
	if re.match('^freshness\\s*\\(',stripped,re.IGNORECASE):return'timeliness'
	if stripped.lower()==_M:return B
	m=LEADING_RE.match(stripped)
	if m is _A:m=re.match('^anomaly\\s+detection\\s+for\\s+([a-z][a-z0-9_]*)',stripped,re.IGNORECASE)
	if m is _A:m=re.match('^change(?:\\s+.+?)?\\s+for\\s+([a-z][a-z0-9_]*)',stripped,re.IGNORECASE)
	if m:
		name=m.group(1).lower()
		if name in METRIC_DEFAULTS:return METRIC_DEFAULTS[name]
	return B
def _parse_rule_item(item:t.Any,label:str)->_QualityRule:
	B='extra';A='expression'
	if isinstance(item,str):
		expr=item.strip()
		if not expr:raise ValueError(f"{label}: rule expression cannot be empty")
		return _QualityRule(name=_A,expression=expr,dimension=_resolve_dimension(expr,_A))
	if not isinstance(item,dict):raise ValueError(f"{label}: each rule must be a string, a one-key mapping, or a flat dict with keys name/expression/dimension/description/extra")
	if A in item:
		payload=dict(item);expr=str(payload.get(A,'')).strip()
		if not expr:raise ValueError(f"{label}: expression cannot be empty")
		if _dq_optional_str(payload.get(_H))is _A:payload[_H]=_resolve_dimension(expr,_A)
		extra=payload.pop(B,{})or{};return _QualityRule(name=_dq_optional_str(payload.get(_K)),expression=expr,dimension=_resolve_dimension(expr,payload.get(_H)),description=_dq_optional_str(payload.get(_N)),extra=extra if isinstance(extra,dict)else{})
	if len(item)!=1:raise ValueError(f"{label}: each rule must be a string, a one-key mapping, or a flat dict with keys name/expression/dimension/description/extra")
	expr_key,inner=next(iter(item.items()))
	if inner is not _A and not isinstance(inner,dict):raise ValueError(f"{label}: rule configuration must be a mapping or null")
	config=dict(inner)if inner else{};name_raw=config.pop(_K,_A);dim_raw=config.pop(_H,_A);description=_dq_optional_str(config.pop(_N,_A));nested_extra=config.pop(B,_A)
	if isinstance(nested_extra,dict):config.update({**nested_extra,**config})
	expr=str(expr_key).strip();name=_dq_optional_str(name_raw)
	if expr.strip().lower()==_M:
		fq=config.get(_R)or config.get(_S)
		if not fq or not str(fq).strip():raise ValueError(f"{label}: for expression 'failed rows', extra must include non-empty 'fail query' (or 'fail_query').")
	return _QualityRule(name=name,expression=expr,dimension=_resolve_dimension(expr,dim_raw),description=description,extra=config)
def _rule_label(rule:_QualityRule)->str:return rule.name or rule.expression
def _parse_raw_rules(raw_rules:t.List[t.Any])->t.List[_QualityRule]:
	rules=[_parse_rule_item(item,f"rules[{i}]")for(i,item)in enumerate(raw_rules)];from vulcan.core.gx.naming import VALID_RULE_NAME;seen:t.Set[str]=set()
	for rule in rules:
		if rule.name is _A:continue
		if not VALID_RULE_NAME.match(rule.name):raise ValueError(f"invalid dq rule name {rule.name!r}. Names must start with a letter and contain only letters, digits and underscores.")
		if rule.name in seen:raise ValueError(f"duplicate dq rule name: {rule.name!r}")
		seen.add(rule.name)
	return rules
def _validate_rule_is_complete(rule:_QualityRule)->_A:
	expr=rule.expression.strip();lower=expr.lower()
	if lower==_Q and not{'warn','fail'}&set(rule.extra):raise ValueError(f"rule {_rule_label(rule)!r}: row_count requires a threshold")
	if _BARE_COLUMN_METRIC_RE.match(expr):raise ValueError(f"rule {_rule_label(rule)!r}: metric check requires a threshold")
	if _BARE_FRESHNESS_RE.match(expr):raise ValueError(f"rule {_rule_label(rule)!r}: freshness requires a threshold")
	if _BARE_CHANGE_RE.match(expr):raise ValueError(f"rule {_rule_label(rule)!r}: change check requires a threshold")
def _zero_defect_translation(op:str,value:float)->t.Tuple[bool,bool]:
	if op=='='and value==0:return _I,_J
	if op=='<='and value>=0:return _I,value!=0
	if op=='<'and value>=1:return _I,value!=1
	return _J,_J
def _record_zero_defect_normalization(rule:_QualityRule,report:_TranslationReport,*,expectation:str)->_A:report.note(_rule_label(rule),f"{rule.expression!r} normalized to {expectation} under Vulcan's zero-defect policy")
def _unsupported_configuration_is_skippable(error:ValueError)->bool:message=str(error).lower();return message.startswith('unsupported anomaly configuration:')or message.startswith('unsupported change configuration:')or message.startswith('unsupported soda format:')or message.startswith('prophet/soda anomaly configuration is no longer supported')
def _split_columns(raw:str)->t.List[str]:
	columns:t.List[str]=[];current:t.List[str]=[];quote:t.Optional[str]=_A
	for char in raw.strip():
		if quote:
			current.append(char)
			if quote==_G and char==_G or quote!=_G and char==quote:quote=_A
			continue
		if char in{'"','`','['}:quote=_G if char=='['else char;current.append(char)
		elif char==',':columns.append(''.join(current).strip());current=[]
		else:current.append(char)
	columns.append(''.join(current).strip());return[column for column in columns if column]
def _column_identifier(raw:str,rule:_QualityRule)->t.Tuple[str,bool]:
	parts:t.List[str]=[];current:t.List[str]=[];quote:t.Optional[str]=_A
	for char in raw.strip():
		if quote:
			current.append(char)
			if quote==_G and char==_G or quote!=_G and char==quote:quote=_A
		elif char in{'"','`','['}:quote=_G if char=='['else char;current.append(char)
		elif char=='.':parts.append(''.join(current).strip());current=[]
		else:current.append(char)
	parts.append(''.join(current).strip());token=parts[-1].strip();quoted=len(token)>=2 and(token[0]==token[-1]and token[0]in{'"','`'}or token[0]=='['and token[-1]==_G)
	if quoted:token=token[1:-1]
	if not token or not re.match('^[^\\x00-\\x1f]+$',token):raise UnsupportedDQExpressionError(rule.expression,rule_name=rule.name,hint=f"Column name {raw!r} is not a valid identifier.")
	return token,quoted
def _column_name(raw:str,rule:_QualityRule)->str:return _column_identifier(raw,rule)[0]
def _columns(raw:str,rule:_QualityRule)->t.List[str]:return[_column_name(column,rule)for column in _split_columns(raw)]
def _referential_columns(raw:str,rule:_QualityRule)->t.Tuple[t.List[str],t.List[bool]]:identifiers=[_column_identifier(column,rule)for column in _split_columns(raw)];return[name for(name,_)in identifiers],[quoted for(_,quoted)in identifiers]
def _meta_for_part(rule:_QualityRule,suffix:str)->t.Dict[str,t.Any]:
	meta=_meta_dict(rule);base=rule.name or re.sub('[^a-zA-Z0-9]+','_',rule.expression).strip('_').lower()
	if not base or not base[0].isalpha():base=f"rule_{base}"
	meta[_K]=f"{base}_{suffix}";return meta
def _validity_expectations(rule:_QualityRule,column:str)->t.List[t.Dict[str,t.Any]]:
	M='valid max';L='valid min';K='valid max length';J='valid min length';I='valid length';H='expect_column_values_to_not_match_regex';G='invalid regex';F='expect_column_values_to_match_regex';E='valid regex';D='invalid values';C='value_set';B='valid values';A='regex';from vulcan.core.gx.anomaly.formats import format_pattern
	if any(key in rule.extra for key in('missing values','missing format','missing regex')):raise UnsupportedDQExpressionError(rule.expression,rule_name=rule.name,hint='custom missing-value semantics have no equivalent stock GX expectation')
	specs:t.List[t.Tuple[str,t.Dict[str,t.Any],str]]=[]
	if B in rule.extra:specs.append(('expect_column_values_to_be_in_set',{C:rule.extra[B]},'valid_values'))
	if D in rule.extra:specs.append(('expect_column_values_to_not_be_in_set',{C:rule.extra[D]},'invalid_values'))
	if E in rule.extra:specs.append((F,{A:rule.extra[E]},'valid_regex'))
	if G in rule.extra:specs.append((H,{A:rule.extra[G]},'invalid_regex'))
	for(key,expectation,suffix)in(('valid format',F,'valid_format'),('invalid format',H,'invalid_format')):
		if key in rule.extra:
			pattern=format_pattern(rule.extra[key])
			if pattern is _A:raise UnsupportedDQExpressionError(rule.expression,rule_name=rule.name,hint=f"unsupported Soda format {rule.extra[key]!r}")
			specs.append((expectation,{A:pattern},suffix))
	if I in rule.extra:specs.append(('expect_column_value_lengths_to_equal',{'value':rule.extra[I]},'valid_length'))
	if J in rule.extra or K in rule.extra:specs.append(('expect_column_value_lengths_to_be_between',{_E:rule.extra.get(J),_F:rule.extra.get(K)},'valid_length_range'))
	if L in rule.extra or M in rule.extra:specs.append(('expect_column_values_to_be_between',{_E:rule.extra.get(L),_F:rule.extra.get(M)},'valid_range'))
	if not specs:raise UnsupportedDQExpressionError(rule.expression,rule_name=rule.name,hint='invalid_count/invalid_percent requires a validity definition')
	return[{_B:expectation,_C:column,**kwargs,_D:_meta_for_part(rule,suffix)}for(expectation,kwargs,suffix)in specs]
def _quoted_identifier(value:str)->str:return'"'+value.replace('"','""')+'"'
def _referential_expectation(rule:_QualityRule,match:re.Match[str])->t.Dict[str,t.Any]:
	A=' AND ';source_columns,source_columns_quoted=_referential_columns(match.group('source'),rule);target_columns,target_columns_quoted=_referential_columns(match.group('target'),rule)
	if not source_columns or len(source_columns)!=len(target_columns):raise ValueError('referential check requires the same number of source and target columns')
	target_table=match.group('table');joins=A.join(f"src.{_quoted_identifier(source)} = ref.{_quoted_identifier(target)}"for(source,target)in zip(source_columns,target_columns));source_present=A.join(f"src.{_quoted_identifier(source)} IS NOT NULL"for source in source_columns);target_missing=f"ref.{_quoted_identifier(target_columns[0])} IS NULL";query=f"SELECT src.* FROM {{batch}} AS src LEFT JOIN {target_table} AS ref ON {joins} WHERE {source_present} AND {target_missing}";return{_B:_U,_T:query,'vulcan_referential':{'source_columns':source_columns,'target_table':target_table,'target_columns':target_columns,'source_columns_quoted':source_columns_quoted,'target_columns_quoted':target_columns_quoted},_D:_meta_dict(rule)}
def _meta_dict(rule:_QualityRule)->t.Dict[str,t.Any]:
	meta:t.Dict[str,t.Any]={_H:str(rule.dimension)}
	if rule.name:meta[_K]=rule.name
	if rule.description:meta[_N]=rule.description
	return meta
def _between_kwargs(operator:str,lower:float,upper:t.Optional[float]=_A)->t.Dict[str,t.Any]:
	if operator==_O:return{_E:lower,_F:upper}
	if operator=='=':return{_E:lower,_F:lower}
	if operator=='>':return{_E:lower,_F:_A,'strict_min':_I}
	if operator=='>=':return{_E:lower,_F:_A}
	if operator=='<':return{_E:_A,_F:lower,'strict_max':_I}
	if operator=='<=':return{_E:_A,_F:lower}
	raise UnsupportedDQExpressionError(f"aggregate comparison {operator}",hint='stock GX between expectations do not support !=')
def _aggregate_expectation(rule:_QualityRule,*,metric:str,column:str,operator:str,lower:float,upper:t.Optional[float]=_A)->t.Dict[str,t.Any]:
	gx_types={'avg':'expect_column_mean_to_be_between','min':'expect_column_min_to_be_between','max':'expect_column_max_to_be_between','sum':'expect_column_sum_to_be_between'};gx_type=gx_types.get(metric)
	if gx_type is _A:raise UnsupportedDQExpressionError(rule.expression,rule_name=rule.name,hint=f"{metric} has no close stock GX aggregate expectation")
	return{_B:gx_type,_C:column,**_between_kwargs(operator,lower,upper),_D:_meta_dict(rule)}
def _percentile_expectation(rule:_QualityRule,*,report:_TranslationReport,column:str,percentile:float,operator:str,lower:float,upper:t.Optional[float]=_A)->t.Dict[str,t.Any]:
	if not 0<=percentile<=1:raise ValueError('percentile must be between 0 and 1')
	bounds=_between_kwargs(operator,lower,upper)
	if operator in{'>','<'}:report.note(_rule_label(rule),f"{rule.expression!r} uses a strict percentile bound; stock GX quantile ranges are inclusive")
	return{_B:'expect_column_quantile_values_to_be_between',_C:column,'quantile_ranges':{'quantiles':[percentile],'value_ranges':[[bounds.get(_E),bounds.get(_F)]]},_D:_meta_dict(rule)}
def _translate_one(rule:_QualityRule,report:_TranslationReport)->t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Dict[str,t.Any]]]]:
	H='threshold';G='operator';F='upper';E='lower';D='metric';C='expect_table_row_count_to_be_between';B='expect_column_values_to_be_unique';A='expect_column_values_to_not_be_null';expr=rule.expression.strip()
	try:anomaly=translate_anomaly_rule(expr,meta=_meta_dict(rule),configurations=rule.extra,rule_label=_rule_label(rule),record_skip=report.skip)
	except ValueError as error:
		if _unsupported_configuration_is_skippable(error):report.skip(_rule_label(rule),str(error));return
		raise
	if anomaly.matched:return anomaly.expectation
	try:change=translate_change_rule(expr,meta=_meta_dict(rule),configurations=rule.extra,rule_label=_rule_label(rule),record_skip=report.skip)
	except ValueError as error:
		if _unsupported_configuration_is_skippable(error):report.skip(_rule_label(rule),str(error));return
		raise
	if change.matched:return change.expectation
	if expr.lower()in{'schema','schema evolution'}:raise UnsupportedDQExpressionError(rule.expression,rule_name=rule.name,hint='schema checks are intentionally not implemented in the GX integration')
	referential=_REFERENTIAL_RE.match(expr)
	if referential:return _referential_expectation(rule,referential)
	if expr.lower()==_M:
		fail_query:t.Optional[str]=rule.extra.get(_R)or rule.extra.get(_S)
		if not fail_query or not str(fail_query).strip():raise UnsupportedDQExpressionError(rule.expression,rule_name=rule.name,hint="'failed rows' requires non-empty 'fail query' (or 'fail_query') in extra.")
		return{_B:_U,_T:str(fail_query).strip(),_D:_meta_dict(rule)}
	row_between=_ROW_COUNT_BETWEEN_RE.match(expr)
	if row_between:
		lower,upper=int(row_between.group(1)),int(row_between.group(2))
		if lower>upper:raise ValueError('row_count between lower bound cannot exceed upper bound')
		return{_B:C,_E:lower,_F:upper,_D:_meta_dict(rule)}
	m=_ROW_COUNT_RE.match(expr)
	if m:op,n=m.group(1),int(m.group(2));bounds:t.Dict[str,t.Tuple[t.Optional[int],t.Optional[int]]]={'>':(n+1,_A),'>=':(n,_A),'<':(_A,n-1),'<=':(_A,n),'=':(n,n)};min_v,max_v=bounds[op];return{_B:C,_E:min_v,_F:max_v,_D:_meta_dict(rule)}
	m=_MISSING_COUNT_RE.match(expr)
	if m:
		col,op,n=_column_name(m.group(1),rule),m.group(2),int(m.group(3));translate,normalized=_zero_defect_translation(op,n)
		if not translate:report.skip(_rule_label(rule),f"{rule.expression!r} is not compatible with Vulcan's zero-defect missing-value policy");return
		if normalized:_record_zero_defect_normalization(rule,report,expectation=A)
		return{_B:A,_C:col,_D:_meta_dict(rule)}
	m=_MISSING_PERCENT_RE.match(expr)
	if m:
		col,op,pct=_column_name(m.group(1),rule),m.group(2),float(m.group(3));translate,normalized=_zero_defect_translation(op,pct)
		if not translate:report.skip(_rule_label(rule),f"{rule.expression!r} is not compatible with Vulcan's zero-defect missing-value policy");return
		if normalized:_record_zero_defect_normalization(rule,report,expectation=A)
		return{_B:A,_C:col,_D:_meta_dict(rule)}
	m=_DUPLICATE_COUNT_RE.match(expr)
	if m:
		columns,op,n=_columns(m.group(1),rule),m.group(2),int(m.group(3));translate,normalized=_zero_defect_translation(op,n)
		if translate:
			expectation_type='expect_compound_columns_to_be_unique'if len(columns)>1 else B
			if normalized:_record_zero_defect_normalization(rule,report,expectation=expectation_type)
			translated:t.Dict[str,t.Any]={_B:expectation_type,_D:_meta_dict(rule)}
			if len(columns)>1:translated['column_list']=columns
			else:translated[_C]=columns[0]
			return translated
		report.skip(_rule_label(rule),f"{rule.expression!r} is not compatible with Vulcan's zero-defect uniqueness policy");return
	m=_DUPLICATE_PERCENT_RE.match(expr)
	if m:
		col,op,pct=_column_name(m.group(1),rule),m.group(2),float(m.group(3));translate,normalized=_zero_defect_translation(op,pct)
		if translate:
			if normalized:_record_zero_defect_normalization(rule,report,expectation=B)
			return{_B:B,_C:col,_D:_meta_dict(rule)}
		report.skip(_rule_label(rule),f"{rule.expression!r} is not compatible with Vulcan's zero-defect uniqueness policy");return
	m=_INVALID_COUNT_RE.match(expr)or _INVALID_PERCENT_RE.match(expr)
	if m:
		col,op,value=_column_name(m.group(1),rule),m.group(2),float(m.group(3));translate,normalized=_zero_defect_translation(op,value)
		if not translate:report.skip(_rule_label(rule),f"{rule.expression!r} is not compatible with Vulcan's zero-defect validity policy");return
		translated=_validity_expectations(rule,col)
		if normalized:report.note(_rule_label(rule),f"{rule.expression!r} normalized to zero-invalid GX row expectations")
		return translated
	if _VALID_COUNT_RE.match(expr):raise UnsupportedDQExpressionError(rule.expression,rule_name=rule.name,hint='valid_count has no stock GX aggregate expectation')
	metric_between=_STATIC_METRIC_BETWEEN_RE.match(expr)
	if metric_between:return _aggregate_expectation(rule,metric=metric_between.group(D).lower(),column=_column_name(metric_between.group(_C),rule),operator=_O,lower=float(metric_between.group(E)),upper=float(metric_between.group(F)))
	metric=_STATIC_METRIC_RE.match(expr)
	if metric:return _aggregate_expectation(rule,metric=metric.group(D).lower(),column=_column_name(metric.group(_C),rule),operator=metric.group(G),lower=float(metric.group(H)))
	percentile_between=_PERCENTILE_BETWEEN_RE.match(expr)
	if percentile_between:return _percentile_expectation(rule,report=report,column=_column_name(percentile_between.group(_C),rule),percentile=float(percentile_between.group(_L)),operator=_O,lower=float(percentile_between.group(E)),upper=float(percentile_between.group(F)))
	percentile=_PERCENTILE_RE.match(expr)
	if percentile:return _percentile_expectation(rule,report=report,column=_column_name(percentile.group(_C),rule),percentile=float(percentile.group(_L)),operator=percentile.group(G),lower=float(percentile.group(H)))
	m=_FRESHNESS_RE.match(expr)
	if m:col=_column_name(m.group(1),rule);unit=m.group(4).lower();unit_seconds={'s':1.,'m':6e1,'h':36e2,'d':864e2,'w':6048e2};threshold_seconds=float(m.group(3))*unit_seconds[unit];return{_B:'vulcan_freshness',_C:col,'op':m.group(2),'threshold_seconds':threshold_seconds,_D:_meta_dict(rule)}
	raise UnsupportedDQExpressionError(expr,rule_name=rule.name)
def _emit_rules_migration_warning(*,label:str,path:t.Optional[str],expectations:t.List[t.Dict[str,t.Any]],report:_TranslationReport)->_A:
	if path is _A:logger=logging.getLogger(__name__);logger.debug('[gx] %s: legacy rules translated from stored snapshot',label);return
	from vulcan.core.console import get_console;location=f"'{label}'"
	if path:location=f"{location} ({path})"
	parts=[f"[gx] {location}: legacy 'rules:' auto-migrated to 'expectations:'. Replace your rules: block with:",'']
	try:import yaml;yaml_body=yaml.dump({_P:expectations},default_flow_style=_J,sort_keys=_J).rstrip()
	except Exception:yaml_body=str({_P:expectations})
	parts.append(yaml_body)
	if report.skipped:parts.extend(['','Skipped (not supported):']);parts.extend(f"  - {name}: {reason}"for(name,reason)in report.skipped)
	if report.notes:parts.extend(['','Normalized during migration:']);parts.extend(f"  - {name}: {reason}"for(name,reason)in report.notes)
	get_console().log_warning('\n'.join(parts))
def translate_rules_to_expectations(raw_rules:t.List[t.Any],*,table_ref:t.Optional[str]=_A,model_name:t.Optional[str]=_A,path:t.Optional[str]=_A)->t.Dict[str,t.Any]:
	label=model_name or path or'unknown';rules=_parse_raw_rules(raw_rules);report=_TranslationReport();expectations:t.List[t.Dict[str,t.Any]]=[]
	for rule in rules:
		_validate_rule_is_complete(rule)
		try:flat_dict=_translate_one(rule,report)
		except UnsupportedDQExpressionError as error:reason=error.hint or'no equivalent GX/Vulcan translation';report.skip(_rule_label(rule),f"{rule.expression!r} — {reason}");continue
		if flat_dict is _A:continue
		if isinstance(flat_dict,list):expectations.extend(flat_dict)
		else:expectations.append(flat_dict)
	_emit_rules_migration_warning(label=label,path=path,expectations=expectations,report=report);return{_P:expectations}