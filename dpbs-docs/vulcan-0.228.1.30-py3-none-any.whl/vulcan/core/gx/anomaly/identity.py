from __future__ import annotations
import typing as t
from vulcan.core.gx.metric_planning import MetricRequest
from vulcan.core.gx.metric_identity import semantic_metric_identity,stable_uuid
def anomaly_metric_identity(request:MetricRequest,*,model_name:str,model_filter:t.Optional[str],dialect:str,gateway:str,environment:str)->str:return semantic_metric_identity(request,model_name=model_name,model_filter=model_filter,dialect=dialect,gateway=gateway,environment=environment)
def anomaly_check_identity(request:MetricRequest,*,model_name:str,model_filter:t.Optional[str],dialect:str,gateway:str,environment:str)->str:metric_identity=anomaly_metric_identity(request,model_name=model_name,model_filter=model_filter,dialect=dialect,gateway=gateway,environment=environment);return stable_uuid({'version':1,'kind':'anomaly','metric_identity':metric_identity})