from __future__ import annotations
import typing as t
from dataclasses import dataclass
from vulcan.core.dq_types import CheckOutcome
@dataclass(frozen=True)
class AnomalyDetectionResult:outcome:CheckOutcome;diagnostics:t.Dict[str,t.Any];reason:t.Optional[str]=None
@dataclass(frozen=True)
class RobustEstimate:baseline:float;score:t.Optional[float];scale:float;scale_method:str;warning_lower:float;warning_upper:float;failure_lower:float;failure_upper:float
@dataclass(frozen=True)
class AnomalyTranslation:matched:bool;expectation:t.Optional[t.Dict[str,t.Any]]=None