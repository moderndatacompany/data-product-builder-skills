from __future__ import annotations
import math,statistics,typing as t
from vulcan.core.dq_types import CheckOutcome
from vulcan.core.gx.anomaly.types import RobustEstimate
_MAD_TO_SIGMA=1.4826
_IQR_TO_SIGMA=1.349
def evaluate_robust_score(current_value:float,history:t.Sequence[float],*,warning_score:float,failure_score:float,minimum_absolute_change:float,minimum_relative_change:float,warn_only:bool)->t.Tuple[CheckOutcome,RobustEstimate]:
	if not math.isfinite(float(current_value)):raise ValueError('current anomaly metric value must be finite')
	values=[float(value)for value in history];baseline=float(statistics.median(values));absolute_deviation=abs(float(current_value)-baseline);material_change=max(minimum_absolute_change,abs(baseline)*minimum_relative_change);mad=float(statistics.median(abs(value-baseline)for value in values))
	if mad>0:scale=mad*_MAD_TO_SIGMA;scale_method='mad'
	else:first_quartile,_,third_quartile=statistics.quantiles(values,n=4,method='inclusive');iqr=float(third_quartile-first_quartile);scale=iqr/_IQR_TO_SIGMA if iqr>0 else .0;scale_method='iqr'if scale>0 else'constant'
	if scale>0:
		score=absolute_deviation/scale;warning_delta=max(warning_score*scale,material_change);failure_delta=max(failure_score*scale,material_change)
		if absolute_deviation<=warning_delta:outcome=CheckOutcome.PASS
		elif absolute_deviation<=failure_delta:outcome=CheckOutcome.WARN
		else:outcome=CheckOutcome.FAIL
	else:score=.0 if absolute_deviation==0 else None;warning_delta=material_change;failure_delta=material_change;outcome=CheckOutcome.PASS if absolute_deviation<=material_change else CheckOutcome.FAIL
	if warn_only and outcome==CheckOutcome.FAIL:outcome=CheckOutcome.WARN
	return outcome,RobustEstimate(baseline=baseline,score=score,scale=scale,scale_method=scale_method,warning_lower=baseline-warning_delta,warning_upper=baseline+warning_delta,failure_lower=baseline-failure_delta,failure_upper=baseline+failure_delta)