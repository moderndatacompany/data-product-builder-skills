from __future__ import annotations
import typing as t
from pydantic import BaseModel,ConfigDict,Field,model_validator
from vulcan.core.gx.anomaly.constants import DEFAULT_FAILURE_SCORE,DEFAULT_MIN_HISTORY,DEFAULT_WARNING_SCORE,DEFAULT_WINDOW_LENGTH
class AnomalyConfig(BaseModel):
	model_config=ConfigDict(extra='forbid');window_length:int=Field(default=DEFAULT_WINDOW_LENGTH,ge=5,le=1000);min_history:int=Field(default=DEFAULT_MIN_HISTORY,ge=3,le=1000);warning_score:float=Field(default=DEFAULT_WARNING_SCORE,gt=0);failure_score:float=Field(default=DEFAULT_FAILURE_SCORE,gt=0);minimum_absolute_change:float=Field(default=.0,ge=0);minimum_relative_change:float=Field(default=.0,ge=0);warn_only:bool=False
	@model_validator(mode='after')
	def validate_thresholds(self)->'AnomalyConfig':
		if self.min_history>self.window_length:raise ValueError('min_history cannot exceed window_length')
		if self.failure_score<=self.warning_score:raise ValueError('failure_score must be greater than warning_score')
		return self
ANOMALY_CONFIG_KEYS=frozenset(AnomalyConfig.model_fields)
OBSOLETE_ANOMALY_CONFIG_KEYS=frozenset({'model','training_dataset_parameters','severity_level_parameters','take_over_existing_anomaly_score_check'})
def parse_anomaly_config(values:t.Mapping[str,t.Any])->AnomalyConfig:
	if OBSOLETE_ANOMALY_CONFIG_KEYS&set(values):raise ValueError('Prophet/Soda anomaly configuration is no longer supported; use window_length, min_history, warning_score, failure_score, minimum_absolute_change, or minimum_relative_change')
	return AnomalyConfig.model_validate({key:values[key]for key in ANOMALY_CONFIG_KEYS if key in values})