from __future__ import annotations
import typing as t
if t.TYPE_CHECKING:import pandas as pd
def historical_values(frame:'pd.DataFrame',window_length:int)->t.List[float]:current_mask=frame['_is_current'].fillna(False).astype(bool);history=frame.loc[~current_mask].sort_values('ds');values=history['y'].dropna().tail(window_length);return[float(value)for value in values]