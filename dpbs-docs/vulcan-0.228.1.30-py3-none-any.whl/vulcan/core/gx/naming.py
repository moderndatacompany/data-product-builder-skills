from __future__ import annotations
import hashlib,re,typing as t
VALID_RULE_NAME=re.compile('^[a-zA-Z][a-zA-Z0-9_]*$')
_ASSET_DIGEST_CHARS=6
def sanitize_asset_name(fqn:str)->str:stem=re.sub('[^a-z0-9_]','_',fqn.lower());digest=hashlib.md5(fqn.encode(),usedforsecurity=False).hexdigest()[:_ASSET_DIGEST_CHARS];return f"{stem}_{digest}"
def check_name_for(expectation_type:str,kwargs:t.Mapping[str,t.Any])->str:
	A='column_list';name=expectation_type.removeprefix('expect_');column=kwargs.get('column')
	if not column and isinstance(kwargs.get(A),(list,tuple)):column='_'.join(str(value)for value in kwargs[A])
	if column:name+='__'+re.sub('[^a-zA-Z0-9]+','_',str(column)).strip('_').lower()
	return name