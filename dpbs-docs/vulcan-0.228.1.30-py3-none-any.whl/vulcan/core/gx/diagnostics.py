from __future__ import annotations
_O='traceback'
_N='message'
_M='__vulcan_gx_batch__'
_L='record'
_K='reproduce_query'
_J='format'
_I=False
_H='failed_rows_sample'
_G='observed_value'
_F='result'
_E='total_failing_rows'
_D='{batch}'
_C='exception'
_B=True
_A=None
import logging,re,typing as t,sqlglot
from sqlglot import exp
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from vulcan.core.dialect import fqn_to_unquoted
from vulcan.core.gx.definitions import GxExceptionDetail,GxRuleResult
if t.TYPE_CHECKING:from vulcan.core.gx.definitions import DqExpectation,DqReferentialSpec
GX_DIAGNOSTICS_FORMAT='gx_v1'
logger=logging.getLogger(__name__)
def _qualified_column(name:str,table:str,*,quoted:bool)->exp.Column:
	identifier=exp.Identifier(this=name,quoted=quoted)
	if quoted:identifier.meta['case_sensitive']=_B
	return exp.Column(this=identifier,table=exp.Identifier(this=table))
def build_referential_unexpected_rows_query(spec:'DqReferentialSpec',*,fqn:str,dialect:str,include_catalog:bool)->str:
	A='catalog';owner=exp.to_table(fqn,dialect=dialect);target=exp.to_table(spec.target_table,dialect=dialect)
	if not target.db and owner.db:target.set('db',owner.args['db'].copy())
	if include_catalog and not target.catalog and owner.catalog:target.set(A,owner.args[A].copy())
	source_alias='src';target_alias='ref';join_condition:t.Optional[exp.Expression]=_A;source_quoted=spec.source_columns_quoted or[_I]*len(spec.source_columns);target_quoted=spec.target_columns_quoted or[_I]*len(spec.target_columns)
	for(source_column,target_column,source_is_quoted,target_is_quoted)in zip(spec.source_columns,spec.target_columns,source_quoted,target_quoted):comparison=_qualified_column(source_column,source_alias,quoted=source_is_quoted).eq(_qualified_column(target_column,target_alias,quoted=target_is_quoted));join_condition=comparison if join_condition is _A else join_condition.and_(comparison)
	source_present:t.Optional[exp.Expression]=_A
	for(source_column,source_is_quoted)in zip(spec.source_columns,source_quoted):present=_qualified_column(source_column,source_alias,quoted=source_is_quoted).is_(exp.null()).not_();source_present=present if source_present is _A else source_present.and_(present)
	target_missing=_qualified_column(spec.target_columns[0],target_alias,quoted=target_quoted[0]).is_(exp.null());placeholder=_M;query=exp.select(exp.Column(this=exp.Star(),table=exp.Identifier(this=source_alias))).from_(exp.to_table(placeholder).as_(source_alias)).join(target.as_(target_alias),on=join_condition,join_type='LEFT').where(t.cast(exp.Expression,source_present).and_(target_missing));normalize_identifiers(query,dialect=dialect);sql=query.sql(dialect=dialect,identify=_B);placeholder_table=exp.to_table(placeholder);normalize_identifiers(placeholder_table,dialect=dialect);rendered_placeholder=placeholder_table.sql(dialect=dialect,identify=_B);return sql.replace(rendered_placeholder,_D)
def gx_query_name_prefix(model_name:str,check_name:str)->str:raw=f"gx.{model_name}.{check_name}";return re.sub('[^\\w.\\-]+','_',raw)
def build_gx_reproduce_query_record(query_name_prefix:str,*,reproduce_sql:str)->t.Dict[str,t.Any]:return{'sql':reproduce_sql.strip(),'name':f"{query_name_prefix}.reproduce_sql"}
def _fqn_match_candidates(fqn:str,*,dialect:str)->t.Set[str]:
	sql_ref=fqn_to_unquoted(fqn,dialect=dialect).lower();table=exp.to_table(fqn,dialect=dialect);candidates={sql_ref}
	if table.name:candidates.add(table.name.lower())
	if table.db and table.name:candidates.add(f"{table.db}.{table.name}".lower())
	return candidates
def ensure_batch_in_unexpected_rows_query(query:str,*,fqn:str,dialect:str)->str:
	A='alias'
	if _D in query:return query
	placeholder=_M
	try:ast=sqlglot.parse_one(query,read=dialect)
	except Exception:logger.warning('[gx] Could not parse unexpected_rows_query for {batch} rewrite; GX may warn about missing batch parameter');return query
	tables=list(ast.find_all(exp.Table))
	if not tables:return query
	candidates=_fqn_match_candidates(fqn,dialect=dialect);target:t.Optional[exp.Table]=_A
	for table in tables:
		name=table.sql(dialect=dialect).replace('"','').lower();leaf=(table.name or'').lower()
		if name in candidates or leaf in candidates:target=table;break
	if target is _A:logger.warning('[gx] unexpected_rows_query does not reference owning model %s; leaving query unchanged rather than substituting an unrelated table',fqn);return query
	replacement=exp.table_(placeholder);alias=target.args.get(A)
	if alias is not _A:replacement.set(A,alias.copy())
	target.replace(replacement);rewritten=ast.sql(dialect=dialect);return rewritten.replace(f'"{placeholder}"',_D).replace(placeholder,_D)
def _batch_subquery_sql(fqn:str,filter_expr:t.Optional[str],*,dialect:str)->str:
	sql_ref=fqn_to_unquoted(fqn,dialect=dialect)
	if filter_expr and filter_expr.strip():return f"(SELECT * FROM {sql_ref} WHERE ({filter_expr.strip()}))"
	return sql_ref
def _resolve_unexpected_rows_sql(query:str,*,fqn:str,filter_expr:t.Optional[str],dialect:str)->str:batch_sql=_batch_subquery_sql(fqn,filter_expr,dialect=dialect);return query.replace(_D,batch_sql)
def resolve_reproduce_sql(expectation:'DqExpectation',result:GxRuleResult,*,fqn:str,filter_expr:t.Optional[str],dialect:str,include_catalog:bool)->t.Optional[str]:
	A='unexpected_rows_expectation';raw=result.reproduce_query
	if not raw and expectation.vulcan_referential is not _A:raw=build_referential_unexpected_rows_query(expectation.vulcan_referential,fqn=fqn,dialect=dialect,include_catalog=include_catalog)
	if not raw and expectation.expectation==A:
		unexpected_q=expectation.gx_kwargs().get('unexpected_rows_query')
		if isinstance(unexpected_q,str)and unexpected_q.strip():raw=unexpected_q.strip()
	if not raw or not str(raw).strip():return
	query=str(raw).strip()
	if expectation.expectation==A:query=ensure_batch_in_unexpected_rows_query(query,fqn=fqn,dialect=dialect)
	if _D in query:query=_resolve_unexpected_rows_sql(query,fqn=fqn,filter_expr=filter_expr,dialect=dialect)
	return query
def _exception_to_dict(exception:GxExceptionDetail)->t.Dict[str,t.Any]:
	payload:t.Dict[str,t.Any]={_N:exception.message}
	if exception.traceback:payload[_O]=exception.traceback
	return payload
def _slim_gx_v1_diagnostics(diagnostics:t.Dict[str,t.Any])->t.Dict[str,t.Any]:
	slimmed=dict(diagnostics);exception=slimmed.get(_C)
	if isinstance(exception,dict):slimmed[_C]={key:value for(key,value)in exception.items()if key!='metric_id'}
	if slimmed.get(_C)and _F in slimmed:del slimmed[_F]
	return slimmed
def build_gx_diagnostics(result:GxRuleResult,*,include_samples:bool=_B)->t.Optional[t.Dict[str,t.Any]]:
	diagnostics:t.Dict[str,t.Any]={_J:GX_DIAGNOSTICS_FORMAT};has_content=_I
	if result.observed_value is not _A:diagnostics[_G]=result.observed_value;has_content=_B
	if result.total_failing_rows is not _A:diagnostics[_E]=result.total_failing_rows;has_content=_B
	if include_samples and result.failed_rows_sample:diagnostics[_H]=[dict(row)for row in result.failed_rows_sample];has_content=_B
	if result.reproduce_query and result.reproduce_query.strip():diagnostics[_K]=result.reproduce_query.strip();has_content=_B
	if result.exception is not _A:diagnostics[_C]=_exception_to_dict(result.exception);has_content=_B
	if result.gx_result and result.exception is _A:diagnostics[_F]=result.gx_result;has_content=_B
	if not has_content:return
	return diagnostics
def _samples_from_legacy_blocks(blocks:t.Any)->t.Optional[t.List[t.Dict[str,t.Any]]]:
	if not isinstance(blocks,list):return
	for block in blocks:
		if not isinstance(block,dict)or block.get('type')!=_L:continue
		record=block.get(_L)
		if not isinstance(record,dict):continue
		samples=record.get('samples')
		if isinstance(samples,list):return[dict(row)for row in samples if isinstance(row,dict)]
def _total_failing_from_legacy_blocks(blocks:t.Any)->t.Optional[int]:
	if not isinstance(blocks,list):return
	for block in blocks:
		if not isinstance(block,dict):continue
		record=block.get(_L)
		if not isinstance(record,dict):continue
		for key in('total_row_count','totalRowCount',_E):
			value=record.get(key)
			if value is not _A:
				try:return int(value)
				except(TypeError,ValueError):continue
def normalize_diagnostics_for_api(raw:t.Any)->t.Dict[str,t.Any]:
	D='exception_traceback';C='exception_message';B='blocks';A='value'
	if not raw:return{}
	if not isinstance(raw,dict):return{}
	if raw.get(_J)==GX_DIAGNOSTICS_FORMAT:return _slim_gx_v1_diagnostics(dict(raw))
	normalized:t.Dict[str,t.Any]={_J:GX_DIAGNOSTICS_FORMAT}
	if _G in raw:normalized[_G]=raw[_G]
	elif A in raw:normalized[_G]=raw[A]
	if _E in raw:normalized[_E]=raw[_E]
	else:
		total=_total_failing_from_legacy_blocks(raw.get(B))
		if total is not _A:normalized[_E]=total
	if _H in raw:
		samples=raw[_H]
		if isinstance(samples,list):normalized[_H]=[dict(row)for row in samples if isinstance(row,dict)]
	else:
		samples=_samples_from_legacy_blocks(raw.get(B))
		if samples:normalized[_H]=samples
	reproduce=raw.get(_K)or raw.get('query')
	if isinstance(reproduce,str)and reproduce.strip():normalized[_K]=reproduce.strip()
	if isinstance(raw.get(_C),dict):normalized[_C]=dict(raw[_C])
	elif raw.get(C):
		exception:t.Dict[str,t.Any]={_N:str(raw[C])}
		if raw.get(D):exception[_O]=str(raw[D])
		normalized[_C]=exception
	gx_result=raw.get(_F)or raw.get('gx')
	if isinstance(gx_result,dict):normalized[_F]=dict(gx_result)
	if len(normalized)==1:return{}
	return _slim_gx_v1_diagnostics(normalized)