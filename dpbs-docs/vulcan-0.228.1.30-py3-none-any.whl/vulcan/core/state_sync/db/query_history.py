from __future__ import annotations
_U='created_ts'
_T='warehouse_query_id'
_S='executor'
_R='error_message'
_Q='row_count'
_P='duration_ms'
_O='status'
_N='dialect'
_M='statement_kind'
_L='fingerprint'
_K='normalized_sql'
_J='params'
_I='sql_text'
_H='component'
_G='job_type'
_F='request_id'
_E='run_id'
_D='bigint'
_C=None
_B='text'
_A=True
import json,logging,typing as t,pandas as pd
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.query.history import QueryHistoryRecord
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.utils import sortable_id
from vulcan.utils.date import now_timestamp
logger=logging.getLogger(__name__)
QUERY_HISTORY=TableSpec(name='_sql_history',primary_key=('id',),description='Append-only warehouse SQL execution log (one row per statement)',columns=(ColumnSpec('id',indexed=_A,description='Sortable ULID primary key'),ColumnSpec(_E,indexed=_A,nullable=_A,description='Links to _runs.run_id'),ColumnSpec(_F,indexed=_A,nullable=_A),ColumnSpec(_G,_B,description='PLAN, RUN, or QUERY'),ColumnSpec(_H,_B,nullable=_A,description='Emitting subsystem (DQ, PROFILE)'),ColumnSpec(_I,blob=_A,description='SQL sent to the driver; may contain bind placeholders'),ColumnSpec(_J,'jsonb',nullable=_A,description='Bound parameters when sql_text uses placeholders'),ColumnSpec(_K,blob=_A,nullable=_A,description='Canonical sqlglot-normalized SQL'),ColumnSpec(_L,indexed=_A,description='SHA-256 of normalized SQL. Excludes bound parameters, so all executions of one statement share a fingerprint'),ColumnSpec(_M,_B,nullable=_A),ColumnSpec(_N,_B),ColumnSpec(_O,_B,description='SUCCESS or FAILED'),ColumnSpec(_P,_D,nullable=_A),ColumnSpec(_Q,_D,nullable=_A),ColumnSpec(_R,blob=_A,nullable=_A),ColumnSpec(_S,_B),ColumnSpec(_T,_B,nullable=_A),ColumnSpec(_U,_D,description='Insertion time (Unix ms)')))
class QueryHistoryState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_C):self.engine_adapter=engine_adapter;self.schema=schema;dialect=engine_adapter.dialect;self.table=exp.table_(QUERY_HISTORY.name,db=schema);self._columns_to_types=QUERY_HISTORY.columns_to_types(dialect)
	def write_batch(self,records:t.Sequence[QueryHistoryRecord])->_C:
		if not records:return
		df=records_to_dataframe(records);df=df[QUERY_HISTORY.column_names()];self.engine_adapter.insert_append(self.table,df,target_columns_to_types=self._columns_to_types,track_rows_processed=False)
def records_to_dataframe(records:t.Sequence[QueryHistoryRecord])->pd.DataFrame:
	created_ts=now_timestamp();rows=[]
	for record in records:rows.append({'id':sortable_id(),_E:record.run_id,_F:record.request_id,_G:record.job_type.value,_H:record.component,_I:record.sql_text,_J:json.dumps(record.params,sort_keys=_A,separators=(',',':'))if record.params is not _C else _C,_K:record.normalized_sql,_L:record.fingerprint,_M:record.statement_kind,_N:record.dialect,_O:record.status,_P:record.duration_ms,_Q:record.row_count,_R:record.error_message,_S:record.executor,_T:record.warehouse_query_id,_U:created_ts})
	return pd.DataFrame(rows)