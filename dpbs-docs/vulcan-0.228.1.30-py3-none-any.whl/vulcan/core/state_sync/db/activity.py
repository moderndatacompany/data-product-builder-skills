from __future__ import annotations
_u='max_seq'
_t='COALESCE'
_s='count_dq_not_evaluated'
_r='count_dq_warn'
_q='count_dq_fail'
_p='count_dq_pass'
_o='count_dq_total'
_n='count_errors'
_m='count_models'
_l='run_data'
_k='total_evaluation_ms'
_j='bytes_processed'
_i='rows_affected'
_h='has_environment_changes'
_g='has_requirements_changes'
_f='count_backfills'
_e='count_metadata'
_d='count_removed'
_c='count_indirect'
_b='count_added'
_a='count_direct'
_Z='has_backfills'
_Y='has_changes'
_X='plan_diff'
_W='models_affected_metadata'
_V='models_affected_indirectly'
_U='models_affected_directly'
_T='version'
_S='prev_plan_id'
_R='git_commit_sha'
_Q='plan_seq'
_P='run_seq'
_O='models_affected'
_N='run_id'
_M='ARRAY<TEXT>'
_L='executor'
_K='created_ts_ns'
_J='start_ts'
_I='success'
_H='boolean'
_G='end_ts'
_F='plan_id'
_E='text'
_D='environment'
_C=None
_B=True
_A='bigint'
import logging,typing as t
from datetime import datetime
from sqlglot import exp
from vulcan.core.activity import PlanActivity,RunActivity
from vulcan.core.types import RunDqCounts
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.query_fingerprints import expire_query_fingerprints_by_models,fingerprint_model_lock_key
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.core.state_sync.db.utils import fetchall,fetchone,is_postgres
from vulcan.utils import get_executor
from vulcan.utils.date import to_timestamp
logger=logging.getLogger(__name__)
ACTIVITY_PLANS=TableSpec(name='_plans',primary_key=(_F,),columns=(ColumnSpec(_F,indexed=_B),ColumnSpec(_D,indexed=_B),ColumnSpec(_J,_A),ColumnSpec(_G,_A),ColumnSpec(_K,_A),ColumnSpec(_L,_E),ColumnSpec(_R,_E),ColumnSpec(_S,_E),ColumnSpec(_T,_E),ColumnSpec(_U,_M),ColumnSpec(_V,_M),ColumnSpec(_W,_M),ColumnSpec(_X,'jsonb'),ColumnSpec(_Y,_H),ColumnSpec(_Z,_H),ColumnSpec(_I,_H),ColumnSpec(_Q,_A),ColumnSpec(_a,_A),ColumnSpec(_b,_A),ColumnSpec(_c,_A),ColumnSpec(_d,_A),ColumnSpec(_e,_A),ColumnSpec(_f,_A),ColumnSpec(_g,_H),ColumnSpec(_h,_H)))
ACTIVITY_RUNS=TableSpec(name='_runs',primary_key=(_N,),columns=(ColumnSpec(_N,indexed=_B),ColumnSpec(_F,indexed=_B),ColumnSpec(_D,indexed=_B),ColumnSpec(_J,_A),ColumnSpec(_G,_A),ColumnSpec(_K,_A),ColumnSpec(_L,_E),ColumnSpec(_I,_H),ColumnSpec(_O,_M),ColumnSpec(_i,_A),ColumnSpec(_j,_A),ColumnSpec(_k,_A),ColumnSpec(_l,'jsonb'),ColumnSpec(_P,_A),ColumnSpec(_m,_A),ColumnSpec(_n,_A),ColumnSpec(_o,_A),ColumnSpec(_p,_A),ColumnSpec(_q,_A),ColumnSpec(_r,_A),ColumnSpec(_s,_A)))
ACTIVITY_LOG=TableSpec(name='_activity_log',primary_key=('id',),columns=(ColumnSpec('id',_E),ColumnSpec(_D,indexed=_B),ColumnSpec('model_name',indexed=_B,nullable=_B),ColumnSpec('event_type',indexed=_B),ColumnSpec('event_ts',_A),ColumnSpec('event_data',_E)))
class ActivityState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_C):self.engine_adapter=engine_adapter;self.schema=schema;dialect=engine_adapter.dialect;self.plans_table=exp.table_(ACTIVITY_PLANS.name,db=schema);self.runs_table=exp.table_(ACTIVITY_RUNS.name,db=schema);self.query_fingerprints=exp.table_('_query_fingerprints',db=schema);self._plan_columns_to_types=ACTIVITY_PLANS.columns_to_types(dialect);self._run_columns_to_types=ACTIVITY_RUNS.columns_to_types(dialect);self._activity_log_columns_to_types=ACTIVITY_LOG.columns_to_types(dialect)
	def store_plan_activity(self,plan_activity:PlanActivity)->_C:
		import pandas as pd,time;updated_ts_ns=time.time_ns()
		with self.engine_adapter.transaction():
			self.engine_adapter.delete_from(self.plans_table,where=exp.EQ(this=exp.column(_F),expression=exp.Literal.string(plan_activity.plan_id)));next_seq_result=fetchone(self.engine_adapter,exp.select(exp.func(_t,exp.func('MAX',exp.column(_Q)),0).as_(_u)).from_(self.plans_table).where(exp.EQ(this=exp.column(_D),expression=exp.Literal.string(plan_activity.environment))));plan_seq=(next_seq_result[0]or 0)+1 if next_seq_result else 1;diff_json=plan_activity.json();models_directly=_C;models_indirectly=_C;models_metadata=_C
			if plan_activity.models_affected_directly:models_directly=plan_activity.models_affected_directly
			if plan_activity.models_affected_indirectly:models_indirectly=plan_activity.models_affected_indirectly
			if plan_activity.models_affected_metadata:models_metadata=plan_activity.models_affected_metadata
			changes=plan_activity.changes;df=pd.DataFrame([{_F:plan_activity.plan_id,_D:plan_activity.environment,_J:int(plan_activity.start_ts),_G:int(plan_activity.end_ts),_K:updated_ts_ns,_L:plan_activity.executor,_R:plan_activity.git_commit_sha,_S:plan_activity.prev_plan_id,_T:plan_activity.version,_U:models_directly,_V:models_indirectly,_W:models_metadata,_X:diff_json,_Y:plan_activity.has_changes,_Z:bool(plan_activity.backfills),_I:plan_activity.success,_Q:plan_seq,_a:len(changes.direct),_b:len(changes.added),_c:len(changes.indirect),_d:len(changes.removed),_e:len(changes.metadata),_f:len(plan_activity.backfills),_g:plan_activity.has_requirements_changes,_h:plan_activity.has_environment_changes}]);self.engine_adapter.insert_append(self.plans_table,df,target_columns_to_types=self._plan_columns_to_types,track_rows_processed=False)
	def store_run_activity(self,run_activity:RunActivity,*,dq_counts:RunDqCounts|_C=_C)->str:
		if dq_counts is _C:dq_counts=RunDqCounts.empty()
		import pandas as pd,time;run_id=run_activity.run_id;executor=get_executor();updated_ts_ns=time.time_ns();model_names=[m.name for m in run_activity.models_affected]if run_activity.models_affected else[]
		with self.engine_adapter.transaction():
			if run_activity.success and model_names and is_postgres(self.engine_adapter):
				for model_name in sorted(set(model_names)):self.engine_adapter.fetchone(exp.select(exp.func('pg_advisory_xact_lock',exp.func('hashtextextended',exp.Literal.string(fingerprint_model_lock_key(run_activity.environment,model_name)),exp.Literal.number(0)))),ignore_unsupported_errors=_B,quote_identifiers=_B)
			self.engine_adapter.delete_from(self.runs_table,where=exp.EQ(this=exp.column(_N),expression=exp.Literal.string(run_id)));next_seq_result=fetchone(self.engine_adapter,exp.select(exp.func(_t,exp.func('MAX',exp.column(_P)),0).as_(_u)).from_(self.runs_table).where(exp.EQ(this=exp.column(_D),expression=exp.Literal.string(run_activity.environment))));run_seq=(next_seq_result[0]or 0)+1 if next_seq_result else 1;execution_json=run_activity.model_dump_json();df=pd.DataFrame([{_N:run_id,_F:run_activity.plan_id,_D:run_activity.environment,_J:int(run_activity.start_ts),_G:int(run_activity.end_ts),_K:updated_ts_ns,_L:executor,_I:run_activity.success,_O:[m.name for m in run_activity.models_affected]if run_activity.models_affected else _C,_i:run_activity.rows_affected,_j:run_activity.bytes_processed,_k:run_activity.total_evaluation_ms,_l:execution_json,_P:run_seq,_m:len(run_activity.models_affected),_n:len(run_activity.errors),_o:dq_counts.total,_p:dq_counts.passed,_q:dq_counts.failed,_r:dq_counts.warned,_s:dq_counts.not_evaluated}]);self.engine_adapter.insert_append(self.runs_table,df,target_columns_to_types=self._run_columns_to_types,track_rows_processed=False)
			if run_activity.success and model_names and is_postgres(self.engine_adapter):self._expire_query_fingerprints_by_models(model_names=model_names,run_id=run_id)
		return run_id
	def get_last_successful_run_end_ts_by_model(self,environment:str)->t.Dict[str,int]:
		query=exp.select(_O,_G).from_(self.runs_table).where(exp.and_(exp.EQ(this=exp.column(_D),expression=exp.Literal.string(environment)),exp.EQ(this=exp.column(_I),expression=exp.true())))
		try:rows=fetchall(self.engine_adapter,query)
		except Exception:logger.debug('Unable to load successful run timestamps for environment %s',environment,exc_info=_B);return{}
		result:t.Dict[str,int]={}
		for(models_affected,end_ts)in rows:
			if not models_affected or end_ts is _C:continue
			names:t.Sequence[str]
			if isinstance(models_affected,str):stripped=models_affected.strip('{}[]');names=[part.strip().strip('\'"')for part in stripped.split(',')if part.strip()]
			else:names=list(models_affected)
			ts=int(end_ts)
			for name in names:
				if not name:continue
				prev=result.get(name)
				if prev is _C or ts>prev:result[name]=ts
		return result
	def get_latest_run_success_by_model(self,environment:str)->t.Dict[str,bool]:
		query=exp.select(_O,_I,_P,_G).from_(self.runs_table).where(exp.EQ(this=exp.column(_D),expression=exp.Literal.string(environment)))
		try:rows=fetchall(self.engine_adapter,query)
		except Exception:logger.debug('Unable to load latest run outcomes for environment %s',environment,exc_info=_B);return{}
		latest:t.Dict[str,t.Tuple[t.Tuple[int,int],bool]]={}
		for(models_affected,success,run_seq,end_ts)in rows:
			if not models_affected:continue
			if isinstance(models_affected,str):stripped=models_affected.strip('{}[]');names=[part.strip().strip('\'"')for part in stripped.split(',')if part.strip()]
			else:names=list(models_affected)
			order=int(run_seq or 0),int(end_ts or 0)
			for name in names:
				if name and(name not in latest or order>latest[name][0]):latest[name]=order,bool(success)
		return{name:outcome for(name,(_,outcome))in latest.items()}
	def _expire_query_fingerprints_by_models(self,model_names:t.Union[str,t.List[str]],run_id:str)->_C:expire_query_fingerprints_by_models(self.engine_adapter,self.query_fingerprints,model_names,run_id)