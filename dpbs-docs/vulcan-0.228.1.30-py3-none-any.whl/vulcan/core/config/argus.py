from __future__ import annotations
import typing as t
from pydantic import Field,SecretStr
from vulcan.core.config.base import BaseConfig
from vulcan.utils.pydantic import model_validator
class ArgusConfig(BaseConfig):
	enabled:bool=False;url:str='';vulcan_base_url:str='';token:t.Optional[SecretStr]=Field(default=None,repr=False);verify_ssl:bool=True;timeout:int=10;health_heartbeat_interval_seconds:int=Field(default=10,ge=1)
	@model_validator(mode='after')
	def _require_fields_when_enabled(self)->'ArgusConfig':
		if self.enabled:
			if not self.url.strip():raise ValueError('argus.url is required when argus.enabled=true')
			if not self.vulcan_base_url.strip():raise ValueError('argus.vulcan_base_url is required when argus.enabled=true')
			if not self.token or not self.token.get_secret_value().strip():raise ValueError('argus.token is required when argus.enabled=true')
		return self