from __future__ import annotations
import typing as t
from vulcan.core.config.base import BaseConfig
from vulcan.utils.pydantic import field_validator
class JanitorConfig(BaseConfig):
	warn_on_delete_failure:bool=False;expired_snapshots_batch_size:t.Optional[int]=None
	@field_validator('expired_snapshots_batch_size',mode='before')
	@classmethod
	def _validate_batch_size(cls,value:int)->int:
		batch_size=int(value)
		if batch_size<=0:raise ValueError('expired_snapshots_batch_size must be greater than 0')
		return batch_size