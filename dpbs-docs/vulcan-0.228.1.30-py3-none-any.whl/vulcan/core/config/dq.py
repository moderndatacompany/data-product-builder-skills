from __future__ import annotations
import typing as t
from zoneinfo import ZoneInfo,ZoneInfoNotFoundError
from vulcan.core.config.base import BaseConfig
from vulcan.utils.pydantic import field_validator
_DEFAULT_MAX_ITEMS=20
_MAX_MAX_ITEMS=100
class DqConfig(BaseConfig):
	capture_failed_row_samples:bool=True;max_items:int=_DEFAULT_MAX_ITEMS;naive_timestamp_timezone:str='UTC'
	@field_validator('naive_timestamp_timezone')
	@classmethod
	def _validate_naive_timestamp_timezone(cls,value:str)->str:
		timezone_name=str(value).strip()
		try:ZoneInfo(timezone_name)
		except(ValueError,ZoneInfoNotFoundError)as exc:raise ValueError(f"unknown timezone: {timezone_name!r}")from exc
		return timezone_name
	@field_validator('max_items',mode='before')
	@classmethod
	def _validate_max_items(cls,value:t.Any)->int:
		if isinstance(value,bool):raise ValueError(f"max_items must be an integer, got bool: {value!r}")
		try:limit=int(value)
		except(TypeError,ValueError)as exc:raise ValueError(f"max_items must be an integer, got {value!r}")from exc
		if limit<1 or limit>_MAX_MAX_ITEMS:raise ValueError(f"max_items must be between 1 and {_MAX_MAX_ITEMS}, got {limit}")
		return limit