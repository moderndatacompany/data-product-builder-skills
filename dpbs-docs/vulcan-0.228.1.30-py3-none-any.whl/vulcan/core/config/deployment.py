from __future__ import annotations
_H='request'
_G='resource'
_F='vulcan'
_E='limits'
_D='requests'
_C='before'
_B='resources'
_A=None
import typing as t,pydantic
from pydantic import AliasChoices,Field,model_validator
from vulcan.core.config.base import BaseConfig
_PLURAL_BY_SINGULAR={_G:_B,_H:_D,'limit':_E}
def _alias(plural:str)->AliasChoices:singular=next(s for(s,p)in _PLURAL_BY_SINGULAR.items()if p==plural);return AliasChoices(plural,singular)
def _reject_both_spellings(data:t.Any,plural:str)->t.Any:
	if isinstance(data,dict):
		singular=next(s for(s,p)in _PLURAL_BY_SINGULAR.items()if p==plural)
		if plural in data and singular in data:raise ValueError(f"cannot set both `{plural}` and `{singular}`; `{singular}` is a deprecated alias for `{plural}`.")
	return data
def deprecated_resource_keys(raw_deployment:t.Mapping[str,t.Any])->t.List[str]:
	B='api';A='workflow';found:t.List[str]=[]
	def visit_block(block:t.Any,path:str)->_A:
		if not isinstance(block,dict):return
		for singular in(_H,'limit'):
			if singular in block:found.append(f"{path}.{singular}")
	def visit_owner(owner:t.Any,path:str)->_A:
		if not isinstance(owner,dict):return
		if _G in owner:found.append(f"{path}.resource");visit_block(owner[_G],f"{path}.resource")
		if _B in owner:visit_block(owner[_B],f"{path}.resources")
	visit_owner(raw_deployment.get(A),A);visit_owner(raw_deployment.get(B),B);trino=raw_deployment.get('trino')
	if isinstance(trino,dict):
		for role in('coordinator','workers'):visit_owner(trino.get(role),f"trino.{role}")
	return sorted(found)
class _DeploymentBase(BaseConfig):model_config=pydantic.ConfigDict(extra='forbid')
class RepoConfig(_DeploymentBase):url:str;base_dir:str;secret_id:t.Optional[str]=_A;sync_flags:t.List[str]=Field(default_factory=lambda:['--ref=main','--submodules=off'])
class ScheduleConfig(_DeploymentBase):end_on:t.Optional[str]=_A;timezone:str='UTC'
class CommandConfig(_DeploymentBase):command:t.List[str]=Field(default_factory=lambda:[_F]);arguments:t.List[str]=Field(default_factory=list)
class ResourceQuota(_DeploymentBase):cpu:t.Optional[str]=_A;memory:t.Optional[str]=_A
class SparkDriverQuota(_DeploymentBase):core_limit:str;cores:int;memory:str
class SparkExecutorQuota(_DeploymentBase):core_limit:str;cores:int;memory:str;instances:int
SparkResourceQuota=SparkExecutorQuota
class ComputeResource(_DeploymentBase):
	requests:t.Optional[ResourceQuota]=Field(default=_A,validation_alias=_alias(_D));limits:t.Optional[ResourceQuota]=Field(default=_A,validation_alias=_alias(_E));driver:t.Optional[SparkDriverQuota]=_A;executor:t.Optional[SparkExecutorQuota]=_A
	@model_validator(mode=_C)
	@classmethod
	def _reject_mixed_spellings(cls,data:t.Any)->t.Any:
		for plural in(_D,_E):data=_reject_both_spellings(data,plural)
		return data
	@model_validator(mode='after')
	def _validate_resource_shape(self)->'ComputeResource':
		has_generic=self.requests is not _A or self.limits is not _A;has_spark=self.driver is not _A or self.executor is not _A
		if has_generic and has_spark:raise ValueError('resources cannot mix requests/limits with driver/executor; use the generic shape (requests/limits) or the spark shape (driver/executor), not both.')
		if has_spark and not(self.driver is not _A and self.executor is not _A):raise ValueError('spark resources requires both `driver` and `executor`.')
		return self
class WorkflowConfig(_DeploymentBase):
	log_level:str='INFO';resources:t.Optional[ComputeResource]=Field(default=_A,validation_alias=_alias(_B));plan:CommandConfig=Field(default_factory=lambda:CommandConfig(command=[_F],arguments=['plan','--auto-apply']));run:CommandConfig=Field(default_factory=lambda:CommandConfig(command=[_F],arguments=['run']))
	@model_validator(mode=_C)
	@classmethod
	def _reject_mixed_spellings(cls,data:t.Any)->t.Any:return _reject_both_spellings(data,_B)
class ApiConfig(_DeploymentBase):
	replicas:int=1;log_level:str='INFO';resources:t.Optional[ComputeResource]=Field(default=_A,validation_alias=_alias(_B))
	@model_validator(mode=_C)
	@classmethod
	def _reject_mixed_spellings(cls,data:t.Any)->t.Any:return _reject_both_spellings(data,_B)
class SecretProjection(_DeploymentBase):id:str;context_alias:str
class EnvVarProjection(_DeploymentBase):key:str;template:str
class UseConfig(_DeploymentBase):secrets:t.List[SecretProjection]=Field(default_factory=list);env_vars:t.List[EnvVarProjection]=Field(default_factory=list)
class TrinoCatalog(_DeploymentBase):config:t.Optional[t.List[str]]=_A
class TrinoOverrideCatalog(_DeploymentBase):name:str;properties:t.Dict[str,t.Union[str,int,float,bool]]
class TrinoServerConfig(_DeploymentBase):jvm_config:t.Optional[str]=_A;config_properties:t.Optional[str]=_A;node_properties:t.Optional[str]=_A;log_properties:t.Optional[str]=_A
class TrinoRoleResource(_DeploymentBase):
	requests:t.Optional[ResourceQuota]=Field(default=_A,validation_alias=_alias(_D));limits:t.Optional[ResourceQuota]=Field(default=_A,validation_alias=_alias(_E))
	@model_validator(mode=_C)
	@classmethod
	def _reject_mixed_spellings(cls,data:t.Any)->t.Any:
		for plural in(_D,_E):data=_reject_both_spellings(data,plural)
		return data
class TrinoAutoscale(_DeploymentBase):min_replicas:t.Optional[int]=Field(default=_A,ge=1);max_replicas:t.Optional[int]=Field(default=_A,ge=1);cpu_target:t.Optional[int]=Field(default=_A,ge=1,le=100)
class TrinoCoordinator(_DeploymentBase):
	resources:t.Optional[TrinoRoleResource]=Field(default=_A,validation_alias=_alias(_B));trino_server_config:t.Optional[TrinoServerConfig]=_A;options:t.Optional[t.Dict[str,t.Any]]=_A
	@model_validator(mode=_C)
	@classmethod
	def _reject_mixed_spellings(cls,data:t.Any)->t.Any:return _reject_both_spellings(data,_B)
class TrinoWorkers(_DeploymentBase):
	replicas:t.Optional[int]=Field(default=_A,ge=1);resources:t.Optional[TrinoRoleResource]=Field(default=_A,validation_alias=_alias(_B));trino_server_config:t.Optional[TrinoServerConfig]=_A;autoscale:t.Optional[TrinoAutoscale]=_A;options:t.Optional[t.Dict[str,t.Any]]=_A
	@model_validator(mode=_C)
	@classmethod
	def _reject_mixed_spellings(cls,data:t.Any)->t.Any:return _reject_both_spellings(data,_B)
class TrinoConfig(_DeploymentBase):catalog:t.Optional[TrinoCatalog]=_A;overide_catalog_config:t.Optional[t.List[TrinoOverrideCatalog]]=_A;coordinator:t.Optional[TrinoCoordinator]=_A;workers:t.Optional[TrinoWorkers]=_A
class DeploymentConfig(_DeploymentBase):type:str=_F;repo:RepoConfig;compute:str;run_as_user:str;engine:t.Optional[str]=_A;state_store_connection:t.Optional[str]=_A;object_store_connection:t.Optional[str]=_A;depots:t.Optional[t.List[str]]=_A;schedule:ScheduleConfig=Field(default_factory=ScheduleConfig);workflow:WorkflowConfig=Field(default_factory=WorkflowConfig);api:ApiConfig=Field(default_factory=ApiConfig);use:t.Optional[UseConfig]=_A;spark_conf:t.Optional[t.Dict[str,t.Any]]=_A;trino:t.Optional[TrinoConfig]=_A