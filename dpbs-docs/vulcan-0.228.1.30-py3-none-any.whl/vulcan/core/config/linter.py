from __future__ import annotations
import typing as t
from sqlglot import exp
from sqlglot.helper import ensure_collection
from vulcan.core.config.base import BaseConfig
from vulcan.utils.pydantic import field_validator
class LinterConfig(BaseConfig):
	enabled:bool=False;rules:t.Set[str]=set();warn_rules:t.Set[str]=set();ignored_rules:t.Set[str]=set()
	@classmethod
	def _validate_rules(cls,v:t.Any)->t.Set[str]:
		if isinstance(v,exp.Paren):v=v.unnest().name
		elif isinstance(v,(exp.Tuple,exp.Array)):v=[e.name for e in v.expressions]
		elif isinstance(v,exp.Expression):v=v.name
		return{name.lower()for name in ensure_collection(v)}
	@field_validator('rules','warn_rules','ignored_rules',mode='before')
	def rules_validator(cls,vs:t.Any)->t.Set[str]:return cls._validate_rules(vs)