from __future__ import annotations
_d='https://vulcan.local'
_c='# Concepts'
_b='# Description'
_a='Semantic Model'
_Z='member'
_Y='product'
_X='folder_index'
_W='root_index'
_V='METRIC'
_U='SEMANTIC'
_T='# Definition'
_S='Table'
_R='View'
_Q='Metric'
_P='model'
_O='stale_after'
_N='verified'
_M='resource'
_L='generated'
_K='tags'
_J='status'
_I='description'
_H='title'
_G='type'
_F='segment'
_E='dimension'
_D=False
_C='measure'
_B=None
_A='\n'
import io,re,tarfile,typing as t,zipfile
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime,timezone
import yaml
from schema.metadata import ColumnEntry,DimensionDetails,Metadata,MeasureDetails,ModelEntry,SegmentDetails
from schema.types import AiContextExampleSpec,AiContextSpec,DimensionBehaviorSpec,MeasureBehaviorSpec
OKF_VERSION='0.2'
_ROOT_MODELS='models'
_ROOT_SEMANTICS='semantics'
_ROOT_METRICS='metrics'
_BUNDLE_ROOTS:t.Tuple[str,...]=(_ROOT_MODELS,_ROOT_SEMANTICS,_ROOT_METRICS)
_MEMBER_FOLDER:t.Dict[str,str]={_C:'measures',_E:'dimensions',_F:'segments'}
_MEMBER_TYPE:t.Dict[str,str]={_C:'Measure',_E:'Dimension',_F:'Segment'}
_FRONTMATTER_KEY_ORDER:t.Tuple[str,...]=(_G,_H,_I,_M,_J,_K,_L,_N,_O)
_BRACE_REF_RE=re.compile('\\{([^{}]+)\\}')
@dataclass(frozen=True)
class _ConceptRef:path:str;title:str
def _include_model(entry:ModelEntry)->bool:
	if entry.kind=='EMBEDDED':return _D
	if entry.source_type=='rollup':return _D
	return True
def _root_for_entry(entry:ModelEntry)->str:
	if entry.kind==_U:return _ROOT_SEMANTICS
	if entry.kind==_V:return _ROOT_METRICS
	return _ROOT_MODELS
def concept_path(kind:str,fqn:str='',member_kind:t.Optional[str]=_B,member_name:t.Optional[str]=_B,*,root:str=_ROOT_MODELS)->str:
	if kind==_W:return'/index.md'
	if kind==_X:
		if root not in _BUNDLE_ROOTS:raise ValueError(f"concept_path root must be one of {_BUNDLE_ROOTS}, got {root!r}")
		return f"/{root}/index.md"
	if kind==_Y:return'/product.md'
	if kind==_P:
		if not fqn:raise ValueError("concept_path(kind='model') requires fqn")
		if root not in _BUNDLE_ROOTS:raise ValueError(f"concept_path root must be one of {_BUNDLE_ROOTS}, got {root!r}")
		return f"/{root}/{fqn}/index.md"
	if kind==_Z:
		if not fqn or not member_kind or not member_name:raise ValueError("concept_path(kind='member') requires fqn, member_kind, and member_name")
		if root not in _BUNDLE_ROOTS:raise ValueError(f"concept_path root must be one of {_BUNDLE_ROOTS}, got {root!r}")
		return f"/{root}/{fqn}/{member_kind}/{member_name}.md"
	raise ValueError(f"unknown concept_path kind: {kind!r}")
def _title_for(name:str)->str:return name.replace('_',' ').title()
def _dedup_tags(tags:t.Sequence[str],terms:t.Sequence[str])->t.List[str]:
	seen:t.Set[str]=set();out:t.List[str]=[]
	for tag in(*tags,*terms):
		if tag in seen:continue
		seen.add(tag);out.append(tag)
	return out
def _concept_type(entry:ModelEntry)->str:
	if entry.kind==_U:return _a
	if entry.kind==_V:return _Q
	if entry.kind=='VIEW':return _R
	return _S
def _status_for(metadata:Metadata)->str:return'stable'if metadata.product.status=='Active'else'draft'
def _verified_field(model_name:str,last_run_ts_by_model:t.Dict[str,int])->t.Optional[t.List[t.Dict[str,str]]]:
	ts=last_run_ts_by_model.get(model_name)
	if ts is _B:return
	at=datetime.fromtimestamp(ts/1000,tz=timezone.utc).isoformat();return[{'by':'process:vulcan-scheduler','at':at}]
def _stale_after_for(model_name:str,metadata:Metadata)->t.Optional[str]:
	nominal=metadata.nominal_runs.get(model_name)
	if nominal is _B or nominal.next is _B:return
	return nominal.next.strftime('%Y-%m-%d')
def _render_frontmatter(fields:t.Mapping[str,t.Any])->str:payload={key:fields[key]for key in _FRONTMATTER_KEY_ORDER if fields.get(key)not in(_B,[],'')};rendered=yaml.safe_dump(payload,sort_keys=_D,allow_unicode=True,default_flow_style=_D);return f"---\n{rendered}---\n"
def _render_concept(fields:t.Mapping[str,t.Any],body:str)->str:return f"{_render_frontmatter(fields)}\n{body}"
def _build_registries(metadata:Metadata)->t.Tuple[_ConceptRef,t.Dict[str,_ConceptRef],t.Dict[t.Tuple[str,str],_ConceptRef]]:
	product_ref=_ConceptRef(path=concept_path(_Y),title=_title_for(metadata.name));model_refs:t.Dict[str,_ConceptRef]={};member_refs:t.Dict[t.Tuple[str,str],_ConceptRef]={}
	for entry in metadata.models:
		if not _include_model(entry):continue
		root=_root_for_entry(entry);model_refs[entry.name]=_ConceptRef(path=concept_path(_P,entry.name,root=root),title=_title_for(entry.name))
		for column in entry.columns:
			member_kind=_MEMBER_FOLDER.get(column.kind)
			if member_kind is _B:continue
			member_refs[entry.name,column.name]=_ConceptRef(path=concept_path(_Z,entry.name,member_kind,column.name,root=root),title=_title_for(column.name))
	return product_ref,model_refs,member_refs
def _split_model_qualified(ref:str,model_refs:t.Mapping[str,_ConceptRef])->t.Tuple[str,str]:
	A='.';parts=ref.split(A)
	if len(parts)<2:return'',ref
	for i in range(len(parts)-1,0,-1):
		candidate=A.join(parts[:i])
		if candidate in model_refs:return candidate,A.join(parts[i:])
	return parts[0],A.join(parts[1:])
def _link_to_model(model_name:str,model_refs:t.Mapping[str,_ConceptRef])->str:
	ref=model_refs.get(model_name)
	if ref is not _B:return f"[{ref.title}]({ref.path})"
	return f"[{_title_for(model_name)}]({concept_path(_P,model_name,root=_ROOT_MODELS)})"
def _link_to_member(model_name:str,column_name:t.Optional[str],model_refs:t.Mapping[str,_ConceptRef],member_refs:t.Mapping[t.Tuple[str,str],_ConceptRef])->str:
	if column_name is not _B:
		ref=member_refs.get((model_name,column_name))
		if ref is not _B:return f"[{ref.title}]({ref.path})"
	return _link_to_model(model_name,model_refs)
def _resolve_brace_refs(text:str,model_refs:t.Mapping[str,_ConceptRef],member_refs:t.Mapping[t.Tuple[str,str],_ConceptRef])->str:
	def _replace(match:'re.Match[str]')->str:
		model_name,field=_split_model_qualified(match.group(1),model_refs)
		if not model_name:return match.group(0)
		return _link_to_member(model_name,field,model_refs,member_refs)
	return _BRACE_REF_RE.sub(_replace,text)
def _link_measure_refs(owning_model:str,refs:t.Sequence[str],model_refs:t.Mapping[str,_ConceptRef],member_refs:t.Mapping[t.Tuple[str,str],_ConceptRef])->t.List[str]:
	links=[]
	for ref in refs:
		model_name,field=_split_model_qualified(ref,model_refs)
		if not model_name:model_name,field=owning_model,ref
		links.append(_link_to_member(model_name,field,model_refs,member_refs))
	return links
def _owning_model_for_measure_refs(entry:ModelEntry,column:ColumnEntry)->str:
	if entry.source_type=='metric'and column.depends_on:return column.depends_on[0].model
	return entry.name
def _render_ai_notes(ai:t.Optional[AiContextSpec])->t.List[str]:
	if ai is _B:return[]
	lines:t.List[str]=[]
	if ai.instructions:instructions=ai.instructions if isinstance(ai.instructions,list)else[ai.instructions];lines.extend(f"- {instruction}"for instruction in instructions);lines.append('')
	if ai.synonyms:lines.append(f"Also known as: {', '.join(ai.synonyms)}");lines.append('')
	if ai.caveats:lines.append('Caveats:');lines.extend(f"* {caveat}"for caveat in ai.caveats);lines.append('')
	return lines
def _render_examples(examples:t.Sequence[AiContextExampleSpec])->t.List[str]:
	if not examples:return[]
	lines=['# Examples','']
	for example in examples:lines.append(example.description);lines.append('');lines.append(f"```{example.format}");lines.append(example.query);lines.append('```');lines.append('')
	return lines
def _render_model_body(entry:ModelEntry,concept_type:str,model_refs:t.Mapping[str,_ConceptRef],member_refs:t.Mapping[t.Tuple[str,str],_ConceptRef])->str:
	A='physical';lines:t.List[str]=[_b,'']
	if entry.description:lines.append(entry.description);lines.append('')
	ai=entry.ai_context
	if not entry.description and not(ai and ai.instructions):lines.append(f"{_title_for(entry.name)} {concept_type.lower()}.");lines.append('')
	if concept_type==_Q:
		measure_column=next((c for c in entry.columns if c.kind==_C),_B)
		if measure_column and measure_column.depends_on:dep=measure_column.depends_on[0];wrapped=_link_to_member(dep.model,dep.column,model_refs,member_refs);lines.append(f"Wraps measure {wrapped}.");lines.append('')
	lines.extend(_render_ai_notes(ai))
	if entry.depends_on:lines.append('# Depends On');lines.append('');lines.extend(f"* {_link_to_model(dep,model_refs)}"for dep in entry.depends_on);lines.append('')
	members_by_kind:t.Dict[str,t.List[ColumnEntry]]=defaultdict(list)
	for column in entry.columns:
		if column.kind!=A:members_by_kind[column.kind].append(column)
	for(kind,heading)in((_C,'# Measures'),(_E,'# Dimensions'),(_F,'# Segments')):
		columns=members_by_kind.get(kind)
		if not columns:continue
		lines.append(heading);lines.append('')
		for column in columns:ref=member_refs[entry.name,column.name];desc=f" - {column.description}"if column.description else'';lines.append(f"* [{ref.title}]({ref.path}){desc}")
		lines.append('')
	if entry.joins:
		lines.append('# Joins');lines.append('')
		for join in entry.joins:target=_link_to_model(join.model,model_refs);expression=_resolve_brace_refs(join.expression,model_refs,member_refs);lines.append(f"* {target} ({join.relationship}): {expression}")
		lines.append('')
	if ai:lines.extend(_render_examples(ai.examples))
	if concept_type in(_S,_R,'Rollup'):
		physical_columns=[c for c in entry.columns if c.kind==A]
		if physical_columns:
			lines.append('# Schema');lines.append('');lines.append('| Column | Type | Description |');lines.append('|---|---|---|')
			for column in physical_columns:lines.append(f"| {column.name} | {column.dtype} | {column.description or''} |")
			lines.append('')
	return _A.join(lines).rstrip(_A)+_A
def _render_measure_body(entry:ModelEntry,column:ColumnEntry,model_ref:_ConceptRef,model_refs:t.Mapping[str,_ConceptRef],member_refs:t.Mapping[t.Tuple[str,str],_ConceptRef])->str:
	lines=[f"Part of [{model_ref.title}]({model_ref.path}).",'',_T,''];details=column.details
	if isinstance(details,MeasureDetails):
		lines.append(f"Aggregation: `{details.agg_type}`");lines.append('')
		if details.expression:expression=_resolve_brace_refs(details.expression,model_refs,member_refs);lines.append(f"Expression: {expression}");lines.append('')
		if details.filters:lines.append('Row filters:');lines.extend(f"* {_resolve_brace_refs(f,model_refs,member_refs)}"for f in details.filters);lines.append('')
	behavior=column.behavior
	if isinstance(behavior,MeasureBehaviorSpec):
		detail_bits:t.List[str]=[]
		if behavior.time_dimension:detail_bits.append(f"* time dimension: {behavior.time_dimension}")
		if behavior.period_treatment:detail_bits.append(f"* period treatment: {behavior.period_treatment}")
		if behavior.period_grain:detail_bits.append(f"* period grain: {behavior.period_grain}")
		if behavior.measure_refs:owning_model=_owning_model_for_measure_refs(entry,column);links=_link_measure_refs(owning_model,behavior.measure_refs,model_refs,member_refs);detail_bits.append(f"* composed of: {', '.join(links)}")
		lines.append(f"Behavior: `{behavior.type}`");lines.append('')
		if detail_bits:lines.extend(detail_bits);lines.append('')
	if column.depends_on:
		lines.append('Sourced from:')
		for dep in column.depends_on:
			link=_link_to_member(dep.model,dep.column,model_refs,member_refs)
			if dep.expression:dep_expr=_resolve_brace_refs(dep.expression,model_refs,member_refs);lines.append(f"* {link}: {dep_expr}")
			else:lines.append(f"* {link}")
		lines.append('')
	if column.description:lines.append(column.description);lines.append('')
	lines.extend(_render_ai_notes(column.ai_context))
	if column.ai_context:lines.extend(_render_examples(column.ai_context.examples))
	return _A.join(lines).rstrip(_A)+_A
def _render_dimension_body(entry:ModelEntry,column:ColumnEntry,model_ref:_ConceptRef,model_refs:t.Mapping[str,_ConceptRef],member_refs:t.Mapping[t.Tuple[str,str],_ConceptRef])->str:
	lines=[f"Part of [{model_ref.title}]({model_ref.path}).",'',_T,'']
	if column.depends_on:dep=column.depends_on[0];source=_link_to_member(dep.model,dep.column,model_refs,member_refs);lines.append(f"Sourced from {source}.");lines.append('')
	behavior=column.behavior
	if isinstance(behavior,DimensionBehaviorSpec):lines.append(f"Behavior: `{behavior.type}`");lines.append('')
	details=column.details
	if isinstance(details,DimensionDetails)and details.mask_expression:lines.append('This dimension is masked (contains sensitive data).');lines.append('')
	if column.description:lines.append(column.description);lines.append('')
	lines.extend(_render_ai_notes(column.ai_context))
	if column.ai_context:lines.extend(_render_examples(column.ai_context.examples))
	return _A.join(lines).rstrip(_A)+_A
def _render_segment_body(entry:ModelEntry,column:ColumnEntry,model_ref:_ConceptRef,model_refs:t.Mapping[str,_ConceptRef],member_refs:t.Mapping[t.Tuple[str,str],_ConceptRef])->str:
	lines=[f"Part of [{model_ref.title}]({model_ref.path}).",'',_T,''];details=column.details
	if isinstance(details,SegmentDetails)and details.expression:lines.append(_resolve_brace_refs(details.expression,model_refs,member_refs));lines.append('')
	if column.description:lines.append(column.description);lines.append('')
	lines.extend(_render_ai_notes(column.ai_context))
	if column.ai_context:lines.extend(_render_examples(column.ai_context.examples))
	return _A.join(lines).rstrip(_A)+_A
_MEMBER_BODY_RENDERERS:t.Dict[str,t.Callable[[ModelEntry,ColumnEntry,_ConceptRef,t.Mapping[str,_ConceptRef],t.Mapping[t.Tuple[str,str],_ConceptRef]],str]]={_C:_render_measure_body,_E:_render_dimension_body,_F:_render_segment_body}
_CONCEPT_TYPE_ORDER:t.Tuple[str,...]=(_a,_Q,_S,_R)
_FOLDER_HEADINGS:t.Dict[str,str]={_ROOT_SEMANTICS:'Semantics',_ROOT_METRICS:'Metrics',_ROOT_MODELS:'Models'}
def _model_bullet_groups(metadata:Metadata,model_refs:t.Mapping[str,_ConceptRef],*,root:t.Optional[str]=_B)->t.List[str]:
	by_type:t.Dict[str,t.List[str]]=defaultdict(list)
	for entry in sorted(metadata.models,key=lambda m:m.name):
		ref=model_refs.get(entry.name)
		if ref is _B:continue
		if root is not _B and _root_for_entry(entry)!=root:continue
		concept_type=_concept_type(entry);desc=f" - {entry.description}"if entry.description else'';by_type[concept_type].append(f"* [{ref.title}]({ref.path}){desc}")
	lines:t.List[str]=[]
	for concept_type in _CONCEPT_TYPE_ORDER:
		bullets=by_type.get(concept_type)
		if not bullets:continue
		lines.append(f"## {concept_type}");lines.append('');lines.extend(bullets);lines.append('')
	return lines
def _render_product_body(metadata:Metadata,model_refs:t.Mapping[str,_ConceptRef])->str:
	lines=[_b,'']
	if metadata.product.description:lines.append(metadata.product.description);lines.append('')
	lines.append(_c);lines.append('');lines.extend(_model_bullet_groups(metadata,model_refs));return _A.join(lines).rstrip(_A)+_A
def _render_root_index(metadata:Metadata,product_ref:_ConceptRef,model_refs:t.Mapping[str,_ConceptRef])->str:frontmatter=yaml.safe_dump({'okf_version':OKF_VERSION},sort_keys=_D);lines=['# Product','',f"* [{product_ref.title}]({product_ref.path})",'',_c,'',*_model_bullet_groups(metadata,model_refs)];body=_A.join(lines).rstrip(_A)+_A;return f"---\n{frontmatter}---\n\n{body}"
def _render_folder_index(root:str,metadata:Metadata,model_refs:t.Mapping[str,_ConceptRef])->str:heading=_FOLDER_HEADINGS[root];lines=[f"# {heading}",'',*_model_bullet_groups(metadata,model_refs,root=root)];return _A.join(lines).rstrip(_A)+_A
def _generated_field(owner:t.Optional[str],at:datetime)->t.Optional[t.Dict[str,str]]:
	if not owner:return
	return{'by':f"human:{owner}",'at':at.isoformat()}
def _model_frontmatter(entry:ModelEntry,concept_type:str,metadata:Metadata,last_run_ts_by_model:t.Dict[str,int],base_url:str='')->t.Dict[str,t.Any]:origin=base_url or _d;return{_G:concept_type,_H:_title_for(entry.name),_I:entry.description,_M:f"{origin}/api/v1/models/{entry.name}",_J:_status_for(metadata),_K:_dedup_tags(entry.tags,entry.terms),_L:_generated_field(entry.owner,entry.changed_at or metadata.as_of),_N:_verified_field(entry.name,last_run_ts_by_model),_O:_stale_after_for(entry.name,metadata)}
def _member_frontmatter(entry:ModelEntry,column:ColumnEntry,concept_type:str,metadata:Metadata,last_run_ts_by_model:t.Dict[str,int])->t.Dict[str,t.Any]:return{_G:concept_type,_H:_title_for(column.name),_I:column.description,_J:_status_for(metadata),_K:_dedup_tags(column.tags,column.terms),_L:_generated_field(entry.owner,entry.changed_at or metadata.as_of),_N:_verified_field(entry.name,last_run_ts_by_model),_O:_stale_after_for(entry.name,metadata)}
def _product_frontmatter(metadata:Metadata,base_url:str='')->t.Dict[str,t.Any]:origin=base_url or _d;product=metadata.product;owner=product.users[0].username if product.users else _B;return{_G:'Data Product',_H:_title_for(metadata.name),_I:product.description,_M:f"{origin}/api/v1/metadata",_J:_status_for(metadata),_K:_dedup_tags(product.tags,product.terms),_L:_generated_field(owner,metadata.as_of)}
def build_okf_archive(bundle:t.Dict[str,str],archive_format:str)->bytes:
	if archive_format=='zip':
		buf=io.BytesIO()
		with zipfile.ZipFile(buf,mode='w',compression=zipfile.ZIP_DEFLATED)as archive:
			for(path,content)in bundle.items():archive.writestr(path.lstrip('/'),content)
		return buf.getvalue()
	if archive_format=='tar.gz':
		buf=io.BytesIO()
		with tarfile.open(fileobj=buf,mode='w:gz')as archive:
			for(path,content)in bundle.items():data=content.encode('utf-8');info=tarfile.TarInfo(name=path.lstrip('/'));info.size=len(data);archive.addfile(info,io.BytesIO(data))
		return buf.getvalue()
	raise ValueError(f"unsupported archive format: {archive_format!r}; expected 'tar.gz' or 'zip'")
def build_okf(metadata:Metadata,last_run_ts_by_model:t.Dict[str,int],base_url:str='')->t.Dict[str,str]:
	product_ref,model_refs,member_refs=_build_registries(metadata);bundle:t.Dict[str,str]={};bundle[concept_path(_W)]=_render_root_index(metadata,product_ref,model_refs);bundle[product_ref.path]=_render_concept(_product_frontmatter(metadata,base_url=base_url),_render_product_body(metadata,model_refs));roots_present={_root_for_entry(e)for e in metadata.models if _include_model(e)}
	for root in _BUNDLE_ROOTS:
		if root not in roots_present:continue
		bundle[concept_path(_X,root=root)]=_render_folder_index(root,metadata,model_refs)
	for entry in metadata.models:
		if not _include_model(entry):continue
		concept_type=_concept_type(entry);model_ref=model_refs[entry.name];bundle[model_ref.path]=_render_concept(_model_frontmatter(entry,concept_type,metadata,last_run_ts_by_model,base_url=base_url),_render_model_body(entry,concept_type,model_refs,member_refs))
		for column in entry.columns:
			renderer=_MEMBER_BODY_RENDERERS.get(column.kind)
			if renderer is _B:continue
			member_type=_MEMBER_TYPE[column.kind];member_path=member_refs[entry.name,column.name].path;bundle[member_path]=_render_concept(_member_frontmatter(entry,column,member_type,metadata,last_run_ts_by_model),renderer(entry,column,model_ref,model_refs,member_refs))
	return bundle