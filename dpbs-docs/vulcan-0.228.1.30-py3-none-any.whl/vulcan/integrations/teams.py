from __future__ import annotations
_B='type'
_A=True
import typing as t
from textwrap import dedent
from vulcan.core.notification.events import ApplyFailurePayload,AuditFailurePayload,MigrationFailurePayload,NotificationEvent,NotificationPayload,NotificationStatus,PlanChangePayload,RunFailurePayload
from vulcan.core.notification.formatting import context_facts
TEAMS_MAX_TEXT_LENGTH=3000
CONTINUATION_SYMBOL='...'
def normalize_text(message:str,*,max_length:int=TEAMS_MAX_TEXT_LENGTH)->str:
	dedented=dedent(message).strip()
	if len(dedented)<=max_length:return dedented
	return dedented[:max_length-len(CONTINUATION_SYMBOL)-3]+CONTINUATION_SYMBOL+dedented[-3:]
def _text_block(text:str,*,size:t.Optional[str]=None,weight:t.Optional[str]=None,wrap:bool=False,font_type:t.Optional[str]=None)->dict[str,t.Any]:
	block:dict[str,t.Any]={_B:'TextBlock','text':normalize_text(text)}
	if size:block['size']=size
	if weight:block['weight']=weight
	if wrap:block['wrap']=_A
	if font_type:block['fontType']=font_type
	return block
def _fact_set_block(facts:list[tuple[str,str]])->dict[str,t.Any]:return{_B:'FactSet','facts':[{'title':title,'value':value}for(title,value)in facts]}
def _status_prefix(status:NotificationStatus)->str:icons={NotificationStatus.PROGRESS:'⏳',NotificationStatus.SUCCESS:'✅',NotificationStatus.FAILURE:'❌',NotificationStatus.WARNING:'⚠️',NotificationStatus.INFO:'ℹ️'};return icons.get(status,'')
def _body_blocks(msg:str,payload:NotificationPayload)->list[dict[str,t.Any]]:
	A='Monospace';blocks:list[dict[str,t.Any]]=[]
	if(facts:=context_facts(payload)):blocks.append(_fact_set_block(facts))
	if isinstance(payload,PlanChangePayload):
		warning_lines=[line.strip()for line in msg.splitlines()if line.strip().startswith('[WARNING]')or line.strip().startswith('[INFO]')]
		if warning_lines:blocks.append(_text_block('\n'.join(warning_lines),wrap=_A))
		return blocks
	if isinstance(payload,(RunFailurePayload,ApplyFailurePayload,MigrationFailurePayload)):blocks.extend([_text_block(msg,wrap=_A),_text_block(payload.exc,wrap=_A,font_type=A)]);return blocks
	if isinstance(payload,AuditFailurePayload):
		blocks.append(_text_block(msg,wrap=_A))
		if payload.audit_sql:blocks.append(_text_block(payload.audit_sql,wrap=_A,font_type=A))
		return blocks
	blocks.append(_text_block(msg,wrap=_A));return blocks
def build_notification_message(*,status:NotificationStatus,msg:str,event:NotificationEvent,payload:NotificationPayload)->dict[str,t.Any]:header=f"{_status_prefix(status)} {event.value}".strip();return{_B:'message','attachments':[{'contentType':'application/vnd.microsoft.card.adaptive','content':{'$schema':'http://adaptivecards.io/schemas/adaptive-card.json',_B:'AdaptiveCard','version':'1.4','body':[_text_block(header,size='Medium',weight='Bolder'),*_body_blocks(msg,payload)]}}]}