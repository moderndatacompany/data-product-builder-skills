_A=None
import typing as t,click
from datetime import datetime,timedelta,timezone
from pydantic import ValidationError
from sqlglot import exp,parse_one
from vulcan.core.config.connection import parse_connection_config
from vulcan.core.context import Context
from vulcan.utils.date import yesterday_ds
def generate_dlt_models_and_settings(pipeline_name:str,dialect:str,tables:t.Optional[t.List[str]]=_A,dlt_path:t.Optional[str]=_A)->t.Tuple[t.Set[t.Tuple[str,str]],t.Optional[str],str]:
	A='name';import dlt;from dlt.common.schema.utils import has_table_seen_data,is_complete_column;from dlt.pipeline.exceptions import CannotRestorePipelineException
	try:pipeline=dlt.attach(pipeline_name=pipeline_name,pipelines_dir=dlt_path or'')
	except CannotRestorePipelineException:raise click.ClickException(f"Could not attach to pipeline {pipeline_name}")
	schema=pipeline.default_schema;dataset=pipeline.dataset_name;storage_ids=list(pipeline._get_load_storage().list_loaded_packages());start_date=get_start_date(storage_ids);db_type=pipeline.destination.to_name(pipeline.destination)
	if db_type=='filesystem':connection_config=_A
	else:
		if dlt.__version__>='1.10.0':client=pipeline.destination_client()
		else:client=pipeline._sql_job_client(schema)
		config=client.config;credentials=config.credentials;configs={key:value for key in dir(credentials)if not key.startswith('_')and not callable((value:=getattr(credentials,key)))and value is not _A};connection_config=format_config(configs,db_type)
	dlt_tables={name:table for(name,table)in schema.tables.items()if(has_table_seen_data(table)and not name.startswith(schema._dlt_tables_prefix)or name==schema.loads_table_name)and(name in tables if tables else True)};vulcan_models=set()
	for(table_name,table)in dlt_tables.items():
		dlt_columns={};primary_key=[]
		for col in filter(is_complete_column,table['columns'].values()):
			dlt_columns[col[A]]=exp.DataType.build(str(col['data_type']),dialect=dialect)
			if col.get('primary_key'):primary_key.append(str(col[A]))
		load_id=next((col for col in['_dlt_load_id','load_id']if col in dlt_columns),_A);load_key='c.'+load_id if load_id else'';parent_table=_A
		if not load_id:
			if'_dlt_parent_id'in dlt_columns and(parent_table:=table['parent'])and parent_table in dlt_tables:load_key='p._dlt_load_id';parent_table=dataset+'.'+parent_table
			else:break
		column_types=[exp.cast(exp.column(column,table='c'),data_type,dialect=dialect).as_(column).sql(dialect=dialect)for(column,data_type)in dlt_columns.items()if isinstance(column,str)];select_columns=',\n'.join(f"  {column_name}"for column_name in column_types)if column_types else'';grain=f"\n  grain ({', '.join(primary_key)}),"if primary_key else'';incremental_model_name=f"{dataset}_vulcan.incremental_{table_name}";incremental_model_sql=generate_incremental_model(incremental_model_name,select_columns,grain,dataset+'.'+table_name,dialect,load_key,parent_table);vulcan_models.add((incremental_model_name,incremental_model_sql))
	return vulcan_models,connection_config,start_date
def generate_dlt_models(context:Context,pipeline_name:str,tables:t.List[str],force:bool,dlt_path:t.Optional[str]=_A)->t.List[str]:
	from vulcan.cli.project_init import _create_object_files;vulcan_models,_,_=generate_dlt_models_and_settings(pipeline_name=pipeline_name,dialect=context.config.dialect or'',tables=tables if tables else _A,dlt_path=dlt_path)
	if not tables and not force:existing_models=[m.name for m in context.models.values()];vulcan_models={model for model in vulcan_models if model[0]not in existing_models}
	if vulcan_models:_create_object_files(context.path/'models',{model[0].split('.')[-1]:model[1]for model in vulcan_models},'sql');return[model[0]for model in vulcan_models]
	return[]
def generate_incremental_model(model_name:str,select_columns:str,grain:str,from_table:str,dialect:str,load_id:str,parent_table:t.Optional[str]=_A)->str:
	time_column=parse_one(f"to_timestamp(CAST({load_id} AS DOUBLE))").sql(dialect=dialect);from_clause=f"{from_table} as c"
	if parent_table:from_clause+=f"\nJOIN\n  {parent_table} as p\nON\n  c._dlt_parent_id = p._dlt_id"
	return f"""MODEL (
  name {model_name},
  kind INCREMENTAL_BY_TIME_RANGE (
    time_column _dlt_load_time,
  ),{grain}
);

SELECT
{select_columns},
  {time_column} as _dlt_load_time
FROM
  {from_clause}
WHERE
  {time_column} BETWEEN @start_ds AND @end_ds
"""
def format_config(configs:t.Dict[str,str],db_type:str)->str:
	config={'type':db_type}
	for(key,value)in configs.items():
		if key=='password':config[key]=f'"{value}"'
		elif key=='username':config['user']=value
		else:config[key]=value
	invalid_fields=[]
	try:parse_connection_config(config)
	except ValidationError as e:
		for error in e.errors():invalid_fields.append(error.get('loc',[])[0])
	return'\n'.join([f"      {key}: {value}"for(key,value)in config.items()if key not in invalid_fields])
def get_start_date(load_ids:t.List[str])->str:
	timestamps=[datetime.fromtimestamp(float(id),tz=timezone.utc)for id in load_ids]
	if timestamps:start_timestamp=min(timestamps)-timedelta(days=1);return start_timestamp.strftime('%Y-%m-%d')
	return yesterday_ds()