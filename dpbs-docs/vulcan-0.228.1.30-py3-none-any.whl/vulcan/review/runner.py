from __future__ import annotations
_A=None
import logging,typing as t
from pathlib import Path
from vulcan.review.evidence import ReviewEvidence
from vulcan.review.governance import policy_issues
from vulcan.review.metadata import try_deterministic_issues
from vulcan.review.orchestration.coordinator import run_project_review
from vulcan.review.preconditions import PreconditionFailure,check_preconditions
from vulcan.review.report import save_report
from vulcan.review.schemas import DimensionFailure,ReportArtifacts,ReportFormat,ReviewCoverage,ReviewReport,ReviewStatus
from vulcan.review.utils.progress import StageCallback,reset_stage_callback,stage_callback_context
logger=logging.getLogger(__name__)
REVIEW_DIR=Path('.vulcan')/'reviews'
def _blocked_report(project_name:str,source:str,blocked:PreconditionFailure)->ReviewReport:return ReviewReport(project_name=project_name,source=source,status=ReviewStatus.PARTIAL,coverage=ReviewCoverage(failures=[DimensionFailure(detail=f"{blocked.reason} {blocked.detail}")]))
if t.TYPE_CHECKING:from vulcan.core.context import Context
def run_review_from_context(context:Context,*,environment:t.Optional[str]=_A,llm_model:t.Optional[str]=_A,output_dir:t.Optional[Path]=_A,report_format:ReportFormat=ReportFormat.HTML,on_stage:t.Optional[StageCallback]=_A)->tuple[ReviewReport,ReportArtifacts]:
	stage_token=stage_callback_context(on_stage)
	try:
		evidence=ReviewEvidence(context,environment=environment,llm_model=llm_model);project_name=evidence.project_name();destination=output_dir or evidence.root/REVIEW_DIR;logger.info('Review started | project=%s environment=%s',project_name,environment or'default');blocked=check_preconditions(evidence)
		if blocked is not _A:logger.warning('Review not run | project=%s reason=%s',project_name,blocked.reason);report=_blocked_report(project_name,evidence.root.name,blocked);artifacts=save_report(report,destination,report_format=report_format);return report,artifacts
		deterministic,notice,metadata_coverage=try_deterministic_issues(context)
		if notice is not _A:logger.warning('Review incomplete | project=%s reason=%s',project_name,notice);report=_blocked_report(project_name,evidence.root.name,PreconditionFailure('Project metadata could not be loaded.',notice));artifacts=save_report(report,destination,report_format=report_format);return report,artifacts
		deterministic.extend(policy_issues(evidence));report=run_project_review(evidence,evidence.root.name,deterministic=deterministic,deterministic_notice=notice,metadata_coverage=metadata_coverage,report_format=report_format);artifacts=save_report(report,destination,report_format=report_format);logger.info('Review finished | status=%s report=%s',report.status.value,artifacts.path);return report,artifacts
	finally:reset_stage_callback(stage_token)