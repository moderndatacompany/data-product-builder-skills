from __future__ import annotations
_A=None
from vulcan.review.constraints import ReviewConstraints
from vulcan.review.schemas import AgentFinding,ContractAlignmentVerdict,CostVerdict,DimensionFailure,FindingCategory,FindingPriority,ModelingVerdict,ReviewCoverage
from vulcan.review.utils.dedupe import dedupe_by_key
_MATERIAL=frozenset({FindingPriority.BLOCKER,FindingPriority.HIGH})
def deduplicate_failures(failures:list[DimensionFailure])->list[DimensionFailure]:return dedupe_by_key(failures,key_fn=lambda failure:(failure.dimension,failure.detail))
def modeling_verdict(coverage:ReviewCoverage,findings:list[AgentFinding],adjudications:dict[str,ContractAlignmentVerdict]|_A=_A,*,findings_parsed:bool=True)->ModelingVerdict:
	if coverage.is_partial or not findings_parsed:return ModelingVerdict.INCOMPLETE
	verdicts=list((adjudications or{}).values())
	if any(verdict is ContractAlignmentVerdict.DRIFT for verdict in verdicts):return ModelingVerdict.CHANGES_REQUIRED
	modeling_findings=[finding for finding in findings if finding.category is not FindingCategory.PHYSICAL_COST]
	if any(finding.priority in _MATERIAL for finding in modeling_findings):return ModelingVerdict.CHANGES_REQUIRED
	if modeling_findings or any(verdict is ContractAlignmentVerdict.UNKNOWN for verdict in verdicts):return ModelingVerdict.WATCH
	return ModelingVerdict.VALIDATED
def cost_verdict(coverage:ReviewCoverage,findings:list[AgentFinding],constraints:ReviewConstraints|_A=_A,*,findings_parsed:bool=True)->CostVerdict:
	if coverage.is_partial or not findings_parsed:return CostVerdict.UNKNOWN
	cost_findings=[finding for finding in findings if finding.category is FindingCategory.PHYSICAL_COST]
	if any(finding.priority in _MATERIAL for finding in cost_findings):return CostVerdict.RISK
	if constraints is not _A and not constraints.workload_evidence_available:return CostVerdict.WATCH if cost_findings else CostVerdict.UNKNOWN
	if cost_findings:return CostVerdict.WATCH
	return CostVerdict.APPROPRIATE