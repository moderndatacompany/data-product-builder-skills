from __future__ import annotations
from vulcan.review.schemas import PRIORITY_RANK,AgentFinding,FindingCategory
from vulcan.review.utils.dedupe import dedupe_by_key
from vulcan.review.utils.text import normalize_token
def _finding_identity(finding:AgentFinding)->tuple[str,str]:return normalize_token(finding.model),normalize_token(finding.title)
def _keep_more_severe(existing:AgentFinding,duplicate:AgentFinding)->AgentFinding:
	priority=existing.priority
	if PRIORITY_RANK[duplicate.priority.value]<PRIORITY_RANK[existing.priority.value]:priority=duplicate.priority
	category=existing.category
	if existing.category is FindingCategory.PHYSICAL_COST and duplicate.category is not FindingCategory.PHYSICAL_COST:category=duplicate.category
	return existing.model_copy(update={'priority':priority,'category':category})
def deduplicate_findings(findings:list[AgentFinding])->list[AgentFinding]:return dedupe_by_key(findings,key_fn=_finding_identity,merge=_keep_more_severe)