from __future__ import annotations
_I='review'
_H='replace'
_G='utf-8'
_F=' \t'
_E=False
_D=', '
_C='not declared'
_B='\n'
_A=None
import json,re,typing as t
from dataclasses import dataclass,field
from pathlib import Path
from vulcan.core import constants as c
from vulcan.core.config.common import ALL_CONFIG_FILENAMES,USAGE_FILENAMES
from vulcan.core.model import Model,SemanticModel
BUSINESS_CONTEXT_FILES=frozenset({'README.md','DATA_REFERENCE.md','limitations.yaml','limitations.yml','usecases.yaml','usecases.yml'})
VULCAN_COMPONENT_DIRECTORIES=frozenset({c.ASSETS,c.AUDITS,c.CHECKS,c.DATA_QUALITY_KIND,c.DATA_QUALITY_KIND_ALIAS,c.EXTERNAL_MODELS,c.EXTERNAL_MODELS_DEPRECATED,c.LINTER,c.MACROS,c.MATERIALIZATIONS,c.METRICS,c.MODELS,c.SEEDS,c.SIGNALS,c.TESTS,'plugins','policies'})
VULCAN_COMPONENT_FILES=frozenset({*ALL_CONFIG_FILENAMES,*USAGE_FILENAMES,'agreement.md',*BUSINESS_CONTEXT_FILES,c.EXTERNAL_MODELS_YAML,c.EXTERNAL_MODELS_DEPRECATED_YAML,c.REQUIREMENTS})
if t.TYPE_CHECKING:from vulcan.core.context import Context
_SENSITIVE_KEY_PATTERN=re.compile('password|passwd|pwd|secret|token|credential|keyfile|keytab|passphrase|access_key|api_key|apikey',re.IGNORECASE)
_SENSITIVE_VALUE_LINE=re.compile('^(?P<prefix>\\s*[\\"\']?[\\w][\\w.-]*[\\"\']?\\s*:\\s*)(?P<value>.+)$')
_CONNECTION_BLOCK_KEY=re.compile('^(?P<indent>[ \\t]*)(?P<quote>[\\"\']?)(?P<key>connection|state_connection)(?P=quote)\\s*:\\s*(?P<rest>.*)$')
_CONNECTION_REDACTION_NOTICE='[REDACTED: connection config omitted from review evidence]'
def _strip_connection_blocks(text:str)->str:
	lines=text.splitlines();output:list[str]=[];skip_indent:t.Optional[int]=_A
	for line in lines:
		if skip_indent is not _A:
			indent_len=len(line)-len(line.lstrip(_F))
			if line.strip()and indent_len<=skip_indent:skip_indent=_A
			else:continue
		match=_CONNECTION_BLOCK_KEY.match(line)
		if match is _A:output.append(line);continue
		indent,quote,key,rest=match['indent'],match['quote'],match['key'],match['rest'];output.append(f"{indent}{quote}{key}{quote}: {_CONNECTION_REDACTION_NOTICE}")
		if not rest.strip()or rest.strip().startswith('#'):skip_indent=len(indent)
	return _B.join(output)
def _redact_secrets(text:str)->str:
	A='prefix';output:list[str]=[];skip_indent:t.Optional[int]=_A
	for line in _strip_connection_blocks(text).splitlines():
		if skip_indent is not _A:
			indent_len=len(line)-len(line.lstrip(_F))
			if line.strip()and indent_len<=skip_indent:skip_indent=_A
			else:continue
		match=_SENSITIVE_VALUE_LINE.match(line)
		if match is _A:output.append(line);continue
		key=match[A].split(':',1)[0]
		if not _SENSITIVE_KEY_PATTERN.search(key):output.append(line);continue
		output.append(f"{match[A]}[REDACTED]")
		if match['value'].lstrip().startswith(('|','>')):skip_indent=len(line)-len(line.lstrip(_F))
	return _B.join(output)
MAX_FILE_BYTES=300000
_BINARY_PROBE_BYTES=8000
def _looks_binary(raw:bytes)->bool:return b'\x00'in raw[:_BINARY_PROBE_BYTES]
@dataclass
class ReviewSafeFiles:
	root:Path;files:dict[str,Path]=field(init=_E)
	def __post_init__(self)->_A:self.root=self.root.resolve();self.files=discover_project_files(self.root)
	def read_text(self,path:Path)->str:
		try:
			size=path.stat().st_size
			with path.open('rb')as file:raw=file.read(MAX_FILE_BYTES+1)
		except OSError:return f"Unavailable review file: could not read {path.name}."
		if _looks_binary(raw):return f"[OMITTED: binary file, {size:,} bytes -- not sent to the review model]"
		truncated=len(raw)>MAX_FILE_BYTES;text=raw[:MAX_FILE_BYTES].decode(_G,errors=_H);text=_redact_secrets(text)
		if truncated:text+=f"\n\n[TRUNCATED: file is {size:,} bytes, exceeding the {MAX_FILE_BYTES:,}-byte per-file budget; showing the first {MAX_FILE_BYTES:,} bytes]"
		return text
	def read_file(self,relative_path:str,start_line:int=1,end_line:t.Optional[int]=_A)->str:
		path=self._indexed_path(relative_path)
		if path is _A:return f"Unavailable review file: {relative_path}"
		lines=self.read_text(path).splitlines();start=max(start_line,1);end=len(lines)if end_line is _A else max(end_line,start)
		if lines and start>len(lines):return f"Unavailable line range: {relative_path}:{start} exceeds the file's {len(lines)} lines."
		return _B.join(f"{number}: {lines[number-1]}"for number in range(start,min(end,len(lines))+1))
	def search(self,text:str)->str:
		needle=text.casefold().strip()
		if not needle:return'Search text must not be empty.'
		matches:list[str]=[]
		for(relative_path,path)in self.files.items():
			for(number,line)in enumerate(self.read_text(path).splitlines(),start=1):
				if needle in line.casefold():matches.append(f"{relative_path}:{number}: {line.strip()}")
		return _B.join(matches)or f"No matches for {text!r}."
	def _indexed_path(self,relative_path:str)->t.Optional[Path]:
		candidate=Path(relative_path)
		if candidate.is_absolute():return
		resolved=(self.root/candidate).resolve()
		if not resolved.is_relative_to(self.root):return
		return self.files.get(resolved.relative_to(self.root).as_posix())
def discover_project_files(root:Path)->dict[str,Path]:
	A='__pycache__';root=root.resolve();files:dict[str,Path]={};candidates=[root/name for name in VULCAN_COMPONENT_FILES]
	for directory in VULCAN_COMPONENT_DIRECTORIES:
		component_root=root/directory
		try:
			resolved_component=component_root.resolve()
			if not resolved_component.is_relative_to(root)or not resolved_component.is_dir():continue
		except OSError:continue
		candidates.extend(path for path in component_root.rglob('*')if A not in path.parts and path.name!='.gitkeep')
	typed_kind=re.compile('^\\s*kind\\s*:\\s*(?:dq|data_quality|policy|semantic|metric|rollup)\\s*$',re.IGNORECASE|re.MULTILINE)
	for pattern in('*.yaml','*.yml'):
		for path in root.rglob(pattern):
			relative_parts=path.relative_to(root).parts
			if any(part==A or part.startswith('.')for part in relative_parts[:-1]):continue
			try:
				with path.open('rb')as file:raw=file.read(MAX_FILE_BYTES)
				if typed_kind.search(raw.decode(_G,errors=_H)):candidates.append(path)
			except OSError:continue
	for path in candidates:
		try:
			resolved=path.resolve()
			if not resolved.is_relative_to(root)or not resolved.is_file():continue
		except OSError:continue
		files[path.relative_to(root).as_posix()]=resolved
	return dict(sorted(files.items()))
def relative_or_name(root:Path,path:t.Any,*,default:str='')->str:
	if path is _A:return default
	try:return Path(path).resolve().relative_to(root).as_posix()
	except ValueError:return Path(path).name
def ensure_context_loaded(context:Context)->_A:
	if not context._loaded:context.load(update_schemas=_E,use_state=_E)
def _model_provider(model_name:str|_A)->str|_A:
	if not model_name:return
	for sep in('/',':'):
		provider,found_sep,_=model_name.partition(sep)
		if found_sep:return provider
	return model_name
class ReviewEvidence:
	def __init__(self,context:Context,environment:str|_A=_A,llm_model:str|_A=_A)->_A:self.context=context;self.environment=environment;self.llm_model=llm_model;self.root=Path(context.path).resolve();self.safe_files=ReviewSafeFiles(self.root);self.doctrine_root=Path(__file__).resolve().parent/'doctrine';(self._physical_metadata):str|_A=_A
	def project_name(self)->str:return str(getattr(self.context.config,'name','')or self.root.name)
	def review_model_name(self)->str|_A:
		if self.llm_model:return self.llm_model
		review_config=getattr(self.context.config,_I,_A)
		if review_config is _A:return
		return review_config.model
	def review_llm_kwargs(self)->dict[str,t.Any]:
		C='timeout';B='temperature';A='api_key';review_config=getattr(self.context.config,_I,_A);model_name=self.review_model_name();api_key=getattr(review_config,A,_A)if review_config else _A
		if api_key is not _A:
			configured_model=getattr(review_config,'model',_A)
			if configured_model and _model_provider(model_name)!=_model_provider(configured_model):api_key=_A
		return{'model_name':model_name,A:api_key.get_secret_value()if api_key else _A,B:getattr(review_config,B,_A)if review_config else _A,C:getattr(review_config,C,_A)if review_config else _A}
	def read_file(self,relative_path:str,start_line:int=1,end_line:t.Optional[int]=_A)->str:return self.safe_files.read_file(relative_path,start_line,end_line)
	def file_content(self,relative_path:str)->str:
		path=self.safe_files.files.get(relative_path)
		if path is _A:return f"Unavailable review file: {relative_path}"
		return self.safe_files.read_text(path)
	def search(self,text:str)->str:return self.safe_files.search(text)
	def read_doctrine(self,relative_path:str)->str:
		candidate=Path(relative_path)
		if candidate.is_absolute():return f"Unavailable doctrine file: {relative_path}"
		path=(self.doctrine_root/candidate).resolve()
		if not path.is_relative_to(self.doctrine_root)or not path.is_file():return f"Unavailable doctrine file: {relative_path}"
		return path.read_text(encoding=_G,errors=_H)
	def product_context(self)->str:
		config=self.context.config;lines=[f"Project: {self.project_name()}",f"Domain: {getattr(config,'domain',_A)or _C}",f"Description: {getattr(config,'description',_A)or _C}"];usage=getattr(config,'usage',_A)
		for section in('good_for','not_for','caveats','references'):
			items=getattr(usage,section,_A)or[]
			if items:lines.append(f"{section.replace('_',' ').title()}:");lines.extend(f"- {_usage_item(item)}"for item in items)
		return _B.join(lines)
	def physical_metadata(self)->str:
		if self._physical_metadata is _A:
			try:metadata=self.context.metadata_for_environment(self.environment);self._physical_metadata=json.dumps(metadata.to_json_dict(),ensure_ascii=_E,indent=2,default=str)
			except Exception as exc:self._physical_metadata=f"Physical metadata unavailable: {exc}"
		return self._physical_metadata
	def model_metadata(self,model_name:str='')->str:
		A='none declared';models=self._models()
		if not model_name:return _B.join(f"{model.name} [{_kind(model)}] ({self._source_path(model)})"for model in models)or'No models loaded.'
		model=self._model(model_name)
		if model is _A:return f"Unknown project model: {model_name}"
		lines=[f"Model: {model.name}",f"Source: {self._source_path(model)}",f"Kind: {_kind(model)}",f"Description: {model.description or _C}",f"Grains: {_D.join(_grains(model))or _C}",f"Unique keys: {_D.join(key.sql()for key in model.unique_key)or _C}",f"Schedule: {model.cron or _C} ({_interval_unit(model)})",f"Depends on: {_D.join(self._depends_on(model))or A}",f"Audits: {_D.join(name for(name,_)in model.audits)or A}"];joins=_joins(model)
		if joins:lines.append('Semantic joins:');lines.extend(f"- {join}"for join in joins)
		lines.append('Fields:');fields=_fields(model);lines.extend(f"- {field}"for field in fields or[A]);return _B.join(lines)
	def model_names(self)->tuple[str,...]:return tuple(model.name for model in self._models())
	def graph(self,model_name:str='')->str:
		A='none';models=self._models();downstream:dict[str,list[str]]={}
		for model in models:
			for dependency in self._depends_on(model):downstream.setdefault(dependency,[]).append(model.name)
		if model_name:
			model=self._model(model_name)
			if model is _A:return f"Unknown project model: {model_name}"
			models=[model]
		lines=['Dependency graph (declared structure only):']
		for model in models:upstream=_D.join(self._depends_on(model))or A;children=_D.join(sorted(downstream.get(model.name,[])))or A;lines.append(f"- {model.name} [{_kind(model)}] | upstream: {upstream} | downstream: {children}")
		joins=[f"- {model.name} -> {join}"for model in models for join in _joins(model)]
		if joins:lines.append('Semantic join graph:');lines.extend(joins)
		return _B.join(lines)
	def ensure_loaded(self)->_A:ensure_context_loaded(self.context)
	def _models(self)->list[Model]:self.ensure_loaded();return sorted(self.context.models.values(),key=lambda model:model.name.casefold())
	def _model(self,model_name:str)->t.Optional[Model]:
		self.ensure_loaded();model=self.context.get_model(model_name.strip(),raise_if_missing=_E)
		if model is not _A:return model
		wanted=model_name.strip().casefold();matches=[candidate for candidate in self.context.models.values()if candidate.name.rsplit('.',1)[-1].casefold()==wanted];return matches[0]if len(matches)==1 else _A
	def _depends_on(self,model:Model)->list[str]:names={parent.name if(parent:=self.context.models.get(fqn))is not _A else fqn for fqn in model.depends_on};return sorted(names)
	def _source_path(self,model:Model)->str:return relative_or_name(self.root,getattr(model,'_path',_A),default=_C)
def _kind(model:Model)->str:return model.kind.name if model.kind is not _A else'UNKNOWN'
def _grains(model:Model)->list[str]:return[grain.sql()for grain in model.grains]
def _interval_unit(model:Model)->str:
	try:return str(model.interval_unit.value)
	except Exception:return'unknown interval'
def _joins(model:Model)->list[str]:
	if not isinstance(model,SemanticModel):return[]
	return[f"{join.name} [{join.type}]: {join.expression or'expression not declared'}"for join in model.joins]
def _fields(model:Model)->list[str]:
	if isinstance(model,SemanticModel):fields=[f"{dimension.name} [dimension; {_dimension_detail(dimension)}]"for dimension in model.dimensions];fields.extend(f"{measure.name} [measure; {measure.type}]"for measure in model.measures);fields.extend(f"{segment.name} [segment]"for segment in model.segments);return fields
	return[f"{name} [physical; {dtype.sql()}]"for(name,dtype)in model.columns_to_types.items()]
def _dimension_detail(dimension:t.Any)->str:
	details=[]
	if dimension.tags:details.append(f"tags={','.join(str(tag)for tag in dimension.tags)}")
	if dimension.behavior:details.append(f"behavior={dimension.behavior.type}")
	return'; '.join(details)or'no tags or behavior declared'
def _usage_item(item:t.Any)->str:title=getattr(item,'title',_A)or'Untitled';details=getattr(item,'details',_A)or getattr(item,'url',_A);return f"{title}: {details}"if details else str(title)