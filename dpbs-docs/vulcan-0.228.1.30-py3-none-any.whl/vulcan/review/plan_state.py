from __future__ import annotations
import logging,typing as t
from pydantic import BaseModel,Field
logger=logging.getLogger(__name__)
if t.TYPE_CHECKING:from vulcan.core.context import Context
class PlanState(BaseModel):
	environment:str='';available:bool=False;unavailable_reason:str='';added:list[str]=Field(default_factory=list);removed:list[str]=Field(default_factory=list);modified:list[str]=Field(default_factory=list);directly_modified:list[str]=Field(default_factory=list);indirectly_modified:list[str]=Field(default_factory=list);metadata_only:list[str]=Field(default_factory=list)
	@property
	def has_pending_changes(self)->bool:return bool(self.added or self.removed or self.modified)
	def prompt_block(self)->str:
		if not self.available:return f"# Deployed comparison\n\nUnavailable: {self.unavailable_reason}\n\nYou cannot tell which of these models are live and which are unplanned local edits. Do not assume the authored state is deployed, and say so when a guarantee depends on the difference."
		if not self.has_pending_changes:return f"# Deployed comparison\n\nEvery authored model matches what is deployed to `{self.environment}`. Guarantees you assess are live guarantees, not pending ones."
		lines=['# Deployed comparison','',f"These differ from what is deployed to `{self.environment}`. This is release state, not a verdict. A project under active development is expected to have authored work ahead of production. What matters is whether a claim you make depends on something being live, and whether production is left inconsistent.",'']
		if self.added:lines.append(f"- Authored, not yet released: {_names(self.added)}. This is the normal state of new work and is not a defect. Production not containing them is expected, so do not report their absence as a fault. Do not describe a guarantee they carry as protecting consumers today either; it is authored, not in force.")
		if self.removed:lines.append(f"- Deployed but no longer authored: {_names(self.removed)}. Anything downstream still depending on these breaks on the next plan. Unlike the authored-not-released list, this is a live inconsistency.")
		if self.directly_modified:lines.append(f"- Directly modified: {_names(self.directly_modified)}")
		if self.indirectly_modified:lines.append(f"- Modified through an upstream change: {_names(self.indirectly_modified)}")
		if self.metadata_only:lines.append(f"- Metadata changed only, no data impact: {_names(self.metadata_only)}")
		return'\n'.join(lines)
def _names(values:list[str])->str:return', '.join(f"`{value}`"for value in values)
def build_plan_state(context:Context,environment:str|None=None)->PlanState:
	from vulcan.core.context_diff import ContextDiff;from vulcan.core.environment import Environment;target=Environment.sanitize_name(environment or context.config.default_target_environment)
	try:diff=ContextDiff.create(target,snapshots=context.snapshots,create_from=target,state_reader=context.state_reader)
	except Exception as exc:reason=f"{type(exc).__name__}: {exc}";logger.warning('Deployed comparison unavailable | environment=%s error=%s',target,reason);return PlanState(environment=target,available=False,unavailable_reason=reason)
	modified=sorted(diff.modified_snapshots);return PlanState(environment=target,available=True,added=sorted(snapshot_id.name for snapshot_id in diff.added),removed=sorted(snapshot_id.name for snapshot_id in diff.removed_snapshots),modified=modified,directly_modified=[name for name in modified if diff.directly_modified(name)],indirectly_modified=[name for name in modified if diff.indirectly_modified(name)],metadata_only=[name for name in modified if diff.metadata_updated(name)])