from __future__ import annotations
_A=False
import re
from pydantic import BaseModel,Field
from vulcan.review.packet import ProjectEvidencePacket
from vulcan.review.schemas import EvidenceKind
_FULL_REBUILD_KINDS=frozenset({'FULL','VIEW'})
_CITATION=re.compile('(?P<path>[\\w./-]+\\.(?:sql|yml|yaml|md|py|csv))(?::\\d+(?:-\\d+)?)?')
class ReviewConstraints(BaseModel):
	model_count:int=0;model_names:list[str]=Field(default_factory=list);unsupported_cost_models:list[str]=Field(default_factory=list);workload_evidence_available:bool=_A;valid_artifacts:list[str]=Field(default_factory=list)
	def prompt_block(self)->str:
		lines=['# Application-owned facts','','These were computed by the application from the project itself. They are not open to interpretation. Do not write anything that contradicts them.','',f"- The review covered {self.model_count} authored model(s)."]
		if not self.workload_evidence_available:lines.append('- No measured workload or scale evidence was available for this project. You may not describe any physical design as appropriate, efficient, or well sized. Where cost matters, state what measurement would settle it.')
		if self.unsupported_cost_models:listed=', '.join(f"`{name}`"for name in self.unsupported_cost_models);lines.append(f"- These models rebuild their full output every run with no measured workload evidence behind them: {listed}. Their cost posture is unknown at best. Do not call them appropriate.")
		return'\n'.join(lines)
def build_constraints(packet:ProjectEvidencePacket)->ReviewConstraints:
	snapshot=packet.context_snapshot;workload_available=_has_workload_evidence(packet);unsupported:list[str]=[]
	if not workload_available:physical=set(packet.physical_model_names);unsupported=sorted(model.name for model in snapshot.models if model.name in physical and model.kind.upper()in _FULL_REBUILD_KINDS)
	return ReviewConstraints(model_count=packet.model_count,model_names=list(packet.model_names),unsupported_cost_models=unsupported,workload_evidence_available=workload_available,valid_artifacts=sorted(entry.target for entry in packet.entries if entry.kind==EvidenceKind.FILE.value))
def _has_workload_evidence(packet:ProjectEvidencePacket)->bool:
	environment=packet.context_snapshot.environment_metadata
	if environment is None:return _A
	return bool(environment.nominal_runs or environment.missing_intervals)
_COST_ENDORSEMENT=re.compile('\\b(?:cost|physical\\s+design|materiali[sz]ation|refresh\\s+strategy)\\b[^.\\n]{0,80}?\\b(?:is|are|remains?|looks?|appears?)\\b[^.\\n]{0,40}?\\b(?:appropriate|optimal|efficient|well[\\s-]sized|right[\\s-]sized|economical)\\b',re.IGNORECASE)
def contradicts_cost_verdict(body:str,cost_verdict:str)->bool:
	if cost_verdict=='appropriate':return _A
	return _COST_ENDORSEMENT.search(body)is not None
def unresolved_citations(body:str,constraints:ReviewConstraints)->list[str]:
	if not constraints.valid_artifacts:return[]
	valid=set(constraints.valid_artifacts);valid_basenames={path.rsplit('/',1)[-1]for path in valid};unresolved={path for path in(match.group('path')for match in _CITATION.finditer(body))if path not in valid and path.rsplit('/',1)[-1]not in valid_basenames};return sorted(unresolved)