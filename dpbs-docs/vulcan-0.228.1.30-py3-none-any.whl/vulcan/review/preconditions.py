from __future__ import annotations
_A=None
import typing as t
from vulcan.core.config.common import USAGE_FILENAMES
if t.TYPE_CHECKING:from vulcan.review.evidence import ReviewEvidence
_README_FILES='README.md','DATA_REFERENCE.md'
_LIMITATION_FILES='limitations.yaml','limitations.yml'
class PreconditionFailure(t.NamedTuple):reason:str;detail:str
def check_preconditions(evidence:ReviewEvidence)->PreconditionFailure|_A:
	if not _has_models(evidence):return PreconditionFailure(reason='This project defines no models.',detail='A review needs models to reason about: structure compares dependency edges, semantics reads exposed members, and contract checks guarantees. None of those exist here. Add at least one model and run the review again.')
	missing=_missing_intent(evidence)
	if missing:return PreconditionFailure(reason='This project states no intent.',detail='Every technical conclusion is judged against what the product claims to be for, and this project claims nothing: '+', '.join(missing)+'. Add a product description, usage guidance, a README, or a limitations file, then run the review again.')
def _has_models(evidence:ReviewEvidence)->bool:
	try:evidence.ensure_loaded()
	except Exception:return True
	return bool(evidence.context.models)
def _missing_intent(evidence:ReviewEvidence)->list[str]:
	config=evidence.context.config;present=evidence.safe_files.files;checks=('no product description in configuration',bool(_description(config))),('no usage guidance',_has_usage(config,present)),('no README or DATA_REFERENCE.md',any(name in present for name in _README_FILES)),('no limitations file',any(name in present for name in _LIMITATION_FILES))
	if any(satisfied for(_,satisfied)in checks):return[]
	return[label for(label,_)in checks]
def _description(config:t.Any)->str:return str(getattr(config,'description','')or'').strip()
def _has_usage(config:t.Any,present:t.Mapping[str,t.Any])->bool:
	if any(name in present for name in USAGE_FILENAMES):return True
	usage=getattr(config,'usage',_A)
	if usage is _A:return False
	return any(getattr(usage,field,_A)for field in('good_for','not_for','caveats','objectives'))