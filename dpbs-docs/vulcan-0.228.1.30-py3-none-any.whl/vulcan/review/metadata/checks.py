from __future__ import annotations
_J='examples'
_I='instructions'
_H='missing_aggregation'
_G='kind_tag_conflict'
_F='medium'
_E='dimension'
_D=None
_C=False
_B='measure'
_A='high'
from vulcan.review.schemas import Coverage,MetadataColumn,MetadataCoverage,MetadataIssue,MetadataModel,MetadataProject
_RULE_SEVERITY={_G:_A,_H:_A}
SEMANTIC_MODEL_KINDS={'SEMANTIC','METRIC'}
def selected_models(project:MetadataProject,*,include_physical:bool=_C)->list[MetadataModel]:allowed_kinds=SEMANTIC_MODEL_KINDS|({'FULL'}if include_physical else set());return[model for model in project.models if model.kind.upper()in allowed_kinds]
def coverage(project:MetadataProject,*,include_physical:bool=_C)->MetadataCoverage:
	semantic_models=[model for model in project.models if model.kind.upper()in SEMANTIC_MODEL_KINDS];physical_models=[model for model in project.models if model.kind.upper()=='FULL']if include_physical else[];semantic_all_fields=[column for model in semantic_models for column in model.columns];semantic_fields=[column for column in semantic_all_fields if not is_generated_count(column)];physical_fields=[column for model in physical_models for column in model.columns];semantic_columns=[]
	for model in semantic_models:
		for column in model.columns:
			if column.kind.casefold()in{_E,_B}and not is_generated_count(column):semantic_columns.append((model.name,column))
	dimensions=[column for column in semantic_fields if column.kind.casefold()==_E];return MetadataCoverage(semantic_models=_coverage(semantic_models),semantic_fields=_coverage(semantic_fields),physical_models=_coverage(physical_models),physical_fields=_coverage(physical_fields),generated_fields_excluded=len(semantic_all_fields)-len(semantic_fields),ai_context_total=len(semantic_columns),ai_context_present=sum(column.ai_context is not _D for(_,column)in semantic_columns),ai_context_passing=sum(passes_ai_context(column,model_name)for(model_name,column)in semantic_columns),dimensions_total=len(dimensions),dimensions_aligned=sum(not conflicting_measure_tags(column)for column in dimensions))
def find_issues(project:MetadataProject)->list[MetadataIssue]:
	issues:list[MetadataIssue]=[]
	for model in selected_models(project):
		for column in model.columns:
			if is_generated_count(column):continue
			issues.extend(column_quality_issues(column,model.name,column.name,scope='semantic',semantic=True))
	return issues
def _coverage(items:list[MetadataModel]|list[MetadataColumn])->Coverage:return Coverage(total=len(items),described=sum(bool(item.description.strip())for item in items),tagged=sum(bool(item.tags)for item in items),termed=sum(bool(item.terms)for item in items))
def column_quality_issues(column:MetadataColumn,model_name:str,field_name:str|_D,*,scope:str,semantic:bool)->list[MetadataIssue]:
	issues:list[MetadataIssue]=[];conflicting_tags=conflicting_measure_tags(column)if semantic else set()
	if column.kind.casefold()==_E and conflicting_tags:rule_id=_G;issues.append(MetadataIssue(rule_id=rule_id,model=model_name,field=field_name,scope=scope,priority=priority(column,rule_id),title='Dimension kind / measure-tag conflict',detail='Column kind is dimension but tags classify it as a measure or metric.',action=f"Resolve the dimension versus {'/'.join(sorted(conflicting_tags))} tag conflict: verify the intended semantic role, then correct either the kind or the conflicting tags."))
	if semantic and column.kind.casefold()==_B and not column.aggregation.strip():rule_id=_H;issues.append(MetadataIssue(rule_id=rule_id,model=model_name,field=field_name,scope=scope,priority=priority(column,rule_id),title='Missing aggregation type',detail='Measure metadata does not declare an aggregation type.',action="Declare the measure's aggregation type and verify it matches the measure semantics."))
	return issues
def is_templated_ai_context(column:MetadataColumn,model_name:str)->bool:
	A='query';context=column.ai_context
	if context is _D:return _C
	prefix=f"Use {column.name} to filter or group {model_name} results.";instructions=str(context.get(_I)or'').strip()
	if not instructions.startswith(prefix):return _C
	examples=context.get(_J)or[];return bool(examples)and all('COUNT(*)'in str(example.get(A,'')).upper()and'GROUP BY'in str(example.get(A,'')).upper()for example in examples if isinstance(example,dict))
def is_generated_count(column:MetadataColumn)->bool:A='count';return bool(column.name.casefold()==A and column.kind.casefold()==_B and' '.join(column.description.split()).casefold()=='count of rows'and column.aggregation.casefold()==A and not column.expression.strip())
def passes_ai_context(column:MetadataColumn,model_name:str)->bool:context=column.ai_context;return bool(context and str(context.get(_I)or'').strip()and context.get('synonyms')and context.get(_J)and not is_templated_ai_context(column,model_name))
def conflicting_measure_tags(column:MetadataColumn)->set[str]:tags={tag.strip().casefold()for tag in column.tags};return tags&{_B,'metric'}
def priority(item:MetadataModel|MetadataColumn,rule_id:str)->str:
	severity=_RULE_SEVERITY.get(rule_id)
	if severity is _D:raise KeyError(f"No severity mapping for rule_id {rule_id!r}; add it to _RULE_SEVERITY.")
	importance=artifact_importance(item)
	if severity==_A:return _A
	if severity==_F:return importance
	return _F if importance==_A else'low'
def artifact_importance(item:MetadataModel|MetadataColumn)->str:
	if isinstance(item,MetadataModel):return _A
	if item.kind.lower()==_B:return _A
	if item.public:return _F
	return'low'