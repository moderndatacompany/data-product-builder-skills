from __future__ import annotations
_A=None
import logging,typing as t
from vulcan.core.model import MetricModel,SemanticModel
from vulcan.review.evidence import ensure_context_loaded
from vulcan.review.metadata.checks import coverage,find_issues
from vulcan.review.schemas import MetadataColumn,MetadataCoverage,MetadataIssue,MetadataModel,MetadataProject
logger=logging.getLogger(__name__)
if t.TYPE_CHECKING:from vulcan.core.context import Context;from vulcan.core.model import Model
def metadata_issue_payload(issue:MetadataIssue)->dict[str,t.Any]:return{'rule_id':issue.rule_id,'model':issue.model,'field':issue.field,'priority':issue.priority,'title':issue.title,'detail':issue.detail,'action':issue.action,'evidence':issue.evidence}
def _ai_context_dict(ai_context:t.Any)->t.Optional[dict[str,t.Any]]:return ai_context.model_dump(mode='json')if ai_context is not _A else _A
def _column_from_dimension(dimension:t.Any)->MetadataColumn:return MetadataColumn(name=dimension.name,kind='dimension',description=dimension.description or'',tags=[str(tag)for tag in dimension.tags],terms=[str(term)for term in dimension.terms],ai_context=_ai_context_dict(dimension.ai_context),public=dimension.public)
def _column_from_measure(measure:t.Any)->MetadataColumn:return MetadataColumn(name=measure.name,kind='measure',description=measure.description or'',tags=[str(tag)for tag in measure.tags],terms=[str(term)for term in measure.terms],ai_context=_ai_context_dict(measure.ai_context),aggregation=measure.type or'',expression=measure.expression or'',public=measure.public)
def _physical_columns(model:Model)->list[MetadataColumn]:
	descriptions=getattr(model,'column_descriptions',_A)or{};tags=getattr(model,'column_tags',_A)or{};terms=getattr(model,'column_terms',_A)or{};ai_context=getattr(model,'column_ai_context',_A)or{};columns:list[MetadataColumn]=[]
	for name in model.columns_to_types_or_raise:raw_context=ai_context.get(name);columns.append(MetadataColumn(name=name,description=str(descriptions.get(name,'')or''),tags=[str(tag)for tag in tags.get(name,[])],terms=[str(term)for term in terms.get(name,[])],ai_context=_ai_context_dict(raw_context)))
	return columns
def _model_kind(model:Model)->str:
	if isinstance(model,MetricModel):return'METRIC'
	if isinstance(model,SemanticModel):return'SEMANTIC'
	return'FULL'
def _metadata_model_from_model(model:Model)->MetadataModel:
	columns:list[MetadataColumn]=[]
	if isinstance(model,SemanticModel):columns.extend(_column_from_dimension(dimension)for dimension in model.dimensions);columns.extend(_column_from_measure(measure)for measure in model.measures)
	else:columns.extend(_physical_columns(model))
	return MetadataModel(name=model.name,kind=_model_kind(model),description=model.description or'',tags=[str(tag)for tag in model.tags],terms=[str(term)for term in getattr(model,'terms',[])or[]],ai_context=_ai_context_dict(getattr(model,'ai_context',_A)),columns=columns)
def metadata_project_from_context(context:Context)->MetadataProject:ensure_context_loaded(context);return MetadataProject(name=str(getattr(context.config,'name','')or''),models=[_metadata_model_from_model(model)for model in context.models.values()])
def try_deterministic_issues(context:Context)->t.Tuple[t.List[MetadataIssue],t.Optional[str],MetadataCoverage]:
	try:project=metadata_project_from_context(context)
	except Exception as exc:detail=f"Deterministic metadata checks skipped: {exc}";logger.warning('Project could not be parsed for deterministic checks: %s',exc);return[],detail,MetadataCoverage()
	return find_issues(project),_A,coverage(project,include_physical=True)