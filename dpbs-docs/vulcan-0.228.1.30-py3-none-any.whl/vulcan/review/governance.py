from __future__ import annotations
import typing as t
from vulcan.review.schemas import MetadataIssue
if t.TYPE_CHECKING:from vulcan.review.evidence import ReviewEvidence
POLICIES_DIR='policies'
_SENSITIVE_CLASSIFICATIONS=frozenset({'restricted','confidential'})
_MISSING_POLICY='missing_access_policy'
def policy_issues(evidence:ReviewEvidence)->list[MetadataIssue]:
	B='observed';A='product';evidence.ensure_loaded()
	if _has_policy(evidence):return[]
	sensitive=_sensitive_columns(evidence)
	if sensitive:listed=', '.join(sensitive[:5]);overflow=f" and {len(sensitive)-5} more"if len(sensitive)>5 else'';return[MetadataIssue(rule_id=_MISSING_POLICY,model='',priority='blocker',title='Sensitive columns are exposed with no access policy',detail=f"The product declares no access policy, and these columns are classified restricted or confidential: {listed}{overflow}. Every consumer who can reach the product can read them.",action='Declare an access policy covering the sensitive columns: filter rows by group, mask the columns, or reclassify them if the classification is wrong. Verify the policy applies across every interface, not only the one you test.',scope=A,evidence_level=B)]
	return[MetadataIssue(rule_id=_MISSING_POLICY,model='',priority='medium',title='No access policy is declared',detail='The product declares no access policy, inline or standalone. No column is currently classified restricted or confidential, so nothing sensitive is known to be exposed, but the access boundary is undeclared rather than deliberately open.',action='Declare the intended access boundary, even when it is open to everyone. An explicit decision survives the next column being added; an absent one does not.',scope=A,evidence_level=B)]
def _has_policy(evidence:ReviewEvidence)->bool:
	if any(path.startswith(f"{POLICIES_DIR}/")for path in evidence.safe_files.files):return True
	return any(getattr(model,'policy',None)for model in evidence.context.models.values())
def _sensitive_columns(evidence:ReviewEvidence)->list[str]:
	sensitive:list[str]=[]
	for model in evidence.context.models.values():
		classifications=getattr(model,'column_classifications',None)or{}
		for(column,classification)in classifications.items():
			if str(classification).casefold()in _SENSITIVE_CLASSIFICATIONS:sensitive.append(f"{model.name}.{column}")
	return sorted(sensitive)