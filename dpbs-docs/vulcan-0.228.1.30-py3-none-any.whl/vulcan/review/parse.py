from __future__ import annotations
_D='finding'
_C=True
_B=False
_A=None
import logging,re
from vulcan.review.schemas import AgentFinding,ContractAlignmentVerdict,DimensionKey,FindingCategory,FindingPriority
logger=logging.getLogger(__name__)
_ADJUDICATION=re.compile('^\\s*[-*]\\s*`?(?P<candidate>contract-[0-9a-f]+)`?\\s*[:\\u2014-]+\\s*\\**(?P<verdict>aligned|drift|unknown)\\b',re.IGNORECASE|re.MULTILINE)
_HEADING=re.compile('^\\s{0,3}#{1,6}\\s*(?P<title>.+?)\\s*#*\\s*$')
_SEPARATOR_ROW=re.compile('^\\s*\\|?[\\s:|-]+\\|[\\s:|-]*$')
_ESCAPED_PIPE_SPLIT=re.compile('(?<!\\\\)\\|')
_NONE_TITLES=frozenset({'','none','n/a','na','-','no material findings.'})
_PRIORITY_ALIASES:dict[str,FindingPriority]={'critical':FindingPriority.BLOCKER,'severe':FindingPriority.BLOCKER,'moderate':FindingPriority.MEDIUM,'minor':FindingPriority.LOW,'info':FindingPriority.LOW}
_CATEGORY_ALIASES:dict[str,FindingCategory]={'structure':FindingCategory.STRUCTURE_COHERENCE,'coherence':FindingCategory.STRUCTURE_COHERENCE,'grain_enforcement':FindingCategory.STRUCTURE_COHERENCE,'join_cardinality':FindingCategory.STRUCTURE_COHERENCE,'history_semantics':FindingCategory.STRUCTURE_COHERENCE,'cadence':FindingCategory.STRUCTURE_COHERENCE,'cost':FindingCategory.PHYSICAL_COST,'cost_signal':FindingCategory.PHYSICAL_COST,'physical_design':FindingCategory.PHYSICAL_COST,'semantics':FindingCategory.SEMANTIC_MEANING,'semantic_quality':FindingCategory.SEMANTIC_MEANING,'measure_reaggregation':FindingCategory.SEMANTIC_MEANING,'contract':FindingCategory.CONTRACT_ENFORCEMENT,'enforcement':FindingCategory.CONTRACT_ENFORCEMENT,'model_validation':FindingCategory.CONTRACT_ENFORCEMENT,'contract_alignment':FindingCategory.CONTRACT_ENFORCEMENT,'data_quality':FindingCategory.CONTRACT_ENFORCEMENT}
_DIMENSION_DEFAULT_CATEGORY:dict[DimensionKey,FindingCategory]={DimensionKey.STRUCTURE:FindingCategory.STRUCTURE_COHERENCE,DimensionKey.SEMANTICS:FindingCategory.SEMANTIC_MEANING,DimensionKey.CONTRACT:FindingCategory.CONTRACT_ENFORCEMENT}
def parse_findings(dimension:DimensionKey,body:str)->tuple[list[AgentFinding],bool]:
	rows=_findings_table_rows(body)
	if rows is _A:logger.warning('Findings table not found in specialist section | dimension=%s',dimension.value);return[],_B
	findings:list[AgentFinding]=[];unreadable=0
	for cells in rows:
		try:finding=_finding_from_cells(dimension,cells)
		except ValueError:unreadable+=1;continue
		if finding is not _A:findings.append(finding)
	if unreadable:logger.warning('Discarded unreadable finding rows | dimension=%s rows=%d',dimension.value,unreadable);return findings,_B
	return findings,_C
def parse_adjudications(body:str,expected:tuple[str,...])->dict[str,ContractAlignmentVerdict]:
	if not expected:return{}
	found:dict[str,ContractAlignmentVerdict]={}
	for match in _ADJUDICATION.finditer(body):candidate=match.group('candidate');found[candidate]=ContractAlignmentVerdict(match.group('verdict').casefold())
	adjudications={candidate:found.get(candidate,ContractAlignmentVerdict.UNKNOWN)for candidate in expected};missing=[candidate for(candidate,verdict)in adjudications.items()if candidate not in found and verdict is ContractAlignmentVerdict.UNKNOWN]
	if missing:logger.warning('Contract candidates were never adjudicated, treating as unknown | candidates=%s',missing)
	return adjudications
def parse_finding_merges(body:str,finding_count:int)->list[tuple[tuple[int,...],str]]:
	rows=_merge_table_rows(body)
	if not rows:return[]
	groups:list[tuple[tuple[int,...],str]]=[];claimed:set[int]=set()
	for cells in rows:
		if len(cells)<2:continue
		members=_merge_indices(cells[0],finding_count);title=cells[1].strip()if len(cells)>1 else''
		if len(members)<2 or not title:continue
		if claimed.intersection(members):logger.warning('Merge group reuses an already merged finding, dropping it | members=%s',members);continue
		claimed.update(members);groups.append((members,title))
	return groups
def _merge_table_rows(body:str)->list[list[str]]:
	lines=body.splitlines()
	for(index,line)in enumerate(lines):
		match=_HEADING.match(line)
		if match and match.group('title').strip().casefold().startswith('merge'):return _table_after(lines,index+1,stop_at_heading=_C)or[]
	return _table_after(lines,0,stop_at_heading=_B)or[]
def _merge_indices(value:str,finding_count:int)->tuple[int,...]:
	numbers=[int(token)for token in re.findall('\\d+',_strip_code(value))];indices=sorted({number-1 for number in numbers if 1<=number<=finding_count})
	if len(indices)!=len(numbers):logger.warning('Merge group cites an out-of-range finding number, dropping it | cell=%r count=%d',value,finding_count);return()
	return tuple(indices)
def _findings_table_rows(body:str)->list[list[str]]|_A:
	lines=body.splitlines();heading_index=_A
	for(index,line)in enumerate(lines):
		match=_HEADING.match(line)
		if match and match.group('title').strip().casefold().startswith(_D):heading_index=index;break
	if heading_index is not _A:
		rows=_table_after(lines,heading_index+1,stop_at_heading=_C)
		if rows is not _A:return rows
	return _table_after(lines,0,stop_at_heading=_B)
def _table_after(lines:list[str],start:int,*,stop_at_heading:bool)->list[list[str]]|_A:
	rows:list[list[str]]=[];in_table=_B
	for line in lines[start:]:
		stripped=line.strip()
		if not in_table:
			if stop_at_heading and _HEADING.match(line):return
			if'|'not in stripped:continue
			in_table=_C
		elif'|'not in stripped:break
		if _SEPARATOR_ROW.match(stripped):continue
		rows.append(_cells(stripped))
	if not in_table:return
	if rows and _is_header_row(rows[0]):return rows[1:]
	return rows
def _is_header_row(cells:list[str])->bool:normalized={_strip_code(cell).casefold()for cell in cells};return{'priority',_D}.issubset(normalized)
def _cells(line:str)->list[str]:
	A='\\|';trimmed=line.strip()
	if trimmed.startswith('|'):trimmed=trimmed[1:]
	if trimmed.endswith('|')and not trimmed.endswith(A):trimmed=trimmed[:-1]
	return[cell.strip().replace(A,'|')for cell in _ESCAPED_PIPE_SPLIT.split(trimmed)]
def _finding_from_cells(dimension:DimensionKey,cells:list[str])->AgentFinding|_A:
	if len(cells)<4:raise ValueError(f"Expected at least 4 cells, got {len(cells)}.")
	priority_cell,category_cell,model_cell,title_cell=cells[:4];title=title_cell.strip()
	if title.casefold()in _NONE_TITLES:return
	if _strip_code(priority_cell).casefold()in{'none','n/a','na'}:return
	priority=_priority(priority_cell)
	if priority is _A:raise ValueError(f"Unreadable priority {priority_cell!r}.")
	return AgentFinding(category=_category(category_cell,dimension),priority=priority,title=title,model=_strip_code(model_cell),dimension=dimension)
def _priority(value:str)->FindingPriority|_A:
	normalized=_strip_code(value).casefold()
	try:return FindingPriority(normalized)
	except ValueError:return _PRIORITY_ALIASES.get(normalized)
def _category(value:str,dimension:DimensionKey)->FindingCategory:
	normalized=_strip_code(value).casefold().replace(' ','_').replace('-','_')
	try:return FindingCategory(normalized)
	except ValueError:0
	root=normalized.split('.',1)[0];alias=_CATEGORY_ALIASES.get(normalized)or _CATEGORY_ALIASES.get(root)
	if alias is not _A:return alias
	fallback=_DIMENSION_DEFAULT_CATEGORY[dimension];logger.warning('Unrecognized finding category, attributing to the producing dimension | dimension=%s category=%r resolved=%s',dimension.value,value,fallback.value);return fallback
def _strip_code(value:str)->str:return value.strip().strip('`*_ ').strip()