# Data Quality, Testing, and Observability

## Contents

1. Quality follows business contracts
2. Quality dimensions
3. Test layers
4. Grain and relationship tests
5. Business invariant tests
6. Metric and semantic tests
7. Incremental tests
8. Soda-style checks
9. Vulcan assertions, audits, and tests
10. Sampling and privacy
11. Threshold design
12. Observability and response
13. Coverage matrix

## Quality follows business contracts

Do not add checks merely because a tool supports them. Tie each check to:

- A business invariant.
- A model assumption.
- A consumer commitment.
- A known failure mode.
- A reconciliation equation.

Every check should identify owner, severity, expected action, and cost.

## Quality dimensions

### Completeness

Required records and fields exist.

Examples:

- No missing subscription IDs.
- Daily source partition arrived.
- All expected tenants represented.

### Uniqueness

Keys match the declared grain.

### Validity

Values satisfy type, range, format, enum, and lifecycle rules.

### Consistency

Related fields and models agree.

Examples:

- Active subscription has no end date before start.
- ARR equals defined annualization of MRR.
- Closing balance equals opening plus movements.

### Referential integrity

Foreign keys resolve under the documented late-arrival policy.

### Accuracy

Data reconciles to an authoritative system within tolerance.

### Timeliness and freshness

Data is available by the promised time and represents the expected source horizon.

### Volume and distribution

Unexpected changes in row count, null rate, distinct count, or distribution are detected.

Do not substitute anomaly detection for hard business invariants.

## Test layers

### Parser and schema validation

Validate YAML/SQL syntax, required fields, supported enums, and references.

### Unit tests

Use fixed inputs and expected outputs for deterministic transformation behavior.

Best targets:

- CASE logic.
- Deduplication.
- Lifecycle classification.
- Currency conversion.
- Date boundaries.
- Null/zero behavior.
- Incremental edge cases.

### Assertions

Attach a model-local query that returns violating rows. Use for invariants close to the transformation.

### Runtime audits

Run after production model execution. Use for keys, ranges, referential integrity, and cross-model consistency.

### DQ scans and monitoring

Use for profiles, thresholds, anomaly trends, freshness, and sampled failed rows.

### Reconciliation tests

Compare totals or states with authoritative systems and balance equations.

### Semantic and contract tests

Validate member references, joins, metric components, API parity, and backward compatibility.

## Grain and relationship tests

For every declared grain:

- Key not null.
- Key unique.
- Expected row multiplicity.

For every relationship:

- One-side uniqueness.
- Orphan count and rate.
- Fanout ratio.
- Measure preservation before/after join.
- Temporal join returns at most one version.
- Bridge allocation weights reconcile.

## Business invariant tests

Examples:

### Subscription

- Start date is present.
- End date is null or after start date.
- Active MRR is positive.
- Status transition is allowed.
- One current state per subscription.

### Usage

- Event ID is unique.
- Event time is within supported bounds.
- Event count/duration is non-negative.
- Bot/test traffic policy is applied.

### Revenue

- Currency is present.
- Amount precision is retained.
- ARR calculation matches contract.
- Opening + movements = closing within tolerance.

### Snapshot

- One row per entity-period.
- Expected entity population coverage.
- No future snapshots.

## Metric and semantic tests

Test:

- Numerator and denominator independently.
- Ratio zero/null handling.
- Stock at period boundary.
- Flow across adjacent periods.
- Average reaggregation from sum/count.
- Distinct behavior across grains.
- Filter and segment equivalence.
- Current versus historical dimension attribution.
- SQL, REST, GraphQL, and BI parity.
- Rollup result equals base result for matching queries.
- Unsupported dimension/metric combinations fail or are hidden.

Use golden query cases based on real business questions.

## Incremental tests

Cover:

- Retry same interval.
- Duplicate input.
- Late input.
- Update.
- Delete.
- Empty input.
- Backfill.
- Schema change.
- Backdated effective change.
- Partial and full restatement.

Run a periodic full reconciliation against a recomputed reference when feasible.

## Soda-style checks

Use:

- Missing, duplicate, validity, row-count, and freshness metrics.
- Failed-row checks for actionable record examples.
- Profiles to understand distributions.
- Anomaly detection for changing baselines.
- Warn/fail thresholds with business ownership.

Avoid:

- Contradictory rules for the same metric.
- Rule description that disagrees with executable threshold.
- `SELECT *` failed rows over sensitive or large tables.
- Unbounded samples.
- Arbitrary thresholds with no action.
- Expensive full-table checks on every small interval when partition-scoped checks suffice.

## Vulcan assertions, audits, and tests

### Assertions

Use model-embedded assertions for invariants tightly coupled to model logic.

### Audits

Use runtime audits to validate output after runs. Remember that incremental model audits may apply only to processed intervals; add periodic full-table checks when needed.

### Unit tests

Use YAML tests with controlled upstream rows and expected output. Test CTEs or macro variables when important.

Separate:

- Transformation correctness.
- Production data quality.
- Contract compatibility.

## Sampling and privacy

Failed rows can expose PII or secrets.

- Select diagnostic fields only.
- Mask or exclude sensitive columns.
- Set sample limits.
- Restrict access and retention.
- Store failed rows in governed diagnostics locations.
- Use aggregate failure counts when record examples are unnecessary.

## Threshold design

For each threshold, record:

- Expected normal range.
- Source and evidence.
- Warn versus fail.
- Minimum sample size.
- Seasonality.
- Grace period.
- Owner and action.
- Automatic blocking policy.

A threshold should reflect a business or operational decision. Avoid blocking a pipeline for a harmless anomaly and avoid warning on a hard contractual violation.

## Observability and response

Monitor:

- Freshness and completeness.
- Run duration and failure.
- Rows/bytes processed.
- Late and duplicate rates.
- Schema changes.
- DQ results.
- Metric reconciliation.
- Rollup/cache use.
- Consumer query errors.

Define:

- Incident severity.
- Owner and support channel.
- Consumer notification.
- Quarantine or rollback.
- Reprocessing.
- Root-cause and prevention update.

## Coverage matrix

Use columns:

| Asset | Grain/key | Completeness | Validity | Referential | Temporal | Metric | Incremental | Reconciliation | Freshness | Owner |
|---|---|---|---|---|---|---|---|---|---|---|

Prioritize high-impact invariants rather than maximizing check count.
