# Pattern Selection: Serving

Use this reference when judging how a product is exposed to its consumers and whether that exposure is safe for the interface it targets. Select patterns because they solve a demonstrated problem, not because they are fashionable.

A serving choice is a promise to a consumer: which joins are safe, which questions are answerable, and which are not. The row shape underneath belongs to structure; the metric definitions it exposes belong to semantics.

## Contents

1. Serving patterns
2. Rejection tests

## 1. Serving patterns

### Semantic model over atomic fact

Use for flexible ad hoc analysis when query cost is acceptable and joins are safe.

### Public view over private base models

Use to expose a curated contract while retaining internal cubes/models for reuse. Include only safe join paths and understandable member names.

### Purpose-built BI mart

Use when:

- A BI tool cannot safely express the relationship graph.
- Query generation repeatedly creates fanout or unsupported SQL.
- Dashboard latency/concurrency requires a stable shape.

Do not duplicate metric definitions independently; source them from the governed metric contract.

### API serving projection

Use for bounded, low-latency, paginated current-state responses. Avoid exposing unbounded high-cardinality analytical exploration as an operational API.

### AI semantic surface

Include:

- Business definitions and synonyms.
- Grain and temporal role.
- Safe dimensions and join paths.
- Metric caveats and examples.
- Explicit unsupported questions.
- PII and access restrictions.

Examples are evidence of intended use, not a substitute for validation.

### ML feature model

Require point-in-time correctness, feature timestamp, entity key, freshness, null/default behavior, and reproducible training snapshot.

## 2. Rejection tests

Reject or redesign a proposed serving surface when any of these is true:

- A serving model cannot expose safe joins to its target consumer.
- The design removes atomic evidence required for reconciliation or audit.
- A serving surface redefines a metric rather than sourcing it from the governed definition.
- An operational interface exposes unbounded analytical exploration.
- An AI-facing surface omits the questions it cannot answer.
