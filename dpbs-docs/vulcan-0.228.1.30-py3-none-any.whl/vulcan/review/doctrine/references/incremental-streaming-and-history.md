# Incremental, Streaming, and Historical Modeling

## Contents

1. Choose from source behavior
2. Incremental patterns
3. Idempotency
4. CDC and deletes
5. Late and out-of-order data
6. Backfills and restatement
7. SCD and snapshots
8. Streaming state
9. Schema evolution
10. Vulcan model-kind selection
11. Validation matrix

## Choose from source behavior

Do not choose an incremental strategy because the table is large. First establish:

- Append-only, mutable, or delete-capable source.
- Stable key.
- Event/effective/ingestion times.
- Source ordering and replay.
- Late-arrival distribution.
- Correction and backdating behavior.
- Required historical interpretation.

## Incremental patterns

### Append-only

Use for immutable events with a stable unique event key.

Risks:

- Duplicate delivery.
- Missing replay ranges.
- Corrections represented as new events or not at all.

Always deduplicate by a source identity or deterministic event key when at-least-once delivery is possible.

### Time-range overwrite

Recompute an interval and replace its output.

Use for:

- Time-partitioned facts.
- Late-arriving data within a known lookback.
- Deterministic period aggregates.

Require:

- Correct business time column.
- Input filter.
- Output interval protection.
- Idempotent logic.
- Lookback sufficient for lateness.

### Unique-key merge/upsert

Insert new and update matching rows.

Use for current-state entities and mutable records with a stable key.

Require:

- Source returns at most one winning row per key.
- Deterministic conflict ordering.
- Delete handling.
- Merge pruning for large targets where supported.

A merge does not automatically preserve history.

### Partition overwrite

Replace affected partitions as a unit.

Use when updates naturally arrive and are corrected by partition. Validate full-partition availability and restatement safety.

### Full rebuild

Use when:

- Data is small.
- Logic is non-incremental.
- Correct incremental state is harder or riskier than recomputation.
- Changes are infrequent.

Full rebuild may be cheaper operationally than complex incremental logic.

### Snapshot

Capture state periodically. Use for historical stock and comparison when source history is absent or reconstruction is expensive.

### Effective-dated SCD

Create versions from source change time or detected changes. Use for historical dimension attribution.

### Change/movement fact

Represent business deltas rather than only current rows. Use for expansion, contraction, stage movement, and lifecycle transitions.

## Idempotency

Running the same interval or batch again should produce the same intended state.

Validate:

- Deterministic keys.
- Stable deduplication order.
- No dependence on wall-clock time unless explicitly parameterized.
- No random or nondeterministic selection.
- Upstream current-state changes do not alter historical restatement unexpectedly.
- Side effects are retriable.

Use execution-time parameters rather than `CURRENT_DATE` for reproducible historical models.

## CDC and deletes

Capture:

- Insert, update, delete/tombstone.
- Source transaction position.
- Source event time.
- Before and after images if required.
- Primary-key changes.
- Snapshot/bootstrap boundary.

Decide:

- Hard delete.
- Soft delete flag.
- Effective expiration.
- Retain audit history.
- Redaction for privacy deletion.

Do not let unique-key merges leave deleted source records permanently active.

## Late and out-of-order data

Measure lateness distribution rather than guessing.

Options:

- Lookback window.
- Watermark with allowed lateness.
- Reopen affected partitions.
- State correction or compensating event.
- Quarantine records beyond the supported window.
- Scheduled deep reconciliation.

Define business behavior for:

- Event arrives after period close.
- Effective date is backdated.
- Event order changes a session or funnel.
- Dimension version arrives after the fact.
- A previously deleted record reappears.

## Backfills and restatement

A backfill plan must specify:

- Scope and time range.
- Dependency order.
- Capacity and rate limit.
- Historical source availability.
- Snapshot/metric impact.
- Data contract version.
- Validation and reconciliation.
- Consumer cutover.
- Rollback.

Do not assume current reference data can reproduce historical output.

## SCD and snapshots

### SCD Type 2 checks

- One current row per business key.
- No overlapping intervals.
- `valid_from < valid_to`.
- Stable hash/change detection.
- Correct late/backdated change handling.
- Surrogate key joins.

### Snapshot checks

- One row per entity and snapshot boundary.
- Complete expected population.
- Closing snapshot reconciles movements.
- Partial-period behavior is explicit.
- Snapshot timezone and calendar are stable.

## Streaming state

Stateful operations include:

- Deduplication.
- Sessionization.
- Windowed aggregates.
- Stream-stream joins.
- Change detection.

Define:

- State key.
- Watermark.
- Timeout/retention.
- Replay behavior.
- Checkpoint compatibility.
- Poison record handling.
- Exactly-once scope.

Do not claim end-to-end exactly once unless source, processing, sink, and side effects all support the guarantee. Prefer idempotent sinks and deterministic replay.

## Schema evolution

Plan for:

- Added nullable columns.
- Added required columns.
- Type widening or narrowing.
- Renames.
- Deleted fields.
- Semantic meaning changes.
- Enum expansion.

A syntactically compatible change can still be semantically breaking. Version contracts and metrics when meaning changes.

## Vulcan model-kind selection

Verify the active Vulcan version and engine.

### FULL

Use for complete recomputation when cost and dependencies permit it.

### VIEW

Use for lightweight logic where query-time compute and dependency behavior are acceptable.

### INCREMENTAL_BY_TIME_RANGE

Use for deterministic time-bounded processing. Filter upstream input with interval macros and keep the time column in UTC as required by Vulcan guidance.

### INCREMENTAL_BY_UNIQUE_KEY

Use for upsert semantics. Ensure the query has no duplicate keys and define delete behavior separately.

### SCD Type 2 kinds

Use for effective history. Account for storage growth and restatement restrictions.

### INCREMENTAL_BY_PARTITION

Use only when loading by partition is specifically required; understand restatement limitations.

### INCREMENTAL_UNMANAGED

Use for append-only unmanaged semantics when appropriate. Treat non-idempotent restatement carefully.

### SEED, EXTERNAL, EMBEDDED, MANAGED

Use for their specific purposes. Do not use embedded logic when repeated query expansion creates excessive compute; do not rely on managed black boxes without understanding lifecycle and portability.

## Validation matrix

Test at least:

| Scenario | Expected validation |
|---|---|
| Duplicate source key | deterministic winner or failure |
| Empty interval | no corruption |
| Retry same interval | same output |
| Late record | included within supported policy |
| Record beyond lookback | alert/quarantine/reconciliation |
| Update | target row changes correctly |
| Delete | target removal/expiration policy |
| Backdated change | historical intervals/snapshots corrected |
| Schema addition | compatible handling |
| Type change | contract failure or controlled migration |
| Full backfill | reconciliation and capacity plan |
| Partial restatement | supported by model kind and dependencies |
