# Pattern Selection: Structure

Use this reference after establishing the business question, grain, lifecycle, history requirement, workload, and serving interface. Select patterns because they solve a demonstrated problem, not because they are fashionable.

This covers the patterns the structure boundary owns: how rows are shaped, how they relate across a dependency edge, and how they are physically materialized. Metric and computation patterns belong to semantics; serving patterns belong to contract.

## Contents

1. Decision sequence
2. Business need to model pattern
3. History and time patterns
4. Relationship patterns
5. Physical optimization patterns
6. Combination patterns
7. Rejection tests

## 1. Decision sequence

Apply these questions in order:

1. What decision or business question must be supported?
2. What real-world process creates the data?
3. What does one row need to represent?
4. Is the requirement about an event, a state, a movement, an eligibility, or a relationship?
5. Is the question about now, a past point in time, a period, or a sequence?
6. Which facts and dimensions are needed at event time?
7. Which aggregations are valid across dimensions and time?
8. How often is the result queried, and at what latency and freshness?
9. What data volume, concurrency, and cost constraints apply?
10. Which serving interface will consume it?

Do not choose a physical pattern before questions 1–7 are answered.

## 2. Business need to model pattern

| Need | Preferred core pattern | Optional serving pattern | Primary risk to validate |
|---|---|---|---|
| Current attributes of an entity | Current-state entity table | Flattened dimension or API projection | Overwriting history needed later |
| Individual immutable activity | Atomic transaction/event fact | Daily aggregate | Duplicate or late events |
| Mutable operational records | Upsert current-state table plus change history | Current-state serving view | Lost changes and delete semantics |
| State at regular points in time | Periodic snapshot fact | Month-end aggregate | Snapshot timing and semi-additivity |
| Process with known milestones | Accumulating snapshot | SLA/cycle-time mart | Reopened or looping processes |
| Changes in balance or value | Movement fact | Monthly movement aggregate | Double counting opening/closing balance |
| Multi-valued membership | Bridge table | Flattened assignment view | Fanout and allocation weighting |
| Eligibility or exposure | Factless fact | Eligibility aggregate | Invalid denominator |
| Event-time descriptive history | SCD Type 2 or fact-stamped attributes | Current and historical views | Range-join cost and overlapping intervals |
| Multiple independent facts | Fact constellation with conformed dimensions | Purpose-built aggregate-before-join mart | Fact-to-fact multiplication |
| Repeated expensive distinct count | Entity-period fact | Exact aggregate or sketch | Reaggregation across periods |
| Repeated sessionization | Session fact | Session daily aggregate | Late events changing session boundaries |
| Funnel progression | Journey/funnel-state fact | Funnel aggregate | Event ordering and conversion window |
| Retention | Cohort assignment plus entity-period activity | Cohort-age aggregate | Denominator and reactivation semantics |
| Marketing attribution | Touchpoint, conversion, and allocation fact | Attribution aggregate | Model/window versioning |
| Point-in-time ML features | Effective-dated feature history | Training snapshot | Leakage and training-serving drift |
| Reconciled finance reporting | Locked-period ledger/movement facts | Certified financial mart | Restatement, currency, and audit trail |
| Low-latency current lookup | Current-state serving table | Cache/indexed API store | Staleness and dual-write consistency |

## 3. History and time patterns

### Current-state table

Use when consumers need the latest known state and historical restatement is acceptable.

Require:

- One row per stable business key.
- Deterministic conflict resolution.
- Update and delete semantics.
- `updated_at` or source sequence evidence.
- Explicit statement that past values are not preserved.

Reject as the sole model when questions ask “as of,” “when changed,” “before/after,” migration, expansion, contraction, or historical attribution.

### Append-only event or transaction fact

Use when each row represents an immutable occurrence.

Require:

- Event identity or a defensible deduplication key.
- Event/effective time separate from ingestion time.
- Late-arrival policy.
- Correction/reversal strategy.
- Source replay and idempotency behavior.

Prefer preserving the lowest useful atomic grain, then derive replaceable aggregates.

### Effective-dated history / SCD Type 2

Use when descriptive attributes must reflect their value at a past point in time.

Require:

- Stable natural key and version key.
- Non-overlapping validity intervals.
- Agreed inclusive/exclusive boundary convention.
- Current-row indicator or open-ended `valid_to` convention.
- Delete representation.
- As-of join strategy.

Avoid when all consumers intentionally restate history using latest attributes and no audit requirement exists.

### Periodic snapshot fact

Use for stocks such as balances, active contracts, inventory, headcount, pipeline, or ARR at a scheduled boundary.

Require:

- Snapshot grain and cadence.
- Boundary timezone and completion rule.
- Missing snapshot policy.
- Restatement/backfill policy.
- Period treatment for downstream metrics.

Choose daily snapshots when intra-month questions or late corrections need daily recovery. Choose month-end snapshots when only certified period reporting is required and daily reconstruction is unnecessary.

### Movement fact

Use when the business asks why a stock changed.

Examples:

- New ARR
- Expansion
- Contraction
- Churn
- Reactivation
- FX movement
- Inventory receipts and issues

Require a balancing equation such as:

```text
closing_stock = opening_stock + inflows - outflows +/- adjustments
```

Store movement category, effective time, prior value, new value, and delta where available.

### Accumulating snapshot

Use for a bounded process with recognizable milestones, such as lead-to-order or order-to-delivery.

Require:

- Stable process identifier.
- Milestone timestamps.
- Current state.
- Reopen/rework rules.
- Event history if every transition must remain auditable.

Do not use alone for highly cyclic workflows.

## 4. Relationship patterns

### Star schema

Use as the default analytical serving shape when one fact can be described by reusable dimensions.

Strengths:

- Explicit grain.
- Predictable one-to-many joins.
- Good BI usability.
- Reusable conformed dimensions.

Validate every dimension key at the fact grain and every historical dimension choice.

### Snowflaked dimension

Use when a hierarchy or reference structure has independent governance, high reuse, or meaningful maintenance savings.

Flatten for consumer serving when extra joins make BI behavior or performance fragile.

### Bridge table

Use for many-to-many or multi-valued membership.

Require:

- Bridge grain.
- Validity dates when membership changes.
- Allocation weight when measures must be allocated.
- Weight reconciliation to 1 per entity/period where required.
- Separate “membership” from “primary assignment” semantics.

### Aggregate-before-join mart

Use when two facts must be compared at a shared grain.

Example:

```text
subscription revenue per customer-month
+
usage per customer-month
-> customer_month_health
```

Require independent aggregation and reconciliation before joining. Never join raw facts by customer merely because both contain `customer_id`.

### Event-time assignment table

Use when an event must be attributed to the entity state valid at that time and repeated range joins are expensive.

Examples:

- User plan at usage-event time.
- Sales territory at booking time.
- Product category version at transaction time.

Materialize the assignment only after validating temporal boundaries and late corrections.

## 5. Physical optimization patterns

### Incremental by time range

Choose for immutable or append-dominant time-series data. Require a bounded source filter, idempotent interval replacement, lookback for late data, and backfill behavior.

### Incremental by unique key

Choose for mutable records with reliable keys. Require deterministic ordering, update/delete handling, merge conflict rules, and full-refresh escape path.

### Partition overwrite

Choose when corrections are naturally bounded by partitions. Rebuild affected partitions rather than merging individual rows when this is simpler and reliable.

### Partitioning

Choose columns that are commonly filtered and create reasonably sized partitions. Avoid extreme high-cardinality partition keys and tiny partitions.

### Clustering/sorting/bucketing

Choose based on actual filters, joins, data skipping, skew, and maintenance cost. Reassess as workloads evolve.

### Materialized view

Choose when the engine can maintain a stable repeated query more efficiently than the transformation framework. Verify refresh semantics, optimizer rewrite behavior, limitations, and operational ownership.

### Cache

Use for repeated identical or near-identical queries with an explicit TTL and invalidation contract. Never use cache to hide a logically invalid model.

### Hot/warm/cold separation

Choose when recent interactive data and long-term history have materially different latency requirements. Keep logical continuity and transparent retrieval boundaries.

## 6. Combination patterns

Experienced designs often combine patterns:

### SaaS revenue

```text
subscription_events
-> subscriptions_current
-> subscription_daily_snapshot
-> subscription_movements
-> revenue_monthly_rollup
-> semantic revenue metrics
```

### Product engagement

```text
usage_events
-> sessions
-> user_feature_day
-> feature_usage_daily
-> DAU/WAU/MAU and adoption semantic metrics
```

### Customer health

```text
customer dimension history
+ customer-month revenue aggregate
+ customer-month usage aggregate
+ customer-month support aggregate
-> customer_month_health
```

### Finance

```text
journal/transaction atomic facts
-> normalized movements
-> locked-period balances
-> certified statement mart
```

## 7. Rejection tests

Reject or redesign a proposed pattern when any of these is true:

- Grain remains implicit.
- A table mixes unrelated facts at different grains.
- Current state is presented as historical truth.
- A snapshot has no boundary or restatement rule.
- A bridge introduces unallocated duplication.
- Two facts are joined before compatible aggregation.
- An incremental model cannot recover from late data, updates, deletes, or backfills.
- A materialization has no demonstrated workload or freshness need.
