# Operating Model for Data Modeling Reviews

## Contents

1. Purpose
2. Review perspectives
3. Decision hierarchy
4. Evidence and confidence
5. Review modes
6. Ownership and handoffs
7. Severity model
8. Completion rules

## Purpose

Run modeling work as a multidisciplinary decision process. A technically valid table may still be commercially misleading, historically incorrect, too expensive, insecure, or unusable through BI and APIs. Combine the perspectives below into one recommendation.

## Review perspectives

### Data Analyst perspective

Own the interpretation of business questions and user experience.

Establish:

- Decisions users will make.
- Business vocabulary and competing definitions.
- Required dimensions, filters, drill paths, comparisons, and time periods.
- Expected reconciliation with current reports.
- Acceptable approximation and latency.
- Meaningful defaults and caveats.

Block when:

- The requested metric has no agreed business meaning.
- A proxy is presented as the requested outcome without disclosure.
- A dashboard or API result would answer a materially different question.

### Analytics Engineer perspective

Own analytical structure and reusable logic.

Establish:

- Business process and one-row grain.
- Fact, dimension, bridge, snapshot, aggregate, and mart boundaries.
- Join cardinality and fanout controls.
- Additivity, stock/flow, ratio, and reaggregation behavior.
- Semantic models, metrics, segments, and public interfaces.
- Tests for transformation and metric behavior.

Block when:

- Grain is unknown or violated.
- Independent facts are joined at an incompatible grain.
- A non-additive measure is exposed without safe aggregation behavior.
- Semantic definitions conflict with physical logic.

### Data Engineer perspective

Own production behavior and physical integrity.

Establish:

- Source ownership and update semantics.
- Natural and surrogate keys.
- CDC, batch, streaming, delete, and late-arrival behavior.
- Incremental strategy, idempotency, backfills, and restatement.
- Partitioning, clustering, file layout, and execution cost.
- Reliability, observability, and recovery.

Block when:

- Incremental logic can silently lose, duplicate, or permanently omit data.
- Required history is overwritten.
- Keys are not stable enough for the chosen merge or SCD strategy.
- Operational failure modes have no recovery path.

### Semantic and BI Engineer perspective

Own consumer-safe exposure.

Establish:

- Public versus private models.
- Safe join paths and relationship direction.
- Tableau, Power BI, Cube, SQL, REST, and GraphQL behavior.
- High-cardinality and expensive-member exposure.
- Rollup matching and drill-through behavior.
- AI metadata, examples, and query guardrails.

Block when:

- Cycles or reciprocal joins create ambiguous BI models.
- A public metric can be reaggregated incorrectly.
- API interfaces expose inconsistent definitions.
- AI-facing metadata encourages unsafe joins or unsupported questions.

### Data Product Owner and Steward perspective

Own accountability and consumer commitments.

Establish:

- Domain and product boundary.
- Authoritative definitions and owners.
- SLA, support, issue, and deprecation process.
- Classification, retention, residency, and access policy.
- Permitted uses and known limitations.

Block when:

- No owner can approve a definition or breaking change.
- Sensitive data is exposed without an enforceable policy.
- Consumer commitments cannot be met or measured.

## Decision hierarchy

Resolve trade-offs in this order:

1. Business truth and legal obligations.
2. Grain, temporal, and metric correctness.
3. Data integrity, reproducibility, and auditability.
4. Consumer safety and compatibility.
5. Reliability and operational recoverability.
6. Performance and cost.
7. Developer convenience and elegance.

A cheaper design is not an improvement if it changes the answer. A more normalized design is not an improvement if every consumer implements unsafe joins. A faster semantic query is not an improvement if it aggregates a stock or ratio incorrectly.

## Evidence and confidence

### Evidence classes

- **Observed:** Directly present in source code, schema, data profile, query log, plan, test, or official documentation.
- **Derived:** Logically follows from observed grain, keys, joins, or metric definitions.
- **Assumed:** Plausible but not confirmed.
- **Unknown:** Required information is absent or conflicting.

### Confidence labels

- **High:** Confirmed by multiple consistent evidence sources.
- **Medium:** Supported by one strong source or several indirect signals.
- **Low:** Inferred primarily from names, examples, or conventions.

Attach evidence and confidence to consequential findings. Do not present low-confidence inferences as defects.

## Review modes

### Existing project review

Prioritize:

- Inventory and dependency graph.
- Inconsistencies across SQL, semantics, metrics, DQ, tests, and policies.
- Business-question feasibility.
- Migration-safe corrections.

### New model design

Prioritize:

- Business processes and question catalog.
- Grain and source capability.
- Target table patterns.
- Metric and temporal contracts.
- Cost model and serving interfaces.

### Change review

Prioritize:

- Semantic diff, not only file diff.
- Row count and grain changes.
- Metric output and historical restatement.
- Compatibility and deprecation.
- Backfill and rollback.

### Cost review

Prioritize:

- Actual frequency, scans, shuffle, sorts, state, and concurrency.
- Repeated calculations.
- Refresh and maintenance cost.
- Targeted, reversible materialization.

## Ownership and handoffs

| Decision | Primary owner | Required reviewers |
|---|---|---|
| Business definition | Domain owner / analyst | Analytics engineer, steward |
| Grain and fact design | Analytics engineer | Data engineer, analyst |
| Source lifecycle and CDC | Data engineer | Analytics engineer |
| Metric aggregation | Analytics engineer | Analyst, semantic engineer |
| Public semantic exposure | Semantic/BI engineer | Analytics engineer, steward |
| Quality threshold | Domain owner | Data engineer, analyst |
| Physical optimization | Data engineer | Analytics engineer, platform owner |
| Contract and SLA | Product owner / steward | Data engineer, consumers |
| Breaking change | Product owner | All affected owners |

No role should approve its own high-risk assumption without a second perspective.

## Severity model

### Blocker

The design cannot produce a trustworthy or operable result.

Examples:

- Missing or contradictory grain.
- Ratio without numerator or denominator.
- Unbounded many-to-many financial aggregation with no allocation rule.
- Incremental merge with no stable key.
- Sensitive data publicly exposed without policy.

### High

Likely to produce materially wrong answers, data loss, or major consumer breakage.

Examples:

- Current-state attribute used for historical attribution without disclosure.
- Stock metric indexed by an event-start date as historical balance.
- Cross-fact metric with no compatible-grain design.
- Reciprocal BI relationships exposed in both directions.

### Medium

Important maintainability, quality, compatibility, or cost risk requiring resolution.

Examples:

- Sparse tests around high-risk logic.
- Contradictory DQ prose and threshold.
- Expensive exact distinct with no workload plan.
- SELECT * at a contract boundary.

### Low

Improvement with limited immediate correctness impact.

### Info

Observation or optimization candidate requiring workload evidence.

## Completion rules

Complete a review only when:

- Every material conclusion names its evidence.
- Unknowns and assumptions are explicit.
- Business-answerability includes unsupported and misleading questions.
- Recommendations specify the intended grain and semantic change.
- Cost recommendations identify workload evidence or the measurements still required.
- Generated artifacts agree with the written design.
- The migration plan explains backfill, validation, compatibility, and rollback.
