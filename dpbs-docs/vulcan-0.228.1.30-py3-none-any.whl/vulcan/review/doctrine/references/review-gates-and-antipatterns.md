# Review Gates and Anti-Patterns

## Contents

1. Approval gates
2. Blocker conditions
3. Anti-pattern catalog
4. Severity discipline
5. Review scorecard
6. Final decision

## Approval gates

### Gate 1: Business intent

Pass when:

- Decisions, consumers, and priority questions are known.
- Definitions and owners exist for material metrics.
- Proxies and out-of-scope questions are explicit.

### Gate 2: Grain and keys

Pass when:

- Every model has one clear grain.
- Keys match the grain and source lifecycle.
- Duplicate and null behavior is validated.

### Gate 3: Temporal correctness

Pass when:

- Event, effective, ingestion, snapshot, and reporting time are distinguished.
- Historical questions have history.
- Current-state restatement is disclosed.

### Gate 4: Relationships

Pass when:

- Cardinality and referential integrity are evidenced.
- Fanout and row preservation are controlled.
- Public join paths are unambiguous.

### Gate 5: Measures and metrics

Pass when:

- Additivity, stock/flow, ratio, average, distinct, and time behavior are explicit.
- Numerators, denominators, and populations exist.
- Reaggregation is safe.

### Gate 6: Answerability

Pass when:

- Required questions are classified.
- Unsupported and misleading questions are documented.
- Missing capabilities have a plan or accepted limitation.

### Gate 7: Incremental and operational behavior

Pass when:

- Updates, deletes, late data, retries, backfills, and schema changes are handled.
- The model is reproducible and recoverable.

### Gate 8: Quality and reconciliation

Pass when:

- Grain, lifecycle, referential, temporal, and metric invariants are tested.
- Critical totals reconcile.
- Alert ownership and response exist.

### Gate 9: Cost and performance

Pass when:

- Workload evidence exists or a measurement plan is defined.
- Materialization and layout costs are considered.
- Optimizations preserve semantics.

### Gate 10: Serving and governance

Pass when:

- BI/API/AI/ML behavior is safe.
- Policies are enforceable.
- Ownership, SLA, versioning, and deprecation are defined.

## Blocker conditions

Block approval for:

- Unknown or mixed grain.
- Metric with no business definition.
- Ratio without numerator/denominator.
- Historical stock with no history.
- Fact-to-fact fanout affecting material measures.
- Many-to-many financial allocation with no bridge/weight policy.
- Incremental merge without a stable key.
- Data-loss path for deletes or restatement.
- Public sensitive data without enforceable policy.
- Contract prose contradicting executable logic.

## Anti-pattern catalog

### Model-first without questions

Designing tables before knowing the decisions creates unused or misleading structures.

### One table for current state, events, and history

Mixes grains and cannot answer temporal questions reliably.

### One Big Table as universal architecture

Often hides fanout, duplicated attributes, full rebuilds, and ambiguous grain.

### Normalize everything for BI

Creates long join chains, repeated shuffle, poor discoverability, and consumer-specific logic.

### Precompute everything

Creates aggregate explosion, refresh cost, stale logic, and unused tables.

### Query-time everything

Repeatedly pays for sessionization, temporal joins, funnels, and complex business logic.

### Current dimension applied to historical fact

Rewrites history silently.

### Start date used as stock history

Grouping current ARR by subscription start date describes cohort/booked context, not period-end ARR.

### Count presented as rate

Retention, churn, adoption, and conversion require eligible denominators.

### Stored ratio averaged later

Produces mathematically invalid results.

### Exact distinct exposed at every grain

Can be both expensive and non-reaggregatable.

### Fact-to-fact join on customer/user

Multiplies both facts unless aggregated to compatible grain.

### Join metadata guessed from names

Incorrect cardinality hints can cause duplicated or missing BI results.

### Reciprocal joins exported to BI

Creates cycles or ambiguity. Keep one intentional public direction or separate views.

### Incremental without late-data or delete policy

Makes incorrect results permanent.

### SCD Type 2 everywhere

Creates unnecessary storage, merge, and temporal-join complexity.

### Partition by high-cardinality identifier

Creates tiny partitions and metadata overhead.

### SELECT * at curated boundary

Makes schema drift and lineage unpredictable.

### DQ rule count as quality strategy

Many generic checks do not replace a few high-value business invariants and reconciliations.

### Contradictory DQ rule

Example: `missing_count(user_id) = 1` named `no_missing_user_ids`.

### AI metadata as correctness layer

Descriptions cannot repair bad grain, joins, or metrics.

### Performance change without benchmark

Clustering, materialized views, and rollups can cost more to maintain than they save.

## Severity discipline

Use blocker/high only for material correctness, data loss, security, or consumer breakage. Do not mark every best-practice deviation as high severity.

For each finding include:

- Evidence.
- Consequence.
- Affected business questions.
- Recommended fix.
- Validation method.
- Residual trade-off.

## Review scorecard

Score each area 0-3:

- 0: absent or unsafe.
- 1: partially defined, high uncertainty.
- 2: adequate with known improvements.
- 3: strong evidence and operationalized.

Areas:

```text
business definitions
grain and keys
temporal/history
relationships/fanout
measures/metrics
answerability
incremental/recovery
quality/reconciliation
performance/cost
serving compatibility
governance/security
documentation/AI context
```

Do not turn the score into an automatic approval. A single blocker overrides a high average.

## Final decision

Use one:

- **Approved:** No relevant blockers or high risks; acceptance criteria pass.
- **Approved with conditions:** Safe for defined scope after named conditions, monitoring, or limitations.
- **Redesign required:** Material correctness or operability issues require structural change.
- **Insufficient evidence:** Critical data, business, or workload evidence is unavailable; provide the exact validation plan.
