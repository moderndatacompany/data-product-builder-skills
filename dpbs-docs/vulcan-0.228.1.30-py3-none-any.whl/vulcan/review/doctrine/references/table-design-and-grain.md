# Table Design and Grain

## Contents

1. Grain first
2. Table pattern taxonomy
3. Keys
4. Facts and dimensions
5. Column design
6. Current state and history
7. Normalization and denormalization
8. Wide serving models
9. Grain validation
10. Table assessment template

## Grain first

State grain as a sentence:

> One row per [business object or event] per [time/version/context].

Examples:

- One row per user.
- One row per subscription contract.
- One row per subscription change event.
- One row per user per activity date.
- One row per account per month-end snapshot.
- One row per order line.
- One row per customer-segment membership validity interval.

A column belongs in a table only when its meaning is valid at that grain. A measure can be summed only when its additivity is valid at that grain.

## Table pattern taxonomy

### Entity or dimension table

Represents a durable business object such as customer, product, plan, employee, or account.

Use for:

- Descriptive attributes.
- Classification.
- Current state or effective-dated versions.
- Reusable conformed dimensions.

Do not assume current attributes provide historical attribution.

### Transaction fact

One row per indivisible transaction or line.

Examples:

- Payment.
- Invoice line.
- Order line.
- Shipment.
- Subscription charge.

Use for additive flows and audit detail.

### Event fact

One row per observed event.

Examples:

- Login.
- API request.
- Feature use.
- Status transition.

Include stable event identity, event time, ingestion time, source, entity keys, and event attributes. Preserve event order when funnels or sessionization are required.

### Periodic snapshot fact

One row per entity per fixed period boundary.

Examples:

- Subscription per day.
- Account per month-end.
- Inventory item per hour.

Use for historical stock and period-end state. Accept storage growth in exchange for simple, reliable historical balance queries.

### Accumulating snapshot fact

One row per process instance updated as milestones occur.

Examples:

- Order fulfillment lifecycle.
- Loan application pipeline.
- Support ticket resolution.

Use for known, mostly linear processes and cycle-time analysis. Retain an event history when loops or full transition audit are important.

### Factless fact

Records participation, eligibility, exposure, assignment, or coverage without a numeric measure.

Examples:

- User eligible for feature.
- Student attended class.
- Account included in campaign.

Factless facts often supply denominators that event tables cannot provide.

### Bridge table

Resolves legitimate many-to-many relationships.

Examples:

- Account to owner.
- Customer to segment.
- Product to category.

Include validity intervals and allocation weights when the relationship changes or measures must be allocated.

### Current-state table

Stores the latest known state per entity.

Use for operational lookup and current dashboards. Do not use as historical truth unless overwriting history is explicitly intended.

### Change or movement fact

Stores business changes and their deltas.

Examples:

- Subscription expansion or contraction.
- Inventory movement.
- Pipeline stage movement.

Use when reporting change volume and cause is more important than repeatedly diffing snapshots.

### Aggregate fact

Stores measures at a higher grain for a targeted workload.

Examples:

- Feature usage per day and plan.
- Revenue per month and region.

Retain atomic facts as the source of truth. Document which dimensions and measures the aggregate can safely reaggregate.

### Reference or lookup table

Small, governed code set or mapping.

Examples:

- Country code.
- Plan type.
- Status mapping.

Version mappings when historical interpretation can change.

### Serving model or mart

Consumer-oriented representation, often denormalized or aggregated.

Use for stable BI/API experiences. Do not let the serving model replace atomic or historical truth unless that loss is acceptable.

## Keys

### Natural key

Business or source identifier with domain meaning.

Validate:

- Stability.
- Uniqueness scope.
- Reuse.
- Nullability.
- Cross-source collisions.
- Case and whitespace normalization.

### Surrogate key

Warehouse-generated identifier.

Use for:

- SCD Type 2 versions.
- Multi-source integration.
- Unknown/default members.
- Compact joins.

Retain the natural key for traceability.

### Composite key

Use all columns required by the grain. Do not substitute a convenient partial key.

Example:

```text
Grain: one row per user per feature per activity_date
Key: user_id + feature_id + activity_date
```

### Degenerate dimension

A business identifier retained directly on a fact without a separate dimension, such as invoice number or order number.

### Unknown members

Decide whether missing foreign keys should:

- Fail quality checks.
- Map to an explicit unknown member.
- Remain null.
- Be quarantined until reference data arrives.

Do not silently coalesce unrelated missing states.

## Facts and dimensions

Distinguish:

- Numeric facts generated by the business process.
- Descriptive dimensions used to slice facts.
- Derived attributes computed from stable logic.
- Labels or categories that can change historically.
- Identifiers needed for drill and reconciliation.

Avoid copying high-churn descriptive attributes into large facts unless event-time attribution, query performance, or immutable source capture justifies it.

## Column design

### Required metadata for important columns

- Business description.
- Data type and precision.
- Unit and currency.
- Null meaning.
- Default behavior.
- Source and derivation.
- Classification.
- Valid values or range.
- Temporal meaning.

### Data types

- Use decimal types for money when exact arithmetic is required.
- Store currency code with monetary value unless the table is contractually single-currency.
- Use UTC for system timestamps and retain source timezone when needed.
- Avoid generic strings for structured values in curated layers.
- Cast explicitly at model boundaries.
- Distinguish date from timestamp and local business date from UTC instant.

### Derived columns

Precompute stable, frequently used, expensive, and cross-tool business logic. Keep parameterized, volatile, or cheap logic at query time when appropriate.

Every derived column should name its source fields and business rule.

## Current state and history

Use separate structures when questions require both:

```text
atomic change events
+ current-state table
+ optional periodic snapshot
```

Examples:

- Current subscription answers current ARR.
- Subscription change events answer expansion/contraction.
- Monthly subscription snapshots answer period-end ARR.

One overwriting table cannot reliably answer all three.

## Normalization and denormalization

### Normalize when

- Entity integrity and reuse dominate.
- Attributes change independently.
- Multiple products consume the core.
- Duplication would cause inconsistent logic.

### Denormalize when

- A stable serving grain is clear.
- Joins are repeated and expensive.
- BI usability requires a curated flat surface.
- Event-time attributes should be frozen.
- The duplicated attributes have controlled derivation.

Use a normalized or atomic core plus denormalized serving models rather than choosing one universally.

## Wide serving models

Approve a wide table only when:

- It has one explicit grain.
- Every measure is valid at that grain.
- Fact-to-fact fanout is resolved before construction.
- Attribute history semantics are explicit.
- Incremental refresh is tractable.
- Consumers and required dimensions are known.
- The source-of-truth layer remains recoverable.

Reject a wide table used as a dumping ground for unrelated facts.

## Grain validation

Use data evidence:

```sql
SELECT key_columns, COUNT(*)
FROM model
GROUP BY key_columns
HAVING COUNT(*) > 1;
```

Also test:

- Null keys.
- Reused identifiers.
- Source duplicates.
- Different records collapsed by transformations.
- Multiple lifecycle episodes.
- Date-boundary and timezone collisions.

A uniqueness test does not prove the grain is conceptually correct. It only shows the chosen key is unique in observed data.

## Table assessment template

For each table, report:

```text
Name:
Business purpose:
Owner:
Table pattern:
One-row grain:
Primary/candidate keys:
Foreign keys:
Lifecycle and mutation:
Temporal columns:
Current versus historical meaning:
Facts:
Dimensions:
Safe aggregations:
Unsafe aggregations:
Directly answerable questions:
Conditional/partial questions:
Not answerable questions:
Expected volume and growth:
Incremental strategy:
Partition/clustering candidate:
Quality and reconciliation:
Security classification:
Consumers:
Risks and recommended changes:
```
