# Measures, Metrics, and Semantic Modeling

## Contents

1. Definitions
2. Additivity
3. Stock and flow
4. Ratio and average behavior
5. Distinct counts
6. Time semantics
7. Metric types
8. Semantic model design
9. Cross-model metrics
10. Reaggregation and rollups
11. Metric contract
12. Common invalid patterns

## Definitions

### Dimension

Descriptive or identifying field used to filter, group, drill, or join.

Classify dimensions as:

- Identifier.
- Categorical.
- Temporal.
- Geographic.
- Ordinal.
- Degenerate identifier.
- High-cardinality drill field.

### Measure

Aggregation over rows of a semantic model.

Examples:

- Sum of revenue.
- Count of subscriptions.
- Distinct users.
- Average duration.

### Metric

Business-level definition binding one or more measures to time, dimensions, filters, populations, and interpretation.

### Segment

Reusable boolean population definition. Treat segment time semantics explicitly: current segment versus segment at event time.

## Additivity

### Additive

Can be summed across all relevant dimensions.

Examples:

- Transaction amount in one currency.
- Units shipped.
- Event count.

### Semi-additive

Can be summed across some dimensions but not time.

Examples:

- Account balance.
- Inventory level.
- Current ARR.
- Active seats.

Require first, last, period-end, average, minimum, or maximum treatment over time.

### Non-additive

Cannot be summed directly.

Examples:

- Ratio.
- Average.
- Median or percentile.
- Distinct count across overlapping groups.

Expose reaggregatable components whenever possible.

## Stock and flow

### Flow

Activity occurring during an interval.

Examples:

- New subscriptions.
- Cancellations.
- Revenue booked.
- API calls.

Flows are usually additive across adjacent non-overlapping periods.

### Stock

State at a point in time.

Examples:

- Active subscriptions.
- ARR.
- Inventory.
- Balance.

A stock measure contract requires:

```text
time_dimension
period_grain
period_treatment
valid snapshot/effective source
```

Do not infer historical stock from an entity start date.

## Ratio and average behavior

### Ratio

Define:

- Numerator.
- Denominator.
- Eligible population.
- Time period.
- Grain.
- Filters and exclusions.
- Zero and null behavior.

Correct reaggregation:

```text
SUM(numerator) / SUM(denominator)
```

Incorrect reaggregation:

```text
AVG(precomputed_ratio)
```

unless a mathematically valid weighting is supplied.

### Average

Retain sum and count components for weighted reaggregation.

Example:

```text
average_order_value = total_order_value / order_count
```

Do not average store-level average order values without order-count weighting.

## Distinct counts

Exact distinct counts are non-additive across overlapping groups and can be expensive.

Patterns:

- Deduplicated entity-period fact: one row per user per day.
- Exact aggregate at a fixed grain.
- Mergeable sketch for approximate distinct.
- Query-time exact distinct for low-volume or infrequent workloads.

Document:

- Exact or approximate.
- Error characteristics.
- Valid time grains.
- Whether distinct values overlap across dimensions.

DAU, WAU, and MAU are different metrics. Summing DAU does not produce MAU.

## Time semantics

Every metric needs:

- Business time dimension.
- Default grain.
- Allowed grains.
- Timezone and calendar.
- Complete versus partial period behavior.
- Current-state or historical attribution.
- Lookback or window.

A metric using a measure from one fact and a time dimension from another requires explicit compatible-grain and join proof.

## Metric types

### Simple aggregate

One measure with filters and dimensions.

### Ratio

Components aggregated before division.

### Cumulative

Running value from a defined start or window. Clarify reset behavior and late-data restatement.

### Rolling

Window such as trailing 7 or 30 days. Clarify inclusive boundaries, partial windows, and distinct behavior.

### Conversion

Requires eligible/exposed population, qualifying event, attribution window, and deduplication rule.

### Funnel

Requires ordered stages, entity or journey grain, event order, timeout/window, and repeated-event handling.

### Retention

Requires cohort entry, observation period, eligibility, activity definition, denominator, and cohort age. Distinguish retained count, retention rate, and survival probability.

### Churn

Requires unit of analysis, churn event, denominator, effective date, reactivation, voluntary/involuntary policy, and gross/net definition.

### Movement metric

New, expansion, contraction, churn, and reactivation should reconcile opening to closing state.

### Statistical metric

Median, percentile, standard deviation, and distribution metrics require clear population, null handling, and merge/reaggregation limitations.

## Semantic model design

### Model one business entity or fact per base semantic model

Expose:

- Stable identifiers.
- Useful dimensions.
- Valid time dimensions.
- Measures grounded at the model grain.
- Segments with explicit semantics.
- Directed joins with known cardinality.

Keep internal models private and expose audience-oriented views or metrics.

### Member metadata

For important members, provide:

- Title.
- Description.
- Business owner.
- Synonyms.
- Caveats.
- Examples for supported interfaces.
- Tags and glossary terms.
- Security classification.
- Cost or filter guidance when relevant.

### AI context

Explain:

- Which questions the model should answer.
- Preferred time dimension.
- Safe dimensions.
- Required segments or filters.
- Non-additive behavior.
- Unsupported or misleading questions.
- Exact query examples.

AI context cannot repair an incorrect physical model. It must describe enforceable semantics.

For the complete distinction between descriptions, AI context, tags, and terms,
artifact-specific expectations, and metadata-quality severity, use
[Semantic metadata and AI context](semantic-metadata-and-ai-context.md). This
section defines the semantic information a measure needs; the dedicated
reference defines whether that information is communicated well.

## Cross-model metrics

Approve only when:

- One unambiguous join path exists.
- The measure and dimensions share a compatible target grain.
- Event-time/current-state attribution is explicit.
- Fanout is prevented.
- Null and unmatched behavior is defined.
- The metric can be tested against a purpose-built SQL reference.

Prefer a derived fact or mart when the metric repeatedly combines independent facts.

## Reaggregation and rollups

A rollup is safe when incoming queries can aggregate its stored state without changing meaning.

Store:

- Additive measures directly.
- Sum and count for averages.
- Numerator and denominator for ratios.
- Fixed-grain exact distinct only for that grain, or mergeable sketches.
- Period-end/first/last state for stocks with explicit time grain.

Validate rollups by comparing representative base and rollup queries across dimensions, filters, late data, and partial periods.

## Metric contract

Use this structure:

```text
Metric name:
Business question:
Owner:
Definition:
Unit of analysis:
Base fact and grain:
Measure type:
Numerator:
Denominator:
Eligible population:
Filters/exclusions:
Time dimension:
Default and allowed grains:
Timezone/calendar:
Stock/flow/additivity:
Reaggregation:
Exact/approximate:
Required dimensions and join paths:
Freshness:
Reconciliation source and tolerance:
Examples:
Caveats and unsafe uses:
Version and compatibility:
```

## Common invalid patterns

- `count(10)` or another placeholder expression presented as a ratio.
- ARR grouped by subscription start month presented as historical period-end ARR.
- Active users by signup cohort presented as retention rate.
- Users who used a feature presented as adoption rate without eligible users.
- Cancellation share presented as churn rate without a period denominator.
- Average of averages without weighting.
- Sum of daily distinct users across a month.
- Current plan used for past events without disclosure.
- A measure from one fact paired with a time dimension from another fact without a compatible-grain model.
- Ratio or stock included in a rollup without component or period semantics.
- Different SQL, REST, GraphQL, and BI implementations of the same metric.
