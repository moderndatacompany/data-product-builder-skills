# Physical Design, Performance, and Cost

## Contents

1. Optimize workloads, not tables in isolation
2. Cost drivers
3. Materialize or calculate
4. Aggregate and rollup design
5. Partitioning and pruning
6. Clustering, sorting, and bucketing
7. File layout and compaction
8. Expensive analytical patterns
9. Caching and materialized views
10. Hot, warm, and cold data
11. Engine-specific caution
12. Measurement plan
13. Cost review output

## Optimize workloads, not tables in isolation

A physical design is appropriate only relative to:

- Business questions.
- Query frequency and concurrency.
- Freshness and latency.
- Data volume and growth.
- Update and delete pattern.
- Historical depth.
- Engine and pricing model.
- Reliability and maintenance capacity.

Do not recommend a star schema, wide table, partition key, clustering key, materialized view, or rollup universally.

## Cost drivers

### Scan and input

- Bytes and columns read.
- Partitions or blocks pruned.
- External file listing and metadata.
- Repeated parsing or transformation.

### Shuffle and communication

- Large joins.
- Group-by redistribution.
- Skewed keys.
- Fact-to-fact expansion.

### Sort and state

- Window functions.
- Exact distinct counts.
- Sessionization.
- Funnels and attribution.
- Temporal range joins.

### Output and materialization

- Rows and bytes written.
- Full versus incremental refresh.
- File count and compaction.
- Materialized-view or index maintenance.

### Concurrency and capacity

- Number of simultaneous queries.
- Warehouse/slot sizing.
- Queueing.
- Cache hit rate.
- BI query bursts.

### Maintenance

- Merge and rewrite cost.
- Clustering/reclustering.
- Search indexes.
- Backfills.
- Testing and observability.

## Materialize or calculate

Use this conceptual comparison:

```text
repeated query computation + user latency + concurrency impact
versus
refresh computation + storage + maintenance + staleness + model complexity
```

### Calculate at query time when

- The query is rare.
- Input is already small or pruned.
- Logic changes frequently.
- Dimensional combinations are unpredictable.
- Engine result caching already solves it.
- Freshness requires immediate base-data visibility.

### Precompute a column when

- Logic is deterministic and stable.
- It is used frequently across tools.
- It is expensive or inconsistently reimplemented.
- Storage overhead is modest.

### Materialize a derived model when

- Multiple consumers reuse expensive joins or windows.
- The result has a clear grain and contract.
- Incremental maintenance is tractable.
- Atomic truth remains available.

### Build a snapshot when

- Historical state is required.
- Reconstructing state repeatedly is expensive or error-prone.
- Period boundaries are meaningful.

### Build an aggregate or rollup when

- Query shapes repeat.
- The dimensions and grains are predictable.
- Measures are safely reaggregatable.
- Refresh cost is lower than repeated query cost.

### Use approximation when

- Scale makes exact computation expensive.
- Error tolerance is agreed.
- Approximation is clearly labelled.
- Sketches can merge across required dimensions and periods.

## Aggregate and rollup design

Define:

```text
base fact and grain
aggregate grain
dimensions
measures and stored states
partition/time grain
refresh method
late-data strategy
reaggregation rules
matching query patterns
drill-through path
retention
```

### Safe stored states

- Sum and count for averages.
- Numerator and denominator for ratios.
- Mergeable sketches for approximate distinct.
- Period-end/first/last values for stocks.
- Additive flows.

### Avoid aggregate explosion

Do not create a rollup for every combination. Rank candidates using:

- Query frequency.
- Runtime and bytes.
- Concurrency impact.
- Dimensional reuse.
- Refresh cost.
- Storage.
- Stability of business logic.

Retire unused rollups. They still consume refresh compute, storage, testing, and incident-response capacity.

## Partitioning and pruning

Choose partition columns that:

- Appear in common selective filters.
- Match data lifecycle and retention.
- Produce sufficiently large partitions.
- Support incremental overwrite or deletion.
- Have stable, understandable semantics.

Common choices:

- Event date.
- Ingestion date.
- Snapshot date.
- Tenant for strong isolation, when cardinality and volume are appropriate.

Avoid:

- Extremely high-cardinality identifiers.
- Tiny partitions.
- Partition expressions that consumers cannot filter correctly.
- Partitioning by a date that differs from business query time without clear guidance.

Require partition filters when the engine and workload justify protecting against full scans.

## Clustering, sorting, and bucketing

Use for common filters, joins, ranges, and data skipping.

Evaluate:

- Selectivity.
- Query frequency.
- Data skew.
- Table size.
- Insert order.
- DML churn.
- Maintenance cost.

Clustering a frequently updated table may cost more than it saves. Benchmark representative queries before and after.

Do not copy one engine's recommendations to another. For example, Snowflake micro-partition clustering, BigQuery clustering, Databricks liquid clustering, and Spark bucketing have different semantics and maintenance costs.

## File layout and compaction

In lakehouse systems, small files can dominate cost.

Monitor:

- File count.
- Median and tail file size.
- Partition size.
- Listing latency.
- Read amplification.
- Rewrite frequency.
- Delete-file or change-file accumulation.

Compact based on measured workload and engine guidance. Avoid constant optimization jobs that cost more than the query benefit.

## Expensive analytical patterns

### Exact distinct counts

Solutions:

- Deduplicate to entity-period grain.
- Build fixed-grain exact aggregates.
- Use mergeable approximate sketches when permitted.
- Restrict broad, high-cardinality exploratory queries.

### Window functions

Reduce cost by:

- Filtering before the window.
- Narrowing partitions.
- Persisting reusable session, rank, or lifecycle state.
- Processing incrementally with a correct boundary/lookback.

### Sessionization

Build an incremental session fact when many users repeatedly query sessions. Define inactivity gap, identity, late-event handling, and cross-day behavior.

### Funnels

Avoid repeated self-joins of raw events. Materialize journey or stage-completion facts for standard funnels while retaining atomic events for alternate definitions.

### Cohorts and retention

Build an entity-period activity spine rather than repeatedly cross-joining raw events to every cohort period.

### Temporal joins

Resolve event-time surrogate keys early or materialize assignment tables for frequent high-volume use. Validate corrections and backdated changes.

### Fact-to-fact joins

Aggregate each fact to a compatible grain before joining. This saves compute and prevents wrong totals.

### High-cardinality dimensions

Treat identifiers, email, URLs, request IDs, and free text as drill or filtered fields. Avoid exposing them as unrestricted default groupings.

### Repeated transformations

Materialize stable normalization, parsing, complex CASE logic, and expensive reusable joins once. Keep volatile or cheap presentation logic at query time.

## Caching and materialized views

### Result cache

Useful when identical queries repeat and data changes slowly. Do not depend on it for varied BI-generated SQL.

### Semantic pre-aggregation

Useful when query matching can redirect many dimensional queries to a rollup. Validate that filters, time grains, joins, and measures match.

### Database materialized view

Use for stable, high-traffic patterns supported by the engine's incremental refresh. Account for storage and maintenance cost.

### Application/API cache

Useful for repeated parameterized responses with explicit TTL and invalidation. Do not let cached results obscure contract freshness.

Document:

- Cache key.
- TTL.
- Invalidation.
- Staleness semantics.
- Security context.
- Tenant isolation.

## Hot, warm, and cold data

### Hot

Recent and frequent. Optimize layout, aggregates, and cache.

### Warm

Occasional analysis. Lower maintenance cadence and moderate performance.

### Cold

Archive or rare audit. Cheap storage and slower access can be acceptable.

Align retention and table layout with actual access patterns rather than keeping all history in the most expensive serving tier.

## Engine-specific caution

### BigQuery

Cost often depends on bytes processed or slot capacity. Column projection, partition pruning, clustering, staged materialization, and targeted materialized views can reduce repeated work. LIMIT on a non-clustered table is not a cost-control strategy.

### Snowflake

Clustering, search optimization, and materialized views incur ongoing compute and/or storage maintenance. Apply them to measured high-value query patterns, especially considering DML churn.

### Databricks/Delta

Choose the active platform's recommended data-layout mechanism. Modern Databricks guidance favors liquid clustering for many new tables, but version, catalog, format, and workload support must be verified.

### Postgres

Use indexes, partitioning, materialized views, statistics, and query plans selectively. Wide analytical scans and high-concurrency BI may require different serving architecture than OLTP defaults.

### Trino/Spark/lakehouse engines

File pruning, partitioning, compaction, join distribution, and shuffle dominate. Validate connector pushdown and storage format.

## Measurement plan

Collect:

- Query text or normalized signature.
- Frequency and users.
- Duration percentiles.
- Bytes/rows scanned.
- Shuffle and spill.
- Slot/credit/warehouse consumption.
- Output rows.
- Cache/pre-aggregation use.
- Filters and dimensions.
- Concurrency and queue time.
- Refresh duration and data changed.

Use representative production queries, not synthetic microbenchmarks alone.

## Cost review output

For each recommendation, state:

```text
Problem and evidence:
Affected questions/users:
Current computation:
Target grain and structure:
Expected avoided work:
Refresh and storage cost:
Freshness change:
Correctness/reaggregation constraints:
Implementation and rollback:
Success metrics:
Decision: query-time / column / derived model / snapshot / aggregate / MV / rollup / approximation / cache / restriction
```
