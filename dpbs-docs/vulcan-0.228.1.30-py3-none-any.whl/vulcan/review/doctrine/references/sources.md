# Source and Verification Guide

Use current primary sources for syntax, supported features, and engine-specific behavior. Use project code and tests ahead of generic documentation when reviewing a fork, extension, or unreleased feature. Record the product version, documentation date, and any mismatch between code and published docs.

Last reviewed for this skill: 2026-08-04.

## Contents

1. Source hierarchy
2. Project evidence
3. Modeling foundations
4. DataOS / Vulcan
5. Semantic models
6. Data quality and assertions
7. Warehouse performance and cost
8. BI relationship behavior
9. Data contracts
10. Verification rules

## 1. Source hierarchy

Use evidence in this order:

1. Business owner definitions and reconciliation targets.
2. Actual schemas, data profiles, query results, and execution plans.
3. Active project source code, configuration schemas, migrations, and tests.
4. Official version-matched vendor documentation.
5. Published modeling references and standards.
6. Community material only when primary sources do not cover the issue; label it accordingly.

Never use a documentation example as proof that the user’s data has the assumed grain or cardinality.

## 2. Project evidence

For Vulcan, inspect at minimum:

- Physical SQL model parser and Vulcan integration.
- Semantic, metric, DQ, policy, and product configuration schemas.
- Join graph construction and BI export logic.
- Query planners for SQL, REST, GraphQL, and MySQL paths.
- Measure expression parser and cross-model reference behavior.
- Rollup/pre-aggregation planner.
- Unit, integration, negative, and compatibility tests.
- Example projects only after separating demonstration fixtures from production conventions.

The supplied `b2b_saas` audit is a useful structural example, but it is not a substitute for the live repository.

## 3. Modeling foundations

### Kimball Group dimensional modeling techniques

- Multivalued dimensions and bridge tables: https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/multivalued-dimension-bridge-table/
- Timespan tracking in fact tables: https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/timespan-fact-table/

Use these for foundational pattern vocabulary. Still validate the chosen implementation against the target engine, BI tool, and business semantics.

## 4. DataOS / Vulcan

Primary documentation: [DataOS Overview](https://v2.dataos.info/) · full index: [llms.txt](https://v2.dataos.info/llms.txt)

### Build guides (how to productize)

- Productize overview: https://v2.dataos.info/build/productize/overview
- Init and configuration: https://v2.dataos.info/build/productize/init-and-configuration
- Data model: https://v2.dataos.info/build/productize/assets/data-model
- Inputs (external models): https://v2.dataos.info/build/productize/assets/inputs
- Seeds: https://v2.dataos.info/build/productize/assets/seeds
- Semantic model: https://v2.dataos.info/build/productize/assets/semantic-model
- Metrics: https://v2.dataos.info/build/productize/assets/metrics
- Assertions (audits that block materialization): https://v2.dataos.info/build/productize/assertions
- Unit tests: https://v2.dataos.info/build/productize/unit-test
- Data quality: https://v2.dataos.info/build/productize/data-quality
- Governance / access policy: https://v2.dataos.info/build/productize/governance
- Plan and run: https://v2.dataos.info/build/productize/plan-and-run

### Recipes

- Incremental by time: https://v2.dataos.info/build/build-1/recipes/incremental-by-time
- SCD Type 2 history: https://v2.dataos.info/build/recipes/recipes/track-dimension-history-with-scd-type-2
- Wait for data with signals: https://v2.dataos.info/build/recipes/recipes/wait-for-data-with-signals
- Mask sensitive columns by role: https://v2.dataos.info/build/recipes/recipes/mask-sensitive-columns-by-role

### Vulcan reference (authoritative syntax)

- Models overview: https://v2.dataos.info/references/resources/vulcan/models
- Data models: https://v2.dataos.info/references/resources/vulcan/models/data-models
- MODEL properties: https://v2.dataos.info/references/resources/vulcan/models/data-models/properties
- Model kinds (FULL, VIEW, INCREMENTAL_*, SCD_TYPE_2, SEED, EMBEDDED): https://v2.dataos.info/references/resources/vulcan/models/data-models/model-kinds
- SQL models: https://v2.dataos.info/references/resources/vulcan/models/data-models/types/sql
- Python models: https://v2.dataos.info/references/resources/vulcan/models/data-models/types/python
- External models: https://v2.dataos.info/references/resources/vulcan/models/data-models/types/external-models
- Plan and run concepts: https://v2.dataos.info/references/resources/vulcan/concepts/run-and-plan
- CLI commands: https://v2.dataos.info/references/resources/vulcan/cli
- Engine guides: https://v2.dataos.info/references/engine-guide/engine-guide

Verify:

- Supported model kind and configuration fields for the installed Vulcan version.
- Required bounded filters for time-range incremental models.
- Unique-key merge semantics.
- SCD Type 2 options and delete / invalidate behavior.
- Assertion versus DQ-check execution scope.
- Unit test fixture and partial-output behavior.
- Engine-specific materialization behavior via the engine guide for the target warehouse.

Prefer DataOS / Vulcan docs and the live project schema over upstream Vulcan docs. Vulcan may constrain, rename, or omit Vulcan features.

## 5. Semantic models

Official DataOS documentation (replaces external Cube docs for Vulcan reviews):

### Build guides

- Semantic model: https://v2.dataos.info/build/productize/assets/semantic-model
- Metrics: https://v2.dataos.info/build/productize/assets/metrics

### Reference

- Semantic models overview: https://v2.dataos.info/references/resources/vulcan/models/semantic-models
- Dimensions: https://v2.dataos.info/references/resources/vulcan/models/semantic-models/dimensions
- Measures: https://v2.dataos.info/references/resources/vulcan/models/semantic-models/measures
- Segments: https://v2.dataos.info/references/resources/vulcan/models/semantic-models/segments
- Joins: https://v2.dataos.info/references/resources/vulcan/models/semantic-models/joins
- Rollups (pre-aggregations): https://v2.dataos.info/references/resources/vulcan/models/semantic-models/rollups
- AI context: https://v2.dataos.info/references/resources/vulcan/models/semantic-models/ai-context
- Business metrics: https://v2.dataos.info/references/resources/vulcan/models/business-metrics

### Consume / query paths (when reviewing serving behavior)

- Querying Data Products: https://v2.dataos.info/consume/activate/querying-data-products
- Semantic SQL over MySQL protocol: https://v2.dataos.info/consume/activate/database-clients/mysql/query
- Semantic GraphQL recipe: https://v2.dataos.info/consume/recipes/query-semantic-model-with-graphql

Verify:

- Join direction and relationship type.
- Primary-key requirements and fanout handling.
- Public/private member exposure.
- Cross-model join-path behavior.
- Rollup match, refresh, partitioning, and reaggregation constraints.
- Measure / metric definition consistency with physical grain.

Treat Vulcan semantic YAML and tests as authoritative. Do not assume Cube syntax or planner behavior unless the project explicitly exports to Cube.

## 6. Data quality and assertions

Official DataOS documentation (replaces external Soda docs for Vulcan reviews):

### Build guides

- Data quality: https://v2.dataos.info/build/productize/data-quality
- Assertions: https://v2.dataos.info/build/productize/assertions
- Unit tests: https://v2.dataos.info/build/productize/unit-test

### Reference

- Quality overview: https://v2.dataos.info/references/resources/vulcan/quality
- Assertions (audits): https://v2.dataos.info/references/resources/vulcan/quality/assertions
- Data quality checks (`kind: dq`): https://v2.dataos.info/references/resources/vulcan/quality/data-quality
- Unit tests: https://v2.dataos.info/references/resources/vulcan/quality/tests

Verify:

- Supported DQ / assertion syntax for the installed Vulcan version.
- Whether failed-row samples are bounded and safe for PII.
- Metric / threshold meaning for continuous DQ checks.
- Difference between blocking assertions and non-blocking DQ monitors.
- Check filters and execution context (plan, run, evaluate).

Vulcan DQ YAML may translate, constrain, or extend Soda-like concepts. Treat the Vulcan schema and tests as authoritative for accepted project syntax.

## 7. Warehouse performance and cost

Prefer the DataOS engine guide for the project's configured engine when reviewing Vulcan materialization, grants, and cost behavior:

- Engine guides overview: https://v2.dataos.info/references/engine-guide/engine-guide
- Snowflake: https://v2.dataos.info/references/engine-guide/snowflake
- Databricks: https://v2.dataos.info/references/engine-guide/databricks
- Spark: https://v2.dataos.info/references/engine-guide/spark-1
- Trino: https://v2.dataos.info/references/engine-guide/trino-1
- Postgres: https://v2.dataos.info/references/engine-guide/postgres
- SQL Server: https://v2.dataos.info/references/engine-guide/sql-server
- Microsoft Fabric: https://v2.dataos.info/references/engine-guide/microsoft-fabric

Supplement with vendor docs below for engine-native features not covered in DataOS.

### BigQuery

- Cost best practices: https://cloud.google.com/bigquery/docs/best-practices-costs
- Performance overview: https://cloud.google.com/bigquery/docs/best-practices-performance-overview
- Materialized views: https://cloud.google.com/bigquery/docs/materialized-views-use

### Snowflake

- Storage optimization: https://docs.snowflake.com/en/user-guide/performance-query-storage
- Query performance overview: https://docs.snowflake.com/en/user-guide/performance-query-options
- Clustering keys and clustered tables: https://docs.snowflake.com/en/user-guide/tables-clustering-keys

### Databricks

- Data warehousing architecture: https://docs.databricks.com/aws/en/sql/get-started/data-warehousing-concepts
- Liquid clustering: https://docs.databricks.com/aws/en/tables/clustering
- Medallion architecture: https://docs.databricks.com/aws/en/lakehouse/medallion

For every warehouse, verify current support and economics for:

- Partitioning/clustering/data layout.
- Materialized views and optimizer rewrite.
- Incremental refresh.
- Exact and approximate distinct structures.
- Result cache.
- File compaction and small-file management.
- Scan-based, compute-time, or capacity pricing.

Do not transfer engine-specific advice. For example, partitioning, clustering, indexing, and materialized-view behavior differ materially by engine.

## 8. BI relationship behavior

### Power BI

- Many-to-many relationship guidance: https://learn.microsoft.com/en-us/power-bi/guidance/relationships-many-to-many
- Star schema guidance: https://learn.microsoft.com/en-us/power-bi/guidance/star-schema
- Model relationships: https://learn.microsoft.com/en-us/power-bi/transform-model/desktop-relationships-understand

### Tableau

- Relationships overview: https://help.tableau.com/current/pro/desktop/en-us/datasource_relationships_learnmorepage.htm
- Relationship performance/cardinality options: https://help.tableau.com/current/pro/desktop/en-us/datasource_relationships_perfoptions.htm
- Relationship behavior guidance: https://help.tableau.com/current/pro/desktop/en-us/datasource_dont_be_scared.htm

Verify:

- Cardinality and referential-integrity declarations.
- Filter direction and ambiguity.
- Many-to-many handling.
- Cycles and multiple paths.
- Generated query behavior.
- Live versus extract/import behavior.

A relationship that is valid in the warehouse may still be unsafe or unsupported in a BI export.

## 9. Data contracts

Open Data Contract Standard:

- Repository: https://github.com/bitol-io/open-data-contract-standard
- Documentation: https://bitol-io.github.io/open-data-contract-standard/latest/

Use a contract to capture schema, semantics, quality, ownership, support, SLA, security, and compatibility where supported. Do not treat a contract document as proof that runtime data complies; connect it to tests and monitoring.

## 10. Verification rules

Before relying on a vendor-specific claim:

1. Identify the installed/deployed version.
2. Open the official version-matched documentation.
3. Confirm the feature in active source/config schema when the product is extended or forked.
4. Reproduce behavior with the smallest valid example.
5. Add a regression test for critical planner, join, metric, or incremental behavior.
6. Capture generated SQL and execution plan for performance claims.
7. Measure on representative data rather than inferring from syntax.
8. Record uncertainty when docs, code, and runtime disagree.

For open-ended modeling principles, use multiple perspectives and state trade-offs. For syntax and feature support, prefer one authoritative source of truth.
