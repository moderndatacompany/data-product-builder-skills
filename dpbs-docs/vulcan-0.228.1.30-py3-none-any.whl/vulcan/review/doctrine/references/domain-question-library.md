# Domain Business-Question Library

Use this library to seed discovery when stakeholders have not yet provided a complete question set. Treat every question as provisional until the domain owner confirms definitions. The purpose is to reveal required grain, history, denominators, relationships, and serving patterns—not to assume every organization uses the same KPI formula.

## Contents

1. How to use the library
2. Cross-domain questions
3. B2B SaaS and subscriptions
4. Product and digital engagement
5. Sales and pipeline
6. Marketing and attribution
7. Customer success and support
8. Commerce and orders
9. Finance and accounting
10. Supply chain and inventory
11. Workforce and people analytics
12. IoT and operations
13. Question-to-data gap patterns

## 1. How to use the library

For each selected question, record:

- Decision and consumer.
- Exact wording and business definition.
- Numerator and denominator.
- Required entity and fact grains.
- Current-state or historical requirement.
- Time axis and timezone.
- Dimensions and filters.
- Exactness, freshness, latency, and retention.
- Reconciliation source.
- Access and privacy constraints.

Then classify it as answerable, conditional, partial, not answerable, or misleading.

## 2. Cross-domain questions

### Entity population

- How many entities currently exist?
- How many were created, activated, suspended, reactivated, or closed in a period?
- What was the population at each period end?
- Which attributes describe entities now versus at event time?
- Are people, accounts, organizations, households, and contracts distinct entities?

Data implications:

- Current entity table for latest population.
- Lifecycle events or periodic snapshots for historical population.
- Stable business keys and deduplication.
- Effective-dated dimensions for historical segmentation.

### Performance over time

- What happened during the period?
- What was true at the end of the period?
- How did the stock change between opening and closing?
- Which movements explain the change?
- Is the comparison calendar, fiscal, rolling, or cohort-based?

Data implications:

- Separate flow, stock, and movement facts.
- Calendar and timezone contract.
- Period locking/restatement rules.

### Segmentation

- How do outcomes differ by segment, region, product, channel, owner, or tier?
- Should historical facts use current or historical segment assignment?
- Are segments mutually exclusive?
- Can an entity have several simultaneous memberships?

Data implications:

- Conformed/effective-dated dimensions.
- Bridges for multi-valued membership.
- Explicit current-state restatement policy.

### Rates and conversion

- What is the numerator?
- Who was eligible for the denominator?
- What exposure or opportunity existed?
- What conversion window and attribution rule apply?
- Can entities convert more than once?

Data implications:

- Factless eligibility/exposure fact.
- Event sequence and effective times.
- Numerator/denominator components, not only percentages.

## 3. B2B SaaS and subscriptions

### Customer and account base

Questions:

- How many active customer accounts do we have now?
- How many users versus paying accounts exist?
- How many new accounts signed up in a period?
- How many accounts activated, suspended, churned, or reactivated?
- What was the active account count at each month end?
- How does the account base vary by industry, size, region, plan, or acquisition channel?

Required distinctions:

- User versus account versus billing customer.
- Signup versus activation.
- Current status versus status history.
- Current segment versus event-time segment.

Likely models:

- `dim_account_current`
- `dim_account_history`
- `account_lifecycle_event`
- `account_daily_snapshot`

### Recurring revenue

Questions:

- What are current MRR and ARR?
- What were MRR and ARR at each historical period end?
- How much new, expansion, contraction, churn, and reactivation MRR occurred?
- What is net new MRR?
- What are gross revenue retention and net revenue retention?
- What is average revenue per account or per seat?
- Which contracts are due for renewal?
- How much revenue is contracted, billed, collected, or recognized?

Required distinctions:

- Contracted versus billed versus collected versus recognized revenue.
- Current state versus period-end snapshot.
- Billing cycle and currency conversion.
- Subscription-level versus account-level churn.
- Opening denominator for retention.
- Plan/list price versus actual contract price.

Likely models:

- `subscription_event`
- `subscription_current`
- `subscription_daily_snapshot`
- `subscription_movement`
- `invoice_line`
- `payment`
- `revenue_recognition_schedule`

Unsafe shortcuts:

- Grouping current ARR by subscription start month and calling it historical ARR.
- Dividing cancellations by current active subscriptions and calling it churn rate.
- Summing ARR across months.
- Treating catalog price as realized MRR.

### Churn and retention

Questions:

- How many subscriptions or accounts churned in a period?
- What is logo churn versus revenue churn?
- What is gross/net retention?
- How many churned accounts later reactivated?
- What leading behaviors predict churn?
- How does retention differ by cohort and plan at acquisition time?

Data implications:

- Opening population and eligible denominator.
- Cancellation effective date.
- Account/subscription episode identity.
- Movement classifications.
- Reactivation history.
- Event-time plan and cohort assignment.

### Pricing and packaging

Questions:

- Which plans are adopted and by whom?
- What is realized price versus list price?
- What discounts and grandfathered prices exist?
- How do upgrades and downgrades affect revenue and usage?
- Which features are available to each plan at each time?

Data implications:

- Versioned plan catalog.
- Contract price history.
- Plan-feature eligibility history.
- Subscription movement facts.

## 4. Product and digital engagement

### Activity

Questions:

- What are DAU, WAU, and MAU?
- What is stickiness such as DAU/MAU?
- How many sessions and events occur?
- Which features are used, by whom, and how often?
- How much time or work is completed in the product?
- What is adoption by plan, persona, account, device, or geography?

Required distinctions:

- Identified user versus anonymous device.
- Event count versus distinct users.
- Activity day timezone.
- Eligible user population.
- Current plan versus plan at event time.
- Bot/test/internal traffic.

Likely models:

- `usage_event`
- `session`
- `user_activity_day`
- `user_feature_day`
- `feature_eligibility_day`
- `feature_usage_daily`

Unsafe shortcuts:

- Summing DAU to obtain MAU.
- Calling feature users an adoption rate without an eligible denominator.
- Using current plan to attribute all historical events without disclosure.
- Treating event volume as engagement quality.

### Funnels

Questions:

- How many users progress through onboarding or purchase stages?
- What is conversion between each stage?
- How long does each transition take?
- Where do users drop out?
- Can stages repeat or occur out of order?

Data implications:

- Ordered event timestamps.
- Stable journey/entity identity.
- Conversion window.
- First/last/repeated completion policy.
- Eligibility at funnel entry.

Likely model:

```text
entity_journey(
  entity_id,
  journey_start,
  stage_1_at,
  stage_2_at,
  converted_at,
  model_version
)
```

### Cohorts and retention

Questions:

- What percentage of a signup/activation cohort is active in week or month N?
- Is retention based on any activity, qualified activity, or paid status?
- Are returning and resurrected users separated?
- Is the denominator fixed at cohort creation or adjusted for eligibility?

Data implications:

- Cohort assignment.
- Entity-period activity.
- Cohort age.
- Eligibility and exclusion rules.
- Reproducible calendar boundaries.

## 5. Sales and pipeline

Questions:

- What is current pipeline value by stage and owner?
- What was pipeline at each historical period end?
- How much pipeline was created, progressed, slipped, won, or lost?
- What are stage conversion rates and cycle times?
- What is forecast coverage and forecast accuracy?
- Which activities influence conversion?
- How are territories and owners credited?

Required distinctions:

- Current opportunity state versus stage history.
- Opportunity amount changes.
- Expected close date changes and slippage.
- Multi-owner credit and allocation.
- Created pipeline versus ending pipeline.
- Forecast version and submission time.

Likely models:

- `opportunity_current`
- `opportunity_stage_event`
- `opportunity_daily_snapshot`
- `opportunity_movement`
- `sales_credit_bridge`
- `forecast_submission`

Unsafe shortcuts:

- Using current stage to reconstruct historical funnel.
- Summing current pipeline across snapshot dates.
- Counting activities as causal influence without attribution design.

## 6. Marketing and attribution

Questions:

- How many people/accounts were reached, engaged, and converted?
- What is cost per lead, opportunity, acquisition, or revenue unit?
- Which campaigns and channels receive credit?
- What is first-touch, last-touch, or multi-touch attribution?
- What is incremental lift versus correlation?
- Which audience was eligible or exposed?

Required distinctions:

- Impression, exposure, click, lead, opportunity, and conversion identities.
- Person-to-account resolution.
- Attribution window and model version.
- Spend currency and allocation.
- Organic versus paid activity.
- Experimental holdout for causal lift.

Likely models:

- `campaign_touchpoint`
- `campaign_spend`
- `conversion`
- `touchpoint_conversion_bridge`
- `attribution_allocation`
- `audience_eligibility`

Unsafe shortcuts:

- Crediting every touch with full revenue.
- Comparing channel ratios without consistent attribution and denominator.
- Calling observational attribution causal impact.

## 7. Customer success and support

Questions:

- How many tickets are opened, resolved, reopened, or breached?
- What are first response and resolution times?
- What backlog existed at period end?
- Which accounts have rising support burden or risk?
- How does support activity relate to revenue and usage?
- Which SLA applied when the ticket was created?

Required distinctions:

- Ticket event history versus current ticket.
- Business hours versus clock hours.
- SLA version and entitlement at event time.
- Requester, user, account, and contract.
- Reopen and merged-ticket behavior.

Likely models:

- `support_ticket_current`
- `support_ticket_event`
- `support_ticket_daily_snapshot`
- `support_sla_history`
- `account_month_support`

Unsafe shortcuts:

- Calculating historical backlog from current ticket status.
- Averaging average resolution times without weighting.
- Joining raw tickets and raw usage directly by account.

## 8. Commerce and orders

Questions:

- What are orders, units, gross sales, discounts, net sales, tax, shipping, returns, and margin?
- What is average order value?
- Which products, customers, channels, and promotions drive performance?
- What is conversion from visit/cart/checkout to order?
- How long does fulfillment take?
- What is the return/refund rate?

Required distinctions:

- Order versus order line grain.
- Booked, shipped, delivered, returned, refunded, and recognized amounts.
- Partial fulfillment and partial returns.
- Promotion allocation to lines.
- Currency and tax treatment.
- Customer identity resolution.

Likely models:

- `order_line`
- `order_status_event`
- `shipment_line`
- `return_line`
- `payment_transaction`
- `order_accumulating_snapshot`
- `inventory_movement`

Unsafe shortcuts:

- Joining order lines to payments without allocation.
- Counting orders after a line-level join without distinct handling.
- Subtracting refunds from sales using mismatched event periods without defining the accounting treatment.

## 9. Finance and accounting

Questions:

- What are revenue, expense, assets, liabilities, and cash by period?
- How do subledgers reconcile to the general ledger?
- What movements explain opening-to-closing balances?
- What is actual versus budget versus forecast?
- Which periods are open, closed, or restated?
- How are currency translation and consolidation handled?

Required distinctions:

- Transaction, journal line, balance, and statement grains.
- Posting date, transaction date, service period, and close period.
- Legal entity and chart-of-accounts version.
- Local, transaction, and reporting currency.
- Adjustment, reversal, and restatement.
- Intercompany elimination.

Likely models:

- `journal_line`
- `account_balance_snapshot`
- `financial_movement`
- `budget_line`
- `forecast_version`
- `fx_rate_history`
- `consolidated_statement_line`

Unsafe shortcuts:

- Summing balances across periods.
- Mixing booked ARR with recognized revenue.
- Converting currency with current FX rates for historical reporting unless restatement is intended.

## 10. Supply chain and inventory

Questions:

- What inventory is on hand, available, allocated, in transit, or backordered?
- What were levels at each historical period end?
- What movements explain changes?
- What is stockout, fill rate, lead time, and inventory turnover?
- Which suppliers or facilities create delays?

Required distinctions:

- SKU-location-lot state grain.
- Movement versus balance.
- Available-to-promise definition.
- Unit of measure conversion.
- Reservation and allocation.
- Event and snapshot timing.

Likely models:

- `inventory_movement`
- `inventory_daily_snapshot`
- `purchase_order_line`
- `shipment_event`
- `supplier_performance_period`

Unsafe shortcuts:

- Summing daily inventory balances.
- Joining receipts and issues directly without compatible aggregation.
- Ignoring negative inventory and late-posted movements.

## 11. Workforce and people analytics

Questions:

- What is current and historical headcount?
- How many hires, transfers, promotions, and terminations occurred?
- What are attrition, span of control, and workforce composition?
- What was an employee’s organization, manager, location, and job level at event time?
- How are contingent workers treated?

Required distinctions:

- Person, worker, employment, position, and assignment.
- Effective-dated organization hierarchy.
- Current versus historical manager/department.
- Voluntary versus involuntary termination.
- Eligible population for attrition.
- Sensitive attributes and minimum cohort sizes.

Likely models:

- `worker_current`
- `worker_assignment_history`
- `employment_event`
- `headcount_monthly_snapshot`
- `organization_hierarchy_history`

Unsafe shortcuts:

- Using current department for historical attrition.
- Dividing terminations by current headcount without an agreed denominator.
- Exposing small-group sensitive results.

## 12. IoT and operations

Questions:

- What devices/assets are active, healthy, degraded, or offline?
- How many readings, alerts, and failures occur?
- What is uptime, downtime, throughput, and utilization?
- Which maintenance actions reduce failures?
- What was configuration/firmware at event time?

Required distinctions:

- Device, asset, sensor, reading, alert, incident, and maintenance work order.
- Event time versus arrival time.
- Missing telemetry versus true zero.
- Sampling frequency and aggregation.
- Effective-dated configuration.
- Outlier and sensor-quality handling.

Likely models:

- `telemetry_reading`
- `device_status_event`
- `device_interval_state`
- `asset_daily_snapshot`
- `maintenance_event`
- `telemetry_hourly_aggregate`

Unsafe shortcuts:

- Treating no reading as zero output.
- Averaging averages from sensors with unequal sample counts.
- Ignoring time-weighted state duration for uptime.

## 13. Question-to-data gap patterns

| Question wording | Common missing capability |
|---|---|
| “What was true at month end?” | Periodic snapshot or effective history |
| “Why did the balance change?” | Movement/change fact |
| “What percentage converted?” | Eligibility/exposure denominator |
| “At the time of the event…” | Effective-dated dimension or stamped attribute |
| “How long between stages?” | Ordered lifecycle events or accumulating snapshot |
| “Which path led to conversion?” | Journey identity and event sequence |
| “How much credit belongs to each…” | Allocation bridge and weighting rules |
| “How many unique over a larger period?” | Entity-period deduplication or mergeable sketch |
| “Compare two independent activities…” | Aggregate each fact to a compatible grain |
| “Current and historical values” | Separate current-state and history representations |
| “Certified financial result” | Reconciliation, period lock, restatement, audit trail |
| “Real-time API response” | Bounded serving projection and freshness contract |
| “Train a model as of that date” | Point-in-time feature history |
