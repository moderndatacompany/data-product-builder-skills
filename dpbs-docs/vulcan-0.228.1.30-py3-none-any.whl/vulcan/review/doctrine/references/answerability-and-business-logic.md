# Answerability and Business Logic

## Contents

1. Why answerability matters
2. Classification system
3. Evaluation algorithm
4. Table-level analysis
5. Cross-table analysis
6. Business logic categories
7. Missing capability patterns
8. Misleading calculations
9. Question matrix
10. Approval standard

## Why answerability matters

A model is valuable only when users know what it can and cannot answer. Syntactically valid SQL can produce a precise-looking but wrong result. Evaluate analytical feasibility before generating metrics or dashboards.

## Classification system

### Answerable

Required fact, grain, key, history, time semantics, denominator, and join path exist. Quality and completeness are sufficient for the requested interpretation.

### Answerable with assumptions

The data can answer the question only under explicit assumptions.

Example:

- Treat `status = cancelled` as churn.
- Treat the current plan as the plan for all historical usage.

State the assumption in the metric contract and consumer output.

### Partially answerable

The model can answer a component, proxy, or subset but not the full question.

Example:

- Churn count exists, but no opening population exists for churn rate.

### Not answerable

Required history, data, key, eligibility, relationship, or definition is absent.

Example:

- Historical month-end ARR from a current-state table that overwrites changes.

### Misleading or unsafe

SQL can execute, but the answer violates business meaning, grain, temporal attribution, additivity, or join safety.

Example:

- Sum of DAU across days.
- Revenue after a fact-to-fact fanout join.

## Evaluation algorithm

For each question:

1. Rewrite the question precisely.
2. Identify the decision and unit of analysis.
3. Define the required metric components.
4. Identify the required fact grain.
5. Identify dimensions and time semantics.
6. Determine current-state versus historical needs.
7. Map candidate tables and fields.
8. Validate keys, cardinality, and join path.
9. Validate metric additivity and reaggregation.
10. Validate completeness, quality, and reconciliation.
11. Classify answerability.
12. Name assumptions, missing capability, and remedy.

Do not let an available column force the business definition.

## Table-level analysis

For every table, list:

### Direct questions

Questions aligned to the table grain and lifecycle.

Example for an atomic usage event table:

- Event count by day.
- Events by feature.
- Distinct active users per day.

### Conditional questions

Questions requiring assumptions or external completeness.

- Feature adoption if any use counts as adoption.
- DAU if event capture is complete and bots are excluded correctly.

### Unsupported questions

- Funnel conversion without event order and stable identity.
- Adoption rate without eligibility denominator.
- Retention without cohort/activity history.

### Unsafe questions

- Treating event count as user count.
- Summing exact distinct users across periods.

## Cross-table analysis

Check:

- Compatible grain.
- Direct versus inferred relationship.
- Event-time versus current-state dimension.
- Shared identifiers and identity resolution.
- Fact-to-fact fanout.
- Missing denominator or eligibility fact.
- Missing bridge or allocation.
- Historical coverage overlap.
- Different data latency and completeness.

A question requiring multiple tables is answerable only when the combined semantics are valid, not merely when a SQL join is possible.

## Business logic categories

### Entity logic

- What is a customer, user, account, subscription, or order?
- Can entities merge or split?
- Are identifiers reused?
- Is one person allowed multiple accounts?

### Lifecycle logic

- Allowed states and transitions.
- Reactivation.
- Pause and resume.
- Cancellation versus expiration.
- Effective dates and backdating.

### Revenue logic

- Booked, billed, collected, recognized.
- Gross or net.
- Discounts, refunds, credits, taxes.
- Currency conversion.
- Contracted versus realized revenue.

### Product usage logic

- Human versus automated events.
- Session definition.
- Feature eligibility.
- Event ordering.
- Duplicate and retry behavior.

### Attribution logic

- First, last, linear, position-based, or custom.
- Attribution window.
- Touchpoint eligibility.
- Multi-touch weights.
- Event-time campaign mapping.

### Temporal logic

- Event, effective, ingestion, snapshot, and reporting time.
- Timezone and fiscal calendar.
- Partial periods.
- Late and corrected data.

### Segmentation logic

- Current or historical segment.
- Exclusive or overlapping.
- Dynamic or fixed.
- Entity-level or event-level.

## Missing capability patterns

| Required question | Common missing capability | Recommended pattern |
|---|---|---|
| Historical balance/ARR | Current state only | Periodic snapshot or effective history |
| Expansion/contraction | No change events | Movement fact |
| Churn/retention rate | No eligible/opening population | Population snapshot or activity spine |
| Feature adoption rate | No eligibility | Factless eligibility fact |
| Usage by event-time plan | Current plan only | Type 2 plan history or event assignment |
| Cross-fact KPI | Independent grains | Compatible-grain derived fact |
| Session metrics | No session key/order | Incremental session fact |
| Funnel conversion | Raw events only | Journey/funnel-state fact |
| Multi-owner allocation | Many-to-many relationship | Bridge with allocation weight |
| Financial reconciliation | Final ratio only | Retain additive components and ledger mapping |

## Misleading calculations

Flag as unsafe:

- Current active subscriptions grouped by start month as historical active trend.
- Churned subscriptions divided by current active subscriptions.
- Users with any feature event divided by all users when only some users are eligible.
- Average of regional conversion rates without exposure weighting.
- Revenue joined to event facts at user level without aggregation.
- Historical usage grouped by current industry or plan without stating restatement semantics.
- Count of active users in a signup cohort described as cohort retention.
- Daily stock summed across a month.

Offer the closest valid alternative rather than only rejecting the query.

## Question matrix

Use these columns:

| Field | Meaning |
|---|---|
| Business question | Precise question |
| Priority | P0-P3 |
| Decision | Action supported |
| Required grain | Fact grain needed |
| Metric components | Numerator/denominator/state |
| Time semantics | Event/effective/snapshot and period |
| Required models | Tables and joins |
| Status | Answerable/conditional/partial/not/misleading |
| Evidence | Source code/data/profile/definition |
| Assumptions | Explicit assumptions |
| Risk | Consequence of misuse |
| Missing capability | Data or model gap |
| Recommended change | Target pattern |

## Approval standard

A question is approved as answerable only when:

- The business definition is explicit.
- The table grain supports the unit of analysis.
- Required history exists.
- Join paths preserve measures.
- Metric components reaggregate correctly.
- Data quality and completeness are sufficient.
- Consumer interfaces can express the required filters and grain.
- Caveats are documented and enforceable where possible.
