# Output Specifications

## Contents

1. General writing rules
2. Full review report
3. Business-question matrix
4. Table assessment
5. Finding format
6. Target model proposal
7. Cost recommendation
8. Migration plan
9. Generated files
10. Source register

## General writing rules

- Lead with the decision, not a glossary.
- Separate observed facts, derived conclusions, assumptions, and unknowns.
- State the consequence of each material issue.
- Name exact model/member/file when evidence permits it.
- Prefer concrete target grains and structures over generic advice.
- Distinguish correctness changes from optimizations.
- Include unsupported and misleading questions.
- Avoid claiming expected performance improvement without measurement.

## Report structure

One synthesis supplies shared narrative to a single application-rendered Markdown
report. Persist that report plus a structured JSON companion.

The exhaustive review uses these eleven sections:

```markdown
# [Domain or Project] — Data Product Architecture Review

## Decision brief
Decision, material risks table (specialist findings plus grouped deterministic HIGH).

## Business intent and question support
Purpose, consumers, limitations, numbered analytical needs (Q1, Q2, …).

## Modeling architecture
Repair-queue cards for blocker/high modeling findings; model, relationship,
measure, and history assessment tables.

## Quality and contracts
Validation, invariants, declared-versus-implemented alignment.

## Semantic quality and SQL readability
Metadata and readability assessments; deterministic issues grouped by rule × model.

## Physical design and cost
Workload evidence, expensive patterns, cost posture (unknown without measurement).

## Target architecture
Proposed models with grains and dependencies (only when specialists completed).

## Prioritized change plan
Blockers, high, medium, later optimizations.

## Acceptance criteria
Queries, tests, benchmarks, reconciliations, interface checks.

## Residual limitations
Accepted caveats and non-answerable questions.

## Evidence coverage
Readable source-coverage register.
```

Do not invent target architecture or change plans when business context failed or
no specialist dimensions completed. Missing areas must say UNKNOWN / did not
complete.

## Required assessment tables

The report renders structured assessment tables from normalized specialist
outputs. Include only columns that carry populated, decision-useful information;
do not emit wide empty matrix scaffolding. No table may exceed five columns.
Render blocker and high findings as detailed cards and lower-priority findings
as compact tables. Group deterministic metadata issues by rule and model; keep
per-field instances out of the Markdown body. Number intended analytical needs
as `Q1`, `Q2`, and so on; findings refer to those labels instead of repeating
full question text.

## Table assessment

Use:

```markdown
### [model name]

**Purpose:**
**Owner:**
**Pattern:**
**One-row grain:**
**Keys:**
**Lifecycle:**
**Temporal meaning:**
**Current/history:**
**Facts:**
**Dimensions:**
**Relationships:**
**Safe measures:**
**Unsafe calculations:**
**Answerable questions:**
**Conditional/unsupported questions:**
**Expected volume/update:**
**Incremental/physical design:**
**Quality/reconciliation:**
**Security/consumers:**
**Findings and changes:**
```

## Finding format

```markdown
### [severity] [code]: [title]

- **Asset:**
- **Category:**
- **Observed evidence:**
- **Why it matters:**
- **Affected questions/consumers:**
- **Recommendation:**
- **Validation:**
- **Trade-off/residual risk:**
```

Do not report a theoretical anti-pattern without showing how it affects this design.

## Target model proposal

For each proposed model:

```text
Name:
Purpose:
Pattern:
Grain:
Primary/candidate key:
Source models:
History semantics:
Columns/facts/dimensions:
Incremental strategy:
Partition/clustering/layout:
Quality and tests:
Semantic exposure:
Metrics enabled:
Questions enabled:
Questions still unsupported:
Estimated cost trade-off:
Migration dependency:
```

Include a dependency diagram in text or Mermaid when useful.

## Cost recommendation

Use:

| Candidate | Current cost evidence | Proposed structure | Avoided work | Refresh/storage cost | Freshness impact | Correctness constraints | Decision |
|---|---|---|---|---|---|---|---|

Use decision values:

- Query time.
- Precomputed column.
- Derived model.
- Snapshot.
- Aggregate.
- Materialized view.
- Semantic rollup.
- Approximation.
- Cache.
- Restrict/require filter.

## Migration plan

Include:

1. Schema/model additions.
2. Historical backfill.
3. Dual-run or shadow comparison.
4. Metric reconciliation.
5. Semantic/API/BI compatibility checks.
6. Consumer migration.
7. Deprecation period.
8. Cutover.
9. Rollback.
10. Post-cutover monitoring.

For semantic changes, state whether historical results are restated.

## Generated files

Before code, list:

- File path.
- Purpose.
- Dependencies.
- Grain.
- Validation command.

Generate coherent sets. For example, a new historical ARR capability may require:

```text
physical snapshot SQL
semantic YAML
metric YAML
DQ YAML
unit test
audit
rollup
migration note
```

Do not generate only the metric YAML when the physical history does not exist.

## Source register

Use:

| Source | Type | Version/date | What it established | Confidence |
|---|---|---|---|---|

Source types:

- Project source code.
- Test.
- Data profile/query.
- Business definition.
- Official product documentation.
- Inference.

When official guidance changes by version, record the exact version or access date.

## Persisted artifact rules

- Persist one exhaustive Markdown report (`*-review.md`) and one structured
  companion (`*-review.json`) under `.vulcan/reviews`.
- Both artifacts derive from the same deterministic report view.
- Persisted artifacts use platform-neutral terms such as `modeling runtime`,
  `semantic layer`, `data-quality checks`, and `loaded project context`.
- Never name an implementation framework, external package, or internal runtime
  source type in persisted artifacts.
- Never show evidence IDs, hashes, packet types, or usage diagnostics in Markdown.
- Use readable project artifacts and precise line ranges for human citations.
