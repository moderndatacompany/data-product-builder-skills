# Semantic Metadata and AI Context

## Contents

1. Purpose and authority
2. Field contracts
3. Expectations by artifact
4. Quality dimensions
5. Deterministic checks
6. Agent judgment
7. Finding and severity discipline
8. Assessment template

## Purpose and authority

Semantic metadata makes a correct model understandable and safe to use. It does
not make an incorrect model correct. Executable code and loaded model objects are
ground truth for current filters, expressions, grain, lifecycle, and outputs.
Documentation supplies intent, definitions, caveats, and expected use.

Judge metadata against the established business and modeling conclusions. A
description that confidently explains behavior the code does not implement is
worse than an honest omission.

## Field contracts

### Description

A description is the concise, portable human definition of an artifact. It
answers “what is this?” without requiring the reader to inspect implementation.

Include only the details needed for safe interpretation:

- Business meaning and row meaning.
- Grain for models and facts when it is not obvious.
- Unit, currency, scale, or format where relevant.
- Population, exclusions, or baked-in filters when material.
- Time meaning for temporal values and measures.
- Aggregation behavior for measures.
- Null or default meaning when it changes interpretation.

A description should not be a SQL walkthrough, a copied identifier, a generic
phrase such as “value of field,” or a promise the implementation does not meet.

### AI context

AI context tells an AI system how to reason about and safely use the artifact.
It should add information beyond the description through some combination of:

- Instructions and preferred use.
- Business and user synonyms.
- Disambiguation from similarly named concepts.
- Required filters, segments, time dimensions, or join paths.
- Safe and unsafe aggregation or reaggregation.
- Approximation, coverage, sampling, or representativeness caveats.
- Default time, population, currency, and null policies.
- Realistic examples for supported interfaces.
- Unsupported or misleading interpretations.

AI context is not complete merely because every schema field is populated. An
exact or lightly reworded copy of the description adds no reasoning value.

### Tags

Tags are controlled labels used for categorization and discovery, such as
domain, subject, semantic role, lifecycle, criticality, or governance posture.

Tags should come from a recognizable vocabulary, remain consistent across the
product, and avoid duplicating synonyms or prose. A tag is not evidence that an
artifact satisfies the property it names.

### Terms

Terms bind an artifact to an authoritative glossary concept. Each binding should
identify the same business concept represented by the artifact. Terms are not
search keywords, loose associations, or decoration added to improve apparent
coverage.

## Expectations by artifact

### Product

Explain purpose, supported decisions, population, major outputs, users, service
expectations, and material limitations. AI guidance should establish product-wide
defaults and prohibitions that downstream members inherit.

### Model

State business purpose and one-row meaning. Clarify current versus historical
meaning and important population restrictions. AI guidance should explain safe
entry points, preferred time, important joins, and model-level limitations.

### Column or dimension

State business meaning, type-specific semantics, unit, null meaning, valid
values, derivation, and time behavior where relevant. AI guidance is most useful
for ambiguous, coded, derived, sensitive, or commonly misused members.

### Measure

State the business calculation, base population, unit, and aggregation contract.
AI guidance should expose numerator and denominator logic, filters, null/zero
rules, time behavior, non-additivity, approximation, and safe dimensions.

### Segment

State the population selected and the business reason for it. AI guidance should
explain overlap, exclusions, appropriate comparisons, and baked-in policy.

### Join

State relationship meaning and row-preservation intent. AI guidance should warn
about optionality, temporal attribution, ambiguous paths, or restricted use. It
does not substitute for key or cardinality evidence.

### Metric

State the decision-oriented result, component measures, time basis, owner, and
interpretation. AI guidance should explain valid slicing, comparison, caveats,
and realistic use. A metric name must not overclaim what its measure computes.

Private intermediates may require less prose. Public and decision-critical
artifacts require enough information to prevent plausible misuse.

## Quality dimensions

Assess semantic metadata across these dimensions:

- **Correctness:** agrees with executable behavior and authoritative upstream
  conclusions.
- **Specificity:** contains product-specific meaning rather than templates.
- **Added value:** AI context contributes guidance not already in description.
- **Actionability:** a consumer can choose filters, time, dimensions, and
  aggregation safely.
- **Consistency:** related artifacts use compatible definitions and vocabulary.
- **Validity:** tags, terms, member references, and examples resolve correctly.
- **Material coverage:** important public surfaces are documented without
  demanding noise on every internal field.

Useful assessment states are `strong`, `adequate`, `thin`, `misleading`, and
`not_applicable`. Missing metadata is normally `thin`; contradictory metadata is
`misleading`.

## Deterministic checks

Application code should establish objective defects before agent judgment:

- Exact or normalized description/AI-context duplication.
- Empty, placeholder, templated, or identifier-only text.
- Duplicate, malformed, or unknown controlled tags.
- Unresolved or invalid term bindings.
- Examples referencing missing models or members.
- Example syntax that cannot parse for its declared format.
- Metadata attached to nonexistent members.
- Deterministically provable contradictions with executable filters, kinds,
  expressions, or output columns.

Deterministic checks produce evidence; they do not establish business usefulness
or severity by themselves.

## Agent judgment

The specialist judges questions that require context:

- Does the description communicate the intended business concept precisely?
- Does AI context add enough product intuition to guide safe use?
- Are the caveats proportionate to the actual semantic risk?
- Are examples realistic rather than merely syntactically valid?
- Do tags and terms improve discovery and governance coherently?
- Does metadata preserve limitations established at product level?
- Could a plausible consumer be materially misled?

## Finding and severity discipline

- Use `high` only when misleading metadata can cause a materially incorrect
  decision, unsafe aggregation, wrong population, or concealed semantic defect.
- Use `medium` when a public or decision-critical artifact lacks material
  aggregation, population, null, time, or limitation guidance, or when AI
  context is broadly generic or duplicative.
- Use `low` for optional taxonomy, discoverability, or prose improvements that
  do not affect correctness.

Group a repeated root cause into one finding with concrete instances. Do not
create a finding per field. Do not penalize absent optional tags or terms as if
they were broken model contracts.

## Assessment template

For each material artifact or coherent artifact group record:

```text
artifact
public_or_decision_critical
description_state
ai_context_state
taxonomy_state
agreement_with_code
material_strengths
material_gaps
evidence
```
