# Governance, Contracts, and Security

## Contents

1. Data product boundary
2. Ownership and authority
3. Data contracts
4. Schema and semantic compatibility
5. SLAs and support
6. Classification and access
7. Privacy and retention
8. Lineage and auditability
9. Versioning and deprecation
10. Governance review

## Data product boundary

Define:

- Product name and domain.
- Business capability and intended consumers.
- Source-aligned or consumer-aligned purpose.
- Included and excluded entities/processes.
- Output ports and interfaces.
- Usage guidance and limitations.

A data product is not just a folder of tables. It has an accountable owner, a stable contract, support, quality commitments, and explicit permitted uses.

## Ownership and authority

Assign:

- Product owner.
- Data steward.
- Data engineer.
- Analytics engineer.
- Security/privacy owner.
- Metric owner.
- Support and escalation channel.

For each definition, identify the authoritative source. Git history is not a substitute for ownership.

## Data contracts

A useful contract includes:

- Identity, version, status, domain, and purpose.
- Schema and field definitions.
- Keys and grain.
- Semantic definitions and authoritative references.
- Data-quality expectations.
- Freshness, availability, retention, and support SLAs.
- Owners and roles.
- Infrastructure/output locations.
- Security and permitted use.
- Compatibility and deprecation policy.

The Open Data Contract Standard is a useful external structure, but map it to the active Vulcan product configuration and organizational policy rather than copying fields mechanically.

## Schema and semantic compatibility

### Additive changes

Often compatible:

- New nullable field.
- New private metric.
- New optional dimension.

Still validate naming, access, cost, and consumer behavior.

### Breaking changes

Examples:

- Rename or remove field.
- Narrow data type.
- Change grain or key.
- Change metric definition or filter.
- Change current versus historical attribution.
- Change timezone or fiscal calendar.
- Change join cardinality or public path.
- Change null meaning.

Semantic changes can be breaking even when schema is unchanged.

## SLAs and support

Define measurable service-level indicators:

- Freshness or update frequency.
- Availability.
- Completeness.
- Time to detect.
- Time to notify.
- Time to restore.
- End-of-support and end-of-life.

Link each commitment to monitoring and an owner. Avoid an SLA that the platform cannot measure.

## Classification and access

Classify fields and models:

- Public/internal/confidential/restricted.
- PII and sensitive personal data.
- Financial or regulated data.
- Secrets and credentials.
- Tenant-scoped data.

Apply:

- Least privilege.
- Row-level security.
- Column-level security or masking.
- Member-level semantic visibility.
- Tenant isolation.
- Purpose limitation.
- Audit logging.

Security should be enforced in the warehouse or semantic layer, not only documented in AI instructions.

## Privacy and retention

Define:

- Collection purpose.
- Data minimization.
- Consent/legal basis where applicable.
- Retention period.
- Deletion/redaction workflow.
- Residency.
- Failed-row sample policy.
- Non-production data handling.

Historical and audit requirements must be reconciled with privacy deletion obligations. Design pseudonymization, aggregation, or redaction where full retention is not permitted.

## Lineage and auditability

Retain:

- Source-to-model lineage.
- Column derivation.
- Metric dependency.
- Contract and definition version.
- Plan/deployment history.
- Backfill and correction record.
- Data-quality history.
- Access/audit logs where required.

Avoid opaque transformations that cannot explain how a business result was produced.

## Versioning and deprecation

For a breaking change:

1. Document semantic impact.
2. Create a new version or parallel member/model when necessary.
3. Backfill and reconcile.
4. Publish migration guidance.
5. Provide a deprecation window.
6. Monitor old usage.
7. Remove only after owner approval.
8. Retain historical definition references.

Do not silently rewrite historical financial or executive metrics without a restatement policy.

## Governance review

Check:

- Product/domain identity is stable across environments.
- Ownership roles are populated and current.
- Business definitions link to authoritative references.
- Contract matches actual schema and semantic behavior.
- DQ rules and SLAs are executable and monitored.
- Sensitive members are masked or hidden consistently across SQL, REST, GraphQL, BI, and AI.
- Usage guidance includes caveats and non-answerable questions.
- Version and deprecation policy covers semantic changes.
- Support and issue channels are usable.
- No credentials or private keys are committed to modeling files.
