# Dimensional and Temporal Modeling

## Contents

1. Layered architecture
2. Dimensional patterns
3. Dimension techniques
4. Slowly changing dimensions
5. Fact table grains
6. Time semantics
7. Point-in-time correctness
8. Snapshots and movements
9. Cohorts and spines
10. Currency and calendar
11. Pattern selection

## Layered architecture

Use layers to separate responsibilities rather than to create ceremonial copies.

```text
Raw/source capture
-> standardized staging
-> atomic and historical core
-> business marts and aggregates
-> semantic and serving interfaces
```

### Raw or source capture

Preserve source payload, ingestion metadata, operation type, source position, and arrival time. Avoid irreversible business transformation.

### Standardized staging

Normalize names, data types, timezone, encodings, nulls, source-specific codes, and deduplication mechanics. Keep transformations close to one source.

### Atomic and historical core

Represent durable entities, atomic events, transactions, relationships, and history. This layer should support reconstruction and new business logic.

### Business marts

Organize facts and conformed dimensions around business processes. Apply agreed calculations and create compatible-grain derived facts.

### Semantic and serving layer

Expose curated dimensions, measures, metrics, segments, join paths, policies, and workload-specific views.

## Dimensional patterns

### Star schema

Use a central fact joined to descriptive dimensions.

Benefits:

- Clear grain and join paths.
- Predictable BI behavior.
- Reusable conformed dimensions.
- Easier measure aggregation.

Prefer a star as the default analytical serving shape unless another pattern solves a specific requirement better.

### Snowflake dimension

Normalize parts of a dimension into subdimensions.

Use when:

- Hierarchies are large and independently governed.
- Duplication is costly or update semantics require separation.

Flatten for BI when extra joins create complexity with little semantic benefit.

### Fact constellation

Use multiple facts sharing conformed dimensions.

Do not directly join facts merely because they share dimensions. Query each fact at its own grain or aggregate to a compatible grain before combining.

### One Big Table

Use a wide table for a dominant workload with one stable grain. Keep atomic facts and dimensions upstream. Reject mixed grains and duplicated independent facts.

### Data Vault

Use hubs, links, and satellites for auditable source integration and history when those properties justify the complexity. Build dimensional marts for end-user analytics. Do not expose a raw vault directly as a general BI model.

### Medallion architecture

Use bronze/silver/gold as quality and responsibility boundaries, not as mandatory duplication. Gold commonly contains dimensional and aggregate business models. Preserve rebuildability from a reliable lower layer.

## Dimension techniques

### Conformed dimension

Use one governed representation across facts.

Validate:

- Shared business identity.
- Compatible natural keys.
- Same attribute definitions.
- Same historical treatment.
- Same security classification.

### Role-playing dimension

Reuse one dimension in different semantic roles.

Examples:

- Order date, ship date, delivery date.
- Origin location, destination location.

Expose role-specific names even when the physical dimension is shared.

### Degenerate dimension

Keep transaction identifiers such as order number on the fact when a separate dimension adds no attributes.

### Junk dimension

Combine low-cardinality flags or indicators when it simplifies the fact and the combinations are stable. Avoid hiding meaningful business concepts in an opaque junk key.

### Mini-dimension

Separate rapidly changing attributes from a large, slowly changing dimension when Type 2 growth would be excessive and the attributes are analytically useful as a group.

### Outrigger dimension

A dimension joined to another dimension. Use carefully because BI tools may create ambiguous paths; flatten common attributes into the main dimension when practical.

## Slowly changing dimensions

### Type 0: retain original

Never change the attribute after first capture.

Use for immutable origin values such as original signup channel when the business wants first-known attribution.

### Type 1: overwrite

Replace the old value.

Use for corrections or attributes where only the latest value matters. Historical facts will appear under the latest attribute.

### Type 2: preserve versions

Create a new dimension row with validity boundaries.

Typical columns:

```text
surrogate_key
business_key
valid_from
valid_to
is_current
version
```

Use when event-time historical attribution matters. Validate non-overlapping intervals and one current version per business key.

### Type 3: retain limited previous state

Store current and previous value or transition date. Use only when a limited comparison is the explicit requirement.

### Hybrid Type 6

Combine Type 1, 2, and 3 behaviors for selected attributes. Use only when consumers understand the semantics and the maintenance complexity is justified.

### Do not default to Type 2

Type 2 adds storage, merge logic, temporal joins, and restatement complexity. Apply it only to attributes whose historical value changes business interpretation.

## Fact table grains

### Transaction fact

Atomic event or transaction. Flexible and auditable; expensive for repeated high-level queries.

### Periodic snapshot

State at a regular boundary. Strong for balances, inventory, active counts, and historical ARR.

### Accumulating snapshot

One process instance updated through milestones. Strong for elapsed time and pipeline bottlenecks.

### Timespan fact

Effective-dated fact row when state changes irregularly and repeated periodic snapshots would create excessive identical rows. Querying requires interval logic.

## Time semantics

Name each temporal field by meaning:

- **event_time:** when the business event occurred.
- **effective_time:** when a state or rule became valid.
- **recorded_time:** when the source recorded it.
- **ingestion_time:** when the platform received it.
- **processing_time:** when transformation ran.
- **snapshot_time:** boundary represented by a snapshot.
- **reporting_period:** accounting or business period.
- **valid_from / valid_to:** interval for a version.

Do not use a generic `date` or `timestamp` when multiple temporal meanings exist.

## Point-in-time correctness

For a fact at time `t`, use only information that was valid and available under the intended analytical contract at `t`.

Important distinctions:

- Event-time truth versus current-state restatement.
- Effective time versus ingestion time.
- Knowledge available then versus corrected data known now.
- Operational state versus financial period-locked state.

### Temporal join

Typical Type 2 predicate:

```sql
fact.event_time >= dim.valid_from
AND fact.event_time < COALESCE(dim.valid_to, TIMESTAMP '9999-12-31')
```

Range joins can be expensive. When event-time attribution is stable and heavily queried, resolve the surrogate key during ingestion or materialize an assignment model.

### Bitemporal modeling

Use valid time and system/recorded time when users must ask both:

- What was true in the business?
- What did the system believe at a given time?

Use only for high-value audit or correction requirements because complexity is substantial.

## Snapshots and movements

### Snapshot

Represents state at a point or period boundary.

Use for:

- Period-end ARR.
- Inventory level.
- Account balance.
- Active seats.

### Movement fact

Represents change between states.

Use for:

- New business.
- Expansion.
- Contraction.
- Churn.
- Reactivation.

A strong revenue design often includes both:

```text
subscription_monthly_snapshot
subscription_movement
```

The snapshot reconciles closing balance; movements explain why it changed.

## Cohorts and spines

### Cohort assignment

Define the cohort event once: signup, first purchase, activation, or subscription start.

### Activity spine

Create one row per entity per relevant period when retention, status, or eligibility must be evaluated consistently.

Example grain:

```text
one row per user per activity_month
```

Columns may include cohort month, age in months, eligible flag, active flag, revenue, and lifecycle state.

### Date spine

Use a calendar or generated time spine to preserve zero-activity periods and compute period comparisons. Do not infer missing periods as zero unless the source completeness contract permits it.

## Currency and calendar

### Currency

Record:

- Original amount.
- Currency code.
- Exchange-rate source.
- Rate date and type.
- Converted amount and reporting currency.

Do not sum mixed currencies without conversion. Separate booked, billed, collected, and recognized amounts.

### Calendar

Define:

- Timezone.
- Week start.
- Fiscal calendar.
- Period close.
- Holiday/business-day logic.
- Partial-period behavior.

Metrics must use the same calendar semantics across SQL, REST, GraphQL, BI, and AI examples.

## Pattern selection

Use:

- Current-state entity for current operational questions.
- Type 2 dimension for historical descriptive attribution.
- Event or movement fact for lifecycle causes and deltas.
- Periodic snapshot for historical balances and stocks.
- Factless fact for eligibility or exposure.
- Bridge for legitimate many-to-many relationships.
- Compatible-grain aggregate for repeated cross-fact analysis.
- Atomic fact plus targeted aggregate for flexibility and performance.
