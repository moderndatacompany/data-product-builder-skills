# Serving BI, APIs, AI, and Machine Learning

## Contents

1. Shared truth, specialized serving
2. BI serving
3. Tableau
4. Power BI
5. SQL, REST, and GraphQL
6. AI agents
7. Machine learning
8. Operational APIs and reverse ETL
9. Finance and audited reporting
10. Consumer compatibility matrix

## Shared truth, specialized serving

Maintain shared atomic facts, history, conformed dimensions, and metric definitions. Create specialized serving representations when workload needs differ.

Do not force one physical table to optimize simultaneously for:

- Flexible ad hoc SQL.
- Executive dashboards.
- Low-latency API lookup.
- AI natural-language exploration.
- ML point-in-time features.
- Financial close and audit.

The serving layer may differ; the business definition must remain consistent.

## BI serving

BI models should provide:

- Clear facts and dimensions.
- Stable star-like relationships.
- One intentional path between public concepts.
- Human-readable names and descriptions.
- Valid time dimensions and hierarchies.
- Safe measures with reaggregation behavior.
- Curated segments and drill paths.
- Hidden technical keys and private models.
- Fast common aggregates.

Avoid:

- Public cycles.
- Ambiguous reciprocal joins.
- Many-to-many facts without a bridge.
- Mixed-grain wide tables.
- High-cardinality fields as default groupings.
- Current-state dimensions silently applied to history.
- Ratios stored without components.

## Tableau

Tableau relationships keep logical tables separate and can preserve each table's level of detail. Cardinality and referential-integrity options influence aggregation and join optimization.

Guidance:

- Prefer relationships over physical flattening when facts have different grains and the Tableau version supports the required multi-fact model.
- Set cardinality to one only when uniqueness is proven.
- Set all-records-match only when referential integrity is proven.
- Retain conservative defaults when uncertain.
- Use physical joins inside a logical table only when one stable row grain results.
- Test selected field combinations because query generation can change with the view.

A false performance hint can produce missing or duplicated results.

## Power BI

Prefer:

- Dimension-to-fact one-to-many relationships.
- Single-direction filtering by default.
- Shared conformed dimensions between facts.
- Bridge tables for multivalued relationships.
- Separate role-playing date dimensions or inactive relationships with explicit measures where appropriate.

Avoid:

- Direct fact-to-fact many-to-many relationships.
- Uncontrolled bidirectional filtering.
- Ambiguous relationship paths.
- Mixing dimensions and facts in the same table without a stable grain.

For higher-grain target or plan facts, model the dimensions at compatible grain rather than forcing a relationship to lower-grain sales rows.

## SQL, REST, and GraphQL

### SQL

Support:

- Predictable names.
- Valid grouping and filtering.
- Safe join generation.
- Explicit measure invocation where the platform requires it.
- Reasonable defaults and limits.

### REST

Validate:

- Member identifiers.
- Time-dimension and date-range syntax.
- Filter and segment support.
- Pagination and result limits.
- Error behavior for unsupported combinations.

### GraphQL

Validate:

- Supported dimensions and filters.
- Time grain representation.
- Segment parity or documented alternatives.
- Nested query shape and null behavior.

Do not claim interface parity when a feature such as segments or complex filters is unavailable. Provide equivalent supported patterns or document the limitation.

## AI agents

AI-facing models need stronger semantic metadata because agents cannot infer organizational context safely.

Provide:

- Purpose and intended questions.
- Grain and entity meaning.
- Preferred metric and time dimension.
- Synonyms and business vocabulary.
- Safe dimensions and join paths.
- Required filters or segments.
- Stock/flow/additivity caveats.
- Examples for each supported interface.
- Unsupported and misleading questions.
- Privacy and access restrictions.

Guardrails:

- Hide unsafe raw members.
- Expose curated views.
- Constrain ambiguous join paths.
- Require date filters for expensive large facts when appropriate.
- Mark approximate metrics.
- Explain current-state versus event-time attribution.
- Return limitations instead of fabricating unavailable answers.

## Machine learning

ML serving requires:

- Point-in-time correct features.
- Stable entity keys.
- Event and feature timestamps.
- Historical feature values.
- Training/serving transformation consistency.
- Leakage prevention.
- Backfill reproducibility.
- Feature freshness and default behavior.

A BI-friendly current-state dimension may be invalid for training historical examples. Build event-time feature assignments or feature snapshots.

## Operational APIs and reverse ETL

Operational consumers often need:

- Current state.
- Point lookup by stable key.
- Low latency and high availability.
- Strict schema and pagination.
- Idempotent change feed or delivery.
- Explicit freshness and conflict behavior.

Do not serve a broad analytical join graph as an operational API without workload isolation and contract design. Create a current-state serving table or API projection.

## Finance and audited reporting

Require:

- Locked reporting periods.
- Versioned definitions.
- Exact currency and precision.
- Reconciliation to ledger or billing source.
- Restatement policy.
- Traceable adjustments.
- Opening, movement, and closing equations.

Finance may need a period-stable snapshot different from a continuously corrected analytical model.

## Consumer compatibility matrix

Use this table for each public model or metric:

| Consumer | Required grain | Freshness | Latency | History | Exactness | Safe joins | Security | Serving model |
|---|---|---|---|---|---|---|---|---|
| BI dashboard | | | | | | | | |
| Ad hoc SQL | | | | | | | | |
| REST API | | | | | | | | |
| GraphQL | | | | | | | | |
| AI agent | | | | | | | | |
| ML feature | | | | | | | | |
| Finance | | | | | | | | |

Create separate serving assets when requirements conflict materially.
