# Pattern Selection: Metrics and Computation

Use this reference when judging how a measure or metric is computed and where that computation lives. Select patterns because they solve a demonstrated problem, not because they are fashionable.

Computation choice is a meaning question before it is a cost question: where a calculation happens decides which aggregations stay valid. The physical shape it materializes into belongs to structure; the interface it is served through belongs to contract.

## Contents

1. Where the computation lives
2. Distinct-count patterns
3. Stock, ratio, and sequence metrics
4. Rejection tests

## 1. Where the computation lives

### Query-time calculation

Choose when:

- The expression is cheap.
- Query frequency is low.
- Logic changes frequently.
- The engine can prune and push down effectively.
- Materialization maintenance would exceed benefit.

### Precomputed derived column

Choose when:

- Logic is deterministic and stable.
- It is reused across many tools.
- It is expensive or inconsistent when repeated.
- Its lineage and definition can be governed centrally.

Do not precompute parameter-dependent classifications as fixed columns unless the parameter is part of the model grain/version.

### Derived fact or mart

Choose when:

- The transformation establishes a reusable business grain.
- Multiple consumers repeat the same joins/windows.
- The result supports drill-through to atomic facts.
- Refresh and backfill can be tested.

### Aggregate fact / rollup

Choose when repeated queries use a stable subset of dimensions and measures.

Require:

- Aggregate grain.
- Additivity/reaggregation contract for each measure.
- Time grain.
- Refresh and late-data strategy.
- Hit-rate or workload evidence.
- Drill path to detail.

Do not include ratios alone; preserve numerator and denominator.

## 2. Distinct-count patterns

### Exact distinct entity-period fact

For DAU/WAU/MAU or adoption, materialize one row per entity per required period or lowest reusable period.

Examples:

```text
user_activity_day(user_id, activity_date, feature_id)
user_activity_month(user_id, activity_month)
```

Do not derive MAU by summing DAU.

### Approximate distinct sketch

Choose when:

- Cardinality is very high.
- Exactness tolerance is explicitly accepted.
- The engine supports mergeable sketches.
- Consumers understand error bounds and reaggregation rules.

Keep exact pathways for reconciliation or regulated metrics.

## 3. Stock, ratio, and sequence metrics

### Snapshot metric

Use for stocks. Store or derive period-end components, and expose allowed time treatment such as last, first, average balance, minimum, or maximum.

### Ratio metric

Store numerator and denominator at a compatible grain. Calculate the ratio after aggregation.

Reject:

- Average of row-level ratios without weighting.
- Sum of percentages.
- Ratio whose denominator population is undefined.

### Funnel or sequence state

Precompute when repeated self-joins or windows over raw events dominate cost. Preserve stage timestamps, conversion window, ordering, and model version.

## 4. Rejection tests

Reject or redesign a proposed computation when any of these is true:

- A rollup contains non-reaggregatable values without components.
- A cost optimization changes the metric definition.
- A ratio is exposed without its numerator and denominator at a compatible grain.
- A distinct count is reaggregated across periods by summing lower-period counts.
- A stock measure is declared additive across time.
