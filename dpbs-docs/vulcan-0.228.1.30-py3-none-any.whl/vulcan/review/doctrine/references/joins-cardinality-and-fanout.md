# Joins, Cardinality, and Fanout

## Contents

1. Relationship contract
2. Cardinality evidence
3. Referential integrity
4. Row preservation
5. Fanout and chasm traps
6. Fact-to-fact analysis
7. Bridges and allocation
8. Temporal joins
9. Cycles, reciprocal joins, and diamonds
10. BI-specific behavior
11. Join validation queries
12. Safe remedies

## Relationship contract

For each edge, record:

```text
Source model and grain:
Target model and grain:
Join columns and types:
Cardinality:
Referential integrity:
Direction and preserved side:
Temporal validity:
Null and orphan behavior:
Measures allowed through the path:
BI/API exposure:
```

A relationship is not defined by matching names. It is defined by business identity, key stability, observed uniqueness, and intended row preservation.

## Cardinality evidence

### One-to-one

Each key appears at most once on both sides.

Use for true extensions or vertically separated attributes. Verify that optional rows do not unexpectedly filter the base.

### One-to-many

The one-side key is unique; the many side can repeat.

Typical dimension-to-fact relationship.

### Many-to-one

Same relationship viewed from the fact side.

### Many-to-many

Both sides can repeat the key. This is not automatically wrong, but measures can multiply. Require a bridge, compatible-grain aggregation, or explicit allocation semantics.

### Prove, do not assume

Check uniqueness on the intended one side and duplication distribution on the many side. Profile historical and current partitions, not only a sample.

## Referential integrity

Determine:

- Can every fact find its dimension?
- Can dimensions exist without facts?
- Are missing keys late-arriving, invalid, deleted, or intentionally optional?
- Does the consumer require unmatched rows?

Incorrectly asserting referential integrity can drop data. Leaving it unknown can reduce optimization. Prefer correctness unless strong evidence supports a stricter contract.

## Row preservation

State which rows must survive:

- All facts, even when dimension data is missing.
- All entities, even without activity.
- Only matched records.

This determines join direction and type. Semantic systems may generate left joins based on directed relationships, so direction is part of business behavior.

## Fanout and chasm traps

### Fanout

A row on one side matches multiple rows on the other side, multiplying measures.

Example:

```text
one user
x three subscriptions
x one hundred usage events
= three hundred joined rows
```

Summing subscription MRR or usage event count after this join is wrong.

### Chasm trap

Two or more fact tables connect through shared dimensions and are queried together, producing a Cartesian multiplication within dimension groups.

### Symptoms

- Totals increase after adding a dimension or measure from another table.
- Distinct counts appear correct while sums inflate.
- BI results depend on selected fields.
- Query plans show output rows far exceeding input rows.

## Fact-to-fact analysis

Do not directly join independent facts at a shared entity unless the business relationship is one-to-one at the target grain.

Use one of these patterns:

1. Aggregate each fact to the same grain and then join.
2. Build a purpose-specific derived fact.
3. Add the missing direct relationship key to the event at source or enrichment time.
4. Use conformed dimensions and query facts independently in a semantic layer capable of multi-fact analysis.
5. Build a bridge with precise event-time assignment.

Example: usage by subscription plan

Safe options:

- Store `subscription_id` on usage events.
- Resolve `plan_id_at_event_time` through effective-dated history.
- Aggregate usage per user-period, then join to one plan assignment per user-period.

Unsafe option:

- Join all usage events to all subscriptions for the user.

## Bridges and allocation

Use a bridge for legitimate multivalued relationships.

Example grain:

```text
one row per account_id + owner_id + validity interval
```

For additive measures assigned to multiple members, define an allocation weight.

Validate:

```text
sum(allocation_weight) = 1
for each allocated object and effective period
```

If full credit is intentionally assigned to every member, label the resulting measure as duplicated/non-additive across the multivalued dimension.

## Temporal joins

Use effective intervals when the relationship or attribute changes.

Validate:

- No overlapping intervals for the same business key.
- No unintended gaps.
- Clear inclusive/exclusive boundary.
- Timezone alignment.
- Late corrections and backdated changes.
- One matching version per fact.

Repeated range joins can be expensive. Materialize event-time assignments for high-volume, stable workloads.

## Cycles, reciprocal joins, and diamonds

### Reciprocal joins

A semantic model may need both A to B and B to A navigation internally. Many BI tools cannot safely expose both because the relationship graph becomes cyclic or ambiguous.

Use:

- One intentional BI direction.
- `skip_for_bi` or the active Vulcan equivalent on the back edge.
- Separate curated views for different base perspectives.

Do not hide both directions unless isolation is intentional.

### Diamond paths

A reaches D through both B and C. Queries may choose different paths or duplicate data.

Resolve with:

- Explicit join paths in curated views.
- Aliased role-specific dimensions.
- Separate semantic views for each path.
- Removing redundant public paths.

### Cycles

Cycles can be valid in a conceptual graph but unsafe for generated SQL and BI. Public serving graphs should be acyclic or path-constrained unless the engine explicitly handles cycles.

## BI-specific behavior

### Tableau

Relationships preserve table-level context and can aggregate before joining. Cardinality and referential-integrity settings affect correctness and optimization. Use conservative defaults when evidence is absent; do not falsely claim uniqueness or complete matching.

### Power BI

Prefer star schemas and one-to-many relationships. Avoid ambiguous bidirectional filtering and direct many-to-many fact relationships. Use bridge dimensions or shared dimensions at compatible grain.

### Cube and Vulcan

Joins are directed. Public views should select intentional paths and hide internal or ambiguous edges. Verify pre-aggregation matching through joins.

## Join validation queries

### Uniqueness on one side

```sql
SELECT join_key, COUNT(*) AS n
FROM dimension
GROUP BY join_key
HAVING COUNT(*) > 1;
```

### Orphans

```sql
SELECT COUNT(*) AS orphan_rows
FROM fact f
LEFT JOIN dimension d ON f.dimension_id = d.dimension_id
WHERE f.dimension_id IS NOT NULL
  AND d.dimension_id IS NULL;
```

### Fanout ratio

```sql
SELECT
  COUNT(*) AS joined_rows,
  COUNT(DISTINCT f.fact_id) AS distinct_facts,
  1.0 * COUNT(*) / NULLIF(COUNT(DISTINCT f.fact_id), 0) AS fanout_ratio
FROM fact f
JOIN other o ON ...;
```

### Measure preservation

Compare totals before and after the join at the same filter scope.

```sql
WITH base AS (...), joined AS (...)
SELECT
  (SELECT SUM(amount) FROM base) AS base_total,
  (SELECT SUM(amount) FROM joined) AS joined_total;
```

## Safe remedies

- Correct the key or cardinality metadata.
- Deduplicate a dimension using a justified rule.
- Introduce a bridge.
- Add an event-time foreign key.
- Aggregate before joining.
- Build a derived compatible-grain fact.
- Expose separate views with explicit join paths.
- Restrict unsafe measures through a path.
- Preserve unmatched rows using the correct direction.
- Add uniqueness, orphan, and measure-preservation tests.
