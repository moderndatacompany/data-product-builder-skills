# Discovery and Business Questions

## Contents

1. Start from decisions
2. Minimum discovery
3. Business process canvas
4. Question decomposition
5. Workload and service expectations
6. Definition and reconciliation
7. Missing requirements
8. Question prioritization
9. Deliverables

## Start from decisions

Do not begin by asking which columns the user wants. Begin with the decision or action that the model must support.

Examples:

- Decide whether to invest in a product feature.
- Forecast cash and revenue.
- Identify accounts at churn risk.
- Allocate sales capacity.
- Monitor a contractual SLA.
- Trigger an operational workflow.

For each decision, identify the question, metric, grain, time horizon, audience, and consequence of an incorrect answer.

## Minimum discovery

Collect enough information to prevent fundamental design errors. Do not require every answer before making progress.

### Business intent

- What business capability or process is being modeled?
- What decisions will be made from it?
- Which questions are mandatory for launch?
- Which questions are future possibilities rather than committed scope?
- Which existing report, ledger, or operational system is authoritative?

### Consumers

- Data analysts and ad hoc SQL.
- Executives and dashboards.
- Finance and audited reporting.
- Product and growth teams.
- Operational APIs and reverse ETL.
- AI agents and natural-language analytics.
- Machine learning and feature generation.

### Service expectations

- Freshness.
- Query latency.
- Concurrency.
- Historical depth.
- Exactness or acceptable approximation.
- Availability and recovery.
- Cost ceiling.

### Governance

- Owner and steward.
- Sensitive fields.
- Allowed audiences.
- Retention and residency.
- Contract and deprecation policy.

## Business process canvas

For each process, fill this structure:

```text
Process:
Business event or state:
Primary entity:
One-row grain candidate:
Lifecycle states:
Event time:
Effective time:
Current state source:
Historical source:
Measures:
Dimensions:
Required questions:
Authoritative reconciliation:
Expected volume and change rate:
Consumers and freshness:
```

Example for subscriptions:

```text
Process: Subscription lifecycle
Events: started, renewed, upgraded, downgraded, paused, cancelled, reactivated
Entity: subscription contract
Current-state grain: one row per subscription
Change-event grain: one row per subscription change
Snapshot grain: one row per subscription per snapshot date
Measures: MRR, ARR, seats, expansion, contraction, churn
Time: effective_at, recorded_at, snapshot_date, billing_period
```

The canvas reveals when one table cannot safely represent current state, history, and movements at once.

## Question decomposition

Turn each business question into an executable semantic contract.

### Decomposition fields

- Question text.
- Decision supported.
- Required metric.
- Numerator and denominator.
- Eligible population.
- Required fact grain.
- Required dimensions.
- Required time dimension and period.
- Current-state or event-time attribution.
- Required history.
- Exact or approximate.
- Freshness and latency.
- Reconciliation source.
- Permitted assumptions.

### Example: monthly customer churn rate

```text
Question: What percentage of customers churned in each month?
Numerator: customers whose agreed churn event became effective in the month
Denominator: eligible active customers at the agreed opening or average population
Unit of analysis: customer, not subscription, unless explicitly defined otherwise
Time: churn effective date
History required: opening population and reactivation history
Exclusions: test accounts, internal accounts, involuntary churn if excluded
Reaggregation: recompute numerator / denominator; never average monthly percentages
```

Without the denominator and lifecycle definition, a cancellation count is not a churn rate.

## Workload and service expectations

Record these per question or workload:

| Attribute | Why it changes design |
|---|---|
| Query frequency | Determines materialization value |
| Concurrency | Determines serving and cache requirements |
| Freshness | Determines incremental cadence and cost |
| Historical depth | Determines storage, snapshots, and partitioning |
| Dimensional flexibility | Determines atomic versus aggregate serving |
| Exactness | Determines exact distinct versus approximation |
| Latency | Determines rollups, materialized views, or engine choice |
| Drill detail | Determines whether aggregates need links to atomic facts |
| Reconciliation | Determines retained components and audit history |

Ask whether the decision genuinely needs minute-level freshness. Faster refresh often increases ingestion, merge, compaction, cache-invalidation, and compute cost.

## Definition and reconciliation

For every important term, capture:

- Business definition.
- Technical implementation.
- Owner.
- Effective date and version.
- Included and excluded populations.
- Timezone and calendar.
- Source of truth.
- Tolerance.
- Known differences from existing reports.

Common ambiguous terms:

- Customer versus user versus account.
- Active.
- Revenue: booked, billed, collected, recognized, gross, net.
- Churn: logo, subscription, voluntary, involuntary, gross, net.
- Conversion.
- Retention.
- Adoption.
- Engagement.
- Current plan versus plan at event time.

## Missing requirements

Do not stop the review for every missing detail. Separate missing information into:

### Must know before design

- Business process and candidate grain.
- Required historical meaning.
- Metric unit of analysis.
- Key source lifecycle.
- Sensitive-data constraints.

### Can proceed with explicit assumption

- Display labels.
- Low-risk dimension naming.
- Initial refresh cadence.
- Optional drill fields.

### Must measure in implementation

- Row volumes.
- query frequency.
- Scan and shuffle cost.
- Late-arrival distribution.
- Cardinality and orphan rates.

## Question prioritization

Score each question using:

- Business impact.
- Decision frequency.
- Consumer count.
- Regulatory or financial importance.
- Cost of an incorrect answer.
- Current pain or compute cost.
- Data readiness.

Use tiers:

- **P0:** Required for correctness, regulation, finance, or launch.
- **P1:** High-value recurring decision.
- **P2:** Useful analysis with a reasonable workaround.
- **P3:** Exploratory or future possibility.

Do not distort the core grain to optimize a P3 question at the expense of P0 correctness.

## Deliverables

Produce:

1. Business process map.
2. Prioritized question catalog.
3. Definition register.
4. Workload profile.
5. Assumption and unknown register.
6. Initial mapping from questions to required facts, dimensions, history, and metric components.
