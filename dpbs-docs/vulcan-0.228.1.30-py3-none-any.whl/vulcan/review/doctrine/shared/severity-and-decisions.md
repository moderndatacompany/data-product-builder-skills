# Shared Severity and Decision Rules

## Finding priority

- **Blocker:** Material analytical incorrectness, unavoidable data loss,
  structurally unsafe aggregation/fanout, or another defect that prevents safe
  use for the declared purpose.
- **High:** Material correctness, reproducibility, contract, or cost risk that
  requires structural change before broad reliance.
- **Medium:** A bounded weakness, missing validation, or credible growth risk
  with a practical mitigation.
- **Low:** A localized improvement that does not materially change current
  analytical safety.

Do not inflate severity because implementation differs from a preferred pattern.
Every finding must state root cause, consequence, recommendation, validation,
residual risk, affected instances, and evidence.

## Independent decisions

Review completion, modeling quality, and physical cost are independent:

- `complete` means all required stages returned valid results and synthesis
  succeeded.
- `partial` means a required stage or synthesis failed or is missing.
- Modeling verdicts are `validated`, `watch`, `changes_required`, and
  `incomplete`.
- Cost verdicts are `appropriate`, `watch`, `risk`, and `unknown`.

A complete review may require modeling changes and identify cost risk. Findings
do not make a run partial.

## Decision hierarchy

```text
business truth
> metric and temporal correctness
> data integrity and reproducibility
> consumer safety
> operability and cost
> authoring convenience
```

Never optimize an analytically incorrect design. A `FULL` model is not
automatically wrong, but without measured workload or scale evidence it cannot
receive an `appropriate` cost verdict.
