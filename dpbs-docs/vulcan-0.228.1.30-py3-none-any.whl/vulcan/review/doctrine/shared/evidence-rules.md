# Shared Evidence Rules

## Evidence classes

- **Declared:** Product contracts, README, agreement, usage, use cases,
  limitations, descriptions, and configuration.
- **Executable:** SQL, semantic/metric/DQ YAML, tests, audits, assertions,
  macros, and policies.
- **Observed:** Physical metadata, query results, profiles, execution plans, and
  measured workload.
- **Derived:** Deterministic application analysis of loaded project evidence.
- **Inferred:** A provisional interpretation needed to continue the review.
- **Unknown:** A conclusion that available evidence cannot establish.

Executable behavior establishes what the product currently does. Declared
evidence establishes what it claims or intends to do. A disagreement is a
contract-alignment candidate, not something to silently resolve.

## Runtime packet behavior

When invoked by `vulcan review`, the supplied immutable packet is the complete
normal-path evidence set. Do not relist the project, reread packet entries, or
rediscover doctrine. Request supplemental evidence only for a concrete gap that
the packet cannot answer.

## Claim discipline

- Cite the exact supplied artifact and the narrowest supported line range.
- Every evidence block begins with `Target: <path>`. In each
  `EvidenceCitation`, set `artifact` to that **exact** `Target` string (for
  example `models/semantics/quote.yml`). Do not use basename-only paths such as
  `quote.yml` unless that string is literally the `Target` value shown.
- Copy `evidence_id` values exactly from the same evidence block (`## Evidence
  ev-…`). Do not invent, truncate, or reuse IDs from another block. Unknown IDs
  are dropped by application code and must not fail an otherwise valid
  business-context result.
- Project-file evidence is displayed with explicit artifact-local
  `line | content` prefixes. Copy those numbers exactly; do not count prompt
  headings, wrapped display rows, doctrine, or adjacent evidence blocks.
- Distinguish facts, derived conclusions, assumptions, and unknowns.
- Preserve qualifiers and scope.
- Never infer semantics only from names when stronger evidence is available.
- Never claim a data invariant passed when physical validation was unavailable.
- Never turn missing workload evidence into a positive cost conclusion.
- Global claims require an exhaustive inventory proving global scope.

Evidence IDs and SHA-256 values are internal traceability fields. They belong in
structured citations and JSON, not human-facing prose or Markdown tables.
