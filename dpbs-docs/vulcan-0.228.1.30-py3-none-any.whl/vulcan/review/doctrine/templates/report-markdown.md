# Report template: Markdown

Return Markdown only. No preamble, no closing commentary, no code fence around
the whole document. Your output is written to disk verbatim as the report.

Start at the title and follow this structure. Section order is fixed. Omit a
section only when the instruction below says it is conditional.

---

# Architecture review: {project name}

One paragraph. State the single most consequential conclusion about this data
product and what it means operationally. A reader who stops here should know
whether they can trust the product and what the biggest problem is. Do not open
with scope, methodology, or a restatement of the request.

## Decision summary

| | |
|---|---|
| Review run | {status} |
| Modeling readiness | {modeling verdict} |
| Cost posture | {cost verdict} |
| Scope | {n} models, {n} files |
| Blockers / High | {n} / {n} |
| AI readiness | {tier label} |

The four values above are supplied to you as application-owned facts. Reproduce
them exactly. Do not soften, upgrade, or reinterpret them, and do not write
prose elsewhere in the report that contradicts them.

Follow the table with two or three sentences explaining what the verdicts mean
for someone deciding whether to build on this product.

## What this product is for

### Product at a glance

| Context | What matters |
|---|---|
| Purpose | |
| Decisions | |
| Consumers | |
| Delivery expectations | |
| Material limitations | |

### Intended analytical needs

| Ref | Priority | Need | Known limitation | Evidence |
|---|---|---|---|---|

Number the refs Q1, Q2, and so on, and reference those short labels from
findings rather than repeating the question text.

### Intent or stage conflicts

| Subject | Stated or upstream | Code or downstream | Evidence |
|---|---|---|---|

Omit this subsection when there are none. Where stated intent and implemented
behavior disagree, carry it into the findings rather than resolving it silently.

## Material findings

Every BLOCKER and HIGH finding, ordered by priority then by blast radius.

For each, a subsection headed with the finding sentence. Cover what is wrong,
why it matters to a consumer of this data, what to change, and how to know the
change worked. Cite as `path/to/artifact.sql:120-134`.

Do not pad. A finding with nothing to say beyond its title should be in the
table below instead.

### Remaining findings

MEDIUM and LOW findings as one table:

| Priority | Category | Model | Finding | Action |
|---|---|---|---|---|

Omit this subsection entirely when there are none.

## Architecture assessment

The state of the product across the three review boundaries: whether its
mechanics line up, whether its exposed meaning matches its data, and whether its
guarantees are enforced. Include what is sound, not only what is broken — a
review that lists only defects gives no sense of proportion.

Physical design and cost belongs here too, as part of the structural picture.

## Change plan

Ordered, specific, and attributable to a file or model. Each item states what to
change and what it unblocks. Sequence by dependency, not by severity: a fix that
must land before another is possible comes first even when it is less severe.

Acceptance criteria for each item must be executable or objectively observable —
a query that must return zero rows, an audit that must exist and pass, a
cadence that must match. "Reviewed and confirmed" is not an acceptance criterion.

## Evidence and limits

### Source coverage

Built from the supplied source ledger:

| Source group | Coverage | Role |
|---|---|---|

Then: what was examined, what was not, and what could not be established. Name
the specific evidence boundary rather than gesturing at it — if physical
validation was unavailable, say which claims that leaves unverified.

Close with anything the review deliberately did not cover.

---

## Rules

- Never print internal evidence identifiers or SHA-256 hashes. Human citations
  are `artifact:line` only.
- Use platform-neutral language. Do not name implementation technologies or
  external framework brands anywhere in the report.
- Every finding in the supplied findings list must appear somewhere: material
  ones in their own subsection, the rest in the remaining-findings table. Do not
  drop one, do not invent one.
- The deterministic constraints supplied to you are facts. You may not write
  anything that contradicts them.
- Do not describe the review process, the stages that ran, or the fact that you
  are an assistant.
