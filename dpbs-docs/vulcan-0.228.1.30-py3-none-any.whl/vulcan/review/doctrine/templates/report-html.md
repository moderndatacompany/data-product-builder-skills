# Report template: HTML

Return one complete HTML document and nothing else. No Markdown, no preamble, no
code fence around the document. Your output is written to disk verbatim.

The shell and stylesheet below are **fixed**. Copy them exactly, character for
character. Do not restyle, re-theme, rename a class, add a font, or add a
colour. Every run of this review must look identical; only the content
between the section markers is yours to write.

The shell already includes a light/dark toggle: a visually-hidden checkbox
plus a `<label>` styled as a button, switched with the `:has()` selector — no
script involved. Copy it exactly along with everything else. Do not add a
second toggle, a `prefers-color-scheme` block, or any other theming of your
own.

The document must be inert and self-contained: no `<script>`, no event handler
attributes, no external stylesheet, font, or image. The application refuses to
write a report that contains any of them.

## Escaping

You are writing the markup yourself, so escaping is your responsibility. Any
model name, column name, description, or SQL fragment you interpolate must have
`&` written as `&amp;`, `<` as `&lt;`, `>` as `&gt;`, and `"` as `&quot;` inside
attributes. A SQL predicate containing `<` will break the page otherwise.

## Fixed shell

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{PROJECT} — Data Product Architecture Review</title>
<style>
:root{
  --bg:#f3f2ed; --surface:#ffffff; --surface-2:#eae7dd; --ink:#20242b; --ink-muted:#565c66;
  --border:#d8d4c9; --accent:#2e5c63; --accent-soft:#dceae8; --accent-ink:#173436;
  --sev-blocker:#b3261e; --sev-blocker-bg:#fbe9e7;
  --sev-high:#a5641c; --sev-high-bg:#fbeedd;
  --sev-medium:#8a6d1b; --sev-medium-bg:#f7f0da;
  --sev-low:#565c66; --sev-low-bg:#eae7dd;
  --font-display: Georgia, "Iowan Old Style", "Palatino Linotype", serif;
  --font-body: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --font-mono: ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas, monospace;
}
*{ box-sizing:border-box; }
html{ scroll-behavior:smooth; }
body{
  margin:0; background:var(--bg); color:var(--ink); font-family:var(--font-body);
  font-size:16px; line-height:1.6; -webkit-font-smoothing:antialiased;
}
a{ color:var(--accent); }
h1,h2,h3,h4{ font-family:var(--font-display); font-weight:700; color:var(--ink); }
code{ font-family:var(--font-mono); font-size:.86em; }
.eyebrow{
  font-family:var(--font-mono); text-transform:uppercase; letter-spacing:.08em;
  font-size:.72rem; color:var(--ink-muted); font-weight:600;
}
.masthead{
  background:linear-gradient(180deg, var(--surface-2), var(--bg));
  border-bottom:1px solid var(--border); padding:2.6rem 1.5rem 1.8rem;
}
.masthead-inner{ max-width:1180px; margin:0 auto; position:relative; }
.sr-toggle{ position:absolute; opacity:0; width:1px; height:1px; overflow:hidden; }
.theme-toggle{
  position:absolute; top:0; right:0; display:inline-flex; align-items:center; justify-content:center;
  border:1px solid var(--border); background:var(--surface); color:var(--ink); border-radius:999px;
  width:2.2rem; height:2.2rem; font-size:1.1rem; cursor:pointer; line-height:1;
}
.theme-toggle:hover{ border-color:var(--accent); }
#theme-switch:focus-visible + .theme-toggle{ outline:2px solid var(--accent); outline-offset:2px; }
body:has(#theme-switch:checked){
  --bg:#181b1e; --surface:#20242a; --surface-2:#262b31; --ink:#e8e6df; --ink-muted:#98a0a6;
  --border:#343a41; --accent:#79bdb0; --accent-soft:#1f3b3a; --accent-ink:#d7f0ea;
  --sev-blocker:#ff7a6b; --sev-blocker-bg:#3d2220;
  --sev-high:#f2ab57; --sev-high-bg:#3c2f18;
  --sev-medium:#e3c56e; --sev-medium-bg:#39301a;
  --sev-low:#98a0a6; --sev-low-bg:#262b31;
}
.masthead h1{ font-size:2.15rem; margin:.35rem 0 .5rem; letter-spacing:-.01em; }
.masthead .sub{ color:var(--ink-muted); max-width:62ch; font-size:1.02rem; }
.badge-row{ display:flex; flex-wrap:wrap; gap:.6rem; margin-top:1.4rem; }
.badge{
  display:inline-flex; align-items:center; gap:.4rem; border:1px solid var(--border);
  background:var(--surface); border-radius:999px; padding:.4rem .85rem; font-size:.82rem;
}
.badge .k{ color:var(--ink-muted); }
.badge .v{ font-weight:700; font-family:var(--font-mono); font-size:.78rem; }
.badge .v.warn{ color:var(--sev-high); }
.top-summary{ max-width:1180px; margin:0 auto; padding:1.6rem 1.5rem 0; }
.stat-strip{ display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:.9rem; margin:1.6rem 0; }
.stat-card{ border:1px solid var(--border); border-radius:12px; background:var(--surface); padding:1rem 1.1rem; display:flex; flex-direction:column; gap:.2rem; }
.stat-num{ font-family:var(--font-mono); font-size:1.7rem; font-weight:700; line-height:1; }
.stat-label{ color:var(--ink-muted); font-size:.78rem; text-transform:uppercase; letter-spacing:.04em; }
.stat-card.stat-blocker .stat-num{ color:var(--sev-blocker); }
.stat-card.stat-high .stat-num{ color:var(--sev-high); }
.callout{
  border:1px solid var(--sev-high); background:var(--sev-high-bg); color:var(--ink);
  border-radius:10px; padding:1rem 1.2rem; margin:1.2rem 0; font-size:.92rem;
}
.callout strong{ color:var(--sev-high); }
.callout ul{ margin:.5rem 0 0; padding-left:1.2rem; }
.callout-blocker{ border-color:var(--sev-blocker); background:var(--sev-blocker-bg); }
.callout-blocker strong{ color:var(--sev-blocker); }
.ai-readiness-card{ background:var(--surface); border:1px solid var(--border); border-radius:14px; padding:1.3rem 1.5rem; margin-top:1.4rem; }
.ai-readiness-head{ display:flex; align-items:center; gap:.8rem; flex-wrap:wrap; margin-bottom:.5rem; }
.ai-readiness-title{ font-family:var(--font-display); font-size:1.15rem; font-weight:700; }
.ai-readiness-sub{ color:var(--ink-muted); font-size:.9rem; max-width:70ch; margin:.2rem 0 .9rem; }
.ai-readiness-list{ list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:.55rem; }
.ai-readiness-list li{ display:flex; align-items:center; gap:.6rem; font-size:.92rem; }
.ai-label{ flex:1; }
.ai-frac{ display:inline-flex; align-items:center; gap:.35rem; color:var(--ink-muted); font-family:var(--font-mono); font-size:.82rem; }
.ai-ok{ color:var(--accent); font-weight:700; }
.ai-warn{ color:var(--sev-high); font-weight:700; }
.ai-fail{ color:var(--sev-blocker); font-weight:700; }
.layout{
  max-width:1180px; margin:0 auto; display:grid; grid-template-columns:230px 1fr;
  gap:2.6rem; padding:2.2rem 1.5rem 5rem; align-items:start;
}
@media (max-width:880px){
  .layout{ grid-template-columns:1fr; }
  .toc{ position:static !important; order:2; }
  .stat-strip{ grid-template-columns:repeat(2,minmax(0,1fr)); }
}
.toc{ position:sticky; top:1.5rem; align-self:start; }
.toc nav{ display:flex; flex-direction:column; gap:.1rem; border-left:2px solid var(--border); }
.toc a{
  text-decoration:none; color:var(--ink-muted); font-size:.86rem; padding:.32rem 0 .32rem .9rem;
  border-left:2px solid transparent; margin-left:-2px;
}
.toc a:hover{ color:var(--ink); }
.toc .legend{ margin-top:1.6rem; padding-top:1.2rem; border-top:1px solid var(--border); }
.legend-row{ display:flex; align-items:center; gap:.5rem; font-size:.8rem; margin-top:.5rem; color:var(--ink-muted); }
main{ min-width:0; }
section{ margin-bottom:3.2rem; scroll-margin-top:1.5rem; }
section > h2{ font-size:1.55rem; margin:0 0 .3rem; }
section > .section-note{ color:var(--ink-muted); font-size:.92rem; margin-bottom:1.3rem; max-width:70ch; }
h3{ font-size:1.15rem; margin:1.6rem 0 .6rem; }
p{ max-width:74ch; }
.sev{
  display:inline-flex; align-items:center; gap:.4rem; font-family:var(--font-mono); font-size:.72rem;
  font-weight:700; text-transform:uppercase; letter-spacing:.04em; padding:.18rem .55rem; border-radius:5px;
  white-space:nowrap;
}
.sev.blocker{ color:var(--sev-blocker); background:var(--sev-blocker-bg); }
.sev.high{ color:var(--sev-high); background:var(--sev-high-bg); }
.sev.medium{ color:var(--sev-medium); background:var(--sev-medium-bg); }
.sev.low{ color:var(--sev-low); background:var(--sev-low-bg); }
.table-wrap{ overflow-x:auto; border:1px solid var(--border); border-radius:10px; background:var(--surface); }
table{ border-collapse:collapse; width:100%; font-size:.88rem; min-width:520px; }
th, td{ text-align:left; padding:.65rem .8rem; border-bottom:1px solid var(--border); vertical-align:top; }
th{ font-family:var(--font-mono); font-size:.7rem; text-transform:uppercase; letter-spacing:.05em; color:var(--ink-muted); background:var(--surface-2); }
tr:last-child td{ border-bottom:none; }
.case{
  border:1px solid var(--border); border-left:4px solid var(--sev-high); border-radius:10px;
  background:var(--surface); padding:1.2rem 1.4rem; margin-bottom:1.1rem;
}
.case.blocker{ border-left-color:var(--sev-blocker); }
.case-head{ display:flex; align-items:baseline; gap:.7rem; flex-wrap:wrap; margin-bottom:.5rem; }
.case-head h4{ font-family:var(--font-body); font-size:1.02rem; font-weight:700; margin:0; }
.case dl{ display:grid; grid-template-columns:max-content 1fr; gap:.35rem 1rem; margin:.8rem 0 0; font-size:.89rem; }
.case dt{ font-family:var(--font-mono); font-size:.68rem; text-transform:uppercase; letter-spacing:.05em; color:var(--ink-muted); padding-top:.15rem; white-space:nowrap; }
.case dd{ margin:0; }
details.more-findings{ margin-top:.8rem; }
details.more-findings > summary{ cursor:pointer; color:var(--accent); font-size:.9rem; font-weight:600; }
details.more-findings[open] > summary{ margin-bottom:.8rem; }
.plan-list{ padding-left:1.3rem; }
.plan-list li{ margin-bottom:.6rem; }
footer{ border-top:1px solid var(--border); padding:2rem 1.5rem; text-align:center; color:var(--ink-muted); font-size:.82rem; }
a:focus-visible{ outline:2px solid var(--accent); outline-offset:2px; }
@media (prefers-reduced-motion: reduce){ html{ scroll-behavior:auto; } }
</style>
</head>
<body>
<input type="checkbox" id="theme-switch" class="sr-toggle">
<header class="masthead"><div class="masthead-inner">
  <label for="theme-switch" class="theme-toggle" aria-label="Toggle dark mode">&#9680;</label>
  <div class="eyebrow">Evidence-backed architecture review</div>
  <h1>{PROJECT} — Data Product Architecture Review</h1>
  <p class="sub">{SCOPE SENTENCE}</p>
  <div class="badge-row">
    <span class="badge"><span class="k">Review run</span><span class="v">{STATUS}</span></span>
    <span class="badge"><span class="k">Modeling readiness</span><span class="v">{MODELING VERDICT}</span></span>
    <span class="badge"><span class="k">Cost posture</span><span class="v">{COST VERDICT}</span></span>
  </div>
</div></header>

<div class="top-summary">
  <div class="stat-strip">
    <div class="stat-card"><span class="stat-num">{MODELS}</span><span class="stat-label">Models reviewed</span></div>
    <div class="stat-card stat-blocker"><span class="stat-num">{BLOCKERS}</span><span class="stat-label">Blockers</span></div>
    <div class="stat-card stat-high"><span class="stat-num">{HIGH}</span><span class="stat-label">High</span></div>
    <div class="stat-card"><span class="stat-num">{COST VERDICT}</span><span class="stat-label">Cost posture</span></div>
  </div>
  {TOP RISK CALLOUT}
  {AI READINESS CARD}
</div>

<div class="layout">
<aside class="toc">
  <nav>
    <a href="#summary">Decision summary</a>
    <a href="#business">What this product is for</a>
    <a href="#findings">Material findings</a>
    <a href="#architecture">Architecture assessment</a>
    <a href="#plan">Change plan</a>
    <a href="#evidence">Evidence and limits</a>
  </nav>
  <div class="legend">
    <div class="eyebrow">Severity</div>
    <div class="legend-row"><span class="sev blocker">Blocker</span> ships broken today</div>
    <div class="legend-row"><span class="sev high">High</span> unsafe under real use</div>
    <div class="legend-row"><span class="sev medium">Medium</span> needs governance</div>
  </div>
</aside>
<main>
  {SECTIONS}
</main>
</div>
<footer>Rendered by the evidence-backed architecture review.</footer>
</body>
</html>
```

Add a `.warn` class to a badge value (`<span class="v warn">`) whenever that
verdict is anything other than `complete`, `validated`, or `appropriate`.

## Top risk callout

The single most severe finding, one or two sentences. Use `callout-blocker` when
it is a BLOCKER, plain `callout` otherwise. Omit the block entirely when there
are no blocker or high findings.

```html
<div class="callout callout-blocker"><strong>Top risk (BLOCKER):</strong> {ONE OR TWO SENTENCES}</div>
```

## AI readiness card

Render from the supplied `ai_readiness` facts. Use `ai-ok` for a passing row,
`ai-warn` for partial, `ai-fail` for zero or near-zero, with `&#10003;`,
`&#9888;`, and `&#10007;` respectively. The severity chip beside the title is
`blocker` for NOT AGENT-READY, `high` for NEEDS WORK, `medium` for AGENT-READY.
The icon sits after the fraction text, not beside the label.

```html
<div class="ai-readiness-card">
  <div class="ai-readiness-head">
    <span class="ai-readiness-title">AI readiness</span>
    <span class="sev blocker">{LABEL}</span>
  </div>
  <p class="ai-readiness-sub">{ONE SENTENCE ON WHAT THE TIER MEANS FOR AN AGENT}</p>
  <ul class="ai-readiness-list">
    <li><span class="ai-label">Descriptions present</span><span class="ai-frac">{n}/{n} fields <span class="ai-warn">&#9888;</span></span></li>
    <li><span class="ai-label">Tags &amp; taxonomy</span><span class="ai-frac">{n}/{n} fields <span class="ai-warn">&#9888;</span></span></li>
    <li><span class="ai-label">AI context (instructions, synonyms, examples)</span><span class="ai-frac">{n}/{n} fields <span class="ai-fail">&#10007;</span></span></li>
    <li><span class="ai-label">Semantic layer declared</span><span class="ai-frac">{n} model(s) <span class="ai-ok">&#10003;</span></span></li>
  </ul>
</div>
```

## Sections

Six `<section>` elements with these exact ids, in this order.

### `#summary` — Decision summary

`<h2>Decision summary</h2>`, then the lead paragraph: the single most
consequential conclusion about this product and what it means operationally. A
reader who stops here should know whether they can trust it and what the biggest
problem is. Do not open with scope or methodology.

When the run is partial, precede the paragraph with a `callout` listing each
missing dimension and failure reason as `<li>` items.

### `#business` — What this product is for

Three subsections, all as `table-wrap` tables:

`<h3>Product at a glance</h3>` — two columns, Context and What matters. Rows for
Purpose, Decisions, Consumers, Delivery expectations, Material limitations.

`<h3>Intended analytical needs</h3>` — Ref, Priority, Need, Known limitation,
Evidence. Number the refs Q1, Q2, and so on, and reference those short labels
from findings rather than repeating the question text.

`<h3>Intent or stage conflicts</h3>` — Subject, Stated or upstream, Code or
downstream, Evidence. Omit this subsection when there are none.

### `#findings` — Material findings

Every BLOCKER and HIGH as a `case` block, ordered by priority then blast radius:

```html
<div class="case blocker">
  <div class="case-head"><span class="sev blocker">BLOCKER</span><h4>{TITLE}</h4></div>
  <dl>
    <dt>Root cause</dt><dd>{...}</dd>
    <dt>Consequence</dt><dd>{...}</dd>
    <dt>Required action</dt><dd>{...}</dd>
    <dt>Validation</dt><dd>{...}</dd>
    <dt>Residual risk</dt><dd>{...}</dd>
    <dt>Affected needs</dt><dd>{Q REFS}</dd>
    <dt>Evidence</dt><dd><code>path/to/file.sql:12-20</code></dd>
  </dl>
</div>
```

Show the first five inline. When there are more, wrap the remainder in
`<details class="more-findings"><summary>Show {n} more findings</summary>…</details>`
so the page stays navigable.

Then `<h3>Additional findings</h3>` as a `table-wrap` table of MEDIUM and LOW:
Priority, Finding, Consequence, Required action, Evidence. Omit when empty.

### `#architecture` — Architecture assessment

`<h3>` per boundary — Structure, Semantics, Contract — plus one for Physical
design and cost. Prose covering what is sound as well as what is broken; a
review that lists only defects gives no sense of proportion.

### `#plan` — Change plan

`<ol class="plan-list">`, one `<li>` per step, ordered by dependency rather than
severity. Each item names the file or model, what to change, and an acceptance
criterion that is executable or objectively observable. "Reviewed and confirmed"
is not an acceptance criterion.

### `#evidence` — Evidence and limits

`<h3>Source coverage</h3>` as a `table-wrap` table built from the supplied source
ledger: Source group, Coverage, Role. Then prose on what could not be
established and what the review deliberately did not cover.

## Rules

- Reproduce the supplied verdicts, scope counts, severity counts, and
  deterministic facts exactly. Never write prose that contradicts them.
- Every supplied finding appears once: material ones as a `case`, the rest in the
  additional-findings table. Do not drop one, do not invent one.
- Never print internal evidence identifiers or hashes. Citations are
  `artifact:line` inside `<code>`.
- Use platform-neutral language. Do not name implementation technologies or
  external framework brands.
- Do not describe the review process or refer to yourself.
