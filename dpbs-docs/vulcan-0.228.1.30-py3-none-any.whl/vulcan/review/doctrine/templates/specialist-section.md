# Specialist section format

Return Markdown only. No JSON, no preamble, no closing commentary. Your output is
pasted directly into a report, so start at the first heading below and stop after
the last section.

Use exactly these four headings, in this order, with nothing between them and the
document start.

## Findings

One table. It must appear even when you found nothing, in which case emit the
header row and a single row reading `| NONE | | | No material findings. |`.

| Priority | Category | Model | Finding |
|---|---|---|---|
| BLOCKER | structure_coherence | sushi.orders | Hourly semantic dimension exposed over a daily-refreshed base |
| HIGH | physical_cost | sushi.order_items | FULL rebuild of an append-only fact with no measured workload |

Rules for this table, all load bearing because the application parses it:

- `Priority` is exactly one of `BLOCKER`, `HIGH`, `MEDIUM`, `LOW`.
- `Category` is exactly one of the categories your skill owns. Do not invent
  values and do not qualify them with a suffix.
- `Model` is the fully qualified model name, or empty when the finding is
  product-wide.
- `Finding` is one sentence naming the defect. Detail belongs in the next
  section, not here.
- One finding per row. Never merge two defects into one row, and never split one
  defect across rows.
- A defect that propagates along a model chain is **one** defect, not one per
  model it reaches. Report it against the model where it originates and name the
  affected downstream models in the Detail block. A mislabeled column that flows
  from staging into a semantic measure is a single row on the staging model, not
  a row for every model that carries it forward.
- If a boundary that ran before you already reported a defect, do not restate it
  under your own category. Add what your boundary knows to the Detail block of
  your own findings instead.
- Do not add, remove, or reorder columns.

## Detail

For each finding above, in the same order, a short block. Use the finding
sentence as a bold lead-in, then cover root cause, consequence, recommendation,
how to validate the fix, and residual risk in prose. Do not use a fixed
sub-heading per field; write it as an engineer would explain it to another
engineer.

Cite evidence inline as `path/to/artifact.sql:120-134`. Cite the narrowest line
range the claim actually rests on. Never cite an artifact that was not supplied
to you.

## Assessment

Prose covering the ground your skill owns across the whole scope you were given,
including the parts that are correct. This is where positive observations belong;
the findings table is for defects only.

Where your skill's doctrine names specific things to establish, establish them
here. Be concrete about which models you examined.

## Adjudication

**Contract boundary only.** Omit this section entirely if you were given no
contract-conflict candidates.

One line per candidate id you were supplied, in this exact shape:

```text
- contract-9f2a1b40c7d3e512: DRIFT - documentation says active only, the query includes pending.
- contract-77c0de91a4b8f206: ALIGNED - the two predicates are differently scoped but resolve to the same population.
- contract-31ba7fd0e6c95483: UNKNOWN - the supplied evidence cannot settle which scope is intended.
```

The verdict word must be exactly `ALIGNED`, `DRIFT`, or `UNKNOWN`, and the
application parses these lines, so do not reword or renumber them.

- `DRIFT` means declared behavior and executable behavior genuinely differ. This
  is material by definition and forces a changes-required verdict, so do not use
  it for a difference you judged cosmetic.
- `ALIGNED` means they agree, including when they are worded differently or
  scoped differently but resolve to the same result.
- `UNKNOWN` means the supplied evidence cannot settle it. Prefer this over
  guessing.

Every supplied candidate needs a line. A candidate you leave out is recorded as
unknown, which is worse for the report than an honest `ALIGNED`.

## Assumptions and unknowns

What you inferred rather than observed, and what the supplied evidence could not
settle. State an unknown plainly rather than guessing. If nothing is uncertain,
write `None.`

---

## Discipline

- Executable code is ground truth for current behavior. Product documentation
  states intent and cannot override it.
- Preserve qualifiers. Never turn "some", "may", "especially", or "unverified"
  into "all", "throughout", "confirmed", or "safe".
- A global claim requires an inventory that proves global scope.
- Never claim a data invariant passed when physical validation was unavailable.
- Never turn missing evidence into a positive conclusion.
- Do not restate the packet back to the reader. They have it.
