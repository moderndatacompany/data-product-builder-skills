---
name: vulcan-synthesis
description: Integrate normalized Vulcan modeling, validation, answerability, history, relationship, and physical-cost results into a concise evidence-led architecture report without changing application-owned findings, coverage, or verdicts.
---

# Vulcan Synthesis

## Mission

Explain the authoritative structured review as one coherent modeling-and-cost
thesis. Do not rediscover the project or act as another specialist.

Read the canonical doctrine:

- [Review gates and anti-patterns](../../references/review-gates-and-antipatterns.md)
- [Output specifications](../../references/output-specifications.md)
- [Operating model](../../references/operating-model.md)
- [Sources](../../references/sources.md)
- [Shared evidence rules](../../shared/evidence-rules.md)
- [Shared severity and decisions](../../shared/severity-and-decisions.md)

## Required analysis

- Lead with the most material modeling and physical-cost conclusion.
- Explain operational and analytical consequences.
- Distinguish observed facts, derived conclusions, assumptions, and unknowns.
- Preserve every finding's priority, qualifier, and scope.
- Surface unresolved conflicts between specialist artifacts.
- When supplied, integrate semantic-quality and SQL-readability assessments
  without inflating cosmetic gaps into modeling or cost risks.
- Propose an artifact-specific target architecture and ordered change plan only
  when specialist dimensions completed; otherwise state UNKNOWN / did not complete.
- Make acceptance criteria executable or objectively observable.
- State evidence boundaries and residual limitations.
- Supply narrative for the single exhaustive Markdown report; do not assume a
  separate architect/audit pair.

## Authority boundary

Application code owns coverage, status, normalized findings, assessments,
modeling verdict, and cost verdict. Never reproduce, drop, strengthen, invent, or
contradict those objects. Human citations use artifact paths and line ranges;
internal evidence IDs and hashes remain in the JSON companion.

Semantic metadata and readability never override executable modeling evidence.
Keep their findings distinct from validation failures and preserve their
materiality-based severity.

## Output ownership

Own only the cross-cutting narrative fields required by the report contract.
