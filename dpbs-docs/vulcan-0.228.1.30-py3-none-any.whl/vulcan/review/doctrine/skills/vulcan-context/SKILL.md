---
name: vulcan-context
description: Establish the stated business intent and operating context of a Vulcan data product before technical modeling review. Extract purpose, decisions, processes, entities, populations, definitions, consumers, questions, limitations, service expectations, assumptions, and intent-versus-code candidates.
---

# Vulcan Business Context

## Mission

Determine what the data product is supposed to mean and which decisions it is
supposed to support. Produce a typed business-context packet for downstream
modeling agents; do not issue final modeling or cost verdicts.

## Evidence
****
Prioritize README, agreement, configuration, usage, use cases, limitations, data
references, semantic descriptions, metric definitions, tests, and examples.
README, usage, and limitation material describes intent and constraints; it cannot
override executable model code, which is ground truth for current be****havior.
Classify claims as stated, executable, observed, derived, inferred, or unknown.

Read the canonical doctrine:

- [Discovery and business questions](../../references/discovery-and-business-questions.md)
- [Domain question library](../../references/domain-question-library.md)
- [Answerability and business logic](../../references/answerability-and-business-logic.md)
- [Operating model](../../references/operating-model.md)
- [Vulcan primitives](../../vulcan-primitives.md)
- [Shared evidence rules](../../shared/evidence-rules.md)
- [Shared severity and decisions](../../shared/severity-and-decisions.md)

## Required analysis

- Product purpose and supported decisions.
- Business processes, entities, terminology, and authoritative definitions.
- Declared populations, filters, exclusions, and outputs.
- Primary consumers and service expectations when declared.
- Prioritized business questions and their required semantics.
- Material limitations and permitted interpretations.
- Explicit assumptions and unresolved unknowns.
- Candidate gaps between stated intent and executable behavior.

Do not assume a document describes current behavior merely because it is prose.
Preserve both claims for downstream analysis and make the executable claim
authoritative about what the product currently does.

## Output ownership

Own only `BusinessContextPacket`. Do not redefine model grain, approve joins,
classify measure reaggregation, select model kinds, or recommend physical
optimization.
