---
name: vulcan-structure
description: Review whether the mechanics of a Vulcan data product line up across every dependency edge — refresh cadence, interval unit, row grain, keys, join cardinality, model kind, incremental parameterization, the binding from physical models into the semantic layer — and whether the resulting physical design is appropriate for its workload, scale, and growth.
---

# Vulcan Structure

## Mission

Establish whether the shape of the product is coherent. Walk the dependency
graph and, for every model and every edge, determine whether what one side
mechanically produces is what the other side mechanically assumes.

This skill compares **code against code**. It does not judge whether a name or
description is honest, and it does not judge whether anything enforces a claim.
Both sides of every comparison are authored artifacts.

Read the canonical doctrine:

- [Table design and grain](../../references/table-design-and-grain.md)
- [Joins, cardinality, and fanout](../../references/joins-cardinality-and-fanout.md)
- [Incremental, streaming, and history](../../references/incremental-streaming-and-history.md)
- [Dimensional and temporal modeling](../../references/dimensional-and-temporal-modeling.md)
- [Physical design, performance, and cost](../../references/physical-design-performance-and-cost.md)
- [Pattern selection structure](../../references/pattern-selection-structure.md)
- [Vulcan primitives](../../vulcan-primitives.md)
- [Shared evidence rules](../../shared/evidence-rules.md)
- [Shared severity and decisions](../../shared/severity-and-decisions.md)

## Scope

Two edge classes, reviewed the same way:

- **Physical → physical.** One model depends on another.
- **Physical → semantic.** A `kind: semantic` model binds one physical model
  through `depends_on`, and members resolve to that model's columns.

External warehouse objects are reference evidence for input assumptions. Do not
emit a standalone assessment for each external object.

## Required analysis

### Cadence and interval coherence

For every edge, compare `cron` and `interval_unit` on both sides.

A mismatch is a **candidate, not a verdict**, and both polarities are candidates:

- A coarser downstream over a finer upstream is usually a legitimate rollup.
  It becomes a defect when the downstream run boundary can observe a partial
  upstream interval, or when the coarser cadence discards a granularity the
  stated purpose requires.
- A finer downstream over a coarser upstream is usually a defect: the downstream
  advertises freshness its inputs cannot supply, and most of its runs recompute
  identical output.

At the physical → semantic boundary the same test applies to exposed time
granularities. A semantic dimension offering `hour` buckets over a base model
refreshed daily is a freshness claim the pipeline cannot honour, regardless of
whether the underlying column supports the bucket.

### Grain

- The one-row grain of every authored model, stated in plain language.
- Whether `grains` is declared. A semantic model's physical base **must** declare
  it or the project does not load, so an undeclared grain on a base model is a
  structural fact, not a preference.
- Whether the row-producing logic is consistent with the declared grain: joins
  that multiply rows, unions without deduplication, window functions whose
  selected row is never filtered.
- Whether grain changes across an edge without an aggregation step that accounts
  for the change.

Whether an audit or DQ rule *proves* the grain belongs to `vulcan-contract`.
Report here only the internal inconsistency between the declaration and the SQL.

### Keys

Natural, surrogate, composite, candidate, primary, and foreign keys; whether
declared keys agree with the declared grain; duplicate, null, update, and
deletion implications for row identity. Never infer a safe key from a column
name.

### Join cardinality and fanout

`JoinRelationshipValue` is `one_to_one`, `one_to_many`, or `many_to_one`. There
is no `many_to_many` — a genuinely many-to-many relationship is a missing bridge
table.

Direction is a claim Vulcan trusts and never verifies against data. A
`many_to_one` whose target is not unique on the join key inflates every sum on
the declaring side. Assess the claim against the target's declared grain and
keys, and say plainly when only warehouse evidence could settle it.

Also check reciprocal join pairs for exactly one `skip_for_bi: true`, join graph
cycles, and join targets that never linked to a physical model.

### Model kind and position

`kind` is a declaration about how rows relate to time and identity, not a
materialization preference. Assess it against the model's position in the graph:

- Incremental kinds whose body does not filter on `@start_date`/`@end_date` are
  not incremental — they rescan everything into one interval.
- Unparameterized `CURRENT_DATE`/`NOW()` in any incremental or historical model
  breaks backfill reproducibility.
- `INCREMENTAL_BY_UNIQUE_KEY` on event-grain data silently collapses history.
- `INCREMENTAL_UNMANAGED` duplicates rows on rerun and needs explicit
  justification.
- Chains of `VIEW` or `EMBEDDED` models push computation onto every consumer.
- `time_column`, `start`, `lookback`, and `partitioned_by` must be consistent
  with the kind and with the upstream cadence.

### Semantic binding

- `depends_on` resolves to exactly one physical model, at one grain.
- Every semantic dimension and measure expression resolves to a column that
  exists physically.
- Declared `granularities` sit on TIMESTAMP-compatible columns.
- Materialized rollups reference measures owned by the declaring model, and
  rolling-window measures inside them carry `date_range`.
- Rollup grain is reachable from the queries the product exists to serve.

### Physical design and cost

Coherent mechanics can still be built badly. For every physical model, judge
whether the implementation suits its workload, freshness need, scale, and
growth. Physical models are authored models whose kind is not `SEMANTIC` or
`METRIC`.

- Model kind, refresh behavior, and dependency amplification.
- Scan, join, shuffle, sort, window, distinct, state, and output cost.
- Storage, file layout, maintenance, and refresh tradeoffs.
- Query frequency, concurrency, freshness, latency, rows, bytes, and measured
  runtime where evidence exists.
- Fit between refresh schedule and the declared usage cadence, freshness target,
  backfill horizon, dependency shape, and consumer decisions.
- Current risk separately from growth risk.
- Query-time calculation versus derived model, incremental model, snapshot,
  aggregate, rollup, materialized view, approximation, or cache.
- A measurement plan where workload evidence is unavailable.

A `FULL` model is not automatically defective. **Without measured workload or
scale evidence its verdict is `unknown` or `watch`, never `appropriate`.** Never
recommend an optimization that changes established analytical semantics, and
never optimize a design that is analytically wrong — fix the modeling defect
first.

Business documents supply workload intent; executable code supplies the actual
materialization and schedule. Explain a mismatch concretely — why rebuilding a
long stable history every night is unnecessary for the stated freshness need —
rather than treating a kind or cron expression as inherently bad.

## Authority boundary

Own `structure_coherence` and `physical_cost` findings, one
`StructureAssessment` per authored review-target model, and one
`EdgeAssessment` per edge where cadence or cardinality is material. Fill the
`physical` block on every physical model's assessment; it is the sole source of
the application-owned cost verdict.

Keep the two finding categories distinct. Coherence defects and cost defects
drive independent verdicts, so a cost problem must never be filed as
`structure_coherence` to make it look more urgent.

Do not own whether a member's name or description is truthful — that is
`vulcan-semantics`. Do not own whether a declared grain, key, or cardinality is
enforced by an audit, assertion, or DQ rule, and do not own promises made in the
product envelope — both are `vulcan-contract`.

When structural analysis exposes a claim that is coherent in code but unproven
in production, hand it to `vulcan-contract` rather than restating it as a
structural defect.
