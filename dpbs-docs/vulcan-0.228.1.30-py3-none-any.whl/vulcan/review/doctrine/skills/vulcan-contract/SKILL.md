---
name: vulcan-contract
description: Review whether a Vulcan data product's guarantees to its consumers are enforceable and enforced — assertions, audits, DQ rules, declared-versus-executable behavior, the product envelope and SLA, the public surface and its policies, and the safety of pending changes.
---

# Vulcan Contract

## Mission

Structure and semantics ask whether the product is correct today. This skill
asks a different question: **what stops it from being violated next Tuesday?**

Everything the product hands outward is a guarantee — the members it marks
`public`, the freshness it advertises, the populations its documentation
promises, the uses it declares it is good and not good for. Determine, for each
one, whether anything executable holds it in place.

This skill compares **code against a product-level promise, and claims against
their enforcement**. It is the only one of the three that looks at the surface
consumers actually touch.

Read the canonical doctrine:

- [Data quality, testing, and observability](../../references/data-quality-testing-and-observability.md)
- [Governance, contracts, and security](../../references/governance-contracts-security.md)
- [Serving BI, API, AI, and ML](../../references/serving-bi-api-ai-ml.md)
- [Review gates and anti-patterns](../../references/review-gates-and-antipatterns.md)
- [Vulcan primitives](../../vulcan-primitives.md)
- [Shared evidence rules](../../shared/evidence-rules.md)
- [Shared severity and decisions](../../shared/severity-and-decisions.md)

## Required analysis

### Enforcement of established claims

Take the structural and semantic conclusions supplied upstream as given, and ask
of each material claim whether an executable check proves it.

- A declared `grains` with no uniqueness assertion, audit, or `duplicate_count`
  DQ rule is a grain contract that production never verifies. This is the single
  most common unenforced guarantee.
- A declared join cardinality with no referential-integrity or uniqueness check
  on the target. Vulcan trusts direction and never verifies it.
- An `SCD_TYPE_2_*` model with nothing asserting non-overlapping, non-gapped
  intervals is unverified history.
- Required fields, accepted values, and lifecycle invariants with no rule behind
  them.
- Reconciliation and balance equations where a number must tie to a source or
  financial system.

An assertion query returning rows is a failure — it is a counterexample query,
not a filter. Read every assertion in that direction before judging it.

### Quality of the checks themselves

An existing check is not automatically a guarantee.

- A threshold that contradicts the rule's name. The name will be believed; the
  threshold will execute.
- Rules whose `filter` narrows the scan, and which therefore prove nothing
  table-wide.
- A wrong DQ `dimension`, which mislabels the published quality report against
  the standardized vocabulary.
- `failed rows` with no `samples limit` — unbounded output, and disclosure if
  the query selects sensitive columns.
- Suites that are permanently red and therefore ignored.
- `change` and `anomaly detection` rules on a model with no accumulated history.
- Auto-derived rule names on rules intended to be tracked over time; they are
  unstable under edits.
- Linting is itself enforcement. A disabled linter, or a rule that catches
  unguaranteed models demoted to a warning, weakens every guarantee below it.

### Declared versus executable

Adjudicate every supplied contract candidate as `ALIGNED`, `DRIFT`, or
`UNKNOWN`, using the Adjudication section of the section template. Those lines
are parsed by the application, and a `DRIFT` verdict forces a changes-required
modeling verdict on its own — independently of the priority you give the
matching finding. Documentation and code describing different products is
material whatever severity the prose assigns it.

That cuts both ways. Do not record `DRIFT` for a difference you judged
cosmetic, and do not soften a real one to `ALIGNED` because the fix looks small.

Application extraction is a candidate generator, not the semantic verdict —
differently scoped literal predicates are frequently both correct, and those are
`ALIGNED`.

Executable code is authoritative for what the product currently does. A README,
usage, agreement, or limitation claim can reveal an unmet need or stale
documentation, but it cannot override what the code implements.

### The product envelope

The supplied product contract carries the outward promise: `service_expectations`,
`good_for`, `not_for`, `caveats`, `support`, `agreement`, `version`, `status`,
`alignment`, and `owner`. Check each against the models.

- A stated refresh expectation that no model's cadence, and no upstream lineage,
  can deliver.
- A `good_for` entry or product description promising questions the exposed
  vocabulary cannot answer.
- A `not_for` boundary contradicted by something the product actively exposes —
  a revenue metric on a product declared unfit for financial reporting.
- A caveat describing a limitation that no code enforces, or a real limitation
  with no caveat. Caveat severity is display metadata and triggers nothing at
  runtime, so a severe caveat is a promise to the reader and nothing more.
- A draft or unversioned product that consumers already depend on, or a version
  unchanged across a breaking change.
- Ownership or support routing that does not resolve to a reachable destination.

### The public surface

- `public: false` is how a curated surface is exposed without deleting
  intermediates. Assess whether the public set is the intended set, and whether
  anything sensitive is public by omission rather than by decision.
- Column classifications, `mask_expression` type compatibility, and policy
  `filter`/`mask` rules. A masked column may not be pre-aggregated into a
  materialized rollup.
- Whether policies hold across **every** interface — SQL, REST, GraphQL, and BI
  export — not only the one that was tested. Two groups legitimately seeing
  different totals is a design decision that must be documented or it reads as a
  data bug.
- DQ `profiles` on sensitive columns publish sample values. Treat the profile
  list as a disclosure decision.

### Change safety

Guarantees break at the moment they change. Your packet carries a **deployed
comparison** section listing which authored models are added, removed, or
modified relative to what is actually deployed. Use it.

- A model listed as added is authored but not yet released. That is the normal
  state of new work, not a finding. Any guarantee it carries is authored rather
  than in force, so do not describe it as protecting anyone today — but do not
  report its absence from production as a defect either.
- A model listed as removed is still deployed and no longer authored. Anything
  downstream that depends on it breaks at the next plan.
- A model listed as directly modified has a live version that differs from what
  you are reviewing. A number already published to consumers may change when
  this ships.
- A model listed as metadata-only changed its description or context without
  changing data. Do not report it as a data risk.

Calibrate severity on release state carefully. A set of new models that reference
each other and are all unreleased together leaves production consistent — it
simply does not have the new work yet, and the deployed product is the previous
version. That is never a blocker on its own. Reserve blocker severity for a
production state that is actually broken or unsafe: a deployed model whose
dependency was withdrawn, a live surface pointing at something that no longer
exists, or a published guarantee that has silently stopped holding.

What *is* worth reporting about unreleased work is a claim that depends on it
being live: a policy, audit, or test that the product presents as protection but
that no consumer is covered by yet. Report the unmet claim, not the fact that a
plan has not run.

When the comparison is unavailable, the packet says so. In that case state that
you could not distinguish live guarantees from pending ones, rather than
assuming the deployed state matches the authored state.

Independently of the comparison, assess:

- Removed assertions, audits, or DQ rules — a guarantee withdrawn without
  replacement.
- Added models and members that ship without any enforcement at all.
- Measures or filters whose change alters a published number.

## Authority boundary

Own contract findings, one `ContractAlignmentAssessment` for every supplied
contract candidate, and one enforcement assessment for every public or
decision-critical guarantee.

Do not re-derive grain, cardinality, cadence, or measure semantics — consume
them from `vulcan-structure` and `vulcan-semantics`. Do not grade general
description quality, AI context richness, tags, terms, or SQL style; metadata
belongs here only when it is an explicit contract claim being adjudicated
against executable behavior.

Missing descriptions are material here only where they leave a consumer-facing
guarantee ambiguous or unsafe.
