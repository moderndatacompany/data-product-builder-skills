---
name: vulcan-semantics
description: Review whether the meaning a Vulcan semantic layer exposes matches the data underneath it — member names, descriptions, AI context, measure behavior and additivity, baked-in filters, dimension classification, and metric time attribution.
---

# Vulcan Semantics

## Mission

Every exposed member makes a claim about meaning. Its name is a claim, its
description is a claim, its `ai_context` is a claim, and its declared
`behavior.type` is a claim. Determine whether the expression underneath produces
what is claimed.

This skill compares **code against a member-level claim**, across the same
physical → semantic boundary that `vulcan-structure` reviews. Structure asks
whether the mechanics line up; this asks whether the meaning does.

Read the canonical doctrine:

- [Measures, metrics, and semantic modeling](../../references/measures-metrics-and-semantic-modeling.md)
- [Semantic metadata and AI context](../../references/semantic-metadata-and-ai-context.md)
- [Answerability and business logic](../../references/answerability-and-business-logic.md)
- [Vulcan primitives](../../vulcan-primitives.md)
- [Shared evidence rules](../../shared/evidence-rules.md)
- [Shared severity and decisions](../../shared/severity-and-decisions.md)

## The core test

Take the member's name, description, and AI context. State what a consumer would
believe the member returns. Then read the expression, filters, behavior, and the
physical column it resolves to, and state what it actually returns. Report the
gap.

The canonical failure is a rename that implies a transformation nobody wrote: a
physical `order_date` surfaced as a semantic `shipping_date` with no offset
applied. Nothing fails to load, no test fails, and every downstream consumer
inherits a date that is wrong by however many days the name implies. Names that
imply arithmetic, a different population, a different unit, a different currency,
or a different time basis are all the same defect.

Missing metadata is counted deterministically by application code and is not a
finding here. **Misleading metadata is.** An accurate absence is safer than a
confident lie.

## Required analysis

### Measure behavior and additivity

`type` is the SQL aggregation to emit. `behavior.type` is the analytical
semantics of the result. Conflating them is the defining Vulcan modeling error.

`is_additive` is computed, never authored: true only for `simple` and `flow`.

- A `stock` measure declared `simple` **loads clean and is silently wrong**.
  Nothing in the engine can catch it. Level-shaped quantities — MRR, ARR,
  headcount, active customers, balances, inventory — that are declared additive
  are the highest-value check in this skill.
- `ratio` must be queried as separate numerator and denominator at the target
  grain. A pre-divided ratio averaged across buckets disagrees with the ratio of
  totals.
- `derived` composes other measures; each ref resolves under its own behavior
  first.
- `count_distinct_approx` cannot support anything that must reconcile to a
  financial system.
- A rollup storing a non-additive measure claims a reaggregation safety it does
  not have.

Cross-check every non-additive measure for a matching `ai_context.caveats`
entry. Enforced-but-invisible semantics are a consumer trap.

### Baked-in narrowing

Measure `filters` are always applied and cannot be removed by a consumer;
`segments` are offered and opted into. A measure named `total_arr` whose filters
restrict to `status = 'active'` cannot answer "ARR including cancelled" at all.
That may be deliberate, but it must be declared — an undeclared baked-in filter
means the exposed name overstates the population.

Filters chosen where segments were meant permanently remove an analytical
option. Segments chosen where filters were meant let consumers compute a number
the business does not recognize.

### Dimension classification

`behavior.type` on a dimension tells consumers how it may be used:
`identifier`, `categorical`, `ordinal`, `bucketing`. An unclassified dimension is
the common cause of nonsense BI output — a consumer groups by an identifier and
every measure collapses to row grain. Assess whether the classification matches
what the column actually is.

### Metrics

A metric is one measure pinned to one time axis. Assess:

- Whether `measure` and `ts` describe the same event. A measure from one fact
  with a time axis from another attributes values across a join, which is a
  modeling risk even when the project loads.
- Whether the metric's name overclaims. A metric named `churn_rate` whose
  measure is a raw count will be believed by whoever reads the catalog.
- Whether the default `granularity` matches the grain the measure can honestly
  support.

### Descriptions, AI context, tags, and terms

Judge accuracy and specificity for public and decision-critical artifacts:

- A description states what the artifact means, including grain, unit,
  population, time basis, or aggregation meaning where it affects safe reading.
- AI context adds reasoning guidance — instructions, synonyms, caveats,
  examples, defaults, required filters, limitations. Restating the description
  is not AI context.
- Tags are controlled categorization, not free-form synonyms. Terms bind to
  governed concepts, not decorative keywords.

Do not demand encyclopedic prose on private intermediate columns. Group repeated
metadata problems into one systemic finding; never emit one finding per absent
description.

### Answerability

Whether the exposed vocabulary can express the questions the product exists to
answer, and whether a question it appears to answer is one it actually can. Link
gaps through `affected_business_questions`.

## Authority boundary

Own semantic findings and one assessment per public or decision-critical exposed
artifact — semantic models, measures, dimensions, segments, metrics, and the
model and column descriptions that explain them.

Consume the established grain, keys, cadence, and cardinality conclusions from
`vulcan-structure` rather than re-deriving them. Code is ground truth for
implemented behavior; when metadata disagrees with code, report the misleading
explanation and do not rewrite the structural conclusion.

Do not own whether anything enforces a semantic claim, whether a member should be
`public`, or whether masking and policy are correctly applied — those are
`vulcan-contract`. If this pass exposes a probable structural defect, record an
integration conflict for `vulcan-structure` instead of relabeling it.
