---
name: vulcan-primitives
description: Explains what every Vulcan authoring primitive *means* for data modeling — model kinds, grains, assertions, macro variables, semantic dimensions/measures/behaviors/segments/joins/rollups/policies, metrics, DQ rules, and the config switches that change validation semantics. Use when reading or writing a Vulcan project and you need to know what a user's choice implies about grain, additivity, time semantics, join safety, idempotency, or cost — or when you need to decide whether an existing model is modeled wrongly.
---

# Vulcan Primitives: What Each Knob Means

## Purpose

This is a **semantics dictionary**, not a syntax reference. For every Vulcan primitive it answers three questions:

1. **What does the author claim** by writing this?
2. **What does Vulcan do** because of that claim?
3. **When is the claim wrong**, and what symptom proves it?

Use it alongside the canonical references in [`references/`](references/), which own the *modeling doctrine*. This file owns the *vocabulary*.

## Source-of-truth rule

Vulcan is a fork of Vulcan with an added semantic/metric/DQ/policy layer. Everything below was read from this repository. When the repo and this file disagree, **the repo wins**. Authoritative locations:

| Concern | File |
|---|---|
| Model kinds | [kind.py](../../core/model/kind.py) |
| Model header fields (`grains`, `assertions`, column metadata) | [meta.py](../../core/model/meta.py) |
| Semantic / metric specs | [semantic.py](../../core/model/semantic.py) |
| Shared enums (measure types, behaviors, granularities, DQ dimensions) | [types.py](../../../schema/types.py) |
| Load-time semantic validators | [validation.py](../../core/model/validation.py) |
| Rollup materialization | [rollup.py](../../core/model/rollup.py) |
| Access policies | [policy.py](../../core/model/policy.py) |
| DQ spec | [spec.py](../../core/soda3/spec.py) |
| Project config | [root.py](../../core/config/root.py) |
| Macro variables | [macro_variables.md](../../../docs/concepts/macros/macro_variables.md) |
| Worked example project | [examples/b2b_saas](../../../examples/b2b_saas) |

The CLI entry point is `vulcan` (`vulcan.cli.main:cli`). Commands mirror Vulcan (`plan`, `run`, `test`, `audit`, `render`, `format`, `table_diff`) plus fork-specific ones (`export metadata|contract|product|joins|dag|okf`, `transpile`, `rewrite`, `import_semantic_view`, `create_deploy_yaml`, `cube`).

## The five authoring layers

A Vulcan project stacks five layers. Each layer's `kind` discriminator tells you which one you are reading.

```text
config.yaml                     product identity, governance, gateways, semantic switches
models/**/*.sql                 MODEL(...)   → physical transformation (layer 1)
models/**/*.yml                 kind: semantic → measures/dimensions/joins (layer 2)
models/metrics/*.yml            kind: metric   → one measure + one time axis (layer 3)
models/**/*-dq.yml              kind: dq       → data-quality rules (layer 4)
policies/**/*.yml               kind: policy   → row filters + column masks (layer 5)
audits/**/*.sql                 reusable runtime audits
tests/**/*.yaml                 unit tests with fixed inputs/outputs
```

**Grain flows upward and cannot be repaired above layer 1.** A semantic model inherits the grain of its physical base; a metric inherits the grain of its measure. If layer 1's grain is wrong, every layer above it is wrong regardless of how carefully it is authored.

---

# Layer 1 — Physical models (`MODEL(...)`)

## `kind` — the most consequential single word in a Vulcan project

`kind` is not a materialization preference. It is a **declaration about how rows relate to time and identity**, and it determines whether reprocessing is safe.

Available kinds ([kind.py](../../core/model/kind.py)):

| `kind` | The author is claiming | Vulcan therefore | Wrong when |
|---|---|---|---|
| `INCREMENTAL_BY_TIME_RANGE (time_column X)` | Every row belongs to exactly one point on `X`, and a row's `X` never changes | Deletes and reinserts the `[@start_date, @end_date]` slice per run; tracks processed intervals | Rows are back-dated or restated after load; `X` is `updated_at` rather than event time; the query does not filter on `X` |
| `INCREMENTAL_BY_UNIQUE_KEY (unique_key K)` | `K` identifies a business entity whose latest version wins | Merges/upserts on `K` | `K` is not unique in the source batch (silent last-writer-wins); history is needed but discarded |
| `INCREMENTAL_BY_PARTITION` | Whole partitions are replaced atomically | Overwrites touched partitions | Partition column has high cardinality, or a run touches a partition it does not fully rebuild |
| `INCREMENTAL_UNMANAGED` | "I append; do not manage intervals for me" | Appends, no interval bookkeeping | Almost always a smell — reruns duplicate rows. Justify explicitly |
| `FULL` | Output is a pure function of current inputs; cost of full rebuild is acceptable | Recomputes everything each run | Table is large and mostly immutable (wasted cost), or the query uses `CURRENT_DATE`/`NOW()` so yesterday's output can never be reproduced |
| `VIEW` | Logic should not be materialized | Creates a view | Downstream consumers pay the computation repeatedly; a BI/API surface reads it hot |
| `EMBEDDED` | Not a table at all — inline this into consumers | Inlines like a CTE; no object created | Multiple consumers need the same expensive intermediate result |
| `SEED` | Reference data lives in CSV in git | Loads the seed file | Values change often, or the seed is large enough to belong in a source system |
| `EXTERNAL` | Vulcan reads but never owns this table | Records schema only (`create_external_models`) | Vulcan is expected to refresh it |
| `SCD_TYPE_2_BY_TIME` | Attribute history matters and the source carries reliable change timestamps | Maintains `valid_from`/`valid_to` intervals | Source timestamps are unreliable → overlapping or gapped intervals |
| `SCD_TYPE_2_BY_COLUMN` | Attribute history matters; detect change by comparing tracked columns | Opens a new version when a tracked column changes | Untracked columns also matter, or nulls flap and create spurious versions |
| `SCD_TYPE_2` | *Legacy alias only* | Parsed as `SCD_TYPE_2_BY_TIME` | Use the explicit name in new code |
| `MANAGED` | The engine owns refresh (e.g. dynamic/materialized table) | Delegates refresh to the engine | Semantics differ per engine; verify against the target engine |
| `CUSTOM` | A registered custom materialization applies | Delegates to that strategy | The custom strategy's idempotency is undocumented |
| `DBT_CUSTOM` | dbt-project compatibility path | dbt materialization mapping | Used outside a dbt-loaded project |
| `SEMANTIC` | This is a layer-2 asset, not a table | Registers under the `__virtual` namespace; **no physical table** | Someone expects to `SELECT` it from the warehouse directly |
| `METRIC` | This is a layer-3 asset | Same — virtual only | Same |

`SEMANTIC` and `METRIC` are real entries in `ModelKindName` in this fork. They share the model graph and fingerprinting machinery with physical kinds, which is why a semantic YAML change triggers a plan diff.

### Diagnosing a wrong `kind`

- `FULL` on a large append-only fact → cost defect. Read the row volume before recommending a change.
- `INCREMENTAL_BY_TIME_RANGE` whose SELECT lacks `BETWEEN @start_date AND @end_date` → the model rescans everything and writes it into one interval. Correctness *and* cost defect.
- `INCREMENTAL_BY_UNIQUE_KEY` on an events table → history silently collapses. Ask what "one row" means; if it is an event, the key is not unique by nature.
- Any incremental kind plus unparameterized `CURRENT_DATE` in the body → backfills cannot reproduce history. Use `@start_date`/`@end_date`/`@execution_date`.
- `SCD_TYPE_2_*` with no test asserting non-overlapping intervals → unverified history.

## `grains` — the grain contract

```sql
MODEL (
  name revenue.subscriptions,
  kind FULL,
  grains (subscription_id)
);
```

`grains` (plural; `grain` is accepted as a singular alias, but **setting both raises a config error** — see [meta.py](../../core/model/meta.py)) declares the column set that uniquely identifies a row.

In this fork `grains` is not documentation — it is **load-blocking infrastructure for the semantic layer**:

- `_semantic_grains_required`: a semantic model's physical base **must** declare grains, or the project fails to load.
- `_semantic_joins_require_grains`: a semantic model that declares joins requires grains on the declaring model's physical base.

Read that as a design statement: Vulcan refuses to build a semantic layer on a table whose grain nobody has committed to, because join fanout and measure additivity are undecidable without it.

**Signals the declared grain is a lie:** row count exceeds `COUNT(DISTINCT grain)`; a `count` measure returns numbers larger than the entity population; a `many_to_one` join inflates a sum.

## `assertions` and audits

Vulcan adds **assertions** as model-local invariants, alongside Vulcan's reusable audits.

```sql
MODEL (
  name revenue.subscriptions,
  kind FULL,
  grains (subscription_id),
  assertions (active_subscriptions_positive_mrr)
);

SELECT ...;

ASSERTION (
  name active_subscriptions_positive_mrr,
  description "Live subscriptions must carry positive monthly recurring revenue.",
  dimension validity
);
SELECT * FROM @this_model
WHERE status = 'active' AND (mrr IS NULL OR mrr <= 0);
```

Meaning:

- An assertion query **returning rows is a failure**. It is a counterexample query, not a filter.
- `dimension` uses the same eight-value DQ vocabulary as layer 4 (see below), so assertion failures classify into the same governance export as DQ results.
- `@this_model` inside an assertion resolves to the physical table being validated — that is what makes the assertion reusable across environments.
- Reusable audits live in `audits/**/*.sql` and attach via `audits (...)`.

**What it means when there are none:** the `nomissingaudits` linter rule exists precisely to flag this. An un-asserted model has no machine-checkable definition of correct.

## Column-level metadata

The `MODEL` header carries governance metadata that flows into contract/metadata export:

- `column_tags` / `column_terms` — free-form labels and glossary term references per column.
- `column_classifications` — per-column sensitivity, restricted to `public | internal | restricted | confidential`. Accepts `col = 'level'` or `col level` shorthand; a classification naming a column that does not exist is dropped with a warning.

Glossary references also appear as `#term` annotations in SQL comments in the examples (`-- #finance.monthly_recurring_revenue`). Those are documentation conventions, not parsed contracts.

Other header fields worth reading as modeling signals: `cron` (claimed freshness — must be consistent with the product SLA), `start` (earliest backfillable interval), `owner`, `stamp` (force a new version), `enabled`, `optimize_query`.

---

# Macro variables — the reproducibility contract

Macro variables are how a model states *which slice of time it is computing*. Misusing them is the most common cause of a model that "works" but cannot be backfilled.

All temporal variables are **UTC**. Prefixes × postfixes ([macro_variables.md](../../../docs/concepts/macros/macro_variables.md)):

- Prefixes: `start` (inclusive interval start), `end` (inclusive interval end), `execution` (when the run started).
- Postfixes: `dt` (TIMESTAMP), `dtntz` (TIMESTAMP WITHOUT TIME ZONE), `date` (DATE), `ds` (`'%Y-%m-%d'`), `ts` (ISO 8601), `tstz` (ISO 8601 + offset), `hour` (0–23 int), `epoch` (seconds), `millis` (milliseconds).

So `@start_date`, `@end_ts`, `@execution_epoch`, `@start_hour` etc. all exist mechanically.

### What each family means for modeling

| Variable | Modeling meaning | Misuse signal |
|---|---|---|
| `@start_*` / `@end_*` | The interval this run **owns**. Every incremental model's WHERE clause must be expressed in these terms | Absent from an `INCREMENTAL_BY_TIME_RANGE` body → the model is not really incremental |
| `@execution_*` | Wall-clock time of the run. Bookkeeping only | Used as a business timestamp → the same logical interval produces different results on rerun |
| `CURRENT_DATE` / `NOW()` (not a macro) | Nothing is pinned | Any appearance in an incremental or historical model is a reproducibility defect. Replace with `@end_date` or `@execution_date` deliberately |
| `@runtime_stage` | Which lifecycle phase is executing: `loading`, `creating`, `evaluating`, `promoting`, `demoting`, `auditing`, `testing` | Used to gate pre/post statements. Side effects that run during `loading` are a bug — loading happens on every CLI invocation |
| `@this_model` | The physical table the model's view selects from; in `on_virtual_update` statements it is the qualified **view** name instead | Hardcoded table names instead of `@this_model` break generic audits and environment isolation |
| `@gateway` | Current gateway name | Branching business logic on gateway means environments compute different numbers |
| `@model_kind_name` | Current kind, for conditional physical properties in model defaults | — |
| `@this_env`, `@schemas`, `@views` | Only available in `before_all` / `after_all` statements | Referenced in a model body → unresolved |

`@{variable}` (braces) renders as a **quoted identifier**; `@variable` does a plain substitution. `@{x}_suffix` is the idiom for building identifiers; `@x` is for values. Getting this backwards produces either a quoted string where a table was meant or an unquoted `foo.bar` split across identifiers.

Project variables from `config.yaml` `variables:` are read with `@VAR('name')`; blueprint variables with `@BLUEPRINT_VAR(...)`. Control-flow macros include `@IF`, `@REDUCE`, `@FILTER`, `@AND`, `@OR`, `@EVAL`, and `@resolve_template` (which requires `@this_model` in scope and supports `@{catalog_name}` / `@{schema_name}` / `@{table_name}`).

---

# Layer 2 — `kind: semantic`

A semantic model binds **one physical model at one grain** to a consumer-facing vocabulary served over SQL, REST, and GraphQL.

```yaml
kind: semantic
name: subscriptions
depends_on: revenue.subscriptions
```

`depends_on` is a single physical model name (required). One semantic model, one grain — a semantic model spanning two grains is the defect that `joins` exists to avoid.

Top-level fields: `name`, `depends_on`, `description`, `owner`, `tags`, `terms`, `ai_context`, `dimensions` (required), `measures`, `segments`, `joins`, `rollups`, `policies`.

## `dimensions` — how a column may be used

Two authoring forms: shorthand (`- plan_id`) and full (`- name: plan_id` with attributes). Both appear in the examples; shorthand means "expose as-is, no semantic classification".

Fields: `name`, `description`, `tags`, `terms`, `format`, `granularities`, `behavior`, `ai_context`, `public`, plus `mask_expression`.

### `behavior.type` — `DimensionSemanticTypeValue`

| Value | Means | Consequence |
|---|---|---|
| `identifier` | Primary key or filter-only ID | Do not group by it in aggregate reporting; grouping by an identifier reduces every measure to one row per entity |
| `categorical` | A legitimate slice/group axis (plan, tier, channel) | Safe in `GROUP BY`; the intended breakdown dimension |
| `ordinal` | Ordered categories (rank, tier level) | Sortable; not arithmetic-safe |
| `bucketing` | Numeric range buckets | Pre-binned; do not re-bin downstream |

Unclassified dimensions are the most common cause of nonsense BI output: a consumer groups by `subscription_id` and every measure collapses to the row grain. The classification is how you tell them not to.

### `granularities` — custom time buckets

```yaml
- name: event_date
  granularities:
    - name: fiscal_week
      interval: 1 week
      offset: 3 days
      origin: '2024-01-01'
```

`interval` must be a positive duration (`1 day`, `15 minutes`); `offset`/`origin` shift bucket boundaries for fiscal calendars. `_semantic_dimension_granularities` requires the underlying **physical column to be TIMESTAMP-compatible** — declaring granularities on a string date fails load. That validator is the guardrail against "date stored as VARCHAR", which otherwise produces silently wrong period boundaries.

### `mask_expression` and `public`

- `mask_expression: "CAST('---' AS TEXT)"` — the value substituted when a policy masks this column. Its type must be compatible with the column's type or the masked query fails at the engine.
- `public: false` — member exists for internal composition but is hidden from consumers. This is the correct way to expose a curated surface without deleting intermediate members.

## `measures` — the additivity contract

Two orthogonal axes, and conflating them is the classic Vulcan modeling error:

- **`type`** = the SQL aggregation to emit.
- **`behavior.type`** = the analytical semantics of the result.

### `type` — `MeasureTypeValue`

`count`, `count_distinct`, `count_distinct_approx`, `sum`, `avg`, `min`, `max`, `number`, `string`, `time`, `boolean`.

Enforced rules ([semantic.py](../../core/model/semantic.py) `MeasureSpec`):

- Only `count` may omit `expression`. Every other type requires a non-empty expression.
- The name `count` is **reserved** for the implicit `COUNT(*)` row-count measure.
- `filters` are allowed only on `sum`, `avg`, `min`, `max`, `count`, `count_distinct`, `count_distinct_approx`.
- `type: number` **cannot** be combined with `filters` — `number` is a composition of other members, so a row filter would be applied at the wrong stage. Push the filter into the referenced measures instead.
- Result types: `sum|avg|min|max|number` → DOUBLE; `count|count_distinct|count_distinct_approx` → BIGINT; `string` → VARCHAR; `time` → TIMESTAMP; `boolean` → BOOLEAN.
- Subqueries are rejected in measure `filters` and in segment expressions — no `EXISTS`, `IN (SELECT …)`, scalar subqueries, or CTEs. The commented "NEGATIVE TEST" blocks in [subscriptions.yml](../../../examples/b2b_saas/models/revenue/subscriptions.yml) are the canonical list. A filter needing a subquery is a signal the physical model is missing a column.

`count_distinct_approx` trades exactness for cost; it must not be used where reconciliation to a financial system is required.

### `behavior.type` — `SemanticMeasureTypeValue`

This is the field that decides whether a number may be summed. `is_additive` is **computed**, not authored: it is `True` only for `simple` and `flow`.

| Behavior | Means | Required fields | Forbidden fields | Reaggregation rule |
|---|---|---|---|---|
| `simple` | Standard additive count/sum | — | all optional behavior fields | Sum freely across any dimension |
| `flow` | Amount that *occurred during* the period (signups, orders, churn events) | — | all optional behavior fields | Additive across time; marks event semantics rather than a level |
| `stock` | Point-in-time **level** (MRR, ARR, headcount, active customers) | `time_dimension`, `period_treatment`, `period_grain` | `numerator`, `denominator`, `measure_refs` | **Never sum across time.** Pin to a boundary via `period_treatment` |
| `ratio` | Numerator ÷ denominator at query grain | `numerator`, `denominator` | `time_dimension`, `period_treatment`, `period_grain` | Query parts separately at target grain, then divide. `measure_refs` is auto-set to `[numerator, denominator]`; authored values are ignored |
| `derived` | Composed from other measures | `measure_refs` | time and ratio fields | Each ref resolves per its own behavior before composition |

`period_treatment` — `last` (snapshot at period end: ARR, headcount), `avg` (average over the period: inventory), `first` (opening balance). `period_grain` uses the granularity vocabulary (`second`…`year`).

`MeasureBehaviorSpec.validate_by_type` enforces the required/forbidden matrix at parse time; `_semantic_measure_behaviors` then checks that the referenced `time_dimension` and `measure_refs` actually resolve on the model graph. So a `stock` measure that forgets `period_treatment` fails loudly — but a `stock` measure declared as `simple` **loads fine and is silently wrong**. Nothing in the engine can catch that, which makes it the highest-value thing to check by hand in a review.

### Reading a real measure

```yaml
- name: total_arr
  type: sum
  expression: "{subscriptions.arr}"
  filters: ["{subscriptions.status} = 'active'"]
  behavior:
    type: stock
    time_dimension: start_date
    period_treatment: last
    period_grain: day
```

Decoded: sum `arr` over active rows; the result is a **level**, so summing it across a date range is meaningless — pin `start_date` to the last day of each period. The active-status filter is baked in, which means a consumer cannot get "ARR including cancelled" from this member at all. That is a deliberate narrowing and belongs in `ai_context.caveats`.

### `filters` vs `segments`

- Measure `filters` are **baked in** — always applied, invisible to the consumer, not removable.
- `segments` are **offered** — the consumer opts in.

Choosing `filters` when you meant `segments` permanently removes an analytical option. Choosing `segments` when you meant `filters` lets consumers compute a number the business does not recognize.

### `rolling_window`

```yaml
rolling_window:
  trailing: 30 days   # or 'unbounded'
  leading: 0 days
  offset: end         # 'start' | 'end'
```

Sizes match `^-?\d+\s+(minute|hour|day|week|month|year)s?$` or `unbounded`. A rolling-window measure referenced by a **materialized rollup** requires that rollup to set `date_range` — the pre-aggregation needs a bounded build window.

## `segments` — named, reusable filters

Fields: `name`, `expression`, `description`, `public`, `tags`, `terms`, `ai_context`. Expressions use `{model.member}` references and, like measure filters, may not contain subqueries.

Consumers reach them differently per interface — SQL API `WHERE recent_churn IS TRUE`, REST `"segments": ["subscriptions.recent_churn"]`, GraphQL by filtering the underlying dimension. That asymmetry is exactly what `ai_context.instructions` should record.

## `joins` — the fanout contract

```yaml
joins:
  - name: subscription_plans
    type: many_to_one
    expression: "{subscriptions.plan_id} = {subscription_plans.plan_id}"
  - name: users
    type: many_to_one
    skip_for_bi: true
    expression: "{subscriptions.user_id} = {users.user_id}"
```

`type` — `JoinRelationshipValue`: `one_to_one`, `one_to_many`, `many_to_one`. **There is no `many_to_many`.** If a relationship is genuinely many-to-many, Vulcan is forcing you to model a bridge table rather than let the semantic layer double-count.

Direction is a **claim about cardinality that Vulcan trusts**. It is not verified against the data. A `many_to_one` that is actually one-to-many inflates every sum on the declaring side. Verify with `COUNT(*)` vs `COUNT(DISTINCT key)` on the target before believing it.

`on` vs `expression`: at least one required. `on` is the structured equi-join form and compiles into `expression` as `{source}.col = {target}.col`, overwriting any authored `expression`. Take the `expression` path only for non-trivial predicates.

### `skip_for_bi` and reciprocal joins

When A joins B and B joins A (a reciprocal pair), **exactly one direction must set `skip_for_bi: true`**. Both edges remain available for semantic join-path resolution; only the flagged one is omitted from BI export. This exists because Tableau and Power BI cannot represent a bidirectional relationship without ambiguous filter propagation.

Governed by `allow_reciprocal_joins` in `config.yaml` (default `True` in [root.py](../../core/config/root.py)). Setting it to `False` makes reciprocal edges a load failure.

Graph-level validators: `_graph_join_cycles` (cycles) and `_graph_unlinked_join_targets` (a join naming a semantic model that never linked to a physical table).

## `rollups` — pre-aggregations

Gated by `enable_rollup` in `config.yaml`, **default `False`**. If rollups are authored but the flag is off, they are inert — a common "why is my query still slow" cause.

```yaml
rollups:
  - name: arr_monthly
    measures: [total_arr, subscription_count]
    dimensions: [plan_type, status, billing_cycle]
    time_dimension: start_date
    granularity: month
```

Rules ([semantic.py](../../core/model/semantic.py) `RollupSpec`, [rollup.py](../../core/model/rollup.py)):

- **`segments` are rejected outright** on rollups. A segment is a query-time choice; baking it into a pre-aggregation would produce a table that answers only one filtered question.
- `granularity` requires `time_dimension`. `date_range` requires `time_dimension`.
- Must reference at least one of `measures`, `dimensions`, `time_dimension`.
- Measures must belong to **this** semantic model (materialized rollups). Dimensions may come from this model or any join-reachable one.
- **Materialized** rollups become their own Vulcan model, building `<rollup_schema>.<model_name>_<rollup_name>` (e.g. `vulcan_rollups.users_signups_01`). Build SQL comes from the transpiler service; the table is always Vulcan-owned, never external.
- Naming: `model_name` and `rollup_name` must match `^[a-z][a-z0-9_]*$`. The transpiler lower-cases and snake_cases the identifier, so any uppercase letter would desynchronize the emitted name from the table Vulcan creates. The combined `<model>_<rollup>` must fit the physical identifier budget (≈32 chars with the default `rollup_schema` on Postgres).
- **Composite** rollups set `rollups:` with **exactly two** entries qualified as `{model}.{rollup_name}`. They are serve-only — no warehouse table is built — and they alone may reference cross-model measures.

Modeling meaning: a rollup is a **claim that the stored aggregate reaggregates correctly**. That claim is safe for `simple`/`flow` measures and dangerous for `stock`, `ratio`, `avg`, and exact `count_distinct`. Storing a pre-divided ratio and then averaging it across buckets is the defect this whole vocabulary exists to prevent. Always test rollup output against the base query.

## `policies` (inline)

```yaml
policies:
  - group: executive
  - group: analyst
    filter:
      - member: status
        operator: equals
        values: [active]
```

A group with no `filter`/`mask` sees everything. See layer 5 for the operator vocabulary.

## `ai_context` — a first-class modeling artifact

Available on the model and on measures, dimensions, segments, joins, granularities, and metric refs. Fields: `instructions` (string or list), `synonyms`, `caveats`, `examples` (each with `description`, `format` ∈ `sql | graphql | rest`, `query`).

Treat this as the **machine-readable limitations contract**. `caveats` is where non-additivity, baked-in filters, and approximation live. A `stock` measure or a `ratio` measure with no caveat is an incomplete model — the semantics are enforced in the engine but invisible to the consumer or agent choosing the member.

`ai_context` participates in `metadata_hash`, not `data_hash` — editing it does not force data recomputation.

---

# Layer 3 — `kind: metric`

```yaml
kind: metric
name: churn_analysis
measure: subscriptions.churn_count
ts: subscriptions.end_date
granularity: month
dimensions:
  - name: plan_type
    ref: subscriptions.plan_type
  - name: signup_channel
    ref: users.signup_channel
```

A metric is **one measure pinned to one time axis at one default granularity**, exposed as its own queryable object where the measure is addressed as `measure` and the time axis as `ts`.

Required: `measure`, `ts`, `granularity`. Optional: `dimensions`, `segments` (both lists of `{name, ref}`), `description`, `owner`, `tags`, `terms`, `ai_context`, `join_path`.

`_metric_validate` / `_metric_field_issues` enforce that each `model.field` ref resolves on a linked semantic model, and that the `ts` ref points at a **TIMESTAMP-compatible column**.

### `metric_join_path` — the switch that decides how strict cross-model metrics are

`config.yaml` key, values `connected` or `directed`. In [common.py](../../core/config/common.py), `MetricJoinPath.default` is **`directed`**.

> Note: the `Config` docstring in [root.py](../../core/config/root.py) says it defaults to `connected`. The code says `directed`. Trust the enum; the docstring is stale.

- `directed` — every referenced semantic model must be **join-reachable from the measure's anchor model**, and `join_map` is populated for export. Cross-model dimensions get one deterministic path.
- `connected` — mere graph connectivity suffices; `join_map` is left empty. Looser, and it permits metrics whose join path is ambiguous.

`_metric_join_pairs` and `_metric_directed_join_path_issue` implement this.

### The high-risk metric shape

**A metric whose `measure` comes from one fact and whose `ts` comes from another is a modeling risk**, even when it loads. `churn_analysis` is legitimate: `churn_count` and `end_date` both live on `subscriptions`, so the time axis is the event's own timestamp. The dangerous version is `measure: subscriptions.total_arr` with `ts: usage_events.event_date` — that attributes revenue to usage timing across a join. Prefer a purpose-built derived fact unless compatible grain and attribution are proven.

Also check: the metric's **name must not overclaim**. A metric named `churn_rate` whose `measure` is a raw count is a naming defect that will be believed by whoever reads the catalog.

---

# Layer 4 — `kind: dq`

```yaml
kind: dq
name: users_dq
depends_on: customer.users
filter: industry = 'finance'
profiles: [plan_type, email, status]
rules:
  - missing_count(company_name) = 0
  - duplicate_count(email) = 0
  - row_count > 20
  - anomaly detection for row_count
  - change for row_count >= -50%
  - failed rows:
      name: invalid_emails
      dimension: validity
      fail query: |
        SELECT user_id, email FROM customer.users WHERE email NOT LIKE '%@%'
      samples limit: 10
```

`kind: dq` is canonical; `type: dq` appears in older files and still parses. Prefer `kind`. `depends_on` is required; `rules` needs at least one entry.

- `profiles` — columns to compute distribution statistics for (min/max/avg/stddev/distinct/frequent values/histogram/quantiles). Profiling a PII column publishes sample values — treat the profile list as a disclosure decision, not a convenience.
- `filter` — restricts the scan. It also restricts what the rules actually prove; a rule under a filter is not a table-wide guarantee.

### Rule forms

Metric comparisons (`row_count`, `missing_count(col)`, `missing_percent`, `duplicate_count`, `duplicate_percent`, `invalid_count`, `valid_count`, `avg`, `min`, `max`, `sum`, `min_length`, `max_length`, `avg_length`, `stddev*`, `var*`, `percentile`) plus pattern-based forms:

| Form | Default dimension | Means |
|---|---|---|
| `change [same day last week \| avg last N] for X <op> V` | `timeliness` | Compare against history — requires accumulated history to be meaningful |
| `anomaly detection for X` | `accuracy` | Learned baseline; noisy until enough runs exist |
| `failed rows` + `fail query` | `validity` | Counterexample query; **returning rows is a failure** |
| `schema` / `schema evolution` | `conformity` | Structural drift |
| `freshness(col)` | `timeliness` | Staleness of a timestamp column |
| `values in X must exist in …` | `consistency` | Referential integrity |
| `distribution(...)` / `distribution_difference(...)` | `conformity` | Distribution shift |

`dimension` may be set explicitly per rule; otherwise it is derived from the expression pattern, then the leading metric name, then falls back to `validity`. Allowed values (`DQDimension`): `accuracy`, `completeness`, `conformity`, `consistency`, `coverage`, `timeliness`, `validity`, `uniqueness`. These map to ODPS v3.1 standardized dimensions, so a wrong dimension mislabels the published quality report.

`name` is optional and auto-derived from the expression when omitted (`missing_count(email) = 0` → `missing_count_email_eq_0`). Auto-derived names are unstable under edits — name any rule you intend to track over time.

### DQ review signals

- Threshold contradicts the rule name (`missing_count(email_1) = 1` named "email required") — the name will be believed, the threshold will execute.
- `failed rows` with no `samples limit` — unbounded diagnostic output, and PII exposure if the query selects sensitive columns.
- No uniqueness rule on the declared `grains` — the grain contract is unverified in production.
- Every rule at `= 0` on a table known to be dirty — the DQ suite will be permanently red and therefore ignored.
- `change`/`anomaly` rules on a brand-new model — no baseline yet; expect noise.

Assertions (layer 1) and DQ rules (layer 4) split by intent: assertions are transformation invariants checked as part of the model; DQ rules are production data observations with dimensions, profiles, and history. Both feed the same governance vocabulary.

---

# Layer 5 — `kind: policy`

Standalone asset (`kind: policy`, `name`, `depends_on` as a **list**, `rules`) or inline `policies:` on a semantic model.

Each rule: `group` (required), `filter` (list of filter expressions), `mask` (list of members to mask using their `mask_expression`).

`FilterOperator` ([policy.py](../../core/model/policy.py)): `equals`, `notEquals`, `contains`, `notContains`, `startsWith`, `notStartsWith`, `endsWith`, `notEndsWith`, `in`, `notIn`, `gt`, `gte`, `lt`, `lte`, `set`, `notSet`, `inDateRange`, `notInDateRange`, `onTheDate`, `beforeDate`, `beforeOrOnDate`, `afterDate`, `afterOrOnDate`, `measureFilter`.

`set`, `notSet`, and `measureFilter` take **no** `values`. Composition uses `and` / `or` logical filters.

Modeling meaning: a policy changes **which rows a group's measures aggregate over**. Two groups with different policies legitimately see different totals for the same measure — that is the design, and it must be documented or it reads as a data bug. Verify the policy applies across **all** interfaces (SQL, REST, GraphQL, BI export), not just the one you tested.

---

# `config.yaml` switches that change modeling semantics

Most config is plumbing. These specific keys change what Vulcan *validates and permits*:

| Key | Default | Effect |
|---|---|---|
| `enable_rollup` | `false` | Rollup blocks are inert unless on |
| `allow_reciprocal_joins` | `true` | When `false`, reciprocal join pairs fail load |
| `strict_semantic_validation` | `false` | When `false`, semantic **expression-shape** violations are logged as errors but do **not** fail load. Turn on for CI |
| `metric_join_path` | `directed` | `directed` requires reachability from the measure anchor and populates `join_map`; `connected` only requires graph connectivity |
| `vde` / `virtual_data_environment` | `false` | Full virtual environments — isolated schemas without copying unchanged tables |
| `gateways.<g>.rollup_schema` | `vulcan_rollups` | Schema for materialized rollup tables; feeds the identifier-length budget |
| `model_defaults` | — | `dialect`, `cron`, `start`, `stamp`, `optimize_query`, `enabled` applied to models that do not override |
| `linter` | — | `enabled`, `rules`, `warnRules`; includes `nomissingaudits` and `nomissingdataosusername` |
| `physical_table_naming_convention` | `schema_and_table` | Affects identifier length, which affects rollup name validation |

`strict_semantic_validation: false` is the one that most often surprises people: a project can load clean and still contain expression-shape violations that were only logged. Check the load output, not just the exit code.

The rest of `config.yaml` is the **data product envelope** — `name`, `tenant`, `domain`, `version`, `alignment`, `status`, `tags`, `terms`, `usage_path`, `agreement_path`, `compliance`, `support`, `sla`, `license`, `dataHolder`, `issueTracker`, `users` (with `type: product_owner | data_steward | data_engineer`). It exports to ODCS/ODPS contracts. Review it for **consistency with the models**: an `sla.update_frequency` of 7 days against a `*/5 * * * *` cron, or a description promising questions the models cannot answer, is a governance defect even though nothing fails.

---

# Load-time validators as a diagnostic index

When a Vulcan project fails to load, the validator name tells you which modeling claim broke ([validation.py](../../core/model/validation.py)):

| Validator | The claim that broke |
|---|---|
| `_semantic_grains_required` | Physical base has no `grains` — nobody committed to a grain |
| `_semantic_joins_require_grains` | Joins declared without a grain to join at |
| `_semantic_dimension_columns` | A dimension names a column that does not exist physically — semantic/physical drift |
| `_semantic_dimension_granularities` | Time granularities on a non-TIMESTAMP column |
| `_semantic_field_uniqueness` | Same name used across dimensions/measures/segments on one model — ambiguous reference |
| `_semantic_measures` | Measure `filters` or body expression invalid, or references an unresolvable member |
| `_semantic_measure_behaviors` | Behavior's `time_dimension` or `measure_refs` do not resolve. (The required/forbidden field matrix itself is enforced earlier, at parse time in `MeasureBehaviorSpec`) |
| `_semantic_segments` | Segment expression invalid or references unknown members |
| `_semantic_joins` | Join target unresolvable, or join predicate invalid |
| `_semantic_materialized_rollups` | Rollup identifier/length, member ownership, rolling-window `date_range`, time dimension, or **masked dimension** violated — a rollup may not pre-aggregate a masked column |
| `_semantic_composite_rollups` | Composite rollup sources, measures, segments, dimensions, or time dimension invalid |
| `_graph_join_cycles` | Join graph contains a cycle |
| `_graph_unlinked_join_targets` | Join targets a semantic model with no physical link |
| `_metric_validate` / `_metric_field_issues` | Metric ref unresolvable, or `ts` is not TIMESTAMP-compatible |
| `_metric_directed_join_path_issue` | Under `directed`, a ref is not reachable from the measure anchor |

---

# Symptom → likely modeling defect

| Symptom | Check first |
|---|---|
| Measure totals inflated when grouped by a joined dimension | Join `type` claims `many_to_one` but the target is not unique on the key |
| Summing MRR/ARR/headcount across a date range gives absurd numbers | `behavior.type` should be `stock` but is `simple`/`flow`; or a consumer ignored the caveat |
| A ratio averaged across buckets disagrees with the ratio of totals | `ratio` behavior not declared, or numerator/denominator not queried separately |
| Backfill produces different numbers than the original run | Unparameterized `CURRENT_DATE`/`NOW()`, or `@execution_*` used as a business timestamp |
| Reruns duplicate rows | `INCREMENTAL_UNMANAGED`, or an incremental model that does not filter on its `time_column` |
| History silently disappears | `INCREMENTAL_BY_UNIQUE_KEY` on event-grain data; or SCD needed but `FULL`/upsert used |
| Rollup result ≠ base query result | Non-additive measure stored in a rollup, or rollup grain coarser than the query |
| Rollup exists but queries are still slow | `enable_rollup: false`, or the query does not match the rollup's grain |
| BI tool reports ambiguous relationships | Reciprocal join pair with no `skip_for_bi`, or a cycle in the join graph |
| Semantic member missing from the API | `public: false`, or a policy masks it for that group |
| Two consumers get different totals for the same measure | Policy row filters differ by group — verify this is intended and documented |
| Cross-model metric returns unexpected attribution | `metric_join_path: connected` allowed an ambiguous path; or `measure` and `ts` come from different facts |
| Project loads clean but numbers are wrong | `strict_semantic_validation: false` swallowed expression-shape errors — re-read the load log |
| Grouping by an ID collapses every measure to one row | Dimension is an `identifier` and should not be a grouping axis |

---

# Enum quick reference

```text
ModelKindName            INCREMENTAL_BY_TIME_RANGE | INCREMENTAL_BY_UNIQUE_KEY |
                         INCREMENTAL_BY_PARTITION | INCREMENTAL_UNMANAGED | FULL |
                         SCD_TYPE_2 (legacy) | SCD_TYPE_2_BY_TIME | SCD_TYPE_2_BY_COLUMN |
                         VIEW | EMBEDDED | SEED | EXTERNAL | CUSTOM | MANAGED |
                         DBT_CUSTOM | SEMANTIC | METRIC

MeasureTypeValue         count | count_distinct | count_distinct_approx | sum | avg |
                         min | max | number | string | time | boolean
SemanticMeasureTypeValue simple | flow | stock | ratio | derived      (additive: simple, flow)
DimensionSemanticType    categorical | identifier | bucketing | ordinal
PeriodTreatmentValue     last | avg | first
JoinRelationshipValue    one_to_one | one_to_many | many_to_one       (no many_to_many)
MetricGranularityValue   second | minute | hour | day | week | month | quarter | year
MetricJoinPathValue      connected | directed                          (default: directed)
LogicalTypeValue         number | string | time | boolean
IntervalUnit             year | month | day | hour | half_hour | quarter_hour | five_minute

DQDimension              accuracy | completeness | conformity | consistency |
                         coverage | timeliness | validity | uniqueness
ColumnClassification     public | internal | restricted | confidential
AiContextExampleFormat   sql | graphql | rest

OnDestructiveChange      ERROR | WARN | ALLOW | IGNORE
Naming pattern           ^[a-zA-Z_][a-zA-Z0-9_]{0,63}$   (rollups additionally: ^[a-z][a-z0-9_]*$)
```

---

# Verification commands

Never assert a modeling conclusion you have not checked. From a project root:

```bash
vulcan format && vulcan plan --no-prompts
```

```bash
vulcan test && vulcan audit
```

```bash
vulcan render <model_name>
```

```bash
vulcan export joins && vulcan export metadata
```

`render` is the fastest way to see what macro variables actually expanded to. `export joins` is the fastest way to see the join graph Vulcan believes in, including which edges were dropped by `skip_for_bi`.

Cardinality and grain evidence still comes from the warehouse:

```sql
SELECT COUNT(*), COUNT(DISTINCT <declared_grain>) FROM <model>;
```

If those two numbers differ, stop reviewing the semantic layer — the grain contract is broken and everything above it is unreliable.
