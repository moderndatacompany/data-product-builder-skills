from __future__ import annotations
_A=None
import logging,time,typing as t
from collections.abc import Awaitable,Callable,Iterator
from contextlib import contextmanager
from pydantic_ai.usage import RunUsage,UsageLimits
from vulcan.review.agents.factories import ReviewDependencyError
from vulcan.review.packet.builder import SpecialistContext
from vulcan.review.schemas import DimensionKey,StageDiagnostics,TokenUsage
from vulcan.review.utils.text import exception_detail
logger=logging.getLogger(__name__)
_T=t.TypeVar('_T')
@contextmanager
def stage_timer()->Iterator[Callable[[],float]]:started=time.monotonic();yield lambda:time.monotonic()-started
def token_usage(usage:RunUsage)->TokenUsage:return TokenUsage(requests=usage.requests,input_tokens=usage.input_tokens,output_tokens=usage.output_tokens,total_tokens=usage.total_tokens,cache_read_tokens=usage.cache_read_tokens,cache_write_tokens=usage.cache_write_tokens)
def stage_diagnostics(stage:str,usage:TokenUsage,elapsed:float,*,dimension:DimensionKey|_A=_A,context:SpecialistContext|_A=_A,accepted_findings:int=0,error:str|_A=_A)->StageDiagnostics:return StageDiagnostics(stage=stage,dimension=dimension,requests=usage.requests,input_tokens=usage.input_tokens,output_tokens=usage.output_tokens,total_tokens=usage.total_tokens,cache_read_tokens=usage.cache_read_tokens,cache_write_tokens=usage.cache_write_tokens,elapsed_seconds=elapsed,unique_evidence_accesses=context.unique_accesses if context else 0,duplicate_evidence_accesses=context.duplicate_accesses if context else 0,malformed_evidence_requests=context.malformed_requests if context else 0,accepted_findings=accepted_findings,error=error)
async def run_agent_stage(stage:str,call:Callable[[RunUsage],Awaitable[_T]],diagnostics_kwargs:Callable[[],dict[str,t.Any]]=lambda:{},*,failure_prefix:str|_A=_A,failure_log:Callable[[str],_A]|_A=_A)->tuple[_T|_A,StageDiagnostics,str|_A]:
	local_usage=RunUsage()
	with stage_timer()as elapsed:
		try:output=await call(local_usage);diagnostics=stage_diagnostics(stage,token_usage(local_usage),elapsed(),**diagnostics_kwargs());return output,diagnostics,_A
		except ReviewDependencyError:raise
		except Exception as exc:detail=exception_detail(exc,prefix=failure_prefix)if failure_prefix else exception_detail(exc);(failure_log or logger.error)(detail);diagnostics=stage_diagnostics(stage,token_usage(local_usage),elapsed(),error=detail,**diagnostics_kwargs());return _A,diagnostics,detail
def unrestricted_usage_limits()->UsageLimits:return UsageLimits(request_limit=_A,tool_calls_limit=_A,input_tokens_limit=_A,output_tokens_limit=_A,total_tokens_limit=_A,per_request_input_tokens_limit=_A,count_tokens_before_request=False)
def aggregate_usage(business_context:StageDiagnostics|_A,specialists:list[StageDiagnostics],synthesis:StageDiagnostics|_A,merge:StageDiagnostics|_A=_A)->TokenUsage:stages=[*([business_context]if business_context else[]),*specialists,*([merge]if merge else[]),*([synthesis]if synthesis else[])];return TokenUsage(requests=sum(stage.requests for stage in stages),input_tokens=sum(stage.input_tokens for stage in stages),output_tokens=sum(stage.output_tokens for stage in stages),total_tokens=sum(stage.total_tokens for stage in stages),cache_read_tokens=sum(stage.cache_read_tokens for stage in stages),cache_write_tokens=sum(stage.cache_write_tokens for stage in stages))