from __future__ import annotations
_A=None
import asyncio,typing as t
from vulcan.review.evidence import ReviewEvidence
from vulcan.review.integration import deduplicate_findings
from vulcan.review.orchestration.specialist import run_specialist_safely
from vulcan.review.orchestration.types import SpecialistResult
from vulcan.review.packet import ProjectEvidencePacket
from vulcan.review.schemas import DimensionFailure,DimensionKey,DimensionOutput,StageDiagnostics
from vulcan.review.utils.progress import report_stage
BATCH_SIZE=10
DIMENSION_BATCH_SIZES:dict[DimensionKey,int]={DimensionKey.SEMANTICS:3}
def batch_size_for_dimension(dimension:DimensionKey)->int:return DIMENSION_BATCH_SIZES.get(dimension,BATCH_SIZE)
def coverage_key_for_dimension(dimension:DimensionKey,project_packet:ProjectEvidencePacket)->tuple[str,...]:
	if dimension is DimensionKey.CONTRACT:return project_packet.contract_conflict_ids
	return project_packet.model_names
def make_batches(keys:tuple[str,...],size:int)->list[tuple[str,...]]:
	if not keys:return[]
	return[tuple(keys[index:index+size])for index in range(0,len(keys),size)]
def combine_batch_diagnostics(dimension:DimensionKey,diagnostics:list[StageDiagnostics])->StageDiagnostics:batch_errors=[d.error for d in diagnostics if d.error];return StageDiagnostics(stage='specialist',dimension=dimension,requests=sum(d.requests for d in diagnostics),input_tokens=sum(d.input_tokens for d in diagnostics),output_tokens=sum(d.output_tokens for d in diagnostics),total_tokens=sum(d.total_tokens for d in diagnostics),cache_read_tokens=sum(d.cache_read_tokens for d in diagnostics),cache_write_tokens=sum(d.cache_write_tokens for d in diagnostics),elapsed_seconds=max((d.elapsed_seconds for d in diagnostics),default=.0),unique_evidence_accesses=sum(d.unique_evidence_accesses for d in diagnostics),duplicate_evidence_accesses=sum(d.duplicate_evidence_accesses for d in diagnostics),malformed_evidence_requests=sum(d.malformed_evidence_requests for d in diagnostics),accepted_findings=sum(d.accepted_findings for d in diagnostics),error=f"{len(batch_errors)}/{len(diagnostics)} batches failed: "+'; '.join(batch_errors)if batch_errors else _A)
def combine_dimension_outputs(dimension:DimensionKey,outputs:list[DimensionOutput])->DimensionOutput:
	blocks:list[str]=[]
	for(index,output)in enumerate(outputs,start=1):
		body=output.body.strip()
		if not body:continue
		blocks.append(f"### Batch {index} of {len(outputs)}\n\n{body}")
	return DimensionOutput(dimension=dimension,body='\n\n'.join(blocks),findings=deduplicate_findings([finding for output in outputs for finding in output.findings]),findings_parsed=all(output.findings_parsed for output in outputs),adjudications={candidate:verdict for output in outputs for(candidate,verdict)in output.adjudications.items()})
def merge_batch_results(dimension:DimensionKey,results:list[SpecialistResult])->SpecialistResult:
	outputs=[result.output for result in results if result.output is not _A];failures=[result.failure for result in results if result.failure is not _A];diagnostics=combine_batch_diagnostics(dimension,[result.diagnostics for result in results]);notes=[note for result in results for note in result.notes]
	if not outputs:detail='; '.join(failure.detail for failure in failures)or'All batches failed.';return SpecialistResult(dimension,_A,DimensionFailure(dimension=dimension,detail=f"All {len(results)} batches failed: {detail}"),diagnostics,notes)
	partial_failure:DimensionFailure|_A=_A
	if failures:detail=f"{len(failures)} of {len(results)} batches failed; this boundary covers only part of the project: {'; '.join(failure.detail for failure in failures)}";notes.append(f"{dimension.value}: {detail}");partial_failure=DimensionFailure(dimension=dimension,detail=detail)
	return SpecialistResult(dimension,combine_dimension_outputs(dimension,outputs),partial_failure,diagnostics,notes)
async def run_specialist_batched(evidence:ReviewEvidence,project_packet:ProjectEvidencePacket,dimension:DimensionKey,upstream_artifacts:dict[str,t.Any]|_A=_A)->SpecialistResult:
	coverage_key=coverage_key_for_dimension(dimension,project_packet);batch_size=batch_size_for_dimension(dimension)
	if len(coverage_key)<=batch_size:return await run_specialist_safely(evidence,project_packet,dimension,upstream_artifacts,batch_models=_A)
	batches=make_batches(coverage_key,batch_size);report_stage(f"{dimension.value}: dispatching {len(batches)} batches");results=await asyncio.gather(*[run_specialist_safely(evidence,project_packet,dimension,upstream_artifacts,batch_models=batch)for batch in batches]);return merge_batch_results(dimension,list(results))