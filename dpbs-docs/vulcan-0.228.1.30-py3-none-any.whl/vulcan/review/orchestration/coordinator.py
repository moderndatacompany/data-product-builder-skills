from __future__ import annotations
_A=None
import asyncio,contextvars,logging,threading,time,typing as t
from vulcan.review.agents.factories import ReviewDependencyError
from vulcan.review.constraints import ReviewConstraints,build_constraints
from vulcan.review.evidence import ReviewEvidence
from vulcan.review.integration import cost_verdict,deduplicate_failures,deduplicate_findings,modeling_verdict
from vulcan.review.orchestration.business import run_business_context
from vulcan.review.orchestration.dag import run_review_dag
from vulcan.review.orchestration.diagnostics import aggregate_usage
from vulcan.review.orchestration.merge import run_finding_merge
from vulcan.review.orchestration.specialist import failed_specialist
from vulcan.review.orchestration.synthesis import run_synthesis
from vulcan.review.orchestration.types import BusinessStageResult,SpecialistResult
from vulcan.review.packet import ProjectEvidencePacket,build_project_packet,build_source_ledger
from vulcan.review.schemas import ALL_DIMENSIONS,DimensionFailure,MetadataCoverage,MetadataIssue,ReportFormat,ReviewBody,ReviewCoverage,ReviewDiagnostics,ReviewReport,ReviewStatus,StageDiagnostics
from vulcan.review.utils.progress import report_stage
from vulcan.review.utils.text import exception_detail
logger=logging.getLogger(__name__)
def run_coroutine(coroutine:t.Coroutine[t.Any,t.Any,ReviewReport])->ReviewReport:
	try:asyncio.get_running_loop()
	except RuntimeError:return asyncio.run(coroutine)
	result:list[ReviewReport]=[];error:list[BaseException]=[]
	def runner()->_A:
		try:result.append(asyncio.run(coroutine))
		except BaseException as exc:error.append(exc)
	copied_context=contextvars.copy_context();thread=threading.Thread(target=lambda:copied_context.run(runner),name='vulcan-review-coordinator');thread.start();thread.join()
	if error:raise error[0]
	return result[0]
async def run_project_review_async(evidence:ReviewEvidence,source:str,*,deterministic:list[MetadataIssue],deterministic_notice:str|_A,metadata_coverage:MetadataCoverage|_A=_A,report_format:ReportFormat=ReportFormat.MARKDOWN)->ReviewReport:
	A='Business context did not run.';started=time.monotonic();project_name=evidence.project_name();packet:ProjectEvidencePacket|_A=_A;specialist_results:list[SpecialistResult]=[];business_result=BusinessStageResult(_A,DimensionFailure(detail=A),StageDiagnostics(stage='business_context',error=A),[]);synthesis:ReviewBody|_A=_A;synthesis_diagnostics:StageDiagnostics|_A=_A;report_stage('Loading project evidence')
	try:packet=build_project_packet(evidence,source,deterministic,deterministic_notice)
	except ReviewDependencyError:raise
	except Exception as exc:detail=exception_detail(exc,prefix='Evidence preparation failed');logger.error('%s | project=%s',detail,project_name);business_result=BusinessStageResult(_A,DimensionFailure(detail=detail),StageDiagnostics(stage='evidence_preparation',error=exception_detail(exc)),[]);specialist_results=[failed_specialist(dimension,f"Skipped because evidence preparation failed: {exception_detail(exc)}")for dimension in ALL_DIMENSIONS]
	if packet is not _A:
		report_stage('Business context');business_result=await run_business_context(evidence,packet)
		if business_result.output is _A:detail=business_result.failure.detail if business_result.failure else'unknown failure';specialist_results=[failed_specialist(dimension,f"Skipped because business context failed: {detail}")for dimension in ALL_DIMENSIONS]
		else:specialist_results=await run_review_dag(evidence,packet,business_result.output)
	dimension_reviews=[result.output for result in specialist_results if result.output];failures=[result.failure for result in specialist_results if result.failure]
	if business_result.failure is not _A:failures.append(business_result.failure)
	completed=[dimension for dimension in ALL_DIMENSIONS if any(review.dimension==dimension for review in dimension_reviews)];missing=[dimension for dimension in ALL_DIMENSIONS if dimension not in completed];findings_parsed=all(review.findings_parsed for review in dimension_reviews)
	if not findings_parsed:failures.extend(DimensionFailure(dimension=review.dimension,detail=f"{review.dimension.value}: findings table could not be fully read; severity for this boundary is unknown.")for review in dimension_reviews if not review.findings_parsed)
	coverage=ReviewCoverage(completed_dimensions=completed,missing_dimensions=missing,failures=deduplicate_failures(failures));findings=deduplicate_findings([finding for review in dimension_reviews for finding in review.findings]);merge_diagnostics:StageDiagnostics|_A=_A
	if findings_parsed and len(findings)>1:report_stage('Collapsing duplicate findings');findings,merge_diagnostics=await run_finding_merge(evidence,findings,dimension_reviews)
	integration_started=time.monotonic();adjudications={candidate:verdict for review in dimension_reviews for(candidate,verdict)in review.adjudications.items()};constraints=build_constraints(packet)if packet is not _A else ReviewConstraints();review_modeling_verdict=modeling_verdict(coverage,findings,adjudications,findings_parsed=findings_parsed);review_cost_verdict=cost_verdict(coverage,findings,constraints,findings_parsed=findings_parsed);integration_diagnostics=StageDiagnostics(stage='integration',elapsed_seconds=time.monotonic()-integration_started);can_synthesize=packet is not _A and business_result.output is not _A and bool(completed)
	if can_synthesize:
		report_stage('Writing report');synthesis,synthesis_diagnostics,synthesis_failure=await run_synthesis(evidence,packet,dimension_reviews,findings,coverage,deterministic,review_modeling_verdict,review_cost_verdict,business_result.output,constraints,metadata_coverage or MetadataCoverage(),report_format)
		if synthesis_failure is not _A:coverage.failures=deduplicate_failures([*coverage.failures,synthesis_failure])
	if synthesis is _A and packet is _A and not coverage.failures:coverage.failures=deduplicate_failures([DimensionFailure(detail='Evidence packet was not produced.')])
	usage=aggregate_usage(business_result.diagnostics,[result.diagnostics for result in specialist_results],synthesis_diagnostics,merge_diagnostics);notes=[note for result in specialist_results for note in result.notes]
	if synthesis is not _A and synthesis.unresolved_citations:notes.append('Report cites artifacts absent from the evidence packet: '+', '.join(synthesis.unresolved_citations))
	if synthesis is not _A and synthesis.contradicts_cost_verdict:notes.append(f"Report endorses a cost posture the application did not grant (verdict: {review_cost_verdict.value}).")
	diagnostics=ReviewDiagnostics(packet_bytes=packet.total_bytes if packet else 0,packet_entries=len(packet.entries)if packet else 0,packet_files=packet.file_count if packet else 0,packet_models=packet.model_count if packet else 0,dag_mode='sequential',business_context=business_result.diagnostics,specialists=[result.diagnostics for result in specialist_results],merge=merge_diagnostics,integration=integration_diagnostics,synthesis=synthesis_diagnostics,supplemental_notes=notes);status=ReviewStatus.PARTIAL if coverage.is_partial else ReviewStatus.COMPLETE;elapsed=time.monotonic()-started;return ReviewReport(project_name=project_name,source=source,status=status,modeling_verdict=review_modeling_verdict,cost_verdict=review_cost_verdict,coverage=coverage,metadata_coverage=metadata_coverage or MetadataCoverage(),deterministic_notice=deterministic_notice,token_usage=usage,elapsed_seconds=elapsed,synthesis=synthesis,dimension_reviews=dimension_reviews,findings=findings,findings_parsed=findings_parsed,deterministic_issues=deterministic,diagnostics=diagnostics,evidence_sources=build_source_ledger(packet)if packet else[],business_context=business_result.output)
def run_project_review(evidence:ReviewEvidence,source:str,*,deterministic:list[MetadataIssue],deterministic_notice:t.Optional[str]=_A,metadata_coverage:t.Optional[MetadataCoverage]=_A,report_format:ReportFormat=ReportFormat.MARKDOWN)->ReviewReport:return run_coroutine(run_project_review_async(evidence,source,deterministic=deterministic,deterministic_notice=deterministic_notice,metadata_coverage=metadata_coverage,report_format=report_format))