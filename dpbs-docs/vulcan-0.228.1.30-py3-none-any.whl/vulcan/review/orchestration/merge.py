from __future__ import annotations
import json,logging
from pydantic_ai.usage import RunUsage
from vulcan.review.agents.factories import build_merge_agent
from vulcan.review.evidence import ReviewEvidence
from vulcan.review.orchestration.diagnostics import run_agent_stage,stage_diagnostics,token_usage,unrestricted_usage_limits
from vulcan.review.parse import parse_finding_merges
from vulcan.review.schemas import PRIORITY_RANK,AgentFinding,DimensionOutput,StageDiagnostics
logger=logging.getLogger(__name__)
def apply_merges(findings:list[AgentFinding],groups:list[tuple[tuple[int,...],str]])->list[AgentFinding]:
	if not groups:return findings
	canonical_by_index:dict[int,str]={};group_by_index:dict[int,tuple[int,...]]={}
	for(members,title)in groups:
		for index in members:canonical_by_index[index]=title;group_by_index[index]=members
	merged:list[AgentFinding]=[];consumed:set[int]=set()
	for(index,finding)in enumerate(findings):
		if index in consumed:continue
		members=group_by_index.get(index)
		if members is None:merged.append(finding);continue
		consumed.update(members);worst=min((findings[member]for member in members),key=lambda item:PRIORITY_RANK[item.priority.value]);merged.append(worst.model_copy(update={'title':canonical_by_index[index]}))
	return merged
async def run_finding_merge(evidence:ReviewEvidence,findings:list[AgentFinding],dimension_reviews:list[DimensionOutput])->tuple[list[AgentFinding],StageDiagnostics]:
	A='merge'
	if len(findings)<2:return findings,stage_diagnostics(A,token_usage(RunUsage()),.0)
	payload={'task':'merge_duplicate_findings','findings':[{'number':index+1,'priority':finding.priority.value,'category':finding.category.value,'model':finding.model,'finding':finding.title}for(index,finding)in enumerate(findings)],'specialist_sections':[{'boundary':review.dimension.value,'section':review.body}for review in dimension_reviews]}
	async def call(usage:RunUsage)->list[AgentFinding]:
		result=await build_merge_agent(**evidence.review_llm_kwargs()).run(json.dumps(payload,ensure_ascii=False),usage=usage,usage_limits=unrestricted_usage_limits());groups=parse_finding_merges(str(result.output),len(findings));merged=apply_merges(findings,groups)
		if groups:logger.info('Merged duplicate findings | before=%d after=%d groups=%d',len(findings),len(merged),len(groups))
		return merged
	merged,diagnostics,_=await run_agent_stage(A,call,failure_prefix='Finding merge failed',failure_log=logger.warning);return merged if merged is not None else findings,diagnostics