from __future__ import annotations
_A=None
import typing as t
from vulcan.review.schemas import DimensionFailure,DimensionKey,DimensionOutput,StageDiagnostics
class SpecialistResult(t.NamedTuple):dimension:DimensionKey;output:DimensionOutput|_A;failure:DimensionFailure|_A;diagnostics:StageDiagnostics;notes:list[str]
class BusinessStageResult(t.NamedTuple):output:str|_A;failure:DimensionFailure|_A;diagnostics:StageDiagnostics;notes:list[str]