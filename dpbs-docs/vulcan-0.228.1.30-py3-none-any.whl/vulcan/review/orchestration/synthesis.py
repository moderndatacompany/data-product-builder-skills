from __future__ import annotations
_B='templates/report-markdown.md'
_A=None
import json,logging,typing as t
from pydantic_ai.usage import RunUsage
from vulcan.review.agents.factories import build_synthesis_agent
from vulcan.review.constraints import ReviewConstraints,contradicts_cost_verdict,unresolved_citations
from vulcan.review.evidence import ReviewEvidence
from vulcan.review.metadata import metadata_issue_payload
from vulcan.review.orchestration.diagnostics import run_agent_stage,unrestricted_usage_limits
from vulcan.review.packet import ProjectEvidencePacket,build_source_ledger,control_plane_doctrine
from vulcan.review.report.ai_readiness import TIER_LABEL,ai_readiness_tier
from vulcan.review.schemas import AgentFinding,CostVerdict,DimensionFailure,DimensionOutput,MetadataCoverage,MetadataIssue,ModelingVerdict,ReportFormat,ReviewBody,ReviewCoverage,StageDiagnostics
logger=logging.getLogger(__name__)
def _severity_counts(findings:list[AgentFinding],deterministic:list[MetadataIssue])->dict[str,int]:
	counts={'blocker':0,'high':0,'medium':0,'low':0}
	for finding in findings:key=finding.priority.value;counts[key]=counts.get(key,0)+1
	for issue in deterministic:key=issue.priority.casefold();counts[key]=counts.get(key,0)+1
	return counts
def _ai_readiness(coverage:MetadataCoverage)->dict[str,t.Any]:tier=ai_readiness_tier(coverage);return{'tier':tier.value,'label':TIER_LABEL[tier],'ai_context_passing':coverage.ai_context_passing,'ai_context_total':coverage.ai_context_total,'described_fields':coverage.semantic_fields.described,'tagged_fields':coverage.semantic_fields.tagged,'total_fields':coverage.semantic_fields.total,'semantic_models':coverage.semantic_models.total}
_TEMPLATE_BY_FORMAT={ReportFormat.MARKDOWN:_B,ReportFormat.HTML:'templates/report-html.md',ReportFormat.JSON:_B}
async def run_synthesis(evidence:ReviewEvidence,packet:ProjectEvidencePacket,dimension_reviews:list[DimensionOutput],findings:list[AgentFinding],coverage:ReviewCoverage,deterministic:list[MetadataIssue],modeling_verdict:ModelingVerdict,cost_verdict:CostVerdict,business_context:str|_A,constraints:ReviewConstraints,metadata_coverage:MetadataCoverage,report_format:ReportFormat=ReportFormat.MARKDOWN)->tuple[ReviewBody|_A,StageDiagnostics,DimensionFailure|_A]:
	A='json';doctrine=control_plane_doctrine(evidence);template_path=_TEMPLATE_BY_FORMAT[report_format];payload={'task':'write_vulcan_review_report','project':packet.project_name,'source':packet.source,'report_template':evidence.read_doctrine(template_path),'application_owned_facts':constraints.prompt_block(),'verdicts':{'review_run':'partial'if coverage.is_partial else'complete','modeling_readiness':modeling_verdict.value,'cost_posture':cost_verdict.value},'scope':{'models':packet.model_count,'files':packet.file_count,'evidence_entries':len(packet.entries)},'coverage':coverage.model_dump(mode=A),'severity_counts':_severity_counts(findings,deterministic),'ai_readiness':_ai_readiness(metadata_coverage),'business_context':business_context,'specialist_sections':[{'boundary':review.dimension.value,'section':review.body}for review in dimension_reviews],'findings':[finding.model_dump(mode=A)for finding in findings],'deterministic_findings':[metadata_issue_payload(issue)for issue in deterministic],'source_ledger':[source.model_dump(mode=A)for source in build_source_ledger(packet)],'control_plane_doctrine':[{'path':entry.target,'content':entry.content}for entry in doctrine]}
	async def call(local_usage:RunUsage)->ReviewBody:
		result=await build_synthesis_agent(**evidence.review_llm_kwargs()).run(json.dumps(payload,ensure_ascii=False),usage=local_usage,usage_limits=unrestricted_usage_limits());content=str(result.output).strip()
		if not content:raise ValueError('Report writer returned an empty document.')
		unresolved=unresolved_citations(content,constraints)
		if unresolved:logger.warning('Report cites artifacts absent from the evidence packet | paths=%s',unresolved)
		contradicts_cost=contradicts_cost_verdict(content,cost_verdict.value)
		if contradicts_cost:logger.warning('Report endorses a cost posture the application did not grant | verdict=%s',cost_verdict.value)
		return ReviewBody(content=content,report_format=report_format,unresolved_citations=unresolved,contradicts_cost_verdict=contradicts_cost)
	body,diagnostics,detail=await run_agent_stage('synthesis',call,lambda:{'accepted_findings':len(findings)},failure_prefix='Report writing failed')
	if detail is not _A:return _A,diagnostics,DimensionFailure(detail=detail)
	return body,diagnostics,_A