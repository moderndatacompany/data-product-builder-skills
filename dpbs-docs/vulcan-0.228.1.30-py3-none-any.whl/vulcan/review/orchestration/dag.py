from __future__ import annotations
import typing as t
from vulcan.review.evidence import ReviewEvidence
from vulcan.review.orchestration.batching import run_specialist_batched
from vulcan.review.orchestration.specialist import failed_specialist
from vulcan.review.orchestration.types import SpecialistResult
from vulcan.review.packet import ProjectEvidencePacket
from vulcan.review.schemas import ALL_DIMENSIONS,DimensionKey
from vulcan.review.utils.progress import report_stage
_STAGE_LABELS:dict[DimensionKey,str]={DimensionKey.STRUCTURE:'Structure: mechanics, grain, edges, physical design',DimensionKey.SEMANTICS:'Semantics: exposed meaning against the data',DimensionKey.CONTRACT:'Contract: guarantees and their enforcement'}
async def run_review_dag(evidence:ReviewEvidence,project_packet:ProjectEvidencePacket,business_context:str)->list[SpecialistResult]:
	upstream:dict[str,t.Any]={'business_context':business_context};results:dict[DimensionKey,SpecialistResult]={}
	for(position,dimension)in enumerate(ALL_DIMENSIONS):
		report_stage(_STAGE_LABELS[dimension]);result=await run_specialist_batched(evidence,project_packet,dimension,upstream);results[dimension]=result
		if result.output is None:
			detail=f"Skipped because {dimension.value} did not complete."
			for skipped in ALL_DIMENSIONS[position+1:]:results[skipped]=failed_specialist(skipped,detail)
			break
		upstream[dimension.value]=result.output.model_dump(mode='json')
	return[results[dimension]for dimension in ALL_DIMENSIONS]