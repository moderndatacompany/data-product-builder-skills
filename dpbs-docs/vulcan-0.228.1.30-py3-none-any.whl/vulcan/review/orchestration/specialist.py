from __future__ import annotations
_B='specialist'
_A=None
import logging,typing as t
from pathlib import Path
from vulcan.review.agents.factories import ReviewDependencyError,build_dimension_agent
from vulcan.review.evidence import ReviewEvidence
from vulcan.review.orchestration.diagnostics import run_agent_stage,unrestricted_usage_limits
from vulcan.review.orchestration.types import SpecialistResult
from vulcan.review.packet import ProjectEvidencePacket,SpecialistContext,build_dimension_packet
from vulcan.review.parse import parse_adjudications,parse_findings
from vulcan.review.schemas import ContractAlignmentVerdict,DimensionFailure,DimensionKey,DimensionOutput,StageDiagnostics
from vulcan.review.utils.text import exception_detail
logger=logging.getLogger(__name__)
def failed_specialist(dimension:DimensionKey,detail:str)->SpecialistResult:return SpecialistResult(dimension,_A,DimensionFailure(dimension=dimension,detail=detail),StageDiagnostics(stage=_B,dimension=dimension,error=detail),[])
async def run_specialist_safely(evidence:ReviewEvidence,project_packet:ProjectEvidencePacket,dimension:DimensionKey,upstream_artifacts:dict[str,t.Any]|_A=_A,batch_models:tuple[str,...]|_A=_A)->SpecialistResult:
	try:return await run_specialist(evidence,project_packet,dimension,upstream_artifacts,batch_models)
	except ReviewDependencyError:raise
	except Exception as exc:detail=exception_detail(exc,prefix='Unexpected specialist coordinator failure');logger.error('Specialist coordinator failed | dimension=%s error=%s',dimension.value,detail);return failed_specialist(dimension,detail)
async def run_specialist(evidence:ReviewEvidence,project_packet:ProjectEvidencePacket,dimension:DimensionKey,upstream_artifacts:dict[str,t.Any]|_A=_A,batch_models:tuple[str,...]|_A=_A)->SpecialistResult:
	from pydantic_ai.usage import RunUsage;context:SpecialistContext|_A=_A;accepted_findings=0
	async def call(local_usage:RunUsage)->DimensionOutput:
		nonlocal context,accepted_findings;packet=build_dimension_packet(evidence,project_packet,dimension,upstream_artifacts,batch_models)
		if packet.coverage_batch is not _A:
			evidence_stems={Path(entry.target).stem.casefold()for entry in packet.evidence};thin_coverage=[item for item in packet.coverage_batch if item.rsplit('.',1)[-1].casefold()not in evidence_stems]
			if thin_coverage:logger.warning('Batch coverage items with no matching evidence file | dimension=%s items=%s',dimension.value,thin_coverage)
		context=SpecialistContext(evidence=evidence,packet=packet);result=await build_dimension_agent(dimension,**evidence.review_llm_kwargs()).run(packet.prompt(),deps=context,usage=local_usage,usage_limits=unrestricted_usage_limits());body=str(result.output).strip()
		if not body:raise ValueError('Specialist returned an empty section.')
		findings,parsed=parse_findings(dimension,body)
		if not parsed:context.notes.append(f"{dimension.value}: findings table could not be read; severity for this boundary is unknown.")
		adjudications=parse_adjudications(body,batch_models or project_packet.contract_conflict_ids)if dimension is DimensionKey.CONTRACT else{};unadjudicated=[candidate for(candidate,verdict)in adjudications.items()if verdict is ContractAlignmentVerdict.UNKNOWN]
		if unadjudicated:context.notes.append(f"contract: {len(unadjudicated)} supplied conflict candidate(s) were not adjudicated and are treated as unknown.")
		accepted_findings=len(findings);return DimensionOutput(dimension=dimension,body=body,findings=findings,findings_parsed=parsed,adjudications=adjudications)
	output,diagnostics,detail=await run_agent_stage(_B,call,lambda:{'dimension':dimension,'context':context,'accepted_findings':accepted_findings},failure_log=lambda msg:logger.error('Specialist result failed | dimension=%s error=%s',dimension.value,msg));notes=context.notes if context else[]
	if detail is not _A:return SpecialistResult(dimension,_A,DimensionFailure(dimension=dimension,detail=detail),diagnostics,notes)
	return SpecialistResult(dimension,output,_A,diagnostics,notes)