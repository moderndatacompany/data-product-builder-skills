from __future__ import annotations
from pydantic_ai.usage import RunUsage
from vulcan.review.agents.factories import build_business_context_agent
from vulcan.review.evidence import ReviewEvidence
from vulcan.review.orchestration.diagnostics import run_agent_stage,unrestricted_usage_limits
from vulcan.review.orchestration.types import BusinessStageResult
from vulcan.review.packet import ProjectEvidencePacket,SpecialistContext,build_business_packet
from vulcan.review.schemas import DimensionFailure
async def run_business_context(evidence:ReviewEvidence,project_packet:ProjectEvidencePacket)->BusinessStageResult:
	A=None;context:SpecialistContext|A=A
	async def call(local_usage:RunUsage)->str:nonlocal context;packet=build_business_packet(evidence,project_packet);context=SpecialistContext(evidence=evidence,packet=packet);result=await build_business_context_agent(**evidence.review_llm_kwargs()).run(packet.prompt(),deps=context,usage=local_usage,usage_limits=unrestricted_usage_limits());return result.output
	output,diagnostics,detail=await run_agent_stage('business_context',call,lambda:{'context':context},failure_prefix='Business context failed');notes=context.notes if context else[]
	if detail is not A:return BusinessStageResult(A,DimensionFailure(detail=detail),diagnostics,notes)
	return BusinessStageResult(output,A,diagnostics,notes)