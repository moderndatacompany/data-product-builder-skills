def migrate_schemas(engine_adapter,schema,**kwargs):
	if engine_adapter.dialect!='postgres':return
	runs_table=f"{schema}._runs"if schema else'_runs'
	if not engine_adapter.table_exists(runs_table):return
	engine_adapter.execute(f"\n        CREATE INDEX IF NOT EXISTS idx_runs_models_gin\n        ON {runs_table} USING GIN (models_affected)\n        ")
def migrate_rows(engine_adapter,schema,**kwargs):0