from sqlglot import exp
def migrate_schemas(engine_adapter,schema,**kwargs):
	A='params';table='_sql_history'
	if schema:table=f"{schema}.{table}"
	if not engine_adapter.table_exists(table):return
	columns=engine_adapter.columns(table)
	if A in columns:return
	engine_adapter.execute(exp.Alter(this=exp.to_table(table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column(A),kind=exp.DataType.build('jsonb',nullable=True))]))
def migrate_rows(engine_adapter,schema,**kwargs):0