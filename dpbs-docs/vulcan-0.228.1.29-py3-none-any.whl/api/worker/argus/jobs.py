from __future__ import annotations
_C='run_finished'
_B='plan_updated'
_A=None
import logging,typing as t
from datetime import timedelta
from pgqueuer.errors import DuplicateJobError
from pgqueuer.models import Job
from pydantic import BaseModel
from vulcan.core import constants as c
from api.context import EnvContextManager
from api.pool import run_blocking_fast
from api.worker import EnqueueQueueManager,WorkerQueueManager
from api.worker.argus.client import ArgusEventType,post_event
logger=logging.getLogger(__name__)
ARGUS_NOTIFY_ENTRYPOINT='argus_notify'
_DEFAULT_DELAY=timedelta(seconds=5)
MAX_RETRIES=3
_dirty:dict[str,bool]={}
class ArgusNotifyPayload(BaseModel):event_type:ArgusEventType;environment:str;plan_id:t.Optional[str]=_A;run_id:t.Optional[str]=_A;sequence:int=0;retry_count:int=0
def _dirty_key(event_type:str,environment:str)->str:return f"{event_type}:{environment}"
def _is_prod(environment:str)->bool:return environment==c.PROD
def _dedupe_key(payload:ArgusNotifyPayload)->str:
	parts=[ARGUS_NOTIFY_ENTRYPOINT,payload.event_type,payload.environment]
	if payload.event_type==_B:
		parts.append(f"plan:{payload.plan_id or''}")
		if payload.retry_count:parts.append(str(payload.retry_count))
	else:parts.append(str(payload.sequence));parts.append(str(payload.retry_count))
	return':'.join(parts)
async def _enqueue(qm:EnqueueQueueManager,payload:ArgusNotifyPayload,*,delay:timedelta,dirty_on_duplicate:bool)->t.Any:
	if not _is_prod(payload.environment):return
	try:return await qm.queries.enqueue([ARGUS_NOTIFY_ENTRYPOINT],[payload.model_dump_json().encode('utf-8')],execute_after=[delay],dedupe_key=[_dedupe_key(payload)])
	except DuplicateJobError:
		if dirty_on_duplicate:_dirty[_dirty_key(payload.event_type,payload.environment)]=True;logger.debug('Argus %s already pending/running for %s; dirty flag set',payload.event_type,payload.environment)
		else:logger.debug('Argus %s already pending/running for %s; dropping duplicate',payload.event_type,payload.environment)
		return
async def enqueue_argus_plan_updated(qm:EnqueueQueueManager,environment:str,*,plan_id:t.Optional[str],delay:timedelta=_DEFAULT_DELAY,retry_count:int=0)->t.Any:
	if not plan_id:logger.warning('Skipping Argus plan_updated: env=%s reason=no_plan_id',environment);return
	return await _enqueue(qm,ArgusNotifyPayload(event_type=_B,environment=environment,plan_id=plan_id,retry_count=retry_count),delay=delay,dirty_on_duplicate=False)
async def enqueue_argus_run_finished(qm:EnqueueQueueManager,environment:str,*,run_id:t.Optional[str]=_A,delay:timedelta=_DEFAULT_DELAY,sequence:int=0,retry_count:int=0)->t.Any:return await _enqueue(qm,ArgusNotifyPayload(event_type=_C,environment=environment,run_id=run_id,sequence=sequence,retry_count=retry_count),delay=delay,dirty_on_duplicate=True)
def register_argus_entrypoints(qm:WorkerQueueManager,manager:EnvContextManager,qm_enqueue:EnqueueQueueManager)->_A:
	@qm.entrypoint(ARGUS_NOTIFY_ENTRYPOINT,concurrency_limit=1)
	async def handle_argus_notify(job:Job)->_A:
		payload=ArgusNotifyPayload.model_validate_json((job.payload or b'{}').decode('utf-8'));env=payload.environment;event_type=payload.event_type;cfg=manager.context.config.argus
		if not cfg or not cfg.enabled:logger.debug('Skipping Argus %s: reason=disabled',event_type);return
		env_ctx=manager.get_env_context(env);tenant=getattr(env_ctx,'tenant','');product_name=getattr(env_ctx,'product','')
		if not tenant or not product_name:logger.warning('Skipping Argus %s: env=%s reason=missing_tenant_or_product',event_type,env);return
		dispatch_error:BaseException|_A=_A
		try:await run_blocking_fast(post_event,cfg,event_type=event_type,tenant=tenant,product_name=product_name,run_id=payload.run_id)
		except Exception as exc:dispatch_error=exc
		if dispatch_error is not _A:
			if payload.retry_count<MAX_RETRIES:
				backoff=_DEFAULT_DELAY*2**payload.retry_count
				if event_type==_B:await enqueue_argus_plan_updated(qm_enqueue,env,plan_id=payload.plan_id,delay=backoff,retry_count=payload.retry_count+1)
				else:await enqueue_argus_run_finished(qm_enqueue,env,run_id=payload.run_id,delay=backoff,sequence=payload.sequence,retry_count=payload.retry_count+1)
				logger.warning('Argus %s failed, retry %d scheduled: %s',event_type,payload.retry_count+1,dispatch_error);return
			logger.error('Argus %s exhausted %d retries: %s',event_type,MAX_RETRIES,dispatch_error);return
		if event_type==_C and _dirty.pop(_dirty_key(event_type,env),False):await enqueue_argus_run_finished(qm_enqueue,env,run_id=payload.run_id,delay=timedelta(0),sequence=payload.sequence+1,retry_count=0)