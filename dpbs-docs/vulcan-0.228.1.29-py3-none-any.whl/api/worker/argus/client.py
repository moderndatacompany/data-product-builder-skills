from __future__ import annotations
_B='product_name'
_A='event_type'
import logging,typing as t
from datetime import datetime,timezone
import requests
from vulcan.core.config.argus import ArgusConfig
logger=logging.getLogger(__name__)
ArgusEventType=t.Literal['plan_updated','run_finished']
def build_events_url(url:str,tenant:str)->str:return f"{url.rstrip('/')}/api/v1/tenants/{tenant}/events"
def resolve_vulcan_base_url(cfg:ArgusConfig)->str:return cfg.vulcan_base_url.strip().rstrip('/')
def build_product_url(base_url:str,tenant:str,product_name:str)->str:return f"{base_url.rstrip('/')}/vulcan/tenants/{tenant}/data-products/{tenant}-{product_name}"
def build_event_body(*,event_type:ArgusEventType,base_url:str,tenant:str,product_name:str,run_id:t.Optional[str],triggered_at:t.Optional[str]=None)->dict[str,t.Any]:
	body:dict[str,t.Any]={_A:event_type,_B:product_name,'base_url':build_product_url(base_url,tenant,product_name),'triggered_at':triggered_at or datetime.now(timezone.utc).isoformat()}
	if run_id:body['run_id']=run_id
	return body
def post_event(cfg:ArgusConfig,*,event_type:ArgusEventType,tenant:str,product_name:str,run_id:t.Optional[str]=None)->dict[str,t.Any]:token=cfg.token.get_secret_value()if cfg.token else'';url=build_events_url(cfg.url,tenant);body=build_event_body(event_type=event_type,base_url=resolve_vulcan_base_url(cfg),tenant=tenant,product_name=product_name,run_id=run_id);response=requests.post(url,json=body,headers={'Authorization':f"Bearer {token}",'Content-Type':'application/json'},timeout=cfg.timeout,verify=cfg.verify_ssl);response.raise_for_status();logger.info('Argus event delivered: event_type=%s tenant=%s product=%s run_id=%s status=%s',event_type,tenant,product_name,run_id,response.status_code);return{_A:event_type,'tenant':tenant,_B:product_name}