from __future__ import annotations
def normalize_token(value:str)->str:return value.strip().strip('"`').casefold()
def first_paragraph(value:str)->str:return value.strip().split('\n\n',1)[0]
def exception_detail(exc:Exception,*,prefix:str='')->str:suffix=f"{type(exc).__name__}: {exc}";return f"{prefix}: {suffix}"if prefix else suffix