from __future__ import annotations
_A=None
import contextvars,typing as t
StageCallback=t.Callable[[str],_A]
_stage_callback:contextvars.ContextVar[t.Optional[StageCallback]]=contextvars.ContextVar('vulcan_review_stage_callback',default=_A)
def report_stage(message:str)->_A:
	callback=_stage_callback.get()
	if callback is not _A:callback(message)
def stage_callback_context(callback:t.Optional[StageCallback])->contextvars.Token:return _stage_callback.set(callback)
def reset_stage_callback(token:contextvars.Token)->_A:_stage_callback.reset(token)