from __future__ import annotations
import typing as t
T=t.TypeVar('T')
K=t.TypeVar('K',bound=t.Hashable)
def dedupe_by_key(items:list[T],key_fn:t.Callable[[T],K],merge:t.Optional[t.Callable[[T,T],T]]=None)->list[T]:
	merged:dict[K,T]={}
	for item in items:
		key=key_fn(item);existing=merged.get(key)
		if existing is None:merged[key]=item
		elif merge is not None:merged[key]=merge(existing,item)
	return list(merged.values())