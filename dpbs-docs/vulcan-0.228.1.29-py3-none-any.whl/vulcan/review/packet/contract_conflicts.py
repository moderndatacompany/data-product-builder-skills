from __future__ import annotations
_G='evidence_id'
_F='value'
_E='line'
_D='artifact'
_C='normalized_value'
_B='operator'
_A='subject'
import hashlib,re,typing as t
from vulcan.review.evidence import BUSINESS_CONTEXT_FILES
from vulcan.review.schemas import EvidenceEntry,EvidenceKind
_PREDICATE_RE=re.compile('(?P<subject>[A-Za-z_][A-Za-z0-9_.$]*)\\s*(?P<operator><>|!=|=|\\bIN\\b)\\s*(?P<value>\\([^\\n)]*\\)|\'[^\'\\n]*\'|\\"[^\\"\\n]*\\"|[-+]?\\d+(?:\\.\\d+)?)',re.IGNORECASE)
_CONTRACT_CUE_RE=re.compile('\\b(?:contract|filter|population|resolved|require(?:d|s)?|must|where|definition|status|include(?:d|s)?|exclude(?:d|s)?)\\b',re.IGNORECASE)
_CONTRACT_FILES={*BUSINESS_CONTEXT_FILES,'agreement.md','usage.yaml','usage.yml'}
def contract_conflicts(entries:list[EvidenceEntry])->list[dict[str,t.Any]]:
	declared:list[dict[str,t.Any]]=[];executable:list[dict[str,t.Any]]=[]
	for entry in entries:
		if entry.kind!=EvidenceKind.FILE.value:continue
		predicates=_predicates(entry,declared=entry.target in _CONTRACT_FILES)
		if entry.target in _CONTRACT_FILES:declared.extend(predicates)
		elif entry.target.casefold().endswith(('.sql','.yaml','.yml')):executable.extend(predicates)
	conflicts:list[dict[str,t.Any]]=[];grouped:dict[tuple[str,str,str,str],tuple[dict[str,t.Any],list[dict[str,t.Any]]]]={}
	for contract in declared:
		for implementation in executable:
			if contract[_A]!=implementation[_A]:continue
			if contract[_B]!=implementation[_B]:continue
			if contract[_C]==implementation[_C]:continue
			identity=contract[_A],contract[_B],contract[_C],implementation[_C];grouped.setdefault(identity,(contract,[]))[1].append(implementation)
	for(identity,(contract,implementations))in sorted(grouped.items()):
		unique_implementations:dict[tuple[str,int,str],dict[str,t.Any]]={}
		for implementation in implementations:unique_implementations.setdefault((implementation[_D],implementation[_E],implementation[_C]),implementation)
		implementation=next(iter(unique_implementations.values()));candidate_id='contract-'+hashlib.sha256('\x00'.join(str(part)for part in identity).encode('utf-8')).hexdigest()[:16];conflicts.append({'candidate_id':candidate_id,_A:contract[_A],_B:contract[_B],'declared':_public_predicate(contract),'implementation':_public_predicate(implementation),'implementation_instances':[_public_predicate(item)for item in unique_implementations.values()],'instruction':'Adjudicate whether the differently scoped literal predicates represent a material gap between stated intent and executable behavior. Executable code is ground truth for current behavior.'})
	return conflicts
def _predicates(entry:EvidenceEntry,*,declared:bool=False)->list[dict[str,t.Any]]:
	A='.md';predicates:list[dict[str,t.Any]]=[];lines=entry.content.splitlines()
	if entry.target.casefold().endswith('.sql'):query_start=next((index for(index,line)in enumerate(lines)if re.match('^\\s*(?:WITH|SELECT)\\b',line,flags=re.IGNORECASE)),len(lines))
	else:query_start=0
	in_code_fence=False
	for(line_number,line)in enumerate(lines[query_start:],start=query_start+1):
		if declared and entry.target.casefold().endswith(A)and line.lstrip().startswith('```'):in_code_fence=not in_code_fence;continue
		if declared and entry.target.casefold().endswith(A)and not in_code_fence and _CONTRACT_CUE_RE.search(line)is None:continue
		for match in _PREDICATE_RE.finditer(line):subject=match.group(_A).rsplit('.',1)[-1].upper();operator=match.group(_B).upper().replace('!=','<>');value=match.group(_F).strip();predicates.append({_A:subject,_B:operator,_F:value,_C:re.sub('\\s+','',value).casefold(),_D:entry.target,_E:line_number,_G:entry.evidence_id,'text':line.strip()})
	return predicates
def _public_predicate(predicate:dict[str,t.Any])->dict[str,t.Any]:return{key:predicate[key]for key in(_D,_E,_G,'text',_F)}