from __future__ import annotations
_T='source_path'
_S='environment_notice'
_R='metrics'
_Q='external_dependency_count'
_P='models'
_O='product'
_N='candidate_id'
_M='deterministic_notice'
_L='deterministic_findings'
_K='doctrine'
_J='contract_conflict_ids'
_I='name'
_H='\n\n'
_G='external'
_F='project'
_E='utf-8'
_D='contract_conflicts'
_C=False
_B='json'
_A=None
import hashlib,json,typing as t
from dataclasses import dataclass,field
from functools import lru_cache
from pathlib import Path
from pydantic import BaseModel,ConfigDict
from pydantic import Field as PydanticField
from vulcan.core.config.common import ALL_CONFIG_FILENAMES,USAGE_FILENAMES
from vulcan.review.doctrine_loader import BUSINESS_CONTEXT_SKILL,DIMENSION_REFERENCES,ORCHESTRATOR_REFERENCES,SKILL_REFERENCES,SPECIALIST_TEMPLATE
from vulcan.review.evidence import BUSINESS_CONTEXT_FILES,ReviewEvidence
from vulcan.review.metadata import metadata_issue_payload
from vulcan.review.packet.context_snapshot import build_context_snapshot
from vulcan.review.packet.contract_conflicts import contract_conflicts
from vulcan.review.plan_state import build_plan_state
from vulcan.review.schemas import DimensionKey,EvidenceEntry,EvidenceKind,MetadataIssue,ProjectContextSnapshot
VULCAN_PRIMITIVES='vulcan-primitives.md'
POLICIES_DIR='policies'
_NON_PHYSICAL_MODEL_KINDS=frozenset({'SEMANTIC','METRIC'})
MAX_PACKET_BYTES=3000000
@lru_cache(maxsize=1)
def _cached_section_template(doctrine_root:Path)->str:
	path=(doctrine_root/SPECIALIST_TEMPLATE).resolve()
	if not path.is_relative_to(doctrine_root)or not path.is_file():return f"Unavailable doctrine file: {SPECIALIST_TEMPLATE}"
	return path.read_text(encoding=_E,errors='replace')
def _section_template(evidence:ReviewEvidence)->str:return _cached_section_template(evidence.doctrine_root)
class ProjectEvidencePacket(BaseModel):
	model_config=ConfigDict(frozen=True);project_name:str;source:str;context_snapshot:ProjectContextSnapshot=PydanticField(default_factory=lambda:ProjectContextSnapshot(product={_I:''}));entries:tuple[EvidenceEntry,...];deterministic_findings:tuple[dict[str,t.Any],...]=();deterministic_notice:str|_A=_A;file_count:int=0;model_count:int=0;model_names:tuple[str,...]=();reference_model_names:tuple[str,...]=();physical_model_names:tuple[str,...]=();sql_model_names:tuple[str,...]=();contract_conflict_ids:tuple[str,...]=();total_bytes:int=0;plan_state:str=''
	def prompt_body(self)->str:
		manifest=[{'id':entry.evidence_id,'kind':entry.kind,'target':entry.target,'sha256':entry.sha256,'bytes':len(entry.content.encode(_E))}for entry in self.entries];sections=['# Immutable project evidence packet',json.dumps({_F:self.project_name,'source':self.source,'file_count':self.file_count,'model_count':self.model_count,'model_names':self.model_names,'reference_model_names':self.reference_model_names,'physical_model_names':self.physical_model_names,'sql_model_names':self.sql_model_names,_J:self.contract_conflict_ids,'manifest':manifest,_L:list(self.deterministic_findings),_M:self.deterministic_notice},ensure_ascii=_C,indent=2)]
		for entry in self.entries:sections.extend([f"## Evidence {entry.evidence_id}",f"Kind: {entry.kind}\nTarget: {entry.target}\nSHA-256: {entry.sha256}",_prompt_entry_content(entry)])
		return _H.join(sections)
class DimensionEvidencePacket(BaseModel):
	model_config=ConfigDict(frozen=True);dimension:DimensionKey;project:ProjectEvidencePacket;evidence:tuple[EvidenceEntry,...];context_summary:dict[str,t.Any];doctrine:tuple[EvidenceEntry,...];upstream_artifacts:dict[str,t.Any]=PydanticField(default_factory=dict);coverage_batch:tuple[str,...]|_A=_A;required_coverage:tuple[str,...]=();section_template:str='';plan_state:str=''
	def prompt(self)->str:evidence=_H.join(f"## Evidence {entry.evidence_id}\nKind: {entry.kind}\nTarget: {entry.target}\n\n{_prompt_entry_content(entry)}"for entry in self.evidence);doctrine=_H.join(f"## Doctrine {entry.target}\n\n{entry.content}"for entry in self.doctrine);upstream='\n\n# Authoritative upstream artifacts\n\n'+json.dumps(self.upstream_artifacts,ensure_ascii=_C,indent=2)if self.upstream_artifacts else'';template=f"\n\n# Section template\n\n{self.section_template}"if self.section_template else'';plan_state=f"\n\n{self.plan_state}"if self.plan_state else'';return f"Review boundary: {self.dimension.value}\n\nThe application has already collected the complete review evidence below. Evaluate it once and return your section as Markdown following the section template. Do not rediscover, relist, or reread evidence already present. Use the supplemental evidence tool only when you can state a concrete missing gap.\n\n"+self._coverage_checklist()+'# Loaded-context technical summary\n\n'+json.dumps(self.context_summary,ensure_ascii=_C,indent=2)+'\n\n# Complete authored project evidence\n\n'+(evidence or'No authored project files were available.')+upstream+plan_state+f"\n\n# Assigned doctrine\n\n{doctrine}"+template+self._coverage_reminder()
	def _coverage_checklist(self)->str:
		if not self.required_coverage:return''
		numbered='\n'.join(f"{index}. {name}"for(index,name)in enumerate(self.required_coverage,1));return f"""# Scope for this call

Cover every item below. This list is exhaustive and authoritative: do not skip an item because it looks like a trivial pass-through view, a bronze or raw table, or a non-SQL semantic model. If an item is sound, say so in your assessment prose rather than omitting it.

{numbered}
"""
	def _coverage_reminder(self)->str:
		if not self.required_coverage:return''
		return f"\n\n# Before you respond\n\nYou were given {len(self.required_coverage)} item(s) to cover. Check that your assessment prose accounts for each of them, and that your findings table follows the section template exactly -- its columns, priority values, and category values are parsed by the application."
class BusinessEvidencePacket(BaseModel):
	model_config=ConfigDict(frozen=True);project:ProjectEvidencePacket;evidence:tuple[EvidenceEntry,...];context_summary:dict[str,t.Any];doctrine:tuple[EvidenceEntry,...]
	def prompt(self)->str:evidence=_H.join(f"## Evidence {entry.evidence_id}\nKind: {entry.kind}\nTarget: {entry.target}\n\n{_prompt_entry_content(entry)}"for entry in self.evidence);doctrine=_H.join(f"## Doctrine {entry.target}\n\n{entry.content}"for entry in self.doctrine);return'Establish the authoritative business context and declared product contract. Return the typed business context once; do not issue technical findings. This is the complete business-context evidence view. Technical implementation evidence remains available to downstream specialists and through a concrete supplemental request; do not infer executable behavior from omitted SQL.\n\n# Loaded-context business summary\n\n'+json.dumps(self.context_summary,ensure_ascii=_C,indent=2)+'\n\n# Authored business evidence\n\n'+(evidence or'No authored business-context files were available.')+f"\n\n# Assigned doctrine\n\n{doctrine}"
@dataclass
class SpecialistContext:
	evidence:ReviewEvidence;packet:DimensionEvidencePacket|BusinessEvidencePacket;supplied_keys:set[tuple[str,str]]=field(default_factory=set);accessed_keys:set[tuple[str,str]]=field(default_factory=set);duplicate_accesses:int=0;malformed_requests:int=0;notes:list[str]=field(default_factory=list)
	def __post_init__(self)->_A:
		self.supplied_keys={(entry.kind,entry.target)for entry in(*self.packet.evidence,*self.packet.doctrine)if not entry.omitted}
		if isinstance(self.packet,BusinessEvidencePacket):return
		snapshot=self.packet.project.context_snapshot;self.supplied_keys.update((EvidenceKind.MODEL_METADATA.value,model.name)for model in snapshot.models);self.supplied_keys.update((EvidenceKind.GRAPH.value,model.name)for model in snapshot.models);self.supplied_keys.update({(EvidenceKind.GRAPH.value,_F)})
	@property
	def unique_accesses(self)->int:return len(self.accessed_keys)
	def request(self,kind:EvidenceKind,target:str,evidence_gap:str)->str:
		target=target.strip()
		if not evidence_gap.strip():return self._malformed('A stated evidence gap is required.')
		normalized_target=self._validate_target(kind,target)
		if normalized_target is _A:return self._malformed(f"Invalid {kind.value} target: {target!r}.")
		key=kind.value,normalized_target
		if key in self.supplied_keys or key in self.accessed_keys:self.duplicate_accesses+=1;reference=_stable_reference(kind.value,normalized_target);note=f"Duplicate supplemental evidence request: {kind.value}:{normalized_target}";self.notes.append(note);return f"Evidence already supplied in the packet; use reference {reference}."
		content=self._load(kind,normalized_target);self.accessed_keys.add(key);reference=_stable_reference(kind.value,normalized_target);return f"Evidence reference: {reference}\n\n{content}"
	def _validate_target(self,kind:EvidenceKind,target:str)->str|_A:
		if not target:return
		if kind is EvidenceKind.FILE:return target if target in self.evidence.safe_files.files else _A
		if kind in(EvidenceKind.MODEL_METADATA,EvidenceKind.GRAPH):return target if target in self.evidence.model_names()else _A
		return target
	def _load(self,kind:EvidenceKind,target:str)->str:
		if kind is EvidenceKind.FILE:return _number_file_content(self.evidence.file_content(target))
		if kind is EvidenceKind.MODEL_METADATA:return self.evidence.model_metadata(target)
		if kind is EvidenceKind.GRAPH:return self.evidence.graph(target)
		return self.evidence.search(target)
	def _malformed(self,detail:str)->str:self.malformed_requests+=1;self.notes.append(detail);return f"Malformed supplemental evidence request: {detail}"
def build_project_packet(evidence:ReviewEvidence,source:str,deterministic:list[MetadataIssue],deterministic_notice:str|_A)->ProjectEvidencePacket:
	context_snapshot=build_context_snapshot(evidence.context,evidence.environment);plan_state=build_plan_state(evidence.context,evidence.environment);entries:list[EvidenceEntry]=[];packet_bytes=0
	for relative_path in evidence.safe_files.files:
		omitted=packet_bytes>=MAX_PACKET_BYTES
		if omitted:content=f"[OMITTED: total evidence packet budget ({MAX_PACKET_BYTES:,} bytes) reached; request this file explicitly via the file evidence tool if needed.]"
		else:content=evidence.file_content(relative_path)
		entries.append(_entry(EvidenceKind.FILE.value,relative_path,content,omitted=omitted));packet_bytes+=len(content.encode(_E))
	entries.append(_entry('context_snapshot',_F,context_snapshot.model_dump_json(indent=2)));review_models=tuple(model for model in context_snapshot.models if model.source_type!=_G);reference_models=tuple(model for model in context_snapshot.models if model.source_type==_G);model_names=tuple(model.name for model in review_models);physical_models=[model.name for model in review_models if model.kind.upper()not in _NON_PHYSICAL_MODEL_KINDS];conflicts=contract_conflicts(entries);entries.append(_entry(_D,_F,json.dumps(conflicts,ensure_ascii=_C,indent=2)));deterministic_payload=tuple(metadata_issue_payload(issue)for issue in deterministic);total_bytes=sum(len(entry.content.encode(_E))for entry in entries);return ProjectEvidencePacket(project_name=evidence.project_name(),source=source,context_snapshot=context_snapshot,entries=tuple(entries),deterministic_findings=deterministic_payload,deterministic_notice=deterministic_notice,file_count=len(evidence.safe_files.files),model_count=len(model_names),model_names=model_names,reference_model_names=tuple(model.name for model in reference_models),physical_model_names=tuple(sorted(physical_models,key=str.casefold)),sql_model_names=tuple(sorted((model.name for model in review_models if model.parsed_query),key=str.casefold)),contract_conflict_ids=tuple(item[_N]for item in conflicts),total_bytes=total_bytes,plan_state=plan_state.prompt_block())
_MODEL_KEYED_DIMENSIONS=frozenset({DimensionKey.STRUCTURE,DimensionKey.SEMANTICS})
def build_dimension_packet(evidence:ReviewEvidence,project:ProjectEvidencePacket,dimension:DimensionKey,upstream_artifacts:dict[str,t.Any]|_A=_A,batch_models:tuple[str,...]|_A=_A)->DimensionEvidencePacket:
	paths=*DIMENSION_REFERENCES[dimension],VULCAN_PRIMITIVES;doctrine=tuple(_entry(_K,path,evidence.read_doctrine(path))for path in paths)
	if batch_models is not _A and dimension in _MODEL_KEYED_DIMENSIONS:selected=_batch_scoped_evidence(project,batch_models);context_summary=_technical_context_summary(project,batch_models=batch_models)
	elif batch_models is not _A and dimension is DimensionKey.CONTRACT:selected=_batch_scoped_evidence_for_conflicts(project,batch_models);context_summary=_technical_context_summary(project)
	else:selected=tuple(entry for entry in project.entries if entry.kind in{EvidenceKind.FILE.value,_D});context_summary=_technical_context_summary(project)
	required_coverage=_required_coverage(dimension,project,batch_models);return DimensionEvidencePacket(dimension=dimension,project=project,evidence=selected,context_summary=context_summary,doctrine=doctrine,upstream_artifacts=upstream_artifacts or{},coverage_batch=batch_models,required_coverage=required_coverage,section_template=_section_template(evidence),plan_state=project.plan_state if dimension is DimensionKey.CONTRACT else'')
def _required_coverage(dimension:DimensionKey,project:ProjectEvidencePacket,batch_models:tuple[str,...]|_A)->tuple[str,...]:
	if dimension is DimensionKey.CONTRACT:return batch_models if batch_models is not _A else project.contract_conflict_ids
	return batch_models if batch_models is not _A else project.model_names
def _always_include_files(project:ProjectEvidencePacket)->set[str]:return{*BUSINESS_CONTEXT_FILES,*ALL_CONFIG_FILENAMES,*USAGE_FILENAMES,'agreement.md',*_policy_targets(project)}
def _policy_targets(project:ProjectEvidencePacket)->set[str]:return{entry.target for entry in project.entries if entry.kind==EvidenceKind.FILE.value and entry.target.startswith(f"{POLICIES_DIR}/")}
def _batch_scoped_evidence(project:ProjectEvidencePacket,batch_models:tuple[str,...])->tuple[EvidenceEntry,...]:
	short_names={name.rsplit('.',1)[-1].casefold()for name in batch_models};source_paths={model.source_path for model in project.context_snapshot.models if model.name in batch_models and model.source_path};always_include=_always_include_files(project);result=[]
	for entry in project.entries:
		if entry.kind==_D:result.append(entry)
		elif entry.kind==EvidenceKind.FILE.value:
			if entry.target in source_paths or entry.target in always_include or Path(entry.target).stem.casefold()in short_names:result.append(entry)
	return tuple(result)
def _conflicts_by_id(project:ProjectEvidencePacket)->dict[str,dict[str,t.Any]]:
	for entry in project.entries:
		if entry.kind==_D:conflicts=json.loads(entry.content);return{conflict[_N]:conflict for conflict in conflicts}
	return{}
def _conflict_artifacts(conflict:dict[str,t.Any])->set[str]:
	A='artifact';artifacts:set[str]=set()
	for key in('declared','implementation'):
		predicate=conflict.get(key)or{}
		if predicate.get(A):artifacts.add(predicate[A])
	for instance in conflict.get('implementation_instances',[]):
		if instance.get(A):artifacts.add(instance[A])
	return artifacts
def _batch_scoped_evidence_for_conflicts(project:ProjectEvidencePacket,conflict_ids:tuple[str,...])->tuple[EvidenceEntry,...]:
	conflicts_by_id=_conflicts_by_id(project);batch_conflicts=[conflicts_by_id[cid]for cid in conflict_ids if cid in conflicts_by_id];artifacts:set[str]=set()
	for conflict in batch_conflicts:artifacts.update(_conflict_artifacts(conflict))
	always_include=_always_include_files(project);result=[]
	for entry in project.entries:
		if entry.kind==_D:result.append(_entry(_D,_F,json.dumps(batch_conflicts,ensure_ascii=_C,indent=2)))
		elif entry.kind==EvidenceKind.FILE.value and(entry.target in artifacts or entry.target in always_include):result.append(entry)
	return tuple(result)
def _technical_context_summary(project:ProjectEvidencePacket,batch_models:tuple[str,...]|_A=_A)->dict[str,t.Any]:
	A='parsed_query';snapshot=project.context_snapshot
	if batch_models is not _A:batch_set=set(batch_models);models_list=[model.model_dump(mode=_B,exclude={A})for model in snapshot.models if model.source_type!=_G and model.name in batch_set];deterministic_findings=[finding for finding in project.deterministic_findings if finding.get('model')in batch_set]
	else:models_list=[model.model_dump(mode=_B,exclude={A})for model in snapshot.models if model.source_type!=_G];deterministic_findings=list(project.deterministic_findings)
	return{_F:project.project_name,_O:snapshot.product.model_dump(mode=_B),_P:models_list,'external_dependencies':[{_I:model.name,_T:model.source_path}for model in snapshot.models if model.source_type==_G],_Q:len(project.reference_model_names),_R:[metric.model_dump(mode=_B)for metric in snapshot.metrics],'audits':[audit.model_dump(mode=_B)for audit in snapshot.audits],'tests':[test.model_dump(mode=_B)for test in snapshot.tests],'graph':snapshot.graph.model_dump(mode=_B),'info':snapshot.info,'environment_metadata':snapshot.environment_metadata.model_dump(mode=_B)if snapshot.environment_metadata else _A,_S:snapshot.environment_notice,_L:deterministic_findings,_M:project.deterministic_notice,_J:list(project.contract_conflict_ids)}
def build_business_packet(evidence:ReviewEvidence,project:ProjectEvidencePacket)->BusinessEvidencePacket:A='semantic';context_files=_always_include_files(project);semantic_paths={model.source_path for model in project.context_snapshot.models if model.source_type in{A,'metric'}and model.source_path};selected=tuple(entry for entry in project.entries if entry.kind==EvidenceKind.FILE.value and(entry.target in context_files or entry.target in semantic_paths)or entry.kind==_D);snapshot=project.context_snapshot;summary={_O:snapshot.product.model_dump(mode=_B),_P:[{_I:model.name,_T:model.source_path,'source_type':model.source_type,'owner':model.owner,'description':model.description,'tags':model.tags,'terms':model.terms,'grains':model.grains,A:model.semantic.model_dump(mode=_B)if model.semantic else _A}for model in snapshot.models if model.source_type!=_G],_Q:len(project.reference_model_names),_R:[metric.model_dump(mode=_B)for metric in snapshot.metrics],_J:list(project.contract_conflict_ids),_S:snapshot.environment_notice};paths=SKILL_REFERENCES[BUSINESS_CONTEXT_SKILL];doctrine=tuple(_entry(_K,path,evidence.read_doctrine(path))for path in paths);return BusinessEvidencePacket(project=project,evidence=selected,context_summary=summary,doctrine=doctrine)
def control_plane_doctrine(evidence:ReviewEvidence)->tuple[EvidenceEntry,...]:return tuple(_entry(_K,path,evidence.read_doctrine(path))for path in ORCHESTRATOR_REFERENCES)
def _entry(kind:str,target:str,content:str,*,omitted:bool=_C)->EvidenceEntry:digest=hashlib.sha256(content.encode(_E)).hexdigest();return EvidenceEntry(evidence_id=_stable_reference(kind,target),kind=kind,target=target,sha256=digest,content=content,omitted=omitted)
def _prompt_entry_content(entry:EvidenceEntry)->str:
	if entry.kind!=EvidenceKind.FILE.value:return entry.content
	return _number_file_content(entry.content)
def _number_file_content(content:str)->str:lines=content.splitlines()or[''];return'\n'.join(f"{number:>6} | {line}"for(number,line)in enumerate(lines,1))
def _stable_reference(kind:str,target:str)->str:digest=hashlib.sha256(f"{kind}\x00{target}".encode(_E)).hexdigest()[:16];return f"ev-{digest}"