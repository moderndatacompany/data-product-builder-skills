from __future__ import annotations
import re,typing as t
from vulcan.review.evidence import BUSINESS_CONTEXT_FILES
from vulcan.review.schemas import EvidenceEntry,EvidenceKind,SourceConfidence,SourceLedgerEntry
if t.TYPE_CHECKING:from vulcan.review.packet.builder import ProjectEvidencePacket
_FAILURE_MARKER=re.compile('\\b(?:failed|unavailable|could not be completed)\\b',re.IGNORECASE)
_UNAVAILABLE_PREFIX=re.compile('^(?:failed|unavailable)\\b',re.IGNORECASE)
def build_source_ledger(packet:ProjectEvidencePacket)->list[SourceLedgerEntry]:return[_source_ledger_entry(entry)for entry in packet.entries]
def _source_ledger_entry(entry:EvidenceEntry)->SourceLedgerEntry:
	A='Project source code';source=entry.target if entry.kind==EvidenceKind.FILE.value else f"{entry.kind}:{entry.target}"
	if entry.kind==EvidenceKind.FILE.value:
		if entry.target in BUSINESS_CONTEXT_FILES or entry.target in{'agreement.md','usage.yaml','usage.yml'}:source_type='Stated business intent';established='Stated model intent, semantics, limitations, or operating context.'
		elif entry.target.startswith('tests/')or entry.target.startswith('checks/'):source_type='Test';established='Declared validation and quality coverage.'
		else:source_type=A;established='Project implementation or executable metadata.'
	elif entry.kind=='physical_metadata':source_type='Data profile/query';established='Live framework-derived diagnostic or environment metadata.'
	else:source_type=A;established='Application-derived project inventory, metadata, or dependency evidence.'
	stripped=entry.content.lstrip();unavailable=bool(_UNAVAILABLE_PREFIX.match(stripped));limited=not unavailable and _FAILURE_MARKER.search(entry.content)is not None;return SourceLedgerEntry(evidence_id=entry.evidence_id,source=source,source_type=source_type,sha256=entry.sha256,what_established=established,confidence=SourceConfidence.UNAVAILABLE if unavailable else SourceConfidence.LOW if limited else SourceConfidence.HIGH)