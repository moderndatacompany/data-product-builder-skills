from __future__ import annotations
_F='references'
_E='description'
_D='project'
_C=False
_B='name'
_A=None
import json,typing as t
from pathlib import Path
from vulcan.core.model import SemanticModel,SqlModel
from vulcan.review.evidence import ensure_context_loaded,relative_or_name
from vulcan.review.schemas import AuditEvidence,ColumnEvidence,DependencyGraphEvidence,EnvironmentMetadataEvidence,MetricEvidence,ModelEvidence,ProductContract,ProjectContextSnapshot,SemanticEvidence,TestEvidence
if t.TYPE_CHECKING:from vulcan.core.context import Context
def build_context_snapshot(context:Context,environment:str|_A=_A)->ProjectContextSnapshot:
	ensure_context_loaded(context);root=Path(context.path).resolve();models:list[ModelEvidence]=[];model_notices:list[str]=[]
	for model in context.models.values():
		try:models.append(_model_evidence(root,model))
		except Exception as exc:name=str(getattr(model,_B,'unknown model'));model_path=relative_or_name(root,getattr(model,'_path',_A));model_kind=str(getattr(getattr(model,'kind',_A),_B,'')or'');models.append(ModelEvidence(name=name,source_path=model_path,kind=model_kind));model_notices.append(f"Model projection unavailable for {name}: {type(exc).__name__}: {exc}")
	models.sort(key=lambda item:item.name.casefold());metrics=[MetricEvidence(name=str(name),definition=_safe_dump(metric))for(name,metric)in sorted(context.metrics.items())];audits=[AuditEvidence(name=str(name),definition=_safe_dump(audit))for(name,audit)in sorted(context.standalone_audits.items())];inline_audits:dict[str,t.Any]={}
	for model in context.models.values():inline_audits.update(getattr(model,'audit_definitions',{})or{})
	audits.extend(AuditEvidence(name=str(name),definition=_safe_dump(audit))for(name,audit)in sorted(inline_audits.items())if str(name)not in{item.name for item in audits});tests=[TestEvidence(name=test.test_name,path=relative_or_name(root,test.path),models=[test.model_name]if test.model_name else[],definition=json.loads(json.dumps(test.body,ensure_ascii=_C,default=str)))for test in context.select_tests()];edges=sorted((str(parent),str(child))for(child,parents)in context.dag.graph.items()for parent in parents);environment_metadata:EnvironmentMetadataEvidence|_A=_A;environment_notice=''
	try:
		metadata=context.metadata_for_environment(environment);physical_tables:dict[str,str]={};virtual_tables:dict[str,str]={}
		for model in metadata.models:
			table=getattr(model,'table',_A);physical=getattr(table,'physical',_A)if table is not _A else _A;virtual=getattr(table,'virtual',_A)if table is not _A else _A
			if physical is not _A and getattr(physical,_B,_A):physical_tables[str(model.name)]=str(physical.name)
			if virtual is not _A and getattr(virtual,_B,_A):virtual_tables[str(model.name)]=str(virtual.name)
		environment_metadata=EnvironmentMetadataEvidence(environment=str(metadata.env),as_of=str(metadata.as_of),physical_tables=physical_tables,virtual_tables=virtual_tables,missing_intervals={str(name):[(str(start),str(end))for(start,end)in intervals]for(name,intervals)in(getattr(metadata,'missing_intervals',_A)or{}).items()},nominal_runs={str(name):_safe_dump(run)for(name,run)in(getattr(metadata,'nominal_runs',_A)or{}).items()})
	except Exception as exc:environment_notice=f"Environment metadata unavailable: {type(exc).__name__}: {exc}"
	return ProjectContextSnapshot(product=_product_contract(context),models=models,metrics=metrics,audits=audits,tests=tests,graph=DependencyGraphEvidence(edges=edges),info={'models':len(models),'macros':len(getattr(context,'_macros',{})or{})},environment_metadata=environment_metadata,environment_notice='; '.join([*model_notices,environment_notice]).strip('; '))
def _product_contract(context:Context)->ProductContract:config=context.config;usage=getattr(config,'usage',_A);users=getattr(config,'users',_A)or[];owner=next((str(getattr(user,'email',_A)or getattr(user,'username',_A)or user)for user in users if str(getattr(user,'type','')).casefold().endswith('owner')),'');return ProductContract(name=str(getattr(config,_B,'')or getattr(config,_D,'')or context.path.name),domain=str(getattr(config,'domain','')or''),description=str(getattr(config,_E,'')or''),owner=owner,version=str(getattr(config,'version','')or''),status=str(getattr(config,'status','')or''),alignment=str(getattr(config,'alignment','')or''),tags=[str(value)for value in getattr(config,'tags',[])or[]],terms=[str(value)for value in getattr(config,'terms',[])or[]],support=[_safe_dump(value)for value in getattr(config,'support',[])or[]],service_expectations=_safe_dump(getattr(config,'sla',_A)),agreement=str(getattr(config,'agreement','')or''),good_for=_usage_values(usage,'good_for'),not_for=_usage_values(usage,'not_for'),caveats=_usage_values(usage,'caveats'),references=_usage_values(usage,_F))
def _usage_values(usage:t.Any,name:str)->list[str]:
	values:list[str]=[]
	for item in getattr(usage,name,_A)or[]:title=str(getattr(item,'title','')or'').strip();detail=str(getattr(item,'details','')or getattr(item,'url','')or'').strip();values.append(f"{title}: {detail}"if title and detail else title or detail or str(item))
	return values
def _model_evidence(root:Path,model:t.Any)->ModelEvidence:
	B='ai_context';A='dialect';columns_to_types=getattr(model,'columns_to_types',_A)or{};descriptions=getattr(model,'column_descriptions',_A)or{};tags=getattr(model,'column_tags',_A)or{};terms=getattr(model,'column_terms',_A)or{};classifications=getattr(model,'column_classifications',_A)or{};masks=getattr(model,'column_mask_expressions',_A)or{};column_ai_context=getattr(model,'column_ai_context',_A)or{};columns=[ColumnEvidence(name=str(name),data_type=_sql(dtype,getattr(model,A,'')),description=str(descriptions.get(name,'')or''),tags=[str(value)for value in tags.get(name,[])],terms=[str(value)for value in terms.get(name,[])],classification=str(classifications.get(name,'')or''),mask=_sql(masks.get(name),getattr(model,A,'')),ai_context=_safe_dump(column_ai_context.get(name))if column_ai_context.get(name)is not _A else _A)for(name,dtype)in columns_to_types.items()];semantic=_A
	if isinstance(model,SemanticModel):semantic=SemanticEvidence(dimensions=[_safe_dump(item)for item in model.dimensions],measures=[_safe_dump(item)for item in model.measures],segments=[_safe_dump(item)for item in model.segments],joins=[_safe_dump(item)for item in model.joins],rollups=[_safe_dump(item)for item in model.rollups],ai_context=_safe_dump(model.ai_context)if model.ai_context else _A)
	parsed_query=''
	if isinstance(model,SqlModel):parsed_query=_sql(model.query,model.dialect)
	time_column=getattr(model,'time_column',_A);return ModelEvidence(name=model.name,source_path=relative_or_name(root,getattr(model,'_path',_A)),source_type=str(getattr(model,'source_type','')or''),project=str(getattr(model,_D,'')or''),owner=str(getattr(model,'owner','')or''),description=str(getattr(model,_E,'')or''),tags=[str(value)for value in getattr(model,'tags',[])or[]],terms=[str(value)for value in getattr(model,'terms',[])or[]],ai_context=_safe_dump(getattr(model,B,_A))if getattr(model,B,_A)is not _A else _A,kind=str(getattr(getattr(model,'kind',_A),_B,'')or''),grains=[_sql(value,model.dialect)for value in getattr(model,'grains',[])],unique_keys=[_sql(value,model.dialect)for value in getattr(model,'unique_key',[])],dependencies=sorted(str(value)for value in getattr(model,'depends_on',_A)or set()),references=[_sql(value,model.dialect)for value in getattr(model,_F,_A)or[]],columns=columns,audits=[str(name)for(name,_)in getattr(model,'audits',[])],data_quality=_safe_dump(model.dq)if getattr(model,'dq',_A)else _A,policy=_safe_dump(model.policy)if getattr(model,'policy',_A)else _A,cron=str(getattr(model,'cron','')or''),interval_unit=str(getattr(getattr(model,'interval_unit',_A),'value','')or''),start=str(getattr(model,'start','')or''),end=str(getattr(model,'end','')or''),lookback=getattr(model,'lookback',_A),time_column=_sql(getattr(time_column,'column',time_column),model.dialect),partitioned_by=[_sql(value,model.dialect)for value in getattr(model,'partitioned_by',_A)or[]],clustered_by=[_sql(value,model.dialect)for value in getattr(model,'clustered_by',_A)or[]],table_format=str(getattr(model,'table_format','')or''),storage_format=str(getattr(model,'storage_format','')or''),physical_properties={str(key):_sql(value,model.dialect)for(key,value)in(getattr(model,'physical_properties',_A)or{}).items()},parsed_query=parsed_query,pre_statements=[_sql(value,model.dialect)for value in getattr(model,'pre_statements',[])],post_statements=[_sql(value,model.dialect)for value in getattr(model,'post_statements',[])],semantic=semantic)
def _safe_dump(value:t.Any)->dict[str,t.Any]:
	if value is _A:return{}
	try:dumped=value.model_dump(mode='json',exclude_none=True)
	except Exception:
		try:dumped=value.dict(exclude_none=True)
		except Exception:dumped=value
	normalized=_json_value(dumped);return normalized if isinstance(normalized,dict)else{'value':normalized}
def _json_value(value:t.Any)->t.Any:
	if isinstance(value,dict):return{str(key):_json_value(item)for(key,item)in value.items()}
	if isinstance(value,set):normalized=[_json_value(item)for item in value];return sorted(normalized,key=lambda item:json.dumps(item,ensure_ascii=_C,sort_keys=True,default=str))
	if isinstance(value,(list,tuple)):return[_json_value(item)for item in value]
	try:return json.loads(json.dumps(value,ensure_ascii=_C))
	except(TypeError,ValueError):return str(value)
def _sql(value:t.Any,dialect:str='')->str:
	if value is _A:return''
	try:return str(value.sql(dialect=dialect))
	except Exception:return str(value)