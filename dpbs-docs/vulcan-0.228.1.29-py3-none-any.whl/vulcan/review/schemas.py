from __future__ import annotations
_H='unknown'
_G='blocker'
_F=False
_E='low'
_D='medium'
_C='high'
_B=True
_A=None
from dataclasses import dataclass
from dataclasses import field as dc_field
from enum import Enum
from pathlib import Path
from typing import Any,Optional
from pydantic import BaseModel,ConfigDict,Field,model_validator
PRIORITY_RANK={_G:-1,_C:0,_D:1,_E:2}
class DimensionKey(str,Enum):STRUCTURE='structure';SEMANTICS='semantics';CONTRACT='contract'
ALL_DIMENSIONS=tuple(DimensionKey)
class ReviewStatus(str,Enum):COMPLETE='complete';PARTIAL='partial'
class ReportFormat(str,Enum):HTML='html';MARKDOWN='markdown';JSON='json'
class EvidenceKind(str,Enum):FILE='file';MODEL_METADATA='model_metadata';GRAPH='graph';SEARCH='search'
class EvidenceEntry(BaseModel):model_config=ConfigDict(frozen=_B);evidence_id:str;kind:str;target:str;sha256:str;content:str;omitted:bool=_F
class FindingCategory(str,Enum):STRUCTURE_COHERENCE='structure_coherence';PHYSICAL_COST='physical_cost';SEMANTIC_MEANING='semantic_meaning';CONTRACT_ENFORCEMENT='contract_enforcement'
class FindingPriority(str,Enum):BLOCKER=_G;HIGH=_C;MEDIUM=_D;LOW=_E
class SourceConfidence(str,Enum):HIGH=_C;MEDIUM=_D;LOW=_E;UNAVAILABLE='unavailable'
class ContractAlignmentVerdict(str,Enum):ALIGNED='aligned';DRIFT='drift';UNKNOWN=_H
class CostVerdict(str,Enum):APPROPRIATE='appropriate';WATCH='watch';RISK='risk';UNKNOWN=_H
class ModelingVerdict(str,Enum):VALIDATED='validated';WATCH='watch';CHANGES_REQUIRED='changes_required';INCOMPLETE='incomplete'
class AIReadinessTier(str,Enum):AGENT_READY='agent_ready';NEEDS_WORK='needs_work';NOT_AGENT_READY='not_agent_ready'
class ProductContract(BaseModel):name:str;domain:str='';description:str='';owner:str='';version:str='';status:str='';alignment:str='';tags:list[str]=Field(default_factory=list);terms:list[str]=Field(default_factory=list);support:list[dict[str,Any]]=Field(default_factory=list);service_expectations:dict[str,Any]=Field(default_factory=dict);agreement:str='';good_for:list[str]=Field(default_factory=list);not_for:list[str]=Field(default_factory=list);caveats:list[str]=Field(default_factory=list);references:list[str]=Field(default_factory=list)
class ColumnEvidence(BaseModel):name:str;data_type:str='';description:str='';tags:list[str]=Field(default_factory=list);terms:list[str]=Field(default_factory=list);classification:str='';mask:str='';ai_context:Optional[dict[str,Any]]=_A
class SemanticEvidence(BaseModel):dimensions:list[dict[str,Any]]=Field(default_factory=list);measures:list[dict[str,Any]]=Field(default_factory=list);segments:list[dict[str,Any]]=Field(default_factory=list);joins:list[dict[str,Any]]=Field(default_factory=list);rollups:list[dict[str,Any]]=Field(default_factory=list);ai_context:Optional[dict[str,Any]]=_A
class ModelEvidence(BaseModel):name:str;source_path:str='';source_type:str='';project:str='';owner:str='';description:str='';tags:list[str]=Field(default_factory=list);terms:list[str]=Field(default_factory=list);ai_context:Optional[dict[str,Any]]=_A;kind:str='';grains:list[str]=Field(default_factory=list);unique_keys:list[str]=Field(default_factory=list);dependencies:list[str]=Field(default_factory=list);references:list[str]=Field(default_factory=list);columns:list[ColumnEvidence]=Field(default_factory=list);audits:list[str]=Field(default_factory=list);data_quality:Optional[dict[str,Any]]=_A;policy:Optional[dict[str,Any]]=_A;cron:str='';interval_unit:str='';start:str='';end:str='';lookback:Optional[int]=_A;time_column:str='';partitioned_by:list[str]=Field(default_factory=list);clustered_by:list[str]=Field(default_factory=list);table_format:str='';storage_format:str='';physical_properties:dict[str,str]=Field(default_factory=dict);parsed_query:str='';pre_statements:list[str]=Field(default_factory=list);post_statements:list[str]=Field(default_factory=list);semantic:Optional[SemanticEvidence]=_A
class MetricEvidence(BaseModel):name:str;definition:dict[str,Any]=Field(default_factory=dict)
class AuditEvidence(BaseModel):name:str;definition:dict[str,Any]=Field(default_factory=dict)
class TestEvidence(BaseModel):name:str;path:str='';models:list[str]=Field(default_factory=list);definition:dict[str,Any]=Field(default_factory=dict)
class DependencyGraphEvidence(BaseModel):edges:list[tuple[str,str]]=Field(default_factory=list)
class EnvironmentMetadataEvidence(BaseModel):environment:str='';as_of:str='';physical_tables:dict[str,str]=Field(default_factory=dict);virtual_tables:dict[str,str]=Field(default_factory=dict);missing_intervals:dict[str,list[tuple[str,str]]]=Field(default_factory=dict);nominal_runs:dict[str,dict[str,Any]]=Field(default_factory=dict)
class ProjectContextSnapshot(BaseModel):product:ProductContract;models:list[ModelEvidence]=Field(default_factory=list);metrics:list[MetricEvidence]=Field(default_factory=list);audits:list[AuditEvidence]=Field(default_factory=list);tests:list[TestEvidence]=Field(default_factory=list);graph:DependencyGraphEvidence=Field(default_factory=DependencyGraphEvidence);info:dict[str,int]=Field(default_factory=dict);environment_metadata:Optional[EnvironmentMetadataEvidence]=_A;environment_notice:str=''
class AgentFinding(BaseModel):category:FindingCategory;priority:FindingPriority;title:str;model:str='';dimension:Optional[DimensionKey]=_A
class DimensionOutput(BaseModel):
	dimension:DimensionKey;body:str;findings:list[AgentFinding]=Field(default_factory=list);findings_parsed:bool=_B;adjudications:dict[str,ContractAlignmentVerdict]=Field(default_factory=dict)
	def __str__(self)->str:return self.model_dump_json()
class DimensionFailure(BaseModel):dimension:Optional[DimensionKey]=_A;detail:str
class StageDiagnostics(BaseModel):stage:str;dimension:Optional[DimensionKey]=_A;requests:int=0;input_tokens:int=0;output_tokens:int=0;total_tokens:int=0;cache_read_tokens:int=0;cache_write_tokens:int=0;elapsed_seconds:float=0;unique_evidence_accesses:int=0;duplicate_evidence_accesses:int=0;malformed_evidence_requests:int=0;accepted_findings:int=0;error:Optional[str]=_A
class ReviewDiagnostics(BaseModel):packet_bytes:int=0;packet_entries:int=0;packet_files:int=0;packet_models:int=0;dag_mode:str='sequential';business_context:Optional[StageDiagnostics]=_A;specialists:list[StageDiagnostics]=Field(default_factory=list);merge:Optional[StageDiagnostics]=_A;integration:Optional[StageDiagnostics]=_A;synthesis:Optional[StageDiagnostics]=_A;supplemental_notes:list[str]=Field(default_factory=list)
class SourceLedgerEntry(BaseModel):evidence_id:str;source:str;source_type:str;sha256:str;what_established:str;confidence:SourceConfidence=SourceConfidence.HIGH
class ReviewBody(BaseModel):content:str;report_format:'ReportFormat'=Field(default_factory=lambda:ReportFormat.MARKDOWN);unresolved_citations:list[str]=Field(default_factory=list);contradicts_cost_verdict:bool=_F
class ReviewCoverage(BaseModel):
	expected_dimensions:list[DimensionKey]=Field(default_factory=lambda:list(ALL_DIMENSIONS));completed_dimensions:list[DimensionKey]=Field(default_factory=list);missing_dimensions:list[DimensionKey]=Field(default_factory=list);duplicate_dimensions:list[DimensionKey]=Field(default_factory=list);failures:list[DimensionFailure]=Field(default_factory=list)
	@property
	def is_partial(self)->bool:return bool(self.missing_dimensions or self.failures)
@dataclass
class MetadataColumn:name:str;kind:str='';public:bool=_F;description:str='';tags:list[str]=dc_field(default_factory=list);terms:list[str]=dc_field(default_factory=list);ai_context:Optional[dict[str,Any]]=_A;aggregation:str='';expression:str=''
@dataclass
class MetadataModel:name:str;kind:str='';description:str='';tags:list[str]=dc_field(default_factory=list);terms:list[str]=dc_field(default_factory=list);ai_context:Optional[dict[str,Any]]=_A;depends_on:list[str]=dc_field(default_factory=list);grains:list[str]=dc_field(default_factory=list);cron:str='';interval_unit:str='';joins:list[dict[str,str]]=dc_field(default_factory=list);columns:list[MetadataColumn]=dc_field(default_factory=list)
@dataclass
class MetadataProject:name:str;product:Optional[dict[str,Any]]=_A;models:list[MetadataModel]=dc_field(default_factory=list)
@dataclass
class Coverage:total:int=0;described:int=0;tagged:int=0;termed:int=0
@dataclass
class MetadataCoverage:semantic_models:Coverage=dc_field(default_factory=Coverage);semantic_fields:Coverage=dc_field(default_factory=Coverage);physical_models:Coverage=dc_field(default_factory=Coverage);physical_fields:Coverage=dc_field(default_factory=Coverage);generated_fields_excluded:int=0;ai_context_total:int=0;ai_context_present:int=0;ai_context_passing:int=0;dimensions_total:int=0;dimensions_aligned:int=0
@dataclass
class MetadataIssue:rule_id:str;model:str;priority:str;title:str;detail:str;action:str;field:Optional[str]=_A;scope:str='semantic';evidence_level:str='METADATA_CONFIRMED';pillar:str='Quality';artifact:str='';evidence:str='';done_when:str=''
@dataclass
class TokenUsage:requests:int=0;input_tokens:int=0;output_tokens:int=0;total_tokens:int=0;cache_read_tokens:int=0;cache_write_tokens:int=0
@dataclass
class ReviewReport:project_name:str;source:str;status:ReviewStatus=ReviewStatus.COMPLETE;modeling_verdict:ModelingVerdict=ModelingVerdict.INCOMPLETE;cost_verdict:CostVerdict=CostVerdict.UNKNOWN;coverage:ReviewCoverage=dc_field(default_factory=ReviewCoverage);metadata_coverage:MetadataCoverage=dc_field(default_factory=MetadataCoverage);deterministic_notice:Optional[str]=_A;token_usage:TokenUsage=dc_field(default_factory=TokenUsage);elapsed_seconds:float=0;synthesis:Optional[ReviewBody]=_A;dimension_reviews:list[DimensionOutput]=dc_field(default_factory=list);findings:list[AgentFinding]=dc_field(default_factory=list);findings_parsed:bool=_B;deterministic_issues:list[MetadataIssue]=dc_field(default_factory=list);diagnostics:ReviewDiagnostics=dc_field(default_factory=ReviewDiagnostics);evidence_sources:list[SourceLedgerEntry]=dc_field(default_factory=list);business_context:Optional[str]=_A
@dataclass(frozen=_B)
class ReportArtifacts:
	report:Optional[Path]=_A;structured:Optional[Path]=_A;html:Optional[Path]=_A
	@property
	def path(self)->Path:
		for candidate in(self.html,self.report,self.structured):
			if candidate is not _A:return candidate
		raise ValueError('ReportArtifacts has no populated path.')