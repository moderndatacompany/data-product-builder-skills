from __future__ import annotations
from vulcan.review.schemas import AIReadinessTier,MetadataCoverage
_NOT_READY_THRESHOLD=.34
_NEEDS_WORK_THRESHOLD=.75
TIER_LABEL={AIReadinessTier.AGENT_READY:'AGENT-READY',AIReadinessTier.NEEDS_WORK:'NEEDS WORK',AIReadinessTier.NOT_AGENT_READY:'NOT AGENT-READY'}
def ai_readiness_tier(metadata_coverage:MetadataCoverage)->AIReadinessTier:
	if metadata_coverage.ai_context_total==0:return AIReadinessTier.NOT_AGENT_READY
	pass_rate=metadata_coverage.ai_context_passing/metadata_coverage.ai_context_total
	if pass_rate<_NOT_READY_THRESHOLD:return AIReadinessTier.NOT_AGENT_READY
	if pass_rate<_NEEDS_WORK_THRESHOLD:return AIReadinessTier.NEEDS_WORK
	return AIReadinessTier.AGENT_READY