from __future__ import annotations
_A='json'
import json
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from vulcan.review.report.neutralize import _assert_platform_neutral,_neutral_value,assert_html_is_inert
from vulcan.review.schemas import ReportArtifacts,ReportFormat,ReviewReport
_FORMAT_EXTENSION={ReportFormat.HTML:'html',ReportFormat.MARKDOWN:'md',ReportFormat.JSON:_A}
def report_to_json(report:ReviewReport)->str:payload=_neutral_value(_report_payload(report));return json.dumps(payload,ensure_ascii=False,indent=2)+'\n'
def report_body(report:ReviewReport)->str:
	if report.synthesis is not None and report.synthesis.content.strip():return report.synthesis.content
	reasons=[failure.detail for failure in report.coverage.failures]or['No specialist stage completed.'];lines=[f"# Architecture review: {report.project_name}",'',f"**Review run:** {report.status.value.upper()}",'','This review did not produce a report body. The stages below did not complete, so no architectural conclusion can be drawn from this run.',''];lines.extend(f"- {reason}"for reason in reasons)
	if report.deterministic_notice:lines.extend(['',report.deterministic_notice])
	return'\n'.join(lines)+'\n'
def save_report(report:ReviewReport,output_dir:Path,*,generated_at:datetime|None=None,report_format:ReportFormat=ReportFormat.HTML)->ReportArtifacts:
	A=True;generated_at=generated_at or datetime.now().astimezone();output_dir.mkdir(parents=A,exist_ok=A);stem=generated_at.strftime('%Y-%m-%d-%H%M');extension=_FORMAT_EXTENSION[report_format];suffix=1
	while A:
		run_stem=stem if suffix==1 else f"{stem}-{suffix}";artifact_path=output_dir/f"{run_stem}-review.{extension}"
		if not artifact_path.exists():break
		suffix+=1
	content=report_to_json(report)if report_format is ReportFormat.JSON else report_body(report);_assert_platform_neutral(content)
	if report_format is ReportFormat.HTML:assert_html_is_inert(content)
	artifact_path.write_text(content,encoding='utf-8')
	if report_format is ReportFormat.HTML:return ReportArtifacts(html=artifact_path)
	if report_format is ReportFormat.MARKDOWN:return ReportArtifacts(report=artifact_path)
	return ReportArtifacts(structured=artifact_path)
def _report_payload(report:ReviewReport)->dict[str,object]:return{'project_name':report.project_name,'source':report.source,'status':report.status.value,'modeling_verdict':report.modeling_verdict.value,'cost_verdict':report.cost_verdict.value,'coverage':report.coverage.model_dump(mode=_A),'metadata_coverage':asdict(report.metadata_coverage),'token_usage':asdict(report.token_usage),'elapsed_seconds':report.elapsed_seconds,'business_context':report.business_context,'report_body':report_body(report),'findings':[finding.model_dump(mode=_A)for finding in report.findings],'findings_parsed':report.findings_parsed,'dimension_reviews':[review.model_dump(mode=_A)for review in report.dimension_reviews],'diagnostics':report.diagnostics.model_dump(mode=_A),'evidence_sources':[source.model_dump(mode=_A)for source in report.evidence_sources],'deterministic_issues':[asdict(issue)for issue in report.deterministic_issues]}