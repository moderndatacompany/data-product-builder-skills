from __future__ import annotations
_K='bold green'
_J='LOW'
_I='MEDIUM'
_H='right'
_G='bold red'
_F='bold yellow'
_E='dim'
_D='HIGH'
_C='BLOCKER'
_B=None
_A=True
from dataclasses import dataclass,field
from pathlib import Path
from rich.console import Console,Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from vulcan.review.report.ai_readiness import TIER_LABEL,ai_readiness_tier
from vulcan.review.report.helpers import grouped_deterministic_issues,sorted_findings
from vulcan.review.schemas import AgentFinding,AIReadinessTier,FindingPriority,MetadataIssue,ReviewReport
REVIEW_CONSOLE=Console()
@dataclass
class _DeterministicSummary:action:str;models:set[str]=field(default_factory=set);fields:int=0
SEVERITY_STYLE={_C:_G,_D:_F,_I:'yellow',_J:_E}
WARN_VALUES={'partial','incomplete','unknown','risk','changes_required','watch'}
CATEGORY_LABELS={'structure_coherence':'Structure & mechanics','physical_cost':'Physical cost','semantic_meaning':'Exposed meaning','contract_enforcement':'Guarantees & enforcement'}
_AI_TIER_STYLE={AIReadinessTier.AGENT_READY:_K,AIReadinessTier.NEEDS_WORK:_F,AIReadinessTier.NOT_AGENT_READY:_G}
def _verdict_style(value:str)->str:return _F if value.lower()in WARN_VALUES else _K
def _fmt_elapsed(seconds:float)->str:minutes,secs=divmod(int(seconds),60);return f"{minutes}m {secs}s"if minutes else f"{secs}s"
def _fmt_tokens(n:int)->str:
	if n>=1000000:return f"{n/1000000:.1f}M"
	if n>=1000:return f"{n/1000:.0f}K"
	return str(n)
def _overview_panel(report:ReviewReport)->Panel:grid=Table.grid(expand=_A,padding=(0,3));grid.add_column(style=_E,no_wrap=_A);grid.add_column(ratio=1);grid.add_column(style=_E,no_wrap=_A);grid.add_column(ratio=1);usage=report.token_usage;grid.add_row('Project',Text(report.project_name),'Elapsed',Text(_fmt_elapsed(report.elapsed_seconds)));grid.add_row('Review run',Text(report.status.value.upper(),style=_verdict_style(report.status.value)),'LLM usage',Text(f"{usage.requests} req · {_fmt_tokens(usage.total_tokens)} tok"));grid.add_row('Modeling readiness',Text(report.modeling_verdict.value.upper().replace('_',' '),style=_verdict_style(report.modeling_verdict.value)),'Input / output',Text(f"{_fmt_tokens(usage.input_tokens)} / {_fmt_tokens(usage.output_tokens)}"));grid.add_row('Cost posture',Text(report.cost_verdict.value.upper(),style=_verdict_style(report.cost_verdict.value)),'Scope',Text(f"{report.diagnostics.packet_files} files, {report.diagnostics.packet_models} models, {report.diagnostics.packet_entries} evidence entries"));return Panel(grid,title='Vulcan Architecture Review',border_style='cyan',expand=_A)
def _severity_counts(report:ReviewReport)->dict[str,int]:
	counts={_C:0,_D:0,_I:0,_J:0}
	for finding in report.findings:key=finding.priority.value.upper();counts[key]=counts.get(key,0)+1
	for issue in report.deterministic_issues:key=issue.priority.upper();counts[key]=counts.get(key,0)+1
	return counts
def _severity_tally(counts:dict[str,int])->Text:
	text=Text()
	for(index,key)in enumerate((_C,_D,_I,_J)):
		if index:text.append('   ')
		text.append(f"{counts.get(key,0):>3} {key}",style=SEVERITY_STYLE[key])
	return text
def _blockers_panel(findings:list[AgentFinding])->Panel|_B:
	blockers=[finding for finding in findings if finding.priority is FindingPriority.BLOCKER]
	if not blockers:return
	body=Text()
	for(index,finding)in enumerate(blockers):
		if index:body.append('\n')
		body.append('● ',style=_G);body.append(finding.title);evidence=finding.model
		if evidence:body.append(f"  ({evidence})",style=_E)
	return Panel(body,title=f"Blockers ({len(blockers)})",border_style='red')
def _ai_readiness_panel(report:ReviewReport)->Panel:
	B='blue';A='AI readiness';coverage=report.metadata_coverage;tier=ai_readiness_tier(coverage);grid=Table.grid(expand=_A,padding=(0,2));grid.add_column(style=_E,no_wrap=_A);grid.add_column(ratio=1,justify=_H);grid.add_row('Verdict',Text(TIER_LABEL[tier],style=_AI_TIER_STYLE[tier]));grid.add_row('AI context',Text(f"{coverage.ai_context_passing}/{coverage.ai_context_total} fields",style=_AI_TIER_STYLE[tier]));grid.add_row('Described',Text(f"{coverage.semantic_fields.described}/{coverage.semantic_fields.total} fields"));grid.add_row('Tagged',Text(f"{coverage.semantic_fields.tagged}/{coverage.semantic_fields.total} fields"))
	if not report.deterministic_notice:return Panel(grid,title=A,border_style=B,expand=_A)
	notice=Text(f"Unavailable: {report.deterministic_notice}",style='dim italic');return Panel(Group(grid,notice),title=A,border_style=B,expand=_A)
def _theme_rank(theme:tuple[str,dict[str,int]])->tuple[int,int,int,str]:label,bucket=theme;return 0 if bucket[_C]else 1,-bucket[_C],-bucket[_D],label
def _theme_cell(label:str,bucket:dict[str,int])->tuple[Text,Text,Text]:
	blockers,highs=bucket[_C],bucket[_D];style=_G if blockers else _F
	if blockers and highs:blocker_word='blocker'if blockers==1 else'blockers';breakdown=f"{blockers} {blocker_word}, {highs} high"
	elif blockers==1:breakdown='1 blocker'
	elif blockers:breakdown=f"{blockers} blockers"
	else:breakdown=f"{highs} high"
	return Text(label),Text(str(blockers+highs),style=style),Text(breakdown,style=_E)
def _repair_themes_panel(findings:list[AgentFinding])->Panel|_B:
	if not findings:return
	buckets:dict[str,dict[str,int]]={}
	for finding in findings:label=CATEGORY_LABELS.get(finding.category.value,finding.category.value);bucket=buckets.setdefault(label,{_C:0,_D:0});priority=finding.priority.value.upper();bucket[priority]=bucket.get(priority,0)+1
	themes=sorted(buckets.items(),key=_theme_rank);grid=Table.grid(expand=_A,padding=(0,1));grid.add_column(ratio=1,no_wrap=_A);grid.add_column(width=4,justify=_H,no_wrap=_A);grid.add_column(width=24,justify=_H,no_wrap=_A)
	for theme in themes:grid.add_row(*_theme_cell(*theme))
	return Panel(grid,title='Repair themes',border_style='magenta',expand=_A)
def _deterministic_summary_table(issues:list[MetadataIssue])->Table|_B:
	groups=grouped_deterministic_issues(issues,priorities=frozenset({_D,_C}))
	if not groups:return
	summary:dict[tuple[str,str],_DeterministicSummary]={}
	for((priority,title,model),grouped_issues)in groups:bucket=summary.setdefault((priority,title),_DeterministicSummary(action=grouped_issues[0].action));bucket.models.add(model);bucket.fields+=sum(1 for issue in grouped_issues if issue.field)
	table=Table(title='Deterministic issues');table.add_column('Priority');table.add_column('Finding');table.add_column('Scope',justify=_H);table.add_column('Action')
	for((priority,title),bucket)in summary.items():table.add_row(Text(priority,style=SEVERITY_STYLE.get(priority,'')),title,f"{len(bucket.models)} model(s), {bucket.fields} field(s)",bucket.action)
	return table
_TOP_ACTION_MAX_CHARS=160
def _top_next_action(report:ReviewReport)->str:
	ranked=sorted_findings(report.findings)
	if not ranked:
		if not report.findings_parsed:return'Unknown -- no findings table could be read from this run.'
		return'No material findings were reported.'
	top=ranked[0];action=f"{top.priority.value.upper()}: {top.title}".replace('**','').replace('`','')
	if top.model:action+=f" ({top.model})"
	if len(action)>_TOP_ACTION_MAX_CHARS:action=action[:_TOP_ACTION_MAX_CHARS].rsplit(' ',1)[0]+'…'
	return action
def render_review_terminal(report:ReviewReport,console:Console,artifact_path:Path|_B=_B)->_B:
	console.print(_overview_panel(report));counts=_severity_counts(report);console.print(_severity_tally(counts))
	if not report.findings_parsed:console.print(Text('At least one findings table could not be read; counts below are incomplete.',style=_F))
	console.print();material_findings=[finding for finding in sorted_findings(report.findings)if finding.priority in{FindingPriority.BLOCKER,FindingPriority.HIGH}];blockers_panel=_blockers_panel(material_findings)
	if blockers_panel is not _B:console.print(blockers_panel)
	ai_panel=_ai_readiness_panel(report);themes_panel=_repair_themes_panel(material_findings)
	if themes_panel is _B:console.print(ai_panel)
	else:readiness_layout=Table.grid(expand=_A,padding=(0,2));readiness_layout.add_column(ratio=1);readiness_layout.add_column(ratio=1);readiness_layout.add_row(ai_panel,themes_panel);console.print(readiness_layout)
	det_table=_deterministic_summary_table(report.deterministic_issues)
	if det_table is not _B:console.print(det_table)
	total=sum(counts.values());console.print();console.print(f"[bold]Top next action:[/bold] {_top_next_action(report)}");tally=f"{total} finding(s) found: {len(material_findings)} blocker/high issue(s) require action.";console.print(tally if report.findings_parsed else tally+' Counts are incomplete.')
	if artifact_path is not _B:resolved=artifact_path.resolve();console.print(f"Full report persisted at: [link=file://{resolved}]{resolved}[/link]")