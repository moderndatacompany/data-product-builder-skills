from __future__ import annotations
import re,typing as t
_PLATFORM_TERMS=(re.compile('(?<![A-Za-z0-9])sql[\\s_.-]*mesh(?:\\d+)?(?![A-Za-z0-9])',re.IGNORECASE),'modeling runtime'),(re.compile('(?<![A-Za-z0-9])cube(?:[\\s_.-]*(?:js|core))?(?![A-Za-z0-9])',re.IGNORECASE),'semantic layer'),(re.compile('(?<![A-Za-z0-9])soda(?:[\\s_.-]*(?:core|sql|cloud|checks?)|\\s*v?\\d+)?(?![A-Za-z0-9])',re.IGNORECASE),'data-quality checks'),(re.compile('(?<![A-Za-z0-9])(?:snowflake|bigquery|databricks|redshift|duckdb|trino|spark|postgres(?:ql)?|mysql|sql[\\s_-]*server)(?![A-Za-z0-9])',re.IGNORECASE),'data platform'),(re.compile('(?<![A-Za-z0-9])(?:pydantic[\\s_-]*ai[\\s_-]*harness|pydantic[\\s_-]*ai|pydantic|litellm|openai)(?![A-Za-z0-9])',re.IGNORECASE),'agent runtime')
_PROHIBITED_TERMS=tuple(pattern for(pattern,_)in _PLATFORM_TERMS[:3])
_REMOVED_REPORT_LANGUAGE=re.compile('business[\\s_-]*question[\\s_-]*answerability',re.IGNORECASE)
def _neutral_text(value:str)->str:
	text=_REMOVED_REPORT_LANGUAGE.sub('business intent coverage',value)
	for(pattern,replacement)in _PLATFORM_TERMS:text=pattern.sub(replacement,text)
	return text
def _neutral_value(value:t.Any)->t.Any:
	if isinstance(value,str):return _neutral_text(value)
	if isinstance(value,dict):
		normalized:dict[str,t.Any]={}
		for(key,item)in value.items():
			normalized_key=_neutral_text(str(key))
			if normalized_key in{'artifact','source','source_path'}and isinstance(item,str):normalized[normalized_key]=_neutral_artifact(item)
			else:normalized[normalized_key]=_neutral_value(item)
		return normalized
	if isinstance(value,list):return[_neutral_value(item)for item in value]
	if isinstance(value,tuple):return[_neutral_value(item)for item in value]
	return value
def _assert_platform_neutral(content:str)->None:
	for pattern in _PROHIBITED_TERMS:
		if pattern.search(content):raise ValueError('Persisted review artifact contains prohibited platform terminology.')
_QUOTE_OR_BARE='(?:[\\"\']\\s*)?'
_ACTIVE_CONTENT=(re.compile('<\\s*script\\b',re.IGNORECASE),'a <script> element'),(re.compile('<\\s*iframe\\b',re.IGNORECASE),'an <iframe> element'),(re.compile('<\\s*object\\b|<\\s*embed\\b',re.IGNORECASE),'an embedded object'),(re.compile(rf"\bon[a-z]+\s*=\s*{_QUOTE_OR_BARE}\S",re.IGNORECASE),'an inline event handler'),(re.compile(rf"(?:href|src|action)\s*=\s*{_QUOTE_OR_BARE}javascript:",re.IGNORECASE),'a javascript: URL'),(re.compile(rf"(?:href|src)\s*=\s*{_QUOTE_OR_BARE}data:text/html",re.IGNORECASE),'a data:text/html URL'),(re.compile('<\\s*meta\\b[^>]*\\bhttp-equiv\\s*=\\s*[\\"\']?\\s*refresh',re.IGNORECASE),'a meta-refresh redirect')
_EXTERNAL_URL='(?:https?:)?//'
_EXTERNAL_REFERENCE=re.compile(rf"(?:\b(?:src|href|srcset|poster)\s*=\s*(?:\"[^\"]*{_EXTERNAL_URL}|'[^']*{_EXTERNAL_URL}|[^\s>]*{_EXTERNAL_URL})|\burl\(\s*{_QUOTE_OR_BARE}{_EXTERNAL_URL}|@import\s+{_QUOTE_OR_BARE}{_EXTERNAL_URL})",re.IGNORECASE)
def assert_html_is_inert(content:str)->None:
	for(pattern,description)in _ACTIVE_CONTENT:
		if pattern.search(content):raise ValueError(f"Persisted HTML review artifact contains {description}. The report is specified to be inert and self-contained.")
	if _EXTERNAL_REFERENCE.search(content):raise ValueError('Persisted HTML review artifact references an external resource. The report is specified to be self-contained.')
def _neutral_artifact(value:str)->str:
	if not any(pattern.search(value)for(pattern,_)in _PLATFORM_TERMS):return value
	return'/'.join(_neutral_text(part).replace(' ','-')for part in value.split('/'))