_E='snapshot'
_D='source'
_C=False
_B=True
_A=None
import typing as t,sys,click
from vulcan_dbt.operations import DbtOperations,create
from vulcan_dbt.error import cli_global_error_handler,ErrorHandlingGroup
from pathlib import Path
from vulcan_dbt.options import YamlParamType
import functools
def _get_dbt_operations(ctx:click.Context,vars:t.Optional[t.Dict[str,t.Any]],threads:t.Optional[int]=_A)->DbtOperations:
	if not isinstance(ctx.obj,functools.partial):raise ValueError(f"Unexpected click context object: {type(ctx.obj)}")
	dbt_operations=ctx.obj(vars=vars,threads=threads)
	if not isinstance(dbt_operations,DbtOperations):raise ValueError(f"Unexpected dbt operations type: {type(dbt_operations)}")
	@ctx.call_on_close
	def _cleanup()->_A:dbt_operations.close()
	return dbt_operations
vars_option=click.option('--vars',type=YamlParamType(),help="Supply variables to the project. This argument overrides variables defined in your dbt_project.yml file. This argument should be a YAML string, eg. '{my_variable: my_value}'")
select_option=click.option('-s','--select',multiple=_B,help='Specify the nodes to include.')
model_option=click.option('-m','--models','--model',multiple=_B,help='Specify the model nodes to include; other nodes are excluded.')
exclude_option=click.option('--exclude',multiple=_B,help='Specify the nodes to exclude.')
resource_types=['metric','semantic_model','saved_query',_D,'analysis','model','test','unit_test','exposure',_E,'seed','default','all']
resource_type_option=click.option('--resource-type',type=click.Choice(resource_types,case_sensitive=_C))
@click.group(cls=ErrorHandlingGroup,invoke_without_command=_B)
@click.option('--profile',help='Which existing profile to load. Overrides output.profile')
@click.option('-t','--target',help='Which target to load for the given profile')
@click.option('-d','--debug/--no-debug',default=_C,help='Display debug logging during dbt execution. Useful for debugging and making bug reports events to help when debugging.')
@click.option('--log-level',default='info',type=click.Choice(['debug','info','warn','error','none']),help='Specify the minimum severity of events that are logged to the console and the log file.')
@click.option('--profiles-dir',type=click.Path(exists=_B,file_okay=_C,path_type=Path),help='Which directory to look in for the profiles.yml file. If not set, dbt will look in the current working directory first, then HOME/.dbt/')
@click.option('--project-dir',type=click.Path(exists=_B,file_okay=_C,path_type=Path),help='Which directory to look in for the dbt_project.yml file. Default is the current working directory and its parents.')
@click.pass_context
@cli_global_error_handler
def dbt(ctx:click.Context,profile:t.Optional[str]=_A,target:t.Optional[str]=_A,debug:bool=_C,log_level:t.Optional[str]=_A,profiles_dir:t.Optional[Path]=_A,project_dir:t.Optional[Path]=_A)->_A:
	if'--help'in sys.argv:return
	ctx.obj=functools.partial(create,project_dir=project_dir,profiles_dir=profiles_dir,profile=profile,target=target,debug=debug,log_level=log_level)
	if not ctx.invoked_subcommand:
		if profile or target:ctx.obj()
		click.echo(f"No command specified. Run `{ctx.info_name} --help` to see the available commands.")
@dbt.command()
@select_option
@model_option
@exclude_option
@resource_type_option
@click.option('-f','--full-refresh',is_flag=_B,default=_C,help='If specified, vulcan will drop incremental models and fully-recalculate the incremental table from the model definition.')
@click.option('--env','--environment',help='Run against a specific Virtual Data Environment (VDE) instead of the main environment')
@click.option('--empty/--no-empty',default=_C,help='If specified, limit input refs and sources')
@click.option('--threads',type=int,help='Specify number of threads to use while executing models. Overrides settings in profiles.yml.')
@vars_option
@click.pass_context
def run(ctx:click.Context,vars:t.Optional[t.Dict[str,t.Any]],threads:t.Optional[int],env:t.Optional[str]=_A,**kwargs:t.Any)->_A:_get_dbt_operations(ctx,vars,threads).run(environment=env,**kwargs)
@dbt.command(name='list')
@select_option
@model_option
@exclude_option
@resource_type_option
@vars_option
@click.pass_context
def list_(ctx:click.Context,vars:t.Optional[t.Dict[str,t.Any]],**kwargs:t.Any)->_A:_get_dbt_operations(ctx,vars).list_(**kwargs)
@dbt.command(name='ls',hidden=_B)
@click.pass_context
def ls(ctx:click.Context)->_A:ctx.forward(list_)
def _not_implemented(name:str)->_A:
	@dbt.command(name=name)
	def _not_implemented()->_A:click.echo(f"dbt {name} not implemented")
for subcommand in('build','clean','clone','compile','debug','deps','docs','init','parse','retry','run-operation','seed','show',_E,_D,'test'):_not_implemented(subcommand)