from __future__ import annotations
_C=False
_B=True
_A=None
import typing as t
from rich.progress import Progress
from pathlib import Path
import logging
from vulcan_dbt import selectors
if t.TYPE_CHECKING:from vulcan.core.context import Context;from vulcan.dbt.project import Project;from vulcan_dbt.console import DbtCliConsole;from vulcan.core.model import Model;from vulcan.core.plan import Plan,PlanBuilder
logger=logging.getLogger(__name__)
class DbtOperations:
	def __init__(self,vulcan_context:Context,dbt_project:Project,debug:bool=_C):self.context=vulcan_context;self.project=dbt_project;self.debug=debug
	def list_(self,select:t.Optional[t.List[str]]=_A,exclude:t.Optional[t.List[str]]=_A,models:t.Optional[t.List[str]]=_A,resource_type:t.Optional[str]=_A)->_A:selected_models=list(self._selected_models(select,exclude,models,resource_type).values());self.console.list_models(selected_models,{k:v.node for(k,v)in self.context.snapshots.items()})
	def run(self,environment:t.Optional[str]=_A,select:t.Optional[t.List[str]]=_A,exclude:t.Optional[t.List[str]]=_A,models:t.Optional[t.List[str]]=_A,resource_type:t.Optional[str]=_A,full_refresh:bool=_C,empty:bool=_C)->Plan:consolidated_select,consolidated_exclude=selectors.consolidate(select or[],exclude or[],models or[],resource_type);plan_builder=self._plan_builder(environment=environment,select=consolidated_select,exclude=consolidated_exclude,full_refresh=full_refresh,empty=empty);plan=plan_builder.build();self.console.plan(plan_builder,default_catalog=self.context.default_catalog,auto_apply=_B,no_diff=_B,no_prompts=_B);return plan
	def _plan_builder(self,environment:t.Optional[str]=_A,select:t.Optional[t.List[str]]=_A,exclude:t.Optional[t.List[str]]=_A,full_refresh:bool=_C,empty:bool=_C)->PlanBuilder:return self.context.plan_builder(**self._plan_builder_options(environment=environment,select=select,exclude=exclude,full_refresh=full_refresh,empty=empty))
	def _selected_models(self,select:t.Optional[t.List[str]]=_A,exclude:t.Optional[t.List[str]]=_A,models:t.Optional[t.List[str]]=_A,resource_type:t.Optional[str]=_A)->t.Dict[str,Model]:
		if(vulcan_selector:=selectors.to_vulcan(*selectors.consolidate(select or[],exclude or[],models or[],resource_type))):
			if self.debug:self.console.print(f"dbt --select: {select}");self.console.print(f"dbt --exclude: {exclude}");self.console.print(f"vulcan equivalent: '{vulcan_selector}'")
			model_selector=self.context._new_selector();selected_models={fqn:model for(fqn,model)in self.context.models.items()if fqn in model_selector.expand_model_selections([vulcan_selector])}
		else:selected_models=dict(self.context.models)
		return selected_models
	def _plan_builder_options(self,select:t.Optional[t.List[str]]=_A,exclude:t.Optional[t.List[str]]=_A,empty:bool=_C,full_refresh:bool=_C,environment:t.Optional[str]=_A)->t.Dict[str,t.Any]:
		import vulcan.core.constants as c;select_models=_A
		if(vulcan_selector:=selectors.to_vulcan(select or[],exclude or[])):select_models=[vulcan_selector]
		is_dev=environment and environment!=c.PROD;is_prod=not is_dev;options:t.Dict[str,t.Any]={}
		if is_prod or is_dev and select_models:options.update(dict(run=_B,ignore_cron=_B))
		if is_dev:options.update(dict(include_unmodified=_C,create_from=c.PROD,enable_preview=_B))
		if empty:
			options['skip_backfill']=_B;self.console.log_warning("dbt's `--empty` drops the tables for all selected models and replaces them with empty ones.\nThis can easily result in accidental data loss, so Vulcan limits this to only new or modified models and leaves the tables for existing unmodified models alone.\n\nIf you were creating empty tables to preview model changes, please consider using `--environment` to preview these changes in an isolated Virtual Data Environment instead.\n\nOtherwise, if you really do want dbt's `--empty` behaviour of clearing every selected table, please file an issue on GitHub so we can better understand the use-case.\n")
			if full_refresh:raise ValueError('`--full-refresh` alongside `--empty` is not currently supported.')
		if full_refresh:options.update(dict(restate_models=[m.dbt_fqn for m in self.context.models.values()if m.dbt_fqn]if not select_models else select_models,always_include_local_changes=_B))
		return dict(environment=environment,select_models=select_models,**options)
	@property
	def console(self)->DbtCliConsole:
		console=self.context.console;from vulcan_dbt.console import DbtCliConsole
		if not isinstance(console,DbtCliConsole):raise ValueError(f"Expecting dbt cli console, got: {console}")
		return console
	def close(self)->_A:self.context.close()
def create(project_dir:t.Optional[Path]=_A,profiles_dir:t.Optional[Path]=_A,profile:t.Optional[str]=_A,target:t.Optional[str]=_A,vars:t.Optional[t.Dict[str,t.Any]]=_A,threads:t.Optional[int]=_A,debug:bool=_C,log_level:t.Optional[str]=_A)->DbtOperations:
	with Progress(transient=_B)as progress:
		load_task_id=progress.add_task('Loading engine',total=_A);from vulcan import configure_logging;from vulcan.core.context import Context;from vulcan.dbt.loader import DbtLoader;from vulcan.core.console import set_console;from vulcan_dbt.console import DbtCliConsole;from vulcan.utils.errors import VulcanError;from vulcan.core.selector import DbtSelector;root_logger=logging.getLogger()
		while root_logger.hasHandlers():root_logger.removeHandler(root_logger.handlers[0])
		configure_logging(force_debug=debug,log_level=log_level);set_console(DbtCliConsole());progress.update(load_task_id,description='Loading project',total=_A);project_dir=project_dir or Path.cwd();init_project_if_required(project_dir);vulcan_context=Context(paths=[project_dir],config_loader_kwargs=dict(profile=profile,target=target,variables=vars,threads=threads,profiles_dir=profiles_dir),load=_B,selector=DbtSelector);dbt_loader=vulcan_context._loaders[0]
		if not isinstance(dbt_loader,DbtLoader):raise VulcanError(f"Unexpected loader type: {type(dbt_loader)}")
		dbt_project=dbt_loader._projects[0];return DbtOperations(vulcan_context,dbt_project,debug=debug)
def init_project_if_required(project_dir:Path,start:t.Optional[str]=_A)->_A:
	from vulcan.cli.project_init import init_example_project,ProjectTemplate;from vulcan.core.config.common import ALL_CONFIG_FILENAMES;from vulcan.core.console import get_console
	if not any(f.exists()for f in[project_dir/file for file in ALL_CONFIG_FILENAMES]):get_console().log_warning('No existing Vulcan config detected; creating one');init_example_project(path=project_dir,engine_type=_A,template=ProjectTemplate.DBT,start=start)