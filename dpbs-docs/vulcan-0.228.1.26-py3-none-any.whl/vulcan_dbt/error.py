import typing as t,logging
from functools import wraps
import click,sys
logger=logging.getLogger(__name__)
def cli_global_error_handler(func:t.Callable[...,t.Any])->t.Callable[...,t.Any]:
	@wraps(func)
	def wrapper(*args:t.List[t.Any],**kwargs:t.Any)->t.Any:
		try:return func(*args,**kwargs)
		except Exception as ex:
			from vulcan.utils.errors import VulcanError;from sqlglot.errors import SqlglotError
			if isinstance(ex,(VulcanError,SqlglotError,ValueError)):click.echo(click.style('Error: '+str(ex),fg='red'));sys.exit(1)
			else:raise
	return wrapper
class ErrorHandlingGroup(click.Group):
	def add_command(self,cmd:click.Command,name:t.Optional[str]=None)->None:
		if cmd.callback:cmd.callback=cli_global_error_handler(cmd.callback)
		super().add_command(cmd,name=name)