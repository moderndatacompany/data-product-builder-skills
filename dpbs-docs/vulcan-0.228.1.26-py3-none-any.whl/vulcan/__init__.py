from __future__ import annotations
_C=True
_B=False
_A=None
import glob,logging,os,sys,typing as t
from datetime import datetime
from enum import Enum
from pathlib import Path
from vulcan.core.dialect import extend_sqlglot
extend_sqlglot()
from vulcan.core import constants as c
from vulcan.core.config import Config as Config
from vulcan.core.context import Context as Context,ExecutionContext as ExecutionContext
from vulcan.core.engine_adapter import EngineAdapter as EngineAdapter
from vulcan.core.macros import SQL as SQL,macro as macro
from vulcan.core.model import Model as Model,asset as asset,model as model
from vulcan.core.signal import signal as signal
from vulcan.core.snapshot import Snapshot as Snapshot
from vulcan.core.snapshot.evaluator import CustomMaterialization as CustomMaterialization
from vulcan.core.model.kind import CustomKind as CustomKind
from vulcan.core.model.kind import ModelKindName as ModelKindName
from vulcan.core.linter.rule import Rule as Rule,RuleViolation as RuleViolation
from vulcan.utils import debug_mode_enabled as debug_mode_enabled,enable_debug_mode as enable_debug_mode,str_to_bool
from vulcan.utils.errors import ConfigError as ConfigError
from vulcan.utils.errors import rebrand
from vulcan.utils.date import DatetimeRanges as DatetimeRanges
from vulcan.utils.pydantic import list_of_fields_validator as list_of_fields_validator
try:from vulcan._version import __version__ as __version__,__version_tuple__ as __version_tuple__
except ImportError:pass
if t.TYPE_CHECKING:from vulcan.core.engine_adapter._typing import QueryOrDF
class RuntimeEnv(str,Enum):
	TERMINAL='terminal';DATABRICKS='databricks';GOOGLE_COLAB='google_colab';JUPYTER='jupyter';DEBUGGER='debugger';CI='ci'
	@classmethod
	def get(cls)->RuntimeEnv:
		runtime_env_var=os.getenv('SQLMESH_RUNTIME_ENVIRONMENT')
		if runtime_env_var:
			try:return RuntimeEnv(runtime_env_var)
			except ValueError:valid_values=[f'"{member.value}"'for member in RuntimeEnv];raise ValueError(f"Invalid SQLMESH_RUNTIME_ENVIRONMENT value: {runtime_env_var}. Must be one of {', '.join(valid_values)}.")
		try:
			shell=get_ipython()
			if os.getenv('DATABRICKS_RUNTIME_VERSION'):return RuntimeEnv.DATABRICKS
			if'google.colab'in str(shell.__class__):return RuntimeEnv.GOOGLE_COLAB
			if shell.__class__.__name__=='ZMQInteractiveShell':return RuntimeEnv.JUPYTER
		except NameError:pass
		if debug_mode_enabled():return RuntimeEnv.DEBUGGER
		if is_cicd_environment()or not is_interactive_environment():return RuntimeEnv.CI
		return RuntimeEnv.TERMINAL
	@property
	def is_terminal(self)->bool:return self==RuntimeEnv.TERMINAL
	@property
	def is_databricks(self)->bool:return self==RuntimeEnv.DATABRICKS
	@property
	def is_jupyter(self)->bool:return self==RuntimeEnv.JUPYTER
	@property
	def is_google_colab(self)->bool:return self==RuntimeEnv.GOOGLE_COLAB
	@property
	def is_ci(self)->bool:return self==RuntimeEnv.CI
	@property
	def is_notebook(self)->bool:return not self.is_terminal and not self.is_ci
def is_cicd_environment()->bool:
	for key in('CI','GITHUB_ACTIONS','TRAVIS','CIRCLECI','GITLAB_CI','BUILDKITE'):
		if str_to_bool(os.environ.get(key,'false')):return _C
	return _B
def is_interactive_environment()->bool:
	if sys.stdin is _A or sys.stdout is _A:return _B
	return sys.stdin.isatty()and sys.stdout.isatty()
if RuntimeEnv.get().is_notebook:
	try:from vulcan.magics import register_magics;register_magics()
	except ImportError:pass
LOG_FORMAT='%(asctime)s - %(threadName)s - %(name)s - %(levelname)s - %(message)s (%(filename)s:%(lineno)d)'
LOG_FILENAME_PREFIX='vulcan_'
class CustomFormatter(logging.Formatter):
	grey='\x1b[38;20m';yellow='\x1b[33;20m';red='\x1b[31;20m';bold_red='\x1b[31;1m';reset='\x1b[0m';FORMATS={logging.DEBUG:grey+LOG_FORMAT+reset,logging.INFO:grey+LOG_FORMAT+reset,logging.WARNING:yellow+LOG_FORMAT+reset,logging.ERROR:red+LOG_FORMAT+reset,logging.CRITICAL:bold_red+LOG_FORMAT+reset}
	def format(self,record:logging.LogRecord)->str:log_fmt=self.FORMATS.get(record.levelno);formatter=logging.Formatter(log_fmt);formatted=formatter.format(record);return rebrand(formatted)
class FileFormatter(logging.Formatter):
	def format(self,record:logging.LogRecord)->str:return rebrand(super().format(record))
def remove_excess_logs(log_file_dir:t.Optional[t.Union[str,Path]]=_A,log_limit:int=c.DEFAULT_LOG_LIMIT)->_A:
	if log_limit<=0:return
	log_file_dir=log_file_dir or c.DEFAULT_LOG_FILE_DIR;log_path_prefix=Path(log_file_dir)/LOG_FILENAME_PREFIX
	for path in list(sorted(glob.glob(f"{log_path_prefix}*.log"),reverse=_C))[log_limit:]:
		try:os.remove(path)
		except FileNotFoundError:pass
		except OSError:pass
def configure_logging(force_debug:bool=_B,write_to_stdout:bool=_B,write_to_file:bool=_C,log_file_dir:t.Optional[t.Union[str,Path]]=_A,ignore_warnings:bool=_B,log_level:t.Optional[t.Union[str,int]]=_A)->_A:
	A='GRPC_VERBOSITY';os.environ[A]=os.environ.get(A,'NONE');logger=logging.getLogger();debug=force_debug or debug_mode_enabled()
	if log_level is not _A:
		if isinstance(log_level,str):level=logging._nameToLevel.get(log_level.upper())or logging.INFO
		else:level=log_level
	else:level=logging.DEBUG if debug else logging.INFO
	logger.setLevel(level)
	if debug:logging.getLogger('snowflake.connector').setLevel(logging.INFO)
	if not debug:logging.getLogger('soda').setLevel(logging.WARNING);logging.getLogger('soda.scan').setLevel(logging.WARNING);logging.getLogger('soda.telemetry').setLevel(logging.WARNING);logging.getLogger('soda.telemetry.soda_telemetry').setLevel(logging.WARNING)
	if write_to_stdout:stdout_handler=logging.StreamHandler(sys.stdout);stdout_handler.setFormatter(CustomFormatter());stdout_handler.setLevel(logging.ERROR if ignore_warnings else level);logger.addHandler(stdout_handler)
	log_file_dir=log_file_dir or c.DEFAULT_LOG_FILE_DIR;log_path_prefix=Path(log_file_dir)/LOG_FILENAME_PREFIX
	if write_to_file:os.makedirs(str(log_file_dir),exist_ok=_C);filename=f"{log_path_prefix}{datetime.now().strftime('%Y_%m_%d_%H_%M_%S')}.log";file_handler=logging.FileHandler(filename,mode='w',encoding='utf-8');file_handler.setLevel(level);file_handler.setFormatter(FileFormatter(LOG_FORMAT));logger.addHandler(file_handler)
	if debug:
		import faulthandler;enable_debug_mode();faulthandler.enable()
		if hasattr(faulthandler,'register'):from signal import SIGUSR1;faulthandler.register(SIGUSR1.value)