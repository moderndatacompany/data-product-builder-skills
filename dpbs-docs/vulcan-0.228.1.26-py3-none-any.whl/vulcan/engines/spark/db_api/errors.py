class SparkDbApiError(Exception):0
class NotSupportedError(SparkDbApiError):0
class ProgrammingError(SparkDbApiError):0