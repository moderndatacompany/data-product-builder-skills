from __future__ import annotations
_t='compact'
_s='--build'
_r='--no-confirm'
_q='dialect'
_p='--format'
_o='--file'
_n='models'
_m='--model'
_l='--overwrite'
_k='--ignore-cron'
_j='--limit'
_i='--name'
_h='graphql'
_g='import_semantic_view'
_f='table_name'
_e='rollback'
_d='metadata'
_c='janitor'
_b='invalidate'
_a='environments'
_Z='destroy'
_Y='create_external_models'
_X='Environment to export (defaults to config default_target_environment). Requires the environment to exist in state (after plan).'
_W='pretty'
_V='down'
_U='sql'
_T='json'
_S='--migrate'
_R='select_model'
_Q='export'
_P='create_deploy_yaml'
_O='-e'
_N='utf-8'
_M='name'
_L='-o'
_K='model'
_J='migrate'
_I='--env'
_H='file'
_G='--select-model'
_F='environment'
_E='--environment'
_D='spark'
_C=False
_B=True
_A=None
import asyncio,json,logging,os,subprocess,sys,typing as t
from pathlib import Path
import click
from schema.auth import SecurityContext
from vulcan import configure_logging,remove_excess_logs
from vulcan.cli import error_handler
from vulcan.cli import options as opt
from vulcan.cli.project_init import InitCliMode,ProjectTemplate,init_example_project,interactive_init
from vulcan.core.config import load_configs
from vulcan.core.console import configure_console,get_console
from vulcan.core.context import Context
from vulcan.core.query.transpiler import RestQuery,get_transpiler_params_from_snapshots,make_transpiler_client
from vulcan.utils.pydantic import pydantic_to_yaml
from vulcan.utils.errors import TranspilerError
from vulcan.utils import Verbosity
from vulcan.utils.date import TimeLike
from vulcan.utils.errors import MissingDependencyError,VulcanError
from vulcan.utils.process import detect_docker_compose_command,get_host_ip
logger=logging.getLogger(__name__)
SKIP_LOAD_COMMANDS='clean',_P,_Y,_Z,_a,_b,_c,_d,_J,_e,'run',_f,_Q,'api',_g
SKIP_CONTEXT_COMMANDS='init','ui',_h,_P
def _vulcan_version()->str:
	try:from vulcan import __version__;return __version__
	except ImportError:return'0.0.0'
@click.group(no_args_is_help=_B)
@click.version_option(version=_vulcan_version(),message='%(version)s')
@opt.paths
@opt.config
@click.option('--gateway',type=str,help='The name of the gateway.',envvar='VULCAN_GATEWAY')
@click.option('--ignore-warnings',is_flag=_B,help='Ignore warnings.',envvar='VULCAN_IGNORE_WARNINGS')
@click.option('--debug',is_flag=_B,help='Enable debug mode.')
@click.option('--log-to-stdout',is_flag=_B,help='Display logs in stdout.')
@click.option('--log-file-dir',type=str,help='The directory to write log files to.')
@click.option('--dotenv',type=click.Path(exists=_B,path_type=Path),help='Path to a custom .env file to load environment variables.',envvar='VULCAN_DOTENV_PATH')
@click.pass_context
@error_handler
def cli(ctx:click.Context,paths:t.List[str],config:t.Optional[str]=_A,gateway:t.Optional[str]=_A,ignore_warnings:bool=_C,debug:bool=_C,log_to_stdout:bool=_B,log_file_dir:t.Optional[str]=_A,dotenv:t.Optional[Path]=_A)->_A:
	if'--help'in sys.argv:return
	configure_logging(debug,log_to_stdout,log_file_dir=log_file_dir,ignore_warnings=ignore_warnings);configure_console(ignore_warnings=ignore_warnings);load=_B
	if len(paths)==1:
		path=os.path.abspath(paths[0])
		if ctx.invoked_subcommand in SKIP_CONTEXT_COMMANDS:ctx.obj=path;return
		if ctx.invoked_subcommand in SKIP_LOAD_COMMANDS:load=_C
	configs=load_configs(config,Context.CONFIG_TYPE,paths,dotenv_path=dotenv);log_limit=list(configs.values())[0].log_limit;remove_excess_logs(log_file_dir,log_limit)
	try:context=Context(paths=paths,config=configs,gateway=gateway,load=load)
	except Exception:
		if debug:logger.exception('Failed to initialize Vulcan context')
		raise
	if load and not context.models:raise click.ClickException(f"`{paths}` doesn't seem to have any models... cd into the proper directory or specify the path(s) with -p.")
	ctx.obj=context
@cli.command('init')
@click.argument('engine',required=_C)
@click.option('-t','--template',type=str,help='Project template. Supported values: default, empty.')
@click.option('--tenant',type=str,help='Project tenant to write into config.yaml.')
@click.option(_i,'project_name',type=str,help='Project name to write into config.yaml.')
@click.option('--description',type=str,help='Project description to write into config.yaml.')
@click.pass_context
@error_handler
def init(ctx:click.Context,engine:t.Optional[str]=_A,template:t.Optional[str]=_A,tenant:t.Optional[str]=_A,project_name:t.Optional[str]=_A,description:t.Optional[str]=_A)->_A:
	project_template=_A
	if template:
		try:project_template=ProjectTemplate(template.lower())
		except ValueError:template_strings="', '".join([template.value for template in ProjectTemplate]);raise click.ClickException(f"Invalid project template '{template}'. Please specify one of '{template_strings}'.")
	if engine:init_example_project(path=ctx.obj,template=project_template or ProjectTemplate.DEFAULT,engine_type=engine,tenant=tenant,name=project_name,description=description);return
	import vulcan.utils.rich as srich;console=srich.console;project_template,engine_type,cli_mode=interactive_init(ctx.obj,console,project_template);config_path=init_example_project(path=ctx.obj,template=project_template,engine_type=engine_type,cli_mode=cli_mode or InitCliMode.DEFAULT,tenant=tenant,name=project_name,description=description);engine_install_text=''
	if engine_type and engine_type not in('duckdb','motherduck'):install_text='pyspark'if engine_type==_D else f"vulcan\\[{engine_type.replace('_','')}]"
	next_step_text=f"{engine_install_text}• Update your gateway connection settings (e.g., username/password) in the project configuration file:\n    {config_path}";console.print(f"""──────────────────────────────

Your Vulcan project is ready!

Next steps:
{next_step_text}
• Run command in CLI: vulcan plan
• (Optional) Explain a plan: vulcan plan --explain

Guide: https://tmdc-io.github.io/vulcan-book/guides

""")
@cli.command('render')
@click.argument(_K)
@opt.start_time
@opt.end_time
@opt.execution_time
@opt.expand
@click.option('--dialect',type=str,help='The SQL dialect to render the query as.')
@click.option('--no-format',is_flag=_B,help='Disable fancy formatting of the query.')
@opt.format_options
@click.pass_context
@error_handler
def render(ctx:click.Context,model:str,start:TimeLike,end:TimeLike,execution_time:t.Optional[TimeLike]=_A,expand:t.Optional[t.Union[bool,t.Iterable[str]]]=_A,dialect:t.Optional[str]=_A,no_format:bool=_C,**format_kwargs:t.Any)->_A:
	model=ctx.obj.get_model(model,raise_if_missing=_B);rendered=ctx.obj.render(model,start=start,end=end,execution_time=execution_time,expand=expand);format_config=ctx.obj.config_for_node(model).format;format_kwargs={**format_config.generator_options,**{k:v for(k,v)in format_kwargs.items()if v is not _A}};sql=rendered.sql(pretty=_B,dialect=ctx.obj.config.dialect if dialect is _A else dialect,**format_kwargs)
	if no_format:print(sql)
	else:ctx.obj.console.show_sql(sql)
@cli.command('evaluate')
@click.argument(_K)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option(_j,type=int,help='The number of rows which the query should be limited to.')
@click.pass_context
@error_handler
def evaluate(ctx:click.Context,model:str,start:TimeLike,end:TimeLike,execution_time:t.Optional[TimeLike]=_A,limit:t.Optional[int]=_A)->_A:
	df=ctx.obj.evaluate(model,start=start,end=end,execution_time=execution_time,limit=limit)
	if hasattr(df,'show'):df.show(limit)
	else:ctx.obj.console.log_success(df)
@cli.command('format')
@click.argument('paths',nargs=-1)
@click.option('-t','--transpile',type=str,help='Transpile project models to the specified dialect.')
@click.option('--check',is_flag=_B,help='Whether or not to check formatting (but not actually format anything).',default=_A)
@click.option('--rewrite-casts/--no-rewrite-casts',is_flag=_B,help='Rewrite casts to use the :: syntax.',default=_A)
@click.option('--append-newline',is_flag=_B,help='Include a newline at the end of each file.',default=_A)
@opt.format_options
@click.pass_context
@error_handler
def format(ctx:click.Context,paths:t.Optional[t.Tuple[str,...]]=_A,**kwargs:t.Any)->_A:
	if not ctx.obj.format(**{k:v for(k,v)in kwargs.items()if v is not _A},paths=paths):ctx.exit(1)
@cli.command('diff')
@click.argument(_F)
@click.pass_context
@error_handler
def diff(ctx:click.Context,environment:t.Optional[str]=_A)->_A:
	if ctx.obj.diff(environment,detailed=_B):exit(1)
@cli.command('plan')
@click.argument(_F,required=_C)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option('--create-from',type=str,help="The environment to create the target environment from if it doesn't exist. Default: prod.")
@click.option('--skip-tests',is_flag=_B,help='Skip tests prior to generating the plan if they are defined.',default=_A)
@click.option('--skip-linter',is_flag=_B,help='Skip linting prior to generating the plan if the linter is enabled.',default=_A)
@click.option('--restate-model','-r',type=str,multiple=_B,help='Restate data for specified models and models downstream from the one specified. For production environment, all related model versions will have their intervals wiped, but only the current versions will be backfilled. For development environment, only the current model versions will be affected.')
@click.option('--no-gaps',is_flag=_B,help='Ensure that new snapshots have no data gaps when comparing to existing snapshots for matching models in the target environment.',default=_A)
@click.option('--skip-backfill','--dry-run',is_flag=_B,help='Skip the backfill step and only create a virtual update for the plan.',default=_A)
@click.option('--empty-backfill',is_flag=_B,help='Produce empty backfill. Like --skip-backfill no models will be backfilled, unlike --skip-backfill missing intervals will be recorded as if they were backfilled.',default=_A)
@click.option('--forward-only',is_flag=_B,help='Create a plan for forward-only changes.',default=_A)
@click.option('--allow-destructive-model',type=str,multiple=_B,help='Allow destructive forward-only changes to models whose names match the expression.')
@click.option('--allow-additive-model',type=str,multiple=_B,help='Allow additive forward-only changes to models whose names match the expression.')
@click.option('--effective-from',type=str,required=_C,help='The effective date from which to apply forward-only changes on production.')
@click.option('--no-prompts',is_flag=_B,help='Disable interactive prompts for the backfill time range. Please note that if this flag is set and there are uncategorized changes, plan creation will fail.',default=_A)
@click.option('--auto-apply',is_flag=_B,help='Automatically apply the new plan after creation.',default=_A)
@click.option('--no-auto-categorization',is_flag=_B,help='Disable automatic change categorization.',default=_A)
@click.option('--include-unmodified',is_flag=_B,help='Include unmodified models in the target environment.',default=_A)
@click.option(_G,type=str,multiple=_B,help='Select specific model changes that should be included in the plan.')
@click.option('--backfill-model',type=str,multiple=_B,help='Backfill only the models whose names match the expression.')
@click.option('--no-diff',is_flag=_B,help='Hide text differences for changed models.',default=_A)
@click.option('--run',is_flag=_B,help='Run latest intervals as part of the plan application (prod environment only).',default=_A)
@click.option('--enable-preview',is_flag=_B,help='Enable preview for forward-only models when targeting a development environment.',default=_A)
@click.option('--diff-rendered',is_flag=_B,help='Output text differences for the rendered versions of the models and standalone audits.',default=_A)
@click.option('--explain',is_flag=_B,help='Explain the plan instead of applying it.',default=_A)
@click.option(_k,is_flag=_B,help='Run all missing intervals, ignoring individual cron schedules. Only applies if --run is set.',default=_A)
@click.option('--min-intervals',default=0,help='For every model, ensure at least this many intervals are covered by a missing intervals check regardless of the plan start date')
@click.option(_S,is_flag=_B,help='Run state migration before planning.')
@opt.verbose
@click.pass_context
@error_handler
def plan(ctx:click.Context,verbose:int,environment:t.Optional[str]=_A,**kwargs:t.Any)->_A:
	context=ctx.obj
	try:
		restate_models=kwargs.pop('restate_model')or _A;select_models=kwargs.pop(_R)or _A;allow_destructive_models=kwargs.pop('allow_destructive_model')or _A;allow_additive_models=kwargs.pop('allow_additive_model')or _A;backfill_models=kwargs.pop('backfill_model')or _A;ignore_cron=kwargs.pop('ignore_cron')or _A;setattr(get_console(),'verbosity',Verbosity(verbose))
		if kwargs.pop(_J,_C):context.migrate()
		context.plan(environment,restate_models=restate_models,select_models=select_models,allow_destructive_models=allow_destructive_models,allow_additive_models=allow_additive_models,backfill_models=backfill_models,ignore_cron=ignore_cron,**kwargs)
	finally:context.close()
@cli.command('run')
@click.argument(_F,required=_C)
@opt.start_time
@opt.end_time
@opt.execution_time
@click.option('--skip-janitor',is_flag=_B,help='Skip the janitor task.')
@click.option(_k,is_flag=_B,help='Run for all missing intervals, ignoring individual cron schedules.')
@click.option(_G,type=str,multiple=_B,help='Select specific models to run. Note: this always includes upstream dependencies.')
@click.option('--exit-on-env-update',type=int,help='If set, the command will exit with the specified code if the run is interrupted by an update to the target environment.')
@click.option('--no-auto-upstream',is_flag=_B,help='Do not automatically include upstream models. Only applicable when --select-model is used. Note: this may result in missing / invalid data for the selected models.')
@click.option(_S,is_flag=_B,help='Run state migration before run.')
@click.pass_context
@error_handler
def run(ctx:click.Context,environment:t.Optional[str]=_A,**kwargs:t.Any)->_A:
	context=ctx.obj
	try:
		select_models=kwargs.pop(_R)or _A
		if kwargs.pop(_J,_C):context.migrate()
		completion_status=context.run(environment,select_models=select_models,**kwargs)
		if completion_status.is_failure:raise click.ClickException('Run failed.')
	finally:context.close()
@cli.command(_b)
@click.argument(_F,required=_B)
@click.option('--sync','-s',is_flag=_B,help='Wait for the environment to be deleted before returning. If not specified, the environment will be deleted asynchronously by the janitor process. This option requires a connection to the data warehouse.')
@click.pass_context
@error_handler
def invalidate(ctx:click.Context,environment:str,**kwargs:t.Any)->_A:context=ctx.obj;context.invalidate_environment(environment,**kwargs)
@cli.command(_c)
@click.option('--ignore-ttl',is_flag=_B,help="Cleanup snapshots that are not referenced in any environment, regardless of when they're set to expire")
@click.pass_context
@error_handler
def janitor(ctx:click.Context,ignore_ttl:bool,**kwargs:t.Any)->_A:ctx.obj.run_janitor(ignore_ttl,**kwargs)
@cli.command(_Z)
@click.pass_context
@error_handler
def destroy(ctx:click.Context,**kwargs:t.Any)->_A:ctx.obj.destroy(**kwargs)
@cli.group(invoke_without_command=_B,no_args_is_help=_C)
@click.pass_context
def graph(ctx:click.Context)->_A:
	if ctx.invoked_subcommand is _A:ctx.invoke(graph_dag,file=_A,select_model=tuple())
@graph.command('dag')
@click.argument(_H,required=_C)
@click.option(_G,type=str,multiple=_B,help='Select specific models to include in the dag.')
@click.pass_obj
@error_handler
def graph_dag(obj:Context,file:t.Optional[str],select_model:t.Tuple[str,...])->_A:
	outfile=file or'dag.html';rendered=obj.render_dag(outfile,select_model if select_model else _A)
	if rendered:obj.console.log_success(f"Generated the dag to {rendered}")
@graph.command('joins')
@click.argument(_H,required=_C)
@click.pass_obj
@error_handler
def graph_join(obj:Context,file:t.Optional[str])->_A:
	outfile=file or'joins.html';out_path=obj.render_joins_graph(outfile)
	if out_path:obj.console.log_success(f"Generated the semantic joins graph to {out_path}")
@cli.command('create_test')
@click.argument(_K)
@click.option('-q','--query','queries',type=(str,str),multiple=_B,default=[],help="Queries that will be used to generate data for the model's dependencies.")
@click.option(_L,_l,'overwrite',is_flag=_B,default=_C,help='When true, the fixture file will be overwritten in case it already exists.')
@click.option('-v','--var','variables',type=(str,str),multiple=_B,help='Key-value pairs that will define variables needed by the model.')
@click.option('-p','--path','path',help="The file path corresponding to the fixture, relative to the test directory. By default, the fixture will be created under the test directory and the file name will be inferred based on the test's name.")
@click.option('-n',_i,_M,help="The name of the test that will be created. By default, it's inferred based on the model's name.")
@click.option('--include-ctes','include_ctes',is_flag=_B,default=_C,help='When true, CTE fixtures will also be generated.')
@click.pass_obj
@error_handler
def create_test(obj:Context,model:str,queries:t.List[t.Tuple[str,str]],overwrite:bool=_C,variables:t.Optional[t.List[t.Tuple[str,str]]]=_A,path:t.Optional[str]=_A,name:t.Optional[str]=_A,include_ctes:bool=_C)->_A:obj.create_test(model,input_queries=dict(queries),overwrite=overwrite,variables=dict(variables)if variables else _A,path=path,name=name,include_ctes=include_ctes)
@cli.command('test')
@opt.match_pattern
@opt.verbose
@click.option('--preserve-fixtures',is_flag=_B,default=_C,help='Preserve the fixture tables in the testing database, useful for debugging.')
@click.argument('tests',nargs=-1)
@click.pass_obj
@error_handler
def test(obj:Context,k:t.List[str],verbose:int,preserve_fixtures:bool,tests:t.List[str])->_A:
	result=obj.test(match_patterns=k,tests=tests,verbosity=Verbosity(verbose),preserve_fixtures=preserve_fixtures)
	if not result.wasSuccessful():exit(1)
@cli.command('audit')
@click.option(_m,_n,multiple=_B,help='A model to audit. Multiple models can be audited.')
@opt.start_time
@opt.end_time
@opt.execution_time
@click.pass_obj
@error_handler
def audit(obj:Context,models:t.Iterator[str],start:TimeLike,end:TimeLike,execution_time:t.Optional[TimeLike]=_A)->_A:
	if not obj.audit(models=models,start=start,end=end,execution_time=execution_time):exit(1)
@cli.command('check_intervals')
@click.option('--no-signals',is_flag=_B,help='Disable signal checks and only show missing intervals.',default=_C)
@click.argument(_F,required=_C)
@click.option(_G,type=str,multiple=_B,help='Select specific models to show missing intervals for.')
@opt.start_time
@opt.end_time
@click.pass_context
@error_handler
def check_intervals(ctx:click.Context,environment:t.Optional[str],no_signals:bool,select_model:t.List[str],start:TimeLike,end:TimeLike)->_A:context=ctx.obj;context.console.show_intervals(context.check_intervals(environment,no_signals=no_signals,select_models=select_model,start=start,end=end))
@cli.command('fetchdf')
@click.argument(_U,required=_C)
@click.option(_o,'-f',type=click.File('r'),default=_A,help="Read SQL from file. Use '-' to read from stdin.")
@click.option(_p,'output_format',type=click.Choice(['table','csv',_T,'raw'],case_sensitive=_C),default='table',help="Output format: 'table' (formatted table), 'csv' (CSV), 'json' (JSON), 'raw' (simple table).")
@click.pass_context
@error_handler
def fetchdf(ctx:click.Context,sql:t.Optional[str],file:t.Optional[t.TextIO],output_format:str)->_A:
	import sys,pandas as pd;context=ctx.obj
	if file:sql_query=file.read()
	elif sql:sql_query=sql
	else:sql_query=sys.stdin.read()
	if not sql_query or not sql_query.strip():raise click.ClickException('No SQL query provided. Provide SQL as argument, --file, or via stdin.')
	df=context.fetchdf(sql_query);is_piped=not sys.stdout.isatty()
	if output_format.lower()=='csv':df.to_csv(sys.stdout,index=_C)
	elif output_format.lower()==_T:df.to_json(sys.stdout,orient='records',indent=2,date_format='iso')
	elif output_format.lower()=='raw':context.console.log_success(df)
	elif is_piped:df.to_csv(sys.stdout,index=_C)
	else:
		from rich.table import Table as RichTable;console=get_console();table=RichTable(show_header=_B,header_style='bold magenta')
		for col in df.columns:table.add_column(str(col))
		def _format_table_cell(val:t.Any)->str:
			A='NULL'
			if val is _A:return A
			if pd.api.types.is_list_like(val)and not isinstance(val,(str,bytes,dict)):return str(val)
			return str(val)if pd.notna(val)else A
		max_rows=1000
		for(idx,row)in df.head(max_rows).iterrows():table.add_row(*[_format_table_cell(val)for val in row])
		console.console.print(table)
		if len(df)>max_rows:console.console.print(f"\n[dim]Showing {max_rows} of {len(df)} rows. Use --format raw|csv|json to export all rows.[/dim]")
@cli.command('info')
@click.option('--skip-connection',is_flag=_B,help='Skip the connection test.')
@opt.verbose
@click.pass_obj
@error_handler
def info(obj:Context,skip_connection:bool,verbose:int)->_A:obj.print_info(skip_connection=skip_connection,verbosity=Verbosity(verbose))
@cli.command(_J)
@click.pass_context
@error_handler
def migrate(ctx:click.Context)->_A:ctx.obj.migrate()
@cli.command(_e)
@click.pass_obj
@error_handler
def rollback(obj:Context)->_A:obj.rollback()
@cli.command(_Y)
@click.option('--strict',is_flag=_B,help='Raise an error if the external model is missing in the database')
@click.pass_obj
@error_handler
def create_external_models(obj:Context,**kwargs:t.Any)->_A:obj.create_external_models(**kwargs)
@cli.command('table_diff')
@click.argument('source_to_target',required=_B,metavar='SOURCE:TARGET')
@click.argument(_K,required=_C)
@click.option(_L,'--on',type=str,multiple=_B,help='The column to join on. Can be specified multiple times. The model grain will be used if not specified.')
@click.option('-s','--skip-columns',type=str,multiple=_B,help='The column(s) to skip when comparing the source and target table.')
@click.option('--where',type=str,help='An optional where statement to filter results.')
@click.option(_j,type=int,default=20,help='The limit of the sample dataframe.')
@click.option('--show-sample',is_flag=_B,help='Show a sample of the rows that differ. With many columns, the output can be very wide.')
@click.option('-d','--decimals',type=int,default=3,help='The number of decimal places to keep when comparing floating point columns. Default: 3')
@click.option('--skip-grain-check',is_flag=_B,help='Disable the check for a primary key (grain) that is missing or is not unique.')
@click.option('--warn-grain-check',is_flag=_B,help='Warn if any selected model is missing a grain, and compute diffs for the remaining models.')
@click.option('--temp-schema',type=str,help='Schema used for temporary tables. It can be `CATALOG.SCHEMA` or `SCHEMA`. Default: `vulcan_temp`')
@click.option(_G,'-m',type=str,multiple=_B,help="Specify one or more models to data diff. Use wildcards to diff multiple models. Ex: '*' (all models with applied plan diffs), 'demo.model+' (this and downstream models), 'git:feature_branch' (models with direct modifications in this branch only)")
@click.option('--schema-diff-ignore-case',is_flag=_B,help="If set, when performing a schema diff the case of column names is ignored when matching between the two schemas. For example, 'col_a' in the source schema and 'COL_A' in the target schema will be treated as the same column.")
@click.pass_obj
@error_handler
def table_diff(obj:Context,source_to_target:str,model:t.Optional[str],**kwargs:t.Any)->_A:
	source,target=source_to_target.split(':');select_model=kwargs.pop(_R,_A)
	if model and select_model:raise VulcanError('The --select-model option cannot be used together with a model argument. Please choose one of them.')
	select_models={model}if model else select_model;obj.table_diff(source=source,target=target,select_models=select_models,**kwargs)
@cli.command('clean')
@click.pass_obj
@error_handler
def clean(obj:Context)->_A:obj.clear_caches()
@cli.command(_f)
@click.argument('model_name',required=_B)
@click.option(_E,_I,help='The environment to source the model version from.')
@click.option('--prod',is_flag=_B,default=_C,help='If set, return the name of the physical table that will be used in production for the model version promoted in the target environment.')
@click.pass_obj
@error_handler
def table_name(obj:Context,model_name:str,environment:t.Optional[str]=_A,prod:bool=_C)->_A:print(obj.table_name(model_name,environment,prod))
@cli.command(_a)
@click.pass_obj
@error_handler
def environments(obj:Context)->_A:obj.print_environment_names()
@cli.command('snapshots')
@click.pass_obj
@error_handler
def snapshots_dump(obj:Context)->_A:
	def _model_dump_json_with_derived(model:t.Any)->t.Dict[str,t.Any]:
		A='depends_on';data=model.model_dump(mode=_T,by_alias=_B);dialect=getattr(model,_q,_A)
		try:
			deps=getattr(model,A,_A)
			if deps is not _A:data[A]=sorted(deps)
		except Exception as exc:logger.debug('Could not derive depends_on for model dump: %s',exc)
		try:
			ctt=getattr(model,'columns_to_types',_A)
			if ctt is not _A:data['columns']={col:dtype.sql(dialect=dialect)if hasattr(dtype,_U)else str(dtype)for(col,dtype)in sorted(ctt.items())}
		except Exception as exc:logger.debug('Could not derive columns for model dump: %s',exc)
		return data
	payload={name:_model_dump_json_with_derived(model)for(name,snapshot)in sorted(obj.snapshots.items())if(model:=snapshot.model_or_none)is not _A};click.echo(json.dumps(payload,indent=2,ensure_ascii=_C))
@cli.command('lint')
@click.option('--models',_m,multiple=_B,help='A model to lint. Multiple models can be linted. If no models are specified, every model will be linted.')
@click.pass_obj
@error_handler
def lint(obj:Context,models:t.Iterator[str])->_A:obj.lint_models(models)
@cli.group(no_args_is_help=_B)
def state()->_A:0
@state.command(_Q)
@click.option(_L,'--output-file',required=_B,help='Path to write the state export to',type=click.Path(dir_okay=_C,writable=_B,path_type=Path))
@click.option(_E,multiple=_B,help='Name of environment to export. Specify multiple --environment arguments to export multiple environments')
@click.option('--local',is_flag=_B,help='Export local state only. Note that the resulting file will not be importable')
@click.option(_r,is_flag=_B,help='Do not prompt for confirmation before exporting existing state')
@click.pass_obj
@error_handler
def state_export(obj:Context,output_file:Path,environment:t.Optional[t.Tuple[str]],local:bool,no_confirm:bool)->_A:
	confirm=not no_confirm
	if environment and local:raise click.ClickException('Cannot specify both --environment and --local')
	environment_names=list(environment)if environment else _A;obj.export_state(output_file=output_file,environment_names=environment_names,local_only=local,confirm=confirm)
@state.command('import')
@click.option('-i','--input-file',help='Path to the state file',required=_B,type=click.Path(exists=_B,dir_okay=_C,readable=_B,path_type=Path))
@click.option('--replace',is_flag=_B,help='Clear the remote state before loading the file. If omitted, a merge is performed instead')
@click.option(_r,is_flag=_B,help='Do not prompt for confirmation before updating existing state')
@click.pass_obj
@error_handler
def state_import(obj:Context,input_file:Path,replace:bool,no_confirm:bool)->_A:confirm=not no_confirm;obj.import_state(input_file=input_file,clear=replace,confirm=confirm)
@cli.command('api')
@click.option('--host',type=str,default='0.0.0.0',help='Bind socket to this host. Default: 0.0.0.0')
@click.option('--port',type=int,default=8000,help='Bind socket to this port. Default: 8000')
@click.option('--reload',is_flag=_B,default=_C,help='Enable auto-reload on file changes. Default: False')
@click.option(_S,is_flag=_B,default=_C,help='Run state migration before starting the API server.')
@click.pass_context
@error_handler
def api(ctx:click.Context,host:str,port:int,reload:bool,migrate:bool)->_A:
	A='debug';from vulcan.core.console import get_console
	try:import uvicorn
	except ModuleNotFoundError as e:raise MissingDependencyError("Missing API dependencies. Run `pip install -e '.[api]'` to install them.")from e
	if isinstance(ctx.obj,Context):project_path=str(ctx.obj.path);console=ctx.obj.console
	else:project_path=str(ctx.obj);console=get_console()
	parent_params=ctx.parent.params if ctx.parent else{};config=parent_params.get('config');gateway=parent_params.get('gateway');log_level=A if parent_params.get(A,_C)else'info';os.environ['PROJECT_PATH']=project_path;os.environ['LOG_LEVEL']=log_level.upper()
	if config:os.environ['CONFIG']=config
	if gateway:os.environ['GATEWAY']=gateway
	if migrate:
		if not isinstance(ctx.obj,Context):raise click.ClickException('--migrate requires a fully initialized context.')
		ctx.obj.migrate()
	console.log_success(f"Starting API server on http://{host}:{port} \n"+f"OpenAPI docs available at http://{host}:{port}/redoc and http://{host}:{port}/scalar");uvicorn.run('api.app:app',host=host,port=port,log_level=log_level,reload=reload,workers=1,timeout_keep_alive=300,ws='none')
def _run_compose_service(*,service_name:str,compose_rel_path:Path,subcommand:str,no_detach:bool,extra_env:t.Dict[str,str],build:bool=_C)->_A:
	A='Docker executable not found. Please install Docker and ensure it is on your PATH.';console=get_console()
	try:cmd_base=detect_docker_compose_command()
	except RuntimeError as e:raise click.ClickException(str(e))
	module_root=Path(__file__).resolve().parents[2];compose_path=module_root/compose_rel_path
	if not compose_path.exists():raise click.ClickException(f"{service_name} docker-compose file not found at '{compose_path}'.")
	env=os.environ.copy();env.update(extra_env)
	if subcommand=='up':
		cmd:t.List[str]=cmd_base+['-f',str(compose_path),'up']
		if not no_detach:cmd.append('-d')
		if build:cmd.append(_s);cmd.append('--force-recreate')
		console.log_success('Starting %s ...'%service_name)
		try:subprocess.run(cmd,env=env,check=_B)
		except FileNotFoundError as e:raise click.ClickException(A)from e
		except subprocess.CalledProcessError as e:raise click.ClickException('Failed to start %s via docker compose (exit code %s).'%(service_name,e.returncode))from e
		console.log_success('%s started.'%service_name)
	elif subcommand==_V:
		cmd=cmd_base+['-f',str(compose_path),_V];console.log_success('Stopping %s ...'%service_name)
		try:subprocess.run(cmd,env=env,check=_B)
		except FileNotFoundError as e:raise click.ClickException(A)from e
		except subprocess.CalledProcessError as e:raise click.ClickException('Failed to stop %s via docker compose (exit code %s).'%(service_name,e.returncode))from e
		console.log_success('%s stopped.'%service_name)
@cli.command(_h)
@click.argument('subcommand',type=click.Choice(['up',_V]))
@click.option('--no-detach',is_flag=_B,default=_C,help='Run docker compose in the foreground (omit -d).')
@click.option(_s,is_flag=_B,default=_C,help='Build images before starting containers. Automatically adds --force-recreate.')
@click.pass_context
@error_handler
def graphql(ctx:click.Context,subcommand:str,no_detach:bool,build:bool)->_A:host_ip=get_host_ip();extra_env={'VULCAN_API_URL':f"http://{host_ip}:8000"};_run_compose_service(service_name='GraphQL',compose_rel_path=Path('docker')/'compose'/'docker-compose.graphql.yml',subcommand=subcommand,no_detach=no_detach,extra_env=extra_env,build=build)
@cli.command('transpile')
@click.argument('query',required=_C)
@click.option(_p,'fmt',type=click.Choice([_U,'rest'],case_sensitive=_C),required=_B,help="Input type: semantic SQL ('sql') or REST-style semantic payload ('rest').")
@click.option(_o,'query_file',type=str,help="Read query or REST payload from file. Use '-' to read from stdin.")
@click.option('--user',type=str,default=_A,help="User id to propagate in the X-User header (defaults to 'cli').")
@click.option('--security-context',multiple=_B,help='Security context attribute as key=value. Repeatable (e.g. group=alpha, country=US).')
@click.option('--disable-post-processing',is_flag=_B,default=_C,help='Disable post-processing in the Transpiler.')
@click.option('--style',type=click.Choice([_W,_t],case_sensitive=_C),help="SQL output style: 'pretty' (formatted with indentation), 'compact' (unformatted but processed), ")
@click.option(_E,_I,_O,type=str,default=_A,help="Environment to use (default: config's default_target_environment). Requires plan to have been run.")
@click.pass_obj
@error_handler
def transpile_command(context:Context,query:t.Optional[str],fmt:str,query_file:t.Optional[str],user:t.Optional[str],security_context:tuple[str,...],disable_post_processing:bool,style:t.Optional[str],environment:t.Optional[str])->_A:
	if query_file and query:raise click.ClickException('Provide either QUERY or --file, not both.')
	if not query_file and not query:raise click.ClickException('Provide either QUERY or --file/STDIN.')
	raw:t.Optional[str]
	if query_file:
		if query_file=='-':raw=sys.stdin.read()
		else:
			path=Path(query_file)
			if not path.exists():raise click.ClickException(f"File not found: {query_file}")
			raw=path.read_text(encoding=_N)
	else:raw=query
	if raw is _A:raise click.ClickException('No input provided.')
	if fmt.lower()=='rest':
		try:payload_dict=t.cast(t.Dict[str,t.Any],json.loads(raw));rest_query=RestQuery(**payload_dict);query_obj:t.Union[RestQuery,str]=rest_query
		except Exception as e:raise click.ClickException(f"Invalid REST payload for --format rest: {e}")from e
	else:
		if not raw.strip():raise click.ClickException('Empty SQL query is not allowed.')
		query_obj=raw
	user_id=user or'vulcan-cli';env=environment or context.config.default_target_environment
	try:security_ctx=SecurityContext.from_pairs(security_context)
	except(ValueError,TypeError)as exc:raise click.ClickException(str(exc))from exc
	async def _run()->_A:
		A='request_id';import uuid;env_obj=context.state_sync.get_environment(env)
		if not env_obj:available=[e.name for e in context.state_sync.get_environments()];raise click.ClickException(f"Environment '{env}' not found. Run 'vulcan plan {env}' first. Available: {', '.join(available)if available else'none'}")
		params=get_transpiler_params_from_snapshots(context,env);params[A]=str(uuid.uuid4());token=os.environ.get('DATAOS_RUN_AS_APIKEY');client=make_transpiler_client(context.config,token=token)
		async with client:
			try:reply=await client.transpile(query_obj,disable_post_processing=disable_post_processing,user=user_id,security_context=security_ctx,schema=params['schema'],tenant_id=params['tenant_id'],request_id=params[A],db_type=params['db_type'],name=params[_M])
			except TranspilerError as e:
				if e.code==503:raise click.ClickException('Failed to connect to the Transpiler service (HTTP 503).\nMake sure the Transpiler is reachable (check transpiler.base_url). For local dev, run `make setup-up` from the docker/ directory.')from e
				if e.code==401:raise click.ClickException('Transpiler rejected request (HTTP 401). Set DATAOS_RUN_AS_APIKEY env var for Transpiler auth.')from e
				if e.is_post_processing_error:console=get_console();console.log_warning(f"Query requires post-processing: {e}");console.log_success(f"Use --disable-post-processing flag");return
				detail=f"TranspilerError (HTTP {e.code}): {e}"
				if getattr(e,'response_data',_A):detail+=f"\nDetails: {e.response_data}"
				raise click.ClickException(detail)
		sql=reply.sql_statement;params=getattr(reply,'sql_params',_A)
		if style and style.lower()in(_W,_t):from vulcan.utils.sql import format_sql_for_display;sql=format_sql_for_display(sql,dialect=context.config.dialect,pretty=style.lower()==_W)
		import sys
		try:
			if sys.stdout.isatty():
				console=get_console();console.show_sql(sql)
				if params:console.log_status_update(f"Parameters: {params}")
			else:
				print(sql,end='')
				if params:print(f"\n-- Parameters: {params}",end='')
		except BrokenPipeError:sys.stdout.close();sys.exit(0)
	asyncio.run(_run())
def _write_to_file(context:Context,path_str:str,text:str)->_A:
	out=Path(path_str).expanduser()
	try:out.write_text(text,encoding=_N)
	except OSError as e:raise click.ClickException(str(e))from e
	context.console.log_success(f"Wrote to {out}")
@cli.group(_Q)
def export_group()->_A:0
@export_group.command('cube')
@click.option(_O,_E,_I,type=str,default=_A,help=_X)
@click.argument(_H)
@click.pass_obj
@error_handler
def export_cube(context:Context,environment:t.Optional[str],file:str)->_A:
	try:schema=context.cube_schema_for_environment(environment);_write_to_file(context,file,pydantic_to_yaml(schema,lean=_B,omit_defaults=_B))
	except VulcanError as e:raise click.ClickException(str(e))from e
@export_group.command('semantic')
@click.option(_O,_E,_I,type=str,default=_A,help=_X)
@click.argument(_H)
@click.pass_obj
@error_handler
def export_semantic(context:Context,environment:t.Optional[str],file:str)->_A:
	try:schema=context.semantic_schema_for_environment(environment);_write_to_file(context,file,pydantic_to_yaml(schema,lean=_B))
	except VulcanError as e:raise click.ClickException(str(e))from e
@export_group.command(_d)
@click.option(_O,_E,_I,type=str,default=_A,help=_X)
@click.argument(_H)
@click.pass_obj
@error_handler
def export_metadata(context:Context,environment:t.Optional[str],file:str)->_A:
	try:schema=context.metadata_for_environment(environment=environment);_write_to_file(context,file,pydantic_to_yaml(schema,lean=_B,json_dump=_B))
	except VulcanError as e:raise click.ClickException(str(e))from e
@cli.command(_g)
@click.argument('view_name')
@click.option('--connection','-c',type=str,default=_A,help='Snowflake gateway/connection name to fetch the view from. Required when VIEW_NAME is a fully-qualified Snowflake identifier (e.g. ECOMMERCE_PLATFORM.GOLD.MY_VIEW). If omitted the view is resolved from local managed/imported YAML files.')
@click.option('--output-dir',type=str,default=_A,help='Base output directory for the imported semantic model YAMLs. A subfolder named after the semantic view is always created inside this directory (e.g. models/TPCH_DEEP_CHAIN/). Defaults to models/snowflake_semantic/.')
@click.pass_obj
@error_handler
def import_semantic_view(context:Context,view_name:str,connection:t.Optional[str],output_dir:t.Optional[str])->_A:
	from vulcan.core.export.snowflake_semantic import fetch_definition,project_root as _project_root,write_model_files;from vulcan.utils.errors import ConfigError;console=context.console;root=_project_root(context)
	if connection:console.log_status_update(f"Fetching '{view_name}' from Snowflake via connection '{connection}'…")
	try:definition=fetch_definition(context,view_name,connection)
	except ConfigError as exc:raise click.ClickException(str(exc))from exc
	written=write_model_files(definition,root,output_dir);out_dir=written[0].parent if written else root;source_label=f"via connection '{connection}'"if connection else f"({definition.source})";console.log_success(f"Imported {len(written)} semantic model(s) from '{definition.name}' {source_label} → {out_dir}")
	for p in written:
		try:display=p.resolve().relative_to(root.resolve())
		except ValueError:display=p
		console.log_status_update(f"  {display}")
@cli.command(_P)
@click.option('--output',_L,type=str,default=_A,help="Output path for the generated DataOS Vulcan resource YAML. Defaults to '<project_name>-deploy.yaml' in the project root.")
@click.option(_l,is_flag=_B,help='Overwrite the output file if it already exists.')
@click.pass_obj
@error_handler
def create_deploy_yaml(context:t.Union[Context,str],output:t.Optional[str],overwrite:bool)->_A:
	F='    resource: #optional\n      driver:\n        coreLimit: "<core-limit>" # \'1\'\n        cores: "<cores>"\n        memory: "<memory>"\n      executor:\n        coreLimit: "<core-limit>" # \'1\'\n        cores: "<cores>"\n        memory: "<memory>"\n        instances: "<instances>"\n\n    sparkConf:\n      spark.sql.shuffle.partitions: "16"\n      spark.sql.adaptive.coalescePartitions.enabled: "true"\n';E='depot';D='type';C='cron';B='model_defaults';A='0 0 * * *';from pathlib import Path;import re;from vulcan.core.config.loader import load_config_from_yaml;project_root=Path(context.path).absolute()if isinstance(context,Context)else Path(str(context)).absolute();raw_config=load_config_from_yaml(project_root/'config.yaml');out_path=Path(output).expanduser()if output else project_root/f"{raw_config.get(_M)}-deploy.yaml"
	if not out_path.is_absolute():out_path=project_root/out_path
	if out_path.exists()and not overwrite:raise click.ClickException(f"Output file already exists: {out_path}. Use --overwrite to replace it.")
	def _yaml_quote_scalar(value:t.Optional[str])->str:s=(value or'').replace('\\','\\\\').replace('"','\\"');return f'"{s}"'
	def _to_k8s_cron(expr:str)->str:B='0 0 1 1 *';e=(expr or'').strip().lower();mapping={'@hourly':'0 * * * *','@daily':A,'@midnight':A,'@weekly':'0 0 * * 0','@monthly':'0 0 1 * *','@yearly':B,'@annually':B};return mapping.get(e,expr)
	crons:t.Set[str]=set();models_dir=project_root/_n
	if models_dir.exists():
		for path in models_dir.rglob('*'):
			if not path.is_file()or path.suffix.lower()not in{'.sql','.py'}:continue
			text=path.read_text(encoding=_N)
			for match in re.finditer('cron\\s*\\(?\\s*[\'\\"]([^\'\\"]+)[\'\\"]',text):crons.add(_to_k8s_cron(match.group(1)))
	if not crons and(raw_config.get(B)or{}).get(C):crons.add(_to_k8s_cron(str((raw_config.get(B)or{}).get(C))))
	if not crons:crons.add(A)
	cron_list=sorted(crons);tags=[str(tag)for tag in raw_config.get('tags')or[]];tags_yaml='\n'.join([f"  - {t}"for t in tags])if tags else'  -';crons_yaml='\n'.join([f"        - '{c}'"for c in cron_list]);tenant=str(raw_config.get('tenant')or'<tenant>');gateways=raw_config.get('gateways')or{};default_gateway_name=str(raw_config.get('default_gateway')or'default');default_gateway=gateways.get(default_gateway_name)if isinstance(gateways,dict)else{};connection=default_gateway.get('connection')if isinstance(default_gateway,dict)else{};depot_address=''
	if isinstance(connection,dict)and connection.get(D)==E:
		from urllib.parse import urlparse;raw_depot_address=str(connection.get('address')or'').strip();parsed_depot_address=urlparse(raw_depot_address)
		if parsed_depot_address.scheme and parsed_depot_address.netloc:depot_address=raw_depot_address if parsed_depot_address.query else f"{parsed_depot_address.scheme}://{parsed_depot_address.netloc}?purpose=<purpose>"
		else:depot_address=raw_depot_address
	depot_section=f"  depots: # Use this if you are using depot for the type depot in config.yaml\n    - {depot_address or'<dataos://<depot-name>?purpose=rw>'}\n"if depot_address else'';connection_type=str(connection.get(D)or'').strip()if isinstance(connection,dict)else'';dialect=str((raw_config.get(B)or{}).get(_q)or'').strip()
	if dialect.startswith(_D)or connection_type==_D:engine=_D
	else:engine=connection_type if connection_type and connection_type!=E else dialect
	spark_workflow_resource_yaml=F;spark_api_resource_yaml=F;generic_workflow_resource_yaml='    resource: #optional\n      request:\n        cpu: "<cpu-request>" # \'200m\'\n        memory: "<memory-request>" # \'512Mi\'\n      limit:\n        cpu: "<cpu-limit>" # \'1000m\'\n        memory: "<memory-limit>" # \'1Gi\'\n';generic_api_resource_yaml='    resource:\n      request:\n        cpu: "<cpu-request>" # \'200m\'\n        memory: "<memory-request>" # \'512Mi\'\n      limit:\n        cpu: "<cpu-limit>" # \'1000m\'\n        memory: "<memory-limit>" # \'1Gi\'\n';workflow_resource_yaml=spark_workflow_resource_yaml if engine==_D else generic_workflow_resource_yaml;api_resource_yaml=spark_api_resource_yaml if engine==_D else generic_api_resource_yaml;resource_name=str(raw_config.get(_M)or'').strip();poros_entity_name_fmt='^[a-z]([-a-z0-9]*[a-z0-9])?$'
	if len(resource_name)>60 or not re.fullmatch(poros_entity_name_fmt,resource_name):raise click.ClickException(f"Invalid DataOS resource name derived from config.yaml `name`.\nGot: {resource_name!r}\nRule: must be <= 60 chars, lowercase, start with a letter, and only contain letters/digits plus '-'; must end with a letter or digit.\nRegex: {poros_entity_name_fmt}\nAction: Correct `name` in config.yaml and re-run `vulcan create_deploy_yaml`.")
	payload=f"""version: v1alpha
type: vulcan
name: {resource_name}
description: {_yaml_quote_scalar(str(raw_config.get("description")or""))}
tags:
{tags_yaml}
spec:
  runAsUser: <Optional> # only add if you want to run as a specific user
  compute: general-purpose-shared # check available computes using dataos CLI
  engine: {engine or"<based on the project config.yaml>"}
  repo:
    url: <git repo url>
    syncFlags:
      - '--ref=main' # change to the branch you want to deploy
      - '--submodules=off' # change if you want to sync submodules
    baseDir: <repo-name>/<path-to-the-project>
    secretId: {tenant}.<secret-name> # optional: if repo is private, create tenant secret and use it here
{depot_section}  use: # Use this section if you are using the connection of source type without depot
    projection:
      secrets:
        - id: {tenant}.<secret-name>
          contextAlias: <secret-alias>
      projections:
        envVars:
          - key: <PROJECT_ENV_VAR_NAME>
            template: \"{{{{ secrets[<secret-alias>].<SECRET_KEY> | base64_decode }}}}\"

  workflow:
    schedule:
      crons:
{crons_yaml}
      endOn: '<end-date-in-ISO-8601-format>' # '2027-01-01T00:00:00-00:00'
      timezone: '<timezone>' # 'US/Pacific'
      concurrencyPolicy: Forbid

    logLevel: INFO #default
{workflow_resource_yaml}

    #NOTE: - refer document for vulcan commands - https://tmdc-io.github.io/vulcan-book/cli-commands/cli/
    plan:
      command:
        - vulcan
      arguments:
        - plan
        - --auto-apply
    run:
      command:
        - vulcan
      arguments:
        - run

  api:
    replicas: 1
    logLevel: INFO
{api_resource_yaml}
""";out_path.parent.mkdir(parents=_B,exist_ok=_B);out_path.write_text(payload,encoding=_N);click.echo(f"Generated deploy YAML: {out_path}")