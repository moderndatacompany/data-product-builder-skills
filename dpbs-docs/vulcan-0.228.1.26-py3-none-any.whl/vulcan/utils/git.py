from __future__ import annotations
_H='github'
_G='bitbucket'
_F='gitlab'
_E='rev-parse'
_D='--diff-filter=d'
_C='--name-only'
_B='diff'
_A=None
import subprocess,typing as t
from functools import cached_property
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit
@dataclass(frozen=True)
class GitCommit:sha:str;message:str;author_name:str;author_email:str;authored_at:str
@dataclass(frozen=True)
class GitCommitInfo:sha:t.Optional[str];url:t.Optional[str]
class GitClient:
	def __init__(self,repo:str|Path):
		self._work_dir=Path(repo)
		if self._work_dir.is_file():self._work_dir=self._work_dir.parent
	def list_untracked_files(self)->t.List[Path]:return self._execute_list_output(['ls-files','--others','--exclude-standard'],self._work_dir)
	def list_uncommitted_changed_files(self)->t.List[Path]:return self._execute_list_output([_B,_C,_D,'HEAD'],self._git_root)
	def list_committed_changed_files(self,target_branch:str='main')->t.List[Path]:return self._execute_list_output([_B,_C,_D,f"{target_branch}..."],self._git_root)
	def _execute_list_output(self,commands:t.List[str],base_path:Path)->t.List[Path]:return[(base_path/o).absolute()for o in self._execute(commands).split('\n')if o]
	def _execute(self,commands:t.List[str])->str:
		A='utf-8';result=subprocess.run(['git']+commands,cwd=self._work_dir,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
		if result.returncode!=0:stderr_output=result.stderr.decode(A).strip();error_message=next((line for line in stderr_output.splitlines()if line.lower().startswith('fatal:')),stderr_output);raise RuntimeError(f"Git error: {error_message}")
		return result.stdout.decode(A).strip()
	@cached_property
	def _git_root(self)->Path:return Path(self._execute([_E,'--show-toplevel']))
	@cached_property
	def commit_sha(self)->str:return self._execute([_E,'HEAD'])
	def remote_url(self,remote:str)->str:url=self._execute(['config','--get',f"remote.{remote}.url"]);return self.convert_url_to_https(url)
	@cached_property
	def origin_url(self)->str:return self.remote_url('origin')
	def diff(self,old_commit_sha:str,new_commit_sha:str)->str:return self._execute([_B,old_commit_sha,new_commit_sha])
	def list_commits(self,old_commit_sha:str,new_commit_sha:str)->t.List[GitCommit]:
		output=self._execute(['log','--reverse','--date=iso-strict','--format=%H%x1f%s%x1f%an%x1f%ae%x1f%ad',f"{old_commit_sha}..{new_commit_sha}"]);commits=[]
		for line in output.splitlines():
			if not line:continue
			sha,message,author_name,author_email,authored_at=line.split('\x1f',4);commits.append(GitCommit(sha=sha,message=message,author_name=author_name,author_email=author_email,authored_at=authored_at))
		return commits
	def commit_url(self,commit_sha:t.Optional[str]=_A)->t.Optional[str]:
		sha=commit_sha or self.commit_sha
		if not sha:return
		try:repo_url=self.origin_url
		except RuntimeError:return
		if not repo_url:return
		host=urlsplit(repo_url).hostname or''
		if _F in host:return f"{repo_url}/-/commit/{sha}"
		if _G in host:return f"{repo_url}/commits/{sha}"
		if _H in host:return f"{repo_url}/commit/{sha}"
	def folder_url(self,folder_path:str,ref:t.Optional[str]=_A)->t.Optional[str]:
		ref=ref or self.commit_sha
		try:repo_url=self.origin_url
		except RuntimeError:return
		if not repo_url:return
		host=urlsplit(repo_url).hostname or'';suffix=f"/{folder_path}"if folder_path else''
		if _F in host:return f"{repo_url}/-/tree/{ref}{suffix}"
		if _G in host:return f"{repo_url}/src/{ref}{suffix}"
		if _H in host:return f"{repo_url}/tree/{ref}{suffix}"
	def commit_info(self)->GitCommitInfo:
		try:commit_sha=self.commit_sha;return GitCommitInfo(sha=commit_sha,url=self.commit_url(commit_sha))
		except Exception:return GitCommitInfo(sha=_A,url=_A)
	def project_folder_url(self)->t.Optional[str]:
		try:
			project_dir=self._work_dir;project_dir=project_dir.resolve();folder_path=project_dir.relative_to(self._git_root).as_posix()
			if folder_path=='.':folder_path=''
			return self.folder_url(folder_path,self.commit_sha)
		except Exception:return
	@staticmethod
	def convert_url_to_https(url:str)->str:
		C='git@';B='http://';A='https://'
		if not url:return url
		if url.startswith(A):result=url
		elif url.startswith(B):result=A+url[len(B):]
		elif url.startswith(C):part=url.split(C,1)[1];part=part.replace(':','/',1);result=f"https://{part}"
		elif url.startswith('ssh://git@'):
			parsed=urlsplit(url)
			if not parsed.hostname:return url
			result=f"https://{parsed.hostname}{parsed.path}"
		else:return url
		if result.endswith('.git'):result=result[:-4]
		return result