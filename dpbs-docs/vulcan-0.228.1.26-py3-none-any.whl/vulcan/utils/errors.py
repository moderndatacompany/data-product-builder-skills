from __future__ import annotations
_C=True
_B=False
_A=None
import re,typing as t
from collections import defaultdict
from enum import auto
from pathlib import Path
from sqlglot import exp
from sqlglot.helper import AutoName
if t.TYPE_CHECKING:from requests.models import Response;from vulcan.core.model import Model;from vulcan.core.schema_diff import TableAlterOperation
class ErrorLevel(AutoName):IGNORE=auto();WARN=auto();RAISE=auto()
class VulcanError(Exception):0
class ConfigError(VulcanError):
	location:t.Optional[Path]=_A
	def __init__(self,message:str|Exception,location:t.Optional[Path]=_A)->_A:
		super().__init__(message)
		if location:self.location=Path(location)if isinstance(location,str)else location
class BaseMissingReferenceError(ConfigError):
	def __init__(self,ref:str)->_A:self.ref=ref
class MissingModelError(BaseMissingReferenceError):0
class MissingSourceError(BaseMissingReferenceError):0
class MissingDependencyError(VulcanError):0
class MacroEvalError(VulcanError):0
class PlanError(VulcanError):0
class NoChangesPlanError(PlanError):0
class UncategorizedPlanError(PlanError):0
class ConflictingPlanError(PlanError):0
class MissingContextException(Exception):0
class SnapshotVersionError(VulcanError):0
class MagicError(VulcanError):0
class AuditConfigError(ConfigError):0
class StateMigrationError(VulcanError):0
class AuditError(VulcanError):
	def __init__(self,audit_name:str,audit_args:t.Dict[t.Any,t.Any],count:int,query:exp.Query,model:t.Optional[Model]=_A,adapter_dialect:t.Optional[str]=_A)->_A:self.audit_name=audit_name;self.audit_args=audit_args;self.model=model;self.count=count;self.query=query;self.adapter_dialect=adapter_dialect;super().__init__(f"'{self.audit_name}' audit error: {self.count} {'row'if self.count==1 else'rows'} failed on model '{self.model.name if self.model else'unknown'}'")
	@property
	def model_name(self)->t.Optional[str]:return self.model.name if self.model else _A
	def sql(self,dialect:t.Optional[str]=_A,**opts:t.Any)->str:return self.query.sql(dialect=dialect or self.adapter_dialect,**opts)
class NodeAuditsErrors(VulcanError):
	def __init__(self,errors:t.List[AuditError])->_A:self.errors=errors;super().__init__(f"Audits failed: {', '.join([e.audit_name for e in errors])}")
class TestError(VulcanError):__test__=_B
class DestructiveChangeError(VulcanError):0
class AdditiveChangeError(VulcanError):0
class MigrationNotSupportedError(VulcanError):0
class NotificationTargetError(VulcanError):0
class ApiError(VulcanError):
	def __init__(self,message:str,code:int)->_A:super().__init__(message);self.code=code
class ApiClientError(ApiError):0
class ApiServerError(ApiError):0
class NotFoundError(ApiClientError):
	def __init__(self,message:str)->_A:super().__init__(message,404)
class CICDBotError(VulcanError):0
class ParsetimeAdapterCallError(VulcanError):0
class EngineAdapterError(VulcanError):0
class UnsupportedCatalogOperationError(EngineAdapterError):0
class CircuitBreakerError(VulcanError):
	def __init__(self)->_A:super().__init__('Circuit breaker triggered.')
class PythonModelEvalError(VulcanError):0
class MissingDefaultCatalogError(VulcanError):0
class LinterError(VulcanError):0
class SignalEvalError(VulcanError):0
def raise_config_error(msg:str,location:t.Optional[Path]=_A,error_type:t.Type[ConfigError]=ConfigError)->_A:
	if location:raise error_type(f"{msg} at '{location}'",location)
	raise error_type(msg,location=location)
def raise_for_status(response:Response)->_A:
	if response.status_code==404:raise NotFoundError(response.text)
	if 400<=response.status_code<500:raise ApiClientError(response.text,response.status_code)
	if 500<=response.status_code<600:raise ApiServerError(response.text,response.status_code)
def _format_schema_change_msg(snapshot_name:str,is_destructive:bool,alter_operations:t.List[TableAlterOperation],dialect:str,error:bool=_C)->str:
	from vulcan.core.schema_diff import get_dropped_column_names,get_additive_column_names;change_type='destructive'if is_destructive else'additive';setting_name='on_destructive_change'if is_destructive else'on_additive_change';action_verb='drops'if is_destructive else'adds';cli_flag='--allow-destructive-model'if is_destructive else'--allow-additive-model';column_names=get_dropped_column_names(alter_operations)if is_destructive else get_additive_column_names(alter_operations);column_str="', '".join(column_names);column_msg=f" that {action_verb} column{'s'if column_names and len(column_names)>1 else''} '{column_str}'"if column_str else'';alter_expr_msg='\n\nSchema changes:\n  '+'\n  '.join([alter.expression.sql(dialect)for alter in alter_operations]);warning_msg=f"Plan requires {change_type} change to forward-only model '{snapshot_name}'s schema"
	if error:permissive_values='`warn`, `allow`, or `ignore`';cli_part=f" or include the model in the plan's `{cli_flag}` option";err_msg=f"\n\nTo allow the {change_type} change, set the model's `{setting_name}` setting to {permissive_values}{cli_part}.\n"
	else:err_msg=''
	return f"\n{warning_msg}{column_msg}.{alter_expr_msg}{err_msg}"
def format_destructive_change_msg(snapshot_name:str,alter_expressions:t.List[TableAlterOperation],dialect:str,error:bool=_C)->str:return _format_schema_change_msg(snapshot_name=snapshot_name,is_destructive=_C,alter_operations=alter_expressions,dialect=dialect,error=error)
def format_additive_change_msg(snapshot_name:str,alter_operations:t.List[TableAlterOperation],dialect:str,error:bool=_C)->str:return _format_schema_change_msg(snapshot_name=snapshot_name,is_destructive=_B,alter_operations=alter_operations,dialect=dialect,error=error)
class SemanticError(ConfigError):
	def __init__(self,message:str,location:t.Optional[str|Path]=_A):super().__init__(message,location);self.message=message;self.location=location
def format_semantic_errors(errors:t.List[SemanticError])->str:
	if not errors:return''
	grouped=defaultdict(list)
	for error in errors:grouped[error.location].append(error.message)
	sections=[[f"{loc}:"]+[f"  - {msg}"for msg in msgs]if loc else[f"- {msg}"for msg in msgs]for(loc,msgs)in grouped.items()];return'\n'.join([line for section in sections for line in section])
class CheckError(ConfigError):
	def __init__(self,message:str,location:t.Optional[str|Path]=_A):super().__init__(message,location);self.message=message;self.location=location
def format_check_errors(errors:t.List[CheckError])->str:
	if not errors:return''
	by_location:t.Dict[t.Optional[str],t.List[str]]={}
	for error in errors:
		loc=str(error.location)if error.location else _A
		if loc not in by_location:by_location[loc]=[]
		by_location[loc].append(error.message)
	lines=[]
	for(location,messages)in by_location.items():
		if location:
			lines.append(f"\n{location}:")
			for msg in messages:lines.append(f"  - {msg}")
		else:
			for msg in messages:lines.append(f"- {msg}")
	return'\n'.join(lines)
class QueryValidationError(VulcanError):
	def __init__(self,error_type:str,message:str):self.error_type=error_type;self.message=message;super().__init__(f"[{error_type}] {message}")
class ObjectStoreError(VulcanError):0
class TranspilerError(ApiError):
	def __init__(self,message:str,code:int,response_data:t.Optional[t.Dict[str,t.Any]]=_A,query_type:t.Optional[str]=_A,is_connection_error:bool=_B)->_A:super().__init__(message,code);self.response_data=response_data;self.query_type=query_type;self._is_connection_error=is_connection_error
	@property
	def is_connection_error(self)->bool:return self._is_connection_error
	@property
	def is_post_processing_error(self)->bool:
		if self.code!=400:return _B
		return'post_processing'==self.query_type
	@property
	def user_message(self)->str:
		B='Error during planning:';A='SQLCompilationError:';msg=str(self)
		if A in msg:
			if B in msg:return msg.split(B)[-1].strip()
			return msg.split(A)[-1].strip()
		return msg
_SQLMESH_URL_RE=re.compile('https?://(?:'+'sql'+'mesh|vulcan)\\.readthedocs\\.io\\S*')
def rebrand(text:t.Any)->t.Any:
	B='vulcan';A='Vulcan'
	if not isinstance(text,str):return text
	text=_SQLMESH_URL_RE.sub('Vulcan Documentation',text);replacements={'SQLMESH':'VULCAN',A:A,B:B}
	for(old,new)in replacements.items():text=text.replace(old,new)
	return text