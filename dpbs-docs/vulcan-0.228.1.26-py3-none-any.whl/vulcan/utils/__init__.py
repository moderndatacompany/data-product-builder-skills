from __future__ import annotations
_C=True
_B=False
_A=None
import copy,hashlib,importlib,logging,os,random,re,string,sys,time,traceback,types,typing as t,uuid
from dataclasses import dataclass
from collections import defaultdict
from contextlib import contextmanager
from copy import deepcopy
from enum import IntEnum,Enum
from functools import lru_cache,reduce,wraps
from pathlib import Path
import unicodedata
from sqlglot import exp
from sqlglot.dialects.dialect import Dialects
from sqlglot.optimizer.annotate_types import annotate_types
logger=logging.getLogger(__name__)
T=t.TypeVar('T')
KEY=t.TypeVar('KEY',bound=t.Hashable)
VALUE=t.TypeVar('VALUE')
ITEM=t.TypeVar('ITEM')
GROUP=t.TypeVar('GROUP')
DECORATOR_RETURN_TYPE=t.TypeVar('DECORATOR_RETURN_TYPE')
ALPHANUMERIC=string.ascii_lowercase+string.digits
def optional_import(name:str)->t.Optional[types.ModuleType]:
	try:module=importlib.import_module(name)
	except ImportError:return
	return module
def major_minor(version:str)->t.Tuple[int,int]:return t.cast(t.Tuple[int,int],tuple(int(part)for part in version.split('.')[0:2]))
def unique(iterable:t.Iterable[T],by:t.Callable[[T],t.Any]=lambda i:i)->t.List[T]:return list({by(i):_A for i in iterable})
def random_id(short:bool=_B)->str:
	if short:return''.join(random.choices(ALPHANUMERIC,k=8))
	return uuid.uuid4().hex
def path_id(txt:str)->str:hash_bytes=hashlib.sha256(txt.encode()).digest()[:16];return uuid.UUID(bytes=hash_bytes).hex
class UniqueKeyDict(t.Dict[KEY,VALUE]):
	def __init__(self,name:str,*args:t.Dict[KEY,VALUE],**kwargs:VALUE)->_A:self.name=name;super().__init__(*args,**kwargs)
	def __setitem__(self,k:KEY,v:VALUE)->_A:
		if k in self:raise ValueError(f"Duplicate key '{k}' found in UniqueKeyDict<{self.name}>. Call dict.update(...) if this is intentional.")
		super().__setitem__(k,v)
class AttributeDict(dict,t.Mapping[KEY,VALUE]):
	def __getattr__(self,key:t.Any)->t.Optional[VALUE]:
		if key.startswith('__')and not hasattr(self,key):raise AttributeError
		return self.get(key)
	def set(self,field:str,value:t.Any)->str:self[field]=value;return''
	def __deepcopy__(self,memo:t.Dict[t.Any,AttributeDict])->AttributeDict:
		copy:AttributeDict=AttributeDict();memo[id(self)]=copy
		for(k,v)in self.items():copy[k]=deepcopy(v,memo)
		return copy
	def __call__(self,**kwargs:t.Dict[str,t.Any])->str:self.update(**kwargs);return''
	def __getstate__(self)->t.Optional[t.Dict[t.Any,t.Any]]:0
class registry_decorator:
	registry_name='';_registry:t.Optional[UniqueKeyDict]=_A
	@classmethod
	def registry(cls)->UniqueKeyDict:
		if cls._registry is _A:cls._registry=UniqueKeyDict(cls.registry_name)
		return cls._registry
	def __init__(self,name:str='')->_A:self.name=name
	def __call__(self,func:t.Callable[...,DECORATOR_RETURN_TYPE])->t.Callable[...,DECORATOR_RETURN_TYPE]:
		self.func=func;registry=self.registry();func_name=(self.name or func.__name__).lower()
		try:registry[func_name]=self
		except ValueError:
			if func.__code__.co_code!=registry[func_name].func.__code__.co_code:raise ValueError(f"Duplicate name: '{func_name}'.")
		@wraps(func)
		def wrapper(*args:t.Any,**kwargs:t.Any)->DECORATOR_RETURN_TYPE:return func(*args,**kwargs)
		return wrapper
	@classmethod
	def get_registry(cls)->UniqueKeyDict:return UniqueKeyDict(cls.registry_name,**cls._registry or{})
	@classmethod
	def set_registry(cls,registry:UniqueKeyDict)->_A:cls._registry=registry
@contextmanager
def sys_path(*paths:Path)->t.Iterator[_A]:
	inserted=set()
	for path in paths:
		path_str=str(path.absolute())
		if path_str not in sys.path:sys.path.insert(0,path_str);inserted.add(path_str)
	try:yield
	finally:
		for path_str in inserted:sys.path.remove(path_str)
def format_exception(exception:BaseException)->t.List[str]:
	if sys.version_info<(3,10):return traceback.format_exception(type(exception),exception,exception.__traceback__)
	return traceback.format_exception(exception)
def word_characters_only(s:str,replacement_char:str='_')->str:return re.sub('\\W',replacement_char,s)
def str_to_bool(s:t.Optional[str])->bool:
	if not s:return _B
	return s.lower()in('true','1','t','y','yes','on')
_debug_mode_enabled:bool=_B
def enable_debug_mode()->_A:global _debug_mode_enabled;_debug_mode_enabled=_C
def debug_mode_enabled()->bool:return _debug_mode_enabled or str_to_bool(os.environ.get('VULCAN_DEBUG'))
def ttl_cache(ttl:int=60,maxsize:int=128000)->t.Callable:
	def decorator(func:t.Callable)->t.Any:
		@lru_cache(maxsize=maxsize)
		def cache(tick:int,*args:t.Any,**kwargs:t.Any)->t.Any:return func(*args,**kwargs)
		@wraps(func)
		def wrap(*args:t.Any,**kwargs:t.Any)->t.Any:return cache(int(time.time()/ttl),*args,**kwargs)
		return wrap
	return decorator
class classproperty(property):
	def __get__(self,obj:t.Any,owner:t.Any=_A)->t.Any:return classmethod(self.fget).__get__(_A,owner)()
@contextmanager
def env_vars(environ:dict[str,str])->t.Iterator[_A]:
	old_environ=os.environ.copy();os.environ.update(environ)
	try:yield
	finally:os.environ.clear();os.environ.update(old_environ)
def merge_dicts(*args:t.Dict)->t.Dict:
	def merge(a:t.Dict,b:t.Dict)->t.Dict:
		for(b_key,b_value)in b.items():
			a_value=a.get(b_key)
			if isinstance(a_value,dict)and isinstance(b_value,dict):merge(a_value,b_value)
			elif isinstance(b_value,dict):a[b_key]=copy.deepcopy(b_value)
			else:a[b_key]=b_value
		return a
	return reduce(merge,args,{})
def sqlglot_dialects()->str:return"'"+"', '".join(Dialects.__members__.values())+"'"
NON_ALNUM=re.compile('[^a-zA-Z0-9_]')
NON_ALUM_INCLUDE_UNICODE=re.compile('\\W',flags=re.UNICODE)
def sanitize_name(name:str,*,include_unicode:bool=_B)->str:
	if include_unicode:s=unicodedata.normalize('NFC',name);s=NON_ALUM_INCLUDE_UNICODE.sub('_',s);return s
	return NON_ALNUM.sub('_',name)
def groupby(items:t.Iterable[ITEM],func:t.Callable[[ITEM],GROUP])->t.DefaultDict[GROUP,t.List[ITEM]]:
	grouped=defaultdict(list)
	for item in items:grouped[func(item)].append(item)
	return grouped
def columns_to_types_to_struct(columns_to_types:t.Union[t.Dict[str,exp.DataType],t.Dict[str,str]])->exp.DataType:return exp.DataType(this=exp.DataType.Type.STRUCT,expressions=[exp.ColumnDef(this=exp.to_identifier(k),kind=v)for(k,v)in columns_to_types.items()],nested=_C)
def type_is_known(d_type:t.Union[exp.DataType,exp.ColumnDef])->bool:
	if isinstance(d_type,exp.ColumnDef):
		if not d_type.kind:return _B
		d_type=d_type.kind
	if isinstance(d_type,exp.DataTypeParam):return _C
	if d_type.is_type(exp.DataType.Type.UNKNOWN,exp.DataType.Type.NULL):return _B
	if d_type.expressions:return all(type_is_known(expression)for expression in d_type.expressions)
	return _C
def columns_to_types_all_known(columns_to_types:t.Dict[str,exp.DataType])->bool:return all(type_is_known(expression)for expression in columns_to_types.values())
class Verbosity(IntEnum):
	DEFAULT=0;VERBOSE=1;VERY_VERBOSE=2
	@property
	def is_default(self)->bool:return self==Verbosity.DEFAULT
	@property
	def is_verbose(self)->bool:return self==Verbosity.VERBOSE
	@property
	def is_very_verbose(self)->bool:return self==Verbosity.VERY_VERBOSE
class CompletionStatus(Enum):
	SUCCESS='success';FAILURE='failure';NOTHING_TO_DO='nothing_to_do'
	@property
	def is_success(self)->bool:return self==CompletionStatus.SUCCESS
	@property
	def is_failure(self)->bool:return self==CompletionStatus.FAILURE
	@property
	def is_nothing_to_do(self)->bool:return self==CompletionStatus.NOTHING_TO_DO
def to_snake_case(name:str)->str:return''.join(f"_{c.lower()}"if c.isupper()and idx!=0 else c.lower()for(idx,c)in enumerate(name))
def to_snake_case_keys(obj:t.Any,*,preserve_dict_keys:t.FrozenSet[str]=frozenset())->t.Any:
	if isinstance(obj,dict):return{to_snake_case(k):{gw_name:to_snake_case_keys(gw_config,preserve_dict_keys=preserve_dict_keys)for(gw_name,gw_config)in v.items()}if to_snake_case(k)in preserve_dict_keys and isinstance(v,dict)else to_snake_case_keys(v,preserve_dict_keys=preserve_dict_keys)for(k,v)in obj.items()}
	if isinstance(obj,list):return[to_snake_case_keys(item,preserve_dict_keys=preserve_dict_keys)for item in obj]
	if isinstance(obj,tuple):return tuple(to_snake_case_keys(item,preserve_dict_keys=preserve_dict_keys)for item in obj)
	if isinstance(obj,set):return{to_snake_case_keys(item,preserve_dict_keys=preserve_dict_keys)for item in obj}
	return obj
class JobType(Enum):PLAN='PLAN';RUN='RUN';QUERY='QUERY'
@dataclass(frozen=_C)
class CorrelationId:
	job_type:JobType;job_id:str;principal:str
	def __str__(self)->str:return f"{self.job_type.value}:{self.job_id}:{self.principal}"
	@staticmethod
	def _principal_from_env_or_default()->str:return os.environ.get('DATAOS_RUN_AS_USER')or'unknown_user_id'
	@classmethod
	def from_plan_id(cls,plan_id:str,principal:t.Optional[str]=_A)->CorrelationId:principal=principal or cls._principal_from_env_or_default();return CorrelationId(JobType.PLAN,plan_id,principal)
	@classmethod
	def from_run_id(cls,run_id:str,principal:t.Optional[str]=_A)->CorrelationId:principal=principal or cls._principal_from_env_or_default();return CorrelationId(JobType.RUN,run_id,principal)
	@classmethod
	def from_query_id(cls,request_id:str,principal:t.Optional[str]=_A)->CorrelationId:principal=principal or cls._principal_from_env_or_default();return CorrelationId(JobType.QUERY,request_id,principal)
def get_source_columns_to_types(columns_to_types:t.Dict[str,exp.DataType],source_columns:t.Optional[t.List[str]])->t.Dict[str,exp.DataType]:source_column_lookup=set(source_columns)if source_columns else _A;return{k:v for(k,v)in columns_to_types.items()if not source_column_lookup or k in source_column_lookup}
def get_columns_to_types_from_query(query:exp.Query,dialect:str)->t.Optional[t.Dict[str,exp.DataType]]:
	try:annotated_query=annotate_types(query.copy(),dialect=dialect)
	except Exception:logger.debug('Unable to infer column types from query.',exc_info=_C);return
	unknown=exp.DataType.build('unknown');columns_to_types:t.Dict[str,exp.DataType]={}
	for select in annotated_query.selects:
		output_name=select.output_name
		if not output_name or output_name in columns_to_types:return
		columns_to_types[output_name]=(select.type or unknown).copy()
	return columns_to_types