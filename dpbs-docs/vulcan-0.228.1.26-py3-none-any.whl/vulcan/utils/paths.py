from __future__ import annotations
import typing as t
from pathlib import Path
from vulcan.core.config.common import ALL_CONFIG_FILENAMES
def relative_to_project_config(path:t.Optional[Path])->str:
	if path is None:return''
	p=Path(path)
	try:abs_path=p.resolve()
	except OSError:return str(p)
	origin=abs_path.parent if abs_path.suffix else abs_path
	for root in[origin,*origin.parents]:
		if any((root/name).is_file()for name in ALL_CONFIG_FILENAMES):
			try:return str(abs_path.relative_to(root))
			except ValueError:break
	return p.name