from typing import Any,Optional,Set
from vulcan.core.config.connection import ConnectionConfig
from vulcan.utils import yaml
excluded_fields:Set[str]={'concurrent_tasks','pre_ping','register_comments'}
sensitive_fields:Set[str]={'access_token','api_key','auth_token','client_secret','certificate','credentials','user','password','keytab','keyfile','keyfile_json','principal','private_key','private_key_passphrase','private_key_path','refresh_token','secret','ssh_key','token'}
def is_sensitive_field(field_name:str,sensitive_fields:Set[str])->bool:field_lower=field_name.lower();return any(sensitive in field_lower for sensitive in sensitive_fields)
def mask_sensitive_value(value:Any)->str:
	if value and str(value).strip():return'****'
	return'None'
def print_config(config:Optional[ConnectionConfig],console:Any,title:str)->None:
	if not config:return
	config_dict=config.dict(mode='json')
	for field_name in config_dict:
		if is_sensitive_field(field_name,sensitive_fields):config_dict[field_name]=mask_sensitive_value(config_dict[field_name])
	configWithTitle={title:config_dict};yaml_output=yaml.dump(configWithTitle);console.log_status_update(yaml_output)