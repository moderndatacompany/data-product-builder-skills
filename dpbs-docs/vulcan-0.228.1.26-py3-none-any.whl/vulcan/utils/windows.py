import platform
from pathlib import Path
IS_WINDOWS=platform.system()=='Windows'
WINDOWS_LONGPATH_PREFIX='\\\\?\\'
def fix_windows_path(path:Path)->Path:
	if path.parts and not path.parts[0].startswith(WINDOWS_LONGPATH_PREFIX):path=Path(WINDOWS_LONGPATH_PREFIX+str(path.absolute()))
	return path.resolve()