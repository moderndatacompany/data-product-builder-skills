from __future__ import annotations
import typing as t
from functools import lru_cache
from sqlglot import exp
if t.TYPE_CHECKING:import pandas as pd
@lru_cache()
def get_pandas_type_mappings()->t.Dict[t.Any,exp.DataType]:
	I='boolean';H='double';G='bigint';F='int';E='smallint';D='tinyint';C='timestamp';B='text';A='float';import pandas as pd,numpy as np;mappings={np.dtype('int8'):exp.DataType.build(D),np.dtype('int16'):exp.DataType.build(E),np.dtype('int32'):exp.DataType.build(F),np.dtype('int64'):exp.DataType.build(G),np.dtype('float16'):exp.DataType.build(A),np.dtype('float32'):exp.DataType.build(A),np.dtype('float64'):exp.DataType.build(H),np.dtype('O'):exp.DataType.build(B),np.dtype('bool'):exp.DataType.build(I),np.dtype('datetime64'):exp.DataType.build(C),np.dtype('datetime64[ns]'):exp.DataType.build(C),np.dtype('datetime64[us]'):exp.DataType.build(C),pd.Int8Dtype():exp.DataType.build(D),pd.Int16Dtype():exp.DataType.build(E),pd.Int32Dtype():exp.DataType.build(F),pd.Int64Dtype():exp.DataType.build(G),pd.Float32Dtype():exp.DataType.build(A),pd.Float64Dtype():exp.DataType.build(H),pd.StringDtype():exp.DataType.build(B),pd.BooleanDtype():exp.DataType.build(I)}
	try:import pyarrow;mappings[pd.StringDtype('pyarrow')]=exp.DataType.build(B)
	except ImportError:pass
	return mappings
def columns_to_types_from_df(df:pd.DataFrame)->t.Dict[str,exp.DataType]:return columns_to_types_from_dtypes(df.dtypes.items())
def columns_to_types_from_dtypes(dtypes:t.Iterable[t.Tuple[t.Hashable,t.Any]])->t.Dict[str,exp.DataType]:
	import pandas as pd;result={}
	for(column_name,column_type)in dtypes:
		exp_type:t.Optional[exp.DataType]=None
		if hasattr(pd,'DatetimeTZDtype')and isinstance(column_type,pd.DatetimeTZDtype):exp_type=exp.DataType.build('timestamptz')
		else:exp_type=get_pandas_type_mappings().get(column_type)
		if not exp_type:raise ValueError(f"Unsupported pandas type '{column_type}'")
		result[str(column_name)]=exp_type
	return result