from __future__ import annotations
_E='__file__'
_D='__wrapped__'
_C='__name__'
_B=False
_A=None
import ast,dis,importlib,inspect,linecache,logging,os,re,sys,textwrap,types,typing as t
from dataclasses import dataclass
from enum import Enum
from numbers import Number
from pathlib import Path
from astor import to_source
from vulcan.core import constants as c
from vulcan.utils import format_exception,unique
from vulcan.utils.errors import VulcanError
from vulcan.utils.pydantic import PydanticModel
logger=logging.getLogger(__name__)
IGNORE_DECORATORS={'macro','model','asset','signal'}
SERIALIZABLE_CALLABLES=type,types.FunctionType
LITERALS=Number,str,bytes,tuple,list,dict,set,bool
def _is_relative_to(path:t.Optional[Path|str],other:t.Optional[Path|str])->bool:
	if path is _A or other is _A:return _B
	if isinstance(path,str):path=Path(path)
	if isinstance(other,str):other=Path(other)
	if'site-packages'in str(path)or not path.exists()or not other.exists():return _B
	try:path.absolute().relative_to(other.absolute());return True
	except ValueError:return _B
def _code_globals(code:types.CodeType)->t.Dict[str,_A]:
	variables={instruction.argval:_A for instruction in dis.get_instructions(code)if instruction.opname=='LOAD_GLOBAL'}
	for const in code.co_consts:
		if isinstance(const,types.CodeType):variables.update(_code_globals(const))
	return variables
def _globals_match(obj1:t.Any,obj2:t.Any)->bool:A='__module__';return type(obj1)==type(obj2)and(obj1==obj2 or getattr(obj1,A,_A)==getattr(obj2,A,_A)and getattr(obj1,_C,_A)==getattr(obj2,_C,_A))
def func_globals(func:t.Callable)->t.Dict[str,t.Any]:
	variables={}
	if hasattr(func,'__code__'):
		root_node=parse_source(func);func_args=next(node for node in ast.walk(root_node)if isinstance(node,ast.arguments));arg_defaults=(d for d in func_args.defaults+func_args.kw_defaults if d is not _A);arg_globals=[n.id for default in arg_defaults for n in ast.walk(default)if isinstance(n,ast.Name)];code=func.__code__
		for var in arg_globals+list(_code_globals(code))+decorator_vars(func,root_node=root_node):
			if var in func.__globals__:variables[var]=func.__globals__[var]
		if func.__closure__:
			for(var,value)in zip(code.co_freevars,func.__closure__):variables[var]=value.cell_contents
	return variables
class ClassFoundException(Exception):0
class _ClassFinder(ast.NodeVisitor):
	def __init__(self,qualname:str)->_A:(self.stack):t.List[str]=[];self.qualname=qualname
	def visit_FunctionDef(self,node:ast.FunctionDef)->_A:self.stack.append(node.name);self.stack.append('<locals>');self.generic_visit(node);self.stack.pop();self.stack.pop()
	visit_AsyncFunctionDef=visit_FunctionDef
	def visit_ClassDef(self,node:ast.ClassDef)->_A:
		self.stack.append(node.name)
		if self.qualname=='.'.join(self.stack):
			if node.decorator_list:line_number=node.decorator_list[0].lineno
			else:line_number=node.lineno
			line_number-=1;raise ClassFoundException(line_number)
		self.generic_visit(node);self.stack.pop()
class _DecoratorDependencyFinder(ast.NodeVisitor):
	def __init__(self)->_A:(self.dependencies):t.List[str]=[]
	def _extract_dependencies(self,node:ast.ClassDef|ast.FunctionDef)->_A:
		for decorator in node.decorator_list:
			dependencies:t.List[str]=[]
			for n in ast.walk(decorator):
				if isinstance(n,ast.Attribute):dep=n.attr
				elif isinstance(n,ast.Name):dep=n.id
				else:continue
				if dep in IGNORE_DECORATORS:dependencies=[];break
				dependencies.append(dep)
			self.dependencies.extend(dependencies)
	def visit_FunctionDef(self,node:ast.FunctionDef)->_A:self._extract_dependencies(node)
	def visit_ClassDef(self,node:ast.ClassDef)->_A:self._extract_dependencies(node)
	visit_AsyncFunctionDef=visit_FunctionDef
def getsource(obj:t.Any)->str:
	path=inspect.getsourcefile(obj)
	if path:
		module=inspect.getmodule(obj,path)
		if module:lines=linecache.getlines(path,module.__dict__)
		else:lines=linecache.getlines(path)
		def join_source(lnum:int)->str:return''.join(inspect.getblock(lines[lnum:]))
		if inspect.isclass(obj):
			qualname=obj.__qualname__;source=''.join(lines);tree=ast.parse(source);class_finder=_ClassFinder(qualname)
			try:class_finder.visit(tree)
			except ClassFoundException as e:return join_source(e.args[0])
		elif inspect.isfunction(obj):
			obj=obj.__code__
			if hasattr(obj,'co_firstlineno'):
				lnum=obj.co_firstlineno-1;pat=re.compile('^(\\s*def\\s)|(\\s*async\\s+def\\s)|(.*(?<!\\w)lambda(:|\\s))|^(\\s*@)')
				while lnum>0:
					try:line=lines[lnum]
					except IndexError:raise OSError('lineno is out of bounds')
					if pat.match(line):break
					lnum=lnum-1
				return join_source(lnum)
	raise VulcanError(f"Cannot find source for {obj}")
def parse_source(func:t.Callable)->ast.Module:return ast.parse(textwrap.dedent(getsource(func)))
def _decorator_name(decorator:ast.expr)->str:
	node=decorator
	if isinstance(decorator,ast.Call):node=decorator.func
	return node.id if isinstance(node,ast.Name)else''
def decorator_vars(func:t.Callable,root_node:t.Optional[ast.Module]=_A)->t.List[str]:root_node=root_node or parse_source(func);finder=_DecoratorDependencyFinder();finder.visit(root_node);return unique(finder.dependencies)
def normalize_source(obj:t.Any)->str:
	root_node=parse_source(obj)
	for node in ast.walk(root_node):
		if isinstance(node,(ast.FunctionDef,ast.ClassDef)):
			for decorator in node.decorator_list:
				if _decorator_name(decorator)in IGNORE_DECORATORS:node.decorator_list.remove(decorator)
			body=node.body
			if body and isinstance(body[0],ast.Expr)and isinstance(body[0].value,ast.Str):node.body=body[1:]
			if isinstance(node,ast.FunctionDef):node.returns=_A
	return to_source(root_node).strip()
def build_env(obj:t.Any,*,env:t.Dict[str,t.Tuple[t.Any,t.Optional[bool]]],name:str,path:Path,is_metadata_obj:bool=_B)->_A:
	visited:t.Set[str]=set()
	def walk(obj:t.Any,name:str,is_metadata:bool=_B)->_A:
		obj_module=inspect.getmodule(obj)
		if obj_module and obj_module.__name__=='builtins':return
		if name in visited:
			if name not in env or _globals_match(env[name][0],obj):return
			raise VulcanError(f"Cannot store {obj} in environment, duplicate definitions found for '{name}'")
		visited.add(name);name_missing_from_env=name not in env
		if name_missing_from_env or not is_metadata and env[name]==(obj,True):
			if not name_missing_from_env:is_metadata=_B
			if hasattr(obj,c.SQLMESH_MACRO):obj=obj.__wrapped__
			elif callable(obj)and not isinstance(obj,SERIALIZABLE_CALLABLES):
				obj=getattr(obj,_D,_A);name=getattr(obj,_C,'')
				if not isinstance(obj,SERIALIZABLE_CALLABLES)or name in env:return
			if not obj_module or not hasattr(obj_module,_E)or not _is_relative_to(obj_module.__file__,path):env[name]=obj,is_metadata;return
			if inspect.isclass(obj):
				for var in decorator_vars(obj):
					if obj_module and var in obj_module.__dict__:walk(obj_module.__dict__[var],var,is_metadata)
				for base in obj.__bases__:walk(base,base.__qualname__,is_metadata)
				for(k,v)in obj.__dict__.items():
					if k.startswith('__'):continue
					if isinstance(v,(classmethod,staticmethod)):v=v.__func__
					if callable(v):
						if v.__qualname__.startswith(obj.__qualname__):
							for(k,v)in func_globals(v).items():walk(v,k,is_metadata)
						else:walk(v,v.__name__,is_metadata)
			elif callable(obj):
				for(k,v)in func_globals(obj).items():walk(v,k,is_metadata)
			env[name]=obj,is_metadata
		elif not _globals_match(env[name][0],obj):raise VulcanError(f"Cannot store {obj} in environment, duplicate definitions found for '{name}'")
	walk(obj,name,is_metadata_obj or getattr(obj,c.SQLMESH_METADATA,_B))
@dataclass
class SqlValue:sql:str
class ExecutableKind(str,Enum):
	IMPORT='import';VALUE='value';DEFINITION='definition'
	def __lt__(self,other:t.Any)->bool:
		if not isinstance(other,ExecutableKind):return NotImplemented
		values=list(ExecutableKind.__dict__.values());return values.index(self)<values.index(other)
	def __str__(self)->str:return self.value
class Executable(PydanticModel):
	payload:str;kind:ExecutableKind=ExecutableKind.DEFINITION;name:t.Optional[str]=_A;path:t.Optional[str]=_A;alias:t.Optional[str]=_A;is_metadata:t.Optional[bool]=_A
	@property
	def is_definition(self)->bool:return self.kind==ExecutableKind.DEFINITION
	@property
	def is_import(self)->bool:return self.kind==ExecutableKind.IMPORT
	@property
	def is_value(self)->bool:return self.kind==ExecutableKind.VALUE
	@classmethod
	def value(cls,v:t.Any,is_metadata:t.Optional[bool]=_A,sort_root_dict:bool=_B)->Executable:payload=_dict_sort(v)if sort_root_dict else repr(v);return Executable(payload=payload,kind=ExecutableKind.VALUE,is_metadata=is_metadata or _A)
def serialize_env(env:t.Dict[str,t.Any],path:Path)->t.Dict[str,Executable]:
	serialized={}
	for(k,(v,is_metadata))in env.items():
		is_metadata=is_metadata or _A
		if isinstance(v,LITERALS)or v is _A:serialized[k]=Executable.value(v,is_metadata=is_metadata)
		elif inspect.ismodule(v):
			name=v.__name__
			if hasattr(v,_E)and _is_relative_to(v.__file__,path):raise VulcanError(f"Cannot serialize 'import {name}'. Use 'from {name} import ...' instead.")
			postfix=''if name==k else f" as {k}";serialized[k]=Executable(payload=f"import {name}{postfix}",kind=ExecutableKind.IMPORT,is_metadata=is_metadata)
		elif callable(v):
			name=v.__name__;name=k if name=='<lambda>'else name
			try:
				file_path=Path(inspect.getfile(v));relative_obj_file_path=_is_relative_to(file_path,path)
				if not relative_obj_file_path and(wrapped:=getattr(v,_D,_A)):v=wrapped;file_path=Path(inspect.getfile(wrapped));relative_obj_file_path=_is_relative_to(file_path,path)
			except TypeError:file_path=_A;relative_obj_file_path=_B
			if relative_obj_file_path:serialized[k]=Executable(name=name,payload=normalize_source(v),kind=ExecutableKind.DEFINITION,path=t.cast(Path,file_path).relative_to(path.absolute()).as_posix(),alias=k if name!=k else _A,is_metadata=is_metadata)
			else:serialized[k]=Executable(payload=f"from {v.__module__} import {name}",kind=ExecutableKind.IMPORT,is_metadata=is_metadata)
		else:raise VulcanError(f"Object '{v}' cannot be serialized. If it's defined in a library, import the corresponding module and reference the object using its fully-qualified name. For example, the datetime module's 'UTC' object should be accessed as 'datetime.UTC'.")
	return serialized
def prepare_env(python_env:t.Dict[str,Executable],env:t.Optional[t.Dict[str,t.Any]]=_A)->t.Dict[str,t.Any]:
	env={}if env is _A else env
	for(name,executable)in sorted(python_env.items(),key=lambda item:0 if item[1].is_import else 1):
		if executable.is_value:env[name]=eval(executable.payload)
		else:
			exec(executable.payload,env)
			if executable.alias and executable.name:env[executable.alias]=env[executable.name]
	return env
def format_evaluated_code_exception(exception:Exception,python_env:t.Dict[str,Executable])->str:
	tb:t.List[str]=[];indent='';skip_patterns=re.compile('Traceback \\(most recent call last\\):|File ".*?core/model/definition\\.py|File ".*?core/snapshot/definition\\.py|File ".*?core/macros\\.py|File ".*?inspect\\.py')
	for error_line in format_exception(exception):
		if skip_patterns.search(error_line):continue
		error_match=re.search('^.*?Error: ',error_line)
		if error_match:tb.append(f"{indent*2}  {error_line}");continue
		eval_code_match=re.search('File "<string>", line (.*), in (.*)',error_line)
		if not eval_code_match:tb.append(f"{indent}{error_line}");continue
		line_num=int(eval_code_match.group(1));func=eval_code_match.group(2)
		if func not in python_env:tb.append(error_line);continue
		executable=python_env[func];indent=error_line[:eval_code_match.start()];error_line=f"{indent}File '{executable.path}' (or imported file), line {line_num}, in {func}";code=executable.payload;formatted=[]
		for(i,code_line)in enumerate(code.splitlines()):
			if i<line_num:
				pad=len(code_line)-len(code_line.lstrip())
				if i+1==line_num:formatted.append(f"{code_line[:pad]}{code_line[pad:]}")
				else:formatted.append(code_line)
		tb.extend((error_line,textwrap.indent(os.linesep.join(formatted),indent+'  ')))
	return os.linesep.join(tb)
def print_exception(exception:Exception,python_env:t.Dict[str,Executable],out:t.TextIO=sys.stderr)->_A:tb=format_evaluated_code_exception(exception,python_env);out.write(tb)
def _dict_sort(obj:t.Any)->str:
	try:
		if isinstance(obj,dict):obj=dict(sorted(obj.items(),key=lambda x:str(x[0])))
	except Exception:logger.warning('Failed to sort non-recursive dict',exc_info=True)
	return repr(obj)
def import_python_file(path:Path,relative_base:Path=Path())->types.ModuleType:
	relative_path=path.absolute().relative_to(relative_base.absolute());module_name=str(relative_path.with_suffix('')).replace(os.path.sep,'.');parts=module_name.split('.')
	for i in range(len(parts)):sys.modules.pop('.'.join(parts[0:i+1]),_A)
	return importlib.import_module(module_name)