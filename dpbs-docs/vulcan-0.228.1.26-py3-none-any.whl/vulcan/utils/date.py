from __future__ import annotations
_D='yesterday'
_C=True
_B=False
_A=None
import re,time,typing as t,warnings
from datetime import date,datetime,timedelta,timezone,tzinfo
import dateparser
from dateparser import freshness_date_parser as freshness_date_parser_module
from dateparser.freshness_date_parser import freshness_date_parser
from sqlglot import exp
from vulcan.utils import ttl_cache
if t.TYPE_CHECKING:import pandas as pd;from sqlglot.dialects.dialect import DialectType
UTC=timezone.utc
TimeLike=t.Union[date,datetime,str,int,float]
DatetimeRange=t.Tuple[datetime,datetime]
DatetimeRanges=t.List[DatetimeRange]
DATE_INT_FMT='%Y%m%d'
warnings.filterwarnings('ignore',message='The localize method is no longer necessary, as this time zone supports the fold attribute')
freshness_date_parser_module.PATTERN=re.compile('(\\d+[.,]?\\d*)\\s*(%s)s?\\b'%freshness_date_parser_module._UNITS,re.I|re.S|re.U)
DAY_SHORTCUT_EXPRESSIONS={'today',_D,'tomorrow'}
TIME_UNITS={'hours','minutes','seconds'}
TEMPORAL_TZ_TYPES={exp.DataType.Type.TIMETZ,exp.DataType.Type.TIMESTAMPTZ,exp.DataType.Type.TIMESTAMPLTZ}
def now(minute_floor:bool=_C)->datetime:
	now=datetime.now(tz=UTC)
	if minute_floor:return now.replace(second=0,microsecond=0,tzinfo=UTC)
	return now.replace(tzinfo=UTC)
def now_timestamp(minute_floor:bool=_B)->int:return to_timestamp(now(minute_floor))
def now_ds()->str:return to_ds(now())
def yesterday(relative_base:t.Optional[datetime]=_A)->datetime:return to_datetime(_D,relative_base=relative_base)
def yesterday_ds(relative_base:t.Optional[datetime]=_A)->str:return to_ds(_D,relative_base=relative_base)
def yesterday_timestamp(relative_base:t.Optional[datetime]=_A)->int:return to_timestamp(yesterday(relative_base=relative_base))
def to_timestamp(value:TimeLike,relative_base:t.Optional[datetime]=_A,check_categorical_relative_expression:bool=_C)->int:return int(to_datetime(value,relative_base=relative_base,check_categorical_relative_expression=check_categorical_relative_expression).timestamp()*1000)
@ttl_cache()
def to_datetime(value:TimeLike,relative_base:t.Optional[datetime]=_A,check_categorical_relative_expression:bool=_C,tz:t.Optional[tzinfo]=_A)->datetime:
	if isinstance(value,datetime):dt:t.Optional[datetime]=value
	elif isinstance(value,date):dt=datetime(value.year,value.month,value.day)
	elif isinstance(value,exp.Expression):return to_datetime(value.name)
	else:
		try:epoch=float(value)
		except ValueError:epoch=_A
		if epoch is _A:
			relative_base=relative_base or now();expression=str(value)
			if check_categorical_relative_expression and is_categorical_relative_expression(expression):relative_base=relative_base.replace(hour=0,minute=0,second=0,microsecond=0)
			dt=dateparser.parse(expression,settings={'RELATIVE_BASE':relative_base,'TIMEZONE':'UTC'})
		else:
			try:dt=datetime.strptime(str(value),DATE_INT_FMT)
			except ValueError:dt=datetime.fromtimestamp(epoch/1e3,tz=UTC)
	if dt is _A:raise ValueError(f"Could not convert `{value}` to datetime.")
	tz=tz or UTC
	if dt.tzinfo:return dt if dt.tzinfo==tz else dt.astimezone(tz)
	return dt.replace(tzinfo=tz)
def to_date(value:TimeLike,relative_base:t.Optional[datetime]=_A)->date:return to_datetime(value,relative_base).date()
def date_dict(execution_time:TimeLike,start:t.Optional[TimeLike],end:t.Optional[TimeLike])->t.Dict[str,TimeLike]:
	kwargs:t.Dict[str,t.Union[str,datetime,date,float,int]]={};execution_dt=to_datetime(execution_time);prefixes=[('latest',execution_dt),('execution',execution_dt)]
	if start is not _A:prefixes.append(('start',to_datetime(start)))
	if end is not _A:prefixes.append(('end',to_datetime(end)))
	for(prefix,time_like)in prefixes:dt=to_datetime(time_like);dtntz=dt.replace(tzinfo=_A);millis=to_timestamp(time_like);kwargs[f"{prefix}_dt"]=dt;kwargs[f"{prefix}_dtntz"]=dtntz;kwargs[f"{prefix}_date"]=to_date(dt);kwargs[f"{prefix}_ds"]=to_ds(time_like);kwargs[f"{prefix}_ts"]=to_ts(dt);kwargs[f"{prefix}_tstz"]=to_tstz(dt);kwargs[f"{prefix}_epoch"]=millis/1000;kwargs[f"{prefix}_millis"]=millis;kwargs[f"{prefix}_hour"]=dt.hour
	return kwargs
def to_ds(obj:TimeLike,relative_base:t.Optional[datetime]=_A)->str:return to_ts(obj,relative_base=relative_base)[0:10]
def to_ts(obj:TimeLike,relative_base:t.Optional[datetime]=_A)->str:return to_datetime(obj,relative_base=relative_base).replace(tzinfo=_A).isoformat(sep=' ')
def to_tstz(obj:TimeLike,relative_base:t.Optional[datetime]=_A)->str:return to_datetime(obj,relative_base=relative_base).isoformat(sep=' ')
def is_date(obj:TimeLike)->bool:
	if isinstance(obj,date)and not isinstance(obj,datetime):return _C
	try:time.strptime(str(obj).replace('-',''),DATE_INT_FMT);return _C
	except ValueError:return _B
def make_inclusive(start:TimeLike,end:TimeLike,dialect:t.Optional[DialectType]='')->DatetimeRange:return to_datetime(start),make_inclusive_end(end,dialect=dialect)
def make_inclusive_end(end:TimeLike,dialect:t.Optional[DialectType]='')->datetime:
	import pandas as pd;exclusive_end=make_exclusive(end)
	if dialect=='tsql':return to_utc_timestamp(exclusive_end)-pd.Timedelta(1,unit='ns')
	return exclusive_end-timedelta(microseconds=1)
def make_exclusive(time:TimeLike)->datetime:
	dt=to_datetime(time)
	if is_date(time):dt=dt+timedelta(days=1)
	return dt
def make_ts_exclusive(time:TimeLike,dialect:DialectType)->datetime:
	ts=to_datetime(time)
	if dialect=='tsql':return to_utc_timestamp(ts)-pd.Timedelta(1,unit='ns')
	return ts+timedelta(microseconds=1)
def to_utc_timestamp(time:datetime)->pd.Timestamp:
	A='utc';import pandas as pd
	if time.tzinfo is not _A:return pd.Timestamp(time).tz_convert(A)
	return pd.Timestamp(time,tz=A)
def validate_date_range(start:t.Optional[TimeLike],end:t.Optional[TimeLike])->_A:
	if start and end and to_datetime(start)>to_datetime(end):raise ValueError(f"Start date / time ({start}) can't be greater than end date / time ({end})")
def time_like_to_str(time_like:TimeLike)->str:
	if isinstance(time_like,str):return time_like
	if is_date(time_like):return to_ds(time_like)
	return to_ts(time_like)
def is_categorical_relative_expression(expression:str)->bool:
	if expression.strip().lower()in DAY_SHORTCUT_EXPRESSIONS:return _C
	grain_kwargs=freshness_date_parser.get_kwargs(expression)
	if not grain_kwargs:return _B
	return not any(k in TIME_UNITS for k in grain_kwargs)
def is_relative(value:TimeLike)->bool:
	if isinstance(value,str):return is_categorical_relative_expression(value)
	return _B
def to_time_column(time_column:t.Union[TimeLike,exp.Null],time_column_type:exp.DataType,dialect:str,time_column_format:t.Optional[str]=_A,nullable:bool=_B)->exp.Expression:
	A='nullable'
	if dialect=='clickhouse'and time_column_type.is_type(*exp.DataType.TEMPORAL_TYPES-{exp.DataType.Type.DATE,exp.DataType.Type.DATE32}):
		if time_column_type.is_type(exp.DataType.Type.DATETIME64):
			if nullable:time_column_type.set(A,nullable)
		else:time_column_type=exp.DataType.build(exp.DataType.Type.DATETIME64,expressions=[exp.DataTypeParam(this=exp.Literal(this=6,is_string=_B)),*time_column_type.expressions],nullable=nullable or time_column_type.args.get(A,_B))
	if isinstance(time_column,exp.Null):return exp.cast(time_column,to=time_column_type)
	if time_column_type.is_type(exp.DataType.Type.DATE,exp.DataType.Type.DATE32):return exp.cast(exp.Literal.string(to_ds(time_column)),to='date')
	if time_column_type.is_type(*TEMPORAL_TZ_TYPES):return exp.cast(exp.Literal.string(to_tstz(time_column)),to=time_column_type)
	if time_column_type.is_type(*exp.DataType.TEMPORAL_TYPES):return exp.cast(exp.Literal.string(to_ts(time_column)),to=time_column_type)
	if time_column_format:time_column=to_datetime(time_column).strftime(time_column_format)
	if time_column_type.is_type(*exp.DataType.TEXT_TYPES):return exp.Literal.string(time_column)
	if time_column_type.is_type(*exp.DataType.NUMERIC_TYPES):return exp.Literal.number(time_column)
	return exp.convert(time_column)
def pandas_timestamp_to_pydatetime(df:pd.DataFrame,columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A)->pd.DataFrame:
	import pandas as pd;from pandas.api.types import is_datetime64_any_dtype
	for column in df.columns:
		if is_datetime64_any_dtype(df.dtypes[column]):
			df[column]=pd.Series(df[column].dt.to_pydatetime(),dtype='object')
			if columns_to_types and columns_to_types[column].this in(exp.DataType.Type.DATE,exp.DataType.Type.DATE32):df[column]=df[column].map(lambda x:x.date()if type(x)is datetime and not pd.isna(x)else x)
	return df
def format_tz_datetime(time:TimeLike,format_string:t.Optional[str]='%Y-%m-%d %I:%M%p %Z',use_local_timezone:bool=_B)->str:
	output_datetime=to_datetime(time)
	if use_local_timezone:local_timezone=datetime.now().astimezone().tzinfo;output_datetime=output_datetime.astimezone(local_timezone)
	return output_datetime.strftime(format_string)if format_string else output_datetime.isoformat(sep=' ')