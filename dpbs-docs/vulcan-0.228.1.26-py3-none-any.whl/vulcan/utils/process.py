_C=False
_B=True
_A=None
from concurrent.futures import Future,ProcessPoolExecutor
import socket,subprocess,typing as t,multiprocessing as mp
from vulcan.utils.windows import IS_WINDOWS
class SynchronousPoolExecutor:
	def __init__(self,max_workers=_A,mp_context=_A,initializer=_A,initargs=()):
		if initializer is not _A:
			try:initializer(*initargs)
			except BaseException as ex:raise RuntimeError(f"Exception in initializer: {ex}")
	def __enter__(self):return self
	def __exit__(self,*args):self.shutdown(wait=_B);return _C
	def shutdown(self,wait=_B,cancel_futures=_C):0
	def submit(self,fn,*args,**kwargs):
		future=Future()
		try:result=fn(*args,**kwargs);future.set_result(result)
		except Exception as e:future.set_exception(e)
		return future
	def map(self,fn,*iterables,timeout=_A,chunksize=1):return map(fn,*iterables)
PoolExecutor=t.Union[SynchronousPoolExecutor,ProcessPoolExecutor]
def create_process_pool_executor(initializer:t.Callable,initargs:t.Tuple,max_workers:t.Optional[int])->PoolExecutor:
	if max_workers==1 or IS_WINDOWS:return SynchronousPoolExecutor(initializer=initializer,initargs=initargs)
	return ProcessPoolExecutor(mp_context=mp.get_context('fork'),initializer=initializer,initargs=initargs,max_workers=max_workers)
def _is_private_ipv4(ip:str)->bool:
	try:
		parts=[int(p)for p in ip.split('.')]
		if len(parts)!=4:return _C
	except ValueError:return _C
	if parts[0]==10:return _B
	if parts[0]==192 and parts[1]==168:return _B
	if parts[0]==172 and 16<=parts[1]<=31:return _B
	return _C
def get_host_ip(default:str='127.0.0.1')->str:
	try:
		infos=socket.getaddrinfo(socket.gethostname(),_A,family=socket.AF_INET)
		for(*_,sockaddr)in infos:
			ip=sockaddr[0]
			if _is_private_ipv4(ip):return ip
	except Exception:pass
	try:
		s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
		try:s.connect(('8.8.8.8',80));ip=s.getsockname()[0]
		finally:s.close()
		return ip
	except Exception:return default
def detect_docker_compose_command()->t.List[str]:
	candidates=[['docker','compose'],['docker-compose']]
	for cmd in candidates:
		try:subprocess.run(cmd+['version'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=_B);return cmd
		except(FileNotFoundError,subprocess.CalledProcessError):continue
	raise RuntimeError("Neither 'docker compose' nor 'docker-compose' is available. Please install Docker and Docker Compose.")