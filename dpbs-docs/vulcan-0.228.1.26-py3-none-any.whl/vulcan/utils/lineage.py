_D='cte'
_C='external_model'
_B='model'
_A=None
import typing as t
from pathlib import Path
from pydantic import Field
from vulcan.core.dialect import normalize_model_name
from vulcan.core.linter.helpers import TokenPositionDetails
from vulcan.core.linter.rule import Range,Position
from vulcan.core.model.definition import SqlModel,ExternalModel,PythonModel,SeedModel
from sqlglot import exp
from sqlglot.optimizer.scope import build_scope
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from ruamel.yaml import YAML
from vulcan.utils.pydantic import PydanticModel
if t.TYPE_CHECKING:from vulcan.core.context import Context,GenericContext
class ModelReference(PydanticModel):type:t.Literal[_B]=_B;path:Path;range:Range;markdown_description:t.Optional[str]=_A
class ExternalModelReference(PydanticModel):type:t.Literal[_C]=_C;range:Range;target_range:t.Optional[Range]=_A;path:t.Optional[Path]=_A;markdown_description:t.Optional[str]=_A
class CTEReference(PydanticModel):type:t.Literal[_D]=_D;path:Path;range:Range;target_range:Range
class MacroReference(PydanticModel):type:t.Literal['macro']='macro';path:Path;range:Range;target_range:Range;markdown_description:t.Optional[str]=_A
Reference=t.Annotated[t.Union[ModelReference,CTEReference,MacroReference,ExternalModelReference],Field(discriminator='type')]
def extract_references_from_query(query:exp.Expression,context:t.Union['Context','GenericContext[t.Any]'],document_path:Path,read_file:t.List[str],depends_on:t.Set[str],dialect:t.Optional[str]=_A)->t.List[Reference]:
	B='catalog';A='alias'
	try:query=normalize_identifiers(query.copy(),dialect=dialect);root_scope=build_scope(query)
	except Exception:root_scope=_A
	references:t.List[Reference]=[]
	if not root_scope:return references
	for scope in root_scope.traverse():
		for table in scope.tables:
			table_name=table.name
			if(cte_scope:=scope.cte_sources.get(table_name)):
				cte=cte_scope.expression.parent;alias=cte.args[A]
				if isinstance(alias,exp.TableAlias):
					identifier=alias.this
					if isinstance(identifier,exp.Identifier):target_range_vulcan=TokenPositionDetails.from_meta(identifier.meta).to_range(read_file);table_range_vulcan=TokenPositionDetails.from_meta(table.this.meta).to_range(read_file);references.append(CTEReference(path=document_path,range=table_range_vulcan,target_range=target_range_vulcan));column_references=_process_column_references(scope=scope,reference_name=table.name,read_file=read_file,referenced_model_path=document_path,description='',reference_type=_D,cte_target_range=target_range_vulcan);references.extend(column_references)
				continue
			unaliased=table.copy()
			if unaliased.args.get(A)is not _A:unaliased.set(A,_A)
			reference_name=unaliased.sql(dialect=dialect)
			try:
				normalized_reference_name=normalize_model_name(reference_name,default_catalog=context.default_catalog,dialect=dialect)
				if normalized_reference_name not in depends_on:continue
			except Exception:continue
			referenced_model=context.get_model(model_or_snapshot=normalized_reference_name,raise_if_missing=False)
			if referenced_model is _A:
				table_meta=TokenPositionDetails.from_meta(table.this.meta);table_range_vulcan=table_meta.to_range(read_file);start_pos_vulcan=table_range_vulcan.start;end_pos_vulcan=table_range_vulcan.end;catalog_or_db=table.args.get(B)or table.args.get('db')
				if catalog_or_db is not _A:catalog_or_db_meta=TokenPositionDetails.from_meta(catalog_or_db.meta);catalog_or_db_range_vulcan=catalog_or_db_meta.to_range(read_file);start_pos_vulcan=catalog_or_db_range_vulcan.start
				references.append(ExternalModelReference(range=Range(start=start_pos_vulcan,end=end_pos_vulcan),markdown_description='Unregistered external model'));continue
			referenced_model_path=referenced_model._path
			if referenced_model_path is _A:continue
			if not referenced_model_path.is_file():continue
			table_meta=TokenPositionDetails.from_meta(table.this.meta);table_range_vulcan=table_meta.to_range(read_file);start_pos_vulcan=table_range_vulcan.start;end_pos_vulcan=table_range_vulcan.end;catalog_or_db=table.args.get(B)or table.args.get('db')
			if catalog_or_db is not _A:catalog_or_db_meta=TokenPositionDetails.from_meta(catalog_or_db.meta);catalog_or_db_range_vulcan=catalog_or_db_meta.to_range(read_file);start_pos_vulcan=catalog_or_db_range_vulcan.start
			description=generate_markdown_description(referenced_model)
			if isinstance(referenced_model,ExternalModel):
				yaml_target_range:t.Optional[Range]=_A
				if referenced_model_path.suffix in('.yaml','.yml')and referenced_model_path.is_file():yaml_target_range=_get_yaml_model_range(referenced_model_path,referenced_model.name)
				references.append(ExternalModelReference(path=referenced_model_path,range=Range(start=start_pos_vulcan,end=end_pos_vulcan),markdown_description=description,target_range=yaml_target_range));column_references=_process_column_references(scope=scope,reference_name=normalized_reference_name,read_file=read_file,referenced_model_path=referenced_model_path,description=description,yaml_target_range=yaml_target_range,reference_type=_C,default_catalog=context.default_catalog,dialect=dialect);references.extend(column_references)
			else:references.append(ModelReference(path=referenced_model_path,range=Range(start=start_pos_vulcan,end=end_pos_vulcan),markdown_description=description));column_references=_process_column_references(scope=scope,reference_name=normalized_reference_name,read_file=read_file,referenced_model_path=referenced_model_path,description=description,reference_type=_B,default_catalog=context.default_catalog,dialect=dialect);references.extend(column_references)
	return references
def generate_markdown_description(model:t.Union[SqlModel,ExternalModel,PythonModel,SeedModel])->t.Optional[str]:
	description=model.description;columns=model.columns_to_types;column_descriptions=model.column_descriptions
	if columns is _A:return description or _A
	columns_table='\n'.join([f"| {column} | {column_type} | {column_descriptions.get(column,'')} |"for(column,column_type)in columns.items()]);table_header='| Column | Type | Description |\n|--------|------|-------------|\n';columns_text=table_header+columns_table;return f"{description}\n\n{columns_text}"if description else columns_text
def _process_column_references(scope:t.Any,reference_name:str,read_file:t.List[str],referenced_model_path:Path,description:t.Optional[str]=_A,yaml_target_range:t.Optional[Range]=_A,reference_type:t.Literal[_B,_C,_D]=_B,default_catalog:t.Optional[str]=_A,dialect:t.Optional[str]=_A,cte_target_range:t.Optional[Range]=_A)->t.List[Reference]:
	references:t.List[Reference]=[]
	for column in scope.find_all(exp.Column):
		if column.table:
			if reference_type==_D:
				if column.table==reference_name:table_range=_get_column_table_range(column,read_file);references.append(CTEReference(path=referenced_model_path,range=table_range,target_range=cte_target_range))
			else:
				table_parts=[part.sql(dialect)for part in column.parts[:-1]];table_ref='.'.join(table_parts);normalized_reference_name=normalize_model_name(table_ref,default_catalog=default_catalog,dialect=dialect)
				if normalized_reference_name==reference_name:
					table_range=_get_column_table_range(column,read_file)
					if reference_type==_C:references.append(ExternalModelReference(path=referenced_model_path,range=table_range,markdown_description=description,target_range=yaml_target_range))
					else:references.append(ModelReference(path=referenced_model_path,range=table_range,markdown_description=description))
	return references
def _get_column_table_range(column:exp.Column,read_file:t.List[str])->Range:table_parts=column.parts[:-1];start_range=TokenPositionDetails.from_meta(table_parts[0].meta).to_range(read_file);end_range=TokenPositionDetails.from_meta(table_parts[-1].meta).to_range(read_file);return Range(start=start_range.start,end=end_range.end)
def _get_yaml_model_range(path:Path,model_name:str)->t.Optional[Range]:
	model_name_ranges=get_yaml_model_name_ranges(path)
	if model_name_ranges is _A:return
	return model_name_ranges.get(model_name,_A)
def get_yaml_model_name_ranges(path:Path)->t.Optional[t.Dict[str,Range]]:
	A='name';yaml=YAML()
	with path.open('r',encoding='utf-8')as f:data=yaml.load(f)
	if not isinstance(data,list):return
	model_name_ranges={}
	for item in data:
		if isinstance(item,dict):
			position_data=item.lc.data[A];start=Position(line=position_data[2],character=position_data[3]);end=Position(line=position_data[2],character=position_data[3]+len(item[A]));name=item.get(A)
			if not name:continue
			model_name_ranges[name]=Range(start=start,end=end)
	return model_name_ranges