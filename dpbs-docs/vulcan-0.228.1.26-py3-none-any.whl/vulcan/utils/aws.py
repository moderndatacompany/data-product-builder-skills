import typing as t
from urllib.parse import urlparse
from vulcan.utils.errors import VulcanError
def validate_s3_uri(value:str,base:bool=False,error_type:t.Type[Exception]=VulcanError)->str:
	if not value.startswith('s3://'):raise error_type(f"Location '{value}' must be a s3:// URI")
	if base and not value.endswith('/'):value=value+'/'
	if len(value)>700:raise error_type(f"Location '{value}' cannot be more than 700 characters")
	return value
def parse_s3_uri(s3_uri:str)->t.Tuple[str,str]:
	validate_s3_uri(s3_uri);parsed_uri=urlparse(s3_uri);bucket=parsed_uri.netloc;key=parsed_uri.path
	if key:key=key[1:]
	return bucket,key