from sqlglot.dialects.dialect import DialectType
MAX_TEXT_INDEX_LENGTH={'mysql':'250','tsql':'450'}
def index_text_type(dialect:DialectType)->str:return f"VARCHAR({MAX_TEXT_INDEX_LENGTH[str(dialect)]})"if dialect in MAX_TEXT_INDEX_LENGTH else'TEXT'
def blob_text_type(dialect:DialectType)->str:return'LONGTEXT'if dialect=='mysql'else'TEXT'