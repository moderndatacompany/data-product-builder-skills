from __future__ import annotations
_B=True
_A=None
import gzip,logging,pickle,shutil,typing as t
from pathlib import Path
from sqlglot._version import __version__ as SQLGLOT_VERSION
from vulcan.utils import sanitize_name
from vulcan.utils.date import to_datetime
from vulcan.utils.errors import VulcanError
from vulcan.utils.windows import IS_WINDOWS,fix_windows_path
logger=logging.getLogger(__name__)
T=t.TypeVar('T')
SQLGLOT_VERSION_TUPLE=tuple(SQLGLOT_VERSION.split('.'))
SQLGLOT_MAJOR_VERSION=SQLGLOT_VERSION_TUPLE[0]
SQLGLOT_MINOR_VERSION=SQLGLOT_VERSION_TUPLE[1]
class FileCache(t.Generic[T]):
	def __init__(self,path:Path,prefix:t.Optional[str]=_A):
		self._path=path/prefix if prefix else path;from vulcan.core.state_sync.base import SCHEMA_VERSION
		try:from vulcan._version import __version_tuple__;major,minor=__version_tuple__[0],__version_tuple__[1]
		except ImportError:major,minor=0,0
		self._cache_version='_'.join([str(major),str(minor),SQLGLOT_MAJOR_VERSION,SQLGLOT_MINOR_VERSION,str(SCHEMA_VERSION)]);threshold=to_datetime('1 week ago').timestamp()
		for file in self._path.glob('*'):
			if IS_WINDOWS:file=fix_windows_path(file)
			if not file.stem.startswith(self._cache_version)or file.stat().st_atime<threshold:file.unlink(missing_ok=_B)
	def get_or_load(self,name:str,entry_id:str='',*,loader:t.Callable[[],T])->T:
		cached_entry=self.get(name,entry_id)
		if cached_entry is not _A:return cached_entry
		loaded_entry=loader();self.put(name,entry_id,value=loaded_entry);return loaded_entry
	def get(self,name:str,entry_id:str='')->t.Optional[T]:
		cache_entry_path=self._cache_entry_path(name,entry_id)
		if cache_entry_path.exists():
			with gzip.open(cache_entry_path,'rb')as fd:
				try:return pickle.load(fd)
				except Exception as ex:logger.warning("Failed to load a cache entry '%s': %s",name,ex)
	def put(self,name:str,entry_id:str='',*,value:T)->_A:
		self._path.mkdir(parents=_B,exist_ok=_B)
		if not self._path.is_dir():raise VulcanError(f"Cache path '{self._path}' is not a directory.")
		with gzip.open(self._cache_entry_path(name,entry_id),'wb',compresslevel=1)as fd:pickle.dump(value,fd)
	def exists(self,name:str,entry_id:str='')->bool:return self._cache_entry_path(name,entry_id).exists()
	def clear(self)->_A:
		try:shutil.rmtree(str(self._path.absolute()))
		except Exception:pass
	def _cache_entry_path(self,name:str,entry_id:str='')->Path:
		entry_file_name='__'.join(p for p in(self._cache_version,name,entry_id)if p);full_path=self._path/sanitize_name(entry_file_name,include_unicode=_B)
		if IS_WINDOWS:full_path=fix_windows_path(full_path)
		return full_path