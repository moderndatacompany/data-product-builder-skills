_D='connection'
_C='cursor'
_B=False
_A=None
import abc,logging,typing as t
from collections import defaultdict
from threading import Lock,get_ident
logger=logging.getLogger(__name__)
class ConnectionPool(abc.ABC):
	@abc.abstractmethod
	def get_cursor(self)->t.Any:0
	@abc.abstractmethod
	def get(self)->t.Any:0
	@abc.abstractmethod
	def get_attribute(self,key:str)->t.Optional[t.Any]:0
	@abc.abstractmethod
	def set_attribute(self,key:str,value:t.Any)->_A:0
	@abc.abstractmethod
	def get_all_attributes(self,key:str)->t.List[t.Any]:0
	@abc.abstractmethod
	def begin(self)->_A:0
	@abc.abstractmethod
	def commit(self)->_A:0
	@abc.abstractmethod
	def rollback(self)->_A:0
	@property
	@abc.abstractmethod
	def is_transaction_active(self)->bool:0
	@abc.abstractmethod
	def close_cursor(self)->_A:0
	@abc.abstractmethod
	def close(self)->_A:0
	@abc.abstractmethod
	def close_all(self,exclude_calling_thread:bool=_B)->_A:0
class _TransactionManagementMixin(ConnectionPool):
	def _do_begin(self)->_A:
		A='begin';cursor=self.get_cursor()
		if hasattr(cursor,A):cursor.begin()
		else:
			conn=self.get()
			if hasattr(conn,A):conn.begin()
	def _do_commit(self)->_A:
		cursor=self.get_cursor()
		if hasattr(cursor,'commit'):cursor.commit()
		else:self.get().commit()
	def _do_rollback(self)->_A:
		cursor=self.get_cursor()
		if hasattr(cursor,'rollback'):cursor.rollback()
		else:self.get().rollback()
class _ThreadLocalBase(_TransactionManagementMixin):
	def __init__(self,connection_factory:t.Callable[[],t.Any],cursor_init:t.Optional[t.Callable[[t.Any],_A]]=_A):self._connection_factory=connection_factory;(self._thread_cursors):t.Dict[t.Hashable,t.Any]={};(self._thread_transactions):t.Set[t.Hashable]=set();(self._thread_attributes):t.Dict[t.Hashable,t.Dict[str,t.Any]]=defaultdict(dict);self._thread_cursors_lock=Lock();self._thread_transactions_lock=Lock();self._cursor_init=cursor_init
	def get_cursor(self)->t.Any:
		thread_id=get_ident()
		with self._thread_cursors_lock:
			if thread_id not in self._thread_cursors:
				self._thread_cursors[thread_id]=self.get().cursor()
				if self._cursor_init:self._cursor_init(self._thread_cursors[thread_id])
			return self._thread_cursors[thread_id]
	def get_attribute(self,key:str)->t.Optional[t.Any]:thread_id=get_ident();return self._thread_attributes[thread_id].get(key)
	def set_attribute(self,key:str,value:t.Any)->_A:thread_id=get_ident();self._thread_attributes[thread_id][key]=value
	def get_all_attributes(self,key:str)->t.List[t.Any]:return[thread_attrs[key]for thread_attrs in self._thread_attributes.values()if key in thread_attrs]
	def begin(self)->_A:
		self._do_begin()
		with self._thread_transactions_lock:self._thread_transactions.add(get_ident())
	def commit(self)->_A:self._do_commit();self._discard_transaction(get_ident())
	def rollback(self)->_A:self._do_rollback();self._discard_transaction(get_ident())
	@property
	def is_transaction_active(self)->bool:
		with self._thread_transactions_lock:return get_ident()in self._thread_transactions
	def close_cursor(self)->_A:
		thread_id=get_ident()
		with self._thread_cursors_lock:
			if thread_id in self._thread_cursors:_try_close(self._thread_cursors[thread_id],_C);self._thread_cursors.pop(thread_id)
	def _discard_transaction(self,thread_id:t.Hashable)->_A:
		with self._thread_transactions_lock:self._thread_transactions.discard(thread_id)
class ThreadLocalConnectionPool(_ThreadLocalBase):
	def __init__(self,connection_factory:t.Callable[[],t.Any],cursor_init:t.Optional[t.Callable[[t.Any],_A]]=_A):super().__init__(connection_factory,cursor_init);(self._thread_connections):t.Dict[t.Hashable,t.Any]={};self._thread_connections_lock=Lock()
	def get(self)->t.Any:
		thread_id=get_ident()
		with self._thread_connections_lock:
			if thread_id not in self._thread_connections:self._thread_connections[thread_id]=self._connection_factory()
			return self._thread_connections[thread_id]
	def close(self)->_A:
		thread_id=get_ident()
		with self._thread_cursors_lock,self._thread_connections_lock:
			if thread_id in self._thread_connections:_try_close(self._thread_connections[thread_id],_D);self._thread_connections.pop(thread_id);self._thread_cursors.pop(thread_id,_A);self._discard_transaction(thread_id)
			self._thread_attributes.pop(thread_id,_A)
	def close_all(self,exclude_calling_thread:bool=_B)->_A:
		calling_thread_id=get_ident()
		with self._thread_cursors_lock,self._thread_connections_lock:
			for(thread_id,connection)in self._thread_connections.copy().items():
				if not exclude_calling_thread or thread_id!=calling_thread_id:_try_close(connection,_D);self._thread_connections.pop(thread_id);self._thread_cursors.pop(thread_id,_A);self._discard_transaction(thread_id)
			self._thread_attributes.clear()
class ThreadLocalSharedConnectionPool(_ThreadLocalBase):
	def __init__(self,connection_factory:t.Callable[[],t.Any],cursor_init:t.Optional[t.Callable[[t.Any],_A]]=_A):super().__init__(connection_factory,cursor_init);(self._connection):t.Optional[t.Any]=_A;self._connection_lock=Lock()
	def get(self)->t.Any:
		with self._connection_lock:
			if self._connection is _A:self._connection=self._connection_factory()
			return self._connection
	def close(self)->_A:
		thread_id=get_ident()
		with self._thread_cursors_lock,self._connection_lock:
			if thread_id in self._thread_cursors:_try_close(self._thread_cursors[thread_id],_C);self._thread_cursors.pop(thread_id)
			self._discard_transaction(thread_id);self._thread_attributes.pop(thread_id,_A)
	def close_all(self,exclude_calling_thread:bool=_B)->_A:
		calling_thread_id=get_ident()
		with self._thread_cursors_lock,self._connection_lock:
			for(thread_id,cursor)in self._thread_cursors.copy().items():
				if not exclude_calling_thread or thread_id!=calling_thread_id:_try_close(cursor,_C);self._thread_cursors.pop(thread_id);self._discard_transaction(thread_id)
				self._thread_attributes.pop(thread_id,_A)
			if not exclude_calling_thread:_try_close(self._connection,_D);self._connection=_A
class SingletonConnectionPool(_TransactionManagementMixin):
	def __init__(self,connection_factory:t.Callable[[],t.Any],cursor_init:t.Optional[t.Callable[[t.Any],_A]]=_A):self._connection_factory=connection_factory;(self._connection):t.Optional[t.Any]=_A;(self._cursor):t.Optional[t.Any]=_A;(self._attributes):t.Dict[str,t.Any]={};(self._is_transaction_active):bool=_B;self._cursor_init=cursor_init
	def get_cursor(self)->t.Any:
		if not self._cursor:
			self._cursor=self.get().cursor()
			if self._cursor_init:self._cursor_init(self._cursor)
		return self._cursor
	def get(self)->t.Any:
		if not self._connection:self._connection=self._connection_factory()
		return self._connection
	def get_attribute(self,key:str)->t.Optional[t.Any]:return self._attributes.get(key)
	def set_attribute(self,key:str,value:t.Any)->_A:self._attributes[key]=value
	def get_all_attributes(self,key:str)->t.List[t.Any]:value=self._attributes.get(key);return[value]if value is not _A else[]
	def begin(self)->_A:self._do_begin();self._is_transaction_active=True
	def commit(self)->_A:self._do_commit();self._is_transaction_active=_B
	def rollback(self)->_A:self._do_rollback();self._is_transaction_active=_B
	@property
	def is_transaction_active(self)->bool:return self._is_transaction_active
	def close_cursor(self)->_A:_try_close(self._cursor,_C);self._cursor=_A
	def close(self)->_A:_try_close(self._connection,_D);self._connection=_A;self._cursor=_A;self._is_transaction_active=_B;self._attributes.clear()
	def close_all(self,exclude_calling_thread:bool=_B)->_A:
		if not exclude_calling_thread:self.close()
def create_connection_pool(connection_factory:t.Callable[[],t.Any],multithreaded:bool,shared_connection:bool=_B,cursor_init:t.Optional[t.Callable[[t.Any],_A]]=_A)->ConnectionPool:pool_class=ThreadLocalSharedConnectionPool if multithreaded and shared_connection else ThreadLocalConnectionPool if multithreaded else SingletonConnectionPool;return pool_class(connection_factory,cursor_init=cursor_init)
def _try_close(closeable:t.Any,kind:str)->_A:
	if closeable is _A:return
	try:closeable.close()
	except Exception:logger.exception('Failed to close %s',kind)