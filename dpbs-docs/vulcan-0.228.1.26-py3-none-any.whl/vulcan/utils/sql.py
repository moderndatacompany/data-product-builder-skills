from __future__ import annotations
import re,typing as t
from sqlglot import exp
from sqlglot.dialects.dialect import DialectType
def format_sql_for_display(sql:str|exp.Expression,dialect:DialectType=None,pretty:bool=True,max_text_width:int=100)->str:
	try:
		if isinstance(sql,str):
			parsed=exp.maybe_parse(sql,dialect=dialect)
			if not parsed:return sql
		else:parsed=sql
		formatted=parsed.sql(dialect=dialect,pretty=pretty,max_text_width=max_text_width);formatted=_normalize_block_comments(formatted);return formatted
	except Exception:return sql if isinstance(sql,str)else sql.sql(dialect=dialect)
def _normalize_block_comments(sql:str)->str:return re.sub('\\*/\\s*/\\*','*/\n/*',sql)