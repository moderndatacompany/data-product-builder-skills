from __future__ import annotations
_B='type'
_A=True
import typing as t
from textwrap import dedent
from vulcan.core.notification.events import ApplyFailurePayload,AuditFailurePayload,MigrationFailurePayload,NotificationEvent,NotificationPayload,NotificationStatus,RunFailurePayload
TEAMS_MAX_TEXT_LENGTH=3000
CONTINUATION_SYMBOL='...'
def normalize_text(message:str,*,max_length:int=TEAMS_MAX_TEXT_LENGTH)->str:
	dedented=dedent(message).strip()
	if len(dedented)<=max_length:return dedented
	return dedented[:max_length-len(CONTINUATION_SYMBOL)-3]+CONTINUATION_SYMBOL+dedented[-3:]
def _text_block(text:str,*,size:t.Optional[str]=None,weight:t.Optional[str]=None,wrap:bool=False,font_type:t.Optional[str]=None)->dict[str,t.Any]:
	block:dict[str,t.Any]={_B:'TextBlock','text':normalize_text(text)}
	if size:block['size']=size
	if weight:block['weight']=weight
	if wrap:block['wrap']=_A
	if font_type:block['fontType']=font_type
	return block
def _status_prefix(status:NotificationStatus)->str:icons={NotificationStatus.PROGRESS:'⏳',NotificationStatus.SUCCESS:'✅',NotificationStatus.FAILURE:'❌',NotificationStatus.WARNING:'⚠️',NotificationStatus.INFO:'ℹ️'};return icons.get(status,'')
def _audit_summary(payload:AuditFailurePayload)->str:model_name=payload.model_name or'unknown';row_label='row'if payload.count==1 else'rows';return f"'{payload.audit_name}' audit error: {payload.count} {row_label} failed on model '{model_name}'"
def _body_blocks(msg:str,payload:NotificationPayload)->list[dict[str,t.Any]]:
	A='Monospace'
	if isinstance(payload,(RunFailurePayload,ApplyFailurePayload,MigrationFailurePayload)):return[_text_block(msg,wrap=_A),_text_block(payload.exc,wrap=_A,font_type=A)]
	if isinstance(payload,AuditFailurePayload):
		blocks=[_text_block(f"{msg}\n{_audit_summary(payload)}",wrap=_A)]
		if payload.audit_sql:blocks.append(_text_block(payload.audit_sql,wrap=_A,font_type=A))
		return blocks
	return[_text_block(msg,wrap=_A)]
def build_notification_message(*,status:NotificationStatus,msg:str,event:NotificationEvent,payload:NotificationPayload)->dict[str,t.Any]:header=f"{_status_prefix(status)} {event.value}".strip();return{_B:'message','attachments':[{'contentType':'application/vnd.microsoft.card.adaptive','content':{'$schema':'http://adaptivecards.io/schemas/adaptive-card.json',_B:'AdaptiveCard','version':'1.4','body':[_text_block(header,size='Medium',weight='Bolder'),*_body_blocks(msg,payload)]}}]}