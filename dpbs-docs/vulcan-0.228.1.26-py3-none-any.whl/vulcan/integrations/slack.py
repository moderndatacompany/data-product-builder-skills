_M=':white_check_mark:'
_L=':rotating_light:'
_K=':warning:'
_J='plain_text'
_I='fields'
_H='attachments'
_G='elements'
_F='section'
_E='SlackMessageComposer'
_D='mrkdwn'
_C='blocks'
_B='text'
_A='type'
import json,typing as t
from enum import Enum
from textwrap import dedent
SLACK_MAX_TEXT_LENGTH=3000
SLACK_MAX_ALERT_PREVIEW_BLOCKS=5
SLACK_MAX_ATTACHMENTS_BLOCKS=50
CONTINUATION_SYMBOL='...'
TSlackBlock=t.Dict[str,t.Any]
class TSlackBlocks(t.TypedDict):blocks:t.List[TSlackBlock]
class TSlackMessage(TSlackBlocks):attachments:t.List[TSlackBlocks];text:str
class SlackMessageComposer:
	def __init__(self,initial_message:t.Optional[TSlackMessage]=None)->None:(self.slack_message):TSlackMessage=initial_message or{_B:'',_C:[],_H:[{_C:[]}]}
	def add_primary_blocks(self,*blocks:TSlackBlock)->_E:self.slack_message[_C].extend(blocks);return self
	def add_secondary_blocks(self,*blocks:TSlackBlock)->_E:
		self.slack_message[_H][0][_C].extend(blocks)
		if len(self.slack_message[_H][0][_C])>=SLACK_MAX_ATTACHMENTS_BLOCKS:raise ValueError('Too many attachments')
		return self
	def add_text(self,text:str)->_E:self.slack_message[_B]=normalize_message(text);return self
	def _introspect(self)->_E:print(json.dumps(self.slack_message,indent=2));return self
def normalize_message(message:t.Union[str,t.List[str],t.Tuple[str],t.Set[str]])->str:
	if isinstance(message,(list,tuple,set)):message='\n'.join(message)
	dedented_message=dedent(message)
	if len(dedented_message)<SLACK_MAX_TEXT_LENGTH:return dedent(dedented_message)
	return dedent(dedented_message[:SLACK_MAX_TEXT_LENGTH-len(CONTINUATION_SYMBOL)-3]+CONTINUATION_SYMBOL+dedented_message[-3:])
def divider_block()->dict:return{_A:'divider'}
def fields_section_block(*messages:str)->dict:return{_A:_F,_I:[{_A:_D,_B:normalize_message(message)}for message in messages]}
def text_section_block(message:str)->dict:return{_A:_F,_B:{_A:_D,_B:normalize_message(message)}}
def preformatted_rich_text_block(message:str)->dict:return{_A:'rich_text',_G:[{_A:'rich_text_preformatted',_G:[{_A:_B,_B:normalize_message(message)}]}]}
def empty_section_block()->dict:return{_A:_F,_B:{_A:_D,_B:normalize_message('\t')}}
def context_block(*messages:str)->dict:return{_A:'context',_G:[{_A:_D,_B:normalize_message(message)}for message in messages]}
def header_block(message:str)->dict:return{_A:'header',_B:{_A:_J,_B:message}}
def button_action_block(text:str,url:str)->dict:return{_A:'actions',_G:[{_A:'button',_B:{_A:_J,_B:text,'emoji':True},'value':text,'url':url}]}
def compacted_sections_blocks(*messages:str)->t.List[dict]:return[{_A:_F,_I:[{_A:_D,_B:normalize_message(message)}for message in messages[i:i+2]]}for i in range(0,len(messages),2)]
class SlackAlertIcon(str,Enum):
	X=':x:';OK=':large_green_circle:';START=':arrow_forward:';STOP=':stop_button:';WARN=_K;ALERT=_L;FAILURE=_L;SUCCESS=_M;WARNING=_K;SKIPPED=':fast_forward:';PASSED=_M;UNKNOWN=':question:';INFO=':information_source:';DEBUG=':beetle:';CRITICAL=':fire:';FATAL=':skull_and_crossbones:';EXCEPTION=':boom:'
	def __str__(self)->str:return self.value
def stringify_list(list_variation:t.Union[t.List[str],str])->str:
	if isinstance(list_variation,str):return list_variation
	if len(list_variation)==1:return list_variation[0]
	return' '.join(list_variation)
message=SlackMessageComposer