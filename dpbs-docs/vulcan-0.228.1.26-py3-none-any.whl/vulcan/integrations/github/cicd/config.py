_J='command_namespace'
_I='merge_method'
_H='forward_only_branch_suffix'
_G='pr_include_unmodified'
_F='skip_pr_backfill'
_E='auto_categorize_changes'
_D='github'
_C='enable_deploy_command'
_B=False
_A=None
import typing as t
from enum import Enum
from pydantic import Field
from vulcan.core.config import CategorizerConfig
from vulcan.core.config.base import BaseConfig
from vulcan.utils.date import TimeLike
from vulcan.utils.pydantic import model_validator
from vulcan.core.console import get_console
class MergeMethod(str,Enum):MERGE='merge';SQUASH='squash';REBASE='rebase'
class GithubCICDBotConfig(BaseConfig):
	type_:t.Literal[_D]=Field(alias='type',default=_D);invalidate_environment_after_deploy:bool=True;enable_deploy_command:bool=_B;merge_method:t.Optional[MergeMethod]=_A;command_namespace:t.Optional[str]=_A;auto_categorize_changes_:t.Optional[CategorizerConfig]=Field(default=_A,alias=_E);default_pr_start:t.Optional[TimeLike]=_A;skip_pr_backfill_:t.Optional[bool]=Field(default=_A,alias=_F);pr_include_unmodified_:t.Optional[bool]=Field(default=_A,alias=_G);run_on_deploy_to_prod:bool=_B;pr_environment_name:t.Optional[str]=_A;pr_min_intervals:t.Optional[int]=_A;prod_branch_names_:t.Optional[str]=Field(default=_A,alias='prod_branch_name');forward_only_branch_suffix_:t.Optional[str]=Field(default=_A,alias=_H)
	@model_validator(mode='before')
	@classmethod
	def _validate(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		if data.get(_C)and not data.get(_I):raise ValueError('merge_method must be set if enable_deploy_command is True')
		if data.get(_J)and not data.get(_C):raise ValueError('enable_deploy_command must be set if command_namespace is set')
		return data
	@property
	def prod_branch_names(self)->t.List[str]:
		if self.prod_branch_names_:return[self.prod_branch_names_]
		return['main','master']
	@property
	def auto_categorize_changes(self)->CategorizerConfig:return self.auto_categorize_changes_ or CategorizerConfig.all_off()
	@property
	def pr_include_unmodified(self)->bool:return self.pr_include_unmodified_ or _B
	@property
	def skip_pr_backfill(self)->bool:
		if self.skip_pr_backfill_ is _A:get_console().log_warning('`skip_pr_backfill` is unset, defaulting it to `true` (no data will be backfilled).\nFuture versions of Vulcan will default to `skip_pr_backfill: false` to align with the CLI default behaviour.\nIf you would like to preserve the current behaviour and remove this warning, please explicitly set `skip_pr_backfill: true` in the bot config.\n\nFor more information on configuring the bot, see: https://vulcan.readthedocs.io/en/stable/integrations/github/');return True
		return self.skip_pr_backfill_
	@property
	def forward_only_branch_suffix(self)->str:return self.forward_only_branch_suffix_ or'-forward-only'
	FIELDS_FOR_ANALYTICS:t.ClassVar[t.Set[str]]={'invalidate_environment_after_deploy',_C,_I,_J,_E,'default_pr_start',_F,_G,'run_on_deploy_to_prod','pr_min_intervals',_H}