_K='parent_data_hash'
_J='data_hash'
_I='fingerprint'
_H='_intervals'
_G='identifier'
_F='name'
_E=None
_D='boolean'
_C='dev_version'
_B='bigint'
_A='version'
import typing as t,json,zlib
from sqlglot import exp
from vulcan.utils.migration import index_text_type,blob_text_type
def migrate_schemas(engine_adapter,schema,**kwargs):
	intervals_table=_H
	if schema:intervals_table=f"{schema}.{intervals_table}"
	index_type=index_text_type(engine_adapter.dialect);alter_table_exp=exp.Alter(this=exp.to_table(intervals_table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column(_C),kind=exp.DataType.build(index_type))]);engine_adapter.execute(alter_table_exp)
def migrate_rows(engine_adapter,schema,**kwargs):
	intervals_table=_H;snapshots_table='_snapshots'
	if schema:intervals_table=f"{schema}.{intervals_table}";snapshots_table=f"{schema}.{snapshots_table}"
	used_dev_versions:t.Set[t.Tuple[str,str]]=set();used_versions:t.Set[t.Tuple[str,str]]=set();used_snapshot_ids:t.Set[t.Tuple[str,str]]=set();snapshot_ids_to_dev_versions:t.Dict[t.Tuple[str,str],str]={};_migrate_snapshots(engine_adapter,snapshots_table,used_dev_versions,used_versions,used_snapshot_ids,snapshot_ids_to_dev_versions);_migrate_intervals(engine_adapter,intervals_table,used_dev_versions,used_versions,used_snapshot_ids,snapshot_ids_to_dev_versions)
def _migrate_intervals(engine_adapter:t.Any,intervals_table:str,used_dev_versions:t.Set[t.Tuple[str,str]],used_versions:t.Set[t.Tuple[str,str]],used_snapshot_ids:t.Set[t.Tuple[str,str]],snapshot_ids_to_dev_versions:t.Dict[t.Tuple[str,str],str])->_E:
	G='is_pending_restatement';F='is_compacted';E='is_removed';D='is_dev';C='end_ts';B='start_ts';A='created_ts';import pandas as pd;index_type=index_text_type(engine_adapter.dialect);intervals_columns_to_types={'id':exp.DataType.build(index_type),A:exp.DataType.build(_B),_F:exp.DataType.build(index_type),_G:exp.DataType.build('text'),_A:exp.DataType.build(index_type),_C:exp.DataType.build(index_type),B:exp.DataType.build(_B),C:exp.DataType.build(_B),D:exp.DataType.build(_D),E:exp.DataType.build(_D),F:exp.DataType.build(_D),G:exp.DataType.build(_D)};new_intervals=[]
	for(interval_id,created_ts,name,identifier,version,_,start_ts,end_ts,is_dev,is_removed,is_compacted,is_pending_restatement)in engine_adapter.fetchall(exp.select(*intervals_columns_to_types).from_(intervals_table),quote_identifiers=True):
		if(name,version)not in used_versions:continue
		dev_version=snapshot_ids_to_dev_versions.get((name,identifier))
		if dev_version not in used_dev_versions and is_dev:continue
		if(name,identifier)not in used_snapshot_ids:
			is_compacted=False;identifier=_E
			if not is_dev:dev_version=_E
		new_intervals.append({'id':interval_id,A:created_ts,_F:name,_G:identifier,_A:version,_C:dev_version,B:start_ts,C:end_ts,D:is_dev,E:is_removed,F:is_compacted,G:is_pending_restatement})
	if new_intervals:engine_adapter.delete_from(intervals_table,'TRUE');engine_adapter.insert_append(intervals_table,pd.DataFrame(new_intervals),target_columns_to_types=intervals_columns_to_types)
def _migrate_snapshots(engine_adapter:t.Any,snapshots_table:str,used_dev_versions:t.Set[t.Tuple[str,str]],used_versions:t.Set[t.Tuple[str,str]],used_snapshot_ids:t.Set[t.Tuple[str,str]],snapshot_ids_to_dev_versions:t.Dict[t.Tuple[str,str],str])->_E:
	F='unrestorable';E='ttl_ms';D='unpaused_ts';C='updated_ts';B='kind_name';A='snapshot';import pandas as pd;index_type=index_text_type(engine_adapter.dialect);blob_type=blob_text_type(engine_adapter.dialect);snapshots_columns_to_types={_F:exp.DataType.build(index_type),_G:exp.DataType.build(index_type),_A:exp.DataType.build(index_type),A:exp.DataType.build(blob_type),B:exp.DataType.build(index_type),C:exp.DataType.build(_B),D:exp.DataType.build(_B),E:exp.DataType.build(_B),F:exp.DataType.build(_D)};new_snapshots=[]
	for(name,identifier,version,snapshot,kind_name,updated_ts,unpaused_ts,ttl_ms,unrestorable)in engine_adapter.fetchall(exp.select(*snapshots_columns_to_types).from_(snapshots_table),quote_identifiers=True):
		parsed_snapshot=json.loads(snapshot);version=parsed_snapshot.get(_A)or version;dev_version=get_dev_version(parsed_snapshot);parsed_snapshot[_C]=dev_version;parsed_snapshot[_A]=version;used_dev_versions.add((name,dev_version));used_versions.add((name,version));used_snapshot_ids.add((name,identifier));snapshot_ids_to_dev_versions[name,identifier]=dev_version
		for previous_version in parsed_snapshot.get('previous_versions',[]):previous_identifier=get_identifier(previous_version);previous_dev_version=get_dev_version(previous_version);snapshot_ids_to_dev_versions[name,previous_identifier]=previous_dev_version
		new_snapshots.append({_F:name,_G:identifier,_A:version,A:json.dumps(parsed_snapshot),B:kind_name,C:updated_ts,D:unpaused_ts,E:ttl_ms,F:unrestorable})
	if new_snapshots:engine_adapter.delete_from(snapshots_table,'TRUE');engine_adapter.insert_append(snapshots_table,pd.DataFrame(new_snapshots),target_columns_to_types=snapshots_columns_to_types)
def get_identifier(snapshot:t.Dict[str,t.Any])->str:fingerprint=snapshot[_I];return crc32([fingerprint[_J],fingerprint['metadata_hash'],fingerprint[_K],fingerprint['parent_metadata_hash']])
def get_dev_version(snapshot:t.Dict[str,t.Any])->str:
	dev_version=snapshot.get(_C)
	if dev_version:return dev_version
	fingerprint=snapshot[_I];return crc32([fingerprint[_J],fingerprint[_K]])
def crc32(data:t.Iterable[t.Optional[str]])->str:return str(zlib.crc32(safe_concat(data)))
def safe_concat(data:t.Iterable[t.Optional[str]])->bytes:return';'.join(''if d is _E else d for d in data).encode('utf-8')