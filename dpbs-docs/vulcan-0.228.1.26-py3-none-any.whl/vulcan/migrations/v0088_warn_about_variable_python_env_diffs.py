import json
from sqlglot import exp
from vulcan.core.console import get_console
SQLMESH_VARS='__vulcan__vars__'
SQLMESH_BLUEPRINT_VARS='__vulcan__blueprint__vars__'
METADATA_HASH_EXPRESSIONS={'on_virtual_update','audits','signals','audit_definitions'}
def migrate_schemas(engine_adapter,schema,**kwargs):0
def migrate_rows(engine_adapter,schema,**kwargs):
	snapshots_table='_snapshots'
	if schema:snapshots_table=f"{schema}.{snapshots_table}"
	warning='Vulcan detected that it may not be able to fully migrate the state database. This should not impact the migration process, but may result in unexpected changes being reported by the next `vulcan plan` command. Please run `vulcan diff prod` after the migration has completed, before making any new changes. If any unexpected changes are reported, consider running a forward-only plan to apply these changes and avoid unnecessary backfills: vulcan plan prod --forward-only. See https://vulcan.readthedocs.io/en/stable/concepts/plans/#forward-only-plans for more details.\n'
	for(snapshot,)in engine_adapter.fetchall(exp.select('snapshot').from_(snapshots_table),quote_identifiers=True):
		parsed_snapshot=json.loads(snapshot);node=parsed_snapshot['node']
		if node.get('source_type')=='audit':continue
		python_env=node.get('python_env')or{}
		if SQLMESH_BLUEPRINT_VARS in python_env or SQLMESH_VARS in python_env and(any(v.get('is_metadata')for v in python_env.values())or any(node.get(k)for k in METADATA_HASH_EXPRESSIONS)):get_console().log_warning(warning);return