_A=True
import json,logging,typing as t
from dataclasses import dataclass
from sqlglot import exp
from vulcan.utils.migration import index_text_type,blob_text_type
logger=logging.getLogger(__name__)
KEYS_TO_MAKE_DETERMINISTIC=['__vulcan__vars__','__vulcan__blueprint__vars__']
@dataclass
class SqlValue:sql:str
def _dict_sort(obj:t.Any)->str:
	try:
		if isinstance(obj,dict):obj=dict(sorted(obj.items(),key=lambda x:str(x[0])))
	except Exception:logger.warning('Failed to sort non-recursive dict',exc_info=_A)
	return repr(obj)
def migrate_schemas(engine_adapter,schema,**kwargs):0
def migrate_rows(engine_adapter,schema,**kwargs):
	K='payload';J='bigint';I='unrestorable';H='ttl_ms';G='unpaused_ts';F='updated_ts';E='kind_name';D='snapshot';C='version';B='identifier';A='name';import pandas as pd;snapshots_table='_snapshots'
	if schema:snapshots_table=f"{schema}.{snapshots_table}"
	migration_needed=False;new_snapshots=[]
	for(name,identifier,version,snapshot,kind_name,updated_ts,unpaused_ts,ttl_ms,unrestorable)in engine_adapter.fetchall(exp.select(A,B,C,D,E,F,G,H,I).from_(snapshots_table),quote_identifiers=_A):
		parsed_snapshot=json.loads(snapshot);python_env=parsed_snapshot['node'].get('python_env')
		if python_env:
			for(key,executable)in python_env.items():
				if key not in KEYS_TO_MAKE_DETERMINISTIC:continue
				if isinstance(executable,dict)and executable.get('kind')=='value':
					old_payload=executable[K]
					try:
						parsed_value=eval(old_payload);new_payload=_dict_sort(parsed_value)
						if old_payload!=new_payload:executable[K]=new_payload;migration_needed=_A
					except Exception:logger.warning('Exception trying to eval payload',exc_info=_A)
		new_snapshots.append({A:name,B:identifier,C:version,D:json.dumps(parsed_snapshot),E:kind_name,F:updated_ts,G:unpaused_ts,H:ttl_ms,I:unrestorable})
	if migration_needed and new_snapshots:engine_adapter.delete_from(snapshots_table,'TRUE');index_type=index_text_type(engine_adapter.dialect);blob_type=blob_text_type(engine_adapter.dialect);engine_adapter.insert_append(snapshots_table,pd.DataFrame(new_snapshots),target_columns_to_types={A:exp.DataType.build(index_type),B:exp.DataType.build(index_type),C:exp.DataType.build(index_type),D:exp.DataType.build(blob_type),E:exp.DataType.build('text'),F:exp.DataType.build(J),G:exp.DataType.build(J),H:exp.DataType.build(J),I:exp.DataType.build('boolean')})