_B='gateway_managed'
_A='_environments'
from sqlglot import exp
def migrate_schemas(engine_adapter,schema,**kwargs):
	environments_table=_A
	if schema:environments_table=f"{schema}.{environments_table}"
	alter_table_exp=exp.Alter(this=exp.to_table(environments_table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column(_B),kind=exp.DataType.build('boolean'))]);engine_adapter.execute(alter_table_exp)
def migrate_rows(engine_adapter,schema,**kwargs):
	environments_table=_A
	if schema:environments_table=f"{schema}.{environments_table}"
	engine_adapter.update_table(environments_table,{_B:False},where=exp.true())