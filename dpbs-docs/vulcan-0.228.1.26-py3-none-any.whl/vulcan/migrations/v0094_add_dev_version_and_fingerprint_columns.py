_C='_snapshots'
_B='fingerprint'
_A='dev_version'
import json
from sqlglot import exp
from vulcan.utils.migration import index_text_type,blob_text_type
def migrate_schemas(engine_adapter,schema,**kwargs):
	A='TABLE';snapshots_table=_C
	if schema:snapshots_table=f"{schema}.{snapshots_table}"
	index_type=index_text_type(engine_adapter.dialect);blob_type=blob_text_type(engine_adapter.dialect);add_dev_version_exp=exp.Alter(this=exp.to_table(snapshots_table),kind=A,actions=[exp.ColumnDef(this=exp.to_column(_A),kind=exp.DataType.build(index_type))]);engine_adapter.execute(add_dev_version_exp);add_fingerprint_exp=exp.Alter(this=exp.to_table(snapshots_table),kind=A,actions=[exp.ColumnDef(this=exp.to_column(_B),kind=exp.DataType.build(blob_type))]);engine_adapter.execute(add_fingerprint_exp)
def migrate_rows(engine_adapter,schema,**kwargs):
	L='boolean';K='bigint';J='forward_only';I='unrestorable';H='ttl_ms';G='unpaused_ts';F='updated_ts';E='kind_name';D='snapshot';C='version';B='identifier';A='name';import pandas as pd;snapshots_table=_C
	if schema:snapshots_table=f"{schema}.{snapshots_table}"
	index_type=index_text_type(engine_adapter.dialect);blob_type=blob_text_type(engine_adapter.dialect);new_snapshots=[]
	for(name,identifier,version,snapshot,kind_name,updated_ts,unpaused_ts,ttl_ms,unrestorable,forward_only,_,_)in engine_adapter.fetchall(exp.select(A,B,C,D,E,F,G,H,I,J,_A,_B).from_(snapshots_table),quote_identifiers=True):parsed_snapshot=json.loads(snapshot);new_snapshots.append({A:name,B:identifier,C:version,D:snapshot,E:kind_name,F:updated_ts,G:unpaused_ts,H:ttl_ms,I:unrestorable,J:forward_only,_A:parsed_snapshot.get(_A),_B:json.dumps(parsed_snapshot.get(_B))})
	if new_snapshots:engine_adapter.delete_from(snapshots_table,'TRUE');engine_adapter.insert_append(snapshots_table,pd.DataFrame(new_snapshots),target_columns_to_types={A:exp.DataType.build(index_type),B:exp.DataType.build(index_type),C:exp.DataType.build(index_type),D:exp.DataType.build(blob_type),E:exp.DataType.build(index_type),F:exp.DataType.build(K),G:exp.DataType.build(K),H:exp.DataType.build(K),I:exp.DataType.build(L),J:exp.DataType.build(L),_A:exp.DataType.build(index_type),_B:exp.DataType.build(blob_type)})