_C='_snapshots'
_B='boolean'
_A='forward_only'
import json
from sqlglot import exp
from vulcan.utils.migration import index_text_type,blob_text_type
def migrate_schemas(engine_adapter,schema,**kwargs):
	snapshots_table=_C
	if schema:snapshots_table=f"{schema}.{snapshots_table}"
	alter_table_exp=exp.Alter(this=exp.to_table(snapshots_table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column(_A),kind=exp.DataType.build(_B))]);engine_adapter.execute(alter_table_exp)
def migrate_rows(engine_adapter,schema,**kwargs):
	J='bigint';I='unrestorable';H='ttl_ms';G='unpaused_ts';F='updated_ts';E='kind_name';D='snapshot';C='version';B='identifier';A='name';import pandas as pd;snapshots_table=_C
	if schema:snapshots_table=f"{schema}.{snapshots_table}"
	new_snapshots=[]
	for(name,identifier,version,snapshot,kind_name,updated_ts,unpaused_ts,ttl_ms,unrestorable,forward_only)in engine_adapter.fetchall(exp.select(A,B,C,D,E,F,G,H,I,_A).from_(snapshots_table),quote_identifiers=True):
		parsed_snapshot=json.loads(snapshot);forward_only=parsed_snapshot.get(_A)
		if forward_only is None:forward_only=parsed_snapshot.get('change_category')==3
		new_snapshots.append({A:name,B:identifier,C:version,D:json.dumps(parsed_snapshot),E:kind_name,F:updated_ts,G:unpaused_ts,H:ttl_ms,I:unrestorable,_A:forward_only})
	if new_snapshots:engine_adapter.delete_from(snapshots_table,'TRUE');index_type=index_text_type(engine_adapter.dialect);blob_type=blob_text_type(engine_adapter.dialect);engine_adapter.insert_append(snapshots_table,pd.DataFrame(new_snapshots),target_columns_to_types={A:exp.DataType.build(index_type),B:exp.DataType.build(index_type),C:exp.DataType.build(index_type),D:exp.DataType.build(blob_type),E:exp.DataType.build(index_type),F:exp.DataType.build(J),G:exp.DataType.build(J),H:exp.DataType.build(J),I:exp.DataType.build(_B),_A:exp.DataType.build(_B)})