from sqlglot import exp
from vulcan.utils.migration import index_text_type
def migrate_schemas(engine_adapter,schema,**kwargs):
	F='bigint';E='metadata';D='updated_at';C='followed_at';B='active';A='user_id';followers_table='_followers'
	if schema:followers_table=f"{schema}.{followers_table}"
	index_type=index_text_type(engine_adapter.dialect);followers_columns_to_types={A:exp.DataType.build(index_type),B:exp.DataType.build('boolean'),C:exp.DataType.build(F),D:exp.DataType.build(F),E:exp.DataType.build('jsonb')};engine_adapter.create_state_table(followers_table,followers_columns_to_types,primary_key=(A,),table_description='Users following this data product',column_descriptions={A:'Heimdall user identifier (primary key)',B:'Whether the user is currently following',C:'Unix timestamp (seconds) when the user first followed',D:'Unix timestamp (seconds) of the last follow/unfollow mutation',E:'Optional JSON metadata for future extensions'});engine_adapter.create_index(followers_table,'idx_followers_active_followed_at',(B,C))
def migrate_rows(engine_adapter,schema,**kwargs):0