import json
from sqlglot import exp
from vulcan.utils.migration import index_text_type,blob_text_type
def migrate_schemas(engine_adapter,schema,**kwargs):0
def migrate_rows(engine_adapter,schema,**kwargs):
	J='unrestorable';I='ttl_ms';H='unpaused_ts';G='updated_ts';F='kind_name';E='snapshot';D='version';C='identifier';B='name';A='bigint';import pandas as pd;snapshots_table='_snapshots'
	if schema:snapshots_table=f"{schema}.{snapshots_table}"
	index_type=index_text_type(engine_adapter.dialect);blob_type=blob_text_type(engine_adapter.dialect);snapshots_columns_to_types={B:exp.DataType.build(index_type),C:exp.DataType.build(index_type),D:exp.DataType.build(index_type),E:exp.DataType.build(blob_type),F:exp.DataType.build(index_type),G:exp.DataType.build(A),H:exp.DataType.build(A),I:exp.DataType.build(A),J:exp.DataType.build('boolean')};new_snapshots=[]
	for(name,identifier,version,snapshot,kind_name,updated_ts,unpaused_ts,ttl_ms,unrestorable)in engine_adapter.fetchall(exp.select(*snapshots_columns_to_types).from_(snapshots_table),quote_identifiers=True):
		parsed_snapshot=json.loads(snapshot);kind=parsed_snapshot['node'].get('kind')
		if kind and kind_name in('EMBEDDED','EXTERNAL'):kind.pop('disable_restatement',None)
		new_snapshots.append({B:name,C:identifier,D:version,E:json.dumps(parsed_snapshot),F:kind_name,G:updated_ts,H:unpaused_ts,I:ttl_ms,J:unrestorable})
	if new_snapshots:engine_adapter.delete_from(snapshots_table,'TRUE');engine_adapter.insert_append(snapshots_table,pd.DataFrame(new_snapshots),target_columns_to_types=snapshots_columns_to_types)