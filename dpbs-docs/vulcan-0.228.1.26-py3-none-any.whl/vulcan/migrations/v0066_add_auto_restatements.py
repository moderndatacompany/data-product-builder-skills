_B='is_pending_restatement'
_A='_intervals'
from sqlglot import exp
from vulcan.utils.migration import index_text_type
def migrate_schemas(engine_adapter,schema,**kwargs):
	B='snapshot_version';A='snapshot_name';auto_restatements_table='_auto_restatements';intervals_table=_A
	if schema:auto_restatements_table=f"{schema}.{auto_restatements_table}";intervals_table=f"{schema}.{intervals_table}"
	index_type=index_text_type(engine_adapter.dialect);engine_adapter.create_state_table(auto_restatements_table,{A:exp.DataType.build(index_type),B:exp.DataType.build(index_type),'next_auto_restatement_ts':exp.DataType.build('bigint')},primary_key=(A,B));alter_table_exp=exp.Alter(this=exp.to_table(intervals_table),kind='TABLE',actions=[exp.ColumnDef(this=exp.to_column(_B),kind=exp.DataType.build('boolean'))]);engine_adapter.execute(alter_table_exp)
def migrate_rows(engine_adapter,schema,**kwargs):
	intervals_table=_A
	if schema:intervals_table=f"{schema}.{intervals_table}"
	engine_adapter.update_table(intervals_table,{_B:False},where=exp.true())