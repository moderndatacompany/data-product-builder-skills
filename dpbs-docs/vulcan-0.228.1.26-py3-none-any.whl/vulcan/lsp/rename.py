import typing as t
from lsprotocol.types import Position,TextEdit,WorkspaceEdit,PrepareRenameResult_Type1,DocumentHighlight,DocumentHighlightKind
from vulcan.lsp.context import LSPContext
from vulcan.lsp.helpers import to_vulcan_position,to_lsp_range
from vulcan.lsp.reference import _position_within_range,get_cte_references,CTEReference
from vulcan.lsp.uri import URI
def prepare_rename(lsp_context:LSPContext,document_uri:URI,lsp_position:Position)->t.Optional[PrepareRenameResult_Type1]:
	position=to_vulcan_position(lsp_position);cte_references=get_cte_references(lsp_context,document_uri,position)
	if cte_references:
		target_range=None
		for ref in cte_references:
			if _position_within_range(position,ref.range):target_range=ref.target_range;break
			elif _position_within_range(position,ref.target_range):target_range=ref.target_range;break
		if target_range:return PrepareRenameResult_Type1(range=to_lsp_range(target_range),placeholder='cte_name')
def rename_symbol(lsp_context:LSPContext,document_uri:URI,lsp_position:Position,new_name:str)->t.Optional[WorkspaceEdit]:
	cte_references=get_cte_references(lsp_context,document_uri,to_vulcan_position(lsp_position))
	if cte_references:return _rename_cte(cte_references,new_name)
def _rename_cte(cte_references:t.List[CTEReference],new_name:str)->WorkspaceEdit:
	changes:t.Dict[str,t.List[TextEdit]]={}
	for ref in cte_references:
		uri=URI.from_path(ref.path).value
		if uri not in changes:changes[uri]=[]
		text_edit=TextEdit(range=to_lsp_range(ref.range),new_text=new_name);changes[uri].append(text_edit)
	return WorkspaceEdit(changes=changes)
def get_document_highlights(lsp_context:LSPContext,document_uri:URI,position:Position)->t.Optional[t.List[DocumentHighlight]]:
	cte_references=get_cte_references(lsp_context,document_uri,to_vulcan_position(position))
	if cte_references:
		highlights=[]
		for ref in cte_references:kind=DocumentHighlightKind.Write if ref.range==ref.target_range else DocumentHighlightKind.Read;highlights.append(DocumentHighlight(range=to_lsp_range(ref.range),kind=kind))
		return highlights