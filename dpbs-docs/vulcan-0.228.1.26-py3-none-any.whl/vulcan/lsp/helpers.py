from lsprotocol.types import Range,Position
from vulcan.core.linter.helpers import Range as VulcanRange,Position as VulcanPosition
def to_vulcan_position(position:Position)->VulcanPosition:return VulcanPosition(line=position.line,character=position.character)
def to_lsp_position(position:VulcanPosition)->Position:return Position(line=position.line,character=position.character)
def to_vulcan_range(range:Range)->VulcanRange:return VulcanRange(start=to_vulcan_position(range.start),end=to_vulcan_position(range.end))
def to_lsp_range(range:VulcanRange)->Range:return Range(start=to_lsp_position(range.start),end=to_lsp_position(range.end))