#!/usr/bin/env python
_D='yaml'
_C='yml'
_B=False
_A=None
from itertools import chain
import logging,typing as t
from pathlib import Path
import urllib.parse,uuid
from lsprotocol import types
from lsprotocol.types import WorkspaceDiagnosticRefreshRequest,WorkspaceInlayHintRefreshRequest
from pygls.server import LanguageServer
from sqlglot import exp
from vulcan._version import __version__
from vulcan.core.context import Context
from vulcan.utils.date import to_timestamp
from vulcan.lsp.api import API_FEATURE,ApiRequest,ApiResponseGetColumnLineage,ApiResponseGetLineage,ApiResponseGetModels,ApiResponseGetTableDiff
from vulcan.lsp.commands import EXTERNAL_MODEL_UPDATE_COLUMNS
from vulcan.lsp.completions import get_sql_completions
from vulcan.lsp.context import LSPContext,ModelTarget
from vulcan.lsp.custom import ALL_MODELS_FEATURE,ALL_MODELS_FOR_RENDER_FEATURE,RENDER_MODEL_FEATURE,SUPPORTED_METHODS_FEATURE,FORMAT_PROJECT_FEATURE,GET_ENVIRONMENTS_FEATURE,GET_MODELS_FEATURE,AllModelsRequest,AllModelsResponse,AllModelsForRenderRequest,AllModelsForRenderResponse,CustomMethodResponseBaseClass,RenderModelRequest,RenderModelResponse,SupportedMethodsRequest,SupportedMethodsResponse,FormatProjectRequest,FormatProjectResponse,CustomMethod,LIST_WORKSPACE_TESTS_FEATURE,ListWorkspaceTestsRequest,ListWorkspaceTestsResponse,LIST_DOCUMENT_TESTS_FEATURE,ListDocumentTestsRequest,ListDocumentTestsResponse,RUN_TEST_FEATURE,RunTestRequest,RunTestResponse,GetEnvironmentsRequest,GetEnvironmentsResponse,EnvironmentInfo,GetModelsRequest,GetModelsResponse,ModelInfo
from vulcan.lsp.errors import ContextFailedError,context_error_to_diagnostic
from vulcan.lsp.helpers import to_lsp_range,to_vulcan_position
from vulcan.lsp.hints import get_hints
from vulcan.lsp.reference import CTEReference,ModelReference,get_references,get_all_references
from vulcan.lsp.rename import prepare_rename,rename_symbol,get_document_highlights
from vulcan.lsp.uri import URI
from vulcan.utils.errors import ConfigError
from vulcan.utils.lineage import ExternalModelReference
from vulcan.utils.pydantic import PydanticModel
from web.server.api.endpoints.lineage import column_lineage,model_lineage
from web.server.api.endpoints.models import get_models
from web.server.api.endpoints.table_diff import _process_sample_data
from typing import Union
from dataclasses import dataclass,field
from web.server.models import RowDiff,SchemaDiff,TableDiff
class InitializationOptions(PydanticModel):project_paths:t.Optional[t.List[str]]=_A
@dataclass
class NoContext:version_id:str=field(default_factory=lambda:str(uuid.uuid4()))
@dataclass
class ContextLoaded:lsp_context:LSPContext;version_id:str=field(default_factory=lambda:str(uuid.uuid4()))
@dataclass
class ContextFailed:error:ContextFailedError;context:t.Optional[Context]=_A;version_id:str=field(default_factory=lambda:str(uuid.uuid4()))
ContextState=Union[NoContext,ContextLoaded,ContextFailed]
class VulcanLanguageServer:
	specified_paths:t.Optional[t.List[Path]]=_A
	def __init__(self,context_class:t.Type[Context],server_name:str='vulcan_lsp',version:str=__version__):self.server=LanguageServer(server_name,version,max_workers=1);self.context_class=context_class;(self.context_state):ContextState=NoContext();(self.workspace_folders):t.List[Path]=[];(self.has_raised_loading_error):bool=_B;self.client_supports_pull_diagnostics=_B;(self._supported_custom_methods):t.Dict[str,t.Callable[[LanguageServer,t.Any],t.Any]]={ALL_MODELS_FEATURE:self._custom_all_models,RENDER_MODEL_FEATURE:self._custom_render_model,ALL_MODELS_FOR_RENDER_FEATURE:self._custom_all_models_for_render,API_FEATURE:self._custom_api,SUPPORTED_METHODS_FEATURE:self._custom_supported_methods,FORMAT_PROJECT_FEATURE:self._custom_format_project,LIST_WORKSPACE_TESTS_FEATURE:self._list_workspace_tests,LIST_DOCUMENT_TESTS_FEATURE:self._list_document_tests,RUN_TEST_FEATURE:self._run_test,GET_ENVIRONMENTS_FEATURE:self._custom_get_environments,GET_MODELS_FEATURE:self._custom_get_models};self._register_features()
	def _list_workspace_tests(self,ls:LanguageServer,params:ListWorkspaceTestsRequest)->ListWorkspaceTestsResponse:
		try:context=self._context_get_or_load();tests=context.list_workspace_tests();return ListWorkspaceTestsResponse(tests=tests)
		except Exception as e:ls.log_trace(f"Error listing workspace tests: {e}");return ListWorkspaceTestsResponse(tests=[])
	def _list_document_tests(self,ls:LanguageServer,params:ListDocumentTestsRequest)->ListDocumentTestsResponse:
		try:uri=URI(params.textDocument.uri);context=self._context_get_or_load(uri);tests=context.get_document_tests(uri);return ListDocumentTestsResponse(tests=tests)
		except Exception as e:ls.log_trace(f"Error listing document tests: {e}");return ListDocumentTestsResponse(tests=[])
	def _run_test(self,ls:LanguageServer,params:RunTestRequest)->RunTestResponse:
		try:uri=URI(params.textDocument.uri);context=self._context_get_or_load(uri);result=context.run_test(uri,params.testName);return result
		except Exception as e:ls.log_trace(f"Error running test: {e}");return RunTestResponse(success=_B,response_error=str(e))
	def _custom_all_models(self,ls:LanguageServer,params:AllModelsRequest)->AllModelsResponse:
		uri=URI(params.textDocument.uri);content=_A
		try:document=ls.workspace.get_text_document(params.textDocument.uri);content=document.source
		except Exception:pass
		try:context=self._context_get_or_load(uri);return LSPContext.get_completions(context,uri,content)
		except Exception as e:from vulcan.lsp.completions import get_sql_completions;return get_sql_completions(_A,URI(params.textDocument.uri),content)
	def _custom_render_model(self,ls:LanguageServer,params:RenderModelRequest)->RenderModelResponse:uri=URI(params.textDocumentUri);context=self._context_get_or_load(uri);return RenderModelResponse(models=context.render_model(uri))
	def _custom_all_models_for_render(self,ls:LanguageServer,params:AllModelsForRenderRequest)->AllModelsForRenderResponse:context=self._context_get_or_load();return AllModelsForRenderResponse(models=context.list_of_models_for_rendering())
	def _custom_format_project(self,ls:LanguageServer,params:FormatProjectRequest)->FormatProjectResponse:
		try:context=self._context_get_or_load();context.context.format();return FormatProjectResponse()
		except Exception as e:ls.log_trace(f"Error formatting project: {e}");return FormatProjectResponse()
	def _custom_get_environments(self,ls:LanguageServer,params:GetEnvironmentsRequest)->GetEnvironmentsResponse:
		try:
			context=self._context_get_or_load();environments={}
			for env in context.context.state_reader.get_environments():environments[env.name]=EnvironmentInfo(name=env.name,snapshots=[s.fingerprint.to_identifier()for s in env.snapshots],start_at=str(to_timestamp(env.start_at)),plan_id=env.plan_id or'')
			return GetEnvironmentsResponse(environments=environments,pinned_environments=context.context.config.pinned_environments,default_target_environment=context.context.config.default_target_environment)
		except Exception as e:ls.log_trace(f"Error getting environments: {e}");return GetEnvironmentsResponse(response_error=str(e),environments={},pinned_environments=set(),default_target_environment='')
	def _custom_get_models(self,ls:LanguageServer,params:GetModelsRequest)->GetModelsResponse:
		try:context=self._context_get_or_load();models=[ModelInfo(name=model.name,fqn=model.fqn,description=model.description)for model in context.context.models.values()if model._path is not _A];return GetModelsResponse(models=models)
		except Exception as e:ls.log_trace(f"Error getting table diff models: {e}");return GetModelsResponse(response_error=str(e),models=[])
	def _custom_api(self,ls:LanguageServer,request:ApiRequest)->t.Union[ApiResponseGetModels,ApiResponseGetColumnLineage,ApiResponseGetLineage,ApiResponseGetTableDiff]:
		A='api';ls.log_trace(f"API request: {request}");context=self._context_get_or_load();parsed_url=urllib.parse.urlparse(request.url);path_parts=parsed_url.path.strip('/').split('/')
		if request.method=='GET':
			if path_parts==[A,'models']:return ApiResponseGetModels(data=get_models(context.context))
			if path_parts[:2]==[A,'lineage']:
				if len(path_parts)==3:model_name=urllib.parse.unquote(path_parts[2]);lineage=model_lineage(model_name,context.context);non_set_lineage={k:v for(k,v)in lineage.items()if v is not _A};return ApiResponseGetLineage(data=non_set_lineage)
				if len(path_parts)==4:
					model_name=urllib.parse.unquote(path_parts[2]);column=urllib.parse.unquote(path_parts[3]);models_only=_B
					if hasattr(request,'params'):models_only=bool(getattr(request.params,'models_only',_B))
					column_lineage_response=column_lineage(model_name,column,models_only,context.context);return ApiResponseGetColumnLineage(data=column_lineage_response)
			if path_parts[:2]==[A,'table_diff']:
				import numpy as np;params=request.params;table_diff_result:t.Optional[TableDiff]=_A
				if(params:=request.params):
					source=getattr(params,'source','')if params else'';target=getattr(params,'target','')if params else'';on=getattr(params,'on',_A)if params else _A;model_or_snapshot=getattr(params,'model_or_snapshot',_A)if params else _A;where=getattr(params,'where',_A)if params else _A;temp_schema=getattr(params,'temp_schema',_A)if params else _A;limit=getattr(params,'limit',20)if params else 20;table_diffs=context.context.table_diff(source=source,target=target,on=exp.condition(on)if on else _A,select_models={model_or_snapshot}if model_or_snapshot else _A,where=where,limit=limit,show=_B)
					if table_diffs:diff=table_diffs[0]if isinstance(table_diffs,list)else table_diffs;_schema_diff=diff.schema_diff();_row_diff=diff.row_diff(temp_schema=temp_schema);schema_diff=SchemaDiff(source=_schema_diff.source,target=_schema_diff.target,source_schema=_schema_diff.source_schema,target_schema=_schema_diff.target_schema,added=_schema_diff.added,removed=_schema_diff.removed,modified=_schema_diff.modified);processed_sample_data=_process_sample_data(_row_diff,source,target);row_diff=RowDiff(source=_row_diff.source,target=_row_diff.target,stats=_row_diff.stats,sample=_row_diff.sample.replace({np.nan:_A}).to_dict(),joined_sample=_row_diff.joined_sample.replace({np.nan:_A}).to_dict(),s_sample=_row_diff.s_sample.replace({np.nan:_A}).to_dict(),t_sample=_row_diff.t_sample.replace({np.nan:_A}).to_dict(),column_stats=_row_diff.column_stats.replace({np.nan:_A}).to_dict(),source_count=_row_diff.source_count,target_count=_row_diff.target_count,count_pct_change=_row_diff.count_pct_change,decimals=getattr(_row_diff,'decimals',3),processed_sample_data=processed_sample_data);s_index,t_index,_=diff.key_columns;table_diff_result=TableDiff(schema_diff=schema_diff,row_diff=row_diff,on=[(s.name,t.name)for(s,t)in zip(s_index,t_index)])
				return ApiResponseGetTableDiff(data=table_diff_result)
		raise NotImplementedError(f"API request not implemented: {request.url}")
	def _custom_supported_methods(self,ls:LanguageServer,params:SupportedMethodsRequest)->SupportedMethodsResponse:return SupportedMethodsResponse(methods=[CustomMethod(name=name)for name in self._supported_custom_methods])
	def _reload_context_and_publish_diagnostics(self,ls:LanguageServer,uri:URI,document_uri:str)->_A:
		if isinstance(self.context_state,NoContext):0
		elif isinstance(self.context_state,ContextFailed):
			if self.context_state.context:
				try:self.context_state.context.load();self.context_state=ContextLoaded(lsp_context=LSPContext(self.context_state.context))
				except Exception as e:ls.log_trace(f"Error loading context: {e}");context=self.context_state.context if hasattr(self.context_state,'context')else _A;self.context_state=ContextFailed(error=e,context=context)
			else:
				ls.log_trace('No partial context available, attempting fresh creation');self.context_state=NoContext();self.has_raised_loading_error=_B
				try:
					self._ensure_context_for_document(uri)
					if isinstance(self.context_state,ContextLoaded):loaded_vulcan_message(ls)
				except Exception as e:ls.log_trace(f"Still cannot load context: {e}")
		else:
			try:context=self.context_state.lsp_context.context;context.load();self.context_state=ContextLoaded(lsp_context=LSPContext(context))
			except Exception as e:ls.log_trace(f"Error loading context: {e}");self.context_state=ContextFailed(error=e,context=self.context_state.lsp_context.context)
		ls.lsp.send_request(types.WORKSPACE_DIAGNOSTIC_REFRESH,WorkspaceDiagnosticRefreshRequest(id=self.context_state.version_id));ls.lsp.send_request(types.WORKSPACE_INLAY_HINT_REFRESH,WorkspaceInlayHintRefreshRequest(id=self.context_state.version_id))
		if not self.client_supports_pull_diagnostics:
			if hasattr(self.context_state,'lsp_context'):diagnostics=self.context_state.lsp_context.lint_model(uri);ls.publish_diagnostics(document_uri,LSPContext.diagnostics_to_lsp_diagnostics(diagnostics))
	def _register_features(self)->_A:
		for(name,method)in self._supported_custom_methods.items():
			def create_function_call(method_func:t.Callable)->t.Callable:
				def function_call(ls:LanguageServer,params:t.Any)->t.Dict[str,t.Any]:
					try:response=method_func(ls,params)
					except Exception as e:response=CustomMethodResponseBaseClass(response_error=str(e))
					return response.model_dump(mode='json')
				return function_call
			self.server.feature(name)(create_function_call(method))
		@self.server.command(EXTERNAL_MODEL_UPDATE_COLUMNS)
		def command_external_models_update_columns(ls:LanguageServer,raw:t.Any)->_A:
			try:
				if not isinstance(raw,list):raise ValueError('Invalid command parameters')
				if len(raw)!=1:raise ValueError('Command expects exactly one parameter')
				model_name=raw[0]
				if not isinstance(model_name,str):raise ValueError('Command parameter must be a string')
				context=self._context_get_or_load()
				if not isinstance(context,LSPContext):raise ValueError('Context is not loaded or invalid')
				model=context.context.get_model(model_name)
				if model is _A:raise ValueError(f"External model '{model_name}' not found")
				if model._path is _A:raise ValueError(f"External model '{model_name}' does not have a file path")
				uri=URI.from_path(model._path);updated=context.update_external_model_columns(ls=ls,uri=uri,model_name=model_name)
				if updated:ls.show_message(f"Updated columns for '{model_name}'",types.MessageType.Info)
				else:ls.show_message(f"Columns for '{model_name}' are already up to date")
			except Exception as e:ls.show_message(f"Error executing command: {e}",types.MessageType.Error);return
		@self.server.feature(types.INITIALIZE)
		def initialize(ls:LanguageServer,params:types.InitializeParams)->_A:
			try:
				if params.initialization_options:
					options=InitializationOptions.model_validate(params.initialization_options)
					if options.project_paths is not _A:self.specified_paths=[Path(path)for path in options.project_paths]
				if params.capabilities and params.capabilities.text_document:
					diagnostics=getattr(params.capabilities.text_document,'diagnostic',_A)
					if diagnostics:self.client_supports_pull_diagnostics=True;ls.log_trace('Client supports pull diagnostics')
					else:self.client_supports_pull_diagnostics=_B;ls.log_trace('Client does not support pull diagnostics')
				else:self.client_supports_pull_diagnostics=_B
				if params.workspace_folders:
					self.workspace_folders=[Path(self._uri_to_path(folder.uri))for folder in params.workspace_folders]
					for folder_path in self.workspace_folders:
						for ext in('py',_C,_D):
							config_path=folder_path/f"config.{ext}"
							if config_path.exists():
								if self._create_lsp_context([folder_path]):loaded_vulcan_message(ls);return
			except Exception as e:ls.log_trace(f"Error initializing Vulcan context: {e}")
		@self.server.feature(types.TEXT_DOCUMENT_DID_OPEN)
		def did_open(ls:LanguageServer,params:types.DidOpenTextDocumentParams)->_A:
			uri=URI(params.text_document.uri);context=self._context_get_or_load(uri)
			if not self.client_supports_pull_diagnostics:diagnostics=context.lint_model(uri);ls.publish_diagnostics(params.text_document.uri,LSPContext.diagnostics_to_lsp_diagnostics(diagnostics))
		@self.server.feature(types.TEXT_DOCUMENT_DID_SAVE)
		def did_save(ls:LanguageServer,params:types.DidSaveTextDocumentParams)->_A:uri=URI(params.text_document.uri);self._reload_context_and_publish_diagnostics(ls,uri,params.text_document.uri)
		@self.server.feature(types.TEXT_DOCUMENT_FORMATTING)
		def formatting(ls:LanguageServer,params:types.DocumentFormattingParams)->t.List[types.TextEdit]:
			try:
				uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);document=ls.workspace.get_text_document(params.text_document.uri);before=document.source;target=next((target for target in chain(context.context._models.values(),context.context._audits.values())if target._path is not _A and target._path.suffix=='.sql'and target._path.samefile(uri.to_path())),_A)
				if target is _A:return[]
				after=context.context._format(target=target,before=before);return[types.TextEdit(range=types.Range(start=types.Position(line=0,character=0),end=types.Position(line=len(document.lines),character=len(document.lines[-1])if document.lines else 0)),new_text=after)]
			except Exception as e:ls.show_message(f"Error formatting SQL: {e}",types.MessageType.Error);return[]
		@self.server.feature(types.TEXT_DOCUMENT_HOVER)
		def hover(ls:LanguageServer,params:types.HoverParams)->t.Optional[types.Hover]:
			try:
				uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);document=ls.workspace.get_text_document(params.text_document.uri);references=get_references(context,uri,to_vulcan_position(params.position))
				if not references:return
				reference=references[0]
				if isinstance(reference,CTEReference)or not reference.markdown_description:return
				return types.Hover(contents=types.MarkupContent(kind=types.MarkupKind.Markdown,value=reference.markdown_description),range=to_lsp_range(reference.range))
			except Exception as e:ls.log_trace(f"Error getting hover information: {e}");return
		@self.server.feature(types.TEXT_DOCUMENT_INLAY_HINT)
		def inlay_hint(ls:LanguageServer,params:types.InlayHintParams)->t.List[types.InlayHint]:
			try:uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);start_line=params.range.start.line;end_line=params.range.end.line;hints=get_hints(context,uri,start_line,end_line);return hints
			except Exception as e:return[]
		@self.server.feature(types.TEXT_DOCUMENT_DEFINITION)
		def goto_definition(ls:LanguageServer,params:types.DefinitionParams)->t.List[types.LocationLink]:
			try:
				uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);references=get_references(context,uri,to_vulcan_position(params.position));location_links=[]
				for reference in references:
					if isinstance(reference,ModelReference):target_range=types.Range(start=types.Position(line=0,character=0),end=types.Position(line=0,character=0));target_selection_range=types.Range(start=types.Position(line=0,character=0),end=types.Position(line=0,character=0))
					elif isinstance(reference,ExternalModelReference):
						target_range=types.Range(start=types.Position(line=0,character=0),end=types.Position(line=0,character=0));target_selection_range=types.Range(start=types.Position(line=0,character=0),end=types.Position(line=0,character=0))
						if reference.target_range is not _A:target_range=to_lsp_range(reference.target_range);target_selection_range=to_lsp_range(reference.target_range)
					else:target_range=to_lsp_range(reference.target_range);target_selection_range=to_lsp_range(reference.target_range)
					if reference.path is not _A:location_links.append(types.LocationLink(target_uri=URI.from_path(reference.path).value,target_selection_range=target_selection_range,target_range=target_range,origin_selection_range=to_lsp_range(reference.range)))
				return location_links
			except Exception as e:ls.show_message(f"Error getting references: {e}",types.MessageType.Error);return[]
		@self.server.feature(types.TEXT_DOCUMENT_REFERENCES)
		def find_references(ls:LanguageServer,params:types.ReferenceParams)->t.Optional[t.List[types.Location]]:
			try:uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);all_references=get_all_references(context,uri,to_vulcan_position(params.position));locations=[types.Location(uri=URI.from_path(ref.path).value,range=to_lsp_range(ref.range))for ref in all_references if ref.path is not _A];return locations if locations else _A
			except Exception as e:ls.show_message(f"Error getting locations: {e}",types.MessageType.Error);return
		@self.server.feature(types.TEXT_DOCUMENT_PREPARE_RENAME)
		def prepare_rename_handler(ls:LanguageServer,params:types.PrepareRenameParams)->t.Optional[types.PrepareRenameResult]:
			try:uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);result=prepare_rename(context,uri,params.position);return result
			except Exception as e:ls.log_trace(f"Error preparing rename: {e}");return
		@self.server.feature(types.TEXT_DOCUMENT_RENAME)
		def rename_handler(ls:LanguageServer,params:types.RenameParams)->t.Optional[types.WorkspaceEdit]:
			try:uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);workspace_edit=rename_symbol(context,uri,params.position,params.new_name);return workspace_edit
			except Exception as e:ls.show_message(f"Error performing rename: {e}",types.MessageType.Error);return
		@self.server.feature(types.TEXT_DOCUMENT_DOCUMENT_HIGHLIGHT)
		def document_highlight_handler(ls:LanguageServer,params:types.DocumentHighlightParams)->t.Optional[t.List[types.DocumentHighlight]]:
			try:uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);highlights=get_document_highlights(context,uri,params.position);return highlights
			except Exception as e:ls.log_trace(f"Error getting document highlights: {e}");return
		@self.server.feature(types.TEXT_DOCUMENT_DIAGNOSTIC)
		def diagnostic(ls:LanguageServer,params:types.DocumentDiagnosticParams)->types.DocumentDiagnosticReport:
			try:
				uri=URI(params.text_document.uri);diagnostics,result_id=self._get_diagnostics_for_uri(uri)
				if hasattr(params,'previous_result_id')and params.previous_result_id==result_id:return types.RelatedUnchangedDocumentDiagnosticReport(kind=types.DocumentDiagnosticReportKind.Unchanged,result_id=str(result_id))
				return types.RelatedFullDocumentDiagnosticReport(kind=types.DocumentDiagnosticReportKind.Full,items=diagnostics,result_id=str(result_id))
			except Exception as e:ls.log_trace(f"Error getting diagnostics: {e}");return types.RelatedFullDocumentDiagnosticReport(kind=types.DocumentDiagnosticReportKind.Full,items=[])
		@self.server.feature(types.WORKSPACE_DIAGNOSTIC)
		def workspace_diagnostic(ls:LanguageServer,params:types.WorkspaceDiagnosticParams)->types.WorkspaceDiagnosticReport:
			try:
				context=self._context_get_or_load();items:t.List[t.Union[types.WorkspaceFullDocumentDiagnosticReport,types.WorkspaceUnchangedDocumentDiagnosticReport]]=[]
				for(path,target)in context.map.items():
					if isinstance(target,ModelTarget):
						uri=URI.from_path(path);diagnostics,result_id=self._get_diagnostics_for_uri(uri);previous_result_id=_A
						if hasattr(params,'previous_result_ids')and params.previous_result_ids:
							for prev in params.previous_result_ids:
								if prev.uri==uri.value:previous_result_id=prev.value;break
						if previous_result_id and previous_result_id==result_id:items.append(types.WorkspaceUnchangedDocumentDiagnosticReport(kind=types.DocumentDiagnosticReportKind.Unchanged,result_id=str(result_id),uri=uri.value))
						else:items.append(types.WorkspaceFullDocumentDiagnosticReport(kind=types.DocumentDiagnosticReportKind.Full,result_id=str(result_id),uri=uri.value,items=diagnostics))
				return types.WorkspaceDiagnosticReport(items=items)
			except Exception as e:
				ls.log_trace(f"Error getting workspace diagnostics: {e}");error_diagnostic,error=context_error_to_diagnostic(e)
				if error_diagnostic:uri_value,unpacked_diagnostic=error_diagnostic;return types.WorkspaceDiagnosticReport(items=[types.WorkspaceFullDocumentDiagnosticReport(kind=types.DocumentDiagnosticReportKind.Full,result_id=self.context_state.version_id,uri=uri_value,items=[unpacked_diagnostic])])
				return types.WorkspaceDiagnosticReport(items=[])
		@self.server.feature(types.TEXT_DOCUMENT_CODE_ACTION)
		def code_action(ls:LanguageServer,params:types.CodeActionParams)->t.Optional[t.List[t.Union[types.Command,types.CodeAction]]]:
			try:ls.log_trace(f"Codeactionrequest: {params}");uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);code_actions=context.get_code_actions(uri,params);return code_actions
			except Exception as e:ls.log_trace(f"Error getting code actions: {e}");return
		@self.server.feature(types.TEXT_DOCUMENT_CODE_LENS)
		def code_lens(ls:LanguageServer,params:types.CodeLensParams)->t.List[types.CodeLens]:
			try:uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);code_lenses=context.get_code_lenses(uri);return code_lenses if code_lenses else[]
			except Exception as e:ls.log_trace(f"Error getting code lenses: {e}");return[]
		@self.server.feature(types.TEXT_DOCUMENT_COMPLETION,types.CompletionOptions(trigger_characters=['@']))
		def completion(ls:LanguageServer,params:types.CompletionParams)->t.Optional[types.CompletionList]:
			try:
				uri=URI(params.text_document.uri);context=self._context_get_or_load(uri);content=_A
				try:document=ls.workspace.get_text_document(params.text_document.uri);content=document.source
				except Exception:pass
				completion_response=LSPContext.get_completions(context,uri,content);completion_items=[]
				for model in completion_response.model_completions:completion_items.append(types.CompletionItem(label=model.name,kind=types.CompletionItemKind.Reference,detail='Vulcan Model',documentation=types.MarkupContent(kind=types.MarkupKind.Markdown,value=model.description or'No description available')if model.description else _A))
				triggered_by_at=params.context is not _A and getattr(params.context,'trigger_character',_A)=='@'
				for macro in completion_response.macros:macro_name=macro.name;insert_text=macro_name if triggered_by_at else f"@{macro_name}";completion_items.append(types.CompletionItem(label=f"@{macro_name}",insert_text=insert_text,insert_text_format=types.InsertTextFormat.PlainText,filter_text=macro_name,kind=types.CompletionItemKind.Function,detail='Vulcan Macro',documentation=macro.description))
				for keyword in completion_response.keywords:completion_items.append(types.CompletionItem(label=keyword,kind=types.CompletionItemKind.Keyword,detail='SQL Keyword'))
				return types.CompletionList(is_incomplete=_B,items=completion_items)
			except Exception as e:get_sql_completions(_A,URI(params.text_document.uri));return
	def _get_diagnostics_for_uri(self,uri:URI)->t.Tuple[t.List[types.Diagnostic],str]:
		try:context=self._context_get_or_load(uri);diagnostics=context.lint_model(uri);return LSPContext.diagnostics_to_lsp_diagnostics(diagnostics),self.context_state.version_id
		except ConfigError as config_error:
			diagnostic,error=context_error_to_diagnostic(config_error,uri_filter=uri)
			if diagnostic:
				location,diag=diagnostic
				if location==uri.value:return[diag],self.context_state.version_id
			return[],self.context_state.version_id
	def _context_get_or_load(self,document_uri:t.Optional[URI]=_A)->LSPContext:
		state=self.context_state
		if isinstance(state,ContextFailed):
			if isinstance(state.error,str):raise Exception(state.error)
			raise state.error
		if isinstance(state,NoContext):
			if self.specified_paths is not _A:
				if self._create_lsp_context(self.specified_paths):loaded_vulcan_message(self.server)
			else:self._ensure_context_for_document(document_uri)
		if isinstance(state,ContextLoaded):return state.lsp_context
		raise RuntimeError('Context failed to load')
	def _ensure_context_for_document(self,document_uri:t.Optional[URI]=_A)->_A:
		if document_uri is not _A:
			document_path=document_uri.to_path()
			if document_path.is_file()and document_path.suffix in('.sql','.py'):
				document_folder=document_path.parent
				if document_folder.is_dir():self._ensure_context_in_folder(document_folder);return
		self._ensure_context_in_folder()
	def _ensure_context_in_folder(self,folder_path:t.Optional[Path]=_A)->_A:
		if not isinstance(self.context_state,NoContext):return
		for workspace_folder in self.workspace_folders:
			for ext in('py',_C,_D):
				config_path=workspace_folder/f"config.{ext}"
				if config_path.exists():
					if self._create_lsp_context([workspace_folder]):loaded_vulcan_message(self.server);return
		path=folder_path
		if path is _A:path=Path.cwd()
		while path.is_dir():
			for ext in('py',_C,_D):
				config_path=path/f"config.{ext}"
				if config_path.exists():
					if self._create_lsp_context([path]):loaded_vulcan_message(self.server);return
			path=path.parent
			if path==path.parent:break
		raise RuntimeError(f"No context found in workspaces folders {self.workspace_folders}"+(f" or in {folder_path}"if folder_path else''))
	def _create_lsp_context(self,paths:t.List[Path])->t.Optional[LSPContext]:
		try:
			if isinstance(self.context_state,NoContext):context=self.context_class(paths=paths)
			elif isinstance(self.context_state,ContextFailed):
				if self.context_state.context:context=self.context_state.context;context.load()
				else:context=self.context_class(paths=paths)
			else:context=self.context_state.lsp_context.context;context.load()
			self.context_state=ContextLoaded(lsp_context=LSPContext(context));return self.context_state.lsp_context
		except Exception as e:
			if not self.has_raised_loading_error:self.server.show_message(f"Error creating context: {e}",types.MessageType.Error);self.has_raised_loading_error=True
			self.server.log_trace(f"Error creating context: {e}");context=_A
			if isinstance(self.context_state,ContextLoaded):context=self.context_state.lsp_context.context
			elif isinstance(self.context_state,ContextFailed)and self.context_state.context:context=self.context_state.context
			self.context_state=ContextFailed(error=e,context=context);return
	@staticmethod
	def _uri_to_path(uri:str)->Path:return URI(uri).to_path()
	def start(self)->_A:logging.basicConfig(level=logging.DEBUG);self.server.start_io()
def loaded_vulcan_message(ls:LanguageServer)->_A:ls.show_message(f"Loaded Vulcan Context",types.MessageType.Info)
def main()->_A:vulcan_server=VulcanLanguageServer(context_class=Context);vulcan_server.start()
if __name__=='__main__':main()