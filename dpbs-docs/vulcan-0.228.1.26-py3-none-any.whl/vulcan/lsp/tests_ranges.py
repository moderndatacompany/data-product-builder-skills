from pathlib import Path
from vulcan.core.linter.rule import Range,Position
from ruamel import yaml
from ruamel.yaml.comments import CommentedMap
import typing as t
def get_test_ranges(path:Path)->t.Dict[str,Range]:
	test_ranges:t.Dict[str,Range]={}
	with open(path,'r',encoding='utf-8')as file:content=file.read()
	yaml_obj=yaml.YAML();yaml_obj.preserve_quotes=True;data=yaml_obj.load(content)
	if not isinstance(data,dict):raise ValueError('Invalid test file format: expected a dictionary at the top level.')
	for test_name in data:
		if isinstance(data,CommentedMap)and test_name in data.lc.data:
			line_info=data.lc.data[test_name];start_line=line_info[0];start_col=line_info[1];lines=content.splitlines();end_line=start_line
			for i in range(start_line+1,len(lines)):
				line=lines[i]
				if line and not line[0].isspace()and':'in line:end_line=i-1;break
			else:end_line=len(lines)-1
			test_ranges[test_name]=Range(start=Position(line=start_line,character=start_col),end=Position(line=end_line,character=len(lines[end_line])if end_line<len(lines)else 0))
	return test_ranges