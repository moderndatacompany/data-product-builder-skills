_A=None
from lsprotocol.types import Diagnostic,DiagnosticSeverity,Range,Position
from vulcan.lsp.uri import URI
from vulcan.utils.errors import ConfigError
import typing as t
ContextFailedError=t.Union[str,ConfigError,Exception]
def context_error_to_diagnostic(error:t.Union[Exception,ContextFailedError],uri_filter:t.Optional[URI]=_A)->t.Tuple[t.Optional[t.Tuple[str,Diagnostic]],ContextFailedError]:
	if isinstance(error,ConfigError):return config_error_to_diagnostic(error),error
	return _A,str(error)
def config_error_to_diagnostic(error:ConfigError,uri_filter:t.Optional[URI]=_A)->t.Optional[t.Tuple[str,Diagnostic]]:
	if error.location is _A:return
	uri=URI.from_path(error.location).value
	if uri_filter and uri!=uri_filter.value:return
	return uri,Diagnostic(range=Range(start=Position(line=0,character=0),end=Position(line=0,character=0)),message=str(error),severity=DiagnosticSeverity.Error,source='Vulcan')