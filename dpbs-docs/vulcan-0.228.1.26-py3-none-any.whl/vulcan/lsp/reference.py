_A=None
import typing as t
from pathlib import Path
from vulcan.core.audit import StandaloneAudit
from vulcan.core.linter.helpers import TokenPositionDetails
from vulcan.core.linter.rule import Range,Position
from vulcan.core.model.definition import SqlModel
from vulcan.lsp.context import LSPContext,ModelTarget,AuditTarget
from sqlglot import exp
from vulcan.lsp.uri import URI
from vulcan.utils.lineage import MacroReference,CTEReference,Reference,ModelReference,extract_references_from_query
import ast
from vulcan.core.model import Model
from vulcan import macro
import inspect
def by_position(position:Position)->t.Callable[[Reference],bool]:
	'\n    Filter reference to only filter references that contain the given position.\n\n    Args:\n        position: The cursor position to check\n\n    Returns:\n        A function that returns True if the reference contains the position, False otherwise\n    '
	def contains_position(r:Reference)->bool:return _position_within_range(position,r.range)
	return contains_position
def get_references(lint_context:LSPContext,document_uri:URI,position:Position)->t.List[Reference]:'\n    Get references at a specific position in a document.\n\n    Used for hover information.\n\n    Args:\n        lint_context: The LSP context\n        document_uri: The URI of the document\n        position: The position to check for references\n\n    Returns:\n        A list of references at the given position\n    ';references=get_model_definitions_for_a_path(lint_context,document_uri);macro_references=get_macro_definitions_for_a_path(lint_context,document_uri);references.extend(macro_references);filtered_references=list(filter(by_position(position),references));return filtered_references
def get_model_definitions_for_a_path(lint_context:LSPContext,document_uri:URI)->t.List[Reference]:
	'\n    Get the model references for a given path.\n\n    Works for models and standalone audits.\n    Works for targeting sql and python models.\n\n    Steps:\n    - Get the parsed query\n    - Find all table objects using find_all exp.Table\n        - Match the string against all model names\n    - Need to normalize it before matching\n    - Try get_model before normalization\n    - Match to models that the model refers to\n    - Also find CTE references within the query\n    ';path=document_uri.to_path()
	if path.suffix!='.sql':return[]
	if path not in lint_context.map:return[]
	file_info=lint_context.map[path]
	if isinstance(file_info,ModelTarget):
		model=lint_context.context.get_model(model_or_snapshot=file_info.names[0],raise_if_missing=False)
		if model is _A or not isinstance(model,SqlModel):return[]
		query=model.query;dialect=model.dialect;depends_on=model.depends_on;file_path=model._path
	elif isinstance(file_info,AuditTarget):
		audit=lint_context.context.standalone_audits.get(file_info.name)
		if audit is _A:return[]
		query=audit.query;dialect=audit.dialect;depends_on=audit.depends_on;file_path=audit._path
	else:return[]
	if file_path is _A:return[]
	with open(file_path,'r',encoding='utf-8')as file:read_file=file.readlines()
	return extract_references_from_query(query=query,context=lint_context.context,document_path=document_uri.to_path(),read_file=read_file,depends_on=depends_on,dialect=dialect)
def get_macro_definitions_for_a_path(lsp_context:LSPContext,document_uri:URI)->t.List[Reference]:
	'\n    Get macro references for a given path.\n\n    This function finds all macro invocations (e.g., @ADD_ONE, @MULTIPLY) in a SQL file\n    and creates references to their definitions in the Python macro files.\n\n    Args:\n        lsp_context: The LSP context containing macro definitions\n        document_uri: The URI of the document to search for macro invocations\n\n    Returns:\n        A list of Reference objects for each macro invocation found\n    ';path=document_uri.to_path()
	if path.suffix!='.sql':return[]
	if path not in lsp_context.map:return[]
	file_info=lsp_context.map[path]
	if isinstance(file_info,ModelTarget):
		target:t.Optional[t.Union[Model,StandaloneAudit]]=lsp_context.context.get_model(model_or_snapshot=file_info.names[0],raise_if_missing=False)
		if target is _A or not isinstance(target,SqlModel):return[]
		query=target.query;file_path=target._path
	elif isinstance(file_info,AuditTarget):
		target=lsp_context.context.standalone_audits.get(file_info.name)
		if target is _A:return[]
		query=target.query;file_path=target._path
	else:return[]
	if file_path is _A:return[]
	references=[];_,config_path=lsp_context.context.config_for_path(file_path)
	with open(file_path,'r',encoding='utf-8')as file:read_file=file.readlines()
	for node in query.find_all(exp.Anonymous):
		macro_name=node.name.lower();reference=get_macro_reference(node=node,target=target,read_file=read_file,config_path=config_path,macro_name=macro_name)
		if reference is not _A:references.append(reference)
	return references
def get_macro_reference(target:t.Union[Model,StandaloneAudit],read_file:t.List[str],config_path:t.Optional[Path],node:exp.Expression,macro_name:str)->t.Optional[Reference]:
	try:
		if hasattr(node,'meta')and node.meta:
			macro_range=TokenPositionDetails.from_meta(node.meta).to_range(read_file)
			if(builtin:=get_built_in_macro_reference(macro_name,macro_range)):return builtin
		else:return
		macro_def=target.python_env.get(macro_name)
		if macro_def is _A:return
		function_name=macro_def.name
		if not function_name:return
		if not macro_def.path:return
		if not config_path:return
		path=Path(config_path).joinpath(macro_def.path)
		with open(path,'r')as f:tree=ast.parse(f.read())
		with open(path,'r')as f:output_read_line=f.readlines()
		start_line=_A;end_line=_A;get_length_of_end_line=_A;docstring=_A
		for ast_node in ast.walk(tree):
			if isinstance(ast_node,ast.FunctionDef)and ast_node.name==function_name:start_line=ast_node.lineno;end_line=ast_node.end_lineno;get_length_of_end_line=len(output_read_line[end_line-1])if end_line is not _A and end_line-1<len(read_file)else 0;docstring=ast.get_docstring(ast_node);break
		if start_line is _A or end_line is _A or get_length_of_end_line is _A:return
		return MacroReference(path=path,range=macro_range,target_range=Range(start=Position(line=start_line-1,character=0),end=Position(line=end_line-1,character=get_length_of_end_line)),markdown_description=docstring)
	except Exception:return
def get_built_in_macro_reference(macro_name:str,macro_range:Range)->t.Optional[Reference]:
	"\n    Get a reference to a built-in macro by its name.\n\n    Args:\n        macro_name: The name of the built-in macro (e.g., 'each', 'sql_literal')\n        macro_range: The range of the macro invocation in the source file\n    ";built_in_macros=macro.get_registry();built_in_macro=built_in_macros.get(macro_name)
	if built_in_macro is _A:return
	func=built_in_macro.func;filename=inspect.getfile(func);source_lines,line_number=inspect.getsourcelines(func);end_line_number=line_number+len(source_lines)-1;return MacroReference(path=Path(filename),range=macro_range,target_range=Range(start=Position(line=line_number-1,character=0),end=Position(line=end_line_number-1,character=0)),markdown_description=func.__doc__ if func.__doc__ else _A)
def get_model_find_all_references(lint_context:LSPContext,document_uri:URI,position:Position)->t.List[ModelReference]:
	'\n    Get all references to a model across the entire project.\n\n    This function finds all usages of a model in other files by searching through\n    all models in the project and checking their dependencies.\n\n    Args:\n        lint_context: The LSP context\n        document_uri: The URI of the document\n        position: The position to check for model references\n\n    Returns:\n        A list of references to the model across all files\n    ';model_at_position=next(filter(lambda ref:isinstance(ref,ModelReference)and _position_within_range(position,ref.range),get_model_definitions_for_a_path(lint_context,document_uri)),_A)
	if not model_at_position:return[]
	assert isinstance(model_at_position,ModelReference);target_model_path=model_at_position.path;all_references:t.List[ModelReference]=[ModelReference(path=model_at_position.path,range=Range(start=Position(line=0,character=0),end=Position(line=0,character=0)),markdown_description=model_at_position.markdown_description)];current_file_refs=filter(lambda ref:isinstance(ref,ModelReference)and ref.path==target_model_path,get_model_definitions_for_a_path(lint_context,document_uri))
	for ref in current_file_refs:assert isinstance(ref,ModelReference);all_references.append(ModelReference(path=document_uri.to_path(),range=ref.range,markdown_description=ref.markdown_description))
	for(path,_)in lint_context.map.items():
		file_uri=URI.from_path(path)
		if file_uri.value==document_uri.value:continue
		matching_refs=filter(lambda ref:isinstance(ref,ModelReference)and ref.path==target_model_path,get_model_definitions_for_a_path(lint_context,file_uri))
		for ref in matching_refs:assert isinstance(ref,ModelReference);all_references.append(ModelReference(path=path,range=ref.range,markdown_description=ref.markdown_description))
	return all_references
def get_cte_references(lint_context:LSPContext,document_uri:URI,position:Position)->t.List[CTEReference]:
	'\n    Get all references to a CTE at a specific position in a document.\n\n    This function finds both the definition and all usages of a CTE within the same file.\n\n    Args:\n        lint_context: The LSP context\n        document_uri: The URI of the document\n        position: The position to check for CTE references\n\n    Returns:\n        A list of references to the CTE (including its definition and all usages)\n    ';cte_references:t.List[CTEReference]=[ref for ref in get_model_definitions_for_a_path(lint_context,document_uri)if isinstance(ref,CTEReference)]
	if not cte_references:return[]
	target_cte_definition_range=_A
	for ref in cte_references:
		if _position_within_range(position,ref.range):target_cte_definition_range=ref.target_range;break
		elif _position_within_range(position,ref.target_range):target_cte_definition_range=ref.target_range;break
	if target_cte_definition_range is _A:return[]
	matching_references=[CTEReference(path=document_uri.to_path(),range=target_cte_definition_range,target_range=target_cte_definition_range)]
	for ref in cte_references:
		if ref.target_range==target_cte_definition_range:matching_references.append(CTEReference(path=document_uri.to_path(),range=ref.range,target_range=ref.target_range))
	return matching_references
def get_macro_find_all_references(lsp_context:LSPContext,document_uri:URI,position:Position)->t.List[MacroReference]:
	'\n    Get all references to a macro at a specific position in a document.\n\n    This function finds all usages of a macro across the entire project.\n\n    Args:\n        lsp_context: The LSP context\n        document_uri: The URI of the document\n        position: The position to check for macro references\n\n    Returns:\n        A list of references to the macro across all files\n    ';macro_at_position=next(filter(lambda ref:isinstance(ref,MacroReference)and _position_within_range(position,ref.range),get_macro_definitions_for_a_path(lsp_context,document_uri)),_A)
	if not macro_at_position:return[]
	assert isinstance(macro_at_position,MacroReference);target_macro_path=macro_at_position.path;target_macro_target_range=macro_at_position.target_range;all_references:t.List[MacroReference]=[MacroReference(path=target_macro_path,range=target_macro_target_range,target_range=target_macro_target_range,markdown_description=_A)]
	for(path,_)in lsp_context.map.items():
		file_uri=URI.from_path(path);matching_refs=filter(lambda ref:isinstance(ref,MacroReference)and ref.path==target_macro_path and ref.target_range==target_macro_target_range,get_macro_definitions_for_a_path(lsp_context,file_uri))
		for ref in matching_refs:assert isinstance(ref,MacroReference);all_references.append(MacroReference(path=path,range=ref.range,target_range=ref.target_range,markdown_description=ref.markdown_description))
	return all_references
def get_all_references(lint_context:LSPContext,document_uri:URI,position:Position)->t.Sequence[Reference]:
	'\n    Get all references of a symbol at a specific position in a document.\n\n    This function determines the type of reference (CTE, model or macro) at the cursor\n    position and returns all references to that symbol across the project.\n\n    Args:\n        lint_context: The LSP context\n        document_uri: The URI of the document\n        position: The position to check for references\n\n    Returns:\n        A list of references to the symbol at the given position\n    '
	if(cte_references:=get_cte_references(lint_context,document_uri,position)):return cte_references
	if(model_references:=get_model_find_all_references(lint_context,document_uri,position)):return model_references
	if(macro_references:=get_macro_find_all_references(lint_context,document_uri,position)):return macro_references
	return[]
def _position_within_range(position:Position,range:Range)->bool:'Check if a position is within a given range.';return(range.start.line<position.line or range.start.line==position.line and range.start.character<=position.character)and(range.end.line>position.line or range.end.line==position.line and range.end.character>=position.character)