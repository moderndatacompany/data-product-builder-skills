_A=None
from lsprotocol import types
import typing as t
from vulcan.core.linter.rule import Range
from vulcan.utils.pydantic import PydanticModel
class CustomMethodRequestBaseClass(PydanticModel):0
class CustomMethodResponseBaseClass(PydanticModel):response_error:t.Optional[str]=_A
ALL_MODELS_FEATURE='vulcan/all_models'
class AllModelsRequest(CustomMethodRequestBaseClass):textDocument:types.TextDocumentIdentifier
class MacroCompletion(PydanticModel):name:str;description:t.Optional[str]=_A
class ModelCompletion(PydanticModel):name:str;description:t.Optional[str]=_A
class AllModelsResponse(CustomMethodResponseBaseClass):models:t.List[str];model_completions:t.List[ModelCompletion];keywords:t.List[str];macros:t.List[MacroCompletion]
RENDER_MODEL_FEATURE='vulcan/render_model'
class RenderModelRequest(CustomMethodRequestBaseClass):textDocumentUri:str
class RenderModelEntry(PydanticModel):name:str;fqn:str;description:t.Optional[str]=_A;rendered_query:str
class RenderModelResponse(CustomMethodResponseBaseClass):models:t.List[RenderModelEntry]
ALL_MODELS_FOR_RENDER_FEATURE='vulcan/all_models_for_render'
class ModelForRendering(PydanticModel):name:str;fqn:str;description:t.Optional[str]=_A;uri:str
class AllModelsForRenderRequest(CustomMethodRequestBaseClass):0
class AllModelsForRenderResponse(CustomMethodResponseBaseClass):models:t.List[ModelForRendering]
SUPPORTED_METHODS_FEATURE='vulcan/supported_methods'
class SupportedMethodsRequest(PydanticModel):0
class CustomMethod(PydanticModel):name:str
class SupportedMethodsResponse(CustomMethodResponseBaseClass):methods:t.List[CustomMethod]
FORMAT_PROJECT_FEATURE='vulcan/format_project'
class FormatProjectRequest(CustomMethodRequestBaseClass):0
class FormatProjectResponse(CustomMethodResponseBaseClass):0
LIST_WORKSPACE_TESTS_FEATURE='vulcan/list_workspace_tests'
class ListWorkspaceTestsRequest(CustomMethodRequestBaseClass):0
GET_ENVIRONMENTS_FEATURE='vulcan/get_environments'
class GetEnvironmentsRequest(CustomMethodRequestBaseClass):0
class TestEntry(PydanticModel):name:str;uri:str;range:Range
class ListWorkspaceTestsResponse(CustomMethodResponseBaseClass):tests:t.List[TestEntry]
LIST_DOCUMENT_TESTS_FEATURE='vulcan/list_document_tests'
class ListDocumentTestsRequest(CustomMethodRequestBaseClass):textDocument:types.TextDocumentIdentifier
class ListDocumentTestsResponse(CustomMethodResponseBaseClass):tests:t.List[TestEntry]
RUN_TEST_FEATURE='vulcan/run_test'
class RunTestRequest(CustomMethodRequestBaseClass):textDocument:types.TextDocumentIdentifier;testName:str
class RunTestResponse(CustomMethodResponseBaseClass):success:bool;error_message:t.Optional[str]=_A
class EnvironmentInfo(PydanticModel):name:str;snapshots:t.List[str];start_at:str;plan_id:str
class GetEnvironmentsResponse(CustomMethodResponseBaseClass):environments:t.Dict[str,EnvironmentInfo];pinned_environments:t.Set[str];default_target_environment:str
GET_MODELS_FEATURE='vulcan/get_models'
class GetModelsRequest(CustomMethodRequestBaseClass):0
class ModelInfo(PydanticModel):name:str;fqn:str;description:t.Optional[str]=_A
class GetModelsResponse(CustomMethodResponseBaseClass):models:t.List[ModelInfo]