_A=None
import typing as t
from pydantic import field_validator
from vulcan.lsp.custom import CustomMethodRequestBaseClass,CustomMethodResponseBaseClass
from web.server.models import LineageColumn,Model,TableDiff
API_FEATURE='vulcan/api'
class ApiRequest(CustomMethodRequestBaseClass):requestId:str;url:str;method:t.Optional[str]='GET';params:t.Optional[t.Dict[str,t.Any]]=_A;body:t.Optional[t.Dict[str,t.Any]]=_A
class BaseAPIResponse(CustomMethodResponseBaseClass):error:t.Optional[str]=_A
class ApiResponseGetModels(BaseAPIResponse):
	data:t.List[Model]
	@field_validator('data',mode='before')
	def sanitize_datetime_fields(cls,data:t.List[Model])->t.List[Model]:
		if isinstance(data,list):
			for model in data:
				if hasattr(model,'details')and model.details:
					for field in['stamp','start','cron_prev','cron_next']:
						if hasattr(model.details,field)and getattr(model.details,field)is not _A:setattr(model.details,field,_A)
		return data
class ApiResponseGetLineage(BaseAPIResponse):data:t.Dict[str,t.List[str]]
class ApiResponseGetColumnLineage(BaseAPIResponse):data:t.Dict[str,t.Dict[str,LineageColumn]]
class ApiResponseGetTableDiff(BaseAPIResponse):data:t.Optional[TableDiff]