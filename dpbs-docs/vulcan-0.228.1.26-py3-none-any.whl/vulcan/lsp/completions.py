_A=None
from functools import lru_cache
from sqlglot import Dialect,Tokenizer
from vulcan.lsp.custom import AllModelsResponse,MacroCompletion,ModelCompletion
from vulcan import macro
import typing as t
from vulcan.lsp.context import AuditTarget,LSPContext,ModelTarget
from vulcan.lsp.uri import URI
from vulcan.utils.lineage import generate_markdown_description
def get_sql_completions(context:t.Optional[LSPContext]=_A,file_uri:t.Optional[URI]=_A,content:t.Optional[str]=_A)->AllModelsResponse:
	sql_keywords=get_keywords(context,file_uri);file_keywords=set()
	if content:file_keywords=extract_keywords_from_content(content,get_dialect(context,file_uri))
	all_keywords=list(sql_keywords)+list(file_keywords-sql_keywords);models=list(get_models(context,file_uri));return AllModelsResponse(models=[m.name for m in models],model_completions=models,keywords=all_keywords,macros=list(get_macros(context,file_uri)))
def get_models(context:t.Optional[LSPContext],file_uri:t.Optional[URI])->t.List[ModelCompletion]:
	if context is _A:return[]
	current_path=file_uri.to_path()if file_uri is not _A else _A;completions:t.List[ModelCompletion]=[]
	for model in context.context.models.values():
		if current_path is not _A and model._path==current_path:continue
		description=_A
		try:description=generate_markdown_description(model)
		except Exception:description=getattr(model,'description',_A)
		completions.append(ModelCompletion(name=model.name,description=description))
	return completions
def get_macros(context:t.Optional[LSPContext],file_uri:t.Optional[URI])->t.List[MacroCompletion]:
	A='__doc__';macros:t.Dict[str,t.Optional[str]]={}
	for(name,m)in macro.get_registry().items():macros[name]=getattr(m.func,A,_A)
	try:
		if context is not _A:
			for(name,m)in context.context._macros.items():macros[name]=getattr(m.func,A,_A)
	except Exception:pass
	return[MacroCompletion(name=name,description=doc)for(name,doc)in macros.items()]
def get_keywords(context:t.Optional[LSPContext],file_uri:t.Optional[URI])->t.Set[str]:
	if file_uri is not _A and context is not _A and file_uri.to_path()in context.map:
		file_info=context.map[file_uri.to_path()]
		if isinstance(file_info,ModelTarget)and file_info.names:
			model_name=file_info.names[0];model_from_context=context.context.get_model(model_name)
			if model_from_context is not _A and model_from_context.dialect:return get_keywords_from_tokenizer(model_from_context.dialect)
		elif isinstance(file_info,AuditTarget)and file_info.name:
			audit=context.context.standalone_audits.get(file_info.name)
			if audit is not _A and audit.dialect:return get_keywords_from_tokenizer(audit.dialect)
	if context is not _A:return get_keywords_from_tokenizer(context.context.default_dialect)
	return get_keywords_from_tokenizer(_A)
@lru_cache()
def get_keywords_from_tokenizer(dialect:t.Optional[str]=_A)->t.Set[str]:
	tokenizer=Tokenizer
	if dialect is not _A:
		try:tokenizer=Dialect.get_or_raise(dialect).tokenizer_class
		except Exception:pass
	expanded_keywords=set()
	for keyword in tokenizer.KEYWORDS.keys():parts=keyword.split(' ');expanded_keywords.update(parts)
	return expanded_keywords
def get_dialect(context:t.Optional[LSPContext],file_uri:t.Optional[URI])->t.Optional[str]:
	if file_uri is not _A and context is not _A and file_uri.to_path()in context.map:
		file_info=context.map[file_uri.to_path()]
		if isinstance(file_info,ModelTarget)and file_info.names:model_name=file_info.names[0];model_from_context=context.context.get_model(model_name);return model_from_context.dialect
		if isinstance(file_info,AuditTarget)and file_info.name:
			audit=context.context.standalone_audits.get(file_info.name)
			if audit is not _A and audit.dialect:return audit.dialect
	if context is not _A:return context.context.default_dialect
def extract_keywords_from_content(content:str,dialect:t.Optional[str]=_A)->t.Set[str]:
	if not content:return set()
	tokenizer_class=Dialect.get_or_raise(dialect).tokenizer_class;keywords=set()
	try:
		tokenizer=tokenizer_class();tokens=tokenizer.tokenize(content)
		for token in tokens:
			if token.text.upper()not in tokenizer_class.KEYWORDS:keywords.add(token.text)
	except Exception:pass
	return keywords