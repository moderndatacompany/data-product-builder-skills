from __future__ import annotations
_M='db_type'
_L='tenant_id'
_K='athena'
_J='redshift'
_I='postgres'
_H='bigquery'
_G='snowflake'
_F='duckdb'
_E='schema'
_D='sql'
_C='mssql'
_B=True
_A=None
import logging,typing as t
from urllib.parse import urljoin
import httpx,pydantic
from pydantic import Field
from schema.auth import SecurityContext
from schema.rest_query import RestQuery
from vulcan.core.config import Config
from vulcan.core.dialect import wrap_query_with_alias_mapping
from vulcan.utils.errors import VulcanError,TranspilerError
from vulcan.utils.pydantic import PydanticModel
if t.TYPE_CHECKING:from vulcan.core.context import Context
logger=logging.getLogger(__name__)
SEMANTIC_DIALECT_MAPPING:t.Dict[str,str]={_F:_F,_G:_G,'databricks':'databricks-jdbc',_H:_H,_I:_I,_J:_J,'mysql':'mysql','spark':'spark','trino':'trino',_K:_K,'fabric':_C,_C:_C,'tsql':_C}
def get_transpiler_params_from_snapshots(context:'Context',environment:t.Optional[str]=_A)->t.Dict[str,t.Any]:
	schema=context.cube_schema_for_environment(environment).model_dump(mode='json',exclude_none=_B);cfg=context.config;tenant_id=(cfg.tenant or'').strip()
	if not tenant_id:raise VulcanError('config.tenant is unset; set DATAOS_TENANT_ID or YAML `tenant` before calling the transpiler.')
	name=(cfg.name or'').strip()
	if not name:raise VulcanError('config.name is unset; configure the project name in YAML before calling the transpiler.')
	connection=cfg.get_connection();dialect=getattr(connection,'DIALECT',_A)or getattr(connection,'type_',_A)
	if not dialect:raise VulcanError('Connection has no DIALECT; cannot determine db_type for transpiler. Ensure a gateway connection is configured.')
	db_type=SEMANTIC_DIALECT_MAPPING.get(dialect,dialect);return{_E:schema,_L:tenant_id,'name':name,_M:db_type}
class TranspilerReply(PydanticModel):
	model_config=pydantic.ConfigDict(extra='ignore');sql:t.Dict[str,t.Any]=Field(...,description='SQL generation result containing sql array, aliases, order, etc.');_wrapped_sql:t.Optional[str]=_A
	@property
	def sql_statement(self)->str:
		sql_data=self.sql.get(_D,[])
		if isinstance(sql_data,list)and len(sql_data)>0:return sql_data[0]
		return str(sql_data)
	@property
	def wrapped_sql_statement(self)->str:
		if self._wrapped_sql is not _A:return self._wrapped_sql
		return self.sql_statement
	@property
	def sql_params(self)->t.Optional[t.List[t.Any]]:
		sql_data=self.sql.get(_D,[])
		if isinstance(sql_data,list)and len(sql_data)>1:params=sql_data[1];return params if params else _A
	@property
	def alias_mapping(self)->t.Dict[str,str]:return self.sql.get('aliasNameToMember',{})
	@property
	def order(self)->t.List[t.Any]:return self.sql.get('order',[])
class TranspilerClient:
	def __init__(self,url:str,timeout:int=30,headers:t.Optional[t.Dict[str,str]]=_A)->_A:self.url=url;self.timeout=timeout;self.default_headers=headers or{};(self._client):t.Optional[httpx.AsyncClient]=_A
	async def __aenter__(self)->'TranspilerClient':self._client=httpx.AsyncClient(timeout=self.timeout,headers=self.default_headers);return self
	async def __aexit__(self,exc_type,exc_val,exc_tb)->_A:
		if self._client:await self._client.aclose()
	async def transpile(self,query:RestQuery|str,*,disable_post_processing:bool=_B,user:str,security_context:SecurityContext|_A=_A,headers:t.Optional[t.Dict[str,str]]=_A,dialect:t.Optional[str]=_A,schema:t.Optional[t.Dict[str,t.Any]]=_A,tenant_id:t.Optional[str]=_A,request_id:t.Optional[str]=_A,db_type:t.Optional[str]=_A,name:t.Optional[str]=_A)->TranspilerReply:
		E='query_type';D='status_code';C='message';B='error';A='format'
		if not self._client:raise RuntimeError('TranspilerClient must be used as async context manager')
		if isinstance(query,RestQuery):format_value='rest';query_value:t.Any=query.model_dump(exclude_none=_B,by_alias=_B)
		else:format_value=_D;query_value=query
		request_headers:t.Dict[str,str]={**self.default_headers,**(headers or{})};central_params={_E:schema,_L:tenant_id,'request_id':request_id,_M:db_type,'name':name};missing=[k for(k,v)in central_params.items()if v is _A or isinstance(v,str)and not v.strip()]
		if missing:raise ValueError(f"Central transpiler requires all of: schema, tenant_id, request_id, db_type, name. Missing: {', '.join(missing)}")
		payload={'query':query_value,A:format_value,'disable_post_processing':disable_post_processing,_E:schema};request_headers['X-Request-Id']=request_id;request_headers['X-Tenant-Id']=tenant_id;request_headers['X-DB-Type']=db_type;request_headers['X-User']=user;request_headers['X-Vulcan-Id']=name;request_headers.update((security_context or SecurityContext()).to_headers());logger.info('Transpiler request start url=%s format=%s disable_post_processing=%s',self.url,format_value,disable_post_processing)
		try:
			response=await self._client.post(self.url,json=payload,headers=request_headers);logger.info('Transpiler response status=%s format=%s',response.status_code,format_value)
			if response.status_code!=200:
				try:data=response.json()if response.content else{}
				except Exception:data={}
				err=data.get(B)
				if isinstance(err,dict)and'code'in err and C in err:message=err[C]
				else:message=data.get('detail',data.get(C,f"HTTP {response.status_code}"))
				logger.error('Transpiler non-200 response status=%s format=%s error=%s',response.status_code,format_value,message,extra={D:response.status_code,A:format_value});raise TranspilerError(message=message,code=response.status_code,response_data=data)
			try:data=response.json()
			except Exception as json_error:logger.error('Transpiler invalid JSON response format=%s error=%s',format_value,json_error);logger.debug('Transpiler raw response (first 500 chars): %s',response.text[:500]);raise TranspilerError(message=f"Invalid JSON response from Transpiler: {str(json_error)}",code=502)
			sql_data=data.get(_D,{})
			if isinstance(sql_data,dict)and sql_data.get('status')==B:error_message=sql_data.get(B,'Unknown error from Transpiler');query_type=sql_data.get(E,'unknown');logger.error('Transpiler error in response body status=%s format=%s error=%s query_type=%s',response.status_code,format_value,error_message,query_type,extra={D:response.status_code,A:format_value,E:query_type});raise TranspilerError(message=error_message,code=400,response_data=data,query_type=query_type)
			reply=TranspilerReply(**data)
			if dialect and reply.alias_mapping:
				try:wrapped_sql=wrap_query_with_alias_mapping(reply.sql_statement,reply.alias_mapping,dialect=dialect);reply._wrapped_sql=wrapped_sql;logger.debug('Wrapped SQL with alias mapping: dialect=%s, columns=%s',dialect,len(reply.alias_mapping))
				except Exception as wrap_error:logger.warning('Failed to wrap SQL with alias mapping: %s. Using original SQL.',wrap_error,exc_info=_B)
			logger.debug('Transpiler reply parsed format=%s sql_len=%s params_count=%s',format_value,len(reply.sql_statement),0 if reply.sql_params is _A else len(reply.sql_params));logger.debug('Transpiler raw SQL: %s',reply.sql_statement)
			if reply._wrapped_sql is not _A:logger.debug('Transpiler wrapped SQL: %s',reply._wrapped_sql)
			return reply
		except httpx.RequestError as e:logger.error('Transpiler connection error url=%s format=%s error=%s',self.url,format_value,e);raise TranspilerError(message=f"Failed to connect to Transpiler: {str(e)}",code=503,is_connection_error=_B)
		except TranspilerError:raise
		except Exception as e:logger.error('Unexpected error in Transpiler client url=%s format=%s error=%s',self.url,format_value,e);raise TranspilerError(message=f"Unexpected error: {str(e)}",code=500)
def make_transpiler_client(config:Config,token:t.Optional[str]=_A)->TranspilerClient:
	base=config.transpiler.base_url;base=base if base.endswith('/')else base+'/';transpiler_url=urljoin(base,'v1/sql');headers={};effective_token=token or config.transpiler.token
	if effective_token:headers['Authorization']=f"Bearer {effective_token}"
	return TranspilerClient(url=transpiler_url,timeout=config.transpiler.timeout,headers=headers if headers else _A)