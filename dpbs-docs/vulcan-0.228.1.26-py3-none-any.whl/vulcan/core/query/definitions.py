from __future__ import annotations
_A=None
import typing as t
from datetime import datetime,timezone
from enum import Enum
from pydantic import BaseModel,computed_field
class QueryStrategy(str,Enum):REUSE_RESULT='REUSE_RESULT';AWAIT_PRIMARY='AWAIT_PRIMARY';EXECUTE='EXECUTE'
class QueryType(str,Enum):SOURCE_SQL='SOURCE_SQL';SEMANTIC_SQL='SEMANTIC_SQL';SEMANTIC_REST='SEMANTIC_REST';SEMANTIC_GRAPHQL='SEMANTIC_GRAPHQL';SEMANTIC_METRIC='SEMANTIC_METRIC'
SEMANTIC_QUERY_TYPES:frozenset[QueryType]=frozenset({QueryType.SEMANTIC_REST,QueryType.SEMANTIC_SQL,QueryType.SEMANTIC_GRAPHQL,QueryType.SEMANTIC_METRIC})
class QueryStatus(str,Enum):ACCEPTED='ACCEPTED';QUEUED='QUEUED';IN_PROGRESS='IN_PROGRESS';SUCCESS='SUCCESS';FAILED='FAILED';CANCELLED='CANCELLED'
ACTIVE_STATUSES:frozenset[QueryStatus]=frozenset({QueryStatus.ACCEPTED,QueryStatus.QUEUED,QueryStatus.IN_PROGRESS})
TERMINAL_STATUSES:frozenset[QueryStatus]=frozenset({QueryStatus.SUCCESS,QueryStatus.FAILED,QueryStatus.CANCELLED})
class QueryResult(BaseModel):
	result_id:str;object_store_path:str;row_count:int;size_bytes:int;columns:t.List[t.Dict[str,str]];sql:t.Optional[str]=_A;references:t.Optional[t.Dict[str,t.List[t.List[str]]]]=_A;created_ts:int
	@computed_field
	@property
	def age_seconds(self)->int:now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return int((now_ts-self.created_ts)/1000)
	@computed_field
	@property
	def size_mb(self)->float:return round(self.size_bytes/1048576,2)
class QueryFingerprintResult(BaseModel):
	fingerprint:str;result_id:str;depends_on:t.Optional[t.List[str]]=_A;cached_at_ts:int;expires_ts:t.Optional[int]=_A;invalidated_by_run_id:t.Optional[str]=_A;invalidated_ts:t.Optional[int]=_A;object_store_path:str;row_count:int;size_bytes:int;columns:t.List[t.Dict[str,str]];result_created_ts:int
	@computed_field
	@property
	def is_expired(self)->bool:
		if self.expires_ts is _A:return False
		now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return now_ts>self.expires_ts
	@computed_field
	@property
	def cache_age_seconds(self)->int:now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return int((now_ts-self.cached_at_ts)/1000)
	@computed_field
	@property
	def result_age_seconds(self)->int:now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return int((now_ts-self.result_created_ts)/1000)
	@computed_field
	@property
	def ttl_seconds(self)->t.Optional[int]:
		if self.expires_ts is _A:return
		return int((self.expires_ts-self.cached_at_ts)/1000)
	@computed_field
	@property
	def size_mb(self)->float:return round(self.size_bytes/1048576,2)
	def to_result(self)->QueryResult:return QueryResult(result_id=self.result_id,object_store_path=self.object_store_path,row_count=self.row_count,size_bytes=self.size_bytes,columns=self.columns,created_ts=self.result_created_ts)
class QueryRequest(BaseModel):
	request_id:str;strategy:QueryStrategy;fingerprint:str;sql_query:str;normalized_sql:str;params:t.Optional[t.Union[t.Dict,t.List]]=_A;depends_on:t.Optional[t.List[str]]=_A;gateway:t.Optional[str]=_A;submitted_by:t.Optional[str]=_A;submitted_ts:int;ttl:int=0;meta:t.Optional[t.Dict]=_A;query_type:t.Optional[QueryType]=_A;semantic_query:t.Optional[str]=_A;rest_query:t.Optional[t.Dict]=_A;graphql_query:t.Optional[str]=_A;perspective_id:t.Optional[str]=_A;execution_status:t.Optional[QueryStatus]=_A;pgq_job_id:t.Optional[int]=_A;execution_start_ts:t.Optional[int]=_A;execution_end_ts:t.Optional[int]=_A;primary_request_id:t.Optional[str]=_A;cached_at_ts:t.Optional[int]=_A;result_id:t.Optional[str]=_A;error_message:t.Optional[str]=_A
	@computed_field
	@property
	def execution_duration_ms(self)->t.Optional[int]:
		if self.execution_start_ts is _A or self.execution_end_ts is _A:return
		return self.execution_end_ts-self.execution_start_ts
	@computed_field
	@property
	def queue_wait_time_ms(self)->t.Optional[int]:
		if self.execution_start_ts is _A:return
		return self.execution_start_ts-self.submitted_ts
	@computed_field
	@property
	def total_duration_ms(self)->t.Optional[int]:
		if self.execution_end_ts is _A:return
		return self.execution_end_ts-self.submitted_ts
	@computed_field
	@property
	def age_seconds(self)->int:now_ts=int(datetime.now(timezone.utc).timestamp()*1000);return int((now_ts-self.submitted_ts)/1000)
class Perspective(BaseModel):perspective_id:str;slug:str;name:str;description:t.Optional[str]=_A;tags:t.List[str]=[];terms:t.List[str]=[];owner:str;request_id:t.Optional[str]=_A;fingerprint:str;sql_query:t.Optional[str]=_A;normalized_sql:t.Optional[str]=_A;params:t.Optional[t.Union[t.Dict,t.List]]=_A;gateway:t.Optional[str]=_A;ttl:int=0;meta:t.Optional[t.Dict]=_A;query_type:t.Optional[QueryType]=_A;semantic_query:t.Optional[str]=_A;rest_query:t.Optional[t.Dict]=_A;graphql_query:t.Optional[str]=_A;depends_on:t.Optional[t.List[str]]=_A;auto_refresh:bool=True;is_public:bool=False;allowed_user_ids:t.List[str]=[];created_at:int;updated_at:int;created_by:t.Optional[str]=_A;updated_by:t.Optional[str]=_A