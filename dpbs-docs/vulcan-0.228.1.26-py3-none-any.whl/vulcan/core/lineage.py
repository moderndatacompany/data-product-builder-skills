from __future__ import annotations
_B=None
_A=False
import logging,typing as t
from collections import defaultdict
from sqlglot import exp,parse_one
from sqlglot.helper import first
from sqlglot.lineage import Node
from sqlglot.lineage import lineage as sqlglot_lineage
from sqlglot.optimizer import Scope,build_scope,qualify
from vulcan.core.dialect import normalize_mapping_schema,normalize_model_name,fqn_to_unquoted
if t.TYPE_CHECKING:from vulcan.core.context import Context;from vulcan.core.model import Model;from vulcan.core.snapshot.definition import Snapshot;ModelOrSnapshot=t.Union[str,Model,Snapshot]
logger=logging.getLogger(__name__)
CACHE:t.Dict[str,t.Tuple[int,exp.Expression,Scope]]={}
def lineage(column:str|exp.Column,model:Model,trim_selects:bool=True,**kwargs:t.Any)->Node:
	query=_B;scope=_B
	if model.name in CACHE:
		obj_id,query,scope=CACHE[model.name]
		if obj_id!=id(model):query=_B;scope=_B
	if not query or not scope:
		query=t.cast(exp.Query,model.render_query_or_raise().copy())
		if model.managed_columns:query=query.select(*(exp.alias_(exp.cast(exp.Null(),to=col_type),col)for(col,col_type)in model.managed_columns.items()if col not in query.named_selects),copy=_A)
		query=qualify.qualify(query,dialect=model.dialect,schema=normalize_mapping_schema(model.mapping_schema,dialect=model.dialect),**{'validate_qualify_columns':_A,'infer_schema':True,**kwargs});scope=build_scope(query)
		if scope:CACHE[model.name]=id(model),query,scope
	return sqlglot_lineage(column,sql=query,scope=scope,trim_selects=trim_selects,dialect=model.dialect,copy=_A)
def column_dependencies(context:Context,model_name:ModelOrSnapshot,column:str|exp.Column)->t.Dict[str,t.Set[str]]:
	model=context.get_model(model_name);parents=defaultdict(set)
	for node in lineage(column,model,trim_selects=_A).walk():
		if node.downstream:continue
		table=node.expression.find(exp.Table)
		if table:name=normalize_model_name(table,default_catalog=context.default_catalog,dialect=model.dialect);parents[name].add(exp.to_column(node.name).name)
	return dict(parents)
def column_description(context:Context,model_name:str,column:str,quote_column:bool=_A)->t.Optional[str]:
	model=context.get_model(model_name)
	if not model:return
	if column in model.column_descriptions:return model.column_descriptions[column]
	dependencies=column_dependencies(context,model_name,exp.column(column,quoted=quote_column))
	if len(dependencies)!=1:return
	parent,columns=first(dependencies.items())
	if len(columns)!=1:return
	return column_description(context,parent,first(columns))
def _build_schema_from_context(context:Context)->t.Dict[str,t.Any]:
	schema:t.Dict[str,t.Any]={}
	for model in context.models.values():
		if(columns_to_types:=model.columns_to_types):
			unquoted_fqn=fqn_to_unquoted(model.fqn,dialect=model.dialect);fqn_parts=unquoted_fqn.split('.')
			if len(fqn_parts)<=3:
				columns_dict={col:dtype.sql(dialect=model.dialect)if hasattr(dtype,'sql')else str(dtype)for(col,dtype)in columns_to_types.items()}
				if columns_dict:
					current=schema
					for key in fqn_parts[:-1]:current=current.setdefault(key,{})
					current[fqn_parts[-1]]=columns_dict
	return schema
def extract_field_references(sql:str,output_columns:t.List[str],context:Context,dialect:t.Optional[str]=_B)->t.Dict[str,t.List[t.Tuple[str,str]]]:
	if not output_columns:logger.warning('extract_field_references: No output columns provided, skipping extraction');return{}
	if not(schema:=_build_schema_from_context(context)):logger.warning('extract_field_references: Schema not available, skipping extraction');return{}
	default_catalog=context.default_catalog;qualify_dialect=dialect or context.default_dialect or'postgres'
	try:
		expression=parse_one(sql,read=qualify_dialect);query_expr=expression if isinstance(expression,exp.Select)else expression.args.get('this')if isinstance(expression,exp.Query)else _B;select_stmt=query_expr.this if isinstance(query_expr,exp.Alias)and isinstance(query_expr.this,exp.Select)else query_expr
		if not isinstance(select_stmt,exp.Select):logger.warning(f"extract_field_references: Could not find SELECT statement (got {type(expression)})");return{}
		qualified_query=qualify.qualify(query_expr.copy(),dialect=qualify_dialect,schema=normalize_mapping_schema(schema,dialect=qualify_dialect),validate_qualify_columns=_A,infer_schema=_A);scope=build_scope(qualified_query)
		if not scope:logger.warning('extract_field_references: Scope is None');return{}
		references:t.Dict[str,t.List[t.Tuple[str,str]]]={}
		for col_name in output_columns:
			try:
				refs={(model.name,exp.to_column(node.name).name)for node in sqlglot_lineage(exp.column(col_name),sql=qualified_query,scope=scope,trim_selects=_A,dialect=qualify_dialect,copy=_A).walk()if not node.downstream and(table:=node.expression.find(exp.Table))and(table_fqn:=normalize_model_name(table,default_catalog=default_catalog,dialect=qualify_dialect))and(model:=context.get_model(table_fqn,raise_if_missing=_A))}
				if refs:references[col_name]=sorted(refs)
			except Exception as e:logger.info(f"extract_field_references: Failed to trace lineage for column '{col_name}': {e}")
		return references
	except Exception as e:logger.warning(f"extract_field_references: Failed to extract references: {e}",exc_info=True);return{}