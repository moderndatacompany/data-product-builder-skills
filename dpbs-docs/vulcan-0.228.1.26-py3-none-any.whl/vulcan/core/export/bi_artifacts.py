from __future__ import annotations
_A=True
import logging,os,zipfile
from dataclasses import dataclass
from pathlib import Path
from schema.metadata import Metadata
from vulcan.core.export.bi.adapter import export_to_bi_tables
from vulcan.core.export.bi.powerbi import build_powerbi_entries
from vulcan.core.export.bi.tableau import build_tableau_entries
logger=logging.getLogger(__name__)
_EXPORT_OUTPUT_DIR_ENV='VULCAN_EXPORT_OUTPUT_DIR'
_DEFAULT_EXPORT_OUTPUT_DIR='/tmp/vulcan_exports'
@dataclass(frozen=_A)
class ExportArtifact:path:Path
def _export_output_base_dir()->Path:return Path(os.getenv(_EXPORT_OUTPUT_DIR_ENV,_DEFAULT_EXPORT_OUTPUT_DIR))
def _product_key(metadata:Metadata)->str:return f"{metadata.tenant}_{metadata.name}"if metadata.tenant else metadata.name
def _write_zip(zip_path:Path,entries:dict[str,str])->None:
	zip_path.parent.mkdir(parents=_A,exist_ok=_A)
	with zipfile.ZipFile(zip_path,mode='w',compression=zipfile.ZIP_DEFLATED)as zf:
		for(name,content)in entries.items():zf.writestr(name,content)
def build_export_artifacts(metadata:Metadata,*,output_dir:Path|None=None)->dict[str,ExportArtifact]:base_dir=output_dir or _export_output_base_dir()/metadata.env/_product_key(metadata)/'metadata_exports';base_dir.mkdir(parents=_A,exist_ok=_A);powerbi_path=base_dir/'powerbi.zip';tableau_path=base_dir/'tableau.zip';tables=export_to_bi_tables(metadata);_write_zip(powerbi_path,build_powerbi_entries(metadata,tables=tables));_write_zip(tableau_path,build_tableau_entries(metadata,tables=tables));logger.info('Generated export artifacts for env=%s product=%s at %s',metadata.env,_product_key(metadata),base_dir);return{'powerbi':ExportArtifact(path=powerbi_path),'tableau':ExportArtifact(path=tableau_path)}