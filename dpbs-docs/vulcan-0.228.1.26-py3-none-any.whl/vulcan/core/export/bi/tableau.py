from __future__ import annotations
_A0='properties'
_z='_.fcp.ObjectModelEncapsulateLegacy.true...object-graph'
_y='show-structure'
_x='measure-ordering'
_w='dim-ordering'
_v='_.fcp.SchemaViewerObjectModel.false...measure-percentage'
_u='_.fcp.SchemaViewerObjectModel.false...dim-percentage'
_t='layout'
_s='column'
_r='_.fcp.ObjectModelTableType.true...column'
_q='aliases'
_p='_.fcp.ObjectModelEncapsulateLegacy.true...relation'
_o='_.fcp.SchemaViewerObjectModel.true...SchemaViewerObjectModel'
_n='_.fcp.ObjectModelTableType.true...ObjectModelTableType'
_m='_.fcp.ObjectModelEncapsulateLegacy.true...ObjectModelEncapsulateLegacy'
_l='document-format-change-manifest'
_k='datasource'
_j='__joinField'
_i='__user'
_h='number'
_g='Error parsing logical tables: Cyclic relationships are not supported in Tableau'
_f='relation'
_e='18.1'
_d='false'
_c='real'
_b='destination_caption'
_a='source_caption'
_Z='alphabetic'
_Y='aggregation'
_X='quantitative'
_W='measure'
_V='CountD'
_U='Sum'
_T='id'
_S='boolean'
_R='ordinal'
_Q='connection'
_P='nominal'
_O='dimension'
_N='hidden'
_M='table'
_L='yes'
_K='datatype'
_J='time'
_I='object-id'
_H='true'
_G='string'
_F='role'
_E='type'
_D=None
_C='name'
_B='caption'
_A='no'
import json,logging,random,string,typing as t
from collections import deque
import xml.etree.ElementTree as ET
from xml.dom import minidom
from schema.metadata import Metadata
from vulcan.core.export.bi.adapter import BiColumn,BiTable,export_to_bi_tables
from vulcan.core.dataproduct_mysql import get_dataproduct_mysql_endpoint
logger=logging.getLogger(__name__)
def _generate_hex_string(length:int=32)->str:characters=string.hexdigits.upper();return''.join(random.choice(characters)for _ in range(length))
def _generate_connection_endstring(length:int=28)->str:characters=string.ascii_lowercase+string.digits;return''.join(random.choice(characters)for _ in range(length))
def _get_relations_sorted(relationship_list:list[dict[str,t.Any]],connection_object:list[dict[str,t.Any]])->list[dict[str,t.Any]]:
	if not relationship_list:return connection_object
	graph:dict[str,list[str]]={};nodes:set[str]=set()
	for rel in relationship_list:src=rel[_a];dst=rel[_b];graph.setdefault(src,[]).append(dst);nodes.add(src);nodes.add(dst)
	in_degree={n:0 for n in nodes}
	for(src,dsts)in graph.items():
		for dst in dsts:in_degree[dst]=in_degree.get(dst,0)+1
	queue:deque[str]=deque(sorted(n for n in nodes if in_degree[n]==0));sorted_names:list[str]=[]
	while queue:
		current=queue.popleft();sorted_names.append(current)
		for neighbor in sorted(graph.get(current,[])):
			in_degree[neighbor]-=1
			if in_degree[neighbor]==0:queue.append(neighbor);queue=deque(sorted(queue))
	if len(sorted_names)!=len(nodes):raise ValueError(_g)
	name_to_index={name:i for(i,name)in enumerate(sorted_names)};return sorted(connection_object,key=lambda item:name_to_index.get(t.cast(str,item[_C]),len(sorted_names)))
def _detect_cycles(xml_string:str)->list[t.Any]:
	try:root=ET.fromstring(xml_string)
	except ET.ParseError:return[]
	id_to_caption:dict[str,str]={}
	for obj in root.findall('.//object'):
		caption=obj.get(_B,'');object_id=obj.get(_T,'')
		if object_id:id_to_caption[object_id]=caption
	edges:list[tuple[str,str]]=[]
	for rel in root.findall('.//relationship'):
		first=rel.find('.//first-end-point');second=rel.find('.//second-end-point')
		if first is not _D and second is not _D:
			src_id=first.get(_I,'');dst_id=second.get(_I,'')
			if src_id in id_to_caption and dst_id in id_to_caption:edges.append((id_to_caption[src_id],id_to_caption[dst_id]))
	graph:dict[str,list[str]]={}
	for(src,dst)in edges:graph.setdefault(src,[]).append(dst)
	visited:set[str]=set();rec_stack:set[str]=set();cycles:list[tuple[str,str]]=[]
	def dfs(node:str)->_D:
		visited.add(node);rec_stack.add(node)
		for neighbor in graph.get(node,[]):
			if neighbor not in visited:dfs(neighbor)
			elif neighbor in rec_stack:cycles.append((node,neighbor))
		rec_stack.discard(node)
	for node in list(graph.keys()):
		if node not in visited:dfs(node)
	return cycles
_DATA_TYPE_MAPPINGS:dict[str,str]={_h:_c,_G:_G,_J:'datetime',_S:_S}
_HIDDEN_MAPPING:dict[str,str]={_H:_d,_d:_H}
_AGGREGATION_MAPPING:dict[str,str]={'sum':_U,_S:'Max','count':'Count','avg':'Avg','min':'Min','max':'Max','countDistinct':_V,'countDistinctApprox':_V,'count_distinct':_V,'count_distinct_approx':_V,_h:_U,_G:'Count',_J:'Min'}
_CONNECTION_CUSTOMIZATIONS:dict[str,str]={'CAP_CONNECT_CUSTOM_SQL_WITHOUT_SCHEMA':_A,'CAP_CREATE_TEMP_TABLES':_A,'CAP_CUSTOM_NOSQL':_A,'CAP_EXTRACT_ONLY':_A,'CAP_ISOLATION_LEVEL_READ_COMMITTED':_A,'CAP_ISOLATION_LEVEL_READ_UNCOMMITTED':_A,'CAP_ISOLATION_LEVEL_REPEATABLE_READS':_A,'CAP_ISOLATION_LEVEL_SERIALIZABLE':_A,'CAP_JDBC_BIND_DETECT_ALIAS_CASE_FOLDING':_A,'CAP_JDBC_SUPPRESS_EMPTY_CATALOG_NAME':_A,'CAP_JDBC_SUPPRESS_ENUMERATE_DATABASES':_A,'CAP_JDBC_SUPPRESS_ENUMERATE_SCHEMAS':_A,'CAP_JDBC_SUPPRESS_ENUMERATE_TABLES':_A,'CAP_QUERY_BOOLEXPR_TO_INTEXPR':_L,'CAP_QUERY_FROM_REQUIRES_ALIAS':_A,'CAP_QUERY_GROUP_ALLOW_DUPLICATES':_L,'CAP_QUERY_GROUP_BY_ALIAS':_A,'CAP_QUERY_GROUP_BY_DEGREE':_A,'CAP_QUERY_HAVING_REQUIRES_GROUP_BY':_A,'CAP_QUERY_HAVING_UNSUPPORTED':_A,'CAP_QUERY_JOIN_ACROSS_SCHEMAS':_A,'CAP_QUERY_JOIN_REQUIRES_SCOPE':_A,'CAP_QUERY_NULL_REQUIRES_CAST':_A,'CAP_QUERY_SELECT_ALIASES_SORTED':_L,'CAP_QUERY_SORT_BY_DEGREE':_L,'CAP_QUERY_SUBQUERIES':_A,'CAP_QUERY_SUBQUERIES_WITH_TOP':_A,'CAP_QUERY_SUBQUERY_QUERY_CONTEXT':_L,'CAP_QUERY_TOPSTYLE_LIMIT':_A,'CAP_QUERY_TOPSTYLE_ROWNUM':_A,'CAP_QUERY_TOPSTYLE_TOP':_A,'CAP_QUERY_TOP_0_METADATA':_A,'CAP_QUERY_TOP_N':_A,'CAP_QUERY_WHERE_FALSE_METADATA':_A,'CAP_SELECT_INTO':_L,'CAP_SELECT_TOP_INTO':_L,'CAP_SET_ISOLATION_LEVEL_VIA_ODBC_API':_A,'CAP_SET_ISOLATION_LEVEL_VIA_SQL':_A,'CAP_SUPPRESS_CONNECTION_POOLING':_A,'CAP_SUPPRESS_DISCOVERY_QUERIES':_A}
def _short_name(col:BiColumn)->str:return col.name.split('.',1)[1]if'.'in col.name else col.name
def _build_jdbc_url(host:str,port:str,dbname:str)->str:host_or=host or'127.0.0.1';port_or=port or'3306';return f"jdbc:mysql://{host_or}:{port_or}/{dbname}"
def _build_genericjdbc_connection(root:ET.Element,jdbc_url:str,host:str,port:str,username:str|_D)->tuple[str,ET.Element]:
	C='mysql';B='genericjdbc';A='class';connection_el=ET.SubElement(root,_Q,attrib={A:'federated'});connection_name=f"genericjdbc.{host or'localhost'}";named_connections=ET.SubElement(connection_el,'named-connections');named_connection=ET.SubElement(named_connections,'named-connection',caption=jdbc_url,name=connection_name);inner_conn=ET.SubElement(named_connection,_Q,attrib={A:B},dbname='public',dialect=C,jdbcproperties='',jdbcurl=jdbc_url,port=port or'',schema='',server=host or'',username=username or'',warehouse='');customization=ET.SubElement(inner_conn,'connection-customization',attrib={A:B},enabled=_d,version=_e);ET.SubElement(customization,'vendor',name=B);ET.SubElement(customization,'driver',name=C);customizations_el=ET.SubElement(customization,'customizations')
	for(name,value)in _CONNECTION_CUSTOMIZATIONS.items():ET.SubElement(customizations_el,'customization',name=name,value=value)
	return connection_name,connection_el
def _build_tables_tds(tables:list[BiTable],host:str,port:int,product_db:str,username:str|_D=_D)->str:
	F='dest';E='source';D='expression';C='cardinality';B='destination_id';A='source_id';port_str=str(port);columns_object:list[dict[str,object]]=[];table_object:list[dict[str,object]]=[];obj:list[dict[str,object]]=[];connection_object:list[dict[str,object]]=[];relationship_obj:list[dict[str,object]]=[];cols_obj:list[dict[str,object]]=[]
	for table in tables:
		if not table.public or table.type!=_M:continue
		hex_string=_generate_hex_string();object_id=f"{table.name}_{hex_string}";table_data={_B:table.name,_K:_M,_C:f"[__tableau_internal_object_id__].[{object_id}]",_F:_W,_E:_X};obj_data={_B:table.name,_T:object_id};connection_data={_Q:'',_C:table.name,_M:f"[public].[{table.name}]",_E:_M};connection_object.append(connection_data);obj.append(obj_data);table_object.append(table_data)
		for dimension in table.dimensions:short=_short_name(dimension);columns_data={_B:short,_K:_DATA_TYPE_MAPPINGS.get(str(dimension.type),_G),_N:_HIDDEN_MAPPING[str(dimension.public).lower()],_C:f"[{short} ({table.name})]",_F:_O,_E:_R if str(dimension.type)==_J else _P};columns_object.append(columns_data)
		for measure in table.measures:
			short=_short_name(measure);columns_data={_B:short,_K:_DATA_TYPE_MAPPINGS.get(str(measure.type),_c),_Y:_AGGREGATION_MAPPING.get(str(measure.agg_type or''),_U),_N:_HIDDEN_MAPPING[str(measure.public).lower()],_C:f"[{short} ({table.name})]",_F:_W,_E:_R if str(measure.type)==_J else _X}
			if str(measure.type)not in[_J,_S,_G]:columns_object.append(columns_data)
			else:columns_data.pop(_Y,_D);columns_data[_F]=_O;columns_data[_E]=_R if str(measure.type)==_J else _P;columns_object.append(columns_data)
		columns_object.append({_B:_i,_K:_G,_N:_H,_C:f"[__user ({table.name})]",_F:_O,_E:_P});columns_object.append({_B:_j,_K:_G,_N:_H,_C:f"[__joinField ({table.name})]",_F:_O,_E:_P})
		for join in table.joins:relationship_obj.append({E:table.name,F:join.name,C:str(join.relationship)})
	caption_to_id={item[_B]:item[_T]for item in obj};relationship_list:list[dict[str,object]]=[]
	for relation in relationship_obj:
		source_caption=t.cast(str,relation[E]);dest_caption=t.cast(str,relation[F]);cardinality=t.cast(str,relation[C]);source_id=caption_to_id.get(source_caption);dest_id=caption_to_id.get(dest_caption)
		if source_id and dest_id:relationship_list.append({_a:source_caption,A:source_id,_b:dest_caption,B:dest_id,C:cardinality})
	connection_object=_get_relations_sorted(relationship_list,connection_object)
	for item in columns_object:key=t.cast(str,item[_C]);caption=t.cast(str,item[_B]);cols_obj.append({'key':key,'value':f"[{key.split('(')[1].split(')')[0]}].[{caption}]"})
	root=ET.Element(_k,inline=_H,version=_e);manifest_el=ET.SubElement(root,_l);ET.SubElement(manifest_el,_m);ET.SubElement(manifest_el,_n);ET.SubElement(manifest_el,_o);jdbc_url=_build_jdbc_url(host,port_str,product_db);connection_name,connection_el=_build_genericjdbc_connection(root,jdbc_url,host,port_str,username)
	for conn in connection_object:conn[_Q]=connection_name
	fcp_true_relation_string=ET.SubElement(connection_el,_p,type='collection')
	for conn in connection_object:ET.SubElement(fcp_true_relation_string,_f,**t.cast(dict[str,str],conn))
	cols=ET.SubElement(connection_el,'cols')
	for col in cols_obj:ET.SubElement(cols,'map',**t.cast(dict[str,str],col))
	ET.SubElement(root,_q,enabled=_L)
	for table in table_object:ET.SubElement(root,_r,**t.cast(dict[str,str],table))
	for column in columns_object:ET.SubElement(root,_s,**t.cast(dict[str,str],column))
	ET.SubElement(root,_t,**{_u:'0.5'},**{_v:'0.4'},**{_w:_Z,_x:_Z,_y:_H});object_graph=ET.SubElement(root,_z);objects=ET.SubElement(object_graph,'objects')
	for x in obj:object_elem=ET.SubElement(objects,'object',**t.cast(dict[str,str],x));properties=ET.SubElement(object_elem,_A0,context='');ET.SubElement(properties,_f,connection=connection_name,name=t.cast(str,x[_B]),table=f"[public].[{t.cast(str,x[_B])}]",type=_M)
	relationships=ET.SubElement(object_graph,'relationships')
	for relation in relationship_list:
		relationship=ET.SubElement(relationships,'relationship');expression=ET.SubElement(relationship,D,op='=');ET.SubElement(expression,D,op=f"[__joinField ({relation[_a]})]");ET.SubElement(expression,D,op=f"[__joinField ({relation[_b]})]");unique_key={'unique-key':_H};card=str(relation[C]).lower()
		if'many_to_one'in card or'belongs'in card:first_end_point_id={_I:relation[A]};second_end_point_id={_I:relation[B],**unique_key}
		elif'one_to_many'in card or'hasmany'in card:first_end_point_id={_I:relation[A],**unique_key};second_end_point_id={_I:relation[B]}
		elif'one_to_one'in card or'hasone'in card:first_end_point_id={_I:relation[A],**unique_key};second_end_point_id={_I:relation[B],**unique_key}
		else:first_end_point_id={_I:relation[A],**unique_key};second_end_point_id={_I:relation[B]}
		ET.SubElement(relationship,'first-end-point',**t.cast(dict[str,str],first_end_point_id));ET.SubElement(relationship,'second-end-point',**t.cast(dict[str,str],second_end_point_id))
	tds_xml=ET.tostring(root,encoding='utf-8',method='xml');tds_str=minidom.parseString(tds_xml).toprettyxml(indent='  ');cycles=_detect_cycles(tds_str)
	if cycles:raise ValueError(_g)
	return tds_str
def _build_view_tds(table:BiTable,host:str,port:int,product_db:str)->str:
	port_str=str(port);columns_object:list[dict[str,object]]=[];table_object:list[dict[str,object]]=[];obj:list[dict[str,object]]=[];connection_object:list[dict[str,object]]=[];table_data={_B:table.name,_K:_M,_C:f"[__tableau_internal_object_id__].[{table.name}]",_F:_W,_E:_X};obj_data={_B:table.name,_T:table.name};connection_data={_Q:'',_C:table.name,_M:f"[public].[{table.name}]",_E:_M};connection_object.append(connection_data);obj.append(obj_data);table_object.append(table_data)
	for dimension in table.dimensions:short=_short_name(dimension);columns_object.append({_B:short,_K:_DATA_TYPE_MAPPINGS.get(str(dimension.type),_G),_N:_HIDDEN_MAPPING[str(dimension.public).lower()],_C:f"[{short}]",_F:_O,_E:_R if str(dimension.type)==_J else _P})
	for measure in table.measures:
		short=_short_name(measure);columns_data={_B:short,_K:_DATA_TYPE_MAPPINGS.get(str(measure.type),_c),_Y:_AGGREGATION_MAPPING.get(str(measure.agg_type or''),_U),_N:_HIDDEN_MAPPING[str(measure.public).lower()],_C:f"[{short}]",_F:_W,_E:_R if str(measure.type)==_J else _X}
		if str(measure.type)not in[_J,_S,_G]:columns_object.append(columns_data)
		else:columns_data.pop(_Y,_D);columns_data[_F]=_O;columns_data[_E]=_R if str(measure.type)==_J else _P;columns_object.append(columns_data)
	columns_object.append({_B:_i,_K:_G,_N:_H,_C:'[__user]',_F:_O,_E:_P});columns_object.append({_B:_j,_K:_G,_N:_H,_C:'[__joinField]',_F:_O,_E:_P});root=ET.Element(_k,inline=_H,version=_e);manifest_el=ET.SubElement(root,_l);ET.SubElement(manifest_el,_m);ET.SubElement(manifest_el,_n);ET.SubElement(manifest_el,_o);jdbc_url=_build_jdbc_url(host,port_str,product_db);connection_name,connection_el=_build_genericjdbc_connection(root,jdbc_url,host,port_str,_D)
	for conn in connection_object:conn[_Q]=connection_name;ET.SubElement(connection_el,_p,**t.cast(dict[str,str],conn))
	ET.SubElement(root,_q,enabled=_L)
	for column in columns_object:ET.SubElement(root,_s,**t.cast(dict[str,str],column))
	for td in table_object:ET.SubElement(root,_r,**t.cast(dict[str,str],td))
	ET.SubElement(root,_t,**{_u:'0.5'},**{_v:'0.4'},**{_w:_Z,_x:_Z,_y:_H});object_graph=ET.SubElement(root,_z);objects=ET.SubElement(object_graph,'objects')
	for x in obj:object_elem=ET.SubElement(objects,'object',**t.cast(dict[str,str],x));properties=ET.SubElement(object_elem,_A0,context='');ET.SubElement(properties,_f,connection=connection_name,name=t.cast(str,x[_B]),table=f"[public].[{t.cast(str,x[_B])}]",type=_M)
	tds_xml=ET.tostring(root,encoding='utf-8',method='xml');return minidom.parseString(tds_xml).toprettyxml(indent='  ')
def build_tableau_entries(metadata:Metadata,*,tables:list[BiTable]|_D=_D,username:str|_D=_D)->dict[str,str]:
	endpoint=get_dataproduct_mysql_endpoint();product_key=f"{metadata.tenant}_{metadata.name}"if metadata.tenant else metadata.name;product_id=f"{metadata.tenant}/{metadata.name}";product_db=f"{metadata.tenant}.{metadata.name}"
	if tables is _D:tables=export_to_bi_tables(metadata)
	entries:dict[str,str]={'data_sources/manifest.json':json.dumps({'product':product_id,'environment':metadata.env,'models':[table.name for table in tables]},indent=2),f"data_sources/tables/{product_key}_tables.tds":_build_tables_tds(tables,endpoint.host,endpoint.port,product_db,username=username)}
	for table in tables:
		if table.type=='view'and table.public:entries[f"data_sources/views/{table.name}.tds"]=_build_view_tds(table,endpoint.host,endpoint.port,product_db)
	return entries