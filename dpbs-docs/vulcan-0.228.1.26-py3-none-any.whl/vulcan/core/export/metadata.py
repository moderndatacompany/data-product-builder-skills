from __future__ import annotations
_G='SEMANTIC'
_F='segment'
_E='dimension'
_D='measure'
_C='name'
_B=True
_A=None
import logging,typing as t
from collections import defaultdict
from dataclasses import dataclass
from sqlglot import exp
from schema.types import IntervalUnit as _WireIntervalUnit
from schema.metadata import AuditEntry,ColumnDetails,ColumnEntry,ColumnKind,ColumnLineage,DependsOn,DimensionDetails,DqRuleEntry,GatewayInfo,Graph,GraphColumn,GraphEdge,GraphNode,JoinDetail,JoinEdge,LineageUpstream,MeasureDetails,Metadata,ModelDataQuality,ModelEntry,ModelKindValue,ModelSourceType,ProductInfo,SegmentDetails,UserEntry,Table,TableDetail
from schema.filters import PolicyEntry
from vulcan.core import constants as c
from vulcan.core import lineage as vulcan_lineage
from vulcan.core.context import Context
from vulcan.core.dialect import extract_expression_references,fqn_to_unquoted
from vulcan.core.environment import Environment,EnvironmentNamingInfo,EnvironmentStatements
from vulcan.core.model import MetricModel,Model,SemanticModel
from vulcan.core.model.definition import _METRIC_COL_MEASURE,_METRIC_COL_TS,_Model
from vulcan.core.model.semantic import PolicySpec,_parse_qualified_reference,sql_dtype_to_logical_type
from vulcan.core.snapshot import DeployabilityIndex
from vulcan.core.snapshot.definition import Snapshot,SnapshotId,SnapshotTableInfo
from vulcan.utils.errors import VulcanError
from vulcan.utils.hashing import hash_data
logger=logging.getLogger(__name__)
_AUDIT_COLUMN_ARG_KEYS='columns','column'
_DEFAULT_DIALECT='postgres'
def _environment_snapshot_set_fingerprint(snapshots_info:t.Sequence[SnapshotTableInfo])->str:
	fingerprint_parts:t.List[str]=[]
	for s in sorted(snapshots_info,key=lambda x:x.name):fingerprint_parts.append(s.name);fingerprint_parts.append(s.identifier)
	return'crc32:'+hash_data(fingerprint_parts)
@dataclass
class MetadataContext:
	_fqn_name:t.Dict[str,str];_by_fqn:t.Dict[str,Model];_name_fqn:t.Dict[str,str]
	@classmethod
	def from_snapshots(cls,snapshots:t.Dict[SnapshotId,Snapshot])->MetadataContext:fqn_name={s.model.fqn:s.model.name for s in snapshots.values()if s.is_model};by_fqn={s.model.fqn:s.model for s in snapshots.values()if s.is_model};name_fqn={name:fqn for(fqn,name)in fqn_name.items()};return cls(_fqn_name=fqn_name,_by_fqn=by_fqn,_name_fqn=name_fqn)
	def by_name(self,name:str)->t.Optional[Model]:
		fqn=self._name_fqn.get(name)
		if not fqn:return
		return self._by_fqn.get(fqn)
	def by_fqn(self,fqn:str)->t.Optional[Model]:return self._by_fqn.get(fqn)
	def resolve_column_name(self,model:t.Optional[Model],column_name:str)->str:
		if model and(columns_to_types:=model.columns_to_types):
			if column_name in columns_to_types:return column_name
			folded=column_name.casefold();matches=[col for col in columns_to_types if col.casefold()==folded]
			if len(matches)==1:return matches[0]
		return column_name
	def lineage_target_for_qualifier(self,qualifier:str)->t.Optional[str]:
		model=self.by_name(qualifier)
		if model is _A:return
		if isinstance(model,SemanticModel)and model.depends_on:anchor=min(model.depends_on)
		else:anchor=str(model.fqn)
		return self._fqn_name.get(anchor)
	def depends_on_from_expressions(self,expressions:t.List[str],dialect:str)->t.List[DependsOn]:
		refs:t.List[DependsOn]=[];seen:t.Set[t.Tuple[str,str]]=set()
		for expr in expressions:
			if not expr or not expr.strip():continue
			try:
				for col in extract_expression_references(expression=expr,dialect=dialect):
					alias=col.table if hasattr(col,'table')and col.table else _A;alias_str=str(alias)if alias else'';column_name=col.name if hasattr(col,_C)and col.name else str(col);ref_name=self.lineage_target_for_qualifier(alias_str)
					if ref_name and(ref_name,column_name)not in seen:seen.add((ref_name,column_name));refs.append(DependsOn(model=ref_name,column=column_name))
			except Exception as e:logger.debug('Failed to extract refs from expression: %s',e)
		return sorted(refs,key=lambda r:(r.model,r.column or''))
	def names_for_fqns(self,fqns:t.Collection[str])->t.List[str]:return[fqn_to_unquoted(self._fqn_name.get(fqn,fqn))for fqn in fqns]
	def column_lineage(self,context:Context,snapshot:Snapshot,column_name:str)->t.List[DependsOn]:
		try:deps=vulcan_lineage.column_dependencies(context,snapshot,column_name)
		except Exception as e:logger.debug('Failed to compute lineage for %s.%s: %s',snapshot.model.name,column_name,e);return[]
		if not deps:return[]
		refs:t.List[DependsOn]=[]
		for(fqn,cols)in deps.items():
			name=self._fqn_name.get(fqn,fqn);parent_model=self.by_fqn(fqn)
			for col_name in cols:refs.append(DependsOn(model=name,column=self.resolve_column_name(parent_model,col_name)))
		return sorted(refs,key=lambda r:(r.model,r.column or''))
def _build_product_info(context:Context)->ProductInfo:config=context.config;users=[UserEntry(username=u.username,type=u.type)for u in context.users];return ProductInfo(display_name=config.display_name,description=config.description,tags=list(config.tags),terms=list(config.terms),users=users,domain=config.domain,usage=config.usage,issue_tracker=config.issue_tracker,repository=context.git_client.project_folder_url())
def _build_gateway_metadata(context:Context)->t.Tuple[GatewayInfo,t.Optional[t.List[GatewayInfo]]]:
	default_name=context.config.default_gateway_name;default_key=default_name.lower();gateways_cfg=context.config.gateways;gateway_names=sorted(gateways_cfg.keys())if isinstance(gateways_cfg,dict)else[default_key];all_gateways=[GatewayInfo(name=name,connection_type=connection.type_,dialect=connection.DIALECT,connection_uri=connection.get_connection_uri())for name in gateway_names if(connection:=context.config.get_connection(name))];default=next((gateway for gateway in all_gateways if gateway.name==default_key),_A)
	if default is _A:raise VulcanError(f"Cannot export default gateway '{default_name}': not found in configured gateways")
	others=[gateway for gateway in all_gateways if gateway.name!=default_key];return default,others or _A
def _build_table(snapshot:Snapshot,model:t.Optional[Model],env_naming_info:t.Optional[EnvironmentNamingInfo],deployability_index:t.Optional[DeployabilityIndex],connection_uri:str,dialect:t.Optional[str]=_A)->t.Optional[Table]:
	dialect=dialect or(model.dialect if model is not _A else _A)or _DEFAULT_DIALECT;uri=connection_uri or''
	try:
		is_deployable=deployability_index.is_deployable(snapshot.snapshot_id)if deployability_index else _B;table=snapshot.table_name(is_deployable=is_deployable);table=fqn_to_unquoted(table,dialect=dialect);physical=TableDetail(connection_uri=uri,name=table)
		if env_naming_info is _A:return Table(physical=physical,virtual=_A)
		view=snapshot.qualified_view_name.for_environment(env_naming_info,dialect=dialect);view=fqn_to_unquoted(view,dialect=dialect);virtual=_A if table==view else TableDetail(connection_uri=uri,name=view);return Table(physical=physical,virtual=virtual)
	except Exception as e:logger.warning('Could not build table for snapshot %s: %s',snapshot.name,e);raise
def _dialect(model:_Model)->str:
	d_dialect=getattr(model,'dialect',_A)
	if isinstance(d_dialect,str)and d_dialect:return d_dialect
	if d_dialect:return str(getattr(d_dialect,_C,_DEFAULT_DIALECT))
	return _DEFAULT_DIALECT
def _build_semantic_columns(sem:SemanticModel,mctx:MetadataContext,primary_model:t.Optional[Model])->t.List[ColumnEntry]:
	A='count';dialect=_dialect(sem);cols=sem.columns_to_types or{};grain_names={g.name for g in sem.grains}if sem.grains else set();col_tags=sem.column_tags or{};col_terms=sem.column_terms or{};col_descriptions=sem.column_descriptions or{};physical_name=primary_model.name if primary_model is not _A else sem.name;by_dimension={d.name:d for d in sem.dimensions};by_measure={m.name:m for m in sem.measures};by_segment={s.name:s for s in sem.segments};out:t.List[ColumnEntry]=[]
	for(name,dtype)in cols.items():
		desc=col_descriptions.get(name);tags=[str(x)for x in col_tags.get(name,[])or[]];terms=[str(x)for x in col_terms.get(name,[])or[]];kind:t.Optional[ColumnKind]=_A;depends_on:t.List[DependsOn]=[];details:t.Optional[ColumnDetails]=_A;primary_key=False;public=_B;ai_context=_A;behavior=_A
		if name in by_dimension:d=by_dimension[name];kind=_E;primary_key=name in grain_names;depends_on=[DependsOn(model=physical_name,column=name)];details=DimensionDetails(time_format=d.format if d.format else _A,time_granularities=d.granularities or _A,mask_expression=d.mask_expression);public=bool(d.public)and not primary_key;ai_context=d.ai_context;behavior=d.behavior
		elif name in by_measure:m=by_measure[name];kind=_D;depends_on=mctx.depends_on_from_expressions(([m.expression]if m.expression else[])+list(m.filters or[]),dialect);details=MeasureDetails(expression=m.expression or _A,agg_type=m.type,filters=list(m.filters or[]),rolling_window=m.rolling_window);public=m.public;ai_context=m.ai_context;behavior=m.behavior
		elif name in by_segment:seg=by_segment[name];kind=_F;depends_on=mctx.depends_on_from_expressions([seg.expression],dialect);details=SegmentDetails(expression=seg.expression or _A);public=seg.public;ai_context=seg.ai_context
		else:continue
		out.append(ColumnEntry(name=name,kind=kind,ltype=sql_dtype_to_logical_type(dtype),dtype=dtype.sql()or str(dtype)or'',description=desc,tags=tags,terms=terms,primary_key=primary_key,public=public,depends_on=depends_on,details=details,behavior=behavior,ai_context=ai_context))
	if not any(c.name==A and c.kind==_D for c in out):out.append(ColumnEntry(name=A,kind=_D,ltype='number',dtype='BIGINT',description='Count of rows',public=_B,depends_on=[],details=MeasureDetails(expression=_A,agg_type=A,filters=[],rolling_window=_A)))
	return out
def _build_metric_columns(metric:MetricModel,mctx:MetadataContext)->t.List[ColumnEntry]:
	columns=metric.columns_to_types or{};dimensions_by_column={d.name:d for d in metric.dimensions};segments_by_column={s.name:s for s in metric.segments}
	def _depends_on(ref:str)->DependsOn:model,column=t.cast(t.Tuple[str,str],_parse_qualified_reference(ref));return DependsOn(model=model,column=column)
	out:t.List[ColumnEntry]=[]
	for(name,dtype)in columns.items():
		column_description=metric.column_descriptions.get(name);col_tags=[str(x)for x in metric.column_tags.get(name,[])];col_terms=[str(x)for x in metric.column_terms.get(name,[])];kind:t.Optional[ColumnKind]=_A;depends_on:t.List[DependsOn]=[];details:t.Optional[ColumnDetails]=_A;public=_B;ai_context=_A;behavior=_A
		if name==_METRIC_COL_MEASURE:kind=_D;source_model,field_name=_parse_qualified_reference(metric.measure);semantic_model=mctx.by_name(source_model);measure_spec=next(spec for spec in semantic_model.measures if spec.name==field_name);depends_on=[_depends_on(metric.measure)];public=measure_spec.public;details=MeasureDetails(expression=measure_spec.expression or _A,agg_type=measure_spec.type,filters=list(measure_spec.filters or[]),rolling_window=measure_spec.rolling_window);ai_context=measure_spec.ai_context;behavior=measure_spec.behavior
		elif name==_METRIC_COL_TS:kind=_E;source_model,field_name=_parse_qualified_reference(metric.ts);semantic_model=t.cast(SemanticModel,mctx.by_name(source_model));dimension_spec=next(spec for spec in semantic_model.dimensions if spec.name==field_name);grain_names={g.name for g in semantic_model.grains}if semantic_model.grains else set();is_grain_dimension=dimension_spec.name in grain_names;public=bool(dimension_spec.public)and not is_grain_dimension;details=DimensionDetails(time_format=dimension_spec.format if dimension_spec.format else _A,time_granularities=dimension_spec.granularities or _A,mask_expression=dimension_spec.mask_expression);depends_on=[_depends_on(metric.ts)];ai_context=dimension_spec.ai_context;behavior=dimension_spec.behavior
		elif name in dimensions_by_column:kind=_E;metric_dim=dimensions_by_column[name];source_model,field_name=_parse_qualified_reference(metric_dim.ref);semantic_model=t.cast(SemanticModel,mctx.by_name(source_model));dimension_spec=next(spec for spec in semantic_model.dimensions if spec.name==field_name);grain_names={g.name for g in semantic_model.grains}if semantic_model.grains else set();is_grain_dimension=dimension_spec.name in grain_names;public=bool(dimension_spec.public)and not is_grain_dimension;details=DimensionDetails(time_format=dimension_spec.format if dimension_spec.format else _A,time_granularities=dimension_spec.granularities or _A,mask_expression=dimension_spec.mask_expression);depends_on=[_depends_on(metric_dim.ref)];ai_context=metric_dim.ai_context;behavior=dimension_spec.behavior
		elif name in segments_by_column:kind=_F;metric_seg=segments_by_column[name];source_model,field_name=_parse_qualified_reference(metric_seg.ref);semantic_model=mctx.by_name(source_model);segment_spec=next(spec for spec in semantic_model.segments if spec.name==field_name);public=segment_spec.public;depends_on=[_depends_on(metric_seg.ref)];details=SegmentDetails(expression=segment_spec.expression or _A);ai_context=segment_spec.ai_context
		else:continue
		out.append(ColumnEntry(name=name,kind=kind,ltype=sql_dtype_to_logical_type(dtype),dtype=dtype.sql()or str(dtype)or'',description=column_description,tags=col_tags,terms=col_terms,public=public,depends_on=depends_on,details=details,behavior=behavior,ai_context=ai_context))
	return out
def _join_details_from_semantic(sem:SemanticModel)->t.List[JoinDetail]:
	joins:t.List[JoinDetail]=[]
	for join in sem.joins:joins.append(JoinDetail(model=join.name,relationship=join.type,expression=join.expression,ai_context=join.ai_context))
	return joins
def _policies(policies:t.Iterable[PolicySpec])->t.List[PolicyEntry]:return[PolicyEntry(group=policy.group,filter=policy.filter,mask=policy.mask)for policy in policies]
def _model_entry_for_metric(context:Context,snapshot:Snapshot,mctx:MetadataContext,*,gateway:t.Optional[GatewayInfo]=_A,env_naming_info:t.Optional[EnvironmentNamingInfo]=_A,deployability_index:t.Optional[DeployabilityIndex]=_A,connection_uri:t.Optional[str]=_A)->ModelEntry:metric=t.cast(MetricModel,snapshot.node);dialect=gateway.dialect if gateway else metric.dialect;return ModelEntry(name=metric.name,fqn=metric.fqn,kind='METRIC',source_type='metric',table=_A,description=metric.description or _A,owner=metric.owner or _A,tags=[str(tag)for tag in metric.tags],terms=[str(term)for term in metric.terms],dialect=dialect,cron=str(metric.cron),interval_unit=_WireIntervalUnit(metric.interval_unit.value)if metric.interval_unit else _A,depends_on=mctx.names_for_fqns(metric.depends_on),columns=_build_metric_columns(metric,mctx),default_granularity=metric.granularity,ai_context=metric.ai_context)
def _model_entry_for_semantic(context:Context,snapshot:Snapshot,mctx:MetadataContext,*,gateway:t.Optional[GatewayInfo]=_A,env_naming_info:t.Optional[EnvironmentNamingInfo]=_A,deployability_index:t.Optional[DeployabilityIndex]=_A,connection_uri:t.Optional[str]=_A)->ModelEntry:semantic=t.cast(SemanticModel,snapshot.node);primary_fqn=min(semantic.depends_on)if semantic.depends_on else _A;primary=mctx.by_fqn(primary_fqn)if primary_fqn else _A;grains=sorted(g.name for g in semantic.grains or()if getattr(g,_C,_A)is not _A);return ModelEntry(name=semantic.name,fqn=semantic.fqn,kind=_G,source_type='semantic',table=_A,description=semantic.description or _A,tags=[str(tag)for tag in semantic.tags],terms=[str(term)for term in semantic.terms],owner=semantic.owner,dialect=semantic.dialect,cron=str(semantic.cron),interval_unit=_WireIntervalUnit(semantic.interval_unit.value)if semantic.interval_unit else _A,depends_on=mctx.names_for_fqns(semantic.depends_on),grains=grains,joins=_join_details_from_semantic(semantic),columns=_build_semantic_columns(semantic,mctx,primary),ai_context=semantic.ai_context,policies=_policies(semantic.policies))
def _audit_column_names(audit_args:t.Optional[t.Dict[str,t.Any]])->t.Optional[t.List[str]]:
	if not audit_args:return
	columns_expr=next((audit_args[key]for key in _AUDIT_COLUMN_ARG_KEYS if key in audit_args),_A)
	if columns_expr is _A:return
	while isinstance(columns_expr,exp.Paren):columns_expr=columns_expr.this
	names:t.List[str]=[]
	if isinstance(columns_expr,exp.Tuple):names=[c.name for c in columns_expr.expressions if isinstance(c,exp.Column)]
	elif isinstance(columns_expr,exp.Column):names=[columns_expr.name]
	elif isinstance(columns_expr,exp.Array):names=[lit.this for lit in columns_expr.expressions if isinstance(lit,exp.Literal)]
	else:return
	return names or _A
def _model_entry_for_sql_model(context:Context,snapshot:Snapshot,mctx:MetadataContext,*,gateway:t.Optional[GatewayInfo]=_A,env_naming_info:t.Optional[EnvironmentNamingInfo]=_A,deployability_index:t.Optional[DeployabilityIndex]=_A,connection_uri:t.Optional[str]=_A)->ModelEntry:model=snapshot.model;dialect_gw=gateway.dialect if gateway else _A;table=_build_table(snapshot,model,env_naming_info,deployability_index,connection_uri or'',dialect_gw);is_external=str(model.source_type).strip().lower()=='external';grains=sorted((g.name for g in model.grains if getattr(g,_C,_A)is not _A),key=str)if hasattr(model,'grains')and model.grains else[];grain_names=set(grains);columns_to_types=model.columns_to_types or{};columns=[ColumnEntry(name=fqn_to_unquoted(name)if is_external else name,kind='physical',ltype=sql_dtype_to_logical_type(dtype),dtype=dtype.sql()or str(dtype)or'',primary_key=name in grain_names,description=model.column_descriptions.get(name)if hasattr(model,'column_descriptions')else _A,tags=list(model.column_tags.get(name,[]))if hasattr(model,'column_tags')else[],terms=list(model.column_terms.get(name,[]))if hasattr(model,'column_terms')else[],depends_on=mctx.column_lineage(context,snapshot,name))for(name,dtype)in columns_to_types.items()];audits=[AuditEntry(name=audit_name,columns=_audit_column_names(audit_args),args={k:v.sql()if hasattr(v,'sql')else str(v)for(k,v)in(audit_args or{}).items()})for(audit_name,audit_args)in model.audits or[]];kind_str=str(model.kind.name);source_type_str=str(model.source_type).strip().lower();return ModelEntry(name=fqn_to_unquoted(model.name)if is_external else model.name,fqn=model.fqn,kind=t.cast(ModelKindValue,kind_str),source_type=t.cast(ModelSourceType,source_type_str),table=table,display_name=_A,description=model.description,tags=list(model.tags),terms=list(model.terms),owner=model.owner,dialect=model.dialect,cron=model.cron,interval_unit=_WireIntervalUnit(model.interval_unit.value)if model.interval_unit else _A,depends_on=mctx.names_for_fqns(model.depends_on),columns=columns,grains=grains,dq=ModelDataQuality(filter=model_dq.filter,profiles=list(model_dq.profiles),rules=[DqRuleEntry(name=r.name,expression=r.expression,dimension=r.dimension,description=r.description,extra=dict(r.extra))for r in model_dq.rules])if(model_dq:=getattr(model,'dq',_A))is not _A else _A,audits=audits,partitioned_by=_A if not model.partitioned_by else', '.join(expr.sql(pretty=_B,dialect=model.dialect)for expr in model.partitioned_by),clustered_by=_A if not model.clustered_by else', '.join(col.sql(dialect=model.dialect)for col in model.clustered_by),table_format=model.table_format,storage_format=model.storage_format,batch_size=model.batch_size,lookback=model.lookback if model.lookback>0 else _A)
def _build_model_entry(context:Context,snapshot:Snapshot,mctx:MetadataContext,env_naming_info:t.Optional[EnvironmentNamingInfo]=_A,deployability_index:t.Optional[DeployabilityIndex]=_A,connection_uri:t.Optional[str]=_A,gateway:t.Optional[GatewayInfo]=_A)->ModelEntry:
	opts={'gateway':gateway,'env_naming_info':env_naming_info,'deployability_index':deployability_index,'connection_uri':connection_uri}
	if isinstance(snapshot.node,MetricModel):builder=_model_entry_for_metric
	elif isinstance(snapshot.node,SemanticModel):builder=_model_entry_for_semantic
	else:builder=_model_entry_for_sql_model
	return builder(context,snapshot,mctx,**opts)
_LineageFlat=t.Tuple[str,str,str]
def _metadata_graph_collect_edges(models:t.List[ModelEntry],names:t.Set[str])->tuple[t.List[GraphEdge],dict[str,t.List[str]],dict[str,t.List[str]]]:
	edges:t.List[GraphEdge]=[];parents:t.Dict[str,t.List[str]]=defaultdict(list);children:t.Dict[str,t.List[str]]=defaultdict(list);seen_edges:t.Set[t.Tuple[str,str]]=set()
	def add_edge(from_n:str,to_n:str)->_A:
		key=from_n,to_n
		if key in seen_edges:return
		seen_edges.add(key);edges.append(GraphEdge(to=to_n,from_=from_n));parents[to_n].append(from_n);children[from_n].append(to_n)
	for entry in sorted(models,key=lambda m:m.name):
		dependant=entry.name
		if dependant not in names:continue
		for dep in entry.depends_on:
			if dep not in names:continue
			add_edge(dep,dependant)
	edges.sort(key=lambda e:(e.from_,e.to));normalized_parents={name:sorted(set(parent_list))for(name,parent_list)in parents.items()};normalized_children={name:sorted(set(child_list))for(name,child_list)in children.items()};return edges,normalized_parents,normalized_children
def _build_graph(models:t.List[ModelEntry])->Graph:
	names={m.name for m in models};edges,parent_map,child_map=_metadata_graph_collect_edges(models,names);relationships:t.List[JoinEdge]=[]
	for m in sorted(models,key=lambda x:x.name):
		if m.kind!=_G:continue
		for j in m.joins:
			if j.model not in names:continue
			relationships.append(JoinEdge(to=j.model,type_=j.relationship,from_=m.name))
	relationships.sort(key=lambda r:(r.from_,r.to))
	def _flatten_lineage(entry:ModelEntry)->t.List[_LineageFlat]:
		out:t.List[_LineageFlat]=[]
		for col in entry.columns:
			for ref in col.depends_on:
				pred=ref.model
				if pred not in names:continue
				out.append((pred,col.name,ref.column or''))
		return out
	def _merge_lineage(entries:t.List[_LineageFlat])->t.List[ColumnLineage]:
		by_pred:t.Dict[t.Tuple[str,str],t.List[str]]=defaultdict(list)
		for(pred_node,target_col,source_col)in entries:by_pred[target_col,pred_node].append(source_col)
		grouped:t.Dict[str,t.List[LineageUpstream]]=defaultdict(list)
		for((target_col,pred_node),source_cols)in by_pred.items():grouped[target_col].append(LineageUpstream(node=pred_node,columns=list(dict.fromkeys(source_cols))))
		lineage:t.List[ColumnLineage]=[]
		for target_col in sorted(grouped.keys()):contributors=grouped[target_col];lineage.append(ColumnLineage(to=target_col,from_=sorted(contributors,key=lambda x:x.node)))
		return lineage
	nodes=[GraphNode(name=m.name,kind=m.kind,source_type=m.source_type,columns=[GraphColumn(name=col.name,ltype=col.ltype,kind=col.kind)for col in m.columns],parents=sorted(parent_map.get(m.name,[])),children=sorted(child_map.get(m.name,[])),column_lineage=_merge_lineage(_flatten_lineage(m)))for m in sorted(models,key=lambda x:x.name)];parents={k:sorted([p for p in v if p in names])for(k,v)in parent_map.items()if k in names};children={k:sorted([p for p in v if p in names])for(k,v)in child_map.items()if k in names};return Graph(nodes=nodes,edges=edges,relationships=relationships,parent_map=dict(sorted(parents.items())),child_map=dict(sorted(children.items())))
def _product_config_from_environment_statements(stmts:t.List[EnvironmentStatements],*,primary_project:t.Optional[str])->t.Tuple[bool,str,str]:
	if not stmts:return c.DEFAULT_DISCOVERABLE,c.DEFAULT_VERSION,c.DEFAULT_ALIGNMENT
	want_project=primary_project or _A
	if len(stmts)==1:s=stmts[0];return s.discoverable,s.version,str(s.alignment.value)
	for s in sorted(stmts,key=lambda x:x.project or''):
		if(s.project or _A)==want_project:return s.discoverable,s.version,str(s.alignment.value)
	s=sorted(stmts,key=lambda x:x.project or'')[0];return s.discoverable,s.version,str(s.alignment.value)
def build_metadata(context:Context,*,environment:t.Optional[str]=_A)->Metadata:
	env_name=Environment.sanitize_name(environment or context.config.default_target_environment);env=context.state_sync.get_environment(env_name)
	if not env:available=[e.name for e in context.state_sync.get_environments()];raise VulcanError(f"Environment '{env_name}' was not found. Available: {', '.join(available)if available else'none'}")
	stmts=context.state_sync.get_environment_statements(env_name);discoverable,product_version,alignment=_product_config_from_environment_statements(stmts,primary_project=context.config.project or _A);snapshots_info=env.finalized_or_current_snapshots;snapshots=context.state_sync.get_snapshots(snapshots_info);fingerprint=_environment_snapshot_set_fingerprint(snapshots_info);env_naming_info=env.naming_info;deployability_index=DeployabilityIndex.create(snapshots)if env.name!=c.PROD else _A;connection_uri=''
	try:
		conn=context.config.get_connection()
		if hasattr(conn,'get_connection_uri'):connection_uri=conn.get_connection_uri()
	except Exception:pass
	mctx=MetadataContext.from_snapshots(snapshots);product=_build_product_info(context);gateway,gateways=_build_gateway_metadata(context);models=[_build_model_entry(context=context,snapshot=s,mctx=mctx,env_naming_info=env_naming_info,deployability_index=deployability_index,connection_uri=connection_uri,gateway=gateway)for s in sorted(snapshots.values(),key=lambda snap:snap.name)if s.is_model];tenant=context.config.tenant if context.config.tenant is not _A else'';graph=_build_graph(models);return Metadata(tenant=tenant,name=context.config.project,discoverable=discoverable,version=product_version,alignment=alignment,fingerprint=fingerprint,product=product,gateway=gateway,gateways=gateways,models=models,graph=graph,env=env_name)