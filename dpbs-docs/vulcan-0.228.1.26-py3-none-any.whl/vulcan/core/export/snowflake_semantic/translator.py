from __future__ import annotations
_K='one_to_one'
_J='^[A-Za-z_][A-Za-z0-9_]*$'
_I='APPROX_COUNT_DISTINCT'
_H='COUNT_DISTINCT'
_G=False
_F='COUNT'
_E='one_to_many'
_D='many_to_one'
_C='number'
_B='snowflake'
_A=None
import logging,re,typing as t
from io import StringIO
from ruamel.yaml import YAML
from sqlglot import exp,parse_one
from sqlglot.errors import ParseError
from vulcan.core.export.snowflake_semantic.definitions import SnowflakeSemanticRelationship,SnowflakeSemanticTable,SnowflakeSemanticViewDefinition
from vulcan.core.export.snowflake_semantic.loader import normalize_key
logger=logging.getLogger(__name__)
_UNSUPPORTED_WINDOW_FUNCTIONS={'RANK','DENSE_RANK','ROW_NUMBER','NTILE'}
_AGG_TYPE_BY_NAME:t.Dict[str,str]={_F:'count','SUM':'sum','AVG':'avg','MIN':'min','MAX':'max',_H:'count_distinct',_I:'count_distinct_approx'}
def _aggregate_nodes(expression:exp.Expression)->t.List[exp.AggFunc]:return list(expression.find_all(exp.AggFunc))
def _aggregate_display_name(node:exp.Expression)->str:
	if isinstance(node,exp.Anonymous):return(node.name or'').upper()or type(node).__name__.upper()
	return node.sql_name().upper()
def _measure_function_name(node:exp.Expression)->t.Optional[str]:
	if isinstance(node,exp.Count):return _H if isinstance(node.this,exp.Distinct)else _F
	if isinstance(node,exp.Sum):return'SUM'
	if isinstance(node,exp.Avg):return'AVG'
	if isinstance(node,exp.Min):return'MIN'
	if isinstance(node,exp.Max):return'MAX'
	if isinstance(node,exp.Anonymous):
		name=(node.name or'').upper()
		if name==_I:return name
def _measure_type_and_sql(expr:str)->t.Tuple[t.Optional[str],t.Optional[str],t.Optional[str]]:
	raw_expr=(expr or'').strip()
	if not raw_expr:return _A,_A,'Metric expression is empty.'
	try:expression=parse_one(raw_expr,dialect=_B)
	except ParseError as exc:return _A,_A,f"Metric expression '{raw_expr}' could not be parsed: {exc}."
	if expression.find(exp.Window):return _A,_A,f"Metric expression '{raw_expr}' uses window functions and is not supported."
	unsupported=[func.sql_name().upper()for func in expression.find_all(exp.Func)if func.sql_name().upper()in _UNSUPPORTED_WINDOW_FUNCTIONS]
	if unsupported:return _A,_A,f"Metric expression '{raw_expr}' uses unsupported ranking functions: {', '.join(sorted(set(unsupported)))}."
	agg_nodes=_aggregate_nodes(expression);unsupported_aggregates=[_aggregate_display_name(node)for node in agg_nodes if _measure_function_name(node)is _A]
	if unsupported_aggregates:return _A,_A,f"Metric expression '{raw_expr}' uses unsupported aggregate functions: {', '.join(sorted(set(unsupported_aggregates)))}."
	if not agg_nodes:return _C,expression.sql(dialect=_B),_A
	nested_aggregates=[node for node in agg_nodes if any(descendant is not node and _measure_function_name(descendant)for descendant in node.find_all(exp.AggFunc))]
	if nested_aggregates:return _A,_A,f"Metric expression '{raw_expr}' uses nested aggregates and requires staged modeling."
	if len(agg_nodes)==1 and agg_nodes[0]is expression:
		agg_name=_measure_function_name(expression)
		if agg_name is _A:return _C,expression.sql(dialect=_B),_A
		raw_inner=expression.this if hasattr(expression,'this')else _A
		if isinstance(raw_inner,exp.Distinct):inner=raw_inner.expressions[0]if raw_inner.expressions else _A
		else:inner=raw_inner
		inner_sql=inner.sql(dialect=_B)if inner is not _A else'1'
		if agg_name==_F and inner_sql=='*':inner_sql='1'
		return _AGG_TYPE_BY_NAME[agg_name],inner_sql or'1',_A
	return _C,expression.sql(dialect=_B),_A
def _strip_table_alias_prefix(sql:str)->str:return re.sub('\\b[A-Za-z_][A-Za-z0-9_]*\\.','',sql or'')
def _qualify_expression(inner_sql:str,table_name:str)->str:
	stripped=inner_sql.strip()
	if not stripped or stripped in('1','*'):return stripped
	if re.match(_J,stripped):return f"{{{table_name}.{stripped}}}"
	try:tree=parse_one(stripped,dialect=_B)
	except ParseError:return f"{{{table_name}.{stripped}}}"
	col_names:t.Set[str]=set()
	for col in tree.find_all(exp.Column):
		if not col.args.get('table'):col_names.add(col.name)
	if not col_names:return stripped
	result=stripped
	for col in sorted(col_names,key=len,reverse=True):result=re.sub(rf"(?<![{{.A-Za-z0-9_])\b{re.escape(col)}\b(?!\s*[\(.])",f"{{{table_name}.{col}}}",result)
	return result
def _normalize_expr(expr:str)->str:return re.sub('\\s+','',expr or'').lower()
def _infer_join_relationship(relationship:SnowflakeSemanticRelationship,tables_by_name:t.Dict[str,SnowflakeSemanticTable])->str:
	A='unique'
	if relationship.relationship_type:return relationship.relationship_type.lower()
	left_table=tables_by_name.get(relationship.left_table);right_table=tables_by_name.get(relationship.right_table)
	if left_table is _A or right_table is _A:return _D
	left_unique_exprs={_normalize_expr(member.expr)for member in[*left_table.dimensions,*left_table.time_dimensions]if getattr(member,A,_G)};right_unique_exprs={_normalize_expr(member.expr)for member in[*right_table.dimensions,*right_table.time_dimensions]if getattr(member,A,_G)};left_cols={_normalize_expr(col.left_column)for col in relationship.relationship_columns};right_cols={_normalize_expr(col.right_column)for col in relationship.relationship_columns};left_unique=bool(left_cols)and left_cols.issubset(left_unique_exprs);right_unique=bool(right_cols)and right_cols.issubset(right_unique_exprs)
	if left_unique and right_unique:return _K
	if right_unique:return _D
	if left_unique:return _E
	return _D
def _sanitize_ident(value:str)->str:A='_';ident=re.sub('[^A-Za-z0-9_]+',A,value.strip());ident=re.sub('_+',A,ident).strip(A)or'member';return f"_{ident}"if ident[0].isdigit()else ident
def _join_sql(source_table:str,target_table:str,columns:t.Iterable[t.Tuple[str,str]])->str:src=_sanitize_ident(source_table);tgt=_sanitize_ident(target_table);return' AND '.join(f"{{{src}.{_sanitize_ident(left)}}} = {{{tgt}.{_sanitize_ident(right)}}}"for(left,right)in columns)
def _extract_column_refs(sql:str)->t.Set[str]:
	stripped=(sql or'').strip()
	if not stripped or stripped in('1','*'):return set()
	if re.match(_J,stripped):return{stripped}
	try:tree=parse_one(stripped,dialect=_B)
	except ParseError:return set()
	return{col.name for col in tree.find_all(exp.Column)if not col.args.get('table')}
def build_semantic_model_yaml(table:SnowflakeSemanticTable,definition:SnowflakeSemanticViewDefinition)->t.Dict[str,t.Any]:
	D='expression';C='type';B='description';A='name';data:t.Dict[str,t.Any]={'kind':'semantic',A:table.name,'depends_on':table.base_table.qualified_name}
	if table.description:data[B]=table.description
	pk_columns:t.Set[str]=set()
	if table.primary_key and table.primary_key.columns:pk_columns={c.lower()for c in table.primary_key.columns}
	elif any(normalize_key(rel.left_table)==normalize_key(table.name)or normalize_key(rel.right_table)==normalize_key(table.name)for rel in definition.relationships):logger.warning("Table '%s' has joins but no primary_key is defined in the Snowflake semantic view. Add a dimension with behavior: {type: identifier} manually to avoid transpiler errors.",table.name)
	regular_facts=[f for f in table.facts if not f.is_filter];regular_dims=[d for d in table.dimensions if not d.is_filter];all_dims=[*regular_dims,*table.time_dimensions,*regular_facts];declared_dim_names:t.Set[str]={m.name.lower()for m in all_dims};dim_entries:t.List[t.Any]=[]
	for member in all_dims:
		is_pk=member.name.lower()in pk_columns
		if is_pk or member.description:
			entry:t.Dict[str,t.Any]={A:member.name}
			if member.description:entry[B]=member.description
			if is_pk:entry['behavior']={C:'identifier'}
			dim_entries.append(entry)
		else:dim_entries.append(member.name)
	measure_referenced_cols:t.Set[str]=set()
	if table.metrics:
		measure_entries:t.List[t.Dict[str,t.Any]]=[]
		for metric in table.metrics:
			sem_type,inner_sql,err=_measure_type_and_sql(metric.expr or'')
			if err:logger.warning("Skipping metric '%s' on table '%s': %s",metric.name,table.name,err);continue
			entry={A:metric.name,C:sem_type or _C}
			if inner_sql and inner_sql not in('1','*'):bare_sql=_strip_table_alias_prefix(inner_sql);entry[D]=_qualify_expression(bare_sql,table.name);measure_referenced_cols.update(_extract_column_refs(bare_sql))
			if metric.description:entry[B]=metric.description
			measure_entries.append(entry)
		if measure_entries:data['measures']=measure_entries
	all_filters=[*[f for f in table.facts if f.is_filter],*[d for d in table.dimensions if d.is_filter]]
	if all_filters:
		segment_entries:t.List[t.Dict[str,t.Any]]=[]
		for f in all_filters:
			bare_expr=_strip_table_alias_prefix(f.expr or'');qualified_expr=_qualify_expression(bare_expr,table.name);seg:t.Dict[str,t.Any]={A:f.name,D:qualified_expr}
			if f.description:seg[B]=f.description
			segment_entries.append(seg)
		data['segments']=segment_entries
	tables_by_name={t_obj.name:t_obj for t_obj in definition.tables};join_entries:t.List[t.Dict[str,t.Any]]=[];join_key_cols:t.Set[str]=set()
	for rel in definition.relationships:
		left=rel.left_table;right=rel.right_table;inferred=_infer_join_relationship(rel,tables_by_name);col_pairs=[(c.left_column,c.right_column)for c in rel.relationship_columns]
		if inferred==_D:one_side,many_side=right,left;declared_type=_E;expr_pairs=[(rc,lc)for(lc,rc)in col_pairs];many_own_cols=[lc for(lc,_)in col_pairs];one_own_cols=[rc for(_,rc)in col_pairs]
		elif inferred==_E:one_side,many_side=left,right;declared_type=_E;expr_pairs=col_pairs;one_own_cols=[lc for(lc,_)in col_pairs];many_own_cols=[rc for(_,rc)in col_pairs]
		else:one_side,many_side=left,right;declared_type=_K;expr_pairs=col_pairs;one_own_cols=[lc for(lc,_)in col_pairs];many_own_cols=[rc for(_,rc)in col_pairs]
		if normalize_key(one_side)==normalize_key(table.name):join_entries.append({A:many_side,C:declared_type,D:_join_sql(one_side,many_side,expr_pairs)});join_key_cols.update(one_own_cols)
		elif normalize_key(many_side)==normalize_key(table.name):join_key_cols.update(many_own_cols)
	if join_entries:data['joins']=join_entries
	needed_cols=measure_referenced_cols|join_key_cols
	for col in sorted(needed_cols):
		if col.lower()not in declared_dim_names:logger.debug("Auto-adding dimension '%s' to table '%s' (referenced in measure/join but not declared as a dimension).",col,table.name);dim_entries.append(col);declared_dim_names.add(col.lower())
	if dim_entries:data['dimensions']=dim_entries
	return data
def semantic_yaml_dumps(data:t.Dict[str,t.Any])->str:yaml=YAML();yaml.default_flow_style=_G;yaml.allow_unicode=True;yaml.width=10000;buf=StringIO();yaml.dump(data,buf);return buf.getvalue()