from __future__ import annotations
_B='Context'
_A='name'
import logging,re,typing as t,pandas as pd
from vulcan.core.export.snowflake_semantic.loader import _yaml_loader
from vulcan.utils.errors import ConfigError
if t.TYPE_CHECKING:from vulcan.core.context import Context
logger=logging.getLogger(__name__)
_QUALIFIED_VIEW_NAME_RE=re.compile('[A-Za-z0-9_]+(?:\\.[A-Za-z0-9_]+){0,2}')
def _validate_qualified_view_name(qualified_view_name:str)->str:
	candidate=(qualified_view_name or'').strip()
	if not _QUALIFIED_VIEW_NAME_RE.fullmatch(candidate):raise ConfigError(f"Snowflake semantic view name must be an unquoted one- to three-part identifier containing only letters, numbers, underscores, and dots: '{qualified_view_name}'.")
	return candidate
def fetch_semantic_view_yaml(context:_B,*,connection_name:str,qualified_view_name:str)->t.Dict[str,t.Any]:
	qualified_view_name=_validate_qualified_view_name(qualified_view_name);connection=context.config.get_connection(connection_name);dialect=getattr(connection,'DIALECT',None)
	if dialect!='snowflake':raise ConfigError(f"Gateway '{connection_name}' is not a Snowflake connection (dialect={dialect}).")
	adapter=context._get_engine_adapter(connection_name);escaped_name=qualified_view_name.replace("'","''");sql=f"SELECT SYSTEM$READ_YAML_FROM_SEMANTIC_VIEW('{escaped_name}') AS yaml";df=adapter.fetchdf(sql)
	if df.empty:raise ConfigError(f"Snowflake semantic view '{qualified_view_name}' returned no YAML definition.")
	raw_yaml=df.iloc[0,0]
	if not raw_yaml:raise ConfigError(f"Snowflake semantic view '{qualified_view_name}' returned an empty YAML definition.")
	parsed=_yaml_loader().load(str(raw_yaml))
	if not isinstance(parsed,dict):raise ConfigError(f"Snowflake semantic view '{qualified_view_name}' returned an invalid YAML payload.")
	return parsed
def _row_value(row:t.Dict[str,t.Any],*keys:str)->t.Any:
	for key in keys:
		if key in row:return row[key]
		for k in row:
			if k.lower()==key.lower():return row[k]
def _coerce_required_flag(value:t.Any)->bool:
	A=False
	if isinstance(value,bool):return value
	if isinstance(value,(int,float)):return bool(value)
	if isinstance(value,str):
		normalized=value.strip().lower()
		if normalized in{'true','t','yes','y','1'}:return True
		if normalized in{'false','f','no','n','0','','null','none','nan'}:return A
	try:
		if pd.isna(value):return A
	except Exception:pass
	return A
def _metric_names_from_definition_data(definition_data:t.Dict[str,t.Any])->t.List[str]:
	A='metrics';metric_names:t.List[str]=[]
	for table in definition_data.get('tables',[])or[]:
		for metric in table.get(A,[])or[]:
			name=metric.get(_A)
			if name:metric_names.append(str(name))
	for metric in definition_data.get(A,[])or[]:
		name=metric.get(_A)
		if name:metric_names.append(str(name))
	return list(dict.fromkeys(metric_names))
def fetch_metric_dimension_contracts(context:_B,*,connection_name:str,qualified_view_name:str,definition_data:t.Dict[str,t.Any])->t.Dict[str,t.List[t.Dict[str,t.Any]]]:
	B='synonyms';A='required';qualified_view_name=_validate_qualified_view_name(qualified_view_name);adapter=context._get_engine_adapter(connection_name);contracts:t.Dict[str,t.List[t.Dict[str,t.Any]]]={}
	for metric_name in _metric_names_from_definition_data(definition_data):
		escaped_metric=metric_name.replace('"','""');sql=f'SHOW SEMANTIC DIMENSIONS IN {qualified_view_name} FOR METRIC "{escaped_metric}"'
		try:df=adapter.fetchdf(sql)
		except Exception:logger.warning("Failed to fetch semantic dimension contracts for '%s'. Metric contract enrichment will be skipped.",qualified_view_name,exc_info=True);return contracts
		if not isinstance(df,pd.DataFrame)or df.empty:continue
		rows:t.List[t.Dict[str,t.Any]]=[]
		for row in df.to_dict(orient='records'):
			table_name=_row_value(row,'table_name');dimension_name=_row_value(row,_A)
			if not table_name or not dimension_name:continue
			rows.append({'table':str(table_name),_A:str(dimension_name),A:_coerce_required_flag(_row_value(row,A)),B:_row_value(row,B)or[],'description':_row_value(row,'comment')})
		if rows:contracts[metric_name]=rows
	return contracts