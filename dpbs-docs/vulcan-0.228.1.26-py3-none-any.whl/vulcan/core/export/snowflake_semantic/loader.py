from __future__ import annotations
_F='imported'
_E='snowflake_semantic'
_D='metric_dimension_contracts'
_C='_vulcan'
_B='Context'
_A=None
import re,typing as t
from pathlib import Path
from ruamel.yaml import YAML
from vulcan.core.export.snowflake_semantic.definitions import SnowflakeSemanticSource,SnowflakeSemanticViewDefinition
from vulcan.utils.errors import ConfigError,VulcanError
from vulcan.utils.yaml import load as yaml_load
DEFAULT_MODEL_BASE=Path('models')/_E
if t.TYPE_CHECKING:from vulcan.core.context import Context
def normalize_key(value:str)->str:return value.strip().lower()
def sanitize_filename(value:str)->str:sanitized=re.sub('[^A-Za-z0-9_.-]+','_',value.strip());return sanitized or _E
def project_root(context:_B)->Path:
	root=getattr(context,'path',_A)
	if root:return Path(root)
	config_paths=getattr(context,'config_paths',_A)
	if config_paths:return Path(next(iter(config_paths)))
	raise VulcanError('Unable to determine Vulcan project root for Snowflake semantic views.')
def _yaml_loader()->YAML:yaml=YAML(typ='safe');yaml.default_flow_style=False;return yaml
def load_definition_from_data(data:t.Dict[str,t.Any],*,source:SnowflakeSemanticSource,connection_name:t.Optional[str]=_A,qualified_source_name:t.Optional[str]=_A,source_path:t.Optional[str]=_A)->SnowflakeSemanticViewDefinition:
	normalized=dict(data);vulcan_meta=normalized.pop(_C,{})if isinstance(normalized.get(_C),dict)else{}
	for key in('source','connection_name','qualified_source_name','raw_yaml','source_path'):normalized.pop(key,_A)
	metric_dimension_contracts=normalized.pop(_D,_A)or vulcan_meta.get(_D);return SnowflakeSemanticViewDefinition(**normalized,source=source,connection_name=connection_name,qualified_source_name=qualified_source_name,metric_dimension_contracts=metric_dimension_contracts or{},raw_yaml=data,source_path=source_path)
def _load_definition_from_path(path:Path,*,source:SnowflakeSemanticSource)->SnowflakeSemanticViewDefinition:
	data=yaml_load(path,render_jinja=True)
	if not isinstance(data,dict):raise ConfigError(f"Snowflake semantic view file '{path}' must contain a YAML object.")
	return load_definition_from_data(data,source=source,source_path=str(path))
def _definitions_dir(context:_B,source:SnowflakeSemanticSource)->Path:return project_root(context)/'semantics'/'snowflake_semantic_views'/source
def resolve_definition(context:_B,view_name:str)->SnowflakeSemanticViewDefinition:
	matches:t.List[SnowflakeSemanticViewDefinition]=[];matched_sources:t.List[SnowflakeSemanticSource]=[]
	for source in(_F,'managed'):
		root=_definitions_dir(context,t.cast(SnowflakeSemanticSource,source))
		if not root.exists():continue
		normalized_target=normalize_key(view_name)
		for ext in('*.yml','*.yaml'):
			for path in sorted(root.rglob(ext)):
				try:definition=_load_definition_from_path(path,source=t.cast(SnowflakeSemanticSource,source))
				except Exception:continue
				if normalize_key(definition.name)==normalized_target:matches.append(definition);matched_sources.append(t.cast(SnowflakeSemanticSource,source));break
	if not matches:raise ConfigError(f"Snowflake semantic view '{view_name}' not found in imported or managed sources.")
	if len(matches)>1:sources=', '.join(matched_sources);raise ConfigError(f"Snowflake semantic view '{view_name}' exists in multiple sources ({sources}). Use --connection to fetch from Snowflake directly.")
	return matches[0]
def fetch_definition(context:_B,view_name:str,connection:t.Optional[str]=_A)->SnowflakeSemanticViewDefinition:
	if connection:
		from vulcan.core.export.snowflake_semantic.importer import fetch_metric_dimension_contracts,fetch_semantic_view_yaml;raw_yaml=fetch_semantic_view_yaml(context,connection_name=connection,qualified_view_name=view_name);contracts=fetch_metric_dimension_contracts(context,connection_name=connection,qualified_view_name=view_name,definition_data=raw_yaml)
		if contracts:payload:t.Dict[str,t.Any]=dict(raw_yaml);vulcan_meta=dict(payload.get(_C)or{});vulcan_meta[_D]=contracts;payload[_C]=vulcan_meta;raw_yaml=payload
		return load_definition_from_data(raw_yaml,source=_F,connection_name=connection,qualified_source_name=view_name)
	return resolve_definition(context,view_name)
def write_model_files(definition:SnowflakeSemanticViewDefinition,root:Path,output_dir:t.Optional[str]=_A)->t.List[Path]:
	from vulcan.core.export.snowflake_semantic.translator import build_semantic_model_yaml,semantic_yaml_dumps;view_folder=definition.name.split('.')[-1];base_dir=Path(output_dir).expanduser()if output_dir else root/DEFAULT_MODEL_BASE;out_dir=base_dir/view_folder;out_dir.mkdir(parents=True,exist_ok=True);written:t.List[Path]=[]
	for table in definition.tables:yaml_data=build_semantic_model_yaml(table,definition);file_path=out_dir/f"{table.name}.yml";file_path.write_text(semantic_yaml_dumps(yaml_data),encoding='utf-8');written.append(file_path)
	return written