from __future__ import annotations
_G='filter'
_F='schema'
_E='managed'
_D=False
_C='ignore'
_B='extra'
_A=None
import typing as t
from pydantic import AliasChoices,Field,model_validator
from vulcan.utils.pydantic import PydanticModel
SnowflakeSemanticSource=t.Literal[_E,'imported']
class SnowflakeSemanticBaseTable(PydanticModel):
	database:str;schema_name:str=Field(validation_alias=AliasChoices(_F,'schema_name'),serialization_alias=_F);table:str;model_config={_B:_C,'populate_by_name':True}
	@property
	def qualified_name(self)->str:return f"{self.database}.{self.schema_name}.{self.table}"
class SnowflakeSemanticNonAdditiveDimension(PydanticModel):table:str;dimension:str;sort_direction:t.Optional[str]=_A;null_order:t.Optional[str]=_A;model_config={_B:_C}
class SnowflakeSemanticBaseMember(PydanticModel):
	name:str;expr:str;data_type:t.Optional[str]=_A;description:t.Optional[str]=_A;synonyms:t.List[str]=Field(default_factory=list);access_modifier:str='public_access';model_config={_B:_C}
	@property
	def public(self)->bool:return self.access_modifier!='private_access'
class SnowflakeSemanticDimension(SnowflakeSemanticBaseMember):
	unique:bool=_D;is_enum:bool=_D;labels:t.List[str]=Field(default_factory=list);model_config={_B:_C}
	@property
	def is_filter(self)->bool:return _G in[l.lower()for l in self.labels]
class SnowflakeSemanticMetric(SnowflakeSemanticBaseMember):non_additive_dimensions:t.List[SnowflakeSemanticNonAdditiveDimension]=Field(default_factory=list);using_relationships:t.List[str]=Field(default_factory=list);model_config={_B:_C}
class SnowflakeSemanticFact(SnowflakeSemanticBaseMember):
	labels:t.List[str]=Field(default_factory=list);model_config={_B:_C}
	@property
	def is_filter(self)->bool:return _G in[l.lower()for l in self.labels]
class SnowflakeSemanticRelationshipColumn(PydanticModel):left_column:str;right_column:str;model_config={_B:_C}
class SnowflakeSemanticRelationship(PydanticModel):name:str;left_table:str;right_table:str;relationship_columns:t.List[SnowflakeSemanticRelationshipColumn];relationship_type:t.Optional[str]=_A;join_type:t.Optional[str]=_A;model_config={_B:_C}
class SnowflakeSemanticPrimaryKey(PydanticModel):columns:t.List[str]=Field(default_factory=list);model_config={_B:_C}
class SnowflakeSemanticTable(PydanticModel):name:str;description:t.Optional[str]=_A;base_table:SnowflakeSemanticBaseTable;primary_key:t.Optional[SnowflakeSemanticPrimaryKey]=_A;dimensions:t.List[SnowflakeSemanticDimension]=Field(default_factory=list);time_dimensions:t.List[SnowflakeSemanticDimension]=Field(default_factory=list);facts:t.List[SnowflakeSemanticFact]=Field(default_factory=list);metrics:t.List[SnowflakeSemanticMetric]=Field(default_factory=list);model_config={_B:_C}
class SnowflakeSemanticMetricDimensionContract(PydanticModel):table:str;name:str;required:bool=_D;synonyms:t.List[str]=Field(default_factory=list);description:t.Optional[str]=_A;model_config={_B:_C}
class SnowflakeSemanticViewDefinition(PydanticModel):
	name:str;description:t.Optional[str]=_A;tables:t.List[SnowflakeSemanticTable]=Field(default_factory=list);relationships:t.List[SnowflakeSemanticRelationship]=Field(default_factory=list);metrics:t.List[SnowflakeSemanticMetric]=Field(default_factory=list);source:SnowflakeSemanticSource=_E;connection_name:t.Optional[str]=_A;qualified_source_name:t.Optional[str]=_A;metric_dimension_contracts:t.Dict[str,t.List[SnowflakeSemanticMetricDimensionContract]]=Field(default_factory=dict);compatibility_errors:t.List[str]=Field(default_factory=list);raw_yaml:t.Optional[t.Dict[str,t.Any]]=_A;source_path:t.Optional[str]=_A;model_config={_B:_C}
	@model_validator(mode='before')
	@classmethod
	def _normalize_legacy_tables_key(cls,data:t.Any)->t.Any:
		B='tables';A='entities'
		if isinstance(data,dict)and A in data and B not in data:normalized=dict(data);normalized[B]=normalized.pop(A);return normalized
		return data