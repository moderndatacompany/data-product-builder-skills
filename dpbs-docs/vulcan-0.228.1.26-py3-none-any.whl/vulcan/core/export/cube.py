from __future__ import annotations
_F='segment'
_E='measure'
_D='dimension'
_C='postgres'
_B='SEMANTIC'
_A=None
import typing as t
from collections import defaultdict,deque
from sqlglot import ParseError,parse_one
from sqlglot import expressions as exp
from vulcan.core.model.definition import _METRIC_COL_MEASURE,_METRIC_COL_TS
from vulcan.core.model.semantic import LogicalTypeValue
from vulcan.utils.dag import DAG
from schema.cube import Cube,CubeAccessPolicyEntry,CubeDimension,CubeJoin,CubeMaskValue,CubeMemberLevelExcludes,CubeMemberLevelIncludesAll,CubeMemberLevelIncludesNone,CubeMemberMaskingIncludes,CubeMemberMaskingIncludesAll,CubeMeasure,CubeRef,CubeRowLevelAllowAll,CubeRowLevelFilters,CubeSchema,CubeSegment,CubeSqlMask,Include,View
from schema.filters import PolicyEntry
from schema.metadata import ColumnEntry,DimensionDetails,MaskExpression,MeasureDetails,Metadata,ModelEntry,SegmentDetails,Table
class Graph:
	__slots__='_dag',
	def __init__(self,dag:DAG[str])->_A:self._dag=dag
	@classmethod
	def from_metadata(cls,metadata:Metadata)->Graph:
		semantics_by_name:t.Dict[str,ModelEntry]={m.name:m for m in metadata.models if m.kind==_B};known=frozenset(semantics_by_name);dag:DAG[str]=DAG[str]()
		for(name,sem)in semantics_by_name.items():dag.add(name,[j.model for j in sem.joins if j.model in known])
		return cls(dag)
	def _semantic_join_adjacency(self)->t.Mapping[str,t.AbstractSet[str]]:
		adj:t.Dict[str,t.Set[str]]=defaultdict(set)
		for(declarer,targets)in self._dag.graph.items():
			for tgt in targets:adj[declarer].add(tgt);adj[tgt].add(declarer)
		return adj
	def join_path(self,start:str,end:str)->t.Optional[str]:
		if start==end:return start
		adj=self._semantic_join_adjacency();queue:t.Deque[str]=deque([start]);visited:t.Set[str]={start};parent:t.Dict[str,str]={}
		while queue:
			curr=queue.popleft()
			if curr==end:break
			for nb in sorted(adj.get(curr,())):
				if nb not in visited:visited.add(nb);parent[nb]=curr;queue.append(nb)
		else:return
		path:t.List[str]=[];at=end
		while True:
			path.append(at)
			if at==start:break
			pn=parent.get(at)
			if pn is _A:return
			at=pn
		path.reverse();return'.'.join(path)
def _mask(mask_expression:MaskExpression|_A,*,dialect:str=_C)->CubeMaskValue|_A:
	if mask_expression is _A:return
	if not isinstance(mask_expression,str):return mask_expression
	expression=mask_expression.strip()
	try:parsed=parse_one(expression,dialect=dialect)
	except ParseError:return mask_expression
	is_scalar_sql_literal=isinstance(parsed,(exp.Literal,exp.Null,exp.Boolean))or isinstance(parsed,exp.Neg)and isinstance(parsed.this,(exp.Literal,exp.Null,exp.Boolean))
	if is_scalar_sql_literal:return mask_expression
	return CubeSqlMask(sql=mask_expression)
def _access_policy(policy:PolicyEntry)->CubeAccessPolicyEntry:
	A='*'
	if policy.filter:row_level=CubeRowLevelFilters(filters=list(policy.filter))
	else:row_level=CubeRowLevelAllowAll(allow_all=True)
	member_masking:CubeMemberMaskingIncludesAll|CubeMemberMaskingIncludes|_A
	if policy.mask==A:member_level=CubeMemberLevelIncludesNone(includes=[]);member_masking=CubeMemberMaskingIncludesAll(includes=A)
	elif policy.mask:member_level=CubeMemberLevelExcludes(excludes=list(policy.mask));member_masking=CubeMemberMaskingIncludes(includes=list(policy.mask))
	else:member_level=CubeMemberLevelIncludesAll(includes=A);member_masking=_A
	return CubeAccessPolicyEntry(group=policy.group,row_level=row_level,member_level=member_level,member_masking=member_masking)
def _measure(col:ColumnEntry,*,semantic_name:str)->CubeMeasure:assert isinstance(col.details,MeasureDetails);m=col.details;return CubeMeasure(name=col.name,type=m.agg_type,sql=m.expression or _A,filters=[{'sql':f"({expr})"}for expr in m.filters or[]],rolling_window=m.rolling_window,public=col.public)
def _dimension(col:ColumnEntry,*,dialect:str)->CubeDimension:assert isinstance(col.details,DimensionDetails);d=col.details;sem_type:LogicalTypeValue=col.ltype;time_fmt=str(d.time_format)if d.time_format and sem_type=='time'else _A;granularities=sorted([g.model_copy(update={'ai_context':_A,'description':_A})for g in d.time_granularities],key=lambda x:x.name)if d.time_granularities else _A;return CubeDimension(name=col.name,sql=col.name,type=sem_type,primary_key=col.primary_key,public=col.public,format=time_fmt,granularities=granularities,mask=_mask(d.mask_expression,dialect=dialect))
def _sql_table(table:t.Optional[Table])->str:
	assert table is not _A;phys=table.physical.name
	if table.virtual is not _A and table.virtual.name!=phys:return table.virtual.name
	return phys
def _cube(sem:ModelEntry,physical:ModelEntry)->Cube:assert physical.table is not _A;sql_tbl=_sql_table(physical.table);dim_cols=sorted((x for x in sem.columns if x.kind==_D),key=lambda x:x.name);dimensions=[_dimension(c,dialect=sem.dialect or _C)for c in dim_cols];measures=[_measure(c,semantic_name=sem.name)for c in sorted((x for x in sem.columns if x.kind==_E),key=lambda x:x.name)];segments=[CubeSegment(name=c.name,sql=t.cast(SegmentDetails,c.details).expression or'',public=c.public)for c in sorted((x for x in sem.columns if x.kind==_F),key=lambda x:x.name)];joins=[CubeJoin(name=j.model,relationship=j.relationship,sql=j.expression)for j in sorted(sem.joins,key=lambda x:x.model)];access_policy=[_access_policy(p)for p in sem.policies]if sem.policies else _A;return Cube(name=sem.name,sql_table=sql_tbl,measures=measures,dimensions=dimensions,segments=segments,joins=joins,access_policy=access_policy)
def _build_cubes(metadata:Metadata)->t.List[Cube]:
	by_name={m.name:m for m in metadata.models};semantics=[m for m in metadata.models if m.kind==_B];cubes:t.List[Cube]=[]
	for sem in sorted(semantics,key=lambda m:m.name):
		if not sem.depends_on:continue
		physical=by_name.get(sem.depends_on[0])
		if physical is _A or physical.table is _A:continue
		cubes.append(_cube(sem,physical))
	return cubes
def _metric_field_triples(metric_entry:ModelEntry)->t.Iterator[t.Tuple[str,str,str]]:
	measure_column=next((column for column in metric_entry.columns if column.name==_METRIC_COL_MEASURE),_A);ts_column=next((column for column in metric_entry.columns if column.name==_METRIC_COL_TS),_A)
	if measure_column is _A or ts_column is _A or not measure_column.depends_on or not ts_column.depends_on or not measure_column.depends_on[0].model or not ts_column.depends_on[0].model:return
	yield(measure_column.depends_on[0].model,measure_column.depends_on[0].column or'',_E);yield(ts_column.depends_on[0].model,ts_column.depends_on[0].column or'','ts')
	for dimension_column in sorted((column for column in metric_entry.columns if column.kind==_D and column.name not in(_METRIC_COL_MEASURE,_METRIC_COL_TS)),key=lambda column:column.name):
		if not dimension_column.depends_on:continue
		yield(dimension_column.depends_on[0].model,dimension_column.depends_on[0].column or'',dimension_column.name)
	for segment_column in sorted((column for column in metric_entry.columns if column.kind==_F),key=lambda column:column.name):
		if not segment_column.depends_on:continue
		yield(segment_column.depends_on[0].model,segment_column.depends_on[0].column or'',segment_column.name)
def _view(metric_entry:ModelEntry,graph:Graph)->View:
	measure_column=next((column for column in metric_entry.columns if column.name==_METRIC_COL_MEASURE),_A);column_triples=tuple(_metric_field_triples(metric_entry))
	if measure_column is _A or not column_triples or not measure_column.depends_on:return View(name=metric_entry.name,cubes=[])
	primary_model_name=measure_column.depends_on[0].model;columns_by_cube:t.DefaultDict[str,t.Dict[str,str]]=defaultdict(dict)
	for(cube_name,column_name,alias)in column_triples:
		column_aliases=columns_by_cube[cube_name]
		if column_name not in column_aliases:column_aliases[column_name]=alias
	cube_refs:t.List[CubeRef]=[]
	for(cube_name,column_aliases)in columns_by_cube.items():join_path=graph.join_path(primary_model_name,cube_name)or f"{primary_model_name}.{cube_name}";includes:t.List[t.Union[str,Include]]=[source_column if column_aliases[source_column]==source_column else Include(name=source_column,alias=column_aliases[source_column])for source_column in sorted(column_aliases)];cube_refs.append(CubeRef(join_path=join_path,includes=includes))
	return View(name=metric_entry.name,cubes=cube_refs)
def _build_views(metadata:Metadata)->t.List[View]:
	metrics=[m for m in metadata.models if m.kind=='METRIC']
	if not metrics:return[]
	graph=Graph.from_metadata(metadata);return[_view(metric_entry,graph)for metric_entry in sorted(metrics,key=lambda metric:metric.name)]
def build_cube_schema(metadata:Metadata)->CubeSchema:
	cubes=_build_cubes(metadata)
	if not cubes:return CubeSchema(cubes=[],views=[])
	views=_build_views(metadata);return CubeSchema(cubes=cubes,views=views)