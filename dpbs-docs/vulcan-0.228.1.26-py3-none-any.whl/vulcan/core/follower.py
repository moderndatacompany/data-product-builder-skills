from __future__ import annotations
_A=None
import typing as t
from enum import Enum
from pydantic import Field
from vulcan.utils.pydantic import PydanticModel
class FollowerGranularity(str,Enum):DAY='day';WEEK='week';MONTH='month'
class Follower(PydanticModel):user_id:str;active:bool;followed_at:int;updated_at:int;metadata:t.Dict[str,t.Any]=Field(default_factory=dict)
class FollowerAnalyticsPeriod(PydanticModel):period_start:int;period_end:int;active_followers:int
class FollowerAnalyticsPagination(PydanticModel):offset:int;limit:int;has_more:bool=True
class FollowerAnalytics(PydanticModel):total_active:int;granularity:t.Optional[FollowerGranularity]=_A;offset:t.Optional[int]=_A;limit:t.Optional[int]=_A;series:t.Optional[t.List[FollowerAnalyticsPeriod]]=_A;pagination:t.Optional[FollowerAnalyticsPagination]=_A