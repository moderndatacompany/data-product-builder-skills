from __future__ import annotations
_A1='ModelExec'
_A0='non_model'
_z='reason'
_y='migration_duration'
_x='backfill_duration'
_w='dq_scan_duration'
_v='run_duration'
_u='plan_duration'
_t='environment'
_s='plan'
_r='skipped'
_q='state_sync_type'
_p='migration_total'
_o='backfill_intervals_total'
_n='backfill_total'
_m='virtual_update_total'
_l='plan_snapshots_created'
_k='environments_active'
_j='snapshots_active'
_i='audit_results_total'
_h='dq_checks_total'
_g='dq_scan_models'
_f='dq_scan_total'
_e='run_intervals_processed'
_d='run_models_backfilled'
_c='run_models_affected'
_b='run_failure_total'
_a='run_total'
_Z='plan_models_affected'
_Y='plan_models_changed'
_X='plan_model_changes_total'
_W='plan_total'
_V='user_name'
_U='instance_name'
_T='resource_type'
_S='resource_id'
_R='dataos_fqdn'
_Q='dataplane_type'
_P='dataplane_network_type'
_O='dataplane_name'
_N='version'
_M='data_product'
_L='tenant'
_K='warned'
_J='passed'
_I='unknown'
_H='result'
_G='backfill_active'
_F='restatement'
_E='kind'
_D='success'
_C='status'
_B='failed'
_A=None
import logging,typing as t
from prometheus_client import CollectorRegistry,Counter,Gauge,Histogram
logger=logging.getLogger(__name__)
if t.TYPE_CHECKING:from vulcan.core.activity import ErrorExec,ModelExec,PlanActivity;from vulcan.core.model.definition import AuditResult;from vulcan.core.plan.definition import EvaluatablePlan,Plan;from vulcan.core.plan.stages import BackfillStage;from vulcan.core.prometheus.pushgateway import PushgatewayCounterCache;from vulcan.core.soda3.spec import CheckExecutionSummary;from vulcan.core.snapshot.definition import Snapshot;from vulcan.utils import CompletionStatus
BackfillStatusLabel=t.Literal[_D,_B]
MigrationStatusLabel=t.Literal[_D,_B]
_DURATION_BUCKETS:t.Tuple[float,...]=(1,5,15,30,60,120,300,600,1200,1800,3600)
_COUNT_BUCKETS:t.Tuple[float,...]=(1,2,5,10,20,50,100,200,500)
_ENV_LABELS:t.Tuple[str,...]=(_L,_M,_N,_O,_P,_Q,_R,_S,_T,_U,_V,_t)
_BASE_LABELS:t.Tuple[str,...]=(_L,_M,_N,_O,_P,_Q,_R,_S,_T,_U,_V)
class CorePromRegistry:
	METRIC_PREFIX='vulcan_'
	@classmethod
	def _metric_name(cls,suffix:str)->str:return f"{cls.METRIC_PREFIX}{suffix}"
	def __init__(self,*,tenant:str,data_product:str,version:str,counter_cache:'PushgatewayCounterCache',dataplane_name:str='',dataplane_network_type:str='',dataplane_type:str='',dataos_fqdn:str='',resource_id:str='',resource_type:str='',instance_name:str='',user_name:str='')->_A:self._tenant=tenant;self._data_product=data_product;self._version=version;self._dataplane_name=dataplane_name;self._dataplane_network_type=dataplane_network_type;self._dataplane_type=dataplane_type;self._dataos_fqdn=dataos_fqdn;self._resource_id=resource_id;self._resource_type=resource_type;self._instance_name=instance_name;self._user_name=user_name;self._counter_cache=counter_cache;self._registry=CollectorRegistry();self._metrics=self._declare_metrics()
	@property
	def registry(self)->t.Any:return self._registry
	def _env_labels(self,environment:str)->t.Dict[str,str]:return{**self._base_labels(),_t:environment}
	def _base_labels(self)->t.Dict[str,str]:return{_L:self._tenant,_M:self._data_product,_N:self._version,_O:self._dataplane_name,_P:self._dataplane_network_type,_Q:self._dataplane_type,_R:self._dataos_fqdn,_S:self._resource_id,_T:self._resource_type,_U:self._instance_name,_V:self._user_name}
	def _inc(self,metric_key:str,labels:t.Dict[str,str],amount:int=1)->_A:self._counter_cache.inc_counter(self._metrics[metric_key],labels,amount=amount)
	def _set_gauge(self,metric_key:str,labels:t.Dict[str,str],value:float)->_A:self._metrics[metric_key].labels(**labels).set(value)
	def _declare_metrics(self)->t.Dict[str,t.Any]:r=self._registry;name=self._metric_name;return{_W:Counter(name(_W),'Plan apply invocations.',list(_ENV_LABELS)+[_C],registry=r),_u:Histogram(name('plan_duration_seconds'),'Plan apply duration.',list(_ENV_LABELS)+[_C,'plan_type'],buckets=_DURATION_BUCKETS,registry=r),_X:Counter(name(_X),'Plan model changes grouped by scope and kind.',list(_ENV_LABELS)+[_C,'scope',_E],registry=r),_Y:Histogram(name(_Y),'Total models changed per plan apply.',list(_ENV_LABELS)+[_C],buckets=_COUNT_BUCKETS,registry=r),_Z:Histogram(name(_Z),'Blast radius - models affected per plan.',list(_ENV_LABELS)+['change_type'],buckets=_COUNT_BUCKETS,registry=r),_a:Counter(name(_a),'Run invocations by outcome.',list(_ENV_LABELS)+[_C],registry=r),_b:Counter(name(_b),'Failed runs by root cause.',list(_ENV_LABELS)+[_z],registry=r),_v:Histogram(name('run_duration_seconds'),'Scheduler wall time per run (excludes DQ).',list(_ENV_LABELS)+[_C],buckets=_DURATION_BUCKETS,registry=r),_c:Histogram(name(_c),'Models executed per run.',list(_ENV_LABELS),buckets=_COUNT_BUCKETS,registry=r),_d:Histogram(name(_d),'Models with at least one batch per run.',list(_ENV_LABELS),buckets=_COUNT_BUCKETS,registry=r),_e:Histogram(name(_e),'Sum of model batch counts per run.',list(_ENV_LABELS),buckets=_COUNT_BUCKETS,registry=r),_f:Counter(name(_f),'DQ scan invocations.',list(_ENV_LABELS)+[_H],registry=r),_w:Histogram(name('dq_scan_duration_seconds'),'DQ scan wall time.',list(_ENV_LABELS),buckets=_DURATION_BUCKETS,registry=r),_g:Histogram(name(_g),'Models scanned per DQ invocation.',list(_ENV_LABELS),buckets=_COUNT_BUCKETS,registry=r),_h:Counter(name(_h),'DQ check outcomes aggregated by model kind.',list(_ENV_LABELS)+[_E,'outcome'],registry=r),_i:Counter(name(_i),'Audit executions by model kind and result.',list(_BASE_LABELS)+[_E,_H],registry=r),_j:Gauge(name(_j),'Active snapshots in the current environment.',list(_ENV_LABELS),registry=r),_k:Gauge(name(_k),'Active environments for the data product.',list(_BASE_LABELS),registry=r),_l:Histogram(name(_l),'Snapshot records created during plan apply.',list(_ENV_LABELS),buckets=_COUNT_BUCKETS,registry=r),_m:Counter(name(_m),'Virtual layer updates that skip compute.',list(_ENV_LABELS),registry=r),_n:Counter(name(_n),'Backfill invocations by trigger type.',list(_ENV_LABELS)+['trigger',_C],registry=r),_x:Histogram(name('backfill_duration_seconds'),'Backfill duration distribution.',list(_ENV_LABELS),buckets=_DURATION_BUCKETS,registry=r),_o:Histogram(name(_o),'Date intervals backfilled per plan apply.',list(_ENV_LABELS),buckets=_COUNT_BUCKETS,registry=r),_G:Gauge(name(_G),'Currently active backfills.',list(_ENV_LABELS),registry=r),_p:Counter(name(_p),'State database migration invocations.',list(_BASE_LABELS)+[_q,_C],registry=r),_y:Histogram(name('migration_duration_seconds'),'State database migration wall time.',list(_BASE_LABELS)+[_q,_C],buckets=_DURATION_BUCKETS,registry=r)}
	def on_plan_end(self,*,plan:'Plan',activity:'PlanActivity')->_A:
		D='non_breaking';C='breaking';B='regular';A='forward_only'
		try:
			status:t.Literal[_D,_B]=_D if activity.success else _B;env=activity.environment;base=self._env_labels(env)
			if plan.restatements:plan_type:t.Literal[_F,A,B]=_F
			elif plan.forward_only:plan_type=A
			else:plan_type=B
			duration_s=max((activity.end_ts-activity.start_ts)/1e3,.0);self._inc(_W,{**base,_C:status});self._metrics[_u].labels(**base,status=status,plan_type=plan_type).observe(duration_s);changes=activity.changes
			for(scope,items)in(('direct',changes.direct),('indirect',changes.indirect),('added',changes.added),('removed',changes.removed),('metadata',changes.metadata)):
				for item in items:kind=item.model_kind.name.lower()if item.model_kind is not _A else _A0;self._inc(_X,{**base,_C:status,'scope':scope,_E:kind})
			total=len(changes.direct)+len(changes.indirect)+len(changes.added)+len(changes.removed)+len(changes.metadata)
			if total>0:self._metrics[_Y].labels(**base,status=status).observe(float(total));change_type:t.Literal[C,D]=C if activity.has_breaking_changes else D;self._metrics[_Z].labels(**base,change_type=change_type).observe(float(total))
			if activity.has_changes:self._inc(_m,base)
		except Exception:logger.exception('Core prom on_plan_end failed')
	def on_run_end(self,*,environment:str,models:t.Sequence[_A1],errors:t.Sequence['ErrorExec'],scheduler_start_ts_ms:int,scheduler_end_ts_ms:int,completion_status:t.Optional['CompletionStatus']=_A,interrupted:bool=False)->_A:
		E='other';D='execution';C='audit';B='interrupted';A='no_op'
		try:
			from vulcan.utils import CompletionStatus as CS
			if completion_status is _A:
				if errors:completion_status=CS.FAILURE
				elif not models:completion_status=CS.NOTHING_TO_DO
				else:completion_status=CS.SUCCESS
			if interrupted:status:t.Literal[_D,_B,A,B]=B
			elif errors:status=_B
			elif completion_status.is_nothing_to_do:status=A
			elif completion_status.is_failure:status=_B
			else:status=_D
			base=self._env_labels(environment);duration_s=max((scheduler_end_ts_ms-scheduler_start_ts_ms)/1e3,.0);self._inc(_a,{**base,_C:status});self._metrics[_v].labels(**base,status=status).observe(duration_s)
			if status==_B:
				if any(error.is_audit_error for error in errors):reason:t.Literal[C,D,E]=C
				elif models:reason=D
				else:reason=E
				self._inc(_b,{**base,_z:reason})
			models_affected=len(models);models_backfilled=sum(1 for model in models if model.total_batches>0);intervals_processed=sum(model.total_batches for model in models)
			if models_affected>0:self._metrics[_c].labels(**base).observe(float(models_affected))
			if models_backfilled>0:self._metrics[_d].labels(**base).observe(float(models_backfilled))
			if intervals_processed>0:self._metrics[_e].labels(**base).observe(float(intervals_processed))
		except Exception:logger.exception('Core prom on_run_end failed')
	def on_dq_end(self,*,environment:str,models:t.Sequence[_A1],check_results:t.Optional['CheckExecutionSummary'],scan_start_ts_ms:int,scan_end_ts_ms:int,error:t.Optional[BaseException]=_A)->_A:
		try:
			base=self._env_labels(environment);result='error'if error is not _A else _D;duration_s=max((scan_end_ts_ms-scan_start_ts_ms)/1e3,.0);models_scanned=len(models);self._inc(_f,{**base,_H:result});self._metrics[_w].labels(**base).observe(duration_s)
			if models_scanned>0:self._metrics[_g].labels(**base).observe(float(models_scanned))
			if error is _A and check_results is not _A:
				kind_by_name={m.name:m.model_kind.name.lower()if m.model_kind else _I for m in models};kind_by_fqn={m.fqn:m.model_kind.name.lower()if m.model_kind else _I for m in models};dq_counts:t.Dict[t.Tuple[str,str],int]={}
				for(model_name,model_data)in check_results.results.items():
					kind=kind_by_name.get(model_name)or kind_by_fqn.get(model_name)or _I
					for(_dimension,stats)in model_data.get('dimensions',{}).items():
						for(soda_key,outcome)in((_J,_J),(_B,_B),(_K,_K),('not_evaluated',_r)):
							count=int(stats.get(soda_key,0))
							if count<=0:continue
							key=kind,outcome;dq_counts[key]=dq_counts.get(key,0)+count
				for((kind,outcome),count)in dq_counts.items():self._inc(_h,{**base,_E:kind,'outcome':outcome},amount=count)
		except Exception:logger.exception('Core prom on_dq_end failed')
	def on_audits_completed(self,*,snapshot:'Snapshot',audit_results:t.Sequence['AuditResult'])->_A:
		try:
			base=self._base_labels()
			if snapshot.is_model:model_kind=snapshot.model_kind_name;audit_kind=model_kind.name.lower()if model_kind else _I
			else:audit_kind=_A0
			for audit_result in audit_results:
				if audit_result.skipped:outcome:t.Literal[_r,_J,_K,_B]=_r
				elif audit_result.count and audit_result.count>0:outcome=_B if audit_result.blocking else _K
				else:outcome=_J
				self._inc(_i,{**base,_E:audit_kind,_H:outcome})
		except Exception:logger.exception('Core prom on_audits_completed failed')
	def on_migration_end(self,*,state_sync_type:str,duration_s:float,status:MigrationStatusLabel)->_A:
		if status not in(_D,_B):return
		try:labels={**self._base_labels(),_q:state_sync_type,_C:status};self._inc(_p,labels);self._metrics[_y].labels(**labels).observe(max(duration_s,.0))
		except Exception:logger.exception('Core prom on_migration_end failed')
	def on_env_inventory(self,*,environment:str,snapshot_count:int,environment_count:int)->_A:
		try:self._set_gauge(_j,self._env_labels(environment),float(snapshot_count));self._set_gauge(_k,self._base_labels(),float(environment_count))
		except Exception:logger.exception('Core prom on_env_inventory failed')
	def on_plan_backfill_started(self,*,environment:str)->_A:
		try:self._metrics[_G].labels(**self._env_labels(environment)).inc()
		except Exception:logger.exception('Core prom on_plan_backfill_started failed')
	def on_plan_backfill_completed(self,*,environment:str,duration_s:float,status:BackfillStatusLabel,stage:'BackfillStage',plan:t.Union['Plan','EvaluatablePlan'])->_A:
		if status not in(_D,_B):return
		try:backfill_intervals=sum(len(intervals)for intervals in stage.snapshot_to_intervals.values())if stage.snapshot_to_intervals else 0;backfill_trigger:t.Literal[_s,_F]=_F if plan.restatements else _s;self._record_plan_backfill_metrics(environment=environment,duration_s=duration_s,status=status,backfill_intervals=backfill_intervals,backfill_trigger=backfill_trigger)
		except Exception:logger.exception('Core prom on_plan_backfill_completed failed')
	def _record_plan_backfill_metrics(self,*,environment:str,duration_s:float,status:BackfillStatusLabel,backfill_intervals:int,backfill_trigger:t.Literal[_s,_F])->_A:
		base=self._env_labels(environment);self._inc(_n,{**base,'trigger':backfill_trigger,_C:status});self._metrics[_x].labels(**base).observe(max(duration_s,.0))
		if backfill_intervals>0:self._metrics[_o].labels(**base).observe(float(backfill_intervals))
		self._set_gauge(_G,base,.0)
	def on_plan_snapshots_created(self,*,environment:str,snapshots_created:int)->_A:
		if snapshots_created<=0:return
		try:self._metrics[_l].labels(**self._env_labels(environment)).observe(float(snapshots_created))
		except Exception:logger.exception('Core prom on_plan_snapshots_created failed')