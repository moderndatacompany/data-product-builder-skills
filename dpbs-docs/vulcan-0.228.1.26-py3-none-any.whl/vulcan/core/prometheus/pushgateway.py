from __future__ import annotations
_C=False
_B=True
_A=None
import logging,os,threading,typing as t,urllib.request
logger=logging.getLogger(__name__)
_DATAOS_GROUPING_KEY_ENV:t.Mapping[str,str]={'resource_id':'DATAOS_RESOURCE_ID','resource_type':'DATAOS_TYPE','tenant_name':'DATAOS_TENANT_ID','instance_name':'DATAOS_INSTANCE_TENANT_ID','dataplane_name':'DATAOS_DATAPLANE_NAME','dataplane_network_type':'DATAOS_DATAPLANE_NETWORK_TYPE','dataplane_type':'DATAOS_DATAPLANE_TYPE','dataos_fqdn':'DATAOS_FQDN','user_name':'DATAOS_RUN_AS_USER'}
def resolve_pushgateway_grouping_key()->t.Dict[str,str]:
	key:t.Dict[str,str]={}
	for(field,env)in _DATAOS_GROUPING_KEY_ENV.items():
		value=os.environ.get(env)
		if not value:return{}
		key[field]=value
	version=os.environ.get('VULCAN_VERSION','latest');key['instance']=f"vulcan:{version}";key['stack_name']='vulcan';key['stack_version']=version;return key
try:from prometheus_client import pushadd_to_gateway;from prometheus_client.exposition import default_handler as _prom_default_handler;_PROM_AVAILABLE=_B
except Exception as ex:pushadd_to_gateway=_A;_prom_default_handler=_A;_PROM_AVAILABLE=_C;logger.warning('prometheus_client unavailable, Core prom push will no-op: %s',ex)
class PushgatewayCounterCache:
	def __init__(self,*,pushgateway_url:str,job:str,grouping_key:t.Mapping[str,str],fetch_timeout_sec:float=2.)->_A:self._pushgateway_url=pushgateway_url.rstrip('/');self._job=job;self._grouping_key=dict(grouping_key);self._fetch_timeout_sec=fetch_timeout_sec;(self._cached_values):t.Dict[str,float]={};self._cache_lock=threading.Lock();self._batch_open=_C
	def close_batch(self)->_A:self._batch_open=_C
	def ensure_batch(self)->_A:
		if not self._pushgateway_url:return
		if self._batch_open:return
		fetched:t.Dict[str,float]={}
		try:
			req=urllib.request.Request(f"{self._pushgateway_url}/metrics")
			with urllib.request.urlopen(req,timeout=self._fetch_timeout_sec)as resp:
				filters=[f'job="{self._job}"']+[f'{k}="{v}"'for(k,v)in self._grouping_key.items()]
				for line in resp.read().decode().splitlines():
					if line.startswith('#')or not line.strip():continue
					parts=line.rsplit(' ',1)
					if len(parts)==2 and all(part in parts[0]for part in filters):fetched[parts[0]]=float(parts[1])
		except Exception:pass
		with self._cache_lock:self._cached_values.clear();self._cached_values.update(fetched)
		self._batch_open=_B
	def inc_counter(self,counter:t.Any,labels:t.Dict[str,str],amount:int=1)->_A:
		if amount<=0:return
		child=counter.labels(**labels)
		if not self._pushgateway_url:child.inc(amount);return
		self.ensure_batch();name=counter._name;new_value=self._reserve(name,labels,amount=amount);current_value=.0;value_ref=getattr(child,'_value',_A)
		if value_ref is not _A and hasattr(value_ref,'get'):
			try:current_value=float(value_ref.get())
			except Exception:current_value=.0
		delta=new_value-current_value
		if delta>0:child.inc(delta)
	def _build_cache_key(self,metric_name:str,labels:t.Dict[str,str])->str:sorted_labels=','.join(f'{k}="{v}"'for(k,v)in sorted(labels.items()));return f"{metric_name}_total{{{sorted_labels}}}"
	def _is_counter_line(self,cached_key:str,metric_name:str)->bool:return'_total{'in cached_key or cached_key.startswith(metric_name+'{')and'_bucket'not in cached_key and'_sum'not in cached_key and'_count'not in cached_key and'_created'not in cached_key
	def _reserve(self,metric_name:str,labels:t.Dict[str,str],amount:int)->float:
		with self._cache_lock:
			prev=.0;update_key:t.Optional[str]=_A
			for(cached_key,value)in self._cached_values.items():
				if metric_name in cached_key and all(f'{k}="{v}"'in cached_key for(k,v)in labels.items()):
					if self._is_counter_line(cached_key,metric_name):prev=value;update_key=cached_key;break
			new_value=prev+amount
			if update_key is not _A:self._cached_values[update_key]=new_value
			else:self._cached_values[self._build_cache_key(metric_name,labels)]=new_value
			return new_value
class PushgatewayPusher:
	def __init__(self,*,registry:t.Any,counter_cache:PushgatewayCounterCache,pushgateway_url:str,job:str,grouping_key:t.Mapping[str,str],push_interval_sec:int=10,push_timeout_sec:float=2.,start_pusher:bool=_B)->_A:
		self._registry=registry;self._counter_cache=counter_cache;self._pushgateway_url=pushgateway_url.rstrip('/');self._job=job;self._grouping_key=dict(grouping_key);self._push_interval_sec=max(1,int(push_interval_sec));self._push_timeout_sec=float(push_timeout_sec);self._stop_event=threading.Event();(self._pusher_thread):t.Optional[threading.Thread]=_A
		if start_pusher:self._pusher_thread=threading.Thread(target=self._push_loop,name='VulcanCorePromPusher',daemon=_B);self._pusher_thread.start()
	def _bounded_push_handler(self,url,method,timeout,headers,data):
		if _prom_default_handler is _A:raise RuntimeError('prometheus_client not available')
		return _prom_default_handler(url,method,self._push_timeout_sec,headers,data)
	def push(self)->bool:
		if not self._pushgateway_url or pushadd_to_gateway is _A:return _C
		try:
			kwargs:t.Dict[str,t.Any]=dict(gateway=self._pushgateway_url,job=self._job,registry=self._registry,handler=self._bounded_push_handler)
			if self._grouping_key:kwargs['grouping_key']=self._grouping_key
			pushadd_to_gateway(**kwargs);self._counter_cache.close_batch();return _B
		except Exception as e:logger.warning('Core Prometheus push failed: %s',e);return _C
	def _push_loop(self)->_A:
		backoff=float(self._push_interval_sec);max_backoff=max(float(self._push_interval_sec)*12,6e1)
		while not self._stop_event.is_set():
			if self.push():wait_s=float(self._push_interval_sec);backoff=float(self._push_interval_sec)
			else:wait_s=backoff;backoff=min(backoff*2.,max_backoff)
			if self._stop_event.wait(timeout=wait_s):break
	def flush(self)->bool:self._counter_cache.close_batch();return self.push()
	def shutdown(self,*,flush:bool=_B)->_A:
		self._stop_event.set()
		if self._pusher_thread is not _A and self._pusher_thread.is_alive():self._pusher_thread.join(timeout=5)
		if flush:self.flush()