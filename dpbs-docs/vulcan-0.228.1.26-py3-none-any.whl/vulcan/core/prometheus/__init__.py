from __future__ import annotations
_B=True
_A=None
import atexit,logging,typing as t
from vulcan.core.prometheus.pushgateway import PushgatewayCounterCache,PushgatewayPusher,resolve_pushgateway_grouping_key
from vulcan.core.prometheus.registry import CorePromRegistry
logger=logging.getLogger(__name__)
if t.TYPE_CHECKING:from vulcan.core.config.prometheus import PrometheusConfig
_pusher:t.Optional[PushgatewayPusher]=_A
def _default_counter_cache()->PushgatewayCounterCache:return PushgatewayCounterCache(pushgateway_url='',job='vulcan-v2',grouping_key={})
registry=CorePromRegistry(tenant='',data_product='',version='',counter_cache=_default_counter_cache())
def init_from_config(prometheus_config:'PrometheusConfig',*,tenant:str,data_product:str,version:str,dataplane_name:str='',dataplane_network_type:str='',dataplane_type:str='',dataos_fqdn:str='',resource_id:str='',resource_type:str='',instance_name:str='',user_name:str='',start_pusher:bool=_B)->CorePromRegistry:
	global registry,_pusher;shutdown(flush=False);pushgateway_url=(prometheus_config.pushgateway_url or'').strip();grouping_key=dict(prometheus_config.grouping_key)if prometheus_config.grouping_key else{}
	if pushgateway_url and not grouping_key:grouping_key=resolve_pushgateway_grouping_key()
	counter_cache=PushgatewayCounterCache(pushgateway_url=pushgateway_url,job=prometheus_config.job,grouping_key=grouping_key,fetch_timeout_sec=prometheus_config.push_timeout_sec);active=CorePromRegistry(tenant=tenant,data_product=data_product or'',version=version or'',counter_cache=counter_cache,dataplane_name=dataplane_name,dataplane_network_type=dataplane_network_type,dataplane_type=dataplane_type,dataos_fqdn=dataos_fqdn,resource_id=resource_id,resource_type=resource_type,instance_name=instance_name,user_name=user_name);registry=active
	if pushgateway_url and start_pusher:_pusher=PushgatewayPusher(registry=active.registry,counter_cache=counter_cache,pushgateway_url=pushgateway_url,job=prometheus_config.job,grouping_key=grouping_key,push_interval_sec=prometheus_config.push_interval_sec,push_timeout_sec=prometheus_config.push_timeout_sec,start_pusher=_B);logger.info('Core Prometheus push enabled (job=%s, pushgateway=%s, tenant=%s, data_product=%s, version=%s)',prometheus_config.job,pushgateway_url,tenant,data_product,version)
	else:_pusher=_A;logger.info('Core Prometheus collecting in-process only (pushgateway_url empty=%s, start_pusher=%s, tenant=%s, data_product=%s, version=%s)',not pushgateway_url,start_pusher,tenant,data_product,version)
	return registry
def flush()->_A:
	if _pusher is not _A:_pusher.flush()
def shutdown(*,flush:bool=_B)->_A:
	global _pusher
	if _pusher is not _A:_pusher.shutdown(flush=flush);_pusher=_A
def _shutdown_on_exit()->_A:shutdown(flush=_B)
atexit.register(_shutdown_on_exit)