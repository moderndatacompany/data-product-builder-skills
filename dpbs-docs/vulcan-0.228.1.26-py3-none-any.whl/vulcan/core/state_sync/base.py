from __future__ import annotations
_E='before'
_D='0.0.0'
_C=True
_B=False
_A=None
import abc,importlib,logging,pkgutil,typing as t
from sqlglot._version import __version__ as SQLGLOT_VERSION
from vulcan import migrations
from vulcan.core.environment import Environment,EnvironmentStatements,EnvironmentSummary
from vulcan.core.snapshot import Snapshot,SnapshotId,SnapshotIdLike,SnapshotIdAndVersionLike,SnapshotInfoLike,SnapshotNameVersion,SnapshotIdAndVersion
from vulcan.core.snapshot.definition import Interval,SnapshotIntervals
from vulcan.utils import major_minor
from vulcan.utils.date import TimeLike
from vulcan.utils.errors import VulcanError
from vulcan.utils.pydantic import PydanticModel,field_validator
from vulcan.core.state_sync.common import StateStream,ExpiredSnapshotBatch,PromotionResult,ExpiredBatchRange
if t.TYPE_CHECKING:from vulcan.core.activity import PlanActivity,RunActivity,RunActivityWithChecksAndProfile;from vulcan.core.soda3.spec import CheckRuns;from vulcan.core.state_sync.db.query import QueryState
logger=logging.getLogger(__name__)
class Versions(PydanticModel):
	schema_version:int=0;sqlglot_version:str=_D;vulcan_version:str=_D
	@property
	def minor_sqlglot_version(self)->t.Tuple[int,int]:return major_minor(self.sqlglot_version)
	@property
	def minor_vulcan_version(self)->t.Tuple[int,int]:return major_minor(self.vulcan_version)
	@field_validator('sqlglot_version','vulcan_version',mode=_E)
	@classmethod
	def _package_version_validator(cls,v:t.Any)->str:return _D if v is _A else str(v)
	@field_validator('schema_version',mode=_E)
	@classmethod
	def _schema_version_validator(cls,v:t.Any)->int:return 0 if v is _A else int(v)
MIN_SCHEMA_VERSION=60
MIN_SQLMESH_VERSION='0.134.0'
MIGRATIONS=[importlib.import_module(f"vulcan.migrations.{migration}")for migration in sorted(info.name for info in pkgutil.iter_modules(migrations.__path__))]
SCHEMA_VERSION:int=MIN_SCHEMA_VERSION+len(MIGRATIONS)-1
class StateReader(abc.ABC):
	@abc.abstractmethod
	def get_snapshots(self,snapshot_ids:t.Iterable[SnapshotIdLike])->t.Dict[SnapshotId,Snapshot]:0
	@abc.abstractmethod
	def get_snapshots_by_names(self,snapshot_names:t.Iterable[str],current_ts:t.Optional[int]=_A,exclude_expired:bool=_C)->t.Set[SnapshotIdAndVersion]:0
	@abc.abstractmethod
	def snapshots_exist(self,snapshot_ids:t.Iterable[SnapshotIdLike])->t.Set[SnapshotId]:0
	@abc.abstractmethod
	def refresh_snapshot_intervals(self,snapshots:t.Collection[Snapshot])->t.List[Snapshot]:0
	@abc.abstractmethod
	def nodes_exist(self,names:t.Iterable[str],exclude_external:bool=_B)->t.Set[str]:0
	@abc.abstractmethod
	def get_environment(self,environment:str)->t.Optional[Environment]:0
	@abc.abstractmethod
	def get_environments(self)->t.List[Environment]:0
	@abc.abstractmethod
	def get_environments_summary(self)->t.List[EnvironmentSummary]:0
	@abc.abstractmethod
	def max_interval_end_per_model(self,environment:str,models:t.Optional[t.Set[str]]=_A,ensure_finalized_snapshots:bool=_B)->t.Dict[str,int]:0
	@abc.abstractmethod
	def recycle(self)->_A:0
	@abc.abstractmethod
	def close(self)->_A:0
	@abc.abstractmethod
	def state_type(self)->str:0
	@abc.abstractmethod
	def update_auto_restatements(self,next_auto_restatement_ts:t.Dict[SnapshotNameVersion,t.Optional[int]])->_A:0
	@abc.abstractmethod
	def get_environment_statements(self,environment:str)->t.List[EnvironmentStatements]:0
	def get_versions(self,validate:bool=_C)->Versions:
		A='Vulcan';from vulcan._version import __version__ as SQLMESH_VERSION;versions=self._get_versions()
		if validate:
			def raise_error(lib:str,local:str|int,remote:str|int,remote_package_version:t.Optional[str]=_A,ahead:bool=_B)->_A:
				if ahead:raise VulcanError(f"{lib} (local) is using version '{local}' which is ahead of '{remote}' (remote). Please run a migration ('vulcan migrate' command).")
				if remote_package_version:upgrade_suggestion=f" Please upgrade {lib} ('pip install --upgrade \"{lib.lower()}=={remote_package_version}\"' command)."
				else:upgrade_suggestion=''
				raise VulcanError(f"{lib} (local) is using version '{local}' which is behind '{remote}' (remote).{upgrade_suggestion}")
			if major_minor(SQLMESH_VERSION)!=major_minor(versions.vulcan_version):raise_error(A,SQLMESH_VERSION,versions.vulcan_version,remote_package_version=versions.vulcan_version,ahead=major_minor(SQLMESH_VERSION)>major_minor(versions.vulcan_version))
			if SCHEMA_VERSION!=versions.schema_version:raise_error(A,SCHEMA_VERSION,versions.schema_version,remote_package_version=versions.vulcan_version,ahead=SCHEMA_VERSION>versions.schema_version)
			if major_minor(SQLGLOT_VERSION)!=major_minor(versions.sqlglot_version):raise_error('SQLGlot',SQLGLOT_VERSION,versions.sqlglot_version,remote_package_version=versions.sqlglot_version,ahead=major_minor(SQLGLOT_VERSION)>major_minor(versions.sqlglot_version))
		return versions
	@abc.abstractmethod
	def _get_versions(self)->Versions:0
	@abc.abstractmethod
	def export(self,environment_names:t.Optional[t.List[str]]=_A)->StateStream:0
	@abc.abstractmethod
	def get_expired_snapshots(self,*,batch_range:ExpiredBatchRange,current_ts:t.Optional[int]=_A,ignore_ttl:bool=_B)->t.Optional[ExpiredSnapshotBatch]:0
	@abc.abstractmethod
	def get_expired_environments(self,current_ts:int)->t.List[EnvironmentSummary]:0
class StateSync(StateReader,abc.ABC):
	@abc.abstractmethod
	def push_snapshots(self,snapshots:t.Iterable[Snapshot])->_A:0
	@abc.abstractmethod
	def delete_snapshots(self,snapshot_ids:t.Iterable[SnapshotIdLike])->_A:0
	@abc.abstractmethod
	def delete_expired_snapshots(self,batch_range:ExpiredBatchRange,ignore_ttl:bool=_B,current_ts:t.Optional[int]=_A)->_A:0
	@abc.abstractmethod
	def invalidate_environment(self,name:str,protect_prod:bool=_C)->_A:0
	@abc.abstractmethod
	def remove_state(self,including_backup:bool=_B)->_A:0
	@abc.abstractmethod
	def remove_intervals(self,snapshot_intervals:t.Sequence[t.Tuple[SnapshotIdAndVersionLike,Interval]],remove_shared_versions:bool=_B)->_A:0
	@abc.abstractmethod
	def promote(self,environment:Environment,no_gaps_snapshot_names:t.Optional[t.Set[str]]=_A,environment_statements:t.Optional[t.List[EnvironmentStatements]]=_A)->PromotionResult:0
	@abc.abstractmethod
	def finalize(self,environment:Environment)->_A:0
	@abc.abstractmethod
	def delete_expired_environments(self,current_ts:t.Optional[int]=_A)->t.List[EnvironmentSummary]:0
	@abc.abstractmethod
	def unpause_snapshots(self,snapshots:t.Collection[SnapshotInfoLike],unpaused_dt:TimeLike)->_A:0
	@abc.abstractmethod
	def compact_intervals(self)->_A:0
	@abc.abstractmethod
	def migrate(self,skip_backup:bool=_B,promoted_snapshots_only:bool=_C)->_A:0
	@abc.abstractmethod
	def rollback(self)->_A:0
	@abc.abstractmethod
	def add_snapshots_intervals(self,snapshots_intervals:t.Sequence[SnapshotIntervals])->_A:0
	def add_interval(self,snapshot:Snapshot,start:TimeLike,end:TimeLike,is_dev:bool=_B,last_altered_ts:t.Optional[int]=_A)->_A:
		start_ts,end_ts=snapshot.inclusive_exclusive(start,end,strict=_B,expand=_B)
		if not snapshot.version:raise VulcanError('Snapshot version must be set to add an interval.')
		intervals=[(start_ts,end_ts)];snapshot_intervals=SnapshotIntervals(name=snapshot.name,identifier=snapshot.identifier,version=snapshot.version,dev_version=snapshot.dev_version,intervals=intervals if not is_dev else[],dev_intervals=intervals if is_dev else[],last_altered_ts=last_altered_ts if not is_dev else _A,dev_last_altered_ts=last_altered_ts if is_dev else _A);self.add_snapshots_intervals([snapshot_intervals])
	@abc.abstractmethod
	def import_(self,stream:StateStream,clear:bool=_C)->_A:0
class DelegatingStateSync(StateSync):
	def __init__(self,state_sync:StateSync)->_A:self.state_sync=state_sync
	def __getattr__(self,name:str)->t.Any:return getattr(self.state_sync,name)
def _create_delegate_method(name:str)->t.Callable:
	def delegate(self:t.Any,*args:t.Any,**kwargs:t.Any)->t.Any:return getattr(self.state_sync,name)(*args,**kwargs)
	return delegate
DelegatingStateSync.__abstractmethods__=frozenset()
for name in StateSync.__abstractmethods__:setattr(DelegatingStateSync,name,_create_delegate_method(name))