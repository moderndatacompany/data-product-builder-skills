_K='environments'
_J='snapshots'
_I='versions'
_H='importable'
_G='timestamp'
_F='utf8'
_E=False
_D='file_version'
_C='metadata'
_B=True
_A=None
import json,typing as t
from vulcan.core.state_sync import StateSync
from vulcan.core.snapshot import Snapshot
from vulcan.utils.date import now,to_tstz
from vulcan.utils.pydantic import _expression_encoder
from vulcan.core.state_sync import Versions
from vulcan.core.state_sync.common import EnvironmentsChunk,SnapshotsChunk,VersionsChunk,EnvironmentWithStatements,StateStream
from vulcan.core.console import Console
from pathlib import Path
from vulcan.core.console import NoopConsole
import json_stream
from json_stream import streamable_dict,to_standard_types,streamable_list
from json_stream.writer import StreamableDict
from json_stream.base import StreamingJSONObject
from json_stream.dump import JSONStreamEncoder
from vulcan.utils.errors import VulcanError
from sqlglot import exp
from vulcan.utils.pydantic import DEFAULT_ARGS as PYDANTIC_DEFAULT_ARGS,PydanticModel
class VulcanJSONStreamEncoder(JSONStreamEncoder):
	def default(self,obj:t.Any)->t.Any:
		if isinstance(obj,exp.Expression):return _expression_encoder(obj)
		return super().default(obj)
def _dump_pydantic_model(model:PydanticModel)->t.Dict[str,t.Any]:dump_args:t.Dict[str,t.Any]=PYDANTIC_DEFAULT_ARGS;return model.model_dump(mode='json',**dump_args)
def _export(state_stream:StateStream,importable:bool,console:Console)->StreamableDict:
	@streamable_list
	def _dump_snapshots(snapshot_stream:t.Iterable[Snapshot])->t.Iterator[t.Dict[str,t.Any]]:
		console.update_state_export_progress(snapshot_count=0)
		for(idx,snapshot)in enumerate(snapshot_stream):yield _dump_pydantic_model(snapshot);console.update_state_export_progress(snapshot_count=idx+1)
	@streamable_dict
	def _dump_environments(environment_stream:t.Iterable[EnvironmentWithStatements])->t.Iterator[t.Tuple[str,t.Any]]:
		console.update_state_export_progress(environment_count=0)
		for(idx,env)in enumerate(environment_stream):yield(env.environment.name,_dump_pydantic_model(env));console.update_state_export_progress(environment_count=idx+1)
	@streamable_dict
	def _do_export()->t.Iterator[t.Tuple[str,t.Any]]:
		yield(_C,{_G:to_tstz(now()),_D:1,_H:importable})
		for state_chunk in state_stream:
			if isinstance(state_chunk,VersionsChunk):versions=_dump_pydantic_model(state_chunk.versions);yield(_I,versions);console.update_state_export_progress(version_count=len(versions),versions_complete=_B)
			if isinstance(state_chunk,SnapshotsChunk):yield(_J,_dump_snapshots(state_chunk));console.update_state_export_progress(snapshots_complete=_B)
			if isinstance(state_chunk,EnvironmentsChunk):yield(_K,_dump_environments(state_chunk));console.update_state_export_progress(environments_complete=_B)
	return _do_export()
def _import(state_sync:StateSync,data:t.Callable[[],StreamingJSONObject],clear:bool,console:Console)->_A:
	def _load_snapshots()->t.Iterator[Snapshot]:
		stream=data()[_J];console.update_state_import_progress(snapshot_count=0)
		for(idx,raw_snapshot)in enumerate(stream):snapshot=Snapshot.model_validate(to_standard_types(raw_snapshot));yield snapshot;console.update_state_import_progress(snapshot_count=idx+1)
		console.update_state_import_progress(snapshots_complete=_B)
	def _load_environments()->t.Iterator[EnvironmentWithStatements]:
		stream=data()[_K];console.update_state_import_progress(environment_count=0)
		for(idx,(_,raw_environment))in enumerate(stream.items()):environment=EnvironmentWithStatements.model_validate(to_standard_types(raw_environment));yield environment;console.update_state_import_progress(environment_count=idx+1)
		console.update_state_import_progress(environments_complete=_B)
	metadata=to_standard_types(data()[_C]);timestamp=metadata[_G]
	if not isinstance(timestamp,str):raise ValueError(f"'timestamp' contains an invalid value. Expecting str, got: {timestamp}")
	console.update_state_import_progress(timestamp=timestamp,state_file_version=metadata[_D]);versions=Versions.model_validate(to_standard_types(data()[_I]));stream=StateStream.from_iterators(versions=versions,snapshots=_load_snapshots(),environments=_load_environments());console.update_state_import_progress(versions=versions);state_sync.import_(stream,clear=clear)
def export_state(state_sync:StateSync,output_file:Path,local_snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,environment_names:t.Optional[t.List[str]]=_A,console:t.Optional[Console]=_A)->_A:
	console=console or NoopConsole();state_stream=StateStream.from_iterators(versions=state_sync.get_versions(),snapshots=iter(local_snapshots.values()),environments=iter([]))if local_snapshots else state_sync.export(environment_names=environment_names);importable=_E if local_snapshots else _B;json_stream=_export(state_stream=state_stream,importable=importable,console=console)
	with output_file.open(mode='w',encoding=_F)as fh:json.dump(json_stream,fh,indent=2,cls=VulcanJSONStreamEncoder)
def import_state(state_sync:StateSync,input_file:Path,clear:bool=_E,console:t.Optional[Console]=_A)->_A:
	console=console or NoopConsole()
	with input_file.open('r',encoding=_F)as fh:
		stream=json_stream.load(fh)
		if not isinstance(stream,StreamingJSONObject):raise VulcanError(f"Expected JSON object, got: {type(stream)}")
		try:metadata=stream[_C].persistent()
		except KeyError:raise VulcanError("Expecting a 'metadata' key to be present")
		if not isinstance(metadata,StreamingJSONObject):raise VulcanError("Expecting the 'metadata' key to contain an object")
		file_version=metadata.get(_D)
		if file_version is _A:raise VulcanError('Unable to determine state file format version from the input file')
		try:int(file_version)
		except ValueError:raise VulcanError(f"Unable to parse state file format version: {file_version}")
		if not metadata.get(_H,_E):raise VulcanError('State file is marked as not importable. Aborting')
	handles:t.List[t.TextIO]=[]
	def _new_handle()->StreamingJSONObject:handle=input_file.open('r',encoding=_F);handles.append(handle);stream=json_stream.load(handle);assert isinstance(stream,StreamingJSONObject);return stream
	try:_import(state_sync=state_sync,data=_new_handle,clear=clear,console=console)
	finally:
		for handle in handles:handle.close()