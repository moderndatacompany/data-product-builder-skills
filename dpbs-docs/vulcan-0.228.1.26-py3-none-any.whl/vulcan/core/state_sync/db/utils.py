from __future__ import annotations
_C=True
_B='name'
_A=None
import json,typing as t,logging
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.snapshot import SnapshotIdLike,SnapshotNameVersionLike
from vulcan.utils.errors import VulcanError
logger=logging.getLogger(__name__)
try:from vulcan._version import __version__ as SQLMESH_VERSION
except ImportError:logger.error('Unable to set __version__, run "pip install -e ." or "python setup.py develop" first.')
T=t.TypeVar('T')
def snapshot_name_filter(snapshot_names:t.Iterable[str],batch_size:int,alias:t.Optional[str]=_A)->t.Iterator[exp.Condition]:
	names=sorted(snapshot_names)
	if not names:yield exp.false()
	else:
		batches=create_batches(names,batch_size=batch_size)
		for names in batches:yield exp.column(_B,table=alias).isin(*names)
def snapshot_id_filter(engine_adapter:EngineAdapter,snapshot_ids:t.Iterable[SnapshotIdLike],batch_size:int,alias:t.Optional[str]=_A)->t.Iterator[exp.Condition]:
	A='identifier';name_identifiers=sorted({(snapshot_id.name,snapshot_id.identifier)for snapshot_id in snapshot_ids});batches=create_batches(name_identifiers,batch_size=batch_size)
	if not name_identifiers:yield exp.false()
	elif engine_adapter.SUPPORTS_TUPLE_IN:
		for identifiers in batches:yield t.cast(exp.Tuple,exp.convert((exp.column(_B,table=alias),exp.column(A,table=alias)))).isin(*identifiers)
	else:
		for identifiers in batches:yield exp.or_(*[exp.and_(exp.column(_B,table=alias).eq(name),exp.column(A,table=alias).eq(identifier))for(name,identifier)in identifiers])
def snapshot_name_version_filter(engine_adapter:EngineAdapter,snapshot_name_versions:t.Iterable[SnapshotNameVersionLike],batch_size:int,version_column_name:str='version',alias:t.Optional[str]='snapshots',column_prefix:t.Optional[str]=_A)->t.Iterator[exp.Condition]:
	name_versions=sorted({(s.name,s.version)for s in snapshot_name_versions});batches=create_batches(name_versions,batch_size=batch_size);name_column_name=_B
	if column_prefix:name_column_name=f"{column_prefix}_{name_column_name}";version_column_name=f"{column_prefix}_{version_column_name}"
	name_column=exp.column(name_column_name,table=alias);version_column=exp.column(version_column_name,table=alias)
	if not name_versions:yield exp.false()
	elif engine_adapter.SUPPORTS_TUPLE_IN:
		for versions in batches:yield t.cast(exp.Tuple,exp.convert((name_column,version_column))).isin(*versions)
	else:
		for versions in batches:yield exp.or_(*[exp.and_(name_column.eq(name),version_column.eq(version))for(name,version)in versions])
def create_batches(l:t.List[T],batch_size:int)->t.List[t.List[T]]:return[l[i:i+batch_size]for i in range(0,len(l),batch_size)]
def is_postgres(engine_adapter:EngineAdapter)->bool:return engine_adapter.dialect=='postgres'
def raise_if_not_postgres(engine_adapter:EngineAdapter,*,feature:str)->_A:
	if not is_postgres(engine_adapter):raise VulcanError(f"{feature} requires PostgreSQL as the state store; got dialect {engine_adapter.dialect!r}.")
SqlParams=t.Union[t.Sequence[t.Any],t.Dict[str,t.Any]]
def fetchone(engine_adapter:EngineAdapter,query:t.Union[exp.Expression,str],params:t.Optional[SqlParams]=_A)->t.Optional[t.Tuple]:
	if params is _A:return engine_adapter.fetchone(query,ignore_unsupported_errors=_C,quote_identifiers=_C)
	with engine_adapter.transaction():engine_adapter.cursor.execute(query,params);return engine_adapter.cursor.fetchone()
def fetchall(engine_adapter:EngineAdapter,query:t.Union[exp.Expression,str],params:t.Optional[SqlParams]=_A)->t.List[t.Tuple]:
	if params is _A:return engine_adapter.fetchall(query,ignore_unsupported_errors=_C,quote_identifiers=_C)
	with engine_adapter.transaction():engine_adapter.cursor.execute(query,params);return list(engine_adapter.cursor.fetchall()or[])
def cursor_columns(engine_adapter:EngineAdapter)->t.List[str]:
	description=engine_adapter.cursor.description
	if not description:return[]
	return[col[0]for col in description]
def fetch_row_as_dict(engine_adapter:EngineAdapter,query:t.Union[exp.Expression,str],params:t.Optional[SqlParams]=_A)->t.Optional[t.Dict[str,t.Any]]:
	row=fetchone(engine_adapter,query,params)
	if row is _A:return
	return dict(zip(cursor_columns(engine_adapter),row))
def fetch_rows_as_dicts(engine_adapter:EngineAdapter,query:t.Union[exp.Expression,str],params:t.Optional[SqlParams]=_A)->t.List[t.Dict[str,t.Any]]:
	rows=fetchall(engine_adapter,query,params)
	if not rows:return[]
	columns=cursor_columns(engine_adapter);return[dict(zip(columns,row))for row in rows]
def json_to_list(raw:t.Any)->t.List[t.Any]:
	if raw is _A:return[]
	if isinstance(raw,list):return raw
	if isinstance(raw,str):
		try:parsed=json.loads(raw);return parsed if isinstance(parsed,list)else[]
		except(json.JSONDecodeError,TypeError):return[]
	return[]
def json_to_dict(raw:t.Any)->t.Dict[str,t.Any]:
	if raw is _A:return{}
	if isinstance(raw,dict):return raw
	if isinstance(raw,str):
		try:parsed=json.loads(raw);return parsed if isinstance(parsed,dict)else{}
		except(json.JSONDecodeError,TypeError):return{}
	return{}