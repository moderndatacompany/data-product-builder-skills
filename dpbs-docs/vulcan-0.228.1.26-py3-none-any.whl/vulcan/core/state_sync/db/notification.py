from __future__ import annotations
_L='username'
_K='payload'
_J='summary'
_I='status'
_H='id'
_G=True
_F='plan_id'
_E='run_id'
_D='event'
_C='environment'
_B='created_ts_ns'
_A=None
import json,logging,time,typing as t,uuid,pandas as pd
from sqlglot import exp
from vulcan.core import constants as c
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.notification import Notification,NotificationEvent,NotificationStatus
from vulcan.core.state_sync.db.utils import fetch_rows_as_dicts,json_to_dict
from vulcan.utils.migration import index_text_type
logger=logging.getLogger(__name__)
_NS_PER_SECOND=1000000000
def _col_eq(column:str,value:str)->exp.EQ:return exp.EQ(this=exp.column(column),expression=exp.Literal.string(value))
class NotificationState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A)->_A:A='text';self.engine_adapter=engine_adapter;self.schema=schema;self.notifications_table=exp.table_('_notifications',db=schema);index_type=index_text_type(engine_adapter.dialect);self._notification_columns_to_types={_H:exp.DataType.build(index_type),_B:exp.DataType.build('bigint'),_D:exp.DataType.build(index_type),_I:exp.DataType.build(A),_C:exp.DataType.build(index_type,nullable=_G),_E:exp.DataType.build(index_type,nullable=_G),_F:exp.DataType.build(index_type,nullable=_G),_L:exp.DataType.build(A,nullable=_G),_J:exp.DataType.build(A),_K:exp.DataType.build('jsonb')}
	def store_notification(self,*,event:NotificationEvent,status:NotificationStatus,summary:str,payload:t.Dict[str,t.Any],environment:t.Optional[str]=_A,run_id:t.Optional[str]=_A,plan_id:t.Optional[str]=_A,username:t.Optional[str]=_A)->str:notification_id=str(uuid.uuid4());created_ts_ns=time.time_ns();df=pd.DataFrame([{_H:notification_id,_B:created_ts_ns,_D:event.value,_I:status.value,_C:environment,_E:run_id,_F:plan_id,_L:username,_J:summary,_K:json.dumps(payload)}]);self.engine_adapter.insert_append(self.notifications_table,df,target_columns_to_types=self._notification_columns_to_types,track_rows_processed=False);return notification_id
	def list_notifications(self,*,environment:t.Optional[str]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,run_id:t.Optional[str]=_A,plan_id:t.Optional[str]=_A,events:t.Optional[t.Sequence[NotificationEvent]]=_A,limit:int=50,offset:int=0)->t.Tuple[t.List[Notification],bool]:
		start_ns=start_ts*_NS_PER_SECOND if start_ts is not _A else _A;end_ns=end_ts*_NS_PER_SECOND if end_ts is not _A else _A;conditions:t.List[exp.Expression]=[]
		if run_id is not _A:conditions.append(_col_eq(_E,run_id))
		elif plan_id is not _A:conditions.append(_col_eq(_F,plan_id))
		else:conditions.append(_col_eq(_C,environment or c.PROD))
		if start_ns is not _A:conditions.append(exp.GTE(this=exp.column(_B),expression=exp.Literal.number(start_ns)))
		if end_ns is not _A:conditions.append(exp.LTE(this=exp.column(_B),expression=exp.Literal.number(end_ns)))
		if environment is not _A and(run_id is not _A or plan_id is not _A):conditions.append(_col_eq(_C,environment))
		if events:conditions.append(exp.column(_D).isin(*[exp.Literal.string(event.value)for event in events]))
		query=exp.select(exp.column(_H),exp.column(_B),exp.column(_D),exp.column(_I),exp.column(_J),exp.column(_K),exp.column(_C),exp.column(_E),exp.column(_F)).from_(self.notifications_table).where(exp.and_(*conditions)).order_by(exp.Ordered(this=exp.column(_B),desc=_G)).limit(limit+1).offset(offset);rows=fetch_rows_as_dicts(self.engine_adapter,query);has_more=len(rows)>limit
		if has_more:rows=rows[:limit]
		return[self._row_to_notification(row)for row in rows],has_more
	def _row_to_notification(self,row:t.Dict[str,t.Any])->Notification:return Notification(id=row[_H],created_ts=int(row[_B])//_NS_PER_SECOND,event=row[_D],status=row[_I],summary=row[_J],payload=json_to_dict(row[_K]),environment=row[_C],run_id=row[_E],plan_id=row[_F])