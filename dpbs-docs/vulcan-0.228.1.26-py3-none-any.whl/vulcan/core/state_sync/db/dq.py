from __future__ import annotations
_A1='models_affected'
_A0='RunActivityWithChecksAndProfile'
_z='columnName'
_y='measured_at'
_x='partition_name'
_w='metric_name'
_v='column'
_u='scanEndTimestamp'
_t='scanStartTimestamp'
_s='not_evaluated'
_r='check_id'
_q='type'
_p='group_by'
_o='resource_attributes'
_n=False
_m='archetype'
_l='filter'
_k='start_ts'
_j='table'
_i='+00:00'
_h='profiled_at'
_g='location'
_f='unknown'
_e='metric_identity'
_d='dimension'
_c='definition'
_b='check_type'
_a='check_name'
_Z='end_ts'
_Y='identity'
_X='profile_type'
_W='outcome_reasons'
_V='json'
_U='number'
_T='metrics'
_S='value'
_R='bigint'
_Q='value_text'
_P='value_json'
_O='value_type'
_N='diagnostics'
_M='outcome'
_L='run_id'
_K='dataTime'
_J='value_number'
_I='column_name'
_H='model_name'
_G='check_identity'
_F='environment'
_E='id'
_D='created_ts'
_C=True
_B='text'
_A=None
import json,typing as t,logging
from collections import defaultdict
from sqlglot import exp
from decimal import Decimal
from datetime import date,datetime,timezone,timedelta
import pandas as pd
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.utils import fetchall,fetchone,json_to_dict,json_to_list,raise_if_not_postgres
from vulcan.utils.migration import index_text_type
from vulcan.utils.date import now_timestamp
from vulcan.utils import random_id,to_snake_case_keys
from vulcan.core.soda3 import _NAME_ATTR_KEY,_DIMENSION_ATTR_KEY
from vulcan.core.soda3.spec import CheckResult,CheckOutcome,CheckRuns,CheckResultWithRunId,ModelProfile,FieldStatistics,ScanResults,QualitySummary,ProductQualitySummary,validate_dq_dimension
if t.TYPE_CHECKING:from vulcan.core.activity import RunActivityWithChecksAndProfile
logger=logging.getLogger(__name__)
ProfileValueType=t.Literal[_U,_V,_B]
def _parse_metric_value(m:t.Dict[str,t.Any])->t.Any:
	vt:t.Optional[ProfileValueType]=m.get(_O)
	if vt==_U:
		v=m.get(_J)
		if v is _A:return
		try:f=float(v);return int(f)if f.is_integer()else f
		except(ValueError,TypeError):return v
	if vt==_V:
		raw=m.get(_P)
		if not raw:return
		try:return json.loads(raw)if isinstance(raw,str)else raw
		except(json.JSONDecodeError,TypeError):return raw
	return m.get(_Q)
def _parse_outcome_reasons(outcome_reasons:t.Any)->t.Optional[t.Dict[str,t.Any]]:
	A='message'
	if not outcome_reasons:return
	try:
		if isinstance(outcome_reasons,str):parsed=json.loads(outcome_reasons)
		else:parsed=outcome_reasons
		if isinstance(parsed,list):
			messages=[]
			for item in parsed:
				if isinstance(item,dict):messages.append(item.get(A,str(item)))
				else:messages.append(str(item))
			return{'messages':messages}
		return parsed if isinstance(parsed,dict)else{A:str(parsed)}
	except(json.JSONDecodeError,Exception):return{A:str(outcome_reasons)}
def _build_quality_list(checks:t.List[t.Any])->t.List[CheckResult]:
	result:t.List[CheckResult]=[]
	for d in checks:
		data=dict(d);data[_W]=_parse_outcome_reasons(data.get(_W));data[_N]=json_to_dict(data.get(_N))
		try:data[_M]=CheckOutcome(data.get(_M)or _s)
		except ValueError:data[_M]=CheckOutcome.NOT_EVALUATED
		result.append(CheckResult.model_validate(data))
	return result
def _build_profile_list(metrics:t.List[t.Any])->t.List[ModelProfile]:
	A='columns'
	if not metrics:return[]
	by_model:t.Dict[str,t.Dict[str,t.Any]]=defaultdict(lambda:{A:defaultdict(dict)})
	for m in metrics:
		model_name=m[_H];col=m.get(_I);ptype=m[_X];value=_parse_metric_value(m)
		if col is _A:by_model[model_name][ptype]=value
		else:by_model[model_name][A][col][ptype]=value
	return[ModelProfile(model_name=name,columns={c:FieldStatistics.model_validate(dict(d))for(c,d)in data[A].items()},**{k:v for(k,v)in data.items()if k!=A})for(name,data)in by_model.items()]
def _timestamp_to_iso(timestamp:int)->str:from datetime import datetime,timezone;dt=datetime.fromtimestamp(timestamp/1000,tz=timezone.utc);return dt.isoformat().replace(_i,'Z')
def format_data_time(value:t.Any)->str:
	if isinstance(value,int):dt=datetime.fromtimestamp(value/1000,tz=timezone.utc);return dt.isoformat().replace(_i,'Z')
	if isinstance(value,datetime):dt=value if value.tzinfo is not _A else value.replace(tzinfo=timezone.utc);dt=dt.astimezone(timezone.utc);return dt.isoformat().replace(_i,'Z')
	if isinstance(value,date):dt=datetime(value.year,value.month,value.day,tzinfo=timezone.utc);return dt.isoformat().replace(_i,'Z')
	if isinstance(value,str):return value
	raise ValueError(f"Unsupported type for dataTime: {type(value)}")
def convert_value(value:t.Any,column_name:t.Optional[str]=_A)->t.Any:
	if isinstance(value,Decimal):return float(value)
	if column_name==_K:return format_data_time(value)
	return value
def _parse_diagnostics(raw:t.Any)->t.Dict[str,t.Any]:return json_to_dict(raw)
class QualityState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A):self.engine_adapter=engine_adapter;self.schema=schema;self.check_results_table=exp.table_('_dq_results',db=schema);self.checks_definitions_table=exp.table_('_dq_definitions',db=schema);self.check_metrics_table=exp.table_('_dq_metrics',db=schema);self.profiles_table=exp.table_('_dq_profiles',db=schema);self.check_feedback_table=exp.table_('_dq_feedbacks',db=schema);self.runs_table=exp.table_('_runs',db=schema)
	def _store_checks_and_profile_results(self,scan_results:t.Dict[str,t.Any],run_id:str,environment:str)->str:
		scan_id=scan_results['scanId']
		try:
			checks_df,check_id_map=self._prepare_checks_dataframe(scan_results,run_id,environment);metrics_df=self._prepare_metrics_dataframe(scan_results,run_id,environment,check_id_map);profiles_df=self._prepare_profiles_dataframe(scan_results,run_id,environment)
			with self.engine_adapter.transaction():
				if not checks_df.empty:self._write_checks_batch(checks_df);self._upsert_checks_definitions(checks_df)
				if not metrics_df.empty:self._write_metrics_batch(metrics_df)
				if not profiles_df.empty:self._write_profiles_batch(profiles_df)
			logger.info(f"Stored check scan {scan_id}, run {run_id}: {len(checks_df)} checks, {len(metrics_df)} metrics, {len(profiles_df)} profile metrics");return scan_id
		except Exception as e:logger.error(f"Failed to store scan results for scan {scan_id}: {e}",exc_info=_C);raise
	def _prepare_checks_dataframe(self,scan_results:ScanResults,run_id:str,environment:str)->t.Tuple[pd.DataFrame,t.Dict[str,str]]:
		C='outcomeReasons';B='group';A='unnamed';all_checks=scan_results.get('checks',[])+scan_results.get('automatedMonitoringChecks',[])
		if not all_checks:return pd.DataFrame(),{}
		rows=[];check_id_map={};created_ts=now_timestamp()
		for check in all_checks:
			resource_attrs=check.get('resourceAttributes',{});dimension=_A
			if isinstance(resource_attrs,list):
				for attr in resource_attrs:
					if not isinstance(attr,dict):continue
					name=attr.get(_NAME_ATTR_KEY)
					if name==_DIMENSION_ATTR_KEY:dimension=attr.get(_S)
			elif isinstance(resource_attrs,dict):dimension=resource_attrs.get(_DIMENSION_ATTR_KEY)
			check_id=random_id();check_identity=check.get(_Y)
			if not check_identity:raise ValueError(f"Check missing 'identity' field. Check name: '{check.get(_NAME_ATTR_KEY,A)}', table: '{check.get(_j,_f)}'.")
			if not dimension or not str(dimension).strip():raise ValueError(f"Check missing '{_DIMENSION_ATTR_KEY}' in resourceAttributes. Check name: '{check.get(_NAME_ATTR_KEY,A)}', identity: '{check_identity}'.")
			dimension=validate_dq_dimension(dimension);metric_identities=check.get(_T,[])
			for metric_id in metric_identities:check_id_map[metric_id]=check_id,check_identity
			effective_model_name=check.get(_j,_f);diagnostics_json=_A;diagnostics=check.get(_N)
			if diagnostics:diagnostics_json=json.dumps(to_snake_case_keys(diagnostics))
			rows.append({_E:check_id,_L:run_id,_F:environment,_H:effective_model_name,_k:scan_results[_t],_Z:scan_results[_u],_G:check_identity,_a:check.get(_NAME_ATTR_KEY,A),_b:check.get(_q,_f),_c:check.get(_c),_d:dimension,_o:json.dumps(resource_attrs)if resource_attrs else _A,_g:json.dumps(check.get(_g))if check.get(_g)else _A,_p:json.dumps(check.get(B))if check.get(B)else _A,_I:check.get(_v),_l:check.get(_l),_T:json.dumps(check.get(_T))if check.get(_T)else _A,_M:check.get(_M)or CheckOutcome.NOT_EVALUATED.value,_W:json.dumps(check.get(C))if check.get(C)else _A,_m:check.get(_m),_N:diagnostics_json,_D:created_ts})
		return pd.DataFrame(rows),check_id_map
	def _prepare_metrics_dataframe(self,scan_results:ScanResults,run_id:str,environment:str,check_id_map:t.Dict[str,str])->pd.DataFrame:
		metrics_list=scan_results.get(_T,[])
		if not metrics_list:return pd.DataFrame()
		rows=[];created_ts=now_timestamp()
		for metric in metrics_list:
			metric_id=random_id();metric_identity=metric.get(_Y);check_mapping=check_id_map.get(metric_identity)
			if check_mapping:check_id,check_identity=check_mapping
			else:check_id,check_identity=_A,_A
			value=metric.get(_S);value_text,value_number,value_json,value_type=_A,_A,_A,_A
			if value is not _A:
				if isinstance(value,(int,float)):value_number=float(value);value_type=_U
				elif isinstance(value,str):value_text=value;value_type=_B
				elif isinstance(value,(dict,list)):value_json=json.dumps(value);value_type=_V
				else:value_json=json.dumps(value);value_type=_V
			rows.append({_E:metric_id,_L:run_id,_F:environment,_r:check_id,_G:check_identity or'',_e:metric.get(_Y),_w:metric.get('metricName')or metric.get(_NAME_ATTR_KEY,_f),_H:metric.get(_j,_f),_I:metric.get(_z)or metric.get(_v),_x:metric.get('partition'),_Q:value_text,_J:value_number,_P:value_json,_O:value_type,_y:metric.get(_K)or scan_results[_u],_D:created_ts})
		return pd.DataFrame(rows)
	def _prepare_profiles_dataframe(self,scan_results:ScanResults,run_id:str,environment:str)->pd.DataFrame:
		profiling=scan_results.get('profiling',[])
		if not profiling:return pd.DataFrame()
		rows=[];current_ts=now_timestamp();profiled_at=scan_results.get(_t,current_ts)
		for profile_table in profiling:
			model_name=profile_table.get(_j)
			if not model_name:continue
			full_model_name=model_name;row_count=profile_table.get('rowCount')
			if row_count is not _A:rows.append({_E:random_id(),_L:run_id,_F:environment,_H:full_model_name,_I:_A,_X:'row_count',_Q:_A,_J:float(row_count),_P:_A,_O:_U,_h:profiled_at,_D:current_ts})
			column_profiles=profile_table.get('columnProfiles',[])
			for col_profile in column_profiles:
				column_name=col_profile.get(_z);profile_data=col_profile.get('profile',{})
				if not column_name or not profile_data:continue
				for(metric_name,metric_value)in profile_data.items():
					if metric_value is _A:continue
					value_text=_A;value_number=_A;value_json=_A;value_type=_A
					if isinstance(metric_value,(int,float)):value_number=float(metric_value);value_type=_U
					elif isinstance(metric_value,str):
						try:value_number=float(metric_value);value_type=_U
						except(ValueError,TypeError):value_text=metric_value;value_type=_B
					elif isinstance(metric_value,(dict,list)):value_json=json.dumps(metric_value);value_type=_V
					else:value_text=str(metric_value);value_type=_B
					rows.append({_E:random_id(),_L:run_id,_F:environment,_H:full_model_name,_I:column_name,_X:metric_name,_Q:value_text,_J:value_number,_P:value_json,_O:value_type,_h:profiled_at,_D:current_ts})
			table_profile=profile_table.get('tableProfile',{})
			if table_profile:
				table_labels=table_profile.get('tableLabels')
				if table_labels:rows.append({_E:random_id(),_L:run_id,_F:environment,_H:full_model_name,_I:_A,_X:'table_labels',_Q:_A,_J:_A,_P:json.dumps(table_labels),_O:_V,_h:profiled_at,_D:current_ts})
		if not rows:return pd.DataFrame()
		return pd.DataFrame(rows)
	def _write_checks_batch(self,df:pd.DataFrame)->_A:index_type=index_text_type(self.engine_adapter.dialect);df_to_insert=df[[_E,_L,_F,_k,_Z,_G,_M,_W,_N,_D]].copy();self.engine_adapter.insert_append(self.check_results_table,df_to_insert,target_columns_to_types={_E:exp.DataType.build(index_type),_L:exp.DataType.build(index_type),_F:exp.DataType.build(index_type),_k:exp.DataType.build(_R),_Z:exp.DataType.build(_R),_G:exp.DataType.build(index_type),_M:exp.DataType.build(_B),_W:exp.DataType.build(_B),_N:exp.DataType.build(_B),_D:exp.DataType.build(_R)},track_rows_processed=_n)
	def _upsert_checks_definitions(self,df:pd.DataFrame)->_A:
		A='updated_ts'
		if df.empty:return
		distinct=df.drop_duplicates(subset=[_G,_F],keep='last')[[_G,_F,_a,_b,_I,_d,_c,_H,_o,_g,_p,_l,_T,_m,_Z]].copy();distinct=distinct.rename(columns={_Z:A});index_type=index_text_type(self.engine_adapter.dialect);target_columns_to_types={_G:exp.DataType.build(index_type),_F:exp.DataType.build(index_type),_a:exp.DataType.build(_B),_b:exp.DataType.build(_B),_I:exp.DataType.build(_B),_d:exp.DataType.build(_B),_c:exp.DataType.build(_B),_H:exp.DataType.build(index_type),_o:exp.DataType.build(_B),_g:exp.DataType.build(_B),_p:exp.DataType.build(_B),_l:exp.DataType.build(_B),_T:exp.DataType.build(_B),_m:exp.DataType.build(_B),A:exp.DataType.build(_R)};self.engine_adapter.merge(self.checks_definitions_table,distinct,target_columns_to_types=target_columns_to_types,unique_key=(exp.column(_G),exp.column(_F)))
	def _write_metrics_batch(self,df:pd.DataFrame)->_A:index_type=index_text_type(self.engine_adapter.dialect);self.engine_adapter.insert_append(self.check_metrics_table,df,target_columns_to_types={_E:exp.DataType.build(index_type),_L:exp.DataType.build(index_type),_F:exp.DataType.build(index_type),_r:exp.DataType.build(index_type),_G:exp.DataType.build(index_type),_e:exp.DataType.build(index_type),_w:exp.DataType.build(index_type),_H:exp.DataType.build(index_type),_I:exp.DataType.build(_B),_x:exp.DataType.build(_B),_Q:exp.DataType.build(_B),_J:exp.DataType.build('numeric'),_P:exp.DataType.build(_B),_O:exp.DataType.build(_B),_y:exp.DataType.build(_R),_D:exp.DataType.build(_R)},track_rows_processed=_n)
	def _write_profiles_batch(self,df:pd.DataFrame)->_A:index_type=index_text_type(self.engine_adapter.dialect);column_order=[_E,_L,_F,_H,_I,_X,_Q,_J,_P,_O,_h,_D];df=df[column_order];self.engine_adapter.insert_append(self.profiles_table,df,target_columns_to_types={_E:exp.DataType.build(index_type),_L:exp.DataType.build(index_type),_F:exp.DataType.build(index_type),_H:exp.DataType.build(index_type),_I:exp.DataType.build(_B),_X:exp.DataType.build(_B),_Q:exp.DataType.build(_B),_J:exp.DataType.build('numeric'),_P:exp.DataType.build(_B),_O:exp.DataType.build(_B),_h:exp.DataType.build(_R),_D:exp.DataType.build(_R)},track_rows_processed=_n)
	def _get_historic_measurements(self,metric_identity:str,limit:int=100)->t.List[t.Dict[str,t.Any]]:
		try:
			query=exp.select(exp.column(_E),exp.column(_e).as_(_Y),exp.column(_J).as_(_S),exp.column(_D).as_(_K)).from_(self.check_metrics_table).where(exp.and_(exp.EQ(this=exp.column(_e),expression=exp.Literal.string(metric_identity)),exp.Is(this=exp.column(_J),expression=exp.Null()).not_())).order_by(exp.column(_D),desc=_C).limit(limit);rows=fetchall(self.engine_adapter,query);results:t.List[t.Dict[str,t.Any]]=[]
			for row in rows:id_,identity,value_number,created_ts=row;value=convert_value(value_number,_S);data_time=convert_value(created_ts,_K);results.append({_E:id_,_Y:identity,_S:value,_K:data_time})
			logger.debug(f"Fetched {len(results)} historic measurements for metric '{metric_identity}'");return results
		except Exception as e:logger.error(f"Failed to fetch historic measurements for '{metric_identity}': {e}",exc_info=_C);return[]
	def _get_historic_check_results(self,check_identity:str,limit:int=100)->t.List[t.Dict[str,t.Any]]:
		E='measurementId';D='testResultId';C='m';B='cd';A='c'
		try:
			c=exp.to_table(self.check_results_table).as_(A);m=exp.to_table(self.check_metrics_table).as_(C);cd=exp.to_table(self.checks_definitions_table).as_(B);select_exprs=[exp.column(_b,table=B).as_(_q),exp.column(_E,table=A).as_(D),exp.column(_M,table=A),exp.column(_D,table=A).as_(_K),exp.column(_N,table=A),exp.column(_E,table=C).as_(E)];query=exp.select(*select_exprs).from_(c).join(cd,on=exp.and_(exp.EQ(this=exp.column(_G,table=A),expression=exp.column(_G,table=B)),exp.EQ(this=exp.column(_F,table=A),expression=exp.column(_F,table=B))),join_type='inner').join(m,on=exp.EQ(this=exp.column(_E,table=A),expression=exp.column(_r,table=C)),join_type='left').where(exp.EQ(this=exp.column(_G,table=A),expression=exp.Literal.string(check_identity))).order_by(exp.Ordered(this=exp.column(_D,table=A),desc=_C)).limit(limit);rows=fetchall(self.engine_adapter,query);results:t.List[t.Dict[str,t.Any]]=[]
			for row in rows:type,test_result_id,outcome,created_ts,diagnostics_raw,measurement_id=row;data_time=convert_value(created_ts,_K);diagnostics=_parse_diagnostics(diagnostics_raw);results.append({_q:type,D:test_result_id,_M:outcome,_K:data_time,_N:diagnostics,E:measurement_id})
			logger.debug(f"Fetched {len(results)} historic check results for check '{check_identity}'");return results
		except Exception as e:logger.error(f"Failed to fetch historic check results for '{check_identity}': {e}",exc_info=_C);return[]
	def _get_historic_metric_change_over_time(self,metric_identity:str,same_day_last_week:bool=_n)->t.List[t.Dict[str,t.Any]]:
		try:
			conditions:t.List[exp.Expression]=[exp.EQ(this=exp.column(_e),expression=exp.Literal.string(metric_identity))];previous_time_start=_A;previous_time_end=_A;today=date.today()
			if same_day_last_week:last_week=today-timedelta(days=7);previous_time_start=datetime(year=last_week.year,month=last_week.month,day=last_week.day,tzinfo=timezone.utc);previous_time_end=datetime(year=last_week.year,month=last_week.month,day=last_week.day,hour=23,minute=59,second=59,tzinfo=timezone.utc)
			if previous_time_start and previous_time_end:start_ms=int(previous_time_start.timestamp()*1000);end_ms=int(previous_time_end.timestamp()*1000);conditions.append(exp.GT(this=exp.column(_D),expression=exp.Literal.number(start_ms)));conditions.append(exp.LTE(this=exp.column(_D),expression=exp.Literal.number(end_ms)))
			query=exp.select(exp.column(_E),exp.column(_e),exp.column(_J),exp.column(_D).as_(_K)).from_(self.check_metrics_table).where(exp.and_(*conditions)).order_by(exp.column(_D));rows=fetchall(self.engine_adapter,query);results:t.List[t.Dict[str,t.Any]]=[]
			for row in rows:measurement_id,identity,value_number,data_time=row;results.append({_E:measurement_id,_Y:identity,_S:convert_value(value_number,_S),_K:convert_value(data_time,_K)})
			logger.debug(f"Fetched {len(results)} historic changes over time for '{metric_identity}'");return results
		except Exception as e:logger.error(f"Failed to fetch change-over-time data for '{metric_identity}': {e}",exc_info=_C);return[]
	def get_check_identity_by_natural_key(self,environment:str,model_name:str,dimension:str,check_name:str)->t.Optional[str]:
		where=exp.and_(exp.EQ(this=exp.column(_F),expression=exp.Literal.string(environment)),exp.EQ(this=exp.column(_H),expression=exp.Literal.string(model_name)),exp.EQ(this=exp.column(_d),expression=exp.Literal.string(dimension)),exp.EQ(this=exp.column(_a),expression=exp.Literal.string(check_name)));query=exp.select(exp.column(_G)).from_(self.checks_definitions_table).where(where).limit(1)
		with self.engine_adapter.transaction():row=fetchone(self.engine_adapter,query)
		return row[0]if row else _A
	def list_checks(self,environment:str,check_identity:t.Optional[str]=_A,model_names:t.Optional[t.List[str]]=_A,column_name:t.Optional[str]=_A,dimension:t.Optional[str]=_A,runs_per_check:int=10,limit:int=100,offset:int=0,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A)->t.List[CheckRuns]:
		raise_if_not_postgres(self.engine_adapter,feature='list_checks')
		if not environment:return[]
		defs_tbl=self.checks_definitions_table.sql(dialect=self.engine_adapter.dialect,identify=_C);results_tbl=self.check_results_table.sql(dialect=self.engine_adapter.dialect,identify=_C);start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A
		def _row_to_check_run(row:t.Dict[str,t.Any])->CheckResultWithRunId:
			try:outcome=CheckOutcome(row.get(_M)or _s)
			except ValueError:outcome=CheckOutcome.NOT_EVALUATED
			return CheckResultWithRunId(check_identity=row[_G],check_name=row[_a],check_type=row[_b],column_name=row[_I],dimension=row[_d],definition=row[_c],model_name=row[_H],outcome=outcome,outcome_reasons=_parse_outcome_reasons(row.get(_W)),diagnostics=_parse_diagnostics(row.get(_N))if outcome!=CheckOutcome.PASS else{},run_id=row[_L],start_ts=row[_k],end_ts=row[_Z])
		if check_identity:rn_min,rn_max=offset,offset+limit;out_limit,out_offset=1,0
		else:rn_min,rn_max=0,runs_per_check;out_limit,out_offset=limit,offset
		sql=f"""
        WITH checks_from_def AS (
            SELECT check_identity, check_name, check_type, column_name, dimension, definition, model_name
            FROM {defs_tbl}
            WHERE environment = %s
              AND (%s IS NULL OR check_identity = %s)
              AND (%s IS NULL OR model_name = ANY(%s))
              AND (%s IS NULL OR column_name = %s)
              AND (%s IS NULL OR dimension = %s)
            ORDER BY model_name NULLS LAST, column_name NULLS LAST, check_name
            LIMIT %s OFFSET %s
        ),
        ranked AS (
            SELECT cr.*,
                ROW_NUMBER() OVER (PARTITION BY cr.check_identity ORDER BY cr.start_ts DESC) AS rn
            FROM {results_tbl} cr
            WHERE cr.environment = %s
              AND cr.check_identity IN (SELECT check_identity FROM checks_from_def)
              AND (%s IS NULL OR cr.start_ts >= %s)
              AND (%s IS NULL OR cr.start_ts <= %s)
        )
        SELECT
            d.check_identity,
            d.check_name,
            d.check_type,
            d.column_name,
            d.dimension,
            d.definition,
            d.model_name,
            COALESCE(
                jsonb_agg(
                    jsonb_build_object(
                        'run_id', r.run_id,
                        'start_ts', r.start_ts,
                        'end_ts', r.end_ts,
                        'check_identity', d.check_identity,
                        'check_name', d.check_name,
                        'check_type', d.check_type,
                        'model_name', d.model_name,
                        'column_name', d.column_name,
                        'dimension', d.dimension,
                        'definition', d.definition,
                        'outcome', r.outcome,
                        'outcome_reasons', r.outcome_reasons,
                        'diagnostics', r.diagnostics
                    ) ORDER BY r.start_ts DESC
                ) FILTER (WHERE r.rn > %s AND r.rn <= %s),
                '[]'::jsonb
            ) AS runs_json
        FROM checks_from_def d
        LEFT JOIN ranked r ON r.check_identity = d.check_identity
        GROUP BY d.check_identity, d.check_name, d.check_type, d.column_name, d.dimension, d.definition, d.model_name
        ORDER BY d.model_name NULLS LAST, d.column_name NULLS LAST, d.check_name
        """;params=environment,check_identity,check_identity,model_names,model_names,column_name,column_name,dimension,dimension,out_limit,out_offset,environment,start_ms,start_ms,end_ms,end_ms,rn_min,rn_max
		try:
			rows=fetchall(self.engine_adapter,sql,params)
			if not rows:return[]
			result=[]
			for row in rows:check_identity_val,check_name,check_type,column_name_val,dimension_val,definition,model_name,runs_json=row;metadata={_G:check_identity_val,_a:check_name,_b:check_type,_I:column_name_val,_d:dimension_val,_c:definition,_H:model_name};runs_list=json_to_list(runs_json);runs=[_row_to_check_run({**r,**metadata})for r in runs_list if isinstance(r,dict)];result.append(CheckRuns(**metadata,runs=runs))
			return result
		except Exception as e:logger.error(f"Failed to fetch checks: {e}",exc_info=_C);return[]
	def list_runs(self,run_id:t.Optional[str]=_A,environment:t.Optional[str]=_A,model_names:t.Optional[t.List[str]]=_A,success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[RunActivityWithChecksAndProfile]:
		raise_if_not_postgres(self.engine_adapter,feature='list_runs');from vulcan.core.activity import RunActivity,RunActivityWithChecksAndProfile;runs_tbl=self.runs_table.sql(dialect=self.engine_adapter.dialect,identify=_C);checks_tbl=self.check_results_table.sql(dialect=self.engine_adapter.dialect,identify=_C);defs_tbl=self.checks_definitions_table.sql(dialect=self.engine_adapter.dialect,identify=_C);profiles_tbl=self.profiles_table.sql(dialect=self.engine_adapter.dialect,identify=_C);start_ms=start_ts*1000 if start_ts else _A;end_ms=end_ts*1000 if end_ts else _A;where_sql='';limit_sql='';params:t.List[t.Any]=[]
		if run_id:where_sql='run_id = %s';params.append(run_id)
		else:
			if environment is _A:return[]
			where_parts=['environment = %s'];params.append(environment)
			if model_names:where_parts.append('models_affected && %s');params.append(model_names)
			if success is not _A:where_parts.append('success = %s');params.append(success)
			if start_ms is not _A:where_parts.append('start_ts >= %s');params.append(start_ms)
			if end_ms is not _A:where_parts.append('start_ts <= %s');params.append(end_ms)
			where_sql=' AND '.join(where_parts);limit_sql='LIMIT %s OFFSET %s';params.extend([limit,offset])
		qc_model_filter=' AND cd.model_name = ANY(%s)'if model_names else'';pm_model_filter=' AND model_name = ANY(%s)'if model_names else''
		if model_names:params.extend([model_names,model_names])
		query=f"""
        WITH runs AS (
            SELECT
                run_data,
                run_seq,
                run_id,
                start_ts
            FROM {runs_tbl}
            WHERE {where_sql}
            ORDER BY start_ts DESC
            {limit_sql}
        ),
        quality_checks AS (
            SELECT
                cr.run_id,
                cd.model_name,
                cd.dimension,
                cr.check_identity,
                cd.check_name,
                cd.check_type,
                cd.column_name,
                cr.outcome,
                cr.outcome_reasons,
                cr.diagnostics,
                cd.definition
            FROM {checks_tbl} cr
            INNER JOIN {defs_tbl} cd
                ON cr.check_identity = cd.check_identity
               AND cr.environment = cd.environment
            WHERE cr.run_id IN (SELECT run_id FROM runs){qc_model_filter}
            ORDER BY
                cr.run_id,
                cd.model_name,
                cd.dimension,
                cd.check_name
        ),
        profile_metrics AS (
            SELECT
                run_id,
                model_name,
                column_name,
                profile_type,
                value_text,
                value_number,
                value_json,
                value_type
            FROM {profiles_tbl}
            WHERE run_id IN (SELECT run_id FROM runs){pm_model_filter}
            ORDER BY
                run_id,
                model_name,
                column_name,
                profile_type
        )
        SELECT
            r.run_data,
            r.run_seq,
            (
                SELECT COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'model_name', qc.model_name,
                            'dimension', qc.dimension,
                            'check_identity', qc.check_identity,
                            'check_name', qc.check_name,
                            'check_type', qc.check_type,
                            'column_name', qc.column_name,
                            'outcome', qc.outcome,
                            'outcome_reasons', qc.outcome_reasons,
                            'diagnostics', qc.diagnostics,
                            'definition', qc.definition
                        )
                        ORDER BY
                            qc.model_name,
                            qc.dimension,
                            qc.check_name
                    ),
                    '[]'::jsonb
                )
                FROM quality_checks qc
                WHERE qc.run_id = r.run_id
            ) AS quality_checks,
            (
                SELECT COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'model_name', pm.model_name,
                            'column_name', pm.column_name,
                            'profile_type', pm.profile_type,
                            'value_text', pm.value_text,
                            'value_number', pm.value_number,
                            'value_json', pm.value_json,
                            'value_type', pm.value_type
                        )
                        ORDER BY
                            pm.model_name,
                            pm.column_name,
                            pm.profile_type
                    ),
                    '[]'::jsonb
                )
                FROM profile_metrics pm
                WHERE pm.run_id = r.run_id
            ) AS profile_metrics
        FROM runs r
        ORDER BY r.start_ts DESC
        """;rows=fetchall(self.engine_adapter,query,params)
		if not rows:return[]
		runs:t.List[_A0]=[]
		for row in rows:
			run_data,seq,quality_raw,profile_raw=row;quality_data=json_to_list(quality_raw);profile_data=json_to_list(profile_raw);run=RunActivity.model_validate(run_data).model_copy(update={'run_seq':seq})
			if model_names:models_set=set(model_names);run=run.model_copy(update={_A1:[m for m in run.models_affected if m.name in models_set]})
			quality=_build_quality_list(quality_data);profile=_build_profile_list(profile_data);runs.append(RunActivityWithChecksAndProfile(**run.model_dump(exclude_none=_C),quality=quality,profile=profile))
		return runs
	def list_latest_runs_by_model(self,environment:str,model_names:t.List[str])->t.Dict[str,RunActivityWithChecksAndProfile]:
		raise_if_not_postgres(self.engine_adapter,feature='list_latest_runs_by_model');from vulcan.core.activity import RunActivity,RunActivityWithChecksAndProfile
		if not environment or not model_names:return{}
		runs_tbl=self.runs_table.sql(dialect=self.engine_adapter.dialect,identify=_C);checks_tbl=self.check_results_table.sql(dialect=self.engine_adapter.dialect,identify=_C);defs_tbl=self.checks_definitions_table.sql(dialect=self.engine_adapter.dialect,identify=_C);profiles_tbl=self.profiles_table.sql(dialect=self.engine_adapter.dialect,identify=_C);query=f"""
        WITH expanded AS (
            SELECT
                r.run_data,
                r.run_seq,
                r.run_id,
                r.start_ts,
                model_name,
                ROW_NUMBER() OVER (
                    PARTITION BY model_name
                    ORDER BY r.start_ts DESC
                ) AS rn
            FROM {runs_tbl} r
            CROSS JOIN LATERAL unnest(r.models_affected) AS model_name
            WHERE r.environment = %s
              AND r.models_affected IS NOT NULL
              AND model_name = ANY(%s)
        ),
        latest AS (
            SELECT
                run_data,
                run_seq,
                run_id,
                model_name
            FROM expanded
            WHERE rn = 1
        ),
        quality_checks AS (
            SELECT
                cr.run_id,
                cd.model_name,
                cd.dimension,
                cr.check_identity,
                cd.check_name,
                cd.check_type,
                cd.column_name,
                cr.outcome,
                cr.outcome_reasons,
                cr.diagnostics,
                cd.definition
            FROM {checks_tbl} cr
            INNER JOIN {defs_tbl} cd
                ON cr.check_identity = cd.check_identity
               AND cr.environment = cd.environment
            WHERE cr.run_id IN (SELECT run_id FROM latest)
              AND cd.model_name = ANY(%s)
            ORDER BY
                cr.run_id,
                cd.model_name,
                cd.dimension,
                cd.check_name
        ),
        profile_metrics AS (
            SELECT
                run_id,
                model_name,
                column_name,
                profile_type,
                value_text,
                value_number,
                value_json,
                value_type
            FROM {profiles_tbl}
            WHERE run_id IN (SELECT run_id FROM latest)
              AND model_name = ANY(%s)
            ORDER BY
                run_id,
                model_name,
                column_name,
                profile_type
        )
        SELECT
            l.model_name,
            l.run_data,
            l.run_seq,
            (
                SELECT COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'model_name', qc.model_name,
                            'dimension', qc.dimension,
                            'check_identity', qc.check_identity,
                            'check_name', qc.check_name,
                            'check_type', qc.check_type,
                            'column_name', qc.column_name,
                            'outcome', qc.outcome,
                            'outcome_reasons', qc.outcome_reasons,
                            'diagnostics', qc.diagnostics,
                            'definition', qc.definition
                        )
                        ORDER BY
                            qc.dimension,
                            qc.check_name
                    ),
                    '[]'::jsonb
                )
                FROM quality_checks qc
                WHERE qc.run_id = l.run_id
                  AND qc.model_name = l.model_name
            ) AS quality_checks,
            (
                SELECT COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'model_name', pm.model_name,
                            'column_name', pm.column_name,
                            'profile_type', pm.profile_type,
                            'value_text', pm.value_text,
                            'value_number', pm.value_number,
                            'value_json', pm.value_json,
                            'value_type', pm.value_type
                        )
                        ORDER BY
                            pm.column_name,
                            pm.profile_type
                    ),
                    '[]'::jsonb
                )
                FROM profile_metrics pm
                WHERE pm.run_id = l.run_id
                  AND pm.model_name = l.model_name
            ) AS profile_metrics
        FROM latest l
        """;params:t.List[t.Any]=[environment,model_names,model_names,model_names];rows=fetchall(self.engine_adapter,query,params)
		if not rows:return{}
		result:t.Dict[str,_A0]={}
		for(model_name,run_data,seq,quality_raw,profile_raw)in rows:quality_data=json_to_list(quality_raw);profile_data=json_to_list(profile_raw);run=RunActivity.model_validate(run_data).model_copy(update={'run_seq':seq});run=run.model_copy(update={_A1:[m for m in run.models_affected or[]if m.name==model_name]});result[model_name]=RunActivityWithChecksAndProfile(**run.model_dump(exclude_none=_C),quality=_build_quality_list(quality_data),profile=_build_profile_list(profile_data))
		return result
	def get_quality_summary(self,environment:str,as_of_ts:t.Optional[int]=_A)->t.Optional[ProductQualitySummary]:
		raise_if_not_postgres(self.engine_adapter,feature='get_quality_summary');check_results_table_str=str(self.check_results_table);checks_definitions_table_str=str(self.checks_definitions_table);as_of_ms=as_of_ts*1000 if as_of_ts is not _A else _A;sql="\n        WITH latest_with_dimension AS (\n            SELECT DISTINCT ON (cd.check_identity, cd.environment)\n                cd.check_identity,\n                cr.outcome,\n                cr.end_ts,\n                cd.dimension\n            FROM {checks_definitions_table} cd\n            INNER JOIN {check_results_table} cr\n                ON cr.check_identity = cd.check_identity\n               AND cr.environment = cd.environment\n            WHERE cd.environment = %s\n              AND (%s IS NULL OR cr.start_ts <= %s)\n            ORDER BY\n                cd.check_identity,\n                cd.environment,\n                cr.start_ts DESC\n        ),\n        stats AS (\n            SELECT\n                dimension,\n                COUNT(*) FILTER (WHERE outcome = 'pass') AS pass_count,\n                COUNT(*) FILTER (WHERE outcome = 'fail') AS fail_count,\n                COUNT(*) FILTER (WHERE outcome = 'warn') AS warn_count,\n                COUNT(*) FILTER (WHERE outcome = 'error') AS error_count,\n                COUNT(*) FILTER (WHERE outcome = 'not_evaluated') AS not_evaluated_count,\n                COUNT(*) AS total_count,\n                MAX(end_ts) AS latest_evaluated_at,\n                COUNT(*) AS checks_count\n            FROM latest_with_dimension\n            GROUP BY GROUPING SETS ((dimension), ())\n        )\n        SELECT\n            COALESCE(\n                MAX(s.latest_evaluated_at) FILTER (WHERE s.dimension IS NULL),\n                0\n            ) AS latest_evaluated_at,\n            COALESCE(\n                MAX(s.checks_count) FILTER (WHERE s.dimension IS NULL),\n                0\n            )::int AS checks_count,\n            COALESCE(\n                jsonb_object_agg(\n                    s.dimension,\n                    jsonb_build_object(\n                        'pass', s.pass_count,\n                        'fail', s.fail_count,\n                        'warn', s.warn_count,\n                        'error', s.error_count,\n                        'not_evaluated', s.not_evaluated_count,\n                        'total', s.total_count,\n                        'pass_rate', ROUND(\n                            s.pass_count::NUMERIC\n                            / NULLIF(s.total_count, 0) * 100,\n                            1\n                        )\n                    )\n                ) FILTER (WHERE s.dimension IS NOT NULL),\n                '{{}}'::jsonb\n            ) AS dimensions,\n            COALESCE(\n                SUM(s.pass_count) FILTER (WHERE s.dimension IS NULL),\n                0\n            )::int AS total_pass,\n            COALESCE(\n                SUM(s.fail_count) FILTER (WHERE s.dimension IS NULL),\n                0\n            )::int AS total_fail,\n            COALESCE(\n                SUM(s.warn_count) FILTER (WHERE s.dimension IS NULL),\n                0\n            )::int AS total_warn,\n            COALESCE(\n                SUM(s.error_count) FILTER (WHERE s.dimension IS NULL),\n                0\n            )::int AS total_error,\n            COALESCE(\n                SUM(s.not_evaluated_count) FILTER (WHERE s.dimension IS NULL),\n                0\n            )::int AS total_not_evaluated,\n            COALESCE(\n                SUM(s.total_count) FILTER (WHERE s.dimension IS NULL),\n                0\n            )::int AS total_checks\n        FROM stats s\n        ".format(check_results_table=check_results_table_str,checks_definitions_table=checks_definitions_table_str);params=environment,as_of_ms,as_of_ms
		try:row=fetchone(self.engine_adapter,sql,params)
		except Exception as e:logger.error(f"Failed to execute get_quality_summary query: {e}");logger.debug(f"SQL query: {sql}");logger.debug(f"Params: {params}");raise
		if not row:return
		try:latest_evaluated_at,checks_count,dimensions_json,total_pass,total_fail,total_warn,total_error,total_not_evaluated,total_checks=row
		except(ValueError,TypeError)as e:logger.error(f"Failed to unpack get_quality_summary result: {e}");logger.debug(f"Row: {row}");raise
		if checks_count==0:return
		dimensions={};dim_dict=json_to_dict(dimensions_json)
		if dim_dict:
			try:dimensions={dim:QualitySummary(**stats)for(dim,stats)in dim_dict.items()}
			except(TypeError,ValueError)as e:logger.warning(f"Failed to parse dimensions for get_quality_summary: {e}")
		pass_rate=round(float(total_pass)/total_checks*100,1)if total_checks and total_checks>0 else .0;summary=QualitySummary(pass_=total_pass or 0,fail=total_fail or 0,warn=total_warn or 0,error=total_error or 0,not_evaluated=total_not_evaluated or 0,total=total_checks or 0,pass_rate=pass_rate);return ProductQualitySummary(environment=environment,as_of_ts=as_of_ts,latest_evaluated_at=latest_evaluated_at or 0,checks_count=checks_count or 0,dimensions=dimensions,summary=summary)