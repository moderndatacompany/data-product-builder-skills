from __future__ import annotations
_L=False
_K='period_start'
_J='bucket_index'
_I='metadata'
_H='period_end'
_G='updated_at'
_F='followed_at'
_E='user_id'
_D=True
_C='active'
_B='b'
_A=None
import json,time,typing as t
from calendar import monthrange
from dataclasses import dataclass
from datetime import datetime,timedelta,timezone
import pandas as pd
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.follower import Follower,FollowerAnalytics,FollowerAnalyticsPagination,FollowerAnalyticsPeriod,FollowerGranularity
from vulcan.core.state_sync.db.utils import fetch_row_as_dict,fetch_rows_as_dicts,fetchall,json_to_dict
from vulcan.utils.migration import index_text_type
MAX_ANALYTICS_LIMIT=365
@dataclass(frozen=_D)
class FollowerBucketSpec:bucket_index:int;period_start:int;period_end:int
def _ts_from_utc(dt:datetime)->int:return int(dt.timestamp())
def _floor_day(dt:datetime)->datetime:return dt.replace(hour=0,minute=0,second=0,microsecond=0)
def _floor_week(dt:datetime)->datetime:floored_day=_floor_day(dt);return floored_day-timedelta(days=floored_day.weekday())
def _floor_month(dt:datetime)->datetime:return dt.replace(day=1,hour=0,minute=0,second=0,microsecond=0)
def _add_months(dt:datetime,months:int)->datetime:month_index=dt.month-1+months;year=dt.year+month_index//12;month=month_index%12+1;day=min(dt.day,monthrange(year,month)[1]);return dt.replace(year=year,month=month,day=day)
def _bucket_bounds_for_index(bucket_index:int,granularity:FollowerGranularity,now:datetime)->tuple[datetime,datetime]:
	if bucket_index<0:raise ValueError('bucket_index must be non-negative')
	if granularity==FollowerGranularity.DAY:
		if bucket_index==0:return _floor_day(now),now
		today_midnight=_floor_day(now);period_end=today_midnight-timedelta(days=bucket_index-1);return period_end-timedelta(days=1),period_end
	if granularity==FollowerGranularity.WEEK:
		if bucket_index==0:return _floor_week(now),now
		current_week_start=_floor_week(now);period_end=current_week_start-timedelta(weeks=bucket_index-1);return period_end-timedelta(weeks=1),period_end
	if bucket_index==0:return _floor_month(now),now
	current_month_start=_floor_month(now);period_end=_add_months(current_month_start,-(bucket_index-1));period_start=_add_months(current_month_start,-bucket_index);return period_start,period_end
def _validate_analytics_pagination(*,limit:int,offset:int)->_A:
	if limit<1 or limit>MAX_ANALYTICS_LIMIT:raise ValueError(f"limit must be between 1 and {MAX_ANALYTICS_LIMIT}")
	if offset<0:raise ValueError('offset must be non-negative')
def _build_analytics_bucket_specs(*,granularity:FollowerGranularity,offset:int,limit:int,now:t.Optional[datetime]=_A)->t.List[FollowerBucketSpec]:
	_validate_analytics_pagination(limit=limit,offset=offset);anchor=now or datetime.now(timezone.utc);specs:t.List[FollowerBucketSpec]=[]
	for bucket_index in range(offset,offset+limit):period_start,period_end=_bucket_bounds_for_index(bucket_index,granularity,anchor);specs.append(FollowerBucketSpec(bucket_index=bucket_index,period_start=_ts_from_utc(period_start),period_end=_ts_from_utc(period_end)))
	return specs
def _analytics_active_at_period_end_condition()->exp.Expression:return exp.and_(exp.LTE(this=exp.column(_F,'f'),expression=exp.column(_H,_B)),exp.or_(exp.column(_C,'f').eq(exp.true()),exp.GT(this=exp.column(_G,'f'),expression=exp.column(_H,_B))))
def _analytics_buckets_subquery(bucket_specs:t.Sequence[FollowerBucketSpec])->exp.Subquery:return exp.select(exp.column(_J),exp.column(_K),exp.column(_H)).from_(exp.values([(spec.bucket_index,spec.period_start,spec.period_end)for spec in bucket_specs],alias='buckets',columns=[_J,_K,_H])).subquery(_B)
class FollowerState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A)->_A:A='bigint';self.engine_adapter=engine_adapter;self.schema=schema;self.followers_table=exp.table_('_followers',db=schema);index_type=index_text_type(engine_adapter.dialect);self._followers_columns_to_types={_E:exp.DataType.build(index_type),_C:exp.DataType.build('boolean'),_F:exp.DataType.build(A),_G:exp.DataType.build(A),_I:exp.DataType.build('jsonb')}
	def follow(self,user_id:str,metadata:t.Optional[t.Dict[str,t.Any]]=_A)->Follower:
		existing=self.get_follower(user_id);now_ts=int(time.time())
		if existing is _A:payload_metadata=metadata or{};df=pd.DataFrame([{_E:user_id,_C:_D,_F:now_ts,_G:now_ts,_I:json.dumps(payload_metadata)}]);self.engine_adapter.insert_append(self.followers_table,df,target_columns_to_types=self._followers_columns_to_types,track_rows_processed=_L);return Follower(user_id=user_id,active=_D,followed_at=now_ts,updated_at=now_ts,metadata=payload_metadata)
		if existing.active:return existing
		merged_metadata=existing.metadata
		if metadata:merged_metadata={**existing.metadata,**metadata}
		self._update_follower(user_id,active=_D,updated_at=now_ts,metadata=merged_metadata);return Follower(user_id=user_id,active=_D,followed_at=existing.followed_at,updated_at=now_ts,metadata=merged_metadata)
	def unfollow(self,user_id:str)->Follower:
		existing=self.get_follower(user_id)
		if existing is _A:raise ValueError(f"User {user_id!r} is not a follower")
		if not existing.active:return existing
		now_ts=int(time.time());self._update_follower(user_id,active=_L,updated_at=now_ts);return Follower(user_id=user_id,active=_L,followed_at=existing.followed_at,updated_at=now_ts,metadata=existing.metadata)
	def get_follower(self,user_id:str)->t.Optional[Follower]:
		query=exp.select(exp.column(_E),exp.column(_C),exp.column(_F),exp.column(_G),exp.column(_I)).from_(self.followers_table).where(exp.column(_E).eq(user_id));row=fetch_row_as_dict(self.engine_adapter,query)
		if row is _A:return
		return self._row_to_follower(row)
	def list_followers(self,*,active_only:bool=_D,limit:int=50,offset:int=0)->t.Tuple[t.List[Follower],bool]:
		conditions:t.List[exp.Expression]=[]
		if active_only:conditions.append(exp.column(_C).eq(exp.true()))
		query=exp.select(exp.column(_E),exp.column(_C),exp.column(_F),exp.column(_G),exp.column(_I)).from_(self.followers_table).where(exp.and_(*conditions)if conditions else _A).order_by(exp.Ordered(this=exp.column(_F),desc=_D)).limit(limit+1).offset(offset);rows=fetch_rows_as_dicts(self.engine_adapter,query);has_more=len(rows)>limit
		if has_more:rows=rows[:limit]
		return[self._row_to_follower(row)for row in rows],has_more
	def get_follower_analytics(self,*,granularity:t.Optional[FollowerGranularity]=_A,limit:int=30,offset:int=0)->FollowerAnalytics:
		total_active=self._count_current_active_followers()
		if granularity is _A:return FollowerAnalytics(total_active=total_active)
		bucket_specs=_build_analytics_bucket_specs(granularity=granularity,offset=offset,limit=limit);series=self._query_active_followers_by_buckets(bucket_specs);return self._build_analytics_response(total_active=total_active,granularity=granularity,offset=offset,limit=limit,series=series)
	def _count_current_active_followers(self)->int:A='count';query=exp.select(exp.Count(this=exp.Star()).as_(A)).from_(self.followers_table).where(exp.column(_C).eq(exp.true()));row=fetch_row_as_dict(self.engine_adapter,query);return int(row[A])if row else 0
	def _query_active_followers_by_buckets(self,bucket_specs:t.Sequence[FollowerBucketSpec])->t.List[FollowerAnalyticsPeriod]:
		if not bucket_specs:return[]
		buckets=_analytics_buckets_subquery(bucket_specs);followers=self.followers_table.as_('f');query=exp.select(exp.column(_J,_B),exp.column(_K,_B),exp.column(_H,_B),exp.Count(this=exp.column(_E,'f')).as_('active_followers')).from_(buckets).join(followers,on=_analytics_active_at_period_end_condition(),join_type='left').group_by(exp.column(_J,_B),exp.column(_K,_B),exp.column(_H,_B)).order_by(exp.column(_J,_B));rows=fetchall(self.engine_adapter,query);counts_by_index={int(row[0]):int(row[3])for row in rows};return[FollowerAnalyticsPeriod(period_start=spec.period_start,period_end=spec.period_end,active_followers=counts_by_index.get(spec.bucket_index,0))for spec in bucket_specs]
	def _build_analytics_response(self,*,total_active:int,granularity:FollowerGranularity,offset:int,limit:int,series:t.List[FollowerAnalyticsPeriod])->FollowerAnalytics:return FollowerAnalytics(total_active=total_active,granularity=granularity,offset=offset,limit=limit,series=series,pagination=FollowerAnalyticsPagination(offset=offset,limit=limit,has_more=_D))
	def _update_follower(self,user_id:str,*,active:bool,updated_at:int,metadata:t.Optional[t.Dict[str,t.Any]]=_A)->_A:
		values:t.Dict[str,t.Any]={_C:active,_G:updated_at}
		if metadata is not _A:values[_I]=json.dumps(metadata)
		update_stmt=exp.update(self.followers_table,values,where=exp.column(_E).eq(user_id));self.engine_adapter.execute(update_stmt)
	def _row_to_follower(self,row:t.Dict[str,t.Any])->Follower:return Follower(user_id=row[_E],active=bool(row[_C]),followed_at=int(row[_F]),updated_at=int(row[_G]),metadata=json_to_dict(row[_I]))