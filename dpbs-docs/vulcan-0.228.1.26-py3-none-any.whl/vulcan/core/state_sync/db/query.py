from __future__ import annotations
_A0='submitted_by'
_z='created_by'
_y='cached_at_ts'
_x='pgq_job_id'
_w='submitted_ts'
_v='invalidated_by_run_id'
_u='size_bytes'
_t='row_count'
_s='object_store_path'
_r='unknown'
_q='updated_by'
_p='created_at'
_o='owner'
_n='slug'
_m='error_message'
_l='execution_start_ts'
_k='primary_request_id'
_j=True
_i='updated_at'
_h='description'
_g='name'
_f='execution_end_ts'
_e='graphql_query'
_d='semantic_query'
_c='query_type'
_b='ttl'
_a='gateway'
_Z='normalized_sql'
_Y='sql_query'
_X='execution_status'
_W='strategy'
_V='created_ts'
_U='auto_refresh'
_T='terms'
_S='tags'
_R='invalidated_ts'
_Q=False
_P='allowed_user_ids'
_O='is_public'
_N='rest_query'
_M='meta'
_L='params'
_K='expires_ts'
_J='depends_on'
_I='references'
_H='perspective_id'
_G='columns'
_F='request_id'
_E='c'
_D='result_id'
_C='fingerprint'
_B='p'
_A=None
import json,logging,typing as t
from datetime import datetime,timedelta,timezone
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.utils import fetch_row_as_dict,fetch_rows_as_dicts,raise_if_not_postgres
from vulcan.utils.migration import index_text_type,blob_text_type
from vulcan.utils.date import to_timestamp
from vulcan.utils import random_id
from vulcan.core.query.definitions import QueryResult,QueryFingerprintResult,QueryRequest,QueryStatus,Perspective,QueryStrategy,QueryType,ACTIVE_STATUSES,TERMINAL_STATUSES
logger=logging.getLogger(__name__)
class StatementContext(t.NamedTuple):request:QueryRequest;primary_request:t.Optional[QueryRequest];result:t.Optional[QueryResult]
class QueryState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A):F='boolean';E='int';D='text[]';C='jsonb';B='bigint';A='text';self.engine_adapter=engine_adapter;self.schema=schema;index_type=index_text_type(engine_adapter.dialect);self.results_table=exp.table_('_query_results',db=schema);self.fingerprints_table=exp.table_('_query_fingerprints',db=schema);self.requests_table=exp.table_('_query_requests',db=schema);self.perspectives_table=exp.table_('_query_perspective',db=schema);self._results_columns_to_types={_D:exp.DataType.build(index_type),_s:exp.DataType.build(A),_t:exp.DataType.build(B),_u:exp.DataType.build(B),_G:exp.DataType.build(C),'sql':exp.DataType.build(A),_I:exp.DataType.build(C),_V:exp.DataType.build(B)};self._fingerprints_columns_to_types={_C:exp.DataType.build(index_type),_D:exp.DataType.build(index_type),_J:exp.DataType.build(D),_V:exp.DataType.build(B),_K:exp.DataType.build(B),_v:exp.DataType.build(index_type),_R:exp.DataType.build(B)};self._requests_columns_to_types={_F:exp.DataType.build(index_type),_W:exp.DataType.build(A),_X:exp.DataType.build(A),_k:exp.DataType.build(index_type),_C:exp.DataType.build(index_type),_Y:exp.DataType.build(A),_Z:exp.DataType.build(A),_L:exp.DataType.build(C),_J:exp.DataType.build(D),_a:exp.DataType.build(index_type),_A0:exp.DataType.build(A),_w:exp.DataType.build(B),_b:exp.DataType.build(E),_M:exp.DataType.build(C),_c:exp.DataType.build(A),_d:exp.DataType.build(A),_N:exp.DataType.build(C),_e:exp.DataType.build(A),_H:exp.DataType.build(index_type),_x:exp.DataType.build(B),_l:exp.DataType.build(B),_f:exp.DataType.build(B),_y:exp.DataType.build(B),_D:exp.DataType.build(index_type),_m:exp.DataType.build(A)};self._perspectives_columns_to_types={_H:exp.DataType.build(index_type),_n:exp.DataType.build(A),_g:exp.DataType.build(A),_h:exp.DataType.build(A),_S:exp.DataType.build(D),_T:exp.DataType.build(D),_o:exp.DataType.build(A),_F:exp.DataType.build(index_type),_C:exp.DataType.build(index_type),_Y:exp.DataType.build(A),_Z:exp.DataType.build(A),_L:exp.DataType.build(C),_a:exp.DataType.build(A),_b:exp.DataType.build(E),_M:exp.DataType.build(C),_c:exp.DataType.build(A),_d:exp.DataType.build(A),_N:exp.DataType.build(C),_e:exp.DataType.build(A),_J:exp.DataType.build(D),_U:exp.DataType.build(F),_O:exp.DataType.build(F),_P:exp.DataType.build(D),_p:exp.DataType.build(B),_i:exp.DataType.build(B),_z:exp.DataType.build(A),_q:exp.DataType.build(A)}
	def get_result_by_id(self,result_id:str)->t.Optional[QueryResult]:
		row=fetch_row_as_dict(self.engine_adapter,self._result_select().where(exp.column(_D).eq(result_id)))
		if row is _A:return
		parsed=dict(row)
		if parsed.get(_G)and isinstance(parsed[_G],str):
			try:parsed[_G]=json.loads(parsed[_G])
			except(json.JSONDecodeError,TypeError):result_id_val=parsed.get(_D,_r);logger.warning('Failed to parse columns for result %s...',str(result_id_val)[:16]);parsed[_G]=[]
		if parsed.get(_I):
			if isinstance(parsed[_I],str):
				try:references_dict=json.loads(parsed[_I]);parsed[_I]={col:[(ref[0],ref[1])for ref in refs]for(col,refs)in references_dict.items()}
				except(json.JSONDecodeError,TypeError,IndexError):result_id_val=parsed.get(_D,_r);logger.warning('Failed to parse references for result %s...',str(result_id_val)[:16]);parsed[_I]=_A
			elif isinstance(parsed[_I],dict):parsed[_I]={col:[(ref[0],ref[1])if isinstance(ref,list)else ref for ref in refs]for(col,refs)in parsed[_I].items()}
		return QueryResult(**parsed)
	def delete_result_by_id(self,result_id:str)->_A:self.engine_adapter.execute(exp.delete(self.results_table).where(exp.column(_D).eq(result_id)))
	def get_fingerprint_result(self,fingerprint:str)->t.Optional[QueryFingerprintResult]:
		A='r';now_ts=to_timestamp(datetime.now(timezone.utc));query=exp.select(exp.column(_C,_E),exp.column(_D,_E),exp.column(_J,_E),exp.column(_V,_E).as_(_y),exp.column(_K,_E),exp.column(_v,_E),exp.column(_R,_E),exp.column(_s,A),exp.column(_t,A),exp.column(_u,A),exp.column(_G,A),exp.column(_V,A).as_('result_created_ts')).from_(self.fingerprints_table.as_(_E)).join(self.results_table.as_(A),on=exp.column(_D,_E).eq(exp.column(_D,A))).where(exp.column(_C,_E).eq(fingerprint)).where(exp.or_(exp.column(_K,_E).is_(exp.null()),exp.column(_K,_E)>now_ts));row=fetch_row_as_dict(self.engine_adapter,query)
		if row is _A:return
		parsed=dict(row)
		if parsed.get(_G)and isinstance(parsed[_G],str):
			try:parsed[_G]=json.loads(parsed[_G])
			except(json.JSONDecodeError,TypeError):fingerprint_val=parsed.get(_C,_r);logger.warning('Failed to parse columns for %s...',str(fingerprint_val)[:16]);parsed[_G]=[]
		return QueryFingerprintResult(**parsed)
	def is_result_fresh(self,fingerprint:str,result_id:str)->bool:
		if not fingerprint:return _j
		query=exp.select(exp.column(_D),exp.column(_R),exp.column(_K)).from_(self.fingerprints_table).where(exp.column(_C).eq(fingerprint));row=fetch_row_as_dict(self.engine_adapter,query)
		if row is _A:return _j
		if row[_D]!=result_id:return _Q
		if row.get(_R)is not _A:return _Q
		if row.get(_K)is not _A:
			now_ts=to_timestamp(datetime.now(timezone.utc))
			if row[_K]<now_ts:return _Q
		return _j
	def delete_fingerprint_entry(self,fingerprint:str)->_A:self.engine_adapter.execute(exp.delete(self.fingerprints_table).where(exp.column(_C).eq(fingerprint)))
	def cleanup_expired_fingerprints(self,retention_days:int=7)->int:
		cutoff_ts=to_timestamp(datetime.now(timezone.utc)-timedelta(days=retention_days));result=self.engine_adapter.execute(exp.delete(self.fingerprints_table).where(exp.and_(exp.column(_K).is_(exp.null()).not_(),exp.column(_K)<cutoff_ts)));affected=getattr(result,'rowcount',0)
		if affected>0:logger.info(f"Cleaned up {affected} fingerprint entries expired >{retention_days} days ago")
		return affected
	def create_request(self,request_id:str,strategy:QueryStrategy,fingerprint:str,sql_query:str,normalized_sql:str,params:t.Optional[t.Union[t.Dict,t.List]],gateway:str,submitted_by:t.Optional[str]=_A,depends_on:t.Optional[t.List[str]]=_A,ttl:int=0,meta:t.Optional[t.Dict]=_A,query_type:t.Optional[QueryType]=_A,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[t.Dict]=_A,graphql_query:t.Optional[str]=_A,perspective_id:t.Optional[str]=_A,execution_status:t.Optional[QueryStatus]=_A,primary_request_id:t.Optional[str]=_A,cached_at_ts:t.Optional[int]=_A,result_id:t.Optional[str]=_A)->_A:
		import pandas as pd
		if strategy==QueryStrategy.AWAIT_PRIMARY:
			if not primary_request_id:raise ValueError(f"primary_request_id is required for strategy={QueryStrategy.AWAIT_PRIMARY.value!r}. Request {request_id} cannot be created without a primary request ID.")
		execution_start_ts_value=_A;execution_end_ts_value=_A;primary_request_id_value=primary_request_id
		if strategy==QueryStrategy.REUSE_RESULT and result_id:
			original_request=self.get_request_by_id(result_id)
			if not original_request:raise ValueError(f"Original request not found for cached result: result_id={result_id}. This indicates data inconsistency - cache entry exists but original request is missing.")
			primary_request_id_value=original_request.primary_request_id or result_id;execution_start_ts_value=original_request.execution_start_ts;execution_end_ts_value=original_request.execution_end_ts
		df=pd.DataFrame([{_F:request_id,_W:strategy.value,_X:execution_status.value if execution_status is not _A else _A,_k:primary_request_id_value,_C:fingerprint,_Y:sql_query,_Z:normalized_sql,_L:json.dumps(params)if params else _A,_J:depends_on if depends_on else _A,_a:gateway,_A0:submitted_by,_w:to_timestamp(datetime.now(timezone.utc)),_b:ttl,_M:json.dumps(meta)if meta else _A,_c:query_type.value if query_type is not _A else _A,_d:semantic_query,_N:json.dumps(rest_query)if rest_query else _A,_e:graphql_query,_H:perspective_id,_x:_A,_l:execution_start_ts_value,_f:execution_end_ts_value,_y:cached_at_ts,_D:result_id,_m:_A}]);self.engine_adapter.insert_append(self.requests_table,df,target_columns_to_types=self._requests_columns_to_types,track_rows_processed=_Q)
	def mark_request_completed(self,request_id:str,result_id:str,object_store_path:str,row_count:int,size_bytes:int,columns:t.List[t.Dict[str,str]],fingerprint:str,depends_on:t.Optional[t.List[str]]=_A,ttl_minutes:int=0,sql:t.Optional[str]=_A,references:t.Optional[t.Dict[str,t.List[t.Tuple[str,str]]]]=_A)->_A:
		now_ts=to_timestamp(datetime.now(timezone.utc))
		with self.engine_adapter.transaction():
			self._store_result_metadata(result_id=result_id,object_store_path=object_store_path,row_count=row_count,size_bytes=size_bytes,columns=columns,created_ts=now_ts,sql=sql,references=references);self._store_fingerprint_entry(fingerprint=fingerprint,result_id=result_id,depends_on=depends_on,ttl_minutes=ttl_minutes,created_ts=now_ts);primary_request=self._get_request_or_raise(request_id);self._update_request(request_id,execution_status=QueryStatus.SUCCESS,result_id=result_id,execution_end_ts=now_ts)
			if primary_request.perspective_id:self._update_request_id_for_perspective(perspective_id=primary_request.perspective_id,request_id=request_id)
		logger.info(f"Request {request_id} completed successfully (transactional)")
	def mark_request_queued(self,request_id:str,pgq_job_id:int)->_A:self._update_request(request_id,execution_status=QueryStatus.QUEUED,pgq_job_id=pgq_job_id);logger.debug(f"Request {request_id} marked as QUEUED (pgq_job_id={pgq_job_id})")
	def mark_request_in_progress(self,request_id:str)->_A:self._update_request(request_id,execution_status=QueryStatus.IN_PROGRESS,execution_start_ts=to_timestamp(datetime.now(timezone.utc)));logger.debug(f"Request {request_id} marked as IN_PROGRESS")
	def mark_request_failed(self,request_id:str,error_message:str)->_A:self._update_request(request_id,execution_status=QueryStatus.FAILED,error_message=error_message,execution_end_ts=to_timestamp(datetime.now(timezone.utc)));logger.debug(f"Request {request_id} marked as FAILED")
	def mark_request_cancelled(self,request_id:str)->_A:self._update_request(request_id,execution_status=QueryStatus.CANCELLED,execution_end_ts=to_timestamp(datetime.now(timezone.utc)));logger.debug(f"Request {request_id} marked as CANCELLED")
	def get_request_by_id(self,request_id:str)->t.Optional[QueryRequest]:
		row=fetch_row_as_dict(self.engine_adapter,self._request_select().where(exp.column(_F).eq(request_id)))
		if row is _A:return
		return self._parse_request_dict(row)
	def get_statement_context(self,request_id:str)->t.Optional[StatementContext]:
		stmt_req=self.get_request_by_id(request_id)
		if stmt_req is _A:return
		primary_req:t.Optional[QueryRequest]=_A;result:t.Optional[QueryResult]=_A
		if stmt_req.strategy==QueryStrategy.AWAIT_PRIMARY:
			if stmt_req.primary_request_id:primary_req=self.get_request_by_id(stmt_req.primary_request_id)
			if primary_req and primary_req.execution_status==QueryStatus.SUCCESS and primary_req.result_id:result=self.get_result_by_id(primary_req.result_id)
		elif stmt_req.strategy==QueryStrategy.REUSE_RESULT:
			if stmt_req.result_id:result=self.get_result_by_id(stmt_req.result_id)
		elif stmt_req.execution_status==QueryStatus.SUCCESS and stmt_req.result_id:result=self.get_result_by_id(stmt_req.result_id)
		return StatementContext(request=stmt_req,primary_request=primary_req,result=result)
	def get_awaiting_requests_by_primary_request_id(self,primary_request_id:str)->t.List[QueryRequest]:rows=fetch_rows_as_dicts(self.engine_adapter,self._request_select().where(exp.column(_W).eq(QueryStrategy.AWAIT_PRIMARY.value)&exp.column(_k).eq(primary_request_id)&exp.column(_H).is_(exp.null()).not_()));return[self._parse_request_dict(row)for row in rows]
	def get_in_flight_request_by_fingerprint(self,fingerprint:str)->t.Optional[QueryRequest]:
		row=fetch_row_as_dict(self.engine_adapter,self._request_select().where(exp.column(_C).eq(fingerprint)).where(exp.column(_W).eq(QueryStrategy.EXECUTE.value)).where(exp.column(_X).isin(*[s.value for s in ACTIVE_STATUSES])).order_by(exp.column(_w)).limit(1))
		if row is _A:return
		return self._parse_request_dict(row)
	def get_recent_failed_execution_by_fingerprint(self,fingerprint:str,window_seconds:int=300)->t.Optional[QueryRequest]:
		cutoff_ts=to_timestamp(datetime.now(timezone.utc)-timedelta(seconds=window_seconds));row=fetch_row_as_dict(self.engine_adapter,self._request_select().where(exp.column(_C).eq(fingerprint)).where(exp.column(_W).eq(QueryStrategy.EXECUTE.value)).where(exp.column(_X).eq(QueryStatus.FAILED.value)).where(exp.column(_f)>cutoff_ts).order_by(exp.column(_f).desc()).limit(1))
		if row is _A:return
		return self._parse_request_dict(row)
	def create_perspective(self,perspective_id:str,slug:str,request_id:str,fingerprint:str,sql_query:str,name:str,owner:str,normalized_sql:t.Optional[str]=_A,params:t.Optional[t.Union[t.Dict,t.List]]=_A,gateway:t.Optional[str]=_A,ttl:int=0,meta:t.Optional[t.Dict]=_A,query_type:t.Optional[QueryType]=_A,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[t.Dict]=_A,graphql_query:t.Optional[str]=_A,depends_on:t.Optional[t.List[str]]=_A,description:t.Optional[str]=_A,tags:t.Optional[t.List[str]]=_A,terms:t.Optional[t.List[str]]=_A,auto_refresh:bool=_j,is_public:bool=_Q,allowed_user_ids:t.Optional[t.List[str]]=_A,created_by:t.Optional[str]=_A)->_A:import pandas as pd,json;now_ts=to_timestamp(datetime.now(timezone.utc));df=pd.DataFrame([{_H:perspective_id,_n:slug,_g:name,_h:description,_S:tags if tags else _A,_T:terms if terms else _A,_o:owner,_F:request_id,_C:fingerprint,_Y:sql_query,_Z:normalized_sql,_L:json.dumps(params)if params else _A,_a:gateway,_b:ttl,_M:json.dumps(meta)if meta else _A,_c:query_type.value if query_type is not _A else _A,_d:semantic_query,_N:json.dumps(rest_query)if rest_query else _A,_e:graphql_query,_J:depends_on if depends_on else _A,_U:auto_refresh,_O:is_public,_P:allowed_user_ids if allowed_user_ids else _A,_p:now_ts,_i:now_ts,_z:created_by or owner,_q:created_by or owner}]);self.engine_adapter.insert_append(self.perspectives_table,df,target_columns_to_types=self._perspectives_columns_to_types,track_rows_processed=_Q);logger.info(f"Created perspective: {perspective_id} (slug: {slug})")
	def get_perspective_by_slug(self,slug:str)->t.Optional[Perspective]:
		row=fetch_row_as_dict(self.engine_adapter,self._perspective_select().where(exp.column(_n).eq(slug)))
		if row is _A:return
		return self._parse_perspective_dict(row)
	def get_perspective_by_id(self,perspective_id:str)->t.Optional[Perspective]:
		row=fetch_row_as_dict(self.engine_adapter,self._perspective_select().where(exp.column(_H).eq(perspective_id)))
		if row is _A:return
		return self._parse_perspective_dict(row)
	def update_perspective(self,perspective_id:str,request_id:t.Optional[str]=_A,fingerprint:t.Optional[str]=_A,sql_query:t.Optional[str]=_A,normalized_sql:t.Optional[str]=_A,params:t.Optional[t.Union[t.Dict,t.List]]=_A,gateway:t.Optional[str]=_A,ttl:t.Optional[int]=_A,meta:t.Optional[t.Dict]=_A,query_type:t.Optional[QueryType]=_A,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[t.Dict]=_A,graphql_query:t.Optional[str]=_A,depends_on:t.Optional[t.List[str]]=_A,updated_by:t.Optional[str]=_A,**kwargs)->_A:
		import json;now_ts=to_timestamp(datetime.now(timezone.utc));update_props={_i:now_ts};has_query_fields=any([sql_query is not _A,normalized_sql is not _A,params is not _A,gateway is not _A,ttl is not _A,meta is not _A,query_type is not _A,semantic_query is not _A,rest_query is not _A,graphql_query is not _A,depends_on is not _A])
		if has_query_fields and fingerprint is _A:raise ValueError('fingerprint must be provided when updating query definition fields')
		if has_query_fields:
			if fingerprint is not _A:update_props[_C]=fingerprint
			if sql_query is not _A:update_props[_Y]=sql_query
			if normalized_sql is not _A:update_props[_Z]=normalized_sql
			if params is not _A:update_props[_L]=json.dumps(params)if params else _A
			if gateway is not _A:update_props[_a]=gateway
			if ttl is not _A:update_props[_b]=ttl
			if meta is not _A:update_props[_M]=json.dumps(meta)if meta else _A
			if query_type is not _A:update_props[_c]=query_type.value
			if semantic_query is not _A:update_props[_d]=semantic_query
			if rest_query is not _A:update_props[_N]=json.dumps(rest_query)if rest_query else _A
			if graphql_query is not _A:update_props[_e]=graphql_query
			if depends_on is not _A:update_props[_J]=depends_on if depends_on else _A
		if request_id is not _A:update_props[_F]=request_id
		if updated_by is not _A:update_props[_q]=updated_by
		if _g in kwargs:update_props[_g]=kwargs[_g]
		if _h in kwargs:update_props[_h]=kwargs[_h]
		if _S in kwargs:update_props[_S]=kwargs[_S]
		if _T in kwargs:update_props[_T]=kwargs[_T]
		if _U in kwargs:update_props[_U]=kwargs[_U]
		if _O in kwargs:update_props[_O]=kwargs[_O]
		if _P in kwargs:update_props[_P]=kwargs[_P]
		if len(update_props)==1:logger.warning(f"No fields to update for perspective {perspective_id}");return
		self.engine_adapter.update_table(self.perspectives_table,update_props,where=exp.column(_H).eq(perspective_id))
	def delete_perspective(self,perspective_id:str)->_A:self.engine_adapter.execute(exp.delete(self.perspectives_table).where(exp.column(_H).eq(perspective_id)));logger.info(f"Deleted perspective: {perspective_id}")
	def list_perspectives(self,current_user_id:str,is_public:t.Optional[bool]=_A,limit:int=50,offset:int=0)->t.Tuple[t.List[Perspective],bool]:
		A='_user_id';query=self._perspective_select();conditions=[];access_condition=exp.or_(exp.column(_O).eq(_j),exp.column(_o).eq(current_user_id),exp.Exists(this=exp.select(exp.Literal.number(1)).from_(exp.Unnest(expressions=[exp.column(_P)],alias=exp.TableAlias(this=exp.to_identifier(A)))).where(exp.column(A).eq(current_user_id))));conditions.append(access_condition)
		if is_public is not _A:conditions.append(exp.column(_O).eq(is_public))
		if conditions:query=query.where(exp.and_(*conditions))
		query=query.order_by(exp.column(_i).desc());query=query.limit(limit+1).offset(offset);rows=fetch_rows_as_dicts(self.engine_adapter,query);has_more=len(rows)>limit
		if has_more:rows=rows[:limit]
		perspectives=[self._parse_perspective_dict(record)for record in rows];return perspectives,has_more
	def list_perspectives_to_refresh(self,since_ts_ms:int,limit:int=100,offset:int=0)->t.Tuple[t.List[Perspective],bool]:query=exp.select(exp.column(_H,_B),exp.column(_n,_B),exp.column(_g,_B),exp.column(_h,_B),exp.column(_S,_B),exp.column(_T,_B),exp.column(_o,_B),exp.column(_F,_B),exp.column(_C,_B),exp.column(_Y,_B),exp.column(_Z,_B),exp.column(_L,_B),exp.column(_a,_B),exp.column(_b,_B),exp.column(_M,_B),exp.column(_c,_B),exp.column(_d,_B),exp.column(_N,_B),exp.column(_e,_B),exp.column(_J,_B),exp.column(_U,_B),exp.column(_O,_B),exp.column(_P,_B),exp.column(_p,_B),exp.column(_i,_B),exp.column(_z,_B),exp.column(_q,_B)).from_(self.perspectives_table.as_(_B)).join(self.fingerprints_table.as_(_E),on=exp.column(_C,_B).eq(exp.column(_C,_E)),join_type='INNER').where(exp.and_(exp.column(_R,_E).is_(exp.null()).not_(),exp.column(_R,_E)>since_ts_ms,exp.column(_U,_B).eq(_j))).distinct().order_by(exp.column(_p,_B),exp.column(_H,_B)).limit(limit).offset(offset);rows=fetch_rows_as_dicts(self.engine_adapter,query);perspectives=[self._parse_perspective_dict(record)for record in rows];has_more=len(perspectives)==limit;return perspectives,has_more
	def get_usage_metrics(self,week_start:datetime|_A=_A)->dict[str,t.Any]:
		from vulcan.core.state_sync.db.query_metrics import fetch_usage_metrics,week_bounds_ms;from vulcan.utils.errors import VulcanError;raise_if_not_postgres(self.engine_adapter,feature='get_usage_metrics')
		if not self.schema:raise VulcanError('Query usage metrics aggregation requires QueryState.schema to be set.')
		week_start_ms,week_end_ms,prev_week_start_ms,prev_prev_week_start_ms=week_bounds_ms(week_start);return fetch_usage_metrics(self.engine_adapter,schema=self.schema,week_start_ms=week_start_ms,week_end_ms=week_end_ms,prev_week_start_ms=prev_week_start_ms,prev_prev_week_start_ms=prev_prev_week_start_ms)
	def _request_select(self)->exp.Select:return exp.select(*[exp.column(name)for name in self._requests_columns_to_types]).from_(self.requests_table)
	def _result_select(self)->exp.Select:return exp.select(*[exp.column(name)for name in self._results_columns_to_types]).from_(self.results_table)
	def _perspective_select(self)->exp.Select:return exp.select(*[exp.column(name)for name in self._perspectives_columns_to_types]).from_(self.perspectives_table)
	def _parse_request_dict(self,request_dict:t.Dict[str,t.Any])->QueryRequest:
		parsed=dict(request_dict)
		for field in[_L,_M,_N]:
			if parsed.get(field)and isinstance(parsed[field],str):
				try:parsed[field]=json.loads(parsed[field])
				except(json.JSONDecodeError,TypeError):request_id=parsed.get(_F,_r);logger.warning('Failed to parse %s for request %s...',field,str(request_id)[:16]);parsed[field]=_A
		return QueryRequest(**parsed)
	def _parse_perspective_dict(self,perspective_dict:t.Dict[str,t.Any])->Perspective:
		for field in[_L,_M,_N]:
			if perspective_dict.get(field)and isinstance(perspective_dict[field],str):
				try:perspective_dict[field]=json.loads(perspective_dict[field])
				except(json.JSONDecodeError,TypeError):logger.warning(f"Failed to parse {field} for perspective");perspective_dict[field]=_A
		for field in[_J,_S,_T,_P]:
			if perspective_dict.get(field)is _A:perspective_dict[field]=[]
		perspective_dict.pop('original_request_id',_A);return Perspective(**perspective_dict)
	def _store_result_metadata(self,result_id:str,object_store_path:str,row_count:int,size_bytes:int,columns:t.List[t.Dict[str,str]],created_ts:int,sql:t.Optional[str]=_A,references:t.Optional[t.Dict[str,t.List[t.Tuple[str,str]]]]=_A)->_A:
		import pandas as pd;references_json=_A
		if references:references_json={col:[[model,field]for(model,field)in refs]for(col,refs)in references.items()}
		result_df=pd.DataFrame([{_D:result_id,_s:object_store_path,_t:row_count,_u:size_bytes,_G:json.dumps(columns),'sql':sql,_I:json.dumps(references_json)if references_json else _A,_V:created_ts}]);self.engine_adapter.insert_append(self.results_table,result_df,target_columns_to_types=self._results_columns_to_types,track_rows_processed=_Q)
	def _store_fingerprint_entry(self,fingerprint:str,result_id:str,depends_on:t.Optional[t.List[str]],ttl_minutes:t.Optional[int],created_ts:int)->_A:
		import pandas as pd;expires_ts=_A
		if ttl_minutes is not _A:expires_dt=datetime.now(timezone.utc)+timedelta(minutes=ttl_minutes);expires_ts=to_timestamp(expires_dt)
		self.engine_adapter.execute(exp.delete(self.fingerprints_table).where(exp.column(_C).eq(fingerprint)));fingerprint_df=pd.DataFrame([{_C:fingerprint,_D:result_id,_J:depends_on if depends_on else _A,_V:created_ts,_K:_A,_v:_A,_R:_A}]);self.engine_adapter.insert_append(self.fingerprints_table,fingerprint_df,target_columns_to_types=self._fingerprints_columns_to_types,track_rows_processed=_Q)
	def _get_request_or_raise(self,request_id:str)->QueryRequest:
		request=self.get_request_by_id(request_id)
		if not request:raise ValueError(f"Request {request_id} not found")
		return request
	def _update_request(self,request_id:str,execution_status:t.Optional[QueryStatus]=_A,pgq_job_id:t.Optional[int]=_A,execution_start_ts:t.Optional[int]=_A,execution_end_ts:t.Optional[int]=_A,result_id:t.Optional[str]=_A,error_message:t.Optional[str]=_A,patch_id:t.Optional[str]=_A)->_A:
		properties={}
		if execution_status is not _A:properties[_X]=execution_status.value
		if pgq_job_id is not _A:properties[_x]=pgq_job_id
		if execution_start_ts is not _A:properties[_l]=execution_start_ts
		if execution_end_ts is not _A:properties[_f]=execution_end_ts
		if result_id is not _A:properties[_D]=result_id
		if error_message is not _A:properties[_m]=error_message
		if patch_id is not _A:properties['patch_id']=patch_id
		if not properties:logger.warning(f"No properties to update for request {request_id}");return
		self.engine_adapter.update_table(self.requests_table,properties,where=exp.column(_F).eq(request_id));terminal_statuses=TERMINAL_STATUSES
		if execution_status in terminal_statuses:
			request=self.get_request_by_id(request_id)
			if request:self._update_awaiting_requests_status(primary_request_id=request_id,execution_status=execution_status,execution_start_ts=request.execution_start_ts or execution_start_ts,execution_end_ts=execution_end_ts or to_timestamp(datetime.now(timezone.utc)),result_id=result_id,error_message=error_message or(f"Failed because primary request failed"if execution_status==QueryStatus.FAILED else _A))
	def _update_awaiting_requests_status(self,primary_request_id:str,execution_status:QueryStatus,execution_start_ts:t.Optional[int],execution_end_ts:int,result_id:t.Optional[str]=_A,error_message:t.Optional[str]=_A)->_A:
		awaiting_rows=fetch_rows_as_dicts(self.engine_adapter,exp.select(exp.column(_F),exp.column(_H)).from_(self.requests_table).where(exp.column(_W).eq(QueryStrategy.AWAIT_PRIMARY.value)&exp.column(_k).eq(primary_request_id)))
		if not awaiting_rows:return
		awaiting_request_ids=[row[_F]for row in awaiting_rows];update_properties={_X:execution_status.value,_l:execution_start_ts,_f:execution_end_ts}
		if execution_status==QueryStatus.SUCCESS and result_id:update_properties[_D]=result_id
		if execution_status==QueryStatus.FAILED and error_message:update_properties[_m]=error_message
		self.engine_adapter.update_table(self.requests_table,update_properties,where=exp.column(_F).isin(*awaiting_request_ids));status_label=execution_status.lower();logger.info(f"Updated {len(awaiting_request_ids)} awaiting request(s) to {status_label} (primary={primary_request_id})")
		for row in awaiting_rows:
			awaiting_perspective_id=row.get(_H)
			if awaiting_perspective_id:self._update_request_id_for_perspective(perspective_id=awaiting_perspective_id,request_id=row[_F]);logger.debug(f"Updated perspective '{awaiting_perspective_id}' request_id to awaiting request '{row[_F]}'")
	def _update_request_id_for_perspective(self,perspective_id:str,request_id:str)->_A:
		now_ts=to_timestamp(datetime.now(timezone.utc));new_request=self.get_request_by_id(request_id)
		if not new_request:logger.warning(f"Request {request_id} not found, skipping perspective update");return
		new_fingerprint=new_request.fingerprint;update_stmt=exp.update(self.perspectives_table.as_(_B),{_F:request_id,_i:now_ts},where=exp.and_(exp.column(_H,_B).eq(perspective_id),exp.column(_C,_B).eq(new_fingerprint)));self.engine_adapter.execute(update_stmt);logger.debug(f"Updated perspective {perspective_id} request_id to {request_id} (fingerprint match verified)")