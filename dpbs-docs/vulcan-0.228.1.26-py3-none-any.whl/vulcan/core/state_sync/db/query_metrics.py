from __future__ import annotations
_M='pct_savings_wow_pct'
_L='pct_savings'
_K='median_query_time_wow_pct'
_J='median_query_time_ms'
_I='queries_wow_pct'
_H='queries'
_G='repeat_users_wow_pct'
_F='repeat_users'
_E='new_users_wow_pct'
_D='new_users'
_C='active_users_wow_pct'
_B='active_users'
_A=None
import typing as t
from decimal import Decimal
from datetime import datetime,timedelta,timezone
import pandas as pd
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.query.definitions import QueryStrategy
USAGE_METRICS_SQL=f"""
WITH base AS (
  SELECT
    COALESCE(submitted_by, 'anonymous') AS submitted_by,
    strategy,
    execution_start_ts,
    execution_end_ts,
    (submitted_ts >= :week_start_ms AND submitted_ts < :week_end_ms) AS is_this_week,
    (submitted_ts >= :prev_week_start_ms AND submitted_ts < :week_start_ms) AS is_prev_week,
    (submitted_ts >= :prev_prev_week_start_ms AND submitted_ts < :prev_week_start_ms) AS is_prev_prev_week
  FROM {{schema}}._query_requests
  WHERE submitted_ts >= :prev_prev_week_start_ms
    AND submitted_ts < :week_end_ms
),
user_flags AS (
  SELECT
    submitted_by,
    BOOL_OR(is_this_week) AS in_this_week,
    BOOL_OR(is_prev_week) AS in_prev_week,
    BOOL_OR(is_prev_prev_week) AS in_prev_prev_week
  FROM base
  GROUP BY submitted_by
),
agg AS (
  SELECT
    COUNT(*) FILTER (WHERE is_this_week) AS total_requests,
    COUNT(*) FILTER (WHERE is_this_week AND strategy = '{QueryStrategy.REUSE_RESULT.value}') AS cache_requests,
    COUNT(DISTINCT submitted_by) FILTER (WHERE is_this_week) AS active_users,
    percentile_cont(0.5) WITHIN GROUP (
      ORDER BY (execution_end_ts - execution_start_ts)
    ) FILTER (
      WHERE is_this_week
        AND execution_start_ts IS NOT NULL
        AND execution_end_ts IS NOT NULL
    ) AS median_ms,
    COUNT(*) FILTER (WHERE is_prev_week) AS total_requests_prev,
    COUNT(*) FILTER (WHERE is_prev_week AND strategy = '{QueryStrategy.REUSE_RESULT.value}') AS cache_requests_prev,
    COUNT(DISTINCT submitted_by) FILTER (WHERE is_prev_week) AS active_users_prev,
    percentile_cont(0.5) WITHIN GROUP (
      ORDER BY (execution_end_ts - execution_start_ts)
    ) FILTER (
      WHERE is_prev_week
        AND execution_start_ts IS NOT NULL
        AND execution_end_ts IS NOT NULL
    ) AS median_ms_prev
  FROM base
),
new_user_count AS (
  SELECT COUNT(*) AS n
  FROM user_flags
  WHERE in_this_week AND NOT in_prev_week
),
new_user_count_prev AS (
  SELECT COUNT(*) AS n
  FROM user_flags
  WHERE in_prev_week AND NOT in_prev_prev_week
),
curr AS (
  SELECT
    a.active_users,
    n.n AS new_users,
    (a.active_users - n.n) AS repeat_users,
    a.total_requests AS queries,
    a.median_ms AS median_query_time_ms,
    (a.cache_requests * 100.0 / NULLIF(a.total_requests, 0)) AS pct_savings
  FROM agg a
  CROSS JOIN new_user_count n
),
prev AS (
  SELECT
    a.active_users_prev,
    np.n AS new_users_prev,
    (a.active_users_prev - np.n) AS repeat_users_prev,
    a.total_requests_prev AS queries_prev,
    a.median_ms_prev AS median_query_time_ms_prev,
    (a.cache_requests_prev * 100.0 / NULLIF(a.total_requests_prev, 0)) AS pct_savings_prev
  FROM agg a
  CROSS JOIN new_user_count_prev np
)
SELECT
  c.active_users,
  c.new_users,
  c.repeat_users,
  c.queries,
  c.median_query_time_ms,
  c.pct_savings,
  ((c.active_users - COALESCE(p.active_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.active_users_prev, 0), 0)) AS active_users_wow_pct,
  ((c.new_users - COALESCE(p.new_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.new_users_prev, 0), 0)) AS new_users_wow_pct,
  ((c.repeat_users - COALESCE(p.repeat_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.repeat_users_prev, 0), 0)) AS repeat_users_wow_pct,
  ((c.queries - COALESCE(p.queries_prev, 0)) * 100.0 / NULLIF(COALESCE(p.queries_prev, 0), 0)) AS queries_wow_pct,
  ((c.median_query_time_ms - COALESCE(p.median_query_time_ms_prev, 0)) * 100.0 / NULLIF(COALESCE(p.median_query_time_ms_prev, 0), 0)) AS median_query_time_wow_pct,
  (c.pct_savings - COALESCE(p.pct_savings_prev, 0)) AS pct_savings_wow_pct
FROM curr c
CROSS JOIN prev p
"""
def week_bounds_ms(week_start:datetime|_A=_A)->tuple[int,int,int,int]:
	if week_start is _A:now=datetime.now(timezone.utc);week_start=now.replace(hour=0,minute=0,second=0,microsecond=0)-timedelta(days=now.weekday())
	if week_start.tzinfo is _A:week_start=week_start.replace(tzinfo=timezone.utc)
	else:week_start=week_start.astimezone(timezone.utc)
	week_start_ms=int(week_start.timestamp()*1000);week_end_ms=int((week_start+timedelta(days=7)).timestamp()*1000);prev_week_start_ms=week_start_ms-604800000;prev_prev_week_start_ms=prev_week_start_ms-604800000;return week_start_ms,week_end_ms,prev_week_start_ms,prev_prev_week_start_ms
def _json_safe_number(x:t.Any)->int|float|_A:
	if x is _A:return
	try:
		if pd.isna(x):return
	except Exception:pass
	if hasattr(x,'item'):
		try:x=x.item()
		except Exception:pass
	if isinstance(x,bool):return int(x)
	if isinstance(x,Decimal):return float(x)
	if isinstance(x,(int,float)):return x
def usage_metrics_defaults()->dict[str,t.Any]:return{_B:0,_C:_A,_D:0,_E:_A,_F:0,_G:_A,_H:0,_I:_A,_J:_A,_K:_A,_L:_A,_M:_A}
def fetch_usage_metrics(engine_adapter:EngineAdapter,*,schema:str,week_start_ms:int,week_end_ms:int,prev_week_start_ms:int,prev_prev_week_start_ms:int)->dict[str,t.Any]:
	sql=USAGE_METRICS_SQL.replace('{schema}',schema);params={'week_start_ms':week_start_ms,'week_end_ms':week_end_ms,'prev_week_start_ms':prev_week_start_ms,'prev_prev_week_start_ms':prev_prev_week_start_ms};df=engine_adapter.fetchdf_with_params(sql,params)
	if df is _A or len(df)==0:return usage_metrics_defaults()
	row=df.iloc[0].to_dict()
	def _int(key:str)->int:v=_json_safe_number(row.get(key));return int(v or 0)
	def _num(key:str)->int|float|_A:return _json_safe_number(row.get(key))
	out:dict[str,t.Any]={_B:_int(_B),_C:_num(_C),_D:_int(_D),_E:_num(_E),_F:_int(_F),_G:_num(_G),_H:_int(_H),_I:_num(_I),_J:_num(_J),_K:_num(_K),_L:_num(_L),_M:_num(_M)};return out