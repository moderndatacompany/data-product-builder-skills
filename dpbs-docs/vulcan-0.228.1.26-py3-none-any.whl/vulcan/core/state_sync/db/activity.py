from __future__ import annotations
_c='max_seq'
_b='COALESCE'
_a='model_name'
_Z='run_data'
_Y='total_evaluation_ms'
_X='bytes_processed'
_W='rows_affected'
_V='models_affected'
_U='has_backfills'
_T='has_changes'
_S='models_affected_indirectly'
_R='version'
_Q='prev_plan_id'
_P='git_commit_sha'
_O=False
_N='run_seq'
_M='run_id'
_L='models_affected_directly'
_K='executor'
_J='end_ts'
_I=True
_H='success'
_G='plan_diff'
_F='plan_id'
_E='start_ts'
_D='plan_seq'
_C='created_ts_ns'
_B='environment'
_A=None
import logging,typing as t
from datetime import datetime
from sqlglot import exp
from vulcan.core.activity import EnvironmentChange,PlanActivity,RunActivity
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.state_sync.db.utils import fetch_row_as_dict,fetch_rows_as_dicts,fetchone,is_postgres,raise_if_not_postgres
from vulcan.utils.date import to_timestamp
from vulcan.utils.migration import index_text_type
logger=logging.getLogger(__name__)
class ActivityState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A):E='jsonb';D='ARRAY<TEXT>';C='boolean';B='text';A='bigint';self.engine_adapter=engine_adapter;self.schema=schema;self.plans_table=exp.table_('_plans',db=schema);self.runs_table=exp.table_('_runs',db=schema);self.query_fingerprints=exp.table_('_query_fingerprints',db=schema);index_type=index_text_type(engine_adapter.dialect);self._plan_columns_to_types={_F:exp.DataType.build(index_type),_B:exp.DataType.build(index_type),_E:exp.DataType.build(A),_J:exp.DataType.build(A),_C:exp.DataType.build(A),_K:exp.DataType.build(B),_P:exp.DataType.build(B),_Q:exp.DataType.build(B),_R:exp.DataType.build(B),_L:exp.DataType.build(D),_S:exp.DataType.build(D),_G:exp.DataType.build(E),_T:exp.DataType.build(C),_U:exp.DataType.build(C),_H:exp.DataType.build(C),_D:exp.DataType.build(A)};self._run_columns_to_types={_M:exp.DataType.build(index_type),_F:exp.DataType.build(index_type),_B:exp.DataType.build(index_type),_E:exp.DataType.build(A),_J:exp.DataType.build(A),_C:exp.DataType.build(A),_K:exp.DataType.build(B),_H:exp.DataType.build(C),_V:exp.DataType.build(D),_W:exp.DataType.build(A),_X:exp.DataType.build(A),_Y:exp.DataType.build(A),_Z:exp.DataType.build(E),_N:exp.DataType.build(A)};self._activity_log_columns_to_types={'id':exp.DataType.build(B),_B:exp.DataType.build(index_type),_a:exp.DataType.build(index_type,nullable=_I),'event_type':exp.DataType.build(index_type),'event_ts':exp.DataType.build(A),'event_data':exp.DataType.build(B)}
	def store_plan_activity(self,plan_activity:PlanActivity)->_A:
		import pandas as pd,time;updated_ts_ns=time.time_ns()
		with self.engine_adapter.transaction():
			self.engine_adapter.delete_from(self.plans_table,where=exp.EQ(this=exp.column(_F),expression=exp.Literal.string(plan_activity.plan_id)));next_seq_result=fetchone(self.engine_adapter,exp.select(exp.func(_b,exp.func('MAX',exp.column(_D)),0).as_(_c)).from_(self.plans_table).where(exp.EQ(this=exp.column(_B),expression=exp.Literal.string(plan_activity.environment))));plan_seq=(next_seq_result[0]or 0)+1 if next_seq_result else 1;diff_json=plan_activity.json();models_directly=_A;models_indirectly=_A
			if plan_activity.models_affected_directly:models_directly=plan_activity.models_affected_directly
			if plan_activity.models_affected_indirectly:models_indirectly=plan_activity.models_affected_indirectly
			df=pd.DataFrame([{_F:plan_activity.plan_id,_B:plan_activity.environment,_E:int(plan_activity.start_ts),_J:int(plan_activity.end_ts),_C:updated_ts_ns,_K:plan_activity.executor,_P:plan_activity.git_commit_sha,_Q:plan_activity.prev_plan_id,_R:plan_activity.version,_L:models_directly,_S:models_indirectly,_G:diff_json,_T:plan_activity.has_changes,_U:bool(plan_activity.backfills),_H:plan_activity.success,_D:plan_seq}]);self.engine_adapter.insert_append(self.plans_table,df,target_columns_to_types=self._plan_columns_to_types,track_rows_processed=_O)
	def store_run_activity(self,run_activity:RunActivity)->str:
		import os,pandas as pd,time;run_id=run_activity.run_id;executor=os.environ.get('VULCAN_USER',os.environ.get('USER','unknown'));updated_ts_ns=time.time_ns()
		with self.engine_adapter.transaction():
			self.engine_adapter.delete_from(self.runs_table,where=exp.EQ(this=exp.column(_M),expression=exp.Literal.string(run_id)));next_seq_result=fetchone(self.engine_adapter,exp.select(exp.func(_b,exp.func('MAX',exp.column(_N)),0).as_(_c)).from_(self.runs_table).where(exp.EQ(this=exp.column(_B),expression=exp.Literal.string(run_activity.environment))));run_seq=(next_seq_result[0]or 0)+1 if next_seq_result else 1;execution_json=run_activity.model_dump_json();df=pd.DataFrame([{_M:run_id,_F:run_activity.plan_id,_B:run_activity.environment,_E:int(run_activity.start_ts),_J:int(run_activity.end_ts),_C:updated_ts_ns,_K:executor,_H:run_activity.success,_V:[m.name for m in run_activity.models_affected]if run_activity.models_affected else _A,_W:run_activity.rows_affected,_X:run_activity.bytes_processed,_Y:run_activity.total_evaluation_ms,_Z:execution_json,_N:run_seq}]);self.engine_adapter.insert_append(self.runs_table,df,target_columns_to_types=self._run_columns_to_types,track_rows_processed=_O)
			if run_activity.models_affected and is_postgres(self.engine_adapter):model_names=[m.name for m in run_activity.models_affected];self._expire_query_fingerprints_by_models(model_names=model_names,run_id=run_id)
		return run_id
	def list_plans(self,plan_id:t.Optional[str]=_A,environment:t.Optional[str]=_A,plan_seq:t.Optional[int]=_A,model_names:t.Optional[t.List[str]]=_A,success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[PlanActivity]:
		start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A;order=exp.Ordered(this=exp.column(_E),desc=_I)
		if plan_id:where=exp.EQ(this=exp.column(_F),expression=exp.Literal.string(plan_id));query=exp.select(exp.column(_G),exp.column(_D)).from_(self.plans_table).where(where).order_by(order)
		else:
			if environment is _A:return[]
			conditions:t.List[exp.Expression]=[exp.EQ(this=exp.column(_B),expression=exp.Literal.string(environment))]
			if plan_seq is not _A:conditions.append(exp.EQ(this=exp.column(_D),expression=exp.Literal.number(plan_seq)))
			if model_names:conditions.append(exp.ArrayOverlaps(this=exp.column(_L),expression=exp.Array(expressions=[exp.Literal.string(m)for m in model_names])))
			if success is not _A:conditions.append(exp.column(_H).eq(exp.true()if success else exp.false()))
			if start_ms is not _A:conditions.append(exp.GTE(this=exp.column(_E),expression=exp.Literal.number(start_ms)))
			if end_ms is not _A:conditions.append(exp.LTE(this=exp.column(_E),expression=exp.Literal.number(end_ms)))
			where=exp.and_(*conditions);query=exp.select(exp.column(_G),exp.column(_D)).from_(self.plans_table).where(where).order_by(order).limit(limit).offset(offset)
		with self.engine_adapter.transaction():
			if plan_id:row=fetch_row_as_dict(self.engine_adapter,query);rows=[row]if row is not _A else[]
			else:rows=fetch_rows_as_dicts(self.engine_adapter,query)
		plans:t.List[PlanActivity]=[]
		for row in rows:
			plan_diff_json=row[_G];plan_seq_val=row[_D]
			if not plan_diff_json:continue
			if isinstance(plan_diff_json,str):plan_activity=PlanActivity.parse_raw(plan_diff_json)
			else:plan_activity=PlanActivity.model_validate(plan_diff_json)
			plans.append(plan_activity.model_copy(update={_D:plan_seq_val}))
		return plans
	def get_last_successful_run_end_ts_by_model(self,environment:str)->t.Dict[str,int]:raise_if_not_postgres(self.engine_adapter,feature='get_last_successful_run_end_ts_by_model');runs_table_str=self.runs_table.sql(dialect=self.engine_adapter.dialect,identify=_I);sql=f"""
            SELECT
                model_name,
                MAX(end_ts) AS ts
            FROM {runs_table_str} r
            CROSS JOIN LATERAL unnest(r.models_affected) AS model_name
            WHERE r.environment = %s
                AND r.success = true
                AND r.models_affected IS NOT NULL
            GROUP BY model_name
        """;rows=fetch_rows_as_dicts(self.engine_adapter,sql,(environment,));return{row[_a]:row['ts']for row in rows}
	def fetch_plan_run_activity_since(self,since_ts_ns:int=0)->t.Tuple[t.List[EnvironmentChange],int]:
		A='action_type';raise_if_not_postgres(self.engine_adapter,feature='fetch_plan_run_activity_since');plans_query=exp.select(_B,exp.Literal.string('plan').as_(A),_C).from_(self.plans_table).where(exp.GT(this=exp.column(_C),expression=exp.Literal.number(since_ts_ns)));runs_query=exp.select(_B,exp.Literal.string('run').as_(A),_C).from_(self.runs_table).where(exp.GT(this=exp.column(_C),expression=exp.Literal.number(since_ts_ns)));combined_query=exp.union(plans_query,runs_query,distinct=_O);combined_query=combined_query.order_by(exp.Ordered(this=exp.column(_C),desc=_I));rows=fetch_rows_as_dicts(self.engine_adapter,combined_query)
		if not rows:return[],since_ts_ns
		changes_dict:t.Dict[str,EnvironmentChange]={};max_overall_ts_ns=since_ts_ns
		for row in rows:env_name=row[_B];action_type=row[A];created_ts_ns=row[_C];change=changes_dict.setdefault(env_name,EnvironmentChange(environment=env_name));setattr(change,f"has_{action_type}",_I);max_overall_ts_ns=max(max_overall_ts_ns,created_ts_ns)
		return list(changes_dict.values()),max_overall_ts_ns
	def _expire_query_fingerprints_by_models(self,model_names:t.Union[str,t.List[str]],run_id:str)->_A:
		C='invalidated_by_run_id';B='_model';A='expires_ts';raise_if_not_postgres(self.engine_adapter,feature='_expire_query_fingerprints_by_models')
		if isinstance(model_names,str):model_names=[model_names]
		if not model_names:return
		run_info=f" (run_id={run_id})"if run_id else'';logger.info(f"Expiring query fingerprint entries for {len(model_names)} model(s): {model_names}{run_info}");now_ts=to_timestamp(datetime.utcnow());where_clause=exp.and_(exp.Exists(this=exp.select(exp.Literal.number(1)).from_(exp.Unnest(expressions=[exp.column('depends_on')],alias=exp.TableAlias(this=exp.to_identifier(B)))).where(exp.column(B).isin(*[exp.Literal.string(m)for m in model_names]))),exp.or_(exp.column(A).is_(exp.null()),exp.column(A)>now_ts),exp.column(C).is_(exp.null()));update_props={A:now_ts,'invalidated_ts':now_ts,C:run_id};self.engine_adapter.execute(exp.update(self.query_fingerprints,update_props,where=where_clause));rowcount=getattr(self.engine_adapter.cursor,'rowcount',_A)
		if rowcount is not _A and rowcount>=0:logger.info(f"Expired {rowcount} query fingerprint entries {run_info}");return
		logger.info(f"Expired query fingerprint entries (row count not reported by {self.engine_adapter.dialect} driver){run_info}")