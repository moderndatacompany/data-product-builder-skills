from __future__ import annotations
_A='StateStream'
import logging,typing as t
from functools import wraps
import itertools,abc
from dataclasses import dataclass
from pydantic_core.core_schema import ValidationInfo
from sqlglot import exp
from vulcan.utils.pydantic import PydanticModel,field_validator
from vulcan.core.environment import Environment,EnvironmentStatements,EnvironmentNamingInfo
from vulcan.core.snapshot import Snapshot,SnapshotId,SnapshotTableCleanupTask,SnapshotTableInfo
if t.TYPE_CHECKING:from vulcan.core.state_sync.base import Versions,StateReader
logger=logging.getLogger(__name__)
EXPIRED_SNAPSHOT_DEFAULT_BATCH_SIZE=200
def transactional()->t.Callable[[t.Callable],t.Callable]:
	def decorator(func:t.Callable)->t.Callable:
		@wraps(func)
		def wrapper(self:t.Any,*args:t.Any,**kwargs:t.Any)->t.Any:
			if not hasattr(self,'_transaction'):return func(self,*args,**kwargs)
			with self._transaction():return func(self,*args,**kwargs)
		return wrapper
	return decorator
T=t.TypeVar('T')
def chunk_iterable(iterable:t.Iterable[T],size:int=10)->t.Iterable[t.Iterable[T]]:
	iterator=iter(iterable)
	for first in iterator:yield itertools.chain([first],itertools.islice(iterator,size-1))
class EnvironmentWithStatements(PydanticModel):environment:Environment;statements:t.List[EnvironmentStatements]=[]
@dataclass
class VersionsChunk:versions:Versions
class SnapshotsChunk:
	def __init__(self,items:t.Iterator[Snapshot]):self.items=items
	def __iter__(self)->t.Iterator[Snapshot]:return self.items
class EnvironmentsChunk:
	def __init__(self,items:t.Iterator[EnvironmentWithStatements]):self.items=items
	def __iter__(self)->t.Iterator[EnvironmentWithStatements]:return self.items
StateStreamContents=t.Union[VersionsChunk,SnapshotsChunk,EnvironmentsChunk]
class StateStream(abc.ABC):
	@abc.abstractmethod
	def __iter__(self)->t.Iterator[StateStreamContents]:0
	@classmethod
	def from_iterators(cls:t.Type[_A],versions:Versions,snapshots:t.Iterator[Snapshot],environments:t.Iterator[EnvironmentWithStatements])->_A:
		class _StateStream(cls):
			def __iter__(self)->t.Iterator[StateStreamContents]:yield VersionsChunk(versions);yield SnapshotsChunk(snapshots);yield EnvironmentsChunk(environments)
		return _StateStream()
class ExpiredBatchRange(PydanticModel):
	start:RowBoundary;end:t.Union[RowBoundary,LimitBoundary]
	@classmethod
	def init_batch_range(cls,batch_size:int)->ExpiredBatchRange:return ExpiredBatchRange(start=RowBoundary.lowest_boundary(),end=LimitBoundary(batch_size=batch_size))
	@classmethod
	def all_batch_range(cls)->ExpiredBatchRange:return ExpiredBatchRange(start=RowBoundary.lowest_boundary(),end=RowBoundary.highest_boundary())
	@classmethod
	def _expanded_tuple_comparison(cls,columns:t.List[exp.Column],values:t.List[exp.Literal],operator:t.Type[exp.Expression])->exp.Expression:
		if operator not in(exp.GT,exp.GTE,exp.LT,exp.LTE):raise ValueError(f"Unsupported operator: {operator}. Use GT, GTE, LT, or LTE.")
		strict_operator:t.Type[exp.Expression];final_operator:t.Type[exp.Expression]
		if operator in(exp.LTE,exp.GTE):strict_operator=exp.LT if operator==exp.LTE else exp.GT;final_operator=operator
		else:strict_operator=operator;final_operator=operator
		conditions:t.List[exp.Expression]=[]
		for i in range(len(columns)):
			equality_conditions=[exp.EQ(this=columns[j],expression=values[j])for j in range(i)];comparison_op=final_operator if i==len(columns)-1 else strict_operator;comparison_condition=comparison_op(this=columns[i],expression=values[i])
			if equality_conditions:conditions.append(exp.and_(*equality_conditions,comparison_condition))
			else:conditions.append(comparison_condition)
		return exp.or_(*conditions)if len(conditions)>1 else conditions[0]
	@property
	def where_filter(self)->exp.Expression:
		columns=[exp.column('updated_ts'),exp.column('name'),exp.column('identifier')];start_values=[exp.Literal.number(self.start.updated_ts),exp.Literal.string(self.start.name),exp.Literal.string(self.start.identifier)];start_condition=self._expanded_tuple_comparison(columns,start_values,exp.GT);range_filter:exp.Expression
		if isinstance(self.end,RowBoundary):end_values=[exp.Literal.number(self.end.updated_ts),exp.Literal.string(self.end.name),exp.Literal.string(self.end.identifier)];end_condition=self._expanded_tuple_comparison(columns,end_values,exp.LTE);range_filter=exp.and_(start_condition,end_condition)
		else:range_filter=start_condition
		return range_filter
class RowBoundary(PydanticModel):
	updated_ts:int;name:str;identifier:str
	@classmethod
	def lowest_boundary(cls)->RowBoundary:return RowBoundary(updated_ts=0,name='',identifier='')
	@classmethod
	def highest_boundary(cls)->RowBoundary:return RowBoundary(updated_ts=0xe677d21fdbff,name='',identifier='')
class LimitBoundary(PydanticModel):
	batch_size:int
	@classmethod
	def init_batch_boundary(cls,batch_size:int)->LimitBoundary:return LimitBoundary(batch_size=batch_size)
class PromotionResult(PydanticModel):
	added:t.List[SnapshotTableInfo];removed:t.List[SnapshotTableInfo];removed_environment_naming_info:t.Optional[EnvironmentNamingInfo]
	@field_validator('removed_environment_naming_info')
	def _validate_removed_environment_naming_info(cls,v:t.Optional[EnvironmentNamingInfo],info:ValidationInfo)->t.Optional[EnvironmentNamingInfo]:
		if v and not info.data.get('removed'):raise ValueError('removed_environment_naming_info must be None if removed is empty')
		return v
class ExpiredSnapshotBatch(PydanticModel):expired_snapshot_ids:t.Set[SnapshotId];cleanup_tasks:t.List[SnapshotTableCleanupTask];batch_range:ExpiredBatchRange
def iter_expired_snapshot_batches(state_reader:StateReader,*,current_ts:int,ignore_ttl:bool=False,batch_size:t.Optional[int]=None)->t.Iterator[ExpiredSnapshotBatch]:
	batch_size=batch_size if batch_size is not None else EXPIRED_SNAPSHOT_DEFAULT_BATCH_SIZE;batch_range=ExpiredBatchRange.init_batch_range(batch_size=batch_size)
	while True:
		batch=state_reader.get_expired_snapshots(current_ts=current_ts,ignore_ttl=ignore_ttl,batch_range=batch_range)
		if batch is None:return
		yield batch;assert isinstance(batch.batch_range.end,RowBoundary),'Only RowBoundary is supported for pagination currently';batch_range=ExpiredBatchRange(start=batch.batch_range.end,end=LimitBoundary(batch_size=batch_size))