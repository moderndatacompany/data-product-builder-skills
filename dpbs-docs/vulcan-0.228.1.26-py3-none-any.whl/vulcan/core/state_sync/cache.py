from __future__ import annotations
_B=False
_A=None
import typing as t
from vulcan.core.model import SeedModel
from vulcan.core.snapshot import Snapshot,SnapshotId,SnapshotIdLike,SnapshotIdAndVersionLike,SnapshotInfoLike
from vulcan.core.snapshot.definition import Interval,SnapshotIntervals
from vulcan.core.state_sync.base import DelegatingStateSync,StateSync
from vulcan.core.state_sync.common import ExpiredBatchRange
from vulcan.utils.date import TimeLike,now_timestamp
class CachingStateSync(DelegatingStateSync):
	def __init__(self,state_sync:StateSync,ttl:int=120):super().__init__(state_sync);(self.snapshot_cache):t.Dict[SnapshotId,t.Tuple[t.Optional[Snapshot|t.Literal[_B]],int]]={};self.ttl=ttl
	def _from_cache(self,snapshot_id:SnapshotId,now:int)->t.Optional[Snapshot|t.Literal[_B]]:
		snapshot:t.Optional[Snapshot|t.Literal[_B]]=_A;snapshot_expiration=self.snapshot_cache.get(snapshot_id)
		if snapshot_expiration and snapshot_expiration[1]>=now:snapshot=snapshot_expiration[0]
		return snapshot
	def get_snapshots(self,snapshot_ids:t.Iterable[SnapshotIdLike])->t.Dict[SnapshotId,Snapshot]:
		existing={};missing=set();now=now_timestamp();expire_at=now+self.ttl*1000
		for s in snapshot_ids:
			snapshot_id=s.snapshot_id;snapshot=self._from_cache(snapshot_id,now)
			if snapshot is _A:self.snapshot_cache[snapshot_id]=_B,expire_at;missing.add(snapshot_id)
			elif snapshot:existing[snapshot_id]=snapshot
		if missing:existing.update(self.state_sync.get_snapshots(missing))
		for(snapshot_id,snapshot)in existing.items():
			cached=self._from_cache(snapshot_id,now)
			if cached and(not isinstance(cached.node,SeedModel)or cached.node.is_hydrated):continue
			self.snapshot_cache[snapshot_id]=snapshot,expire_at
		return existing
	def snapshots_exist(self,snapshot_ids:t.Iterable[SnapshotIdLike])->t.Set[SnapshotId]:
		existing=set();missing=set();now=now_timestamp()
		for s in snapshot_ids:
			snapshot_id=s.snapshot_id;snapshot=self._from_cache(snapshot_id,now)
			if snapshot:existing.add(snapshot_id)
			elif snapshot is _A:missing.add(snapshot_id)
		if missing:existing.update(self.state_sync.snapshots_exist(missing))
		return existing
	def push_snapshots(self,snapshots:t.Iterable[Snapshot])->_A:
		snapshots=tuple(snapshots)
		for snapshot in snapshots:self.snapshot_cache.pop(snapshot.snapshot_id,_A)
		self.state_sync.push_snapshots(snapshots)
	def delete_snapshots(self,snapshot_ids:t.Iterable[SnapshotIdLike])->_A:
		snapshot_ids=tuple(snapshot_ids)
		for s in snapshot_ids:self.snapshot_cache.pop(s.snapshot_id,_A)
		self.state_sync.delete_snapshots(snapshot_ids)
	def delete_expired_snapshots(self,batch_range:ExpiredBatchRange,ignore_ttl:bool=_B,current_ts:t.Optional[int]=_A)->_A:self.snapshot_cache.clear();self.state_sync.delete_expired_snapshots(batch_range=batch_range,ignore_ttl=ignore_ttl,current_ts=current_ts)
	def add_snapshots_intervals(self,snapshots_intervals:t.Sequence[SnapshotIntervals])->_A:
		for snapshot_intervals in snapshots_intervals:
			if snapshot_intervals.snapshot_id:self.snapshot_cache.pop(snapshot_intervals.snapshot_id,_A)
			else:self.snapshot_cache={snapshot_id:value for(snapshot_id,value)in self.snapshot_cache.items()if snapshot_id.name!=snapshot_intervals.name}
		self.state_sync.add_snapshots_intervals(snapshots_intervals)
	def remove_intervals(self,snapshot_intervals:t.Sequence[t.Tuple[SnapshotIdAndVersionLike,Interval]],remove_shared_versions:bool=_B)->_A:
		for(s,_)in snapshot_intervals:self.snapshot_cache.pop(s.snapshot_id,_A)
		self.state_sync.remove_intervals(snapshot_intervals,remove_shared_versions)
	def unpause_snapshots(self,snapshots:t.Collection[SnapshotInfoLike],unpaused_dt:TimeLike)->_A:self.snapshot_cache.clear();self.state_sync.unpause_snapshots(snapshots,unpaused_dt)
	def clear_cache(self)->_A:self.snapshot_cache.clear()