from __future__ import annotations
_I='catalog'
_H='pending_restatement_intervals'
_G='physical_schema'
_F='dev_intervals'
_E='intervals'
_D='dev_version'
_C=True
_B=False
_A=None
import sys,typing as t
from collections import defaultdict
from datetime import datetime,timedelta
from enum import IntEnum
import logging
from functools import cached_property,lru_cache
from pathlib import Path
from pydantic import Field
from sqlglot import exp
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from vulcan.core.config.common import TableNamingConvention,VirtualEnvironmentMode,EnvironmentSuffixTarget
from vulcan.core import constants as c
from vulcan.core.audit import StandaloneAudit
from vulcan.core.macros import call_macro
from vulcan.core.model import Model,ModelKindMixin,ModelKindName,ViewKind,CustomKind
from vulcan.core.model.definition import _Model
from vulcan.core.node import IntervalUnit,NodeType
from vulcan.utils import sanitize_name,unique
from vulcan.utils.dag import DAG
from vulcan.utils.date import TimeLike,is_date,make_inclusive,make_exclusive,make_inclusive_end,now,now_timestamp,time_like_to_str,to_date,to_datetime,to_ds,to_timestamp,to_ts,validate_date_range,yesterday
from vulcan.utils.errors import VulcanError,SignalEvalError
from vulcan.utils.metaprogramming import format_evaluated_code_exception,Executable
from vulcan.utils.hashing import hash_data,md5
from vulcan.utils.pydantic import PydanticModel,field_validator
if t.TYPE_CHECKING:from sqlglot.dialects.dialect import DialectType;from vulcan.core.environment import EnvironmentNamingInfo;from vulcan.core.context import ExecutionContext
Interval=t.Tuple[int,int]
Intervals=t.List[Interval]
Node=t.Annotated[t.Union[Model,StandaloneAudit],Field(discriminator='source_type')]
logger=logging.getLogger(__name__)
class SnapshotChangeCategory(IntEnum):
	BREAKING=1;NON_BREAKING=2;FORWARD_ONLY=3;INDIRECT_BREAKING=4;INDIRECT_NON_BREAKING=5;METADATA=6
	@property
	def is_breaking(self)->bool:return self==self.BREAKING
	@property
	def is_non_breaking(self)->bool:return self==self.NON_BREAKING
	@property
	def is_forward_only(self)->bool:return self==self.FORWARD_ONLY
	@property
	def is_metadata(self)->bool:return self==self.METADATA
	@property
	def is_indirect_breaking(self)->bool:return self==self.INDIRECT_BREAKING
	@property
	def is_indirect_non_breaking(self)->bool:return self==self.INDIRECT_NON_BREAKING
	def __repr__(self)->str:return self.name
class SnapshotFingerprint(PydanticModel,frozen=_C):
	data_hash:str;metadata_hash:str;parent_data_hash:str='0';parent_metadata_hash:str='0'
	def to_version(self)->str:return hash_data([self.data_hash,self.parent_data_hash])
	def to_identifier(self)->str:return hash_data([self.data_hash,self.metadata_hash,self.parent_data_hash,self.parent_metadata_hash])
	def __str__(self)->str:return f"SnapshotFingerprint<{self.to_identifier()}, data: {self.data_hash}, meta: {self.metadata_hash}, pdata: {self.parent_data_hash}, pmeta: {self.parent_metadata_hash}>"
class SnapshotId(PydanticModel,frozen=_C):
	name:str;identifier:str
	@property
	def snapshot_id(self)->SnapshotId:return self
	def __eq__(self,other:t.Any)->bool:return isinstance(other,self.__class__)and self.name==other.name and self.identifier==other.identifier
	def __hash__(self)->int:return hash((self.__class__,self.name,self.identifier))
	def __lt__(self,other:SnapshotId)->bool:return self.name<other.name
	def __str__(self)->str:return f"SnapshotId<{self.name}: {self.identifier}>"
class SnapshotIdBatch(PydanticModel,frozen=_C):snapshot_id:SnapshotId;batch_id:int
class SnapshotNameVersion(PydanticModel,frozen=_C):
	name:str;version:str
	@property
	def name_version(self)->SnapshotNameVersion:return self
class SnapshotIntervals(PydanticModel):
	name:str;identifier:t.Optional[str];version:str;dev_version:t.Optional[str];intervals:Intervals=[];dev_intervals:Intervals=[];pending_restatement_intervals:Intervals=[];last_altered_ts:t.Optional[int]=_A;dev_last_altered_ts:t.Optional[int]=_A
	@property
	def snapshot_id(self)->t.Optional[SnapshotId]:
		if not self.identifier:return
		return SnapshotId(name=self.name,identifier=self.identifier)
	@property
	def name_version(self)->SnapshotNameVersion:return SnapshotNameVersion(name=self.name,version=self.version)
	def add_interval(self,start:int,end:int)->_A:self._add_interval(start,end,_E)
	def add_dev_interval(self,start:int,end:int)->_A:self._add_interval(start,end,_F)
	def add_pending_restatement_interval(self,start:int,end:int)->_A:self._add_interval(start,end,_H)
	def update_last_altered_ts(self,last_altered_ts:t.Optional[int])->_A:self._update_last_altered_ts(last_altered_ts,'last_altered_ts')
	def update_dev_last_altered_ts(self,last_altered_ts:t.Optional[int])->_A:self._update_last_altered_ts(last_altered_ts,'dev_last_altered_ts')
	def remove_interval(self,start:int,end:int)->_A:self._remove_interval(start,end,_E)
	def remove_dev_interval(self,start:int,end:int)->_A:self._remove_interval(start,end,_F)
	def remove_pending_restatement_interval(self,start:int,end:int)->_A:self._remove_interval(start,end,_H)
	def is_empty(self)->bool:return not self.intervals and not self.dev_intervals and not self.pending_restatement_intervals
	def _add_interval(self,start:int,end:int,interval_attr:str)->_A:target_intervals=getattr(self,interval_attr);target_intervals=merge_intervals([*target_intervals,(start,end)]);setattr(self,interval_attr,target_intervals)
	def _update_last_altered_ts(self,last_altered_ts:t.Optional[int],last_altered_attr:str)->_A:
		if last_altered_ts:existing_last_altered_ts=getattr(self,last_altered_attr);setattr(self,last_altered_attr,max(existing_last_altered_ts or 0,last_altered_ts))
	def _remove_interval(self,start:int,end:int,interval_attr:str)->_A:target_intervals=getattr(self,interval_attr);target_intervals=remove_interval(target_intervals,start,end);setattr(self,interval_attr,target_intervals)
class SnapshotDataVersion(PydanticModel,frozen=_C):
	fingerprint:SnapshotFingerprint;version:str;dev_version_:t.Optional[str]=Field(default=_A,alias=_D);change_category:t.Optional[SnapshotChangeCategory]=_A;physical_schema_:t.Optional[str]=Field(default=_A,alias=_G);dev_table_suffix:str;table_naming_convention:TableNamingConvention=Field(default=TableNamingConvention.default);virtual_environment_mode:VirtualEnvironmentMode=Field(default=VirtualEnvironmentMode.default)
	def snapshot_id(self,name:str)->SnapshotId:return SnapshotId(name=name,identifier=self.fingerprint.to_identifier())
	@property
	def dev_version(self)->str:return self.dev_version_ or self.fingerprint.to_version()
	@property
	def physical_schema(self)->str:return self.physical_schema_ or c.SQLMESH
	@property
	def data_version(self)->SnapshotDataVersion:return self
	@property
	def is_new_version(self)->bool:return self.fingerprint.to_version()==self.version
class QualifiedViewName(PydanticModel,frozen=_C):
	catalog:t.Optional[str]=_A;schema_name:t.Optional[str]=_A;table:str
	def for_environment(self,environment_naming_info:EnvironmentNamingInfo,dialect:DialectType=_A)->str:return exp.table_name(self.table_for_environment(environment_naming_info,dialect=dialect))
	def table_for_environment(self,environment_naming_info:EnvironmentNamingInfo,dialect:DialectType=_A)->exp.Table:return exp.table_(self.table_name_for_environment(environment_naming_info,dialect=dialect),db=self.schema_for_environment(environment_naming_info,dialect=dialect),catalog=self.catalog_for_environment(environment_naming_info,dialect=dialect))
	def catalog_for_environment(self,environment_naming_info:EnvironmentNamingInfo,dialect:DialectType=_A)->t.Optional[str]:
		catalog_name:t.Optional[str]=_A
		if environment_naming_info.is_dev and environment_naming_info.suffix_target.is_catalog:catalog_name=f"{self.catalog}__{environment_naming_info.name}"
		elif environment_naming_info.catalog_name_override:catalog_name=environment_naming_info.catalog_name_override
		if catalog_name:return normalize_identifiers(catalog_name,dialect=dialect).name if environment_naming_info.normalize_name else catalog_name
		return self.catalog
	def schema_for_environment(self,environment_naming_info:EnvironmentNamingInfo,dialect:DialectType=_A)->str:
		normalize=environment_naming_info.normalize_name
		if self.schema_name:schema=self.schema_name
		else:
			schema=c.DEFAULT_SCHEMA
			if normalize:schema=normalize_identifiers(schema,dialect=dialect).name
		if environment_naming_info.is_dev and environment_naming_info.suffix_target.is_schema:
			env_name=environment_naming_info.name
			if normalize:env_name=normalize_identifiers(env_name,dialect=dialect).name
			schema=f"{schema}__{env_name}"
		return schema
	def table_name_for_environment(self,environment_naming_info:EnvironmentNamingInfo,dialect:DialectType=_A)->str:
		table=self.table
		if environment_naming_info.is_dev and environment_naming_info.suffix_target.is_table:
			env_name=environment_naming_info.name
			if environment_naming_info.normalize_name:env_name=normalize_identifiers(env_name,dialect=dialect).name
			table=f"{table}__{env_name}"
		return table
class SnapshotInfoMixin(ModelKindMixin):
	name:str;dev_version_:t.Optional[str];change_category:t.Optional[SnapshotChangeCategory];fingerprint:SnapshotFingerprint;previous_versions:t.Tuple[SnapshotDataVersion,...];base_table_name_override:t.Optional[str];dev_table_suffix:str;table_naming_convention:TableNamingConvention;forward_only:bool
	@cached_property
	def identifier(self)->str:return self.fingerprint.to_identifier()
	@cached_property
	def snapshot_id(self)->SnapshotId:return SnapshotId(name=self.name,identifier=self.identifier)
	@property
	def qualified_view_name(self)->QualifiedViewName:view_name=exp.to_table(self.fully_qualified_table or self.name);return QualifiedViewName(catalog=view_name.catalog or _A,schema_name=view_name.db or _A,table=view_name.name)
	@property
	def previous_version(self)->t.Optional[SnapshotDataVersion]:
		if self.previous_versions:return self.previous_versions[-1]
	@property
	def dev_version(self)->str:return self.dev_version_ or self.fingerprint.to_version()
	@property
	def physical_schema(self)->str:raise NotImplementedError
	@property
	def data_version(self)->SnapshotDataVersion:raise NotImplementedError
	@property
	def is_new_version(self)->bool:raise NotImplementedError
	@cached_property
	def fully_qualified_table(self)->t.Optional[exp.Table]:raise NotImplementedError
	@property
	def virtual_environment_mode(self)->VirtualEnvironmentMode:raise NotImplementedError
	@property
	def is_forward_only(self)->bool:return self.forward_only or self.change_category==SnapshotChangeCategory.FORWARD_ONLY
	@property
	def is_metadata(self)->bool:return self.change_category==SnapshotChangeCategory.METADATA
	@property
	def is_indirect_non_breaking(self)->bool:return self.change_category==SnapshotChangeCategory.INDIRECT_NON_BREAKING
	@property
	def is_no_rebuild(self)->bool:return self.forward_only or self.change_category in(SnapshotChangeCategory.FORWARD_ONLY,SnapshotChangeCategory.METADATA,SnapshotChangeCategory.INDIRECT_NON_BREAKING)
	@property
	def is_no_preview(self)->bool:return self.forward_only and self.change_category in(SnapshotChangeCategory.METADATA,SnapshotChangeCategory.INDIRECT_NON_BREAKING)
	@property
	def all_versions(self)->t.Tuple[SnapshotDataVersion,...]:return(*self.previous_versions,self.data_version)[-c.DATA_VERSION_LIMIT:]
	def display_name(self,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],dialect:DialectType=_A)->str:return display_name(self,environment_naming_info,default_catalog,dialect=dialect)
	def data_hash_matches(self,other:t.Optional[SnapshotInfoMixin|SnapshotDataVersion])->bool:return other is not _A and self.fingerprint.data_hash==other.fingerprint.data_hash
	def _table_name(self,version:str,is_deployable:bool)->str:
		if self.is_external:return self.name
		if is_deployable and self.virtual_environment_mode.is_dev_only:return self.name
		is_dev_table=not is_deployable
		if is_dev_table:version=self.dev_version
		if self.fully_qualified_table is _A:raise VulcanError(f"Tried to get a table name for a snapshot that does not have a table. {self.name}")
		if self.base_table_name_override:base_table_name=self.base_table_name_override
		else:fqt=self.fully_qualified_table.copy();fqt.set(_I,_A);base_table_name=fqt.sql()
		return table_name(self.physical_schema,base_table_name,version,catalog=self.fully_qualified_table.catalog,suffix=self.dev_table_suffix if is_dev_table else _A,naming_convention=self.table_naming_convention)
	@property
	def node_type(self)->NodeType:raise NotImplementedError
	@property
	def is_model(self)->bool:return self.node_type==NodeType.MODEL
	@property
	def is_audit(self)->bool:return self.node_type==NodeType.AUDIT
	@property
	def is_semantic(self)->bool:return _B
	@property
	def is_semantic_model(self)->bool:return _B
	@property
	def is_semantic_metric(self)->bool:return _B
class SnapshotTableInfo(PydanticModel,SnapshotInfoMixin,frozen=_C):
	name:str;fingerprint:SnapshotFingerprint;version:str;dev_version_:t.Optional[str]=Field(default=_A,alias=_D);physical_schema_:str=Field(alias=_G);parents:t.Tuple[SnapshotId,...];previous_versions:t.Tuple[SnapshotDataVersion,...]=();change_category:t.Optional[SnapshotChangeCategory]=_A;kind_name:t.Optional[ModelKindName]=_A;node_type_:NodeType=Field(default=NodeType.MODEL,alias='node_type');base_table_name_override:t.Optional[str]=_A;custom_materialization:t.Optional[str]=_A;dev_table_suffix:str;model_gateway:t.Optional[str]=_A;forward_only:bool=_B;table_naming_convention:TableNamingConvention=TableNamingConvention.default;virtual_environment_mode_:VirtualEnvironmentMode=Field(default=VirtualEnvironmentMode.default,alias='virtual_environment_mode')
	def __lt__(self,other:SnapshotTableInfo)->bool:return self.name<other.name
	def __eq__(self,other:t.Any)->bool:return isinstance(other,SnapshotTableInfo)and self.fingerprint==other.fingerprint
	def __hash__(self)->int:return hash((self.__class__,self.name,self.fingerprint))
	def table_name(self,is_deployable:bool=_C)->str:return self._table_name(self.version,is_deployable)
	@property
	def physical_schema(self)->str:return self.physical_schema_
	@cached_property
	def fully_qualified_table(self)->exp.Table:return exp.to_table(self.name)
	@property
	def table_info(self)->SnapshotTableInfo:return self
	@property
	def virtual_environment_mode(self)->VirtualEnvironmentMode:return self.virtual_environment_mode_
	@property
	def data_version(self)->SnapshotDataVersion:return SnapshotDataVersion(fingerprint=self.fingerprint,version=self.version,dev_version=self.dev_version,change_category=self.change_category,physical_schema=self.physical_schema,dev_table_suffix=self.dev_table_suffix,table_naming_convention=self.table_naming_convention,virtual_environment_mode=self.virtual_environment_mode)
	@property
	def is_new_version(self)->bool:return self.fingerprint.to_version()==self.version
	@property
	def model_kind_name(self)->t.Optional[ModelKindName]:return self.kind_name
	@property
	def node_type(self)->NodeType:return self.node_type_
	@property
	def name_version(self)->SnapshotNameVersion:return SnapshotNameVersion(name=self.name,version=self.version)
	@property
	def id_and_version(self)->SnapshotIdAndVersion:return SnapshotIdAndVersion(name=self.name,kind_name=self.kind_name,identifier=self.identifier,version=self.version,dev_version=self.dev_version,fingerprint=self.fingerprint)
class SnapshotIdAndVersion(PydanticModel,ModelKindMixin):
	name:str;version:str;kind_name_:t.Optional[ModelKindName]=Field(default=_A,alias='kind_name');dev_version_:t.Optional[str]=Field(alias=_D);identifier:str;fingerprint_:t.Union[str,SnapshotFingerprint]=Field(alias='fingerprint')
	@property
	def snapshot_id(self)->SnapshotId:return SnapshotId(name=self.name,identifier=self.identifier)
	@property
	def id_and_version(self)->SnapshotIdAndVersion:return self
	@property
	def name_version(self)->SnapshotNameVersion:return SnapshotNameVersion(name=self.name,version=self.version)
	@property
	def fingerprint(self)->SnapshotFingerprint:
		value=self.fingerprint_
		if isinstance(value,str):self.fingerprint_=value=SnapshotFingerprint.parse_raw(value)
		return value
	@property
	def dev_version(self)->str:return self.dev_version_ or self.fingerprint.to_version()
	@property
	def model_kind_name(self)->t.Optional[ModelKindName]:return self.kind_name_
	def display_name(self,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],dialect:DialectType=_A)->str:return model_display_name(self.name,environment_naming_info,default_catalog,dialect=dialect)
class Snapshot(PydanticModel,SnapshotInfoMixin):
	name:str;fingerprint:SnapshotFingerprint;physical_schema_:t.Optional[str]=Field(default=_A,alias=_G);node:Node;parents:t.Tuple[SnapshotId,...];intervals:Intervals=[];dev_intervals:Intervals=[];pending_restatement_intervals:Intervals=[];created_ts:int;updated_ts:int;ttl:str;previous_versions:t.Tuple[SnapshotDataVersion,...]=();version:t.Optional[str]=_A;dev_version_:t.Optional[str]=Field(default=_A,alias=_D);change_category:t.Optional[SnapshotChangeCategory]=_A;unpaused_ts:t.Optional[int]=_A;effective_from:t.Optional[TimeLike]=_A;migrated:bool=_B;unrestorable:bool=_B;base_table_name_override:t.Optional[str]=_A;next_auto_restatement_ts:t.Optional[int]=_A;dev_table_suffix:str='dev';table_naming_convention:TableNamingConvention=TableNamingConvention.default;forward_only:bool=_B;last_altered_ts:t.Optional[int]=_A;dev_last_altered_ts:t.Optional[int]=_A
	@field_validator('ttl')
	@classmethod
	def _time_delta_must_be_positive(cls,v:str)->str:
		current_time=now()
		if to_datetime(v,current_time)<current_time:raise ValueError("Must be positive. Use the 'in' keyword to denote a positive time interval. For example, 'in 7 days'.")
		return v
	@staticmethod
	def hydrate_with_intervals_by_version(snapshots:t.Iterable[Snapshot],intervals:t.Iterable[SnapshotIntervals])->t.List[Snapshot]:
		intervals_by_name_version=defaultdict(list)
		for interval in intervals:intervals_by_name_version[interval.name,interval.version].append(interval)
		result=[]
		for snapshot in snapshots:
			snapshot_intervals=intervals_by_name_version.get((snapshot.name,snapshot.version_get_or_generate()),[])
			for interval in snapshot_intervals:snapshot.merge_intervals(interval)
			result.append(snapshot)
		return result
	@classmethod
	def from_node(cls,node:Node,*,nodes:t.Dict[str,Node],ttl:str=c.DEFAULT_SNAPSHOT_TTL,version:t.Optional[str]=_A,cache:t.Optional[t.Dict[str,SnapshotFingerprint]]=_A,table_naming_convention:TableNamingConvention=TableNamingConvention.default)->Snapshot:created_ts=now_timestamp();return cls(name=node.fqn,fingerprint=fingerprint_from_node(node,nodes=nodes,cache=cache),node=node,parents=tuple(SnapshotId(name=parent_node.fqn,identifier=fingerprint_from_node(parent_node,nodes=nodes,cache=cache).to_identifier())for parent_node in _parents_from_node(node,nodes).values()),intervals=[],dev_intervals=[],created_ts=created_ts,updated_ts=created_ts,ttl=ttl,version=version,table_naming_convention=table_naming_convention)
	def __eq__(self,other:t.Any)->bool:return isinstance(other,Snapshot)and self.fingerprint==other.fingerprint
	def __hash__(self)->int:return hash((self.__class__,self.name,self.fingerprint))
	def __lt__(self,other:Snapshot)->bool:return self.name<other.name
	def add_interval(self,start:TimeLike,end:TimeLike,is_dev:bool=_B)->_A:
		if to_timestamp(start)>to_timestamp(end):raise ValueError(f"Attempted to add an Invalid interval ({start}, {end}) to snapshot {self.snapshot_id}")
		start_ts,end_ts=self.inclusive_exclusive(start,end,strict=_B,expand=_B)
		if start_ts>=end_ts:return
		intervals=self.dev_intervals if is_dev else self.intervals;intervals.append((start_ts,end_ts))
		if len(intervals)<2:return
		merged_intervals=merge_intervals(intervals)
		if is_dev:self.dev_intervals=merged_intervals
		else:self.intervals=merged_intervals
	def remove_interval(self,interval:Interval)->_A:self.intervals=remove_interval(self.intervals,*interval);self.dev_intervals=remove_interval(self.dev_intervals,*interval)
	def get_removal_interval(self,start:TimeLike,end:TimeLike,execution_time:t.Optional[TimeLike]=_A,*,strict:bool=_C,is_preview:bool=_B)->Interval:
		end=execution_time or now_timestamp()if self.depends_on_past else end;removal_interval=self.inclusive_exclusive(start,end,strict)
		if not is_preview and self.full_history_restatement_only and self.intervals:
			expanded_removal_interval=self.inclusive_exclusive(self.intervals[0][0],end,strict);requested_start,requested_end=removal_interval;expanded_start,expanded_end=expanded_removal_interval
			if(requested_start>expanded_start or requested_end<expanded_end)and self.is_incremental:from vulcan.core.console import get_console;get_console().log_warning(f"Model '{self.model.name}' is '{self.model_kind_name}' which does not support partial restatement.\nExpanding the requested restatement intervals from [{to_ts(requested_start)} - {to_ts(requested_end)}] to [{to_ts(expanded_start)} - {to_ts(expanded_end)}] in order to fully restate the model.")
			removal_interval=expanded_removal_interval
		return removal_interval
	@property
	def allow_partials(self)->bool:return self.is_model and self.model.allow_partials
	def inclusive_exclusive(self,start:TimeLike,end:TimeLike,strict:bool=_C,allow_partial:t.Optional[bool]=_A,expand:bool=_C)->Interval:return inclusive_exclusive(start,end,self.node.interval_unit,strict=strict,allow_partial=self.allow_partials if allow_partial is _A else allow_partial,expand=expand)
	def merge_intervals(self,other:t.Union[Snapshot,SnapshotIntervals])->_A:
		effective_from_ts=self.normalized_effective_from_ts or 0;apply_effective_from=effective_from_ts>0 and self.identifier!=other.identifier
		for(start,end)in other.intervals:
			if apply_effective_from and start<effective_from_ts:end=min(end,effective_from_ts)
			if not apply_effective_from or end<=effective_from_ts:self.add_interval(start,end)
		if other.last_altered_ts:self.last_altered_ts=max(self.last_altered_ts or 0,other.last_altered_ts)
		if self.dev_version==other.dev_version:
			for(start,end)in other.dev_intervals:self.add_interval(start,end,is_dev=_C)
			if other.dev_last_altered_ts:self.dev_last_altered_ts=max(self.dev_last_altered_ts or 0,other.dev_last_altered_ts)
		self.pending_restatement_intervals=merge_intervals([*self.pending_restatement_intervals,*other.pending_restatement_intervals])
	@property
	def evaluatable(self)->bool:
		if self.is_semantic:return _B
		return bool(not self.is_symbolic or self.model.audits)
	def missing_intervals(self,start:TimeLike,end:TimeLike,execution_time:t.Optional[TimeLike]=_A,deployability_index:t.Optional[DeployabilityIndex]=_A,ignore_cron:bool=_B,end_bounded:bool=_B)->Intervals:
		if self.node.end and to_datetime(start)>to_datetime(self.node.end)or self.node.start and to_datetime(self.node.start)>to_datetime(end):return[]
		if self.node.start and to_datetime(start)<to_datetime(self.node.start):start=self.node.start
		validate_date_range(start,end)
		if not is_date(end)and not self.allow_partials and to_timestamp(end)-to_timestamp(start)<self.node.interval_unit.milliseconds:return[]
		deployability_index=deployability_index or DeployabilityIndex.all_deployable();intervals=self.intervals if deployability_index.is_representative(self)else self.dev_intervals
		if not self.evaluatable or self.is_seed and intervals:return[]
		start_ts,end_ts=(to_timestamp(ts)for ts in self.inclusive_exclusive(start,end));interval_unit=self.node.interval_unit;execution_time_ts=to_timestamp(execution_time)if execution_time else now_timestamp();upper_bound_ts=execution_time_ts if ignore_cron else to_timestamp(self.node.cron_floor(execution_time_ts))
		if end_bounded:upper_bound_ts=min(upper_bound_ts,end_ts)
		if not self.allow_partials:upper_bound_ts=to_timestamp(interval_unit.cron_floor(upper_bound_ts))
		end_ts=min(end_ts,upper_bound_ts);lookback=0;model_end_ts:t.Optional[int]=_A
		if self.is_model:lookback=self.model.lookback;model_end_ts=to_timestamp(make_exclusive(self.model.end))if self.model.end else _A
		return compute_missing_intervals(interval_unit,tuple(intervals),start_ts,end_ts,lookback,model_end_ts)
	def check_ready_intervals(self,intervals:Intervals,context:ExecutionContext)->Intervals:
		signals=self.is_model and self.model.render_signal_calls()
		if not signals:return intervals
		for(signal_name,kwargs)in signals.signals_to_kwargs.items():
			try:intervals=check_ready_intervals(signals.prepared_python_env[signal_name],intervals,context,python_env=signals.python_env,dialect=self.model.dialect,path=self.model._path,snapshot=self,kwargs=kwargs)
			except VulcanError as e:raise SignalEvalError(f"{e} '{signal_name}' for '{self.model.name}' at {self.model._path}")
		return intervals
	def categorize_as(self,category:SnapshotChangeCategory,forward_only:bool=_B)->_A:
		assert category!=SnapshotChangeCategory.FORWARD_ONLY,'FORWARD_ONLY change category is deprecated';self.dev_version_=self.fingerprint.to_version();is_no_rebuild=forward_only or category in(SnapshotChangeCategory.INDIRECT_NON_BREAKING,SnapshotChangeCategory.METADATA)
		if self.is_model and not self.virtual_environment_mode.is_full:self.version='novde'
		elif self.is_model and self.model.physical_version:self.version=self.model.physical_version
		elif is_no_rebuild and self.previous_version:self.version=self.previous_version.data_version.version
		elif self.is_model and self.model.forward_only and not self.previous_version:self.version=hash_data([self.name,*self.model.kind.data_hash_values])
		else:self.version=self.fingerprint.to_version()
		if is_no_rebuild and self.previous_version:
			previous_version=self.previous_version;self.physical_schema_=previous_version.physical_schema;self.table_naming_convention=previous_version.table_naming_convention
			if self.is_materialized and(category.is_indirect_non_breaking or category.is_metadata):self.dev_version_=previous_version.data_version.dev_version or previous_version.fingerprint.to_version();self.dev_table_suffix=previous_version.data_version.dev_table_suffix
		self.change_category=category;self.forward_only=forward_only
	@property
	def categorized(self)->bool:return self.change_category is not _A and self.version is not _A
	def table_name(self,is_deployable:bool=_C)->str:self._ensure_categorized();assert self.version;return self._table_name(self.version,is_deployable)
	def version_get_or_generate(self)->str:return self.version or self.fingerprint.to_version()
	def is_valid_start(self,start:t.Optional[TimeLike],snapshot_start:TimeLike,execution_time:t.Optional[TimeLike]=_A)->bool:
		if self.depends_on_past and start:
			interval_unit=self.node.interval_unit;start_ts=to_timestamp(interval_unit.cron_floor(start))
			if not self.intervals:
				snapshot_start_ts=to_timestamp(interval_unit.cron_floor(snapshot_start))
				if snapshot_start_ts<to_timestamp(snapshot_start):snapshot_start_ts=to_timestamp(interval_unit.cron_next(snapshot_start_ts))
				return snapshot_start_ts>=start_ts
			missing_intervals=self.missing_intervals(snapshot_start,now(),execution_time=execution_time);earliest_interval=missing_intervals[0][0]if missing_intervals else _A
			if earliest_interval:return earliest_interval>=start_ts
		return _C
	def get_latest(self,default:t.Optional[TimeLike]=_A)->t.Optional[TimeLike]:
		def to_end_date(end:int,unit:IntervalUnit)->TimeLike:
			if unit.is_day:return to_date(make_inclusive_end(end))
			return end
		return to_end_date(to_timestamp(self.intervals[-1][1]),self.node.interval_unit)if self.intervals else default
	def needs_destructive_check(self,allow_destructive_snapshots:t.Set[str])->bool:return self.is_model and not self.model.on_destructive_change.is_allow and self.name not in allow_destructive_snapshots
	def needs_additive_check(self,allow_additive_snapshots:t.Set[str])->bool:return self.is_model and not self.model.on_additive_change.is_allow and self.name not in allow_additive_snapshots
	def get_next_auto_restatement_interval(self,execution_time:TimeLike)->t.Optional[Interval]:
		if not self.is_model or not self.intervals or not self.model.auto_restatement_cron or self.model.disable_restatement:return
		execution_time_ts=to_timestamp(execution_time);next_auto_restatement_ts=self.next_auto_restatement_ts or to_timestamp(self.model.auto_restatement_croniter(self.created_ts).get_next(estimate=_B))
		if execution_time_ts<next_auto_restatement_ts:return
		num_intervals_to_restate=self.model.auto_restatement_intervals
		if num_intervals_to_restate is _A:return self.intervals[0][0],self.intervals[-1][1]
		auto_restatement_end_ts=to_timestamp(self.node.interval_unit.cron_floor(execution_time_ts));auto_restatement_start_ts=auto_restatement_end_ts-num_intervals_to_restate*self.node.interval_unit.milliseconds;return auto_restatement_start_ts,auto_restatement_end_ts
	def update_next_auto_restatement_ts(self,execution_time:TimeLike)->t.Optional[int]:
		if not self.is_model or not self.model.auto_restatement_cron or self.model.disable_restatement:self.next_auto_restatement_ts=_A
		else:self.next_auto_restatement_ts=to_timestamp(self.model.auto_restatement_croniter(execution_time).get_next(estimate=_B))
		return self.next_auto_restatement_ts
	def apply_pending_restatement_intervals(self)->_A:
		if not self.is_model or self.model.disable_restatement:return
		for pending_restatement_interval in self.pending_restatement_intervals:logger.info('Applying the auto restated interval (%s, %s) to snapshot %s',time_like_to_str(pending_restatement_interval[0]),time_like_to_str(pending_restatement_interval[1]),self.snapshot_id);self.intervals=remove_interval(self.intervals,*pending_restatement_interval)
	def is_directly_modified(self,other:Snapshot)->bool:return self.node.is_data_change(other.node)
	def is_indirectly_modified(self,other:Snapshot)->bool:return self.fingerprint.parent_data_hash!=other.fingerprint.parent_data_hash and not self.node.is_data_change(other.node)
	def is_metadata_updated(self,other:Snapshot)->bool:return self.fingerprint.metadata_hash!=other.fingerprint.metadata_hash
	@property
	def physical_schema(self)->str:
		if self.physical_schema_ is not _A:return self.physical_schema_
		return self.model.physical_schema if self.is_model else''
	@property
	def table_info(self)->SnapshotTableInfo:self._ensure_categorized();custom_materialization=self.model.kind.materialization if self.is_model and isinstance(self.model.kind,CustomKind)else _A;return SnapshotTableInfo(physical_schema=self.physical_schema,name=self.name,fingerprint=self.fingerprint,version=self.version,dev_version=self.dev_version,parents=self.parents,previous_versions=self.previous_versions,change_category=self.change_category,kind_name=self.model_kind_name,node_type=self.node_type,custom_materialization=custom_materialization,dev_table_suffix=self.dev_table_suffix,model_gateway=self.model_gateway,table_naming_convention=self.table_naming_convention,forward_only=self.forward_only,virtual_environment_mode=self.virtual_environment_mode)
	@property
	def data_version(self)->SnapshotDataVersion:self._ensure_categorized();return SnapshotDataVersion(fingerprint=self.fingerprint,version=self.version,dev_version=self.dev_version,change_category=self.change_category,physical_schema=self.physical_schema,dev_table_suffix=self.dev_table_suffix,table_naming_convention=self.table_naming_convention,virtual_environment_mode=self.virtual_environment_mode)
	@property
	def snapshot_intervals(self)->SnapshotIntervals:self._ensure_categorized();return SnapshotIntervals(name=self.name,identifier=self.identifier,version=self.version,dev_version=self.dev_version,intervals=self.intervals.copy(),dev_intervals=self.dev_intervals.copy(),pending_restatement_intervals=self.pending_restatement_intervals.copy())
	@property
	def is_materialized_view(self)->bool:return self.is_model and isinstance(self.model.kind,ViewKind)and self.model.kind.materialized
	@property
	def is_new_version(self)->bool:self._ensure_categorized();return self.fingerprint.to_version()==self.version
	@property
	def is_paused(self)->bool:return self.unpaused_ts is _A
	@property
	def is_paused_forward_only(self)->bool:return self.is_paused and self.is_forward_only
	@property
	def normalized_effective_from_ts(self)->t.Optional[int]:return to_timestamp(self.node.interval_unit.cron_floor(self.effective_from))if self.effective_from else _A
	@property
	def model_kind_name(self)->t.Optional[ModelKindName]:return self.model.kind.name if self.is_model else _A
	@property
	def node_type(self)->NodeType:
		if self.node.is_model:return NodeType.MODEL
		if self.node.is_audit:return NodeType.AUDIT
		raise VulcanError(f"Snapshot {self.snapshot_id} has an unknown node type.")
	@property
	def model(self)->Model:
		model=self.model_or_none
		if model:return model
		raise VulcanError(f"Snapshot {self.snapshot_id} is not a model snapshot.")
	@property
	def model_or_none(self)->t.Optional[Model]:
		if self.is_model:return t.cast(Model,self.node)
	@property
	def model_gateway(self)->t.Optional[str]:return self.model.gateway if self.is_model else _A
	@property
	def audit(self)->StandaloneAudit:
		if self.is_audit:return t.cast(StandaloneAudit,self.node)
		raise VulcanError(f"Snapshot {self.snapshot_id} is not an audit snapshot.")
	@property
	def depends_on_past(self)->bool:return self.depends_on_self or self.full_history_restatement_only
	@property
	def depends_on_self(self)->bool:return self.is_model and self.model.depends_on_self
	@property
	def name_version(self)->SnapshotNameVersion:return SnapshotNameVersion(name=self.name,version=self.version)
	@property
	def id_and_version(self)->SnapshotIdAndVersion:return self.table_info.id_and_version
	@property
	def disable_restatement(self)->bool:return self.is_model and self.model.disable_restatement
	@cached_property
	def fully_qualified_table(self)->t.Optional[exp.Table]:
		if not self.is_model:return
		return t.cast(Model,self.node).fully_qualified_table
	@property
	def expiration_ts(self)->int:return to_timestamp(self.ttl,relative_base=to_datetime(self.updated_ts),check_categorical_relative_expression=_B)
	@property
	def supports_schema_migration_in_prod(self)->bool:return self.is_paused and self.is_model and not self.is_symbolic and not self.is_seed
	@property
	def requires_schema_migration_in_prod(self)->bool:return self.supports_schema_migration_in_prod and(self.previous_version and self.previous_version.version==self.version or self.model.forward_only or bool(self.model.physical_version)or not self.virtual_environment_mode.is_full)
	@property
	def ttl_ms(self)->int:return self.expiration_ts-self.updated_ts
	@property
	def custom_materialization(self)->t.Optional[str]:
		if self.is_custom:return t.cast(CustomKind,self.model.kind).materialization
	@property
	def virtual_environment_mode(self)->VirtualEnvironmentMode:return self.model.virtual_environment_mode if self.is_model else VirtualEnvironmentMode.default
	def _ensure_categorized(self)->_A:
		if not self.change_category:raise VulcanError(f"Snapshot {self.snapshot_id} has not been categorized yet.")
		if not self.version:raise VulcanError(f"Snapshot {self.snapshot_id} has not been versioned yet.")
	def __getstate__(self)->t.Dict[t.Any,t.Any]:A='__dict__';state=super().__getstate__();state[A]=state[A].copy();state[A][_E]=[];state[A][_F]=[];return state
class SnapshotTableCleanupTask(PydanticModel):snapshot:SnapshotTableInfo;dev_table_only:bool
SnapshotIdLike=t.Union[SnapshotId,SnapshotIdAndVersion,SnapshotTableInfo,Snapshot]
SnapshotIdAndVersionLike=t.Union[SnapshotIdAndVersion,SnapshotTableInfo,Snapshot]
SnapshotInfoLike=t.Union[SnapshotTableInfo,Snapshot]
SnapshotNameVersionLike=t.Union[SnapshotNameVersion,SnapshotTableInfo,SnapshotIdAndVersion,Snapshot]
class DeployabilityIndex(PydanticModel,frozen=_C):
	indexed_ids:t.FrozenSet[str];is_opposite_index:bool=_B;representative_shared_version_ids:t.FrozenSet[str]=frozenset()
	@field_validator('indexed_ids','representative_shared_version_ids',mode='before')
	@classmethod
	def _snapshot_ids_set_validator(cls,v:t.Any)->t.Optional[t.FrozenSet[t.Tuple[str,str]]]:
		if v is _A:return v
		return frozenset({cls._snapshot_id_key(snapshot_id)if isinstance(snapshot_id,SnapshotId)else snapshot_id for snapshot_id in v})
	def is_deployable(self,snapshot:SnapshotIdLike)->bool:snapshot_id=self._snapshot_id_key(snapshot.snapshot_id);return self.is_opposite_index and snapshot_id not in self.indexed_ids or not self.is_opposite_index and snapshot_id in self.indexed_ids
	def is_representative(self,snapshot:SnapshotIdLike)->bool:snapshot_id=self._snapshot_id_key(snapshot.snapshot_id);representative=snapshot_id in self.representative_shared_version_ids;return representative or self.is_deployable(snapshot)
	def with_non_deployable(self,snapshot:SnapshotIdLike)->DeployabilityIndex:return self._add_snapshot(snapshot,_B)
	def with_deployable(self,snapshot:SnapshotIdLike)->DeployabilityIndex:return self._add_snapshot(snapshot,_C)
	def _add_snapshot(self,snapshot:SnapshotIdLike,deployable:bool)->DeployabilityIndex:
		snapshot_id={self._snapshot_id_key(snapshot.snapshot_id)};indexed_ids=self.indexed_ids
		if self.is_opposite_index:indexed_ids=indexed_ids-snapshot_id if deployable else indexed_ids|snapshot_id
		else:indexed_ids=indexed_ids|snapshot_id if deployable else indexed_ids-snapshot_id
		return DeployabilityIndex(indexed_ids=indexed_ids,is_opposite_index=self.is_opposite_index,representative_shared_version_ids=self.representative_shared_version_ids)
	@classmethod
	def all_deployable(cls)->DeployabilityIndex:return cls(indexed_ids=frozenset(),is_opposite_index=_C)
	@classmethod
	def none_deployable(cls)->DeployabilityIndex:return cls(indexed_ids=frozenset())
	@classmethod
	def create(cls,snapshots:t.Dict[SnapshotId,Snapshot]|t.Collection[Snapshot],start:t.Optional[TimeLike]=_A,start_override_per_model:t.Optional[t.Dict[str,datetime]]=_A)->DeployabilityIndex:
		if not isinstance(snapshots,dict):snapshots={s.snapshot_id:s for s in snapshots}
		deployability_mapping:t.Dict[SnapshotId,bool]={};children_deployability_mapping:t.Dict[SnapshotId,bool]={};representative_shared_version_ids:t.Set[SnapshotId]=set();start_override_per_model=start_override_per_model or{};start_date_cache:t.Optional[t.Dict[str,datetime]]={};dag=snapshots_to_dag(snapshots.values())
		for node in dag:
			if node not in snapshots:continue
			snapshot=snapshots[node]
			if not snapshot.virtual_environment_mode.is_full:this_deployable=_B
			else:this_deployable=all(children_deployability_mapping[p_id]for p_id in snapshots[node].parents if p_id in children_deployability_mapping)
			if this_deployable:
				is_forward_only_model=snapshot.is_model and snapshot.model.forward_only and not snapshot.is_metadata;has_auto_restatement=snapshot.is_model and snapshot.model.auto_restatement_cron is not _A;snapshot_start=start_override_per_model.get(node.name,start_date(snapshot,snapshots.values(),cache=start_date_cache));is_valid_start=snapshot.is_valid_start(start,snapshot_start)if start is not _A else _C;children_deployable=is_valid_start and not has_auto_restatement
				if snapshot.is_forward_only or snapshot.is_indirect_non_breaking or is_forward_only_model or has_auto_restatement or not is_valid_start:
					this_deployable=_B
					if not snapshot.is_paused or snapshot.is_indirect_non_breaking and snapshot.intervals:representative_shared_version_ids.add(node)
					else:children_deployable=_B
			else:
				children_deployable=_B
				if not snapshots[node].is_paused:representative_shared_version_ids.add(node)
			deployability_mapping[node]=this_deployable;children_deployability_mapping[node]=children_deployable
		deployable_ids={snapshot_id for(snapshot_id,deployable)in deployability_mapping.items()if deployable};non_deployable_ids=set(snapshots)-deployable_ids
		if len(deployable_ids)<=len(non_deployable_ids):return cls(indexed_ids=deployable_ids,representative_shared_version_ids=representative_shared_version_ids)
		return cls(indexed_ids=non_deployable_ids,is_opposite_index=_C,representative_shared_version_ids=representative_shared_version_ids)
	@staticmethod
	def _snapshot_id_key(snapshot_id:SnapshotId)->str:return f"{snapshot_id.name}__{snapshot_id.identifier}"
def table_name(physical_schema:str,name:str,version:str,catalog:t.Optional[str]=_A,suffix:t.Optional[str]=_A,naming_convention:t.Optional[TableNamingConvention]=_A)->str:
	table=exp.to_table(name);naming_convention=naming_convention or TableNamingConvention.default
	if naming_convention==TableNamingConvention.HASH_MD5:value_to_hash=table_name(physical_schema=physical_schema,name=name,version=version,catalog=catalog,suffix=suffix,naming_convention=TableNamingConvention.SCHEMA_AND_TABLE);full_name=f"{c.SQLMESH}_md5__{md5(value_to_hash)}"
	else:table_parts=table.parts;parts_to_consider=2 if naming_convention==TableNamingConvention.SCHEMA_AND_TABLE else 1;parts_to_consider=min(len(table_parts),parts_to_consider);name='__'.join(sanitize_name(part.name)for part in table_parts[-parts_to_consider:]);full_name=f"{name}__{version}"
	suffix=f"__{suffix}"if suffix else'';table.set('this',exp.to_identifier(f"{full_name}{suffix}"));table.set('db',exp.to_identifier(physical_schema))
	if not table.catalog and catalog:table.set(_I,exp.to_identifier(catalog))
	return exp.table_name(table)
def display_name(snapshot_info_like:t.Union[SnapshotInfoLike,SnapshotInfoMixin],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],dialect:DialectType=_A)->str:
	if snapshot_info_like.is_audit:return snapshot_info_like.name
	return model_display_name(snapshot_info_like.name,environment_naming_info,default_catalog,dialect)
def model_display_name(node_name:str,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],dialect:DialectType=_A)->str:view_name=exp.to_table(node_name);catalog=_A if environment_naming_info.suffix_target!=EnvironmentSuffixTarget.CATALOG and view_name.catalog==default_catalog else view_name.catalog;qvn=QualifiedViewName(catalog=catalog,schema_name=view_name.db or _A,table=view_name.name);return qvn.for_environment(environment_naming_info,dialect=dialect)
def fingerprint_from_node(node:Node,*,nodes:t.Dict[str,Node],cache:t.Optional[t.Dict[str,SnapshotFingerprint]]=_A)->SnapshotFingerprint:
	cache={}if cache is _A else cache
	if node.fqn not in cache:parents=[fingerprint_from_node(nodes[table],nodes=nodes,cache=cache)for table in node.depends_on if table in nodes];parent_data_hash=hash_data(sorted(p.to_version()for p in parents));parent_metadata_hash=hash_data(sorted(h for p in parents for h in(p.metadata_hash,p.parent_metadata_hash)));cache[node.fqn]=SnapshotFingerprint(data_hash=node.data_hash,metadata_hash=node.metadata_hash,parent_data_hash=parent_data_hash,parent_metadata_hash=parent_metadata_hash)
	return cache[node.fqn]
def _parents_from_node(node:Node,nodes:t.Dict[str,Node])->t.Dict[str,Node]:
	parent_nodes={}
	for parent_fqn in node.depends_on:
		parent=nodes.get(parent_fqn)
		if parent:
			parent_nodes[parent.fqn]=parent
			if parent.is_model and t.cast(_Model,parent).kind.is_embedded:parent_nodes.update(_parents_from_node(parent,nodes))
	return parent_nodes
def merge_intervals(intervals:t.Collection[Interval])->Intervals:
	if not intervals:return[]
	intervals=sorted(intervals);merged=[intervals[0]]
	for interval in intervals[1:]:
		current=merged[-1]
		if interval[0]<=current[1]:merged[-1]=current[0],max(current[1],interval[1])
		else:merged.append(interval)
	return merged
def _format_date_time(time_like:TimeLike,unit:t.Optional[IntervalUnit])->str:
	if unit is _A or unit.is_date_granularity:return to_ds(time_like)
	return to_ts(time_like)[0:19]
def format_intervals(intervals:Intervals,unit:t.Optional[IntervalUnit])->str:inclusive_intervals=[make_inclusive(start,end)for(start,end)in intervals];return', '.join(' - '.join([_format_date_time(start,unit),_format_date_time(end,unit)])for(start,end)in inclusive_intervals)
def remove_interval(intervals:Intervals,remove_start:int,remove_end:int)->Intervals:
	modified:Intervals=[]
	for(start,end)in intervals:
		if remove_start>start and remove_end<end:modified.extend(((start,remove_start),(remove_end,end)))
		elif remove_start>start:modified.append((start,min(remove_start,end)))
		elif remove_end<end:modified.append((max(remove_end,start),end))
	return modified
def to_table_mapping(snapshots:t.Iterable[Snapshot],deployability_index:t.Optional[DeployabilityIndex])->t.Dict[str,str]:deployability_index=deployability_index or DeployabilityIndex.all_deployable();return{snapshot.name:snapshot.table_name(deployability_index.is_representative(snapshot))for snapshot in snapshots if snapshot.version and not snapshot.is_embedded and snapshot.is_model}
def to_view_mapping(snapshots:t.Iterable[Snapshot],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str]=_A,dialect:t.Optional[str]=_A)->t.Dict[str,str]:return{snapshot.name:snapshot.display_name(environment_naming_info,default_catalog=default_catalog,dialect=dialect)for snapshot in snapshots if snapshot.is_model}
def has_paused_forward_only(targets:t.Iterable[SnapshotIdLike],snapshots:t.Union[t.List[Snapshot],t.Dict[SnapshotId,Snapshot]])->bool:
	if not isinstance(snapshots,dict):snapshots={s.snapshot_id:s for s in snapshots}
	for target in targets:
		target_snapshot=snapshots[target.snapshot_id]
		if target_snapshot.is_paused_forward_only:return _C
	return _B
def missing_intervals(snapshots:t.Union[t.Collection[Snapshot],t.Dict[SnapshotId,Snapshot]],start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,restatements:t.Optional[t.Dict[SnapshotId,Interval]]=_A,deployability_index:t.Optional[DeployabilityIndex]=_A,start_override_per_model:t.Optional[t.Dict[str,datetime]]=_A,end_override_per_model:t.Optional[t.Dict[str,datetime]]=_A,ignore_cron:bool=_B,end_bounded:bool=_B)->t.Dict[Snapshot,Intervals]:
	if not isinstance(snapshots,dict):snapshots={snapshot.snapshot_id:snapshot for snapshot in snapshots}
	missing={};cache:t.Dict[str,datetime]={};end_date=end or now_timestamp();start_dt=to_datetime(start)if start else earliest_start_date(snapshots,cache=cache,relative_to=end_date);restatements=restatements or{};start_override_per_model=start_override_per_model or{};end_override_per_model=end_override_per_model or{};deployability_index=deployability_index or DeployabilityIndex.all_deployable()
	for snapshot in snapshots.values():
		if not snapshot.evaluatable:continue
		snapshot_start_date=start_override_per_model.get(snapshot.name,start_dt);snapshot_end_date:TimeLike=end_date;restated_interval=restatements.get(snapshot.snapshot_id)
		if restated_interval:snapshot_start_date,snapshot_end_date=(to_datetime(i)for i in restated_interval);snapshot=snapshot.copy();snapshot.intervals=snapshot.intervals.copy();snapshot.remove_interval(restated_interval)
		existing_interval_end=end_override_per_model.get(snapshot.name)
		if existing_interval_end:
			if snapshot_start_date>=existing_interval_end:continue
			snapshot_end_date=existing_interval_end
		snapshot_start_date=max(to_datetime(snapshot_start_date),to_datetime(start_date(snapshot,snapshots,cache,relative_to=snapshot_end_date)))
		if snapshot_start_date>to_datetime(snapshot_end_date):continue
		missing_interval_end_date=snapshot_end_date;node_end_date=snapshot.node.end
		if node_end_date and to_datetime(node_end_date)<to_datetime(snapshot_end_date):missing_interval_end_date=node_end_date
		intervals=snapshot.missing_intervals(snapshot_start_date,missing_interval_end_date,execution_time=execution_time,deployability_index=deployability_index,ignore_cron=ignore_cron,end_bounded=end_bounded)
		if intervals:missing[snapshot]=intervals
	return missing
@lru_cache(maxsize=16384)
def expand_range(start_ts:int,end_ts:int,interval_unit:IntervalUnit)->t.List[int]:
	croniter=interval_unit.croniter(start_ts);timestamps=[start_ts]
	while _C:
		ts=to_timestamp(croniter.get_next(estimate=_C))
		if ts>end_ts:
			if timestamps and timestamps[-1]!=end_ts:timestamps.append(end_ts)
			break
		timestamps.append(ts)
	return timestamps
@lru_cache(maxsize=16384)
def compute_missing_intervals(interval_unit:IntervalUnit,intervals:t.Tuple[Interval,...],start_ts:int,end_ts:int,lookback:int,model_end_ts:t.Optional[int])->Intervals:
	if start_ts==end_ts:return[]
	timestamps=expand_range(start_ts,end_ts,interval_unit);missing=set()
	for(current_ts,next_ts)in zip(timestamps,timestamps[1:]):
		for(low,high)in intervals:
			if current_ts<low:missing.add((current_ts,next_ts));break
			elif current_ts>=low and next_ts<=high:break
		else:missing.add((current_ts,next_ts))
	if missing:
		if lookback:
			if model_end_ts:
				croniter=interval_unit.croniter(end_ts);end_ts=to_timestamp(croniter.get_prev(estimate=_C))
				while model_end_ts<end_ts:end_ts=to_timestamp(croniter.get_prev(estimate=_C));lookback-=1
				lookback=max(lookback,0)
			for(i,(current_ts,next_ts))in enumerate(zip(timestamps,timestamps[1:])):
				parent=timestamps[i+lookback:i+lookback+2]
				if len(parent)<2 or tuple(parent)in missing:missing.add((current_ts,next_ts))
		if model_end_ts:missing={interval for interval in missing if interval[0]<model_end_ts}
	return sorted(missing)
@lru_cache(maxsize=16384)
def inclusive_exclusive(start:TimeLike,end:TimeLike,interval_unit:IntervalUnit,strict:bool=_C,allow_partial:bool=_B,expand:bool=_C)->Interval:
	start_dt=interval_unit.cron_floor(start)
	if not expand and not allow_partial and start_dt<to_datetime(start):start_dt=interval_unit.cron_next(start_dt)
	start_ts=to_timestamp(start_dt)
	if is_date(end):end=to_datetime(end)+timedelta(days=1)
	if allow_partial:end_dt=end
	else:
		end_dt=interval_unit.cron_floor(end)
		if expand and end_dt!=to_datetime(end):end_dt=interval_unit.cron_next(end_dt)
	end_ts=to_timestamp(end_dt)
	if strict and start_ts>=end_ts:raise ValueError(f"`end` ({to_datetime(end_ts)}) must be greater than `start` ({to_datetime(start_ts)})")
	return start_ts,end_ts
def earliest_start_date(snapshots:t.Union[t.Collection[Snapshot],t.Dict[SnapshotId,Snapshot]],cache:t.Optional[t.Dict[str,datetime]]=_A,relative_to:t.Optional[TimeLike]=_A)->datetime:
	cache={}if cache is _A else cache
	if snapshots:
		if not isinstance(snapshots,dict):snapshots={snapshot.snapshot_id:snapshot for snapshot in snapshots}
		return min(start_date(snapshot,snapshots,cache=cache,relative_to=relative_to)for snapshot in snapshots.values())
	relative_base=_A
	if relative_to is not _A:relative_base=to_datetime(relative_to)
	return yesterday(relative_base=relative_base)
def start_date(snapshot:Snapshot,snapshots:t.Dict[SnapshotId,Snapshot]|t.Iterable[Snapshot],cache:t.Optional[t.Dict[str,datetime]]=_A,relative_to:t.Optional[TimeLike]=_A)->datetime:
	cache={}if cache is _A else cache;key=f"{snapshot.name}_{to_timestamp(relative_to)}"if relative_to else snapshot.name
	if key in cache:return cache[key]
	if snapshot.node.start:start=to_datetime(snapshot.node.start);cache[key]=start;return start
	if not isinstance(snapshots,dict):snapshots={snapshot.snapshot_id:snapshot for snapshot in snapshots}
	earliest=snapshot.node.cron_prev(snapshot.node.cron_floor(relative_to or now()))
	for parent in snapshot.parents:
		if parent in snapshots:earliest=min(earliest,start_date(snapshots[parent],snapshots,cache=cache,relative_to=relative_to))
	cache[key]=earliest;return earliest
def snapshots_to_dag(snapshots:t.Collection[Snapshot])->DAG[SnapshotId]:
	dag:DAG[SnapshotId]=DAG()
	for snapshot in snapshots:dag.add(snapshot.snapshot_id,snapshot.parents)
	return dag
def apply_auto_restatements(snapshots:t.Dict[SnapshotId,Snapshot],execution_time:TimeLike)->t.Tuple[t.List[SnapshotIntervals],t.Dict[SnapshotId,t.List[SnapshotId]]]:
	dag=snapshots_to_dag(snapshots.values());auto_restatement_triggers:t.Dict[SnapshotId,t.List[SnapshotId]]={};auto_restated_intervals_per_snapshot:t.Dict[SnapshotId,Interval]={}
	for s_id in dag:
		if s_id not in snapshots:continue
		snapshot=snapshots[s_id]
		if not snapshot.is_model or snapshot.model.disable_restatement:continue
		next_auto_restated_interval=snapshot.get_next_auto_restatement_interval(execution_time);auto_restated_intervals=[auto_restated_intervals_per_snapshot[parent_s_id]for parent_s_id in snapshot.parents if parent_s_id in auto_restated_intervals_per_snapshot];upstream_triggers=[]
		if next_auto_restated_interval:logger.info('Calculated the next auto restated interval (%s, %s) for snapshot %s',time_like_to_str(next_auto_restated_interval[0]),time_like_to_str(next_auto_restated_interval[1]),snapshot.snapshot_id);auto_restated_intervals.append(next_auto_restated_interval);upstream_triggers=[s_id]
		else:
			for parent_s_id in snapshot.parents:
				if parent_s_id in auto_restatement_triggers:upstream_triggers.extend(auto_restatement_triggers[parent_s_id])
		if upstream_triggers:auto_restatement_triggers[s_id]=unique(upstream_triggers)
		if auto_restated_intervals:
			auto_restated_interval_start=sys.maxsize;auto_restated_interval_end=-sys.maxsize
			for interval in auto_restated_intervals:auto_restated_interval_start=min(auto_restated_interval_start,interval[0]);auto_restated_interval_end=max(auto_restated_interval_end,interval[1])
			interval_to_remove_start=snapshot.node.interval_unit.cron_floor(auto_restated_interval_start);interval_to_remove_end=snapshot.node.interval_unit.cron_floor(auto_restated_interval_end)
			if auto_restated_interval_end>to_timestamp(interval_to_remove_end):interval_to_remove_end=snapshot.node.interval_unit.cron_next(interval_to_remove_end)
			removal_interval=snapshot.get_removal_interval(interval_to_remove_start,interval_to_remove_end,execution_time=execution_time);auto_restated_intervals_per_snapshot[s_id]=removal_interval;snapshot.pending_restatement_intervals=merge_intervals([*snapshot.pending_restatement_intervals,removal_interval])
		snapshot.apply_pending_restatement_intervals();snapshot.update_next_auto_restatement_ts(execution_time)
	return[SnapshotIntervals(name=snapshots[s_id].name,identifier=_A,version=snapshots[s_id].version,dev_version=_A,intervals=[],dev_intervals=[],pending_restatement_intervals=[interval])for(s_id,interval)in auto_restated_intervals_per_snapshot.items()if s_id in snapshots],auto_restatement_triggers
def parent_snapshots_by_name(snapshot:Snapshot,snapshots:t.Dict[SnapshotId,Snapshot])->t.Dict[str,Snapshot]:parent_snapshots_by_name={snapshots[p_sid].name:snapshots[p_sid]for p_sid in snapshot.parents};parent_snapshots_by_name[snapshot.name]=snapshot;return parent_snapshots_by_name
def _contiguous_intervals(intervals:Intervals)->t.List[Intervals]:
	contiguous_intervals=[];current_batch:t.List[Interval]=[]
	for interval in intervals:
		if len(current_batch)==0 or interval[0]==current_batch[-1][-1]:current_batch.append(interval)
		else:contiguous_intervals.append(current_batch);current_batch=[interval]
	if len(current_batch)>0:contiguous_intervals.append(current_batch)
	return contiguous_intervals
def check_ready_intervals(check:t.Callable,intervals:Intervals,context:ExecutionContext,python_env:t.Dict[str,Executable],dialect:DialectType=_A,path:t.Optional[Path]=_A,snapshot:t.Optional[Snapshot]=_A,kwargs:t.Optional[t.Dict]=_A)->Intervals:
	checked_intervals:Intervals=[]
	for interval_batch in _contiguous_intervals(intervals):
		batch=[(to_datetime(start),to_datetime(end))for(start,end)in interval_batch]
		try:ready_intervals=call_macro(check,dialect,path,provided_args=(batch,),provided_kwargs=kwargs or{},context=context,snapshot=snapshot)
		except Exception as ex:raise SignalEvalError(format_evaluated_code_exception(ex,python_env))
		if isinstance(ready_intervals,bool):
			if not ready_intervals:batch=[]
		elif isinstance(ready_intervals,list):
			for i in ready_intervals:
				if i not in batch:raise SignalEvalError(f"Unknown interval {i} for signal")
			batch=ready_intervals
		else:raise SignalEvalError(f"Expected bool | list, got {type(ready_intervals)} for signal")
		checked_intervals.extend((to_timestamp(start),to_timestamp(end))for(start,end)in batch)
	return checked_intervals
def get_next_model_interval_start(snapshots:t.Iterable[Snapshot])->t.Optional[datetime]:now_dt=now();starts=[snap.node.cron_next(now_dt)for snap in snapshots if snap.is_model and not snap.is_symbolic and not snap.is_seed];return min(starts)if starts else _A