from __future__ import annotations
_B='context'
_A=None
import typing as t
from contextlib import contextmanager
from threading import local
from dataclasses import dataclass,field
from vulcan.core.snapshot import SnapshotIdBatch
@dataclass
class QueryExecutionStats:snapshot_id_batch:SnapshotIdBatch;total_rows_processed:t.Optional[int]=_A;total_bytes_processed:t.Optional[int]=_A
@dataclass
class QueryExecutionContext:
	snapshot_id_batch:SnapshotIdBatch;stats:QueryExecutionStats=field(init=False)
	def __post_init__(self)->_A:self.stats=QueryExecutionStats(snapshot_id_batch=self.snapshot_id_batch)
	def add_execution(self,sql:str,row_count:t.Optional[int],bytes_processed:t.Optional[int])->_A:
		if row_count is not _A and row_count>=0:
			if self.stats.total_rows_processed is _A:self.stats.total_rows_processed=row_count
			else:self.stats.total_rows_processed+=row_count
			if bytes_processed is not _A:
				if self.stats.total_bytes_processed is _A:self.stats.total_bytes_processed=bytes_processed
				else:self.stats.total_bytes_processed+=bytes_processed
	def get_execution_stats(self)->QueryExecutionStats:return self.stats
class QueryExecutionTracker:
	def __init__(self)->_A:self._thread_local=local();(self._contexts):t.Dict[SnapshotIdBatch,QueryExecutionContext]={}
	def get_execution_context(self,snapshot_id_batch:SnapshotIdBatch)->t.Optional[QueryExecutionContext]:return self._contexts.get(snapshot_id_batch)
	def is_tracking(self)->bool:return getattr(self._thread_local,_B,_A)is not _A
	@contextmanager
	def track_execution(self,snapshot_id_batch:SnapshotIdBatch)->t.Iterator[t.Optional[QueryExecutionContext]]:
		context=QueryExecutionContext(snapshot_id_batch=snapshot_id_batch);self._thread_local.context=context;self._contexts[snapshot_id_batch]=context
		try:yield context
		finally:self._thread_local.context=_A
	def record_execution(self,sql:str,row_count:t.Optional[int],bytes_processed:t.Optional[int])->_A:
		context=getattr(self._thread_local,_B,_A)
		if context is not _A:context.add_execution(sql,row_count,bytes_processed)
	def get_execution_stats(self,snapshot_id_batch:SnapshotIdBatch)->t.Optional[QueryExecutionStats]:context=self._contexts.get(snapshot_id_batch);self._contexts.pop(snapshot_id_batch,_A);return context.get_execution_stats()if context else _A