from __future__ import annotations
_A=None
import typing as t
from vulcan.core.config import AutoCategorizationMode,CategorizerConfig
from vulcan.core.snapshot.definition import Snapshot,SnapshotChangeCategory
from vulcan.utils.errors import VulcanError
def categorize_change(new:Snapshot,old:Snapshot,config:t.Optional[CategorizerConfig]=_A,is_breaking_change:t.Optional[t.Callable[...,t.Optional[bool]]]=_A,**kwargs:t.Any)->t.Optional[SnapshotChangeCategory]:
	old_model=old.model;new_model=new.model;config=config or CategorizerConfig();mode=config.dict().get(new_model.source_type,AutoCategorizationMode.OFF)
	if mode==AutoCategorizationMode.OFF:return
	default_category=SnapshotChangeCategory.BREAKING if mode==AutoCategorizationMode.FULL else _A
	if type(new_model)!=type(old_model):return default_category
	if new.fingerprint==old.fingerprint:raise VulcanError(f"{new} is unmodified or indirectly modified and should not be categorized")
	if not new.is_directly_modified(old):
		if new.fingerprint.parent_data_hash==old.fingerprint.parent_data_hash:return SnapshotChangeCategory.NON_BREAKING
		return
	breaking_change=is_breaking_change(new_model,old_model,**kwargs)if is_breaking_change else new_model.is_breaking_change(old_model)
	if breaking_change is _A:return default_category
	return SnapshotChangeCategory.BREAKING if breaking_change else SnapshotChangeCategory.NON_BREAKING
def _categorize_semantic_change(new:Snapshot,old:Snapshot)->SnapshotChangeCategory:
	if new.fingerprint==old.fingerprint:raise VulcanError(f"{new} is unmodified or indirectly modified and should not be categorized")
	if new.fingerprint.data_hash==old.fingerprint.data_hash and new.fingerprint.metadata_hash!=old.fingerprint.metadata_hash:return SnapshotChangeCategory.METADATA
	if new.fingerprint.data_hash!=old.fingerprint.data_hash:
		old_node=old.node;new_node=new.node;breaking_change=new_node.is_breaking_change(old_node)
		if breaking_change is not _A:return SnapshotChangeCategory.BREAKING if breaking_change else SnapshotChangeCategory.NON_BREAKING
	return SnapshotChangeCategory.METADATA