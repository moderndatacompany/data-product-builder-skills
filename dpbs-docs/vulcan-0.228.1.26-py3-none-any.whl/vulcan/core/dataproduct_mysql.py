from __future__ import annotations
import os
from dataclasses import dataclass
@dataclass(frozen=True)
class DataProductMySQLEndpoint:
	host:str;port:int
	@property
	def hostport(self)->str:return f"{self.host}:{self.port}"
def get_dataproduct_mysql_endpoint(*,default_host:str='localhost',default_port:int=3306)->DataProductMySQLEndpoint:
	host=(os.getenv('DATAPRODUCT_MYSQL_HOST')or default_host).strip();port_raw=(os.getenv('DATAPRODUCT_MYSQL_PORT')or str(default_port)).strip()
	if not host:raise ValueError('DATAPRODUCT_MYSQL_HOST is empty')
	try:port=int(port_raw)
	except ValueError as e:raise ValueError(f"DATAPRODUCT_MYSQL_PORT must be an integer, got: {port_raw!r}")from e
	if port<1 or port>65535:raise ValueError(f"DATAPRODUCT_MYSQL_PORT must be in [1, 65535], got: {port}")
	return DataProductMySQLEndpoint(host=host,port=port)