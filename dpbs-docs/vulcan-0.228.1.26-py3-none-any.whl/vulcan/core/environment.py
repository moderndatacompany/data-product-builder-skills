from __future__ import annotations
_F='promoted_snapshot_ids_'
_E='previous_finalized_snapshots_'
_D='snapshots_'
_C='normalize_name'
_B='before'
_A=None
import json,re,typing as t
from pydantic import Field
from vulcan.core import constants as c
from vulcan.core.config import EnvironmentSuffixTarget
from vulcan.core.config.common import DataProductAlignment
from vulcan.core.engine_adapter.base import EngineAdapter
from vulcan.core.macros import RuntimeStage
from vulcan.core.renderer import render_statements
from vulcan.core.snapshot import SnapshotId,SnapshotTableInfo,Snapshot
from vulcan.utils import word_characters_only
from vulcan.utils.date import TimeLike,now_timestamp
from vulcan.utils.errors import VulcanError
from vulcan.utils.jinja import JinjaMacroRegistry
from vulcan.utils.metaprogramming import Executable
from vulcan.utils.pydantic import PydanticModel,field_validator,ValidationInfo
T=t.TypeVar('T',bound='EnvironmentNamingInfo')
PydanticType=t.TypeVar('PydanticType',bound='PydanticModel')
class EnvironmentNamingInfo(PydanticModel):
	name:str=c.PROD;suffix_target:EnvironmentSuffixTarget=Field(default=EnvironmentSuffixTarget.SCHEMA);catalog_name_override:t.Optional[str]=_A;normalize_name:bool=True;gateway_managed:bool=False
	@property
	def is_dev(self)->bool:return self.name.lower()!=c.PROD
	@field_validator('name',mode=_B)
	@classmethod
	def _sanitize_name(cls,v:str)->str:return word_characters_only(v).lower()
	@field_validator(_C,'gateway_managed',mode=_B)
	@classmethod
	def _validate_boolean_field(cls,v:t.Any,info:ValidationInfo)->bool:
		if v is _A:return info.field_name==_C
		return bool(v)
	@t.overload
	@classmethod
	def sanitize_name(cls,v:str)->str:...
	@t.overload
	@classmethod
	def sanitize_name(cls,v:Environment)->Environment:...
	@classmethod
	def sanitize_name(cls,v:str|Environment)->str|Environment:
		if isinstance(v,Environment):return v
		if not isinstance(v,str):raise TypeError(f"Expected str or Environment, got {type(v).__name__}")
		return cls._sanitize_name(v)
	@classmethod
	def sanitize_names(cls,values:t.Iterable[str])->t.Set[str]:return{cls.sanitize_name(value)for value in values}
	@classmethod
	def from_environment_catalog_mapping(cls:t.Type[T],environment_catalog_mapping:t.Dict[re.Pattern,str],name:str=c.PROD,**kwargs:t.Any)->T:
		construction_kwargs=dict(name=name,**kwargs)
		for(re_pattern,catalog_name)in environment_catalog_mapping.items():
			if re.match(re_pattern,name):return cls(catalog_name_override=catalog_name,**construction_kwargs)
		return cls(**construction_kwargs)
class EnvironmentSummary(PydanticModel):
	name:str;start_at:TimeLike;end_at:t.Optional[TimeLike]=_A;plan_id:str;previous_plan_id:t.Optional[str]=_A;expiration_ts:t.Optional[int]=_A;finalized_ts:t.Optional[int]=_A
	@property
	def expired(self)->bool:return self.expiration_ts is not _A and self.expiration_ts<=now_timestamp()
class Environment(EnvironmentNamingInfo,EnvironmentSummary):
	snapshots_:t.List[t.Any]=Field(alias='snapshots');promoted_snapshot_ids_:t.Optional[t.List[t.Any]]=Field(default=_A,alias='promoted_snapshot_ids');previous_finalized_snapshots_:t.Optional[t.List[t.Any]]=Field(default=_A,alias='previous_finalized_snapshots');requirements:t.Dict[str,str]={}
	@field_validator(_D,_E,mode=_B)
	@classmethod
	def _load_snapshots(cls,v:str|t.List[t.Any]|_A)->t.List[t.Any]|_A:
		if isinstance(v,str):return json.loads(v)
		if v and not isinstance(next(iter(v)),(dict,SnapshotTableInfo)):raise ValueError('Must be a list of SnapshotTableInfo dicts or objects')
		return v
	@field_validator(_F,mode=_B)
	@classmethod
	def _load_snapshot_ids(cls,v:str|t.List[t.Any]|_A)->t.List[t.Any]|_A:
		if isinstance(v,str):return json.loads(v)
		if v and not isinstance(next(iter(v)),(dict,SnapshotId)):raise ValueError('Must be a list of SnapshotId dicts or objects')
		return v
	@field_validator('requirements',mode=_B)
	def _load_requirements(cls,v:t.Any)->t.Any:
		if isinstance(v,str):v=json.loads(v)
		return v or{}
	@property
	def snapshots(self)->t.List[SnapshotTableInfo]:return self._convert_list_to_models_and_store(_D,SnapshotTableInfo)or[]
	def snapshot_dicts(self)->t.List[dict]:return self._convert_list_to_dicts(self.snapshots_)
	@property
	def promoted_snapshot_ids(self)->t.Optional[t.List[SnapshotId]]:return self._convert_list_to_models_and_store(_F,SnapshotId)
	def promoted_snapshot_id_dicts(self)->t.List[dict]:return self._convert_list_to_dicts(self.promoted_snapshot_ids_)
	@property
	def promoted_snapshots(self)->t.List[SnapshotTableInfo]:
		if self.promoted_snapshot_ids is _A:return self.snapshots
		promoted_snapshot_ids=set(self.promoted_snapshot_ids);return[s for s in self.snapshots if s.snapshot_id in promoted_snapshot_ids]
	@property
	def previous_finalized_snapshots(self)->t.Optional[t.List[SnapshotTableInfo]]:return self._convert_list_to_models_and_store(_E,SnapshotTableInfo)
	def previous_finalized_snapshot_dicts(self)->t.List[dict]:return self._convert_list_to_dicts(self.previous_finalized_snapshots_)
	@property
	def finalized_or_current_snapshots(self)->t.List[SnapshotTableInfo]:return self.snapshots if self.finalized_ts else self.previous_finalized_snapshots or self.snapshots
	@property
	def naming_info(self)->EnvironmentNamingInfo:return EnvironmentNamingInfo(name=self.name,suffix_target=self.suffix_target,catalog_name_override=self.catalog_name_override,normalize_name=self.normalize_name,gateway_managed=self.gateway_managed)
	@property
	def summary(self)->EnvironmentSummary:return EnvironmentSummary(name=self.name,start_at=self.start_at,end_at=self.end_at,plan_id=self.plan_id,previous_plan_id=self.previous_plan_id,expiration_ts=self.expiration_ts,finalized_ts=self.finalized_ts)
	def can_partially_promote(self,existing_environment:Environment)->bool:return bool(existing_environment.finalized_ts)and not existing_environment.expired and existing_environment.gateway_managed==self.gateway_managed and existing_environment.name==c.PROD
	def _convert_list_to_models_and_store(self,field:str,type_:t.Type[PydanticType])->t.Optional[t.List[PydanticType]]:
		value=getattr(self,field)
		if value and not isinstance(value[0],type_):value=[type_.parse_obj(obj)for obj in value];setattr(self,field,value)
		return value
	def _convert_list_to_dicts(self,value:t.Optional[t.List[t.Any]])->t.List[dict]:
		if not value:return[]
		return value if isinstance(value[0],dict)else[v.dict()for v in value]
class EnvironmentStatements(PydanticModel):
	before_all:t.List[str];after_all:t.List[str];python_env:t.Dict[str,Executable];jinja_macros:t.Optional[JinjaMacroRegistry]=_A;project:t.Optional[str]=_A;domain:t.Optional[str]=_A;discoverable:bool=c.DEFAULT_DISCOVERABLE;version:str=c.DEFAULT_VERSION;alignment:DataProductAlignment=Field(default_factory=lambda:DataProductAlignment(c.DEFAULT_ALIGNMENT))
	def render_before_all(self,dialect:str,default_catalog:t.Optional[str]=_A,**render_kwargs:t.Any)->t.List[str]:return self.render(RuntimeStage.BEFORE_ALL,dialect,default_catalog,**render_kwargs)
	def render_after_all(self,dialect:str,default_catalog:t.Optional[str]=_A,**render_kwargs:t.Any)->t.List[str]:return self.render(RuntimeStage.AFTER_ALL,dialect,default_catalog,**render_kwargs)
	def render(self,runtime_stage:RuntimeStage,dialect:str,default_catalog:t.Optional[str]=_A,**render_kwargs:t.Any)->t.List[str]:return render_statements(statements=getattr(self,runtime_stage.value),dialect=dialect,default_catalog=default_catalog,python_env=self.python_env,jinja_macros=self.jinja_macros,runtime_stage=runtime_stage,**render_kwargs)
def execute_environment_statements(adapter:EngineAdapter,environment_statements:t.List[EnvironmentStatements],runtime_stage:RuntimeStage,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,execution_time:t.Optional[TimeLike]=_A,selected_models:t.Optional[t.Set[str]]=_A)->_A:
	try:rendered_expressions=[expr for statements in environment_statements for expr in statements.render(runtime_stage=runtime_stage,dialect=adapter.dialect,default_catalog=default_catalog,snapshots=snapshots,start=start,end=end,execution_time=execution_time,environment_naming_info=environment_naming_info,engine_adapter=adapter,selected_models=selected_models)]
	except Exception as e:raise VulcanError(f"An error occurred during rendering of the '{runtime_stage.value}' statements:\n\n{e}")
	if rendered_expressions:
		with adapter.transaction():
			for expr in rendered_expressions:
				try:adapter.execute(expr)
				except Exception as e:raise VulcanError(f"An error occurred during execution of the following '{runtime_stage.value}' statement:\n\n{expr}\n\n{e}")