from __future__ import annotations
_A=None
import logging,typing as t
from vulcan.core.notification.dispatcher import DEFAULT_SHUTDOWN_TIMEOUT_SEC,AsyncNotificationDispatcher,QueuedNotification
from vulcan.core.notification.events import NotificationEvent
from vulcan.core.notification.targets import NotificationTarget
logger=logging.getLogger(__name__)
class NotificationTargetManager:
	def __init__(self,notification_targets:t.Dict[NotificationEvent,t.Set[NotificationTarget]]|_A=_A,user_notification_targets:t.Dict[str,t.Set[NotificationTarget]]|_A=_A,username:str|_A=_A)->_A:self.notification_targets=notification_targets or{};self.user_notification_targets=user_notification_targets or{};self.username=username;self._async_dispatcher=AsyncNotificationDispatcher()
	def _deliver(self,notification_target:NotificationTarget,event:NotificationEvent,*args:t.Any,**kwargs:t.Any)->_A:
		try:notify_func=self._get_notification_function(notification_target,event);notify_func(*args,**kwargs)
		except Exception:logger.exception("Notification delivery failed for event '%s' and target type '%s'.",event.value,notification_target.type_)
	def _deliver_queued(self,queued:QueuedNotification)->_A:
		for target in queued.async_targets:self._deliver(target,queued.event,*queued.args,**queued.kwargs)
	def _notify_targets(self,targets:t.Iterable[NotificationTarget],event:NotificationEvent,*args:t.Any,**kwargs:t.Any)->_A:
		for target in(target for target in targets if target.sync):self._deliver(target,event,*args,**kwargs)
		if(async_targets:=tuple(target for target in targets if not target.sync)):self._async_dispatcher.enqueue(QueuedNotification(event=event,args=args,kwargs=dict(kwargs),async_targets=async_targets),self._deliver_queued)
	def notify(self,event:NotificationEvent,*args:t.Any,**kwargs:t.Any)->_A:
		if self.username:self.notify_user(event,self.username,*args,**kwargs)
		else:self._notify_targets(self.notification_targets.get(event,set()),event,*args,**kwargs)
	def notify_user(self,event:NotificationEvent,username:str,*args:t.Any,**kwargs:t.Any)->_A:
		targets=[target for target in self.user_notification_targets.get(username,set())if event in target.notify_on]
		if targets:self._notify_targets(targets,event,*args,**kwargs)
	def flush(self,timeout_sec:float=DEFAULT_SHUTDOWN_TIMEOUT_SEC)->bool:return self._async_dispatcher.flush(timeout_sec=timeout_sec)
	def shutdown(self,flush:bool=True,timeout_sec:float=DEFAULT_SHUTDOWN_TIMEOUT_SEC)->_A:self._async_dispatcher.shutdown(flush=flush,timeout_sec=timeout_sec)
	def _get_notification_function(self,notification_target:NotificationTarget,event:NotificationEvent)->t.Callable:return getattr(notification_target,f"notify_{event.value}")