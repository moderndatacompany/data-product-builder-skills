from __future__ import annotations
_A='console'
import typing as t
from pydantic import Field
from vulcan.core.console import Console,get_console
from vulcan.core.notification.events import NotificationStatus
from vulcan.core.notification.targets.base import BaseTextBasedNotificationTarget
class ConsoleNotificationTarget(BaseTextBasedNotificationTarget,frozen=True):
	type_:t.Literal[_A]=Field(alias='type',default=_A);sync:bool=True;_console:t.Optional[Console]=None
	@property
	def console(self)->Console:
		if not self._console:self._console=get_console()
		return self._console
	def send_text_message(self,notification_status:NotificationStatus,msg:str)->None:
		if notification_status.is_success:self.console.log_success(msg)
		elif notification_status.is_failure:self.console.log_error(msg)
		else:self.console.log_status_update(msg)