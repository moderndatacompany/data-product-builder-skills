from __future__ import annotations
_A='cloudevents'
import logging,typing as t
from datetime import datetime,timezone
import requests
from pydantic import Field
from vulcan.core.notification.events import NotificationEvent,NotificationPayload,NotificationStatus
from vulcan.core.notification.targets.base import BaseNotificationTarget
from vulcan.utils.errors import ApiClientError,ConfigError,raise_for_status
logger=logging.getLogger(__name__)
class CloudEventsNotificationTarget(BaseNotificationTarget,frozen=True):
	url:str;source:str='/vulcan/notifications';headers:t.Dict[str,str]=Field(default_factory=dict);timeout:int=10;type_:t.Literal[_A]=Field(alias='type',default=_A)
	@property
	def is_configured(self)->bool:return True
	def __hash__(self)->int:return hash((self.type_,self.url,self.source,self.timeout,frozenset(self.notify_on),tuple(sorted(self.headers.items()))))
	def send(self,notification_status:NotificationStatus,msg:str,*,event:NotificationEvent,payload:NotificationPayload)->None:self._emit(event,notification_status,payload.model_dump(mode='json',exclude_none=True),msg.strip())
	def _emit(self,event:NotificationEvent,status:NotificationStatus,payload:t.Dict[str,t.Any],summary:str)->None:
		if not self.url:raise ConfigError('Missing CloudEvents notification endpoint URL')
		from cloudevents.conversion import to_structured;from cloudevents.http import CloudEvent;attributes={'type':f"{event.value}",'source':self.source,'datacontenttype':'application/json','time':datetime.now(timezone.utc).isoformat()};data:t.Dict[str,t.Any]={'status':status.value,'event':event.value,'summary':summary,'payload':payload};cloud_event=CloudEvent(attributes,data);headers,body=to_structured(cloud_event)
		if self.headers:
			for(key,value)in self.headers.items():
				if key not in headers:headers[key]=value
		response=requests.post(self.url,data=body,headers=headers,timeout=self.timeout)
		try:raise_for_status(response)
		except ApiClientError as e:logger.error('CloudEvents notification failed for event %s: | url: %s | status: %s | payload: %r',event.value,self.url,e.code,payload)