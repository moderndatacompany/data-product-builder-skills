from __future__ import annotations
_B='teams_webhook'
_A=None
import typing as t,requests
from pydantic import Field
from vulcan.core.notification.events import NotificationEvent,NotificationPayload,NotificationStatus
from vulcan.core.notification.targets.base import BaseNotificationTarget,_apply_str_env_defaults
from vulcan.integrations import teams
from vulcan.utils.errors import ConfigError,raise_for_status
from vulcan.utils.pydantic import model_validator
class BaseTeamsNotificationTarget(BaseNotificationTarget,frozen=True):
	def send(self,notification_status:NotificationStatus,msg:str,*,event:NotificationEvent,payload:NotificationPayload)->_A:composed=teams.build_notification_message(status=notification_status,msg=msg,event=event,payload=payload);self._post_teams_message(composed)
	def _post_teams_message(self,composed:dict[str,t.Any])->_A:0
class TeamsWebhookNotificationTarget(BaseTeamsNotificationTarget,frozen=True):
	url:t.Optional[str]=_A;timeout:int=10;type_:t.Literal[_B]=Field(alias='type',default=_B)
	@model_validator(mode='before')
	@classmethod
	def _apply_teams_webhook_env_defaults(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		_apply_str_env_defaults(data,('url','TEAMS_WEBHOOK_URL'));return data
	def _post_teams_message(self,composed:dict[str,t.Any])->_A:
		if not self.url:raise ConfigError('Missing Teams webhook URL for notification')
		response=requests.post(self.url,json=composed,timeout=self.timeout);raise_for_status(response)
	@property
	def is_configured(self)->bool:return bool(self.url)