from __future__ import annotations
_A=None
import os,smtplib,typing as t
from email.message import EmailMessage
from pydantic import Field,SecretStr
from vulcan.core.notification.events import NotificationStatus
from vulcan.core.notification.targets.base import BaseTextBasedNotificationTarget,_apply_str_env_defaults
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import model_validator
class BasicSMTPNotificationTarget(BaseTextBasedNotificationTarget,frozen=True):
	DEFAULT_PORT:t.ClassVar[int]=465;host:t.Optional[str]=_A;port:t.Optional[int]=_A;user:t.Optional[str]=_A;password:t.Optional[SecretStr]=_A;sender:t.Optional[str]=_A;recipients:t.Optional[t.FrozenSet[str]]=_A;subject:t.Optional[str]='Vulcan Notification';type_:t.Literal['smtp']=Field(alias='type',default='smtp')
	@model_validator(mode='before')
	@classmethod
	def _apply_smtp_env_defaults(cls,data:t.Any)->t.Any:
		B='password';A='port'
		if not isinstance(data,dict):return data
		_apply_str_env_defaults(data,('host','SMTP_HOST'),('user','SMTP_USER'),('sender','SMTP_SENDER'))
		if not data.get(B)and(v:=os.getenv('SMTP_PASSWORD','').strip()):data[B]=v
		if data.get(A)is _A and(v:=os.getenv('SMTP_PORT','').strip()):
			try:data[A]=int(v)
			except ValueError as e:raise ValueError(f"Invalid SMTP_PORT environment variable: {v!r}")from e
		if data.get(A)is _A:data[A]=cls.DEFAULT_PORT
		return data
	def send_text_message(self,notification_status:NotificationStatus,msg:str)->_A:
		if not self.host:raise ConfigError('Missing SMTP host for notification')
		email=EmailMessage();email['Subject']=self.subject;email['To']=','.join(self.recipients or[]);email['From']=self.sender;email.set_content(msg)
		with smtplib.SMTP_SSL(host=self.host,port=self.port or self.DEFAULT_PORT)as smtp:
			if self.user and self.password:smtp.login(user=self.user,password=self.password.get_secret_value())
			smtp.send_message(email)
	@property
	def is_configured(self)->bool:return all((self.host,self.user,self.password,self.sender))