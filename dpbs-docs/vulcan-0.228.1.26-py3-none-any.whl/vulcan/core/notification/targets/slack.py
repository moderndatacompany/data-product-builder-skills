from __future__ import annotations
_G='slack_api'
_F='attachments'
_E='blocks'
_D="Missing Slack dependencies. Run `pip install 'vulcan[slack]'` to install them."
_C='before'
_B='slack_webhook'
_A=None
import sys,typing as t
from pydantic import Field
from vulcan.core.notification.events import ApplyFailurePayload,AuditFailurePayload,MigrationFailurePayload,NotificationEvent,NotificationPayload,NotificationStatus,RunFailurePayload
from vulcan.core.notification.targets.base import BaseNotificationTarget,_apply_str_env_defaults,_vulcan_version
from vulcan.integrations import slack
from vulcan.utils.errors import ConfigError,MissingDependencyError
from vulcan.utils.pydantic import model_validator
if t.TYPE_CHECKING:from slack_sdk import WebClient,WebhookClient
class BaseSlackNotificationTarget(BaseNotificationTarget,frozen=True):
	def send(self,notification_status:NotificationStatus,msg:str,*,event:NotificationEvent,payload:NotificationPayload)->_A:
		status_emoji={NotificationStatus.PROGRESS:slack.SlackAlertIcon.START,NotificationStatus.SUCCESS:slack.SlackAlertIcon.SUCCESS,NotificationStatus.FAILURE:slack.SlackAlertIcon.FAILURE,NotificationStatus.WARNING:slack.SlackAlertIcon.WARNING,NotificationStatus.INFO:slack.SlackAlertIcon.INFO};composed=slack.message().add_primary_blocks(slack.header_block(f"{status_emoji[notification_status]} Vulcan Notification"),slack.context_block(f"*Status:* `{notification_status.value}`"),slack.divider_block(),slack.text_section_block(f"*Message*: {msg}"));details=[]
		if isinstance(payload,AuditFailurePayload):
			details=[slack.fields_section_block(f"*Audit*: `{payload.audit_name}`",f"*Model*: `{payload.model_name}`",f"*Count*: `{payload.count}`")]
			if payload.audit_sql:details.append(slack.preformatted_rich_text_block(payload.audit_sql))
		elif isinstance(payload,(RunFailurePayload,ApplyFailurePayload,MigrationFailurePayload)):details=[slack.preformatted_rich_text_block(payload.exc)]
		composed.add_primary_blocks(*details,slack.divider_block(),slack.context_block(f"*Vulcan Version:* {_vulcan_version()}",f"*Python Version:* {sys.version}"));composed.add_text(msg);self._send_slack_message(composed=composed.slack_message)
	def _send_slack_message(self,composed:slack.TSlackMessage)->_A:0
class SlackWebhookNotificationTarget(BaseSlackNotificationTarget,frozen=True):
	url:t.Optional[str]=_A;type_:t.Literal[_B]=Field(alias='type',default=_B);_client:t.Optional[WebhookClient]=_A
	@model_validator(mode=_C)
	@classmethod
	def _apply_slack_webhook_env_defaults(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		_apply_str_env_defaults(data,('url','SLACK_WEBHOOK_URL'));return data
	@property
	def client(self)->WebhookClient:
		if not self._client:
			try:from slack_sdk import WebhookClient
			except ModuleNotFoundError as e:raise MissingDependencyError(_D)from e
			if not self.url:raise ConfigError('Missing Slack webhook URL')
			self._client=WebhookClient(url=self.url)
		return self._client
	def _send_slack_message(self,composed:slack.TSlackMessage)->_A:self.client.send(text=composed['text'],blocks=composed[_E],attachments=composed[_F])
	@property
	def is_configured(self)->bool:return bool(self.url)
class SlackApiNotificationTarget(BaseSlackNotificationTarget,frozen=True):
	token:t.Optional[str]=_A;channel:t.Optional[str]=_A;type_:t.Literal[_G]=Field(alias='type',default=_G);_client:t.Optional[WebClient]=_A
	@model_validator(mode=_C)
	@classmethod
	def _apply_slack_api_env_defaults(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		_apply_str_env_defaults(data,('token','SLACK_API_TOKEN'));return data
	@property
	def client(self)->WebClient:
		if not self._client:
			try:from slack_sdk import WebClient
			except ModuleNotFoundError as e:raise MissingDependencyError(_D)from e
			self._client=WebClient(token=self.token)
		return self._client
	def _send_slack_message(self,composed:slack.TSlackMessage)->_A:
		if not self.channel:raise ConfigError('Missing Slack channel for notification')
		self.client.chat_postMessage(channel=self.channel,text=composed['text'],blocks=composed[_E],attachments=composed[_F])
	@property
	def is_configured(self)->bool:return all((self.token,self.channel))