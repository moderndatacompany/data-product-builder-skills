from __future__ import annotations
import typing as t
from vulcan.core.notification.targets import DbNotificationTarget,NotificationTarget
def validate_notification_target_config(targets:t.Iterable[NotificationTarget])->None:
	for target in targets:
		if isinstance(target,DbNotificationTarget):raise ValueError("Notification target type 'state_store' is reserved for internal use and cannot be set in project configuration.")