from __future__ import annotations
_B=True
_A=None
import atexit,logging,queue,threading,time,typing as t
from dataclasses import dataclass
from vulcan.core.notification.events import NotificationEvent
from vulcan.core.notification.targets import NotificationTarget
logger=logging.getLogger(__name__)
FLUSH_POLL_INTERVAL_SEC=.05
DEFAULT_SHUTDOWN_TIMEOUT_SEC=6e1
_DISPATCHERS:list[AsyncNotificationDispatcher]=[]
@dataclass(frozen=_B)
class QueuedNotification:event:NotificationEvent;args:tuple[t.Any,...];kwargs:dict[str,t.Any];async_targets:tuple[NotificationTarget,...]
class AsyncNotificationDispatcher:
	def __init__(self,shutdown_timeout_sec:float=DEFAULT_SHUTDOWN_TIMEOUT_SEC)->_A:self._shutdown_timeout_sec=shutdown_timeout_sec;(self._queue):queue.Queue[tuple[QueuedNotification,t.Callable[[QueuedNotification],_A]]|_A]=queue.Queue();self._worker=threading.Thread(target=self._run,name='notification-dispatcher',daemon=_B);self._worker.start();_DISPATCHERS.append(self)
	def enqueue(self,job:QueuedNotification,handler:t.Callable[[QueuedNotification],_A])->_A:self._queue.put((job,handler))
	def flush(self,timeout_sec:float|_A=_A)->bool:
		timeout=timeout_sec if timeout_sec is not _A else self._shutdown_timeout_sec;deadline=time.monotonic()+timeout
		while self._queue.unfinished_tasks>0:
			if time.monotonic()>=deadline:logger.warning('Notification flush timed out with %d job(s) still pending.',self._queue.unfinished_tasks);return False
			time.sleep(FLUSH_POLL_INTERVAL_SEC)
		return _B
	def shutdown(self,flush:bool=_B,timeout_sec:float|_A=_A)->_A:
		timeout=timeout_sec if timeout_sec is not _A else self._shutdown_timeout_sec
		if flush:self.flush(timeout_sec=timeout)
		self._queue.put(_A);self._worker.join(timeout=timeout)
		if self._worker.is_alive():logger.warning('Notification dispatcher worker did not stop in time.')
	def _run(self)->_A:
		while _B:
			item=self._queue.get()
			try:
				if item is _A:break
				job,handler=item
				try:handler(job)
				except Exception:logger.exception("Notification job failed for event '%s'.",job.event.value)
			finally:self._queue.task_done()
def _shutdown_all_dispatchers()->_A:
	for dispatcher in list(_DISPATCHERS):dispatcher.shutdown(flush=_B)
atexit.register(_shutdown_all_dispatchers)