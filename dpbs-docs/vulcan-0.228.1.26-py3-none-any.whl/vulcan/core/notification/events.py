from __future__ import annotations
_A=None
import typing as t
from enum import Enum
from pydantic import ConfigDict,Field,model_validator
from vulcan.utils.pydantic import PydanticModel
DqIssuesByDimension=t.Dict[str,t.List[str]]
class NotificationStatus(str,Enum):
	SUCCESS='success';FAILURE='failure';WARNING='warning';INFO='info';PROGRESS='progress'
	@property
	def is_success(self)->bool:return self==NotificationStatus.SUCCESS
	@property
	def is_failure(self)->bool:return self==NotificationStatus.FAILURE
	@property
	def is_info(self)->bool:return self==NotificationStatus.INFO
	@property
	def is_warning(self)->bool:return self==NotificationStatus.WARNING
	@property
	def is_progress(self)->bool:return self==NotificationStatus.PROGRESS
class NotificationEvent(str,Enum):APPLY_START='apply_start';APPLY_END='apply_end';RUN_START='run_start';RUN_END='run_end';MIGRATION_START='migration_start';MIGRATION_END='migration_end';APPLY_FAILURE='apply_failure';RUN_FAILURE='run_failure';AUDIT_FAILURE='audit_failure';MIGRATION_FAILURE='migration_failure';PLAN_CHANGE='plan_change';DQ_START='dq_start';DQ_END='dq_end'
class NotificationPayloadBase(PydanticModel):extras:t.Dict[str,t.Any]=Field(default_factory=dict)
class ApplyStartPayload(NotificationPayloadBase):environment:str;plan_id:str
class ApplyEndPayload(NotificationPayloadBase):environment:str;plan_id:str
class ApplyFailurePayload(NotificationPayloadBase):environment:str;plan_id:str;exc:str
class RunStartPayload(NotificationPayloadBase):environment:str;run_id:str
class RunEndPayload(NotificationPayloadBase):environment:str;run_id:str;nothing_to_do:bool=False;interrupted:bool=False
class RunFailurePayload(NotificationPayloadBase):environment:str;run_id:str;exc:str
class MigrationStartPayload(NotificationPayloadBase):0
class MigrationEndPayload(NotificationPayloadBase):0
class MigrationFailurePayload(NotificationPayloadBase):exc:str
class AuditFailurePayload(NotificationPayloadBase):audit_name:str;model_name:t.Optional[str]=_A;count:int;audit_sql:t.Optional[str]=_A;environment:t.Optional[str]=_A;run_id:t.Optional[str]=_A;plan_id:t.Optional[str]=_A
class PlanChangePayload(NotificationPayloadBase):environment:str;plan_id:str;added:int;modified:int;removed:int;directly_modified:t.List[str];downstream_affected:int;has_breaking_changes:bool;requires_backfill:bool
class DqStartPayload(NotificationPayloadBase):run_id:str;environment:str;model_count:int
class DqEndPayload(NotificationPayloadBase):run_id:str;environment:str;total_checks:int;passed:int;failed:int;warned:int;not_evaluated:int;model_count:int;pass_rate:float;failures_by_dimension:DqIssuesByDimension;warnings_by_dimension:DqIssuesByDimension
NotificationPayload=t.Union[ApplyStartPayload,ApplyEndPayload,ApplyFailurePayload,RunStartPayload,RunEndPayload,RunFailurePayload,MigrationStartPayload,MigrationEndPayload,MigrationFailurePayload,AuditFailurePayload,PlanChangePayload,DqStartPayload,DqEndPayload]
PAYLOAD_TYPES:t.Dict[NotificationEvent,t.Type[NotificationPayload]]={NotificationEvent.APPLY_START:ApplyStartPayload,NotificationEvent.APPLY_END:ApplyEndPayload,NotificationEvent.APPLY_FAILURE:ApplyFailurePayload,NotificationEvent.RUN_START:RunStartPayload,NotificationEvent.RUN_END:RunEndPayload,NotificationEvent.RUN_FAILURE:RunFailurePayload,NotificationEvent.MIGRATION_START:MigrationStartPayload,NotificationEvent.MIGRATION_END:MigrationEndPayload,NotificationEvent.MIGRATION_FAILURE:MigrationFailurePayload,NotificationEvent.AUDIT_FAILURE:AuditFailurePayload,NotificationEvent.PLAN_CHANGE:PlanChangePayload,NotificationEvent.DQ_START:DqStartPayload,NotificationEvent.DQ_END:DqEndPayload}
class Notification(PydanticModel):
	model_config=ConfigDict(extra='ignore',frozen=True);id:str;created_ts:int;event:NotificationEvent;status:NotificationStatus;summary:str;payload:NotificationPayload;environment:t.Optional[str]=_A;run_id:t.Optional[str]=_A;plan_id:t.Optional[str]=_A
	@model_validator(mode='before')
	@classmethod
	def _coerce_payload(cls,data:t.Any)->t.Any:
		A='payload'
		if not isinstance(data,dict):return data
		event=data.get('event');payload=data.get(A)
		if event is _A or payload is _A or not isinstance(payload,dict):return data
		event_enum=event if isinstance(event,NotificationEvent)else NotificationEvent(event);payload_type=PAYLOAD_TYPES.get(event_enum)
		if payload_type is _A:raise ValueError(f"Unknown notification event: {event}")
		return{**data,A:payload_type.model_validate(payload)}