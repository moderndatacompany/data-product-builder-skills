from __future__ import annotations
_A=True
import typing as t,logging
from dataclasses import dataclass,field
from vulcan.core.state_sync import StateReader
from vulcan.core.snapshot import Snapshot,SnapshotId,SnapshotIdAndVersion,SnapshotNameVersion
from vulcan.core.snapshot.definition import Interval
from vulcan.utils.dag import DAG
from vulcan.utils.date import now_timestamp
logger=logging.getLogger(__name__)
def should_force_rebuild(old:Snapshot,new:Snapshot)->bool:
	if new.is_view and new.is_indirect_non_breaking and not new.is_forward_only:return _A
	if new.is_seed and not(new.is_metadata and new.previous_version and new.previous_version.snapshot_id(new.name)==old.snapshot_id):return _A
	return is_breaking_kind_change(old,new)
def is_breaking_kind_change(old:Snapshot,new:Snapshot)->bool:
	A=False
	if new.is_model!=old.is_model:return _A
	if not new.is_model or not old.is_model:return A
	if old.virtual_environment_mode!=new.virtual_environment_mode:return _A
	if old.model.kind.name==new.model.kind.name:return A
	if not old.is_incremental or not new.is_incremental:return _A
	if old.model.partitioned_by==new.model.partitioned_by:return A
	return _A
@dataclass
class SnapshotIntervalClearRequest:
	snapshot:SnapshotIdAndVersion;interval:Interval;environment_names:t.Set[str]=field(default_factory=set)
	@property
	def snapshot_id(self)->SnapshotId:return self.snapshot.snapshot_id
	@property
	def sorted_environment_names(self)->t.List[str]:return list(sorted(self.environment_names))
def identify_restatement_intervals_across_snapshot_versions(state_reader:StateReader,prod_restatements:t.Dict[str,Interval],disable_restatement_models:t.Set[str],loaded_snapshots:t.Dict[SnapshotId,Snapshot],current_ts:t.Optional[int]=None)->t.Dict[SnapshotId,SnapshotIntervalClearRequest]:
	if not prod_restatements:return{}
	prod_name_versions:t.Set[SnapshotNameVersion]={s.name_version for s in loaded_snapshots.values()};snapshot_intervals_to_clear:t.Dict[SnapshotId,SnapshotIntervalClearRequest]={}
	for env_summary in state_reader.get_environments_summary():
		env=state_reader.get_environment(env_summary.name)
		if not env:logger.warning('Environment %s not found',env_summary.name);continue
		snapshots_by_name={s.name:s.table_info for s in env.snapshots};env_dag=DAG({s.name:{p.name for p in s.parents}for s in env.snapshots})
		for(restate_snapshot_name,interval)in prod_restatements.items():
			if restate_snapshot_name not in snapshots_by_name:continue
			affected_snapshot_names=[x for x in[restate_snapshot_name]+env_dag.downstream(restate_snapshot_name)if x not in disable_restatement_models]
			for affected_snapshot_name in affected_snapshot_names:
				affected_snapshot=snapshots_by_name[affected_snapshot_name]
				if affected_snapshot.name_version in prod_name_versions:continue
				clear_request=snapshot_intervals_to_clear.get(affected_snapshot.snapshot_id)
				if not clear_request:clear_request=SnapshotIntervalClearRequest(snapshot=affected_snapshot.id_and_version,interval=interval);snapshot_intervals_to_clear[affected_snapshot.snapshot_id]=clear_request
				clear_request.environment_names|=set([env.name])
	unique_snapshot_names=set(snapshot_id.name for snapshot_id in snapshot_intervals_to_clear);current_ts=current_ts or now_timestamp();all_matching_non_prod_snapshots={s.snapshot_id:s for s in state_reader.get_snapshots_by_names(snapshot_names=unique_snapshot_names,current_ts=current_ts,exclude_expired=_A)if s.name_version not in prod_name_versions}
	if(remaining_snapshot_ids:=set(all_matching_non_prod_snapshots).difference(snapshot_intervals_to_clear)):
		snapshot_name_to_widest_interval:t.Dict[str,Interval]={}
		for(s_id,clear_request)in snapshot_intervals_to_clear.items():current_start,current_end=snapshot_name_to_widest_interval.get(s_id.name,clear_request.interval);next_start,next_end=clear_request.interval;next_start=min(current_start,next_start);next_end=max(current_end,next_end);snapshot_name_to_widest_interval[s_id.name]=next_start,next_end
		for remaining_snapshot_id in remaining_snapshot_ids:remaining_snapshot=all_matching_non_prod_snapshots[remaining_snapshot_id];snapshot_intervals_to_clear[remaining_snapshot_id]=SnapshotIntervalClearRequest(snapshot=remaining_snapshot,interval=snapshot_name_to_widest_interval[remaining_snapshot_id.name])
	full_history_restatement_snapshot_ids=[s_id for(s_id,s)in snapshot_intervals_to_clear.items()if s.snapshot.full_history_restatement_only]
	if full_history_restatement_snapshot_ids:
		additional_snapshots=state_reader.get_snapshots([s.snapshot_id for s in full_history_restatement_snapshot_ids if s.snapshot_id not in loaded_snapshots]);all_snapshots=loaded_snapshots|additional_snapshots
		for full_snapshot_id in full_history_restatement_snapshot_ids:full_snapshot=all_snapshots[full_snapshot_id];intervals_to_clear=snapshot_intervals_to_clear[full_snapshot_id];original_start,original_end=intervals_to_clear.interval;new_interval=full_snapshot.get_removal_interval(start=original_start,end=original_end);intervals_to_clear.interval=new_interval
	return snapshot_intervals_to_clear