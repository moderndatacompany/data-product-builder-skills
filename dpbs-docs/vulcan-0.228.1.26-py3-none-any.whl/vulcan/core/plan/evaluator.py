_C='Plan application failed.'
_B=False
_A=None
import abc,logging,time,typing as t
from vulcan.core import constants as c,prometheus
from vulcan.core.console import Console,get_console
from vulcan.core.environment import EnvironmentNamingInfo,execute_environment_statements
from vulcan.core.macros import RuntimeStage
from vulcan.core.snapshot.definition import to_view_mapping,SnapshotTableInfo
from vulcan.core.plan import stages
from vulcan.core.plan.definition import EvaluatablePlan
from vulcan.core.scheduler import Scheduler
from vulcan.core.snapshot import DeployabilityIndex,Snapshot,SnapshotEvaluator,SnapshotIntervals,SnapshotId,SnapshotInfoLike,SnapshotCreationFailedError
from vulcan.utils import to_snake_case
from vulcan.core.state_sync import StateSync
from vulcan.core.plan.common import identify_restatement_intervals_across_snapshot_versions
from vulcan.utils import CorrelationId
from vulcan.utils.concurrency import NodeExecutionFailedError
from vulcan.utils.errors import PlanError,ConflictingPlanError,VulcanError
from vulcan.utils.date import now,to_timestamp
logger=logging.getLogger(__name__)
class PlanEvaluator(abc.ABC):
	@abc.abstractmethod
	def evaluate(self,plan:EvaluatablePlan,circuit_breaker:t.Optional[t.Callable[[],bool]]=_A)->_A:0
class BuiltInPlanEvaluator(PlanEvaluator):
	def __init__(self,state_sync:StateSync,snapshot_evaluator:SnapshotEvaluator,create_scheduler:t.Callable[[t.Iterable[Snapshot],SnapshotEvaluator],Scheduler],default_catalog:t.Optional[str],console:t.Optional[Console]=_A):self.state_sync=state_sync;self.snapshot_evaluator=snapshot_evaluator;self.create_scheduler=create_scheduler;self.default_catalog=default_catalog;self.console=console or get_console();(self._circuit_breaker):t.Optional[t.Callable[[],bool]]=_A
	def evaluate(self,plan:EvaluatablePlan,circuit_breaker:t.Optional[t.Callable[[],bool]]=_A)->_A:
		self._circuit_breaker=circuit_breaker;self.snapshot_evaluator=self.snapshot_evaluator.set_correlation_id(CorrelationId.from_plan_id(plan.plan_id));self.console.start_plan_evaluation(plan)
		try:plan_stages=stages.build_plan_stages(plan,self.state_sync,self.default_catalog);self._evaluate_stages(plan_stages,plan)
		finally:self.snapshot_evaluator.recycle();self.console.stop_plan_evaluation()
	def _evaluate_stages(self,plan_stages:t.List[stages.PlanStage],plan:EvaluatablePlan)->_A:
		for stage in plan_stages:
			stage_name=stage.__class__.__name__;handler_name=f"visit_{to_snake_case(stage_name)}"
			if not hasattr(self,handler_name):raise VulcanError(f"Unexpected plan stage: {stage_name}")
			logger.info('Evaluating plan stage %s',stage_name);handler=getattr(self,handler_name);handler(stage,plan)
	def visit_before_all_stage(self,stage:stages.BeforeAllStage,plan:EvaluatablePlan)->_A:execute_environment_statements(adapter=self.snapshot_evaluator.adapter,environment_statements=stage.statements,runtime_stage=RuntimeStage.BEFORE_ALL,environment_naming_info=plan.environment.naming_info,default_catalog=self.default_catalog,snapshots=stage.all_snapshots,start=plan.start,end=plan.end,execution_time=plan.execution_time,selected_models=plan.selected_models)
	def visit_after_all_stage(self,stage:stages.AfterAllStage,plan:EvaluatablePlan)->_A:execute_environment_statements(adapter=self.snapshot_evaluator.adapter,environment_statements=stage.statements,runtime_stage=RuntimeStage.AFTER_ALL,environment_naming_info=plan.environment.naming_info,default_catalog=self.default_catalog,snapshots=stage.all_snapshots,start=plan.start,end=plan.end,execution_time=plan.execution_time,selected_models=plan.selected_models)
	def visit_create_snapshot_records_stage(self,stage:stages.CreateSnapshotRecordsStage,plan:EvaluatablePlan)->_A:
		self.state_sync.push_snapshots(stage.snapshots);self._update_intervals_for_new_snapshots(stage.snapshots)
		if stage.snapshots:prometheus.registry.on_plan_snapshots_created(environment=plan.environment.name,snapshots_created=len(stage.snapshots))
	def visit_physical_layer_update_stage(self,stage:stages.PhysicalLayerUpdateStage,plan:EvaluatablePlan)->_A:
		skip_message=''if plan.restatements else'\nSKIP: No physical layer updates to perform';snapshots_to_create=stage.snapshots
		if not snapshots_to_create:self.console.log_success(skip_message);return
		completion_status=_A;progress_stopped=_B
		try:
			completion_status=self.snapshot_evaluator.create(snapshots_to_create,stage.all_snapshots,allow_destructive_snapshots=plan.allow_destructive_models,allow_additive_snapshots=plan.allow_additive_models,deployability_index=stage.deployability_index,on_start=lambda x:self.console.start_creation_progress(x,plan.environment,self.default_catalog),on_complete=self.console.update_creation_progress)
			if completion_status.is_nothing_to_do:self.console.log_success(skip_message);return
		except SnapshotCreationFailedError as ex:
			self.console.stop_creation_progress(success=_B);progress_stopped=True
			for error in ex.errors:logger.info(str(error),exc_info=error)
			self.console.log_skipped_models({s.name for s in ex.skipped});self.console.log_failed_models(ex.errors);raise PlanError(_C)
		finally:
			if not progress_stopped:self.console.stop_creation_progress(success=completion_status is not _A and completion_status.is_success)
	def visit_physical_layer_schema_creation_stage(self,stage:stages.PhysicalLayerSchemaCreationStage,plan:EvaluatablePlan)->_A:
		try:self.snapshot_evaluator.create_physical_schemas(stage.snapshots,stage.deployability_index)
		except Exception as ex:raise PlanError(_C)from ex
	def visit_backfill_stage(self,stage:stages.BackfillStage,plan:EvaluatablePlan)->_A:
		A='SKIP: No model batches to execute'
		if plan.empty_backfill:
			intervals_to_add=[]
			for snapshot in stage.all_snapshots.values():
				if not snapshot.evaluatable or not plan.is_selected_for_backfill(snapshot.name):continue
				intervals=[snapshot.inclusive_exclusive(plan.start,plan.end,strict=_B,expand=_B)];is_deployable=stage.deployability_index.is_deployable(snapshot);intervals_to_add.append(SnapshotIntervals(name=snapshot.name,identifier=snapshot.identifier,version=snapshot.version,dev_version=snapshot.dev_version,intervals=intervals if is_deployable else[],dev_intervals=intervals if not is_deployable else[]))
			self.state_sync.add_snapshots_intervals(intervals_to_add);self.console.log_success(A);return
		if not stage.snapshot_to_intervals:self.console.log_success(A);return
		environment=plan.environment.name;prometheus.registry.on_plan_backfill_started(environment=environment);started_at=time.perf_counter();scheduler=self.create_scheduler(stage.all_snapshots.values(),self.snapshot_evaluator);errors,_=scheduler.run_merged_intervals(merged_intervals=stage.snapshot_to_intervals,deployability_index=stage.deployability_index,environment_naming_info=plan.environment.naming_info,execution_time=plan.execution_time,circuit_breaker=self._circuit_breaker,start=plan.start,end=plan.end,allow_destructive_snapshots=plan.allow_destructive_models,allow_additive_snapshots=plan.allow_additive_models,selected_snapshot_ids=stage.selected_snapshot_ids,selected_models=plan.selected_models,is_restatement=bool(plan.restatements));prometheus.registry.on_plan_backfill_completed(environment=environment,duration_s=time.perf_counter()-started_at,status='failed'if errors else'success',stage=stage,plan=plan)
		if errors:raise PlanError(_C)
	def visit_audit_only_run_stage(self,stage:stages.AuditOnlyRunStage,plan:EvaluatablePlan)->_A:
		audit_snapshots=stage.snapshots
		if not audit_snapshots:return
		scheduler=self.create_scheduler(audit_snapshots,self.snapshot_evaluator);completion_status=scheduler.audit(plan.environment,plan.start,plan.end,execution_time=plan.execution_time,end_bounded=plan.end_bounded,start_override_per_model=plan.start_override_per_model,end_override_per_model=plan.end_override_per_model)
		if completion_status.is_failure:raise PlanError(_C)
	def visit_restatement_stage(self,stage:stages.RestatementStage,plan:EvaluatablePlan)->_A:
		intervals_to_clear=identify_restatement_intervals_across_snapshot_versions(state_reader=self.state_sync,prod_restatements=plan.restatements,disable_restatement_models=plan.disabled_restatement_models,loaded_snapshots={s.snapshot_id:s for s in stage.all_snapshots.values()},current_ts=to_timestamp(plan.execution_time or now()))
		if not intervals_to_clear:return
		deployed_during_restatement:t.Dict[str,t.Tuple[SnapshotTableInfo,SnapshotTableInfo]]={}
		if(deployed_env:=self.state_sync.get_environment(plan.environment.name)):
			promoted_snapshots_by_name={s.name:s for s in deployed_env.snapshots}
			for name in plan.restatements:
				snapshot=stage.all_snapshots[name];version=snapshot.table_info.version
				if(prod_snapshot:=promoted_snapshots_by_name.get(name))and prod_snapshot.version!=version:deployed_during_restatement[name]=snapshot.table_info,prod_snapshot.table_info
		filtered_intervals_to_clear=[(s.snapshot,s.interval)for s in intervals_to_clear.values()if s.snapshot.name not in deployed_during_restatement]
		if filtered_intervals_to_clear:self.state_sync.remove_intervals(snapshot_intervals=filtered_intervals_to_clear,remove_shared_versions=plan.is_prod)
		if deployed_env and deployed_during_restatement:self.console.log_models_updated_during_restatement(list(deployed_during_restatement.values()),plan.environment.naming_info,self.default_catalog);raise ConflictingPlanError(f"Another plan ({deployed_env.summary.plan_id}) deployed new versions of {len(deployed_during_restatement)} models in the target environment '{plan.environment.name}' while they were being restated by this plan.\nPlease re-apply your plan if these new versions should be restated.")
	def visit_environment_record_update_stage(self,stage:stages.EnvironmentRecordUpdateStage,plan:EvaluatablePlan)->_A:self.state_sync.promote(plan.environment,no_gaps_snapshot_names=stage.no_gaps_snapshot_names if plan.no_gaps else set(),environment_statements=plan.environment_statements)
	def visit_migrate_schemas_stage(self,stage:stages.MigrateSchemasStage,plan:EvaluatablePlan)->_A:
		try:self.snapshot_evaluator.migrate(stage.snapshots,stage.all_snapshots,allow_destructive_snapshots=plan.allow_destructive_models,allow_additive_snapshots=plan.allow_additive_models,deployability_index=stage.deployability_index)
		except NodeExecutionFailedError as ex:raise PlanError(str(ex.__cause__)if ex.__cause__ else str(ex))
	def visit_unpause_stage(self,stage:stages.UnpauseStage,plan:EvaluatablePlan)->_A:self.state_sync.unpause_snapshots(stage.promoted_snapshots,plan.end)
	def visit_virtual_layer_update_stage(self,stage:stages.VirtualLayerUpdateStage,plan:EvaluatablePlan)->_A:
		environment=plan.environment;self.console.start_promotion_progress(list(stage.promoted_snapshots)+list(stage.demoted_snapshots),environment.naming_info,self.default_catalog);completed=_B
		try:
			self._promote_snapshots(plan,[stage.all_snapshots[s.snapshot_id]for s in stage.promoted_snapshots],environment.naming_info,deployability_index=stage.deployability_index,on_complete=lambda s:self.console.update_promotion_progress(s,True),snapshots=stage.all_snapshots)
			if stage.demoted_environment_naming_info:self._demote_snapshots([stage.all_snapshots[s.snapshot_id]for s in stage.demoted_snapshots],stage.demoted_environment_naming_info,deployability_index=stage.deployability_index,on_complete=lambda s:self.console.update_promotion_progress(s,_B),snapshots=stage.all_snapshots)
			completed=True
		finally:self.console.stop_promotion_progress(success=completed)
	def visit_finalize_environment_stage(self,stage:stages.FinalizeEnvironmentStage,plan:EvaluatablePlan)->_A:self.state_sync.finalize(plan.environment)
	def _promote_snapshots(self,plan:EvaluatablePlan,target_snapshots:t.Iterable[Snapshot],environment_naming_info:EnvironmentNamingInfo,snapshots:t.Dict[SnapshotId,Snapshot],deployability_index:t.Optional[DeployabilityIndex]=_A,on_complete:t.Optional[t.Callable[[SnapshotInfoLike],_A]]=_A)->_A:self.snapshot_evaluator.promote(target_snapshots,start=plan.start,end=plan.end,execution_time=plan.execution_time or now(),snapshots=snapshots,table_mapping=to_view_mapping(snapshots.values(),environment_naming_info,default_catalog=self.default_catalog,dialect=self.snapshot_evaluator.adapter.dialect),environment_naming_info=environment_naming_info,deployability_index=deployability_index,on_complete=on_complete)
	def _demote_snapshots(self,target_snapshots:t.Iterable[Snapshot],environment_naming_info:EnvironmentNamingInfo,snapshots:t.Dict[SnapshotId,Snapshot],deployability_index:t.Optional[DeployabilityIndex]=_A,on_complete:t.Optional[t.Callable[[SnapshotInfoLike],_A]]=_A)->_A:self.snapshot_evaluator.demote(target_snapshots,environment_naming_info,table_mapping=to_view_mapping(snapshots.values(),environment_naming_info,default_catalog=self.default_catalog,dialect=self.snapshot_evaluator.adapter.dialect),deployability_index=deployability_index,on_complete=on_complete)
	def _update_intervals_for_new_snapshots(self,snapshots:t.Collection[Snapshot])->_A:
		snapshots_intervals:t.List[SnapshotIntervals]=[]
		for snapshot in snapshots:
			if snapshot.is_forward_only:snapshots_intervals.append(SnapshotIntervals(name=snapshot.name,identifier=snapshot.identifier,version=snapshot.version,dev_version=snapshot.dev_version,dev_intervals=snapshot.dev_intervals))
		if snapshots_intervals:self.state_sync.add_snapshots_intervals(snapshots_intervals)