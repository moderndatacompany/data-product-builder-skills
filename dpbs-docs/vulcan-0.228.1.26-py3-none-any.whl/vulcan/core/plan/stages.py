_A=None
import typing as t
from dataclasses import dataclass
from vulcan.core import constants as c
from vulcan.core.environment import EnvironmentStatements,EnvironmentNamingInfo,Environment
from vulcan.core.plan.common import should_force_rebuild
from vulcan.core.plan.definition import EvaluatablePlan
from vulcan.core.state_sync import StateReader
from vulcan.core.scheduler import merged_missing_intervals,SnapshotToIntervals
from vulcan.core.snapshot.definition import DeployabilityIndex,Snapshot,SnapshotTableInfo,SnapshotId,snapshots_to_dag
from vulcan.utils.errors import PlanError
@dataclass
class BeforeAllStage:statements:t.List[EnvironmentStatements];all_snapshots:t.Dict[str,Snapshot]
@dataclass
class AfterAllStage:statements:t.List[EnvironmentStatements];all_snapshots:t.Dict[str,Snapshot]
@dataclass
class CreateSnapshotRecordsStage:snapshots:t.List[Snapshot]
@dataclass
class PhysicalLayerUpdateStage:snapshots:t.List[Snapshot];all_snapshots:t.Dict[SnapshotId,Snapshot];snapshots_with_missing_intervals:t.Set[SnapshotId];deployability_index:DeployabilityIndex
@dataclass
class PhysicalLayerSchemaCreationStage:snapshots:t.List[Snapshot];deployability_index:DeployabilityIndex
@dataclass
class AuditOnlyRunStage:snapshots:t.List[Snapshot]
@dataclass
class RestatementStage:all_snapshots:t.Dict[str,Snapshot]
@dataclass
class BackfillStage:snapshot_to_intervals:SnapshotToIntervals;selected_snapshot_ids:t.Set[SnapshotId];all_snapshots:t.Dict[str,Snapshot];deployability_index:DeployabilityIndex;before_promote:bool=True
@dataclass
class EnvironmentRecordUpdateStage:no_gaps_snapshot_names:t.Set[str]
@dataclass
class MigrateSchemasStage:snapshots:t.List[Snapshot];all_snapshots:t.Dict[SnapshotId,Snapshot];deployability_index:DeployabilityIndex
@dataclass
class VirtualLayerUpdateStage:promoted_snapshots:t.Set[SnapshotTableInfo];demoted_snapshots:t.Set[SnapshotTableInfo];demoted_environment_naming_info:t.Optional[EnvironmentNamingInfo];all_snapshots:t.Dict[SnapshotId,Snapshot];deployability_index:DeployabilityIndex
@dataclass
class UnpauseStage:promoted_snapshots:t.Set[SnapshotTableInfo]
@dataclass
class FinalizeEnvironmentStage:0
PlanStage=t.Union[BeforeAllStage,AfterAllStage,CreateSnapshotRecordsStage,PhysicalLayerUpdateStage,PhysicalLayerSchemaCreationStage,AuditOnlyRunStage,RestatementStage,BackfillStage,EnvironmentRecordUpdateStage,MigrateSchemasStage,VirtualLayerUpdateStage,UnpauseStage,FinalizeEnvironmentStage]
class PlanStagesBuilder:
	def __init__(self,state_reader:StateReader,default_catalog:t.Optional[str]):self.state_reader=state_reader;self.default_catalog=default_catalog
	def build(self,plan:EvaluatablePlan)->t.List[PlanStage]:
		new_snapshots={s.snapshot_id:s for s in plan.new_snapshots};stored_snapshots=self.state_reader.get_snapshots(plan.environment.snapshots);snapshots={**new_snapshots,**stored_snapshots};snapshots_by_name={s.name:s for s in snapshots.values()};dag=snapshots_to_dag(snapshots.values());all_selected_for_backfill_snapshots={s.snapshot_id for s in snapshots.values()if plan.is_selected_for_backfill(s.name)};existing_environment=self.state_reader.get_environment(plan.environment.name);self._adjust_intervals(snapshots_by_name,plan,existing_environment);deployability_index=DeployabilityIndex.create(snapshots,start=plan.start)
		if plan.is_dev:before_promote_snapshots=all_selected_for_backfill_snapshots;after_promote_snapshots=set();snapshots_with_schema_migration=[]
		else:before_promote_snapshots={s.snapshot_id for s in snapshots.values()if(deployability_index.is_representative(s)or s.is_seed)and plan.is_selected_for_backfill(s.name)};after_promote_snapshots=all_selected_for_backfill_snapshots-before_promote_snapshots;deployability_index=DeployabilityIndex.all_deployable();snapshot_ids_with_schema_migration=[s.snapshot_id for s in snapshots.values()if s.requires_schema_migration_in_prod];snapshots_with_schema_migration=[snapshots[s_id]for s_id in dag.subdag(*snapshot_ids_with_schema_migration)if snapshots[s_id].supports_schema_migration_in_prod]
		snapshots_to_intervals=self._missing_intervals(plan,snapshots_by_name,deployability_index);needs_backfill=not plan.empty_backfill and not plan.skip_backfill and bool(snapshots_to_intervals);missing_intervals_before_promote:SnapshotToIntervals={};missing_intervals_after_promote:SnapshotToIntervals={}
		if needs_backfill:
			for(snapshot,intervals)in snapshots_to_intervals.items():
				if snapshot.snapshot_id in before_promote_snapshots:missing_intervals_before_promote[snapshot]=intervals
				elif snapshot.snapshot_id in after_promote_snapshots:missing_intervals_after_promote[snapshot]=intervals
		promoted_snapshots,demoted_snapshots,demoted_environment_naming_info=self._get_promoted_demoted_snapshots(plan,existing_environment);stages:t.List[PlanStage]=[];before_all_stage=self._get_before_all_stage(plan,snapshots_by_name)
		if before_all_stage:stages.append(before_all_stage)
		if plan.new_snapshots:stages.append(CreateSnapshotRecordsStage(snapshots=plan.new_snapshots))
		snapshots_to_create=self._get_snapshots_to_create(plan,snapshots)
		if snapshots_to_create:stages.append(PhysicalLayerSchemaCreationStage(snapshots=snapshots_to_create,deployability_index=deployability_index))
		if not needs_backfill:stages.append(self._get_physical_layer_update_stage(plan,snapshots_to_create,snapshots,snapshots_to_intervals,deployability_index))
		audit_only_snapshots=self._get_audit_only_snapshots(new_snapshots)
		if audit_only_snapshots:stages.append(AuditOnlyRunStage(snapshots=list(audit_only_snapshots.values())))
		if missing_intervals_before_promote:stages.append(BackfillStage(snapshot_to_intervals=missing_intervals_before_promote,selected_snapshot_ids={s_id for s_id in before_promote_snapshots if plan.is_selected_for_backfill(s_id.name)},all_snapshots=snapshots_by_name,deployability_index=deployability_index))
		elif not needs_backfill:stages.append(BackfillStage(snapshot_to_intervals={},selected_snapshot_ids=set(),all_snapshots=snapshots_by_name,deployability_index=deployability_index))
		restatement_stage=self._get_restatement_stage(plan,snapshots_by_name)
		if restatement_stage:stages.append(restatement_stage)
		stages.append(EnvironmentRecordUpdateStage(no_gaps_snapshot_names={s.name for s in before_promote_snapshots}))
		if snapshots_with_schema_migration:stages.append(MigrateSchemasStage(snapshots=snapshots_with_schema_migration,all_snapshots=snapshots,deployability_index=deployability_index))
		if not plan.is_dev and not plan.ensure_finalized_snapshots and promoted_snapshots:stages.append(UnpauseStage(promoted_snapshots=promoted_snapshots))
		if missing_intervals_after_promote:stages.append(BackfillStage(snapshot_to_intervals=missing_intervals_after_promote,selected_snapshot_ids={s_id for s_id in after_promote_snapshots if plan.is_selected_for_backfill(s_id.name)},all_snapshots=snapshots_by_name,deployability_index=deployability_index))
		if not plan.is_dev and plan.ensure_finalized_snapshots and promoted_snapshots:stages.append(UnpauseStage(promoted_snapshots=promoted_snapshots))
		full_demoted_snapshots=self.state_reader.get_snapshots(s.snapshot_id for s in demoted_snapshots if s.snapshot_id not in snapshots);virtual_layer_update_stage=self._get_virtual_layer_update_stage(promoted_snapshots,demoted_snapshots,demoted_environment_naming_info,snapshots|full_demoted_snapshots,deployability_index,plan.is_dev)
		if virtual_layer_update_stage:stages.append(virtual_layer_update_stage)
		stages.append(FinalizeEnvironmentStage());after_all_stage=self._get_after_all_stage(plan,snapshots_by_name)
		if after_all_stage:stages.append(after_all_stage)
		return stages
	def _get_before_all_stage(self,plan:EvaluatablePlan,snapshots_by_name:t.Dict[str,Snapshot])->t.Optional[BeforeAllStage]:before_all=[environment_statements for environment_statements in plan.environment_statements or[]if environment_statements.before_all];return BeforeAllStage(statements=before_all,all_snapshots=snapshots_by_name)if before_all else _A
	def _get_after_all_stage(self,plan:EvaluatablePlan,snapshots_by_name:t.Dict[str,Snapshot])->t.Optional[AfterAllStage]:after_all=[environment_statements for environment_statements in plan.environment_statements or[]if environment_statements.after_all];return AfterAllStage(statements=after_all,all_snapshots=snapshots_by_name)if after_all else _A
	def _get_restatement_stage(self,plan:EvaluatablePlan,snapshots_by_name:t.Dict[str,Snapshot])->t.Optional[RestatementStage]:
		if plan.restate_all_snapshots:
			if plan.is_dev:raise PlanError('Clearing intervals from state across dev model versions is only valid for prod plans')
			if plan.restatements:return RestatementStage(all_snapshots=snapshots_by_name)
	def _get_physical_layer_update_stage(self,plan:EvaluatablePlan,snapshots_to_create:t.List[Snapshot],all_snapshots:t.Dict[SnapshotId,Snapshot],snapshots_to_intervals:SnapshotToIntervals,deployability_index:DeployabilityIndex)->PhysicalLayerUpdateStage:return PhysicalLayerUpdateStage(snapshots=snapshots_to_create,all_snapshots=all_snapshots,snapshots_with_missing_intervals={s.snapshot_id for s in snapshots_to_intervals if plan.is_selected_for_backfill(s.name)},deployability_index=deployability_index)
	def _get_virtual_layer_update_stage(self,promoted_snapshots:t.Set[SnapshotTableInfo],demoted_snapshots:t.Set[SnapshotTableInfo],demoted_environment_naming_info:t.Optional[EnvironmentNamingInfo],all_snapshots:t.Dict[SnapshotId,Snapshot],deployability_index:DeployabilityIndex,is_dev:bool)->t.Optional[VirtualLayerUpdateStage]:
		def _should_update_virtual_layer(snapshot:SnapshotTableInfo)->bool:virtual_environment_enabled=is_dev or snapshot.virtual_environment_mode.is_full;return snapshot.is_model and not snapshot.is_symbolic and virtual_environment_enabled
		promoted_snapshots={s for s in promoted_snapshots if _should_update_virtual_layer(s)};demoted_snapshots={s for s in demoted_snapshots if _should_update_virtual_layer(s)}
		if not promoted_snapshots and not demoted_snapshots:return
		return VirtualLayerUpdateStage(promoted_snapshots=promoted_snapshots,demoted_snapshots=demoted_snapshots,demoted_environment_naming_info=demoted_environment_naming_info,all_snapshots=all_snapshots,deployability_index=deployability_index)
	def _get_promoted_demoted_snapshots(self,plan:EvaluatablePlan,existing_environment:t.Optional[Environment])->t.Tuple[t.Set[SnapshotTableInfo],t.Set[SnapshotTableInfo],t.Optional[EnvironmentNamingInfo]]:
		if existing_environment:new_table_infos={table_info.name:table_info for table_info in plan.environment.promoted_snapshots};existing_table_infos={table_info.name:table_info for table_info in existing_environment.promoted_snapshots};views_that_changed_location={existing_table_info for existing_table_info in existing_environment.promoted_snapshots if existing_table_info.name in new_table_infos and existing_table_info.qualified_view_name.for_environment(existing_environment.naming_info)!=new_table_infos[existing_table_info.name].qualified_view_name.for_environment(plan.environment.naming_info)};missing_model_names=set(existing_table_infos)-{s.name for s in plan.environment.promoted_snapshots};demoted_snapshots={existing_table_infos[name]for name in missing_model_names}|views_that_changed_location
		else:demoted_snapshots=set()
		promoted_snapshots=set(plan.environment.promoted_snapshots)
		if existing_environment and plan.environment.can_partially_promote(existing_environment):promoted_snapshots-=set(existing_environment.promoted_snapshots)
		demoted_environment_naming_info=existing_environment.naming_info if demoted_snapshots and existing_environment else _A;return promoted_snapshots,demoted_snapshots,demoted_environment_naming_info
	def _missing_intervals(self,plan:EvaluatablePlan,snapshots_by_name:t.Dict[str,Snapshot],deployability_index:DeployabilityIndex)->SnapshotToIntervals:return merged_missing_intervals(snapshots=snapshots_by_name.values(),start=plan.start,end=plan.end,execution_time=plan.execution_time,restatements={snapshots_by_name[name].snapshot_id:interval for(name,interval)in plan.restatements.items()},deployability_index=deployability_index,end_bounded=plan.end_bounded,ignore_cron=plan.ignore_cron,start_override_per_model=plan.start_override_per_model,end_override_per_model=plan.end_override_per_model)
	def _get_audit_only_snapshots(self,new_snapshots:t.Dict[SnapshotId,Snapshot])->t.Dict[SnapshotId,Snapshot]:
		metadata_snapshots=[]
		for snapshot in new_snapshots.values():
			if not snapshot.is_metadata or not snapshot.is_model or not snapshot.evaluatable or not snapshot.previous_version:continue
			metadata_snapshots.append(snapshot)
		previous_snapshot_ids=[s.previous_version.snapshot_id(s.name)for s in metadata_snapshots if s.previous_version];previous_snapshots={s.name:s for s in self.state_reader.get_snapshots(previous_snapshot_ids).values()};audit_snapshots={}
		for snapshot in metadata_snapshots:
			if snapshot.name not in previous_snapshots:continue
			previous_snapshot=previous_snapshots[snapshot.name];new_audits_hash=snapshot.model.audit_metadata_hash();previous_audit_hash=previous_snapshot.model.audit_metadata_hash()
			if snapshot.model.audits and previous_audit_hash!=new_audits_hash:audit_snapshots[snapshot.snapshot_id]=snapshot
		return audit_snapshots
	def _get_snapshots_to_create(self,plan:EvaluatablePlan,snapshots:t.Dict[SnapshotId,Snapshot])->t.List[Snapshot]:
		promoted_snapshot_ids=set(plan.environment.promoted_snapshot_ids)if plan.environment.promoted_snapshot_ids is not _A else _A
		def _should_create(s:Snapshot)->bool:
			if not s.is_model or s.is_symbolic:return False
			return plan.is_selected_for_backfill(s.name)or promoted_snapshot_ids is _A or s.snapshot_id in promoted_snapshot_ids
		return[s for s in snapshots.values()if _should_create(s)]
	def _adjust_intervals(self,snapshots_by_name:t.Dict[str,Snapshot],plan:EvaluatablePlan,existing_environment:t.Optional[Environment])->_A:
		self.state_reader.refresh_snapshot_intervals(snapshots_by_name.values())
		if not existing_environment:existing_environment=self.state_reader.get_environment(c.PROD)
		if existing_environment:
			new_snapshot_ids=set();new_snapshot_versions=set()
			for s in snapshots_by_name.values():
				if s.is_model:new_snapshot_ids.add(s.snapshot_id);new_snapshot_versions.add(s.name_version)
			old_snapshot_ids={s.snapshot_id for s in existing_environment.snapshots if s.is_model and s.name_version in new_snapshot_versions and s.snapshot_id not in new_snapshot_ids}
			if old_snapshot_ids:
				old_snapshots=self.state_reader.get_snapshots(old_snapshot_ids)
				for old in old_snapshots.values():
					new=snapshots_by_name.get(old.name)
					if not new or old.version!=new.version:continue
					if should_force_rebuild(old,new):new.intervals=[]
		for new_snapshot in plan.new_snapshots:
			if new_snapshot.is_forward_only:new_snapshot.dev_intervals=new_snapshot.intervals.copy()
		for(s_name,interval)in plan.restatements.items():snapshots_by_name[s_name].remove_interval(interval)
def build_plan_stages(plan:EvaluatablePlan,state_reader:StateReader,default_catalog:t.Optional[str])->t.List[PlanStage]:return PlanStagesBuilder(state_reader,default_catalog).build(plan)