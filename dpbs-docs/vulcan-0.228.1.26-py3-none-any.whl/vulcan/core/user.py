import typing as t
from enum import Enum
from vulcan.core.notification import BasicSMTPNotificationTarget,NotificationTarget,SlackApiNotificationTarget,validate_notification_target_config
from vulcan.utils.pydantic import PydanticModel,ValidationInfo,field_validator
class UserRole(str,Enum):
	REQUIRED_APPROVER='required_approver'
	@property
	def is_required_approver(self)->bool:return self==UserRole.REQUIRED_APPROVER
class User(PydanticModel):
	username:str;github_username:t.Optional[str]=None;slack_username:t.Optional[str]=None;email:t.Optional[str]=None;roles:t.List[UserRole]=[];notification_targets:t.List[NotificationTarget]=[];type:str='MEMBER'
	@property
	def is_required_approver(self)->bool:return UserRole.REQUIRED_APPROVER in self.roles
	@field_validator('notification_targets',mode='after')
	def validate_notification_targets(cls,v:t.List[NotificationTarget],info:ValidationInfo)->t.List[NotificationTarget]:
		validate_notification_target_config(v);email=info.data.get('email');slack_username=info.data.get('slack_username');result:t.List[NotificationTarget]=[]
		for target in v:
			if isinstance(target,BasicSMTPNotificationTarget):
				if not target.recipients:
					if not email:raise ValueError('User email is required when SMTP notification targets omit recipients')
					target=target.model_copy(update={'recipients':frozenset([email])})
			elif isinstance(target,SlackApiNotificationTarget):
				if not target.channel:
					if not slack_username:raise ValueError('User slack_username is required when Slack API targets omit channel')
					target=target.model_copy(update={'channel':slack_username})
			result.append(target)
		return result