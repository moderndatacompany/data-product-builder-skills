from __future__ import annotations
_B=True
_A=None
import abc
from dataclasses import dataclass,field
from pathlib import Path
from vulcan.core.model import Model
from typing import Type
import typing as t
from vulcan.utils.pydantic import PydanticModel
if t.TYPE_CHECKING:from vulcan.core.context import GenericContext
class RuleLocation(PydanticModel):'The location of a rule in a file.';file_path:str;start_line:t.Optional[int]=_A
@dataclass(frozen=_B)
class Position:'The position of a rule violation in a file, the position follows the LSP standard.';line:int;character:int
@dataclass(frozen=_B)
class Range:'The range of a rule violation in a file. The range follows the LSP standard.';start:Position;end:Position
@dataclass(frozen=_B)
class TextEdit:'A text edit to apply to a file.';path:Path;range:Range;new_text:str
@dataclass(frozen=_B)
class CreateFile:'Create a new file with the provided text.';path:Path;text:str
@dataclass(frozen=_B)
class Fix:'A fix that can be applied to resolve a rule violation.';title:str;edits:t.List[TextEdit]=field(default_factory=list);create_files:t.List[CreateFile]=field(default_factory=list)
class _Rule(abc.ABCMeta):
	def __new__(cls:Type[_Rule],clsname:str,bases:t.Tuple,attrs:t.Dict)->_Rule:attrs['name']=clsname.lower();return super().__new__(cls,clsname,bases,attrs)
class Rule(abc.ABC,metaclass=_Rule):
	'The base class for a rule.';name='rule'
	def __init__(self,context:GenericContext):self.context=context
	def check_model(self,model:Model)->t.Optional[t.Union[RuleViolation,t.List[RuleViolation]]]:'Per-model check. Override in rules that lint individual models.'
	def check_project(self)->t.Optional[t.Union[RuleViolation,t.List[RuleViolation]]]:'Project-level check. Override in rules that lint config or external services.'
	@property
	def summary(self)->str:'A summary of what this rule checks for.';return self.__doc__ or''
	def violation(self,violation_msg:t.Optional[str]=_A,violation_range:t.Optional[Range]=_A,fixes:t.Optional[t.List[Fix]]=_A)->RuleViolation:'Create a RuleViolation instance for this rule';return RuleViolation(rule=self,violation_msg=violation_msg or self.summary,violation_range=violation_range,fixes=fixes)
	def get_definition_location(self)->RuleLocation:
		"Return the file path and position information for this rule.\n\n        This method returns information about where this rule is defined,\n        which can be used in diagnostics to link to the rule's documentation.\n\n        Returns:\n            A dictionary containing file path and position information.\n        ";import inspect;file_path=inspect.getfile(self.__class__)
		try:source_lines,start_line=inspect.getsourcelines(self.__class__);return RuleLocation(file_path=file_path,start_line=start_line)
		except(IOError,TypeError):return RuleLocation(file_path=file_path)
	def __repr__(self)->str:return self.name
class RuleViolation:
	def __init__(self,rule:Rule,violation_msg:str,violation_range:t.Optional[Range]=_A,fixes:t.Optional[t.List[Fix]]=_A)->_A:self.rule=rule;self.violation_msg=violation_msg;self.violation_range=violation_range;self.fixes=fixes or[]
	def __repr__(self)->str:return f"{self.rule.name}: {self.violation_msg}"