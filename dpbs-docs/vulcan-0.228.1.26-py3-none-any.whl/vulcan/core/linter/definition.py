from __future__ import annotations
_C='warning'
_B=False
_A=None
import operator as op,typing as t
from collections.abc import Iterator,Iterable,Set,Mapping,Callable
from functools import reduce
from pathlib import Path
from vulcan.core.config.linter import LinterConfig
from vulcan.core.console import LinterConsole,get_console
from vulcan.core.linter.rule import Rule,RuleViolation,Range,Fix
from vulcan.core.linter.source import LintSource
from vulcan.core.model import Model
from vulcan.utils.errors import raise_config_error
if t.TYPE_CHECKING:from vulcan.core.context import GenericContext
def _lint(error_violations:t.List[RuleViolation],warn_violations:t.List[RuleViolation],lint_source:LintSource,console:LinterConsole)->t.Tuple[bool,t.List[AnnotatedRuleViolation]]:
	if isinstance(lint_source,Model):model:t.Optional[Model]=lint_source;source_path=lint_source._path
	else:model=_A;source_path=lint_source
	all_violations:t.List[AnnotatedRuleViolation]=[AnnotatedRuleViolation(rule=violation.rule,violation_msg=violation.violation_msg,model=model,source_path=source_path,violation_type='error',violation_range=violation.violation_range,fixes=violation.fixes)for violation in error_violations]+[AnnotatedRuleViolation(rule=violation.rule,violation_msg=violation.violation_msg,model=model,source_path=source_path,violation_type=_C,violation_range=violation.violation_range,fixes=violation.fixes)for violation in warn_violations]
	if warn_violations:console.show_linter_violations(warn_violations,lint_source)
	if error_violations:console.show_linter_violations(error_violations,lint_source,is_error=True);return True,all_violations
	return _B,all_violations
def select_rules(all_rules:RuleSet,rule_names:t.Set[str])->RuleSet:
	if'all'in rule_names:return all_rules
	rules=set()
	for rule_name in rule_names:
		if rule_name not in all_rules:raise_config_error(f"Rule {rule_name} could not be found")
		rules.add(all_rules[rule_name])
	return RuleSet(rules)
class Linter:
	def __init__(self,enabled:bool,all_rules:RuleSet,rules:RuleSet,warn_rules:RuleSet)->_A:
		self.enabled=enabled;self.all_rules=all_rules;self.rules=rules;self.warn_rules=warn_rules
		if(overlapping:=rules.intersection(warn_rules)):overlapping_rules=', '.join(rule for rule in overlapping);raise_config_error(f"Rules cannot simultaneously warn and raise an error: [{overlapping_rules}]")
	@classmethod
	def from_rules(cls,all_rules:RuleSet,config:LinterConfig)->Linter:ignored_rules=select_rules(all_rules,config.ignored_rules);included_rules=all_rules.difference(ignored_rules);rules=select_rules(included_rules,config.rules);warn_rules=select_rules(included_rules,config.warn_rules);return Linter(config.enabled,all_rules,rules,warn_rules)
	def lint_project(self,context:GenericContext,source_path:Path,console:LinterConsole=get_console())->t.Tuple[bool,t.List[AnnotatedRuleViolation]]:
		if not self.enabled:return _B,[]
		error_violations=self.rules.check_project(context);warn_violations=self.warn_rules.check_project(context);return _lint(error_violations,warn_violations,source_path,console)
	def lint_model(self,model:Model,context:GenericContext,console:LinterConsole=get_console())->t.Tuple[bool,t.List[AnnotatedRuleViolation]]:
		if not self.enabled:return _B,[]
		ignored_rules=select_rules(self.all_rules,model.ignored_rules);rules=self.rules.difference(ignored_rules);warn_rules=self.warn_rules.difference(ignored_rules);error_violations=rules.check_model(model,context);warn_violations=warn_rules.check_model(model,context);return _lint(error_violations,warn_violations,model,console)
class RuleSet(Mapping[str,type[Rule]]):
	def __init__(self,rules:Iterable[type[Rule]]=())->_A:self._underlying={rule.name:rule for rule in rules}
	def _normalize(self,violation:t.Optional[t.Union[RuleViolation,t.List[RuleViolation]]])->t.List[RuleViolation]:
		if violation is _A:return[]
		if isinstance(violation,RuleViolation):return[violation]
		return list(violation)
	def check_model(self,model:Model,context:GenericContext)->t.List[RuleViolation]:
		violations=[]
		for rule in self._underlying.values():
			if rule.check_model is Rule.check_model:continue
			violation=rule(context).check_model(model);violations.extend(self._normalize(violation))
		return violations
	def check_project(self,context:GenericContext)->t.List[RuleViolation]:
		violations=[]
		for rule in self._underlying.values():
			if rule.check_project is Rule.check_project:continue
			violation=rule(context).check_project();violations.extend(self._normalize(violation))
		return violations
	def __iter__(self)->Iterator[str]:return iter(self._underlying)
	def __len__(self)->int:return len(self._underlying)
	def __getitem__(self,rule:str|type[Rule])->type[Rule]:key=rule if isinstance(rule,str)else rule.name;return self._underlying[key]
	def __op(self,op:Callable[[Set[type[Rule]],Set[type[Rule]]],Set[type[Rule]]],other:RuleSet)->RuleSet:
		rules=set()
		for rule in op(set(self.values()),set(other.values())):rules.add(other[rule]if rule in other else self[rule])
		return RuleSet(rules)
	def union(self,*others:RuleSet)->RuleSet:return reduce(lambda lhs,rhs:lhs.__op(op.or_,rhs),(self,*others))
	def intersection(self,*others:RuleSet)->RuleSet:return reduce(lambda lhs,rhs:lhs.__op(op.and_,rhs),(self,*others))
	def difference(self,*others:RuleSet)->RuleSet:return reduce(lambda lhs,rhs:lhs.__op(op.sub,rhs),(self,*others))
class AnnotatedRuleViolation(RuleViolation):
	def __init__(self,rule:Rule,violation_msg:str,model:t.Optional[Model],violation_type:t.Literal['error',_C],source_path:t.Optional[Path]=_A,violation_range:t.Optional[Range]=_A,fixes:t.Optional[t.List[Fix]]=_A)->_A:super().__init__(rule,violation_msg,violation_range,fixes);self.model=model;self.source_path=source_path;self.violation_type=violation_type
	@property
	def lint_source(self)->t.Optional[LintSource]:
		if self.model is not _A:return self.model
		return self.source_path