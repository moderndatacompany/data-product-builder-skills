from __future__ import annotations
_C='.sql'
_B='utf-8'
_A=None
import typing as t,httpx
from sqlglot.expressions import Star
from sqlglot.helper import subclasses
from vulcan.core.constants import EXTERNAL_MODELS_DEPRECATED_YAML,EXTERNAL_MODELS_YAML
from vulcan.core.dialect import normalize_model_name
from vulcan.core.linter.helpers import TokenPositionDetails,get_range_of_model_block,get_range_of_a_key_in_model_block,read_range_from_string
from vulcan.core.linter.rule import Rule,RuleViolation,Range,Fix,TextEdit,Position,CreateFile
from vulcan.core.linter.definition import RuleSet
from vulcan.core.model import Model,SqlModel,ExternalModel
from vulcan.utils.lineage import extract_references_from_query,ExternalModelReference
class NoSelectStar(Rule):
	def check_model(self,model:Model)->t.Optional[RuleViolation]:
		if not isinstance(model,SqlModel):return
		if model.query.is_star:violation_range=self._get_range(model);fixes=self._create_fixes(model,violation_range);return self.violation(violation_range=violation_range,fixes=fixes)
	def _get_range(self,model:SqlModel)->t.Optional[Range]:
		try:
			if len(model.query.expressions)==1 and isinstance(model.query.expressions[0],Star):return TokenPositionDetails.from_meta(model.query.expressions[0].meta).to_range(_A)
		except Exception:pass
	def _create_fixes(self,model:SqlModel,violation_range:t.Optional[Range])->t.Optional[t.List[Fix]]:
		if not violation_range:return
		columns=model.columns_to_types
		if not columns:return
		path=model._path
		if path is _A:return
		new_text=', '.join(columns.keys());return[Fix(title='Replace SELECT * with explicit column list',edits=[TextEdit(path=path,range=violation_range,new_text=new_text)])]
class InvalidSelectStarExpansion(Rule):
	def check_model(self,model:Model)->t.Optional[RuleViolation]:
		deps=model.violated_rules_for_query.get(InvalidSelectStarExpansion)
		if not deps:return
		violation_msg=f"SELECT * cannot be expanded due to missing schema(s) for model(s): {deps}. Run `vulcan create_external_models` and / or make sure that the model '{model.fqn}' can be rendered at parse time.";return self.violation(violation_msg)
class AmbiguousOrInvalidColumn(Rule):
	def check_model(self,model:Model)->t.Optional[RuleViolation]:
		sqlglot_err=model.violated_rules_for_query.get(AmbiguousOrInvalidColumn)
		if not sqlglot_err:return
		violation_msg=f"{sqlglot_err} for model '{model.fqn}', the column may not exist or is ambiguous.";return self.violation(violation_msg)
class NoMissingAudits(Rule):
	def check_model(self,model:Model)->t.Optional[RuleViolation]:
		if model.audits or model.kind.is_symbolic:return
		if model._path is _A or not str(model._path).endswith(_C):return self.violation()
		try:
			with open(model._path,'r',encoding=_B)as file:content=file.read()
			range=get_range_of_model_block(content,model.dialect)
			if range:return self.violation(violation_range=range)
			return self.violation()
		except Exception:return self.violation()
class NoMissingUnitTest(Rule):
	def check_model(self,model:Model)->t.Optional[RuleViolation]:
		if isinstance(model,ExternalModel):return
		if model.name not in self.context.models_with_tests:return self.violation(violation_msg=f"Model {model.name} is missing unit test(s). Please add in the tests/ directory.")
class NoMissingExternalModels(Rule):
	def check_model(self,model:Model)->t.Optional[t.Union[RuleViolation,t.List[RuleViolation]]]:
		if isinstance(model,ExternalModel):return
		not_registered_external_models:t.Set[str]=set()
		for depends_on_model in model.depends_on:
			existing_model=self.context.get_model(depends_on_model)
			if existing_model is _A:not_registered_external_models.add(depends_on_model)
		if not not_registered_external_models:return
		path=model._path
		if not isinstance(model,SqlModel)or not path or not str(path).endswith(_C):return self._standard_error_message(model_name=model.fqn,external_models=not_registered_external_models)
		with open(path,'r',encoding=_B)as file:read_file=file.read()
		split_read_file=read_file.splitlines();references=extract_references_from_query(query=model.query,context=self.context,document_path=path,read_file=split_read_file,depends_on=model.depends_on,dialect=model.dialect);external_references={normalize_model_name(table=read_range_from_string(read_file,ref.range),default_catalog=model.default_catalog,dialect=model.dialect):ref for ref in references if isinstance(ref,ExternalModelReference)and ref.path is _A}
		if not_registered_external_models!=set(external_references.keys()):return self._standard_error_message(model_name=model.fqn,external_models=not_registered_external_models)
		violations=[]
		for(ref_name,ref)in external_references.items():
			if ref_name in not_registered_external_models:fix=self.create_fix(ref_name);violations.append(RuleViolation(rule=self,violation_msg=f"Model '{model.fqn}' depends on unregistered external model '{ref_name}'. Please register it in the external models file. This can be done by running 'vulcan create_external_models'.",violation_range=ref.range,fixes=[fix]if fix else[]))
		if len(violations)<len(not_registered_external_models):return self._standard_error_message(model_name=model.fqn,external_models=not_registered_external_models)
		return violations
	def _standard_error_message(self,model_name:str,external_models:t.Set[str])->RuleViolation:return RuleViolation(rule=self,violation_msg=f"Model '{model_name}' depends on unregistered external models: {', '.join(m for m in external_models)}. Please register them in the external models file. This can be done by running 'vulcan create_external_models'.")
	def create_fix(self,model_name:str)->t.Optional[Fix]:
		root=self.context.path
		if not root:return
		external_models_path=root/EXTERNAL_MODELS_YAML;deprecated_path=root/EXTERNAL_MODELS_DEPRECATED_YAML
		if not external_models_path.exists()and deprecated_path.exists():external_models_path=deprecated_path
		if not external_models_path.exists():return Fix(title='Add external model file',edits=[],create_files=[CreateFile(path=external_models_path,text=f"- name: '{model_name}'\n")])
		with open(external_models_path,'r',encoding=_B)as file:lines=file.read()
		split_lines=lines.splitlines()
		if lines.endswith('\n'):new_text=f"- name: '{model_name}'\n";position=Position(line=len(split_lines),character=0)
		else:new_text=f"\n- name: '{model_name}'\n";position=Position(line=len(split_lines)-1,character=len(split_lines[-1])if split_lines else 0)
		return Fix(title='Add external model',edits=[TextEdit(path=external_models_path,range=Range(start=position,end=position),new_text=new_text)])
class NoAmbiguousProjections(Rule):
	def check_model(self,model:Model)->t.Optional[RuleViolation]:
		query=model.render_query()
		if query is _A:return
		name_counts:t.Dict[str,int]={};projection_list=query.selects
		for expression in projection_list:
			alias=expression.output_name
			if alias=='*':continue
			if not alias:return self.violation(f"Outer projection '{expression.sql(dialect=model.dialect)}' must have inferrable names or explicit aliases.")
			name_counts[alias]=name_counts.get(alias,0)+1
		for(name,count)in name_counts.items():
			if count>1:return self.violation(f"Found duplicate outer select name '{name}'")
class PreferAssertions(Rule):
	def check_model(self,model:Model)->t.Optional[RuleViolation]:
		if not model.audits or model.kind.is_symbolic:return
		path=model._path
		if path is _A or not str(path).endswith(_C):return
		try:
			with open(path,'r',encoding=_B)as file:content=file.read()
			ranges=get_range_of_a_key_in_model_block(content,model.dialect,'audits')
			if ranges:return self.violation()
		except Exception:return
class MetadataRequired(Rule):
	def check_model(self,model:Model)->t.Optional[RuleViolation]:
		if not model.owner or not model.description:return self.violation()
		if model.columns_to_types:
			column_descriptions=model.column_descriptions or{}
			if len(column_descriptions)!=len(model.columns_to_types):return self.violation()
class NoMissingDataOSUsername(Rule):
	@staticmethod
	def _user_exists(base_url:str,user_id:str,run_as_token:str,timeout:float)->bool:
		url=f"{base_url.rstrip('/')}/api/v1/users/{user_id}";response=httpx.get(url,headers={'apikey':run_as_token},timeout=timeout)
		if response.status_code==404:return False
		response.raise_for_status();return True
	def check_project(self)->t.Optional[t.Union[RuleViolation,t.List[RuleViolation]]]:
		heimdall=self.context.config.heimdall
		if not heimdall.enabled:return
		run_as_token=(heimdall.run_as_token or'').strip()
		if not run_as_token:return self.violation(f"heimdall.run_as_token is required to run the {self.name} rule.")
		base_url=heimdall.base_url.rstrip('/');missing:t.List[str]=[];lookup_errors:t.List[str]=[]
		for user in self.context.config.users:
			username=(user.username or'').strip()
			if not username:continue
			try:
				if not self._user_exists(base_url,username,run_as_token,heimdall.timeout):missing.append(username)
			except httpx.HTTPError as error:lookup_errors.append(f"{username}: {error}")
		if lookup_errors:return self.violation('Could not validate config.users against DataOS: '+'; '.join(lookup_errors))
		if not missing:return
		missing_str=', '.join(sorted(missing));return self.violation(f"config.users entries not found in DataOS: {missing_str}. Ensure username matches the DataOS user id.")
BUILTIN_RULES=RuleSet(subclasses(__name__,Rule,(Rule,)))