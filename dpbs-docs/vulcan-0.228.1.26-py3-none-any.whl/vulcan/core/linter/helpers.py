from pathlib import Path
from vulcan.core.dialect import MODEL_DDL_KEYWORDS
from vulcan.core.linter.rule import Range,Position
from vulcan.utils.pydantic import PydanticModel
from sqlglot import tokenize,TokenType,Token
import typing as t
class TokenPositionDetails(PydanticModel):
	line:int;col:int;start:int;end:int
	@staticmethod
	def from_meta(meta:t.Dict[str,int])->'TokenPositionDetails':return TokenPositionDetails(line=meta['line'],col=meta['col'],start=meta['start'],end=meta['end'])
	def to_range(self,read_file:t.Optional[t.List[str]])->Range:
		if self.start==self.end:return Range(start=Position(line=self.line-1,character=self.col-1),end=Position(line=self.line-1,character=self.col))
		if read_file is None:raise ValueError('read_file must be provided when start and end positions differ.')
		end_line_0=self.line-1;end_col_0=self.col;start_pos=self.start;end_pos=self.end;start_line_0=end_line_0;start_col_0=end_col_0-(end_pos-start_pos+1)
		while start_col_0<0 and start_line_0>0:
			start_line_0-=1;start_col_0+=len(read_file[start_line_0])
			if start_col_0>=0:break
			start_col_0+=1
		start_col_0=max(0,start_col_0);return Range(start=Position(line=start_line_0,character=start_col_0),end=Position(line=end_line_0,character=end_col_0))
def read_range_from_string(content:str,text_range:Range)->str:
	lines=content.splitlines(keepends=False);start_line=max(0,text_range.start.line);end_line=min(len(lines),text_range.end.line+1)
	if start_line>=end_line:return''
	result=[]
	for i in range(start_line,end_line):line=lines[i];start_char=text_range.start.character if i==text_range.start.line else 0;end_char=text_range.end.character if i==text_range.end.line else len(line);result.append(line[start_char:end_char])
	return''.join(result)
def read_range_from_file(file:Path,text_range:Range)->str:
	with file.open('r',encoding='utf-8')as f:lines=f.readlines()
	return read_range_from_string(''.join(lines),text_range)
def get_start_and_end_of_model_block(tokens:t.List[Token])->t.Optional[t.Tuple[int,int]]:
	try:model_idx=next(i for(i,tok)in enumerate(tokens)if tok.token_type is TokenType.VAR and tok.text.upper()in MODEL_DDL_KEYWORDS)
	except StopIteration:return
	try:lparen_idx=next(i for i in range(model_idx+1,len(tokens))if tokens[i].token_type is TokenType.L_PAREN)
	except StopIteration:return
	try:
		closing_semicolon=next(i for i in range(lparen_idx+1,len(tokens))if tokens[i].token_type is TokenType.SEMICOLON);rparen_idx=closing_semicolon-1
		if tokens[rparen_idx].token_type is TokenType.R_PAREN:return lparen_idx,rparen_idx
		return
	except StopIteration:return
def get_range_of_model_block(sql:str,dialect:str)->t.Optional[Range]:
	tokens=tokenize(sql,dialect=dialect);block=get_start_and_end_of_model_block(tokens)
	if not block:return
	start_idx,end_idx=block;start=tokens[start_idx-1];end=tokens[end_idx+1];start_position=TokenPositionDetails(line=start.line,col=start.col,start=start.start,end=start.end);end_position=TokenPositionDetails(line=end.line,col=end.col,start=end.start,end=end.end);splitlines=sql.splitlines();return Range(start=start_position.to_range(splitlines).start,end=end_position.to_range(splitlines).end)
def get_range_of_a_key_in_model_block(sql:str,dialect:str,key:str)->t.Optional[t.Tuple[Range,Range]]:
	tokens=tokenize(sql,dialect=dialect)
	if not tokens:return
	block=get_start_and_end_of_model_block(tokens)
	if not block:return
	lparen_idx,rparen_idx=block;depth=1
	for i in range(lparen_idx+1,rparen_idx):
		tok=tokens[i];tt=tok.token_type
		if tt is TokenType.L_PAREN:depth+=1;continue
		if tt is TokenType.R_PAREN:
			depth-=1
			if depth<=0:break
			continue
		if depth==1 and tt is TokenType.VAR and tok.text.upper()==key.upper():
			prev_idx=i-1;prev_tt=tokens[prev_idx].token_type if prev_idx>=0 else None
			if prev_tt not in(TokenType.L_PAREN,TokenType.COMMA):continue
			lines=sql.splitlines();key_start=TokenPositionDetails(line=tok.line,col=tok.col,start=tok.start,end=tok.end);key_range=key_start.to_range(lines);value_start_idx=i+1
			if value_start_idx>=rparen_idx:return
			nested=0;j=value_start_idx;value_end_idx=value_start_idx
			def is_open(t:TokenType)->bool:return t in(TokenType.L_PAREN,TokenType.L_BRACE,TokenType.L_BRACKET)
			def is_close(t:TokenType)->bool:return t in(TokenType.R_PAREN,TokenType.R_BRACE,TokenType.R_BRACKET)
			while j<rparen_idx:
				ttype=tokens[j].token_type
				if is_open(ttype):nested+=1
				elif is_close(ttype):nested-=1
				if nested==0 and(ttype is TokenType.COMMA or ttype is TokenType.R_PAREN and depth==1):
					if ttype is TokenType.COMMA:break
					else:value_end_idx=j;break
				value_end_idx=j;j+=1
			value_start_tok=tokens[value_start_idx];value_end_tok=tokens[value_end_idx];value_start_pos=TokenPositionDetails(line=value_start_tok.line,col=value_start_tok.col,start=value_start_tok.start,end=value_start_tok.end);value_end_pos=TokenPositionDetails(line=value_end_tok.line,col=value_end_tok.col,start=value_end_tok.start,end=value_end_tok.end);value_range=Range(start=value_start_pos.to_range(lines).start,end=value_end_pos.to_range(lines).end);return key_range,value_range