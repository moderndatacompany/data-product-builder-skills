from __future__ import annotations
import typing as t
from pathlib import Path
from vulcan.core.config.common import ALL_CONFIG_FILENAMES
from vulcan.core.model import Model
LintSource=t.Union[Model,Path]
def project_lint_source(config_path:Path)->Path:
	for name in ALL_CONFIG_FILENAMES:
		candidate=config_path/name
		if candidate.is_file():return candidate
	return config_path
def lint_source_path(source:LintSource)->Path:
	if isinstance(source,Model):
		if source._path is None:raise ValueError('Lint source model has no file path.')
		return source._path
	return source