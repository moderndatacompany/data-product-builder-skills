from __future__ import annotations
_F='pyformat'
_E='named'
_D='numeric_dollar'
_C='qmark'
_B='format'
_A=None
import logging,typing as t,re
from sqlparams import SQLParams
logger=logging.getLogger(__name__)
_NUMERIC_DOLLAR_RE=re.compile('\\$\\d+\\b')
_NUMERIC_AT_RE=re.compile('(?<!@)@_?\\d+\\b')
_PYFORMAT_RE=re.compile('%\\([^)]+\\)s')
_NAMED_RE=re.compile('(?<!:):([A-Za-z_][A-Za-z0-9_]*)\\b')
def _likely_input_style(sql:str,style:str)->bool:
	if style==_C:return'?'in sql
	if style==_D:return bool(_NUMERIC_DOLLAR_RE.search(sql))
	if style=='numeric_at':return bool(_NUMERIC_AT_RE.search(sql))
	if style==_E:return bool(_NAMED_RE.search(sql))
	if style==_B:return'%s'in sql
	if style==_F:return bool(_PYFORMAT_RE.search(sql))
	return False
def _rewrite_numeric_at_to_dollar(sql:str)->str:
	def _repl(match:re.Match)->str:raw=match.group(0);digits=re.sub('\\D','',raw);return f"${digits}"
	return _NUMERIC_AT_RE.sub(_repl,sql)
def normalize_query_params(input_query:str,input_parameters:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any],_A],output_style:str=_B)->t.Tuple[str,t.Union[t.List[t.Any],t.Dict[str,t.Any],_A]]:
	A=True
	if input_parameters is _A:return input_query,_A
	if input_parameters is not _A:
		rewritten_query=input_query
		if _NUMERIC_AT_RE.search(rewritten_query):rewritten_query=_rewrite_numeric_at_to_dollar(rewritten_query)
		styles=[_C,_B,_D,_E,_F]if'?'in rewritten_query else[_B,_D,_C,_E,_F]
		for style in styles:
			try:
				converter=SQLParams(in_style=style,out_style=output_style,escape_char='%',expand_tuples=A,strip_comments=A,allow_out_quotes=A);output_sql,output_params=converter.format(rewritten_query,input_parameters)
				if output_sql!=rewritten_query or output_params:return output_sql,output_params
			except(IndexError,ValueError)as e:
				logger.debug(f"Parameter error with style {style}: {e}",exc_info=A)
				if _likely_input_style(rewritten_query,style):raise
				continue
			except Exception as e:logger.debug(f"Style {style} didn't match: {e}",exc_info=A);continue
	return input_query,input_parameters