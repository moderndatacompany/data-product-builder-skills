from __future__ import annotations
_E='No row description was found, pandas dataframe will be missing column labels.'
_D='VARCHAR'
_C=True
_B=False
_A=None
import logging,typing as t
from sqlglot import exp
from vulcan.core.dialect import to_schema
from vulcan.core.engine_adapter.base import MERGE_SOURCE_ALIAS,MERGE_TARGET_ALIAS
from vulcan.core.engine_adapter.base_postgres import BasePostgresEngineAdapter
from vulcan.core.engine_adapter.mixins import GetCurrentCatalogFromFunctionMixin,NonTransactionalTruncateMixin,VarcharSizeWorkaroundMixin,RowDiffMixin,logical_merge,GrantsFromInfoSchemaMixin
from vulcan.core.engine_adapter.shared import CommentCreationView,DataObject,DataObjectType,SourceQuery,set_catalog
from vulcan.utils.errors import VulcanError
if t.TYPE_CHECKING:import pandas as pd;from vulcan.core._typing import SchemaName,TableName;from vulcan.core.engine_adapter.base import QueryOrDF,Query
logger=logging.getLogger(__name__)
@set_catalog()
class RedshiftEngineAdapter(BasePostgresEngineAdapter,GetCurrentCatalogFromFunctionMixin,NonTransactionalTruncateMixin,VarcharSizeWorkaroundMixin,RowDiffMixin,GrantsFromInfoSchemaMixin):
	DIALECT='redshift';CURRENT_CATALOG_EXPRESSION=exp.func('current_database');COMMENT_CREATION_VIEW=CommentCreationView.UNSUPPORTED;SUPPORTS_REPLACE_TABLE=_B;SUPPORTS_GRANTS=_C;SUPPORTS_MULTIPLE_GRANT_PRINCIPALS=_C;SCHEMA_DIFFER_KWARGS={'parameterized_type_defaults':{exp.DataType.build('VARBYTE',dialect=DIALECT).this:[(64000,)],exp.DataType.build('DECIMAL',dialect=DIALECT).this:[(18,0),(0,)],exp.DataType.build('CHAR',dialect=DIALECT).this:[(1,)],exp.DataType.build(_D,dialect=DIALECT).this:[(256,)],exp.DataType.build('NCHAR',dialect=DIALECT).this:[(1,)],exp.DataType.build('NVARCHAR',dialect=DIALECT).this:[(256,)]},'max_parameter_length':{exp.DataType.build('CHAR',dialect=DIALECT).this:4096,exp.DataType.build(_D,dialect=DIALECT).this:65535},'precision_increase_allowed_types':{exp.DataType.build(_D,dialect=DIALECT).this},'drop_cascade':_C};VARIABLE_LENGTH_DATA_TYPES={'char','character','nchar','varchar','character varying','nvarchar','varbyte','varbinary','binary varying'}
	def columns(self,table_name:TableName,include_pseudo_columns:bool=_C)->t.Dict[str,exp.DataType]:
		table=exp.to_table(table_name);sql=exp.select('column_name','data_type','character_maximum_length','numeric_precision','numeric_scale').from_('svv_columns').where(exp.column('table_name').eq(table.alias_or_name))
		if table.args.get('db'):sql=sql.where(exp.column('table_schema').eq(table.args['db'].name))
		columns_raw=self.fetchall(sql,quote_identifiers=_C)
		def build_var_length_col(column_name:str,data_type:str,character_maximum_length:t.Optional[int]=_A,numeric_precision:t.Optional[int]=_A,numeric_scale:t.Optional[int]=_A)->tuple:
			data_type=data_type.lower()
			if data_type in self.VARIABLE_LENGTH_DATA_TYPES and character_maximum_length is not _A:return column_name,f"{data_type}({character_maximum_length})"
			if data_type in('decimal','numeric'):return column_name,f"{data_type}({numeric_precision}, {numeric_scale})"
			return column_name,data_type
		columns=[build_var_length_col(*row)for row in columns_raw];return{column_name:exp.DataType.build(data_type,dialect=self.dialect)for(column_name,data_type)in columns}
	@property
	def enable_merge(self)->bool:return bool(self._extra_config.get('enable_merge'))
	@property
	def cursor(self)->t.Any:cursor=self._connection_pool.get_cursor();cursor.paramstyle='qmark';return cursor
	def _fetch_native_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_B)->pd.DataFrame:
		import pandas as pd;self.execute(query,quote_identifiers=quote_identifiers);fetcheddata=self.cursor.fetchall()
		try:columns=[column[0]for column in self.cursor.description]
		except Exception:columns=_A;logging.warning(_E)
		result=[tuple(row)for row in fetcheddata];return pd.DataFrame(result,columns=columns)
	def _fetch_native_df_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_B)->pd.DataFrame:
		import pandas as pd;self.execute(query,params=params,quote_identifiers=quote_identifiers);fetcheddata=self.cursor.fetchall()
		try:columns=[column[0]for column in self.cursor.description]
		except Exception:columns=_A;logging.warning(_E)
		result=[tuple(row)for row in fetcheddata];return pd.DataFrame(result,columns=columns)
	def _create_table_from_source_queries(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,exists:bool=_C,replace:bool=_B,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,table_kind:t.Optional[str]=_A,track_rows_processed:bool=_C,**kwargs:t.Any)->_A:
		if not exists:return super()._create_table_from_source_queries(table_name,source_queries,target_columns_to_types,exists,table_description=table_description,column_descriptions=column_descriptions,**kwargs)
		if self.table_exists(table_name):return
		super()._create_table_from_source_queries(table_name,source_queries,exists=_B,table_description=table_description,column_descriptions=column_descriptions,**kwargs)
	def create_view(self,view_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,replace:bool=_C,materialized:bool=_B,materialized_properties:t.Optional[t.Dict[str,t.Any]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,view_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,source_columns:t.Optional[t.List[str]]=_A,**create_kwargs:t.Any)->_A:
		no_schema_binding=_C
		if isinstance(query_or_df,exp.Expression):has_recursive_cte=any(w.args.get('recursive',_B)for w in query_or_df.find_all(exp.With));no_schema_binding=not has_recursive_cte
		return super().create_view(view_name,query_or_df,target_columns_to_types,replace,materialized,materialized_properties,table_description=table_description,column_descriptions=column_descriptions,no_schema_binding=no_schema_binding,view_properties=view_properties,source_columns=source_columns,**create_kwargs)
	def replace_query(self,table_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,source_columns:t.Optional[t.List[str]]=_A,supports_replace_table_override:t.Optional[bool]=_A,**kwargs:t.Any)->_A:
		import pandas as pd;target_data_object=self.get_data_object(table_name);table_exists=target_data_object is not _A
		if self.drop_data_object_on_type_mismatch(target_data_object,DataObjectType.TABLE):table_exists=_B
		if not isinstance(query_or_df,pd.DataFrame)or not table_exists:return super().replace_query(table_name,query_or_df,target_columns_to_types,table_description,column_descriptions,source_columns=source_columns,**kwargs)
		source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types,target_table=table_name,source_columns=source_columns);target_columns_to_types=target_columns_to_types or self.columns(table_name);target_table=exp.to_table(table_name)
		with self.transaction():temp_table=self._get_temp_table(target_table);old_table=self._get_temp_table(target_table);self.create_table(temp_table,target_columns_to_types,exists=_B,table_description=table_description,column_descriptions=column_descriptions,**kwargs);self._insert_append_source_queries(temp_table,source_queries,target_columns_to_types);self.rename_table(target_table,old_table);self.rename_table(temp_table,target_table);self.drop_table(old_table)
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		H='%create materialized view%';G='definition';F='pg_views';E='viewname';D='type';C='schemaname';B='name';A='schema_name';catalog=self.get_current_catalog();table_query=exp.select(exp.column(C).as_(A),exp.column('tablename').as_(B),exp.Literal.string('TABLE').as_(D)).from_('pg_tables');view_query=exp.select(exp.column(C).as_(A),exp.column(E).as_(B),exp.Literal.string('VIEW').as_(D)).from_(F).where(exp.column(G).ilike(H).not_());materialized_view_query=exp.select(exp.column(C).as_(A),exp.column(E).as_(B),exp.Literal.string('MATERIALIZED_VIEW').as_(D)).from_(F).where(exp.column(G).ilike(H));subquery=exp.union(table_query,exp.union(view_query,materialized_view_query,distinct=_B),distinct=_B);query=exp.select('*').from_(subquery.subquery(alias='objs')).where(exp.column(A).eq(to_schema(schema_name).db))
		if object_names:query=query.where(exp.column(B).isin(*object_names))
		df=self.fetchdf(query);return[DataObject(catalog=catalog,schema=row.schema_name,name=row.name,type=DataObjectType.from_str(row.type))for row in df.itertuples()]
	def merge(self,target_table:TableName,source_table:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],unique_key:t.Sequence[exp.Expression],when_matched:t.Optional[exp.Whens]=_A,merge_filter:t.Optional[exp.Expression]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:
		if self.enable_merge:super().merge(target_table=target_table,source_table=source_table,target_columns_to_types=target_columns_to_types,unique_key=unique_key,when_matched=when_matched,merge_filter=merge_filter,source_columns=source_columns)
		else:logical_merge(self,target_table,source_table,target_columns_to_types,unique_key,when_matched=when_matched,merge_filter=merge_filter,source_columns=source_columns)
	def _merge(self,target_table:TableName,query:Query,on:exp.Expression,whens:exp.Whens)->_A:
		A='matched'
		def resolve_target_table(expression:exp.Expression)->exp.Expression:
			if isinstance(expression,exp.Column)and expression.table.upper()==MERGE_TARGET_ALIAS:expression.set('table',exp.to_table(target_table))
			return expression
		if len(whens.expressions)!=2 or whens.expressions[0].args[A]==whens.expressions[1].args[A]:raise VulcanError('Redshift only supports a single WHEN MATCHED and WHEN NOT MATCHED clause')
		using=exp.alias_(exp.Subquery(this=query),alias=MERGE_SOURCE_ALIAS,copy=_B,table=_C);self.execute(exp.Merge(this=target_table,using=using,on=on.transform(resolve_target_table),whens=whens.transform(resolve_target_table)),track_rows_processed=_C)
	def _normalize_decimal_value(self,expr:exp.Expression,precision:int)->exp.Expression:rounded=exp.func('ROUND',expr,precision);return super()._normalize_decimal_value(rounded,precision)