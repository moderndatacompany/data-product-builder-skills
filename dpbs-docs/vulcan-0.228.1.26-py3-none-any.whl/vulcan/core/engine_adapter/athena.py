from __future__ import annotations
_K='Location'
_J='StorageDescriptor'
_I='Values'
_H='table_type'
_G='table_name'
_F='table_schema'
_E=False
_D='iceberg'
_C='hive'
_B=True
_A=None
from functools import lru_cache
import typing as t,logging
from sqlglot import exp
from vulcan.core.dialect import to_schema
from vulcan.utils.aws import validate_s3_uri,parse_s3_uri
from vulcan.core.engine_adapter.mixins import PandasNativeFetchDFSupportMixin,RowDiffMixin
from vulcan.core.engine_adapter.trino import TrinoEngineAdapter
from vulcan.core.node import IntervalUnit
import posixpath
from vulcan.utils.errors import VulcanError
from vulcan.core.engine_adapter.shared import CatalogSupport,DataObject,DataObjectType,CommentCreationTable,CommentCreationView,SourceQuery,InsertOverwriteStrategy
if t.TYPE_CHECKING:from vulcan.core._typing import SchemaName,TableName;from vulcan.core.engine_adapter._typing import QueryOrDF;TableType=t.Union[t.Literal[_C],t.Literal[_D]]
logger=logging.getLogger(__name__)
class AthenaEngineAdapter(PandasNativeFetchDFSupportMixin,RowDiffMixin):
	DIALECT='athena';SUPPORTS_TRANSACTIONS=_E;SUPPORTS_REPLACE_TABLE=_E;COMMENT_CREATION_TABLE=CommentCreationTable.UNSUPPORTED;COMMENT_CREATION_VIEW=CommentCreationView.UNSUPPORTED;SCHEMA_DIFFER_KWARGS=TrinoEngineAdapter.SCHEMA_DIFFER_KWARGS;MAX_TIMESTAMP_PRECISION=3;ATTACH_CORRELATION_ID=_E;SUPPORTS_QUERY_EXECUTION_TRACKING=_B;SUPPORTED_DROP_CASCADE_OBJECT_KINDS=['DATABASE','SCHEMA']
	def __init__(self,*args:t.Any,s3_warehouse_location:t.Optional[str]=_A,**kwargs:t.Any):super().__init__(*args,s3_warehouse_location=s3_warehouse_location,**kwargs);self.s3_warehouse_location=s3_warehouse_location;self._default_catalog=self._default_catalog or'awsdatacatalog'
	@property
	def s3_warehouse_location(self)->t.Optional[str]:return self._s3_warehouse_location
	@s3_warehouse_location.setter
	def s3_warehouse_location(self,value:t.Optional[str])->_A:
		if value:value=validate_s3_uri(value,base=_B)
		self._s3_warehouse_location=value
	@property
	def s3_warehouse_location_or_raise(self)->str:
		if(location:=self.s3_warehouse_location):return location
		raise VulcanError('s3_warehouse_location was expected to be populated; it isnt')
	@property
	def catalog_support(self)->CatalogSupport:return CatalogSupport.SINGLE_CATALOG_ONLY
	def create_state_table(self,table_name:str,target_columns_to_types:t.Dict[str,exp.DataType],primary_key:t.Optional[t.Tuple[str,...]]=_A)->_A:self.create_table(table_name,target_columns_to_types,primary_key=primary_key,table_format=_D)
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		A='t';schema_name=to_schema(schema_name);schema=schema_name.db;query=exp.select(exp.column('table_catalog').as_('catalog'),exp.column(_F,table=A).as_('schema'),exp.column(_G,table=A).as_('name'),exp.case().when(exp.column(_H,table=A).eq('BASE TABLE'),exp.Literal.string('table')).else_(exp.column(_H,table=A)).as_('type')).from_(exp.to_table('information_schema.tables',alias=A)).where(exp.column(_F,table=A).eq(schema))
		if object_names:query=query.where(exp.column(_G,table=A).isin(*object_names))
		df=self.fetchdf(query);return[DataObject(catalog=row.catalog,schema=row.schema,name=row.name,type=DataObjectType.from_str(row.type))for row in df.itertuples()]
	def columns(self,table_name:TableName,include_pseudo_columns:bool=_E)->t.Dict[str,exp.DataType]:table=exp.to_table(table_name);query=exp.select('column_name','data_type').from_('information_schema.columns').where(exp.column(_F).eq(table.db),exp.column(_G).eq(table.name)).order_by('ordinal_position');result=self.fetchdf(query,quote_identifiers=_B);return{str(r.column_name):exp.DataType.build(str(r.data_type))for r in result.itertuples(index=_E)}
	def _create_schema(self,schema_name:SchemaName,ignore_if_exists:bool,warn_on_error:bool,properties:t.List[exp.Expression],kind:str)->_A:
		if(location:=self._table_location(table_properties=_A,table=exp.to_table(schema_name))):
			if not any(p for p in properties if isinstance(p,exp.LocationProperty)):properties.append(location)
		return super()._create_schema(schema_name=schema_name,ignore_if_exists=ignore_if_exists,warn_on_error=warn_on_error,properties=properties,kind=kind)
	def _build_create_table_exp(self,table_name_or_schema:t.Union[exp.Schema,TableName],expression:t.Optional[exp.Expression],exists:bool=_B,replace:bool=_E,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,**kwargs:t.Any)->exp.Create:
		exists=_E if replace else exists;table:exp.Table
		if isinstance(table_name_or_schema,str):table=exp.to_table(table_name_or_schema)
		elif isinstance(table_name_or_schema,exp.Schema):table=table_name_or_schema.this
		else:table=table_name_or_schema
		properties=self._build_table_properties_exp(table=table,expression=expression,target_columns_to_types=target_columns_to_types,partitioned_by=partitioned_by,table_properties=table_properties,table_description=table_description,table_kind=table_kind,**kwargs);is_hive=self._table_type(kwargs.get('table_format',_A))==_C
		if is_hive and partitioned_by and isinstance(table_name_or_schema,exp.Schema):partitioned_by_column_names={e.name for e in partitioned_by};filtered_expressions=[e for e in table_name_or_schema.expressions if isinstance(e,exp.ColumnDef)and e.this.name not in partitioned_by_column_names];table_name_or_schema.args['expressions']=filtered_expressions
		return exp.Create(this=table_name_or_schema,kind=table_kind or'TABLE',replace=replace,exists=exists,expression=expression,properties=properties)
	def _build_table_properties_exp(self,catalog_name:t.Optional[str]=_A,table_format:t.Optional[str]=_A,storage_format:t.Optional[str]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,partition_interval_unit:t.Optional[IntervalUnit]=_A,clustered_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,table:t.Optional[exp.Table]=_A,expression:t.Optional[exp.Expression]=_A,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties:t.List[exp.Expression]=[];table_properties=table_properties or{};is_hive=self._table_type(table_format)==_C;is_iceberg=not is_hive
		if is_hive and not expression:properties.append(exp.ExternalProperty())
		if table_format:properties.append(exp.Property(this=exp.var(_H),value=exp.Literal.string(table_format)))
		if table_description:properties.append(exp.SchemaCommentProperty(this=exp.Literal.string(table_description)))
		if partitioned_by:
			schema_expressions:t.List[exp.Expression]=[]
			if is_hive and target_columns_to_types:
				for(match_name,match_dtype)in self._find_matching_columns(partitioned_by,target_columns_to_types):column_def=exp.ColumnDef(this=exp.to_identifier(match_name),kind=match_dtype);schema_expressions.append(column_def)
			else:schema_expressions=partitioned_by
			properties.append(exp.PartitionedByProperty(this=exp.Schema(expressions=schema_expressions)))
		if clustered_by:logging.warning('clustered_by is not supported in the Athena adapter at this time')
		if storage_format:
			if is_iceberg:table_properties['format']=exp.Literal.string(storage_format)
			else:properties.append(exp.FileFormatProperty(this=storage_format))
		if table and(location:=self._table_location_or_raise(table_properties,table)):
			properties.append(location)
			if is_iceberg and expression:properties.append(exp.Property(this=exp.var('is_external'),value='false'))
		for(name,value)in table_properties.items():properties.append(exp.Property(this=exp.var(name),value=value))
		if properties:return exp.Properties(expressions=properties)
	def drop_table(self,table_name:TableName,exists:bool=_B,**kwargs:t.Any)->_A:
		table=exp.to_table(table_name)
		if self._query_table_type(table)==_C:self._truncate_table(table)
		return super().drop_table(table_name=table,exists=exists,**kwargs)
	def _truncate_table(self,table_name:TableName)->_A:
		table=exp.to_table(table_name)
		if self._query_table_type(table)==_D:return self.delete_from(table,exp.true())
		if self._is_hive_partitioned_table(table):self._clear_partition_data(table,exp.true())
		elif(s3_location:=self._query_table_s3_location(table)):self._clear_s3_location(s3_location)
	def _table_type(self,table_format:t.Optional[str]=_A)->TableType:
		if table_format and table_format.lower()==_D:return _D
		return _C
	def _query_table_type(self,table:exp.Table)->t.Optional[TableType]:
		if self.table_exists(table):return self._query_table_type_or_raise(table)
	@lru_cache()
	def _query_table_type_or_raise(self,table:exp.Table)->TableType:
		for row in self.fetchall(f"SHOW TBLPROPERTIES {table.sql(dialect=_C,identify=_B)}"):
			row_lower=row[0].lower()
			if'external'in row_lower and'true'in row_lower:return _C
		return _D
	def _is_hive_partitioned_table(self,table:exp.Table)->bool:
		try:self._list_partitions(table=table,where=_A,limit=1);return _B
		except Exception as e:
			if'TABLE_NOT_FOUND'in str(e):return _E
			raise e
	def _table_location_or_raise(self,table_properties:t.Optional[t.Dict[str,exp.Expression]],table:exp.Table)->exp.LocationProperty:
		location=self._table_location(table_properties,table)
		if not location:raise VulcanError(f"Cannot figure out location for table {table}. Please either set `s3_base_location` in `physical_properties` or set `s3_warehouse_location` in the Athena connection config")
		return location
	def _table_location(self,table_properties:t.Optional[t.Dict[str,exp.Expression]],table:exp.Table)->t.Optional[exp.LocationProperty]:
		A='s3_base_location';base_uri:str
		if table_properties and A in table_properties:
			s3_base_location_property=table_properties.pop(A)
			if isinstance(s3_base_location_property,exp.Expression):base_uri=s3_base_location_property.name
			else:base_uri=s3_base_location_property
		elif self.s3_warehouse_location:base_uri=posixpath.join(self.s3_warehouse_location,table.catalog or'',table.db or'')
		else:return
		full_uri=validate_s3_uri(posixpath.join(base_uri,table.text('this')or''),base=_B);return exp.LocationProperty(this=exp.Literal.string(full_uri))
	def _find_matching_columns(self,partitioned_by:t.List[exp.Expression],columns_to_types:t.Dict[str,exp.DataType])->t.List[t.Tuple[str,exp.DataType]]:
		matches=[]
		for col in partitioned_by:
			key=col.name
			if isinstance(col,exp.Column)and(match_dtype:=columns_to_types.get(key)):matches.append((key,match_dtype))
		return matches
	def replace_query(self,table_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,source_columns:t.Optional[t.List[str]]=_A,supports_replace_table_override:t.Optional[bool]=_A,**kwargs:t.Any)->_A:
		table=exp.to_table(table_name)
		if self._query_table_type(table=table)==_C:self.drop_table(table)
		return super().replace_query(table_name=table,query_or_df=query_or_df,target_columns_to_types=target_columns_to_types,table_description=table_description,column_descriptions=column_descriptions,source_columns=source_columns,**kwargs)
	def _insert_overwrite_by_time_partition(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Dict[str,exp.DataType],where:exp.Condition,**kwargs:t.Any)->_A:
		table=exp.to_table(table_name);table_type=self._query_table_type(table)
		if table_type==_D:return super()._insert_overwrite_by_time_partition(table,source_queries,target_columns_to_types,where,**kwargs)
		self._clear_partition_data(table,where);return super()._insert_overwrite_by_time_partition(table,source_queries,target_columns_to_types,where,insert_overwrite_strategy_override=InsertOverwriteStrategy.INTO_IS_OVERWRITE,**kwargs)
	def _clear_partition_data(self,table:exp.Table,where:t.Optional[exp.Condition])->_A:
		if(partitions_to_drop:=self._list_partitions(table,where)):
			for(_,s3_location)in partitions_to_drop:logger.debug(f"Clearing S3 location for '{table.sql(dialect=self.dialect)}': {s3_location}");self._clear_s3_location(s3_location)
			partition_values=[k for(k,_)in partitions_to_drop];logger.debug(f"Dropping partitions for '{table.sql(dialect=self.dialect)}' from metastore: {partition_values}");self._drop_partitions_from_metastore(table,partition_values)
	def _list_partitions(self,table:exp.Table,where:t.Optional[exp.Condition]=_A,limit:t.Optional[int]=_A)->t.List[t.Tuple[t.List[str],str]]:
		partition_table_name=table.copy();partition_table_name.this.replace(exp.to_identifier(f"{table.name}$partitions",quoted=_B));query=exp.select('*').from_(partition_table_name).where(where)
		if limit:query=query.limit(limit)
		partition_values=[list(r)for r in self.fetchall(query,quote_identifiers=_B)]
		if partition_values:response=self._glue_client.batch_get_partition(DatabaseName=table.db,TableName=table.name,PartitionsToGet=[{_I:[str(v)for v in lst]}for lst in partition_values]);return sorted([(p[_I],p[_J][_K])for p in response['Partitions']])
		return[]
	def _query_table_s3_location(self,table:exp.Table)->str:
		response=self._glue_client.get_table(DatabaseName=table.db,Name=table.name)
		if(location:=response.get('Table',{}).get(_J,{}).get(_K,_A)):return location
		raise VulcanError(f"Table {table} has no location set in the metastore!")
	def _drop_partitions_from_metastore(self,table:exp.Table,partition_values:t.List[t.List[str]])->_A:
		def _chunks()->t.Iterable[t.List[t.List[str]]]:
			for i in range(0,len(partition_values),25):yield partition_values[i:i+25]
		for batch in _chunks():self._glue_client.batch_delete_partition(DatabaseName=table.db,TableName=table.name,PartitionsToDelete=[{_I:v}for v in batch])
	def delete_from(self,table_name:TableName,where:t.Union[str,exp.Expression])->_A:
		table=exp.to_table(table_name);table_type=self._query_table_type(table)
		if table_type==_D:return super().delete_from(table,where)
		if table_type==_C:
			empty_check=exp.select('*').from_(table).where(where).limit(1)
			if len(self.fetchall(empty_check))>0:raise VulcanError('Cannot delete individual records from a Hive table')
	def _clear_s3_location(self,s3_uri:str)->_A:
		A='Key';s3=self._s3_client;bucket,key=parse_s3_uri(s3_uri)
		if not key.endswith('/'):key=f"{key}/"
		keys_to_delete=[]
		for page in s3.get_paginator('list_objects_v2').paginate(Bucket=bucket,Prefix=key,Delimiter='/'):
			keys=[item[A]for item in page.get('Contents',[])]
			if keys:keys_to_delete.append(keys)
		for chunk in keys_to_delete:s3.delete_objects(Bucket=bucket,Delete={'Objects':[{A:k}for k in chunk]})
	@property
	def _glue_client(self)->t.Any:return self._boto3_client('glue')
	@property
	def _s3_client(self)->t.Any:return self._boto3_client('s3')
	def _boto3_client(self,name:str)->t.Any:conn=self.connection;return conn.session.client(name,region_name=conn.region_name,config=conn.config,**conn._client_kwargs)
	def get_current_catalog(self)->t.Optional[str]:return self.connection.catalog_name