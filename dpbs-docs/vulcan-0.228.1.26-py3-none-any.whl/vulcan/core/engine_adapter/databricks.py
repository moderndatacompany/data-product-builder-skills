from __future__ import annotations
_I='catalog'
_H='databricks_connect_use_serverless'
_G='databricks_connect_cluster_id'
_F='databricks_connect_access_token'
_E='databricks_connect_server_hostname'
_D='use_spark_engine_adapter'
_C=False
_B=True
_A=None
import logging,typing as t
from functools import partial
from sqlglot import exp
from vulcan.core.dialect import to_schema
from vulcan.core.engine_adapter.mixins import GrantsFromInfoSchemaMixin
from vulcan.core.engine_adapter.shared import CatalogSupport,DataObject,DataObjectType,InsertOverwriteStrategy,SourceQuery
from vulcan.core.engine_adapter.spark import SparkEngineAdapter
from vulcan.core.node import IntervalUnit
from vulcan.core.schema_diff import NestedSupport
from vulcan.engines.spark.db_api.spark_session import connection,SparkSessionConnection
from vulcan.utils.errors import VulcanError,MissingDefaultCatalogError
if t.TYPE_CHECKING:import pandas as pd;from vulcan.core._typing import SchemaName,TableName,SessionProperties;from vulcan.core.engine_adapter._typing import DF,PySparkSession,Query
logger=logging.getLogger(__name__)
class DatabricksEngineAdapter(SparkEngineAdapter,GrantsFromInfoSchemaMixin):
	DIALECT='databricks';INSERT_OVERWRITE_STRATEGY=InsertOverwriteStrategy.REPLACE_WHERE;SUPPORTS_CLONING=_B;SUPPORTS_MATERIALIZED_VIEWS=_B;SUPPORTS_MATERIALIZED_VIEW_SCHEMA=_B;SUPPORTS_GRANTS=_B;USE_CATALOG_IN_GRANTS=_B;QUOTE_IDENTIFIERS_IN_VIEWS=_B;SCHEMA_DIFFER_KWARGS={'support_positional_add':_B,'nested_support':NestedSupport.ALL,'array_element_selector':'element','parameterized_type_defaults':{exp.DataType.build('DECIMAL',dialect=DIALECT).this:[(10,0),(0,)]}}
	def __init__(self,*args:t.Any,**kwargs:t.Any)->_A:super().__init__(*args,**kwargs);self._set_spark_engine_adapter_if_needed()
	@classmethod
	def can_access_spark_session(cls,disable_spark_session:bool)->bool:
		from vulcan import RuntimeEnv
		if disable_spark_session:return _C
		return RuntimeEnv.get().is_databricks
	@classmethod
	def can_access_databricks_connect(cls,disable_databricks_connect:bool)->bool:
		if disable_databricks_connect:return _C
		try:from databricks.connect import DatabricksSession;return _B
		except ImportError:return _C
	@property
	def _use_spark_session(self)->bool:
		if self.can_access_spark_session(bool(self._extra_config.get('disable_spark_session'))):return _B
		return self.can_access_databricks_connect(bool(self._extra_config.get('disable_databricks_connect')))and{_E,_F}.issubset(self._extra_config)and(_G in self._extra_config or _H in self._extra_config)
	@property
	def is_spark_session_connection(self)->bool:return isinstance(self.connection,SparkSessionConnection)
	def _set_spark_engine_adapter_if_needed(self)->_A:
		self._spark_engine_adapter=_A
		if not self._use_spark_session or self.is_spark_session_connection:return
		from databricks.connect import DatabricksSession;connect_kwargs=dict(host=self._extra_config[_E],token=self._extra_config[_F])
		if _H in self._extra_config:connect_kwargs['serverless']=_B
		else:connect_kwargs['cluster_id']=self._extra_config[_G]
		catalog=self._extra_config.get(_I);spark=DatabricksSession.builder.remote(**connect_kwargs).userAgent('vulcan').getOrCreate();self._spark_engine_adapter=SparkEngineAdapter(partial(connection,spark=spark,catalog=catalog),default_catalog=catalog,execute_log_level=self._execute_log_level,multithreaded=self._multithreaded,sql_gen_kwargs=self._sql_gen_kwargs,register_comments=self._register_comments,pre_ping=self._pre_ping,pretty_sql=self._pretty_sql)
	@property
	def cursor(self)->t.Any:
		if self._connection_pool.get_attribute(_D)and not self.is_spark_session_connection:return self._spark_engine_adapter.cursor
		return super().cursor
	@property
	def spark(self)->PySparkSession:
		if not self._use_spark_session:raise VulcanError('SparkSession is not available. Either run from a Databricks Notebook or install `databricks-connect` and configure it to connect to your Databricks cluster.')
		if self.is_spark_session_connection:return self.connection.spark
		return self._spark_engine_adapter.spark
	@property
	def catalog_support(self)->CatalogSupport:return CatalogSupport.FULL_SUPPORT
	@staticmethod
	def _grant_object_kind(table_type:DataObjectType)->str:
		if table_type==DataObjectType.VIEW:return'VIEW'
		if table_type==DataObjectType.MATERIALIZED_VIEW:return'MATERIALIZED VIEW'
		return'TABLE'
	def _get_grant_expression(self,table:exp.Table)->exp.Expression:A='where';expression=super()._get_grant_expression(table);expression.args[A].set('this',exp.and_(expression.args[A].this,exp.column('inherited_from').eq(exp.Literal.string('NONE')),wrap=_C));return expression
	def _begin_session(self,properties:SessionProperties)->t.Any:self.set_current_catalog(self.default_catalog)
	def _end_session(self)->_A:self._connection_pool.set_attribute(_D,_C)
	def _df_to_source_queries(self,df:DF,target_columns_to_types:t.Dict[str,exp.DataType],batch_size:int,target_table:TableName,source_columns:t.Optional[t.List[str]]=_A)->t.List[SourceQuery]:
		if not self._use_spark_session:return super(SparkEngineAdapter,self)._df_to_source_queries(df,target_columns_to_types,batch_size,target_table,source_columns=source_columns)
		pyspark_df=self._ensure_pyspark_df(df,target_columns_to_types,source_columns=source_columns)
		def query_factory()->Query:temp_table=self._get_temp_table(target_table or'spark',table_only=_B);pyspark_df.createOrReplaceTempView(temp_table.sql(dialect=self.dialect));self._connection_pool.set_attribute(_D,_B);return exp.select(*self._select_columns(target_columns_to_types)).from_(temp_table)
		return[SourceQuery(query_factory=query_factory)]
	def _fetch_native_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_C)->DF:
		if self.is_spark_session_connection:return super()._fetch_native_df(query,quote_identifiers=quote_identifiers)
		if self._spark_engine_adapter:return self._spark_engine_adapter._fetch_native_df(query,quote_identifiers=quote_identifiers)
		self.execute(query);return self.cursor.fetchall_arrow().to_pandas()
	def _fetch_native_df_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_C)->DF:
		if self.is_spark_session_connection:return super()._fetch_native_df_with_params(query,params,quote_identifiers=quote_identifiers)
		if self._spark_engine_adapter:return self._spark_engine_adapter._fetch_native_df_with_params(query,params,quote_identifiers=quote_identifiers)
		self.execute(query,params=params);return self.cursor.fetchall_arrow().to_pandas()
	def fetchdf(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_C)->pd.DataFrame:
		import pandas as pd;df=self._fetch_native_df(query,quote_identifiers=quote_identifiers)
		if not isinstance(df,pd.DataFrame):return df.toPandas()
		return df
	def get_current_catalog(self)->t.Optional[str]:
		pyspark_catalog=_A;sql_connector_catalog=_A
		if self._spark_engine_adapter:
			from py4j.protocol import Py4JError;from pyspark.errors.exceptions.connect import SparkConnectGrpcException
			try:pyspark_catalog=self._spark_engine_adapter.get_current_catalog()
			except(Py4JError,SparkConnectGrpcException):pass
		elif self.is_spark_session_connection:pyspark_catalog=self.connection.spark.catalog.currentCatalog()
		if not self.is_spark_session_connection:result=self.fetchone(exp.select(self.CURRENT_CATALOG_EXPRESSION));sql_connector_catalog=result[0]if result else _A
		if self._spark_engine_adapter and pyspark_catalog!=sql_connector_catalog:logger.warning(f"Current catalog mismatch between Databricks SQL Connector and Databricks-Connect: `{sql_connector_catalog}` != `{pyspark_catalog}`. Set `catalog` connection property to make them the same.")
		return pyspark_catalog or sql_connector_catalog
	def set_current_catalog(self,catalog_name:str)->_A:
		def _set_spark_session_current_catalog(spark:PySparkSession)->_A:
			from py4j.protocol import Py4JError;from pyspark.errors.exceptions.connect import SparkConnectGrpcException
			try:spark.catalog.setCurrentCatalog(catalog_name)
			except(Py4JError,SparkConnectGrpcException):pass
		self.execute(exp.Use(this=exp.to_identifier(catalog_name),kind='CATALOG'))
		if self.is_spark_session_connection:_set_spark_session_current_catalog(self.connection.spark)
		if self._spark_engine_adapter:_set_spark_session_current_catalog(self._spark_engine_adapter.spark)
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		C='table_catalog';B='table_schema';A='table_name';schema=to_schema(schema_name);catalog_name=schema.catalog or self.get_current_catalog();query=exp.select(exp.column(A).as_('name'),exp.column(B).as_('schema'),exp.column(C).as_(_I),exp.case(exp.column('table_type')).when(exp.Literal.string('VIEW'),exp.Literal.string('view')).when(exp.Literal.string('MATERIALIZED_VIEW'),exp.Literal.string('materialized_view')).else_(exp.Literal.string('table')).as_('type')).from_(exp.table_('tables','information_schema','system')).where(exp.column(C).eq(catalog_name)).where(exp.column(B).eq(schema.db))
		if object_names:query=query.where(exp.column(A).isin(*object_names))
		df=self.fetchdf(query);return[DataObject(catalog=row.catalog,schema=row.schema,name=row.name,type=DataObjectType.from_str(row.type))for row in df.itertuples()]
	def clone_table(self,target_table_name:TableName,source_table_name:TableName,replace:bool=_C,exists:bool=_B,clone_kwargs:t.Optional[t.Dict[str,t.Any]]=_A,**kwargs:t.Any)->_A:clone_kwargs=clone_kwargs or{};clone_kwargs['shallow']=_B;super().clone_table(target_table_name,source_table_name,replace=replace,clone_kwargs=clone_kwargs,**kwargs)
	def wap_supported(self,table_name:TableName)->bool:return _C
	def close(self)->t.Any:
		super().close()
		if self._spark_engine_adapter:self._spark_engine_adapter.close()
	@property
	def default_catalog(self)->t.Optional[str]:
		try:return super().default_catalog
		except MissingDefaultCatalogError as e:raise MissingDefaultCatalogError("Could not determine default catalog. Define the connection property `catalog` since it can't be inferred from your connection. See Vulcan Databricks documentation for details")from e
	def _build_table_properties_exp(self,catalog_name:t.Optional[str]=_A,table_format:t.Optional[str]=_A,storage_format:t.Optional[str]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,partition_interval_unit:t.Optional[IntervalUnit]=_A,clustered_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties=super()._build_table_properties_exp(catalog_name=catalog_name,table_format=table_format,storage_format=storage_format,partitioned_by=partitioned_by,partition_interval_unit=partition_interval_unit,clustered_by=clustered_by,table_properties=table_properties,target_columns_to_types=target_columns_to_types,table_description=table_description,table_kind=table_kind)
		if clustered_by:clustered_by_exp=exp.Cluster(expressions=[exp.Tuple(expressions=[c.copy()for c in clustered_by])]);expressions=properties.expressions if properties else[];expressions.append(clustered_by_exp);properties=exp.Properties(expressions=expressions)
		return properties
	def _build_column_defs(self,target_columns_to_types:t.Dict[str,exp.DataType],column_descriptions:t.Optional[t.Dict[str,str]]=_A,is_view:bool=_C,materialized:bool=_C)->t.List[exp.ColumnDef]:
		if is_view and materialized and column_descriptions:is_view=_C
		return super()._build_column_defs(target_columns_to_types,column_descriptions,is_view,materialized)