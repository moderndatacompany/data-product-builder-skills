from __future__ import annotations
_C=True
_B=False
_A=None
import typing as t,logging
from sqlglot import exp
from vulcan.core.dialect import to_schema
from vulcan.core.engine_adapter.base import EngineAdapter,_get_data_object_cache_key
from vulcan.core.engine_adapter.shared import CatalogSupport,CommentCreationTable,CommentCreationView,DataObject,DataObjectType
from vulcan.utils.errors import VulcanError
if t.TYPE_CHECKING:from vulcan.core._typing import SchemaName,TableName;from vulcan.core.engine_adapter._typing import QueryOrDF
logger=logging.getLogger(__name__)
class BasePostgresEngineAdapter(EngineAdapter):
	DEFAULT_BATCH_SIZE=400;COMMENT_CREATION_TABLE=CommentCreationTable.COMMENT_COMMAND_ONLY;COMMENT_CREATION_VIEW=CommentCreationView.COMMENT_COMMAND_ONLY;SUPPORTS_QUERY_EXECUTION_TRACKING=_C;SUPPORTED_DROP_CASCADE_OBJECT_KINDS=['SCHEMA','TABLE','VIEW']
	def columns(self,table_name:TableName,include_pseudo_columns:bool=_B)->t.Dict[str,exp.DataType]:
		table=exp.to_table(table_name);sql=exp.select('attname AS column_name','pg_catalog.format_type(atttypid, atttypmod) AS data_type').from_('pg_catalog.pg_attribute').join('pg_catalog.pg_class',on='pg_class.oid = attrelid').join('pg_catalog.pg_namespace',on='pg_namespace.oid = relnamespace').where(exp.and_('attnum > 0','NOT attisdropped',exp.column('relname').eq(table.alias_or_name)))
		if table.args.get('db'):sql=sql.where(exp.column('nspname').eq(table.args['db'].name))
		self.execute(sql);resp=self.cursor.fetchall()
		if not resp:raise VulcanError(f"Could not get columns for table '{table.sql(dialect=self.dialect)}'. Table not found.")
		return{column_name:exp.DataType.build(data_type,dialect=self.dialect,udt=_C)for(column_name,data_type)in resp}
	@property
	def catalog_support(self)->CatalogSupport:return CatalogSupport.SINGLE_CATALOG_ONLY
	def table_exists(self,table_name:TableName)->bool:
		table=exp.to_table(table_name);data_object_cache_key=_get_data_object_cache_key(table.catalog,table.db,table.name)
		if data_object_cache_key in self._data_object_cache:logger.debug('Table existence cache hit: %s',data_object_cache_key);return self._data_object_cache[data_object_cache_key]is not _A
		sql=exp.select('1').from_('information_schema.tables').where(f"table_name = '{table.alias_or_name}'");database_name=table.db
		if database_name:sql=sql.where(f"table_schema = '{database_name}'")
		self.execute(sql);result=self.cursor.fetchone();return result[0]==1 if result is not _A else _B
	def create_view(self,view_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,replace:bool=_C,materialized:bool=_B,materialized_properties:t.Optional[t.Dict[str,t.Any]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,view_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,source_columns:t.Optional[t.List[str]]=_A,**create_kwargs:t.Any)->_A:
		with self.transaction():
			if replace:self.drop_data_object_on_type_mismatch(self.get_data_object(view_name),DataObjectType.VIEW if not materialized else DataObjectType.MATERIALIZED_VIEW);self.drop_view(view_name,materialized=materialized)
			super().create_view(view_name,query_or_df,target_columns_to_types=target_columns_to_types,replace=_B,materialized=materialized,materialized_properties=materialized_properties,table_description=table_description,column_descriptions=column_descriptions,view_properties=view_properties,source_columns=source_columns,**create_kwargs)
	def drop_view(self,view_name:TableName,ignore_if_not_exists:bool=_C,materialized:bool=_B,**kwargs:t.Any)->_A:A='cascade';kwargs[A]=kwargs.get(A,_C);return super().drop_view(view_name,ignore_if_not_exists=ignore_if_not_exists,materialized=materialized,**kwargs)
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		D='type';C='schemaname';B='name';A='schema_name';catalog=self.get_current_catalog();table_query=exp.select(exp.column(C).as_(A),exp.column('tablename').as_(B),exp.Literal.string('TABLE').as_(D)).from_('pg_tables');view_query=exp.select(exp.column(C).as_(A),exp.column('viewname').as_(B),exp.Literal.string('VIEW').as_(D)).from_('pg_views');materialized_view_query=exp.select(exp.column(C).as_(A),exp.column('matviewname').as_(B),exp.Literal.string('MATERIALIZED_VIEW').as_(D)).from_('pg_matviews');subquery=exp.union(table_query,exp.union(view_query,materialized_view_query,distinct=_B),distinct=_B);query=exp.select('*').from_(subquery.subquery(alias='objs')).where(exp.column(A).eq(to_schema(schema_name).db))
		if object_names:query=query.where(exp.column(B).isin(*object_names))
		df=self.fetchdf(query);return[DataObject(catalog=catalog,schema=row.schema_name,name=row.name,type=DataObjectType.from_str(row.type))for row in df.itertuples()]
	def _get_current_schema(self)->str:
		result=self.fetchone(exp.select(exp.func('current_schema')))
		if result and result[0]:return result[0]
		return'public'