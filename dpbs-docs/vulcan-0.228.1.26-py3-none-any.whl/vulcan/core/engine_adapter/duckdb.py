from __future__ import annotations
_D='DATABASE'
_C=False
_B=True
_A=None
import typing as t
from sqlglot import exp
from pathlib import Path
from vulcan.core.engine_adapter.mixins import GetCurrentCatalogFromFunctionMixin,LogicalMergeMixin,RowDiffMixin
from vulcan.core.engine_adapter.shared import CatalogSupport,CommentCreationTable,CommentCreationView,DataObject,DataObjectType,SourceQuery,set_catalog
if t.TYPE_CHECKING:from vulcan.core._typing import SchemaName,TableName;from vulcan.core.engine_adapter._typing import DF
@set_catalog(override_mapping={'_get_data_objects':CatalogSupport.REQUIRES_SET_CATALOG})
class DuckDBEngineAdapter(LogicalMergeMixin,GetCurrentCatalogFromFunctionMixin,RowDiffMixin):
	DIALECT='duckdb';SUPPORTS_TRANSACTIONS=_C;SCHEMA_DIFFER_KWARGS={'parameterized_type_defaults':{exp.DataType.build('DECIMAL',dialect=DIALECT).this:[(18,3),(0,)]}};COMMENT_CREATION_TABLE=CommentCreationTable.COMMENT_COMMAND_ONLY;COMMENT_CREATION_VIEW=CommentCreationView.COMMENT_COMMAND_ONLY;SUPPORTS_CREATE_DROP_CATALOG=_B;SUPPORTED_DROP_CASCADE_OBJECT_KINDS=['SCHEMA','TABLE','VIEW']
	@property
	def catalog_support(self)->CatalogSupport:return CatalogSupport.FULL_SUPPORT
	def set_current_catalog(self,catalog:str)->_A:self.execute(exp.Use(this=exp.to_identifier(catalog)))
	def _create_catalog(self,catalog_name:exp.Identifier)->_A:
		if not self._is_motherduck:db_filename=f"{catalog_name.output_name}.db";self.execute(exp.Attach(this=exp.alias_(exp.Literal.string(db_filename),catalog_name),exists=_B))
		else:self.execute(exp.Create(this=exp.Table(this=catalog_name),kind=_D,exists=_B))
	def _drop_catalog(self,catalog_name:exp.Identifier)->_A:
		if not self._is_motherduck:
			db_file_path=Path(f"{catalog_name.output_name}.db");self.execute(exp.Detach(this=catalog_name,exists=_B))
			if db_file_path.exists():db_file_path.unlink()
		else:self.execute(exp.Drop(this=exp.Table(this=catalog_name),kind=_D,cascade=_B,exists=_B))
	def _df_to_source_queries(self,df:DF,target_columns_to_types:t.Dict[str,exp.DataType],batch_size:int,target_table:TableName,source_columns:t.Optional[t.List[str]]=_A)->t.List[SourceQuery]:temp_table=self._get_temp_table(target_table);temp_table_sql=exp.select(*self._casted_columns(target_columns_to_types,source_columns)).from_('df').sql(dialect=self.dialect);self.cursor.sql(f"CREATE TABLE {temp_table} AS {temp_table_sql}");return[SourceQuery(query_factory=lambda:self._select_columns(target_columns_to_types).from_(temp_table),cleanup_func=lambda:self.drop_table(temp_table))]
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		C='table';B='table_schema';A='table_name';catalog=self.get_current_catalog()
		if isinstance(schema_name,exp.Table):schema_name='.'.join(part.name for part in schema_name.parts)
		query=exp.select(exp.column(A).as_('name'),exp.column(B).as_('schema'),exp.case(exp.column('table_type')).when(exp.Literal.string('BASE TABLE'),exp.Literal.string(C)).when(exp.Literal.string('VIEW'),exp.Literal.string('view')).when(exp.Literal.string('LOCAL TEMPORARY'),exp.Literal.string(C)).as_('type')).from_(exp.to_table('system.information_schema.tables')).where(exp.column('table_catalog').eq(catalog),exp.column(B).eq(schema_name))
		if object_names:query=query.where(exp.column(A).isin(*object_names))
		df=self.fetchdf(query);return[DataObject(catalog=catalog,schema=row.schema,name=row.name,type=DataObjectType.from_str(row.type))for row in df.itertuples()]
	def _normalize_decimal_value(self,col:exp.Expression,precision:int)->exp.Expression:return exp.cast(exp.cast(col,'DOUBLE'),f"DECIMAL(38, {precision})")
	def _create_table(self,table_name_or_schema:t.Union[exp.Schema,TableName],expression:t.Optional[exp.Expression],exists:bool=_B,replace:bool=_C,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,table_kind:t.Optional[str]=_A,track_rows_processed:bool=_B,**kwargs:t.Any)->_A:
		catalog=self.get_current_catalog();catalog_type_tuple=self.fetchone(exp.select('type').from_('duckdb_databases()').where(exp.column('database_name').eq(catalog)));catalog_type=catalog_type_tuple[0]if catalog_type_tuple else _A;partitioned_by_exps=_A
		if catalog_type=='ducklake':partitioned_by_exps=kwargs.pop('partitioned_by',_A)
		super()._create_table(table_name_or_schema,expression,exists,replace,target_columns_to_types,table_description,column_descriptions,table_kind,track_rows_processed=track_rows_processed,**kwargs)
		if partitioned_by_exps:table_name=table_name_or_schema.this if isinstance(table_name_or_schema,exp.Schema)else table_name_or_schema;table_name_str=table_name.sql(dialect=self.dialect)if isinstance(table_name,exp.Table)else table_name;partitioned_by_str=', '.join(expr.sql(dialect=self.dialect)for expr in partitioned_by_exps);self.execute(f"ALTER TABLE {table_name_str} SET PARTITIONED BY ({partitioned_by_str});")
	@property
	def _is_motherduck(self)->bool:return self._extra_config.get('is_motherduck',_C)