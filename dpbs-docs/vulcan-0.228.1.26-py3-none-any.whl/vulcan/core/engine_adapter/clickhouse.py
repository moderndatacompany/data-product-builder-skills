from __future__ import annotations
_L='join_use_nulls'
_K='system.tables'
_J='MergeTree'
_I='settings'
_H='TABLE'
_G='database'
_F='_partition_id'
_E='name'
_D='cluster'
_C=False
_B=True
_A=None
import typing as t,logging,re
from sqlglot import exp,maybe_parse
from vulcan.core.dialect import to_schema
from vulcan.core.engine_adapter.mixins import LogicalMergeMixin
from vulcan.core.engine_adapter.base import EngineAdapterWithIndexSupport
from vulcan.core.engine_adapter.shared import DataObject,DataObjectType,EngineRunMode,SourceQuery,CommentCreationView,InsertOverwriteStrategy
from vulcan.core.schema_diff import TableAlterOperation
from vulcan.utils import get_source_columns_to_types
if t.TYPE_CHECKING:import pandas as pd;from vulcan.core._typing import SchemaName,TableName;from vulcan.core.engine_adapter._typing import DF,Query,QueryOrDF;from vulcan.core.node import IntervalUnit
logger=logging.getLogger(__name__)
class ClickhouseEngineAdapter(EngineAdapterWithIndexSupport,LogicalMergeMixin):
	DIALECT='clickhouse';SUPPORTS_TRANSACTIONS=_C;SUPPORTS_VIEW_SCHEMA=_C;SUPPORTS_REPLACE_TABLE=_C;COMMENT_CREATION_VIEW=CommentCreationView.COMMENT_COMMAND_ONLY;SCHEMA_DIFFER_KWARGS={};DEFAULT_TABLE_ENGINE=_J;ORDER_BY_TABLE_ENGINE_REGEX='^.*?MergeTree.*$'
	@property
	def engine_run_mode(self)->EngineRunMode:
		if self._extra_config.get('cloud_mode'):return EngineRunMode.CLOUD
		if self._extra_config.get(_D):return EngineRunMode.CLUSTER
		return EngineRunMode.STANDALONE
	@property
	def cluster(self)->t.Optional[str]:return self._extra_config.get(_D)
	def fetchone(self,query:t.Union[exp.Expression,str],ignore_unsupported_errors:bool=_C,quote_identifiers:bool=_C)->t.Tuple:
		with self.transaction():self.execute(query,ignore_unsupported_errors=ignore_unsupported_errors,quote_identifiers=quote_identifiers);return self.cursor.fetchall()[0]
	def _fetch_native_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_C)->pd.DataFrame:return self.cursor.client.query_df(self._to_sql(query,quote=quote_identifiers)if isinstance(query,exp.Expression)else query,use_extended_dtypes=_B)
	def _fetch_native_df_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_C)->pd.DataFrame:sql=self._to_sql(query,quote=quote_identifiers)if isinstance(query,exp.Expression)else query;return self.cursor.client.query_df(sql,parameters=params,use_extended_dtypes=_B)
	def _df_to_source_queries(self,df:DF,target_columns_to_types:t.Dict[str,exp.DataType],batch_size:int,target_table:TableName,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->t.List[SourceQuery]:
		temp_table=self._get_temp_table(target_table,**kwargs);source_columns_to_types=get_source_columns_to_types(target_columns_to_types,source_columns)
		def query_factory()->Query:
			if not self.table_exists(temp_table):self.create_table(temp_table,source_columns_to_types,storage_format=exp.var(_J),**kwargs);ordered_df=df[list(source_columns_to_types)];self.cursor.client.insert_df(temp_table.sql(dialect=self.dialect),df=ordered_df)
			return exp.select(*self._casted_columns(target_columns_to_types,source_columns)).from_(temp_table)
		return[SourceQuery(query_factory=query_factory,cleanup_func=lambda:self.drop_table(temp_table,**kwargs))]
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		query=exp.select(exp.column(_G).as_('schema_name'),exp.column(_E),exp.case(exp.column('engine')).when(exp.Literal.string('View'),exp.Literal.string('view')).else_(exp.Literal.string('table')).as_('type')).from_(_K).where(exp.column(_G).eq(to_schema(schema_name).db))
		if object_names:query=query.where(exp.column(_E).isin(*object_names))
		df=self.fetchdf(query);return[DataObject(catalog=_A,schema=row.schema_name,name=row.name,type=DataObjectType.from_str(row.type))for row in df.itertuples()]
	def create_schema(self,schema_name:SchemaName,ignore_if_exists:bool=_B,warn_on_error:bool=_B,properties:t.List[exp.Expression]=[])->_A:
		properties_copy=properties.copy()
		if self.engine_run_mode.is_cluster:properties_copy.append(exp.OnCluster(this=exp.to_identifier(self.cluster)))
		return self._create_schema(schema_name=schema_name,ignore_if_exists=ignore_if_exists,warn_on_error=warn_on_error,properties=properties_copy,kind='DATABASE')
	def _insert_overwrite_by_condition(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,where:t.Optional[exp.Condition]=_A,insert_overwrite_strategy_override:t.Optional[InsertOverwriteStrategy]=_A,**kwargs:t.Any)->_A:
		target_table=exp.to_table(table_name);target_columns_to_types=target_columns_to_types or self.columns(target_table);temp_table=self._get_temp_table(target_table);self.create_table_like(temp_table,target_table);dynamic_key=kwargs.get('dynamic_key')
		if dynamic_key:dynamic_key_exp=t.cast(exp.Expression,kwargs.get('dynamic_key_exp'));dynamic_key_unique=t.cast(bool,kwargs.get('dynamic_key_unique'))
		try:
			for source_query in source_queries:
				with source_query as query:
					if dynamic_key and dynamic_key_unique:query=query.distinct(*dynamic_key)
					query=self._order_projections_and_filter(query,target_columns_to_types,where=where);self._insert_append_query(temp_table,query,target_columns_to_types=target_columns_to_types,order_projections=_C)
			if dynamic_key:
				key_query=exp.select(dynamic_key_exp).from_(temp_table)
				if not dynamic_key_unique:key_query=key_query.distinct()
				where=dynamic_key_exp.isin(query=key_query)
			table_partition_exp=self.fetchone(exp.select('partition_key').from_(_K).where(exp.column(_G).eq(target_table.db),exp.column(_E).eq(target_table.name)));all_affected_partitions:t.Set[str]=set()
			if where:
				existing_records_insert_exp=exp.insert(self._select_columns(target_columns_to_types).from_(target_table).where(exp.paren(expression=where).not_()),temp_table)
				if table_partition_exp:partitions_temp_table_name=self._get_temp_table(exp.to_table(f"{target_table.db}._affected_partitions"));all_affected_partitions,existing_records_insert_exp=self._get_affected_partitions_and_insert_exp(target_table,temp_table,where,existing_records_insert_exp,partitions_temp_table_name)
				try:self.execute(existing_records_insert_exp,track_rows_processed=_B)
				finally:
					if table_partition_exp:self.drop_table(partitions_temp_table_name)
			if table_partition_exp and(where or kwargs.get('keep_existing_partition_rows')is _C):
				partitions_to_replace=self._get_partition_ids(temp_table);partitions_to_drop=all_affected_partitions-partitions_to_replace
				if partitions_to_replace or partitions_to_drop:self.alter_table([self._build_alter_partition_exp(target_table,temp_table,partitions_to_replace,partitions_to_drop)])
			else:self._exchange_tables(target_table,temp_table)
		finally:self.drop_table(temp_table)
	def _get_affected_partitions_and_insert_exp(self,target_table:exp.Table,temp_table:exp.Table,where:exp.Condition,existing_records_insert_exp:exp.Insert,partitions_temp_table_name:exp.Table)->tuple[t.Set[str],exp.Insert]:A='partition_id';self.ctas(partitions_temp_table_name,exp.select(A).distinct().from_(exp.union(exp.select(exp.column(_F).as_(A)).from_(target_table).where(where),exp.select(exp.column(_F).as_(A)).from_(temp_table)).subquery('_affected_partitions')));all_affected_partitions=self._get_partition_ids(partitions_temp_table_name,A);existing_records_insert_exp.set('expression',existing_records_insert_exp.expression.where(exp.column(_F).isin(exp.select(A).from_(partitions_temp_table_name))));return all_affected_partitions,existing_records_insert_exp
	def _build_alter_partition_exp(self,target_table:exp.Table,temp_table:exp.Table,partitions_to_replace:t.Set[str],partitions_to_drop:t.Set[str])->exp.Alter:
		A='actions';alter_expr=exp.Alter(this=target_table,kind=_H)
		for partition in partitions_to_replace:alter_expr.append(A,exp.ReplacePartition(expression=exp.Partition(expressions=[exp.PartitionId(this=exp.Literal.string(str(partition)))]),source=temp_table))
		for partition in partitions_to_drop:alter_expr.append(A,exp.DropPartition(expressions=[exp.Partition(expressions=[exp.PartitionId(this=exp.Literal.string(str(partition)))])],source=temp_table))
		return alter_expr
	def _replace_by_key(self,target_table:TableName,source_table:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],key:t.Sequence[exp.Expression],is_unique_key:bool,source_columns:t.Optional[t.List[str]]=_A)->_A:source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(source_table,target_columns_to_types,target_table=target_table,source_columns=source_columns);key_exp=exp.func('CONCAT_WS',"'__SQLMESH_DELIM__'",*key)if len(key)>1 else key[0];self._insert_overwrite_by_condition(target_table,source_queries,target_columns_to_types,dynamic_key=key,dynamic_key_exp=key_exp,dynamic_key_unique=is_unique_key)
	def insert_overwrite_by_partition(self,table_name:TableName,query_or_df:QueryOrDF,partitioned_by:t.List[exp.Expression],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A)->_A:source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types,target_table=table_name,source_columns=source_columns);self._insert_overwrite_by_condition(table_name,source_queries,target_columns_to_types,keep_existing_partition_rows=_C)
	def _create_table_like(self,target_table_name:TableName,source_table_name:TableName,exists:bool,**kwargs:t.Any)->_A:self.execute(f"CREATE TABLE {target_table_name}{self._on_cluster_sql()} AS {source_table_name}")
	def _get_partition_ids(self,table:exp.Table,partition_col_name:str=_F,where:t.Optional[exp.Condition]=_A,limit:t.Optional[int]=_A)->t.Set[t.Any]:
		partitions_query=exp.select(partition_col_name).distinct().from_(table)
		if where:partitions_query=partitions_query.where(where)
		if limit:partitions_query=partitions_query.limit(limit)
		partitions=self.fetchall(partitions_query);return set([part[0]for part in partitions]if partitions else[])
	def _create_table(self,table_name_or_schema:t.Union[exp.Schema,TableName],expression:t.Optional[exp.Expression],exists:bool=_B,replace:bool=_C,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,table_kind:t.Optional[str]=_A,track_rows_processed:bool=_B,**kwargs:t.Any)->_A:
		C='limit';B='nullable';A='partitioned_by'
		if kwargs.get(A):
			partition_cols=[col.name for part_expr in kwargs[A]for col in part_expr.find_all(exp.Column)]
			if isinstance(table_name_or_schema,exp.Schema):
				for coldef in table_name_or_schema.expressions:
					if coldef.name in partition_cols:coldef.kind.set(B,_C)
			if target_columns_to_types:
				for col in partition_cols:target_columns_to_types[col].set(B,_C)
		super()._create_table(table_name_or_schema,expression,exists,replace,target_columns_to_types,table_description,column_descriptions,table_kind,empty_ctas=self.engine_run_mode.is_cloud and expression is not _A,track_rows_processed=track_rows_processed,**kwargs)
		if self.engine_run_mode.is_cloud and table_kind!='VIEW'and expression and not(expression.args.get(C)is not _A and expression.args[C].expression.this=='0'):table_name=table_name_or_schema.this if isinstance(table_name_or_schema,exp.Schema)else table_name_or_schema;self._insert_append_query(table_name,expression,target_columns_to_types or self.columns(table_name))
	def _exchange_tables(self,old_table_name:TableName,new_table_name:TableName)->_A:
		from clickhouse_connect.driver.exceptions import DatabaseError;old_table_sql=exp.to_table(old_table_name).sql(dialect=self.dialect,identify=_B);new_table_sql=exp.to_table(new_table_name).sql(dialect=self.dialect,identify=_B)
		try:self.execute(f"EXCHANGE TABLES {old_table_sql} AND {new_table_sql}{self._on_cluster_sql()}")
		except DatabaseError as e:
			if'NOT_IMPLEMENTED'in str(e):throwaway_table_name=self._get_temp_table(old_table_name);self._rename_table(old_table_name,throwaway_table_name);self._rename_table(new_table_name,old_table_name);self.drop_table(throwaway_table_name)
	def _rename_table(self,old_table_name:TableName,new_table_name:TableName)->_A:old_table_sql=exp.to_table(old_table_name).sql(dialect=self.dialect,identify=_B);new_table_sql=exp.to_table(new_table_name).sql(dialect=self.dialect,identify=_B);self.execute(f"RENAME TABLE {old_table_sql} TO {new_table_sql}{self._on_cluster_sql()}")
	def delete_from(self,table_name:TableName,where:t.Union[str,exp.Expression])->_A:
		delete_expr=exp.delete(table_name,where)
		if self.engine_run_mode.is_cluster:delete_expr.set(_D,exp.OnCluster(this=exp.to_identifier(self.cluster)))
		self.execute(delete_expr)
	def alter_table(self,alter_expressions:t.Union[t.List[exp.Alter],t.List[TableAlterOperation]])->_A:
		with self.transaction():
			for alter_expression in[x.expression if isinstance(x,TableAlterOperation)else x for x in alter_expressions]:
				if self.engine_run_mode.is_cluster:alter_expression.set(_D,exp.OnCluster(this=exp.to_identifier(self.cluster)))
				self.execute(alter_expression)
	def _drop_object(self,name:TableName|SchemaName,exists:bool=_B,kind:str=_H,cascade:bool=_C,**drop_args:t.Any)->_A:super()._drop_object(name=name,exists=exists,kind=kind,cascade=cascade,cluster=exp.OnCluster(this=exp.to_identifier(self.cluster))if self.engine_run_mode.is_cluster else _A,**drop_args)
	def _build_partitioned_by_exp(self,partitioned_by:t.List[exp.Expression],**kwargs:t.Any)->t.Optional[t.Union[exp.PartitionedByProperty,exp.Property]]:return exp.PartitionedByProperty(this=exp.Schema(expressions=partitioned_by))
	def ensure_nulls_for_unmatched_after_join(self,query:Query)->Query:query.append(_I,exp.var(_L).eq(exp.Literal.number('1')));return query
	def use_server_nulls_for_unmatched_after_join(self,query:Query)->Query:
		setting_name=_L;setting_value='1';user_settings=query.args.get(_I)
		if not(user_settings and any([isinstance(setting,exp.EQ)and setting.name==setting_name for setting in user_settings])):
			server_value=self.fetchone(exp.select('value').from_('system.settings').where(exp.column(_E).eq(exp.Literal.string(setting_name))))[0];inject_setting=setting_value!=server_value;setting_value=server_value if inject_setting else setting_value
			if inject_setting:query.append(_I,exp.var(setting_name).eq(exp.Literal.number(setting_value)))
		return query
	def _build_settings_property(self,key:str,value:exp.Expression|str|int|float)->exp.SettingsProperty:return exp.SettingsProperty(expressions=[exp.EQ(this=exp.var(key.lower()),expression=value if isinstance(value,exp.Expression)else exp.Literal(this=value,is_string=isinstance(value,str)))])
	def _build_table_properties_exp(self,catalog_name:t.Optional[str]=_A,table_format:t.Optional[str]=_A,storage_format:t.Optional[str]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,partition_interval_unit:t.Optional[IntervalUnit]=_A,clustered_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,empty_ctas:bool=_C,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties:t.List[exp.Expression]=[];table_engine=self.DEFAULT_TABLE_ENGINE
		if storage_format:table_engine=storage_format.this if isinstance(storage_format,exp.Var)else storage_format
		properties.append(exp.EngineProperty(this=table_engine));table_properties_copy={k.upper():v for(k,v)in(table_properties.copy()if table_properties else{}).items()};mergetree_engine=bool(re.search(self.ORDER_BY_TABLE_ENGINE_REGEX,table_engine));ordered_by_raw=table_properties_copy.pop('ORDER_BY',_A)
		if mergetree_engine:
			ordered_by_exprs=[]
			if ordered_by_raw:
				ordered_by_vals=[]
				if isinstance(ordered_by_raw,(exp.Tuple,exp.Array)):ordered_by_vals=ordered_by_raw.expressions
				if isinstance(ordered_by_raw,exp.Paren):ordered_by_vals=[ordered_by_raw.this]
				if not ordered_by_vals:ordered_by_vals=ordered_by_raw if isinstance(ordered_by_raw,list)else[ordered_by_raw]
				for col in ordered_by_vals:ordered_by_exprs.append(col if isinstance(col,exp.Column)else maybe_parse(col.name if isinstance(col,exp.Literal)else col,dialect=self.dialect,into=exp.Ordered))
			properties.append(exp.Order(expressions=[exp.Tuple(expressions=ordered_by_exprs)]))
		primary_key=table_properties_copy.pop('PRIMARY_KEY',_A)
		if mergetree_engine and primary_key:
			primary_key_vals=[]
			if isinstance(primary_key,(exp.Tuple,exp.Array)):primary_key_vals=primary_key.expressions
			if isinstance(ordered_by_raw,exp.Paren):primary_key_vals=[primary_key.this]
			if not primary_key_vals:primary_key_vals=primary_key if isinstance(primary_key,list)else[primary_key]
			properties.append(exp.PrimaryKey(expressions=[exp.to_column(k.name if isinstance(k,exp.Literal)else k)for k in primary_key_vals]))
		ttl=table_properties_copy.pop('TTL',_A)
		if ttl:properties.append(exp.MergeTreeTTL(expressions=[ttl if isinstance(ttl,exp.Expression)else exp.var(ttl)]))
		if partitioned_by and(partitioned_by_prop:=self._build_partitioned_by_exp(partitioned_by))is not _A:properties.append(partitioned_by_prop)
		if self.engine_run_mode.is_cluster:properties.append(exp.OnCluster(this=exp.to_identifier(self.cluster)))
		if empty_ctas:properties.append(exp.EmptyProperty())
		if table_properties_copy:properties.extend([self._build_settings_property(k,v)for(k,v)in table_properties_copy.items()])
		if table_description:properties.append(exp.SchemaCommentProperty(this=exp.Literal.string(self._truncate_table_comment(table_description))))
		if properties:return exp.Properties(expressions=properties)
	def _build_view_properties_exp(self,view_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,table_description:t.Optional[str]=_A,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties:t.List[exp.Expression]=[];view_properties_copy=view_properties.copy()if view_properties else{}
		if self.engine_run_mode.is_cluster:properties.append(exp.OnCluster(this=exp.to_identifier(self.cluster)))
		if view_properties_copy:properties.extend([self._build_settings_property(k,v)for(k,v)in view_properties_copy.items()])
		if table_description:properties.append(exp.SchemaCommentProperty(this=exp.Literal.string(self._truncate_table_comment(table_description))))
		if properties:return exp.Properties(expressions=properties)
	def _build_create_comment_table_exp(self,table:exp.Table,table_comment:str,table_kind:str,**kwargs:t.Any)->exp.Comment|str:table_sql=table.sql(dialect=self.dialect,identify=_B);truncated_comment=self._truncate_table_comment(table_comment);comment_sql=exp.Literal.string(truncated_comment).sql(dialect=self.dialect);return f"ALTER TABLE {table_sql}{self._on_cluster_sql()} MODIFY COMMENT {comment_sql}"
	def _build_create_comment_column_exp(self,table:exp.Table,column_name:str,column_comment:str,table_kind:str=_H,**kwargs:t.Any)->exp.Comment|str:table_sql=table.sql(dialect=self.dialect,identify=_B);column_sql=exp.to_column(column_name).sql(dialect=self.dialect,identify=_B);truncated_comment=self._truncate_table_comment(column_comment);comment_sql=exp.Literal.string(truncated_comment).sql(dialect=self.dialect);return f"ALTER TABLE {table_sql}{self._on_cluster_sql()} COMMENT COLUMN {column_sql} {comment_sql}"
	def _on_cluster_sql(self)->str:
		if self.engine_run_mode.is_cluster:cluster_name=exp.to_identifier(self.cluster,quoted=_B).sql(dialect=self.dialect);return f" ON CLUSTER {cluster_name} "
		return''