from __future__ import annotations
_F='warehouses'
_E='displayName'
_D='target_catalog'
_C=True
_B=False
_A=None
import typing as t,logging,requests,time
from functools import cached_property
from sqlglot import exp
from tenacity import retry,stop_after_attempt,wait_exponential,retry_if_result
from vulcan.core.engine_adapter.mssql import MSSQLEngineAdapter
from vulcan.core.engine_adapter.shared import InsertOverwriteStrategy
from vulcan.utils.errors import VulcanError
from vulcan.utils.connection_pool import ConnectionPool
from vulcan.core.schema_diff import TableAlterOperation
from vulcan.utils import random_id
logger=logging.getLogger(__name__)
class FabricEngineAdapter(MSSQLEngineAdapter):
	DIALECT='fabric';SUPPORTS_INDEXES=_B;SUPPORTS_TRANSACTIONS=_B;SUPPORTS_CREATE_DROP_CATALOG=_C;INSERT_OVERWRITE_STRATEGY=InsertOverwriteStrategy.DELETE_INSERT
	def __init__(self,connection_factory_or_pool:t.Union[t.Callable,t.Any],*args:t.Any,**kwargs:t.Any)->_A:
		if not isinstance(connection_factory_or_pool,ConnectionPool):original_connection_factory=connection_factory_or_pool;connection_factory_or_pool=lambda*args,**kwargs:original_connection_factory(*args,target_catalog=self._target_catalog,**kwargs)
		super().__init__(connection_factory_or_pool,*args,**kwargs)
	@property
	def _target_catalog(self)->t.Optional[str]:return self._connection_pool.get_attribute(_D)
	@_target_catalog.setter
	def _target_catalog(self,value:t.Optional[str])->_A:self._connection_pool.set_attribute(_D,value)
	@property
	def api_client(self)->FabricHttpClient:
		A='api_client'
		if(existing_client:=self._connection_pool.get_attribute(A)):return existing_client
		tenant_id:t.Optional[str]=self._extra_config.get('tenant_id');workspace_id:t.Optional[str]=self._extra_config.get('workspace_id');client_id:t.Optional[str]=self._extra_config.get('user');client_secret:t.Optional[str]=self._extra_config.get('password')
		if not tenant_id or not client_id or not client_secret:raise VulcanError('Service Principal authentication requires tenant_id, client_id, and client_secret in the Fabric connection configuration')
		if not workspace_id:raise VulcanError('Fabric requires the workspace_id to be configured in the connection configuration to create / drop catalogs')
		client=FabricHttpClient(tenant_id=tenant_id,workspace_id=workspace_id,client_id=client_id,client_secret=client_secret);self._connection_pool.set_attribute(A,client);return client
	def _create_catalog(self,catalog_name:exp.Identifier)->_A:warehouse_name=catalog_name.sql(dialect=self.dialect,identify=_B);logger.info(f"Creating Fabric warehouse: {warehouse_name}");self.api_client.create_warehouse(warehouse_name)
	def _drop_catalog(self,catalog_name:exp.Identifier)->_A:
		warehouse_name=catalog_name.sql(dialect=self.dialect,identify=_B);current_catalog=self.get_current_catalog();logger.info(f"Deleting Fabric warehouse: {warehouse_name}");self.api_client.delete_warehouse(warehouse_name)
		if warehouse_name==current_catalog:self.close()
	def set_current_catalog(self,catalog_name:str)->_A:
		current_catalog=self.get_current_catalog()
		if current_catalog and current_catalog==catalog_name:logger.debug(f"Already using catalog '{catalog_name}', no action needed");return
		logger.info(f"Switching from catalog '{current_catalog}' to '{catalog_name}'");self._connection_pool.commit();self._connection_pool.close();self._target_catalog=catalog_name;catalog_after_switch=self.get_current_catalog()
		if catalog_after_switch!=catalog_name:raise VulcanError(f"Unable to switch catalog to {catalog_name}, catalog ended up as {catalog_after_switch}")
	def alter_table(self,alter_expressions:t.Union[t.List[exp.Alter],t.List[TableAlterOperation]])->_A:
		B='dtype';A='TABLE'
		if not alter_expressions:return
		first_op=alter_expressions[0];expression=first_op.expression if isinstance(first_op,TableAlterOperation)else first_op
		if not isinstance(expression,exp.Alter)or not expression.this.catalog:logger.warning('Could not determine catalog from alter expression, executing with current context.');super().alter_table(alter_expressions);return
		target_catalog=expression.this.catalog;self.set_current_catalog(target_catalog)
		with self.transaction():
			for op in alter_expressions:
				expression=op.expression if isinstance(op,TableAlterOperation)else op
				if not isinstance(expression,exp.Alter):self.execute(expression);continue
				for action in expression.actions:
					table_name=expression.this;table_name_without_catalog=table_name.copy();table_name_without_catalog.set('catalog',_A);is_type_change=isinstance(action,exp.AlterColumn)and action.args.get(B)
					if is_type_change:column_to_alter=action.this;new_type=action.args[B];temp_column_name_str=f"{column_to_alter.name}__{random_id(short=_C)}";temp_column_name=exp.to_identifier(temp_column_name_str);logger.info("Applying workaround for column '%s' on table '%s' to change type to '%s'.",column_to_alter.sql(),table_name.sql(),new_type.sql());add_column_expr=exp.Alter(this=table_name_without_catalog.copy(),kind=A,actions=[exp.ColumnDef(this=temp_column_name.copy(),kind=new_type.copy())]);add_sql=self._to_sql(add_column_expr);self.execute(add_sql);update_sql=self._to_sql(exp.Update(this=table_name_without_catalog.copy(),expressions=[exp.EQ(this=temp_column_name.copy(),expression=exp.Cast(this=column_to_alter.copy(),to=new_type.copy()))]));self.execute(update_sql);drop_sql=self._to_sql(exp.Alter(this=table_name_without_catalog.copy(),kind=A,actions=[exp.Drop(this=column_to_alter.copy(),kind='COLUMN')]));self.execute(drop_sql);old_name_qualified=f"{table_name_without_catalog.sql(dialect=self.dialect)}.{temp_column_name.sql(dialect=self.dialect)}";new_name_unquoted=column_to_alter.sql(dialect=self.dialect,identify=_B);rename_sql=f"EXEC sp_rename '{old_name_qualified}', '{new_name_unquoted}', 'COLUMN'";self.execute(rename_sql)
					else:direct_alter_expr=exp.Alter(this=table_name_without_catalog.copy(),kind=A,actions=[action]);self.execute(direct_alter_expr)
class FabricHttpClient:
	def __init__(self,tenant_id:str,workspace_id:str,client_id:str,client_secret:str):self.tenant_id=tenant_id;self.client_id=client_id;self.client_secret=client_secret;self.workspace_id=workspace_id
	def create_warehouse(self,warehouse_name:str,if_not_exists:bool=_C,attempt:int=0)->_A:
		if attempt>10:raise VulcanError(f"Gave up waiting for Fabric warehouse {warehouse_name} to become available")
		logger.info(f"Creating Fabric warehouse: {warehouse_name}");request_data={_E:warehouse_name,'description':f"Warehouse created by Vulcan: {warehouse_name}"};response=self.session.post(self._endpoint_url(_F),json=request_data)
		if if_not_exists and response.status_code==400 and(errorCode:=response.json().get('errorCode',_A)):
			if errorCode=='ItemDisplayNameAlreadyInUse':logger.warning(f"Fabric warehouse {warehouse_name} already exists");return
			if errorCode=='ItemDisplayNameNotAvailableYet':logger.warning(f"Fabric warehouse {warehouse_name} is still spinning up; waiting");time.sleep(30);return self.create_warehouse(warehouse_name=warehouse_name,if_not_exists=if_not_exists,attempt=attempt+1)
		try:response.raise_for_status()
		except:logger.exception(f"Failed to create warehouse {warehouse_name}. status: {response.status_code}, body: {response.text}");raise
		if response.status_code==201:logger.info(f"Successfully created Fabric warehouse: {warehouse_name}");return
		if response.status_code==202 and(location_header:=response.headers.get('location')):logger.info(f"Warehouse creation initiated for: {warehouse_name}");self._wait_for_completion(location_header,warehouse_name);logger.info(f"Successfully created Fabric warehouse: {warehouse_name}")
		else:logger.error(f"Unexpected response from Fabric API: {response}\n{response.text}");raise VulcanError(f"Unable to create warehouse: {response}")
	def delete_warehouse(self,warehouse_name:str,if_exists:bool=_C)->_A:
		logger.info(f"Deleting Fabric warehouse: {warehouse_name}");response=self.session.get(self._endpoint_url(_F));response.raise_for_status();warehouse_name_to_id={warehouse.get(_E):warehouse.get('id')for warehouse in response.json().get('value',[])};warehouse_id=warehouse_name_to_id.get(warehouse_name,_A)
		if not warehouse_id:
			logger.warning(f"Fabric warehouse does not exist: {warehouse_name}\n(available warehouses: {', '.join(warehouse_name_to_id)})")
			if if_exists:return
			raise VulcanError(f"Unable to delete Fabric warehouse {warehouse_name} as it doesnt exist")
		response=self.session.delete(self._endpoint_url(f"warehouses/{warehouse_id}"));response.raise_for_status();logger.info(f"Successfully deleted Fabric warehouse: {warehouse_name}")
	@cached_property
	def session(self)->requests.Session:s=requests.Session();access_token=self._get_access_token();s.headers.update({'Authorization':f"Bearer {access_token}"});return s
	def _endpoint_url(self,endpoint:str)->str:
		if endpoint.startswith('/'):endpoint=endpoint[1:]
		return f"https://api.fabric.microsoft.com/v1/workspaces/{self.workspace_id}/{endpoint}"
	def _get_access_token(self)->str:token_url=f"https://login.microsoftonline.com/{self.tenant_id}/oauth2/v2.0/token";data={'grant_type':'client_credentials','client_id':self.client_id,'client_secret':self.client_secret,'scope':'https://api.fabric.microsoft.com/.default'};response=requests.post(token_url,data=data);response.raise_for_status();token_data=response.json();return token_data['access_token']
	def _wait_for_completion(self,location_url:str,operation_name:str)->_A:
		B='Failed';A='Succeeded'
		@retry(wait=wait_exponential(multiplier=1,min=1,max=30),stop=stop_after_attempt(20),retry=retry_if_result(lambda result:result not in[A,B]))
		def _poll()->str:
			response=self.session.get(location_url);response.raise_for_status();result=response.json();status=result.get('status','Unknown');logger.debug(f"Operation {operation_name} status: {status}")
			if status==B:error_msg=result.get('error',{}).get('message','Unknown error');raise VulcanError(f"Operation {operation_name} failed: {error_msg}")
			elif status in['InProgress','Running']:logger.debug(f"Operation {operation_name} still in progress...")
			elif status not in[A]:logger.warning(f"Unknown status '{status}' for operation {operation_name}")
			return status
		final_status=_poll()
		if final_status!=A:raise VulcanError(f"Operation {operation_name} completed with status: {final_status}")