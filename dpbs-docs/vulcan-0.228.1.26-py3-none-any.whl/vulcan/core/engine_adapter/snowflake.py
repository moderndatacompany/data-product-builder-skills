from __future__ import annotations
_O='TEMPORARY TABLE'
_N='properties'
_M='TARGET_LAG'
_L='MATERIALIZED VIEW'
_K='DYNAMIC TABLE'
_J='SCHEMA'
_I='snowflake'
_H='WAREHOUSE'
_G='VIEW'
_F='DATABASE'
_E='catalog'
_D='TABLE'
_C=False
_B=True
_A=None
import contextlib,json,logging,typing as t
from sqlglot import exp,parse_one
from sqlglot.helper import ensure_list
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.optimizer.qualify_columns import quote_identifiers
import vulcan.core.constants as c
from vulcan.core.dialect import to_schema
from vulcan.core.engine_adapter.mixins import GetCurrentCatalogFromFunctionMixin,ClusteredByMixin,RowDiffMixin,GrantsFromInfoSchemaMixin
from vulcan.core.engine_adapter.shared import CatalogSupport,DataObject,DataObjectType,SourceQuery,set_catalog
from vulcan.utils import optional_import,get_source_columns_to_types
from vulcan.utils.errors import VulcanError
from vulcan.utils.pandas import columns_to_types_from_dtypes
logger=logging.getLogger(__name__)
snowpark=optional_import('snowflake.snowpark')
def _is_ctas_sql(sql:str)->bool:
	try:expression=parse_one(sql,dialect=_I)
	except Exception:return _C
	return isinstance(expression,exp.Create)and expression.kind==_D and expression.expression is not _A
def _snowflake_rows_affected(cursor:t.Any,sql:str)->t.Optional[int]:
	stats_data=getattr(cursor,'_stats_data',_A)
	if stats_data is not _A:
		stats=getattr(cursor,'stats',_A)
		if stats is not _A:
			parts=[getattr(stats,'num_rows_inserted',_A),getattr(stats,'num_rows_deleted',_A),getattr(stats,'num_rows_updated',_A)];known=[p for p in parts if isinstance(p,int)and not isinstance(p,bool)and p>=0]
			if known:return sum(known)
		return
	if _is_ctas_sql(sql):return
	rowcount=getattr(cursor,'rowcount',_A)
	if rowcount is _A:return
	try:count=int(rowcount)
	except(TypeError,ValueError):return
	return count if count>=0 else _A
if t.TYPE_CHECKING:import pandas as pd;from vulcan.core._typing import SchemaName,SessionProperties,TableName;from vulcan.core.engine_adapter._typing import DF,Query,QueryOrDF,SnowparkSession;from vulcan.core.node import IntervalUnit
@set_catalog(override_mapping={'_get_data_objects':CatalogSupport.REQUIRES_SET_CATALOG,'create_schema':CatalogSupport.REQUIRES_SET_CATALOG,'drop_schema':CatalogSupport.REQUIRES_SET_CATALOG,'drop_catalog':CatalogSupport.REQUIRES_SET_CATALOG})
class SnowflakeEngineAdapter(GetCurrentCatalogFromFunctionMixin,ClusteredByMixin,RowDiffMixin,GrantsFromInfoSchemaMixin):
	DIALECT=_I;SUPPORTS_MATERIALIZED_VIEWS=_B;SUPPORTS_MATERIALIZED_VIEW_SCHEMA=_B;SUPPORTS_CLONING=_B;SUPPORTS_MANAGED_MODELS=_B;CURRENT_CATALOG_EXPRESSION=exp.func('current_database');SUPPORTS_CREATE_DROP_CATALOG=_B;SUPPORTS_METADATA_TABLE_LAST_MODIFIED_TS=_B;SUPPORTED_DROP_CASCADE_OBJECT_KINDS=[_F,_J,_D];SCHEMA_DIFFER_KWARGS={'parameterized_type_defaults':{exp.DataType.build('BINARY',dialect=DIALECT).this:[(8388608,)],exp.DataType.build('VARBINARY',dialect=DIALECT).this:[(8388608,)],exp.DataType.build('DECIMAL',dialect=DIALECT).this:[(38,0),(0,)],exp.DataType.build('CHAR',dialect=DIALECT).this:[(1,)],exp.DataType.build('NCHAR',dialect=DIALECT).this:[(1,)],exp.DataType.build('VARCHAR',dialect=DIALECT).this:[(16777216,)],exp.DataType.build('TIME',dialect=DIALECT).this:[(9,)],exp.DataType.build('TIMESTAMP',dialect=DIALECT).this:[(9,)],exp.DataType.build('TIMESTAMP_LTZ',dialect=DIALECT).this:[(9,)],exp.DataType.build('TIMESTAMP_NTZ',dialect=DIALECT).this:[(9,)],exp.DataType.build('TIMESTAMP_TZ',dialect=DIALECT).this:[(9,)]}};MANAGED_TABLE_KIND=_K;SNOWPARK='snowpark';QUERY_TAG_STAMP='_stamp_query_tag';SUPPORTS_QUERY_EXECUTION_TRACKING=_B;SUPPORTS_GRANTS=_B;CURRENT_USER_OR_ROLE_EXPRESSION:exp.Expression=exp.func('CURRENT_ROLE');USE_CATALOG_IN_GRANTS=_B
	@contextlib.contextmanager
	def session(self,properties:SessionProperties)->t.Iterator[_A]:
		warehouse=properties.get('warehouse')
		if not warehouse:yield;return
		if isinstance(warehouse,str):warehouse=exp.to_identifier(warehouse)
		if not isinstance(warehouse,exp.Expression):raise VulcanError(f"Invalid warehouse: '{warehouse}'")
		warehouse_exp=quote_identifiers(normalize_identifiers(warehouse,dialect=self.dialect),dialect=self.dialect);warehouse_sql=warehouse_exp.sql(dialect=self.dialect);current_warehouse_sql=self._current_warehouse.sql(dialect=self.dialect)
		if warehouse_sql==current_warehouse_sql:yield;return
		self.execute(f"USE WAREHOUSE {warehouse_sql}")
		try:yield
		finally:self.execute(f"USE WAREHOUSE {current_warehouse_sql}")
	@property
	def _current_warehouse(self)->exp.Identifier:current_warehouse_str=self.fetchone('SELECT CURRENT_WAREHOUSE()')[0];return quote_identifiers(exp.to_identifier(current_warehouse_str),dialect=self.dialect)
	@property
	def snowpark(self)->t.Optional[SnowparkSession]:
		if snowpark:
			if not self._connection_pool.get_attribute(self.SNOWPARK):new_session=snowpark.Session.builder.configs({'connection':self._connection_pool.get()}).create();self._connection_pool.set_attribute(self.SNOWPARK,new_session)
			return self._connection_pool.get_attribute(self.SNOWPARK)
	@property
	def catalog_support(self)->CatalogSupport:return CatalogSupport.FULL_SUPPORT
	@staticmethod
	def _grant_object_kind(table_type:DataObjectType)->str:
		if table_type==DataObjectType.VIEW:return _G
		if table_type==DataObjectType.MATERIALIZED_VIEW:return _L
		if table_type==DataObjectType.MANAGED_TABLE:return _K
		return _D
	def _get_current_schema(self)->str:
		result=self.fetchone('SELECT CURRENT_SCHEMA()')
		if not result or not result[0]:raise VulcanError('Unable to determine current schema')
		return str(result[0])
	def _create_catalog(self,catalog_name:exp.Identifier)->_A:props=exp.Properties(expressions=[exp.SchemaCommentProperty(this=exp.Literal.string(c.SQLMESH_MANAGED))]);self.execute(exp.Create(this=exp.Table(this=catalog_name),kind=_F,exists=_B,properties=props))
	def _drop_catalog(self,catalog_name:exp.Identifier)->_A:
		exists_check=exp.select(exp.Literal.number(1)).from_(exp.to_table('information_schema.databases')).where(exp.and_(exp.column('database_name').eq(exp.Literal.string(catalog_name)),exp.column('comment').eq(exp.Literal.string(c.SQLMESH_MANAGED))));normalize_identifiers(exists_check,dialect=self.dialect)
		if self.fetchone(exists_check,quote_identifiers=_B)is not _A:self.execute(exp.Drop(this=exp.Table(this=catalog_name),kind=_F,exists=_B))
		else:logger.warning(f"Not dropping database {catalog_name.sql(dialect=self.dialect)} because there is no indication it is '{c.SQLMESH_MANAGED}'")
	def _create_table(self,table_name_or_schema:t.Union[exp.Schema,TableName],expression:t.Optional[exp.Expression],exists:bool=_B,replace:bool=_C,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,table_kind:t.Optional[str]=_A,track_rows_processed:bool=_B,**kwargs:t.Any)->_A:
		table_format=kwargs.get('table_format')
		if table_format and isinstance(table_format,str):
			table_format=table_format.upper()
			if not table_kind:table_kind=f"{table_format} TABLE"
			elif table_kind==self.MANAGED_TABLE_KIND:table_kind=f"DYNAMIC {table_format} TABLE"
		super()._create_table(table_name_or_schema=table_name_or_schema,expression=expression,exists=exists,replace=replace,target_columns_to_types=target_columns_to_types,table_description=table_description,column_descriptions=column_descriptions,table_kind=table_kind,track_rows_processed=track_rows_processed,**kwargs)
	def _may_be_run_query_tag(self)->_A:
		if not self._user_agent and not self.correlation_id:return
		query_tag:t.Dict[str,str]={}
		if self._user_agent:query_tag['user_agent']=self._user_agent
		if self.correlation_id:query_tag['correlation_type']=self.correlation_id.job_type.value;query_tag['correlation_id']=self.correlation_id.job_id;query_tag['principal']=self.correlation_id.principal
		conn=self.connection;conn_id=id(conn);query_tag_json=json.dumps(query_tag,separators=(',',':'));stamp_value=f"{conn_id}:{query_tag_json}"
		if self._connection_pool.get_attribute(self.QUERY_TAG_STAMP)!=stamp_value:self.cursor.execute(f"ALTER SESSION SET QUERY_TAG = $${query_tag_json}$$");self._connection_pool.set_attribute(self.QUERY_TAG_STAMP,stamp_value)
	def _execute(self,sql:str,track_rows_processed:bool=_C,params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any],_A]=_A,**kwargs:t.Any)->_A:
		self._may_be_run_query_tag()
		if params is not _A:
			from vulcan.core.engine_adapter._parameter_utils import normalize_query_params;out_style=self._dbapi_paramstyle()or'format'
			if not isinstance(params,dict):out_style='qmark'
			sql,params=normalize_query_params(sql,params,output_style=out_style);self.cursor.execute(sql,params,**kwargs)
		else:self.cursor.execute(sql,**kwargs)
		if self.SUPPORTS_QUERY_EXECUTION_TRACKING and track_rows_processed and self._query_execution_tracker and self._query_execution_tracker.is_tracking():
			if(rows:=_snowflake_rows_affected(self.cursor,sql))is not _A:self._record_execution_stats(sql,rows)
	def create_managed_table(self,table_name:TableName,query:Query,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,clustered_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:
		target_table=exp.to_table(table_name);table_properties={k.upper():v for(k,v)in(table_properties or{}).items()}
		if _H not in table_properties:table_properties[_H]=self._current_warehouse
		if _M not in table_properties:raise VulcanError('`target_lag` must be specified in the model physical_properties for a Snowflake Dynamic Table')
		source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query,target_columns_to_types,target_table=target_table,source_columns=source_columns);self._create_table_from_source_queries(target_table,source_queries,target_columns_to_types,replace=self.SUPPORTS_REPLACE_TABLE,partitioned_by=partitioned_by,clustered_by=clustered_by,table_properties=table_properties,table_description=table_description,column_descriptions=column_descriptions,table_kind=self.MANAGED_TABLE_KIND,**kwargs)
	def create_view(self,view_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,replace:bool=_B,materialized:bool=_C,materialized_properties:t.Optional[t.Dict[str,t.Any]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,view_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,source_columns:t.Optional[t.List[str]]=_A,**create_kwargs:t.Any)->_A:
		properties=create_kwargs.pop(_N,_A)
		if not properties:properties=exp.Properties(expressions=[])
		if replace:properties.append('expressions',exp.CopyGrantsProperty())
		super().create_view(view_name=view_name,query_or_df=query_or_df,target_columns_to_types=target_columns_to_types,replace=replace,materialized=materialized,materialized_properties=materialized_properties,table_description=table_description,column_descriptions=column_descriptions,view_properties=view_properties,properties=properties,source_columns=source_columns,**create_kwargs)
	def drop_managed_table(self,table_name:TableName,exists:bool=_B)->_A:self._drop_object(table_name,exists,kind=self.MANAGED_TABLE_KIND)
	def _build_table_properties_exp(self,catalog_name:t.Optional[str]=_A,table_format:t.Optional[str]=_A,storage_format:t.Optional[str]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,partition_interval_unit:t.Optional[IntervalUnit]=_A,clustered_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties:t.List[exp.Expression]=[]
		if table_description:properties.append(exp.SchemaCommentProperty(this=exp.Literal.string(self._truncate_table_comment(table_description))))
		if clustered_by and(clustered_by_prop:=self._build_clustered_by_exp(clustered_by))is not _A:properties.append(clustered_by_prop)
		if table_properties:
			table_properties={k.upper():v for(k,v)in table_properties.items()}
			if'DYNAMIC'not in(table_kind or'').upper():
				for prop in{_H,_M,'REFRESH_MODE','INITIALIZE'}:table_properties.pop(prop,_A)
			table_type=self._pop_creatable_type_from_properties(table_properties);properties.extend(ensure_list(table_type));properties.extend(self._table_or_view_properties_to_expressions(table_properties))
		return exp.Properties(expressions=properties)if properties else _A
	def _df_to_source_queries(self,df:DF,target_columns_to_types:t.Dict[str,exp.DataType],batch_size:int,target_table:TableName,source_columns:t.Optional[t.List[str]]=_A)->t.List[SourceQuery]:
		import pandas as pd;from pandas.api.types import is_datetime64_any_dtype;source_columns_to_types=get_source_columns_to_types(target_columns_to_types,source_columns);temp_table=self._get_temp_table(target_table or'pandas',quoted=_C);is_snowpark_dataframe=snowpark and isinstance(df,snowpark.dataframe.DataFrame)
		def query_factory()->Query:
			database=normalize_identifiers(temp_table.catalog,dialect=self.dialect)if temp_table.catalog else _A
			if is_snowpark_dataframe:
				temp_table.set(_E,database);columns_already_quoted=all(col.startswith('"')and col.endswith('"')for col in df.columns);local_df=df
				if not columns_already_quoted:local_df=df.rename({col:exp.to_identifier(col).sql(dialect=self.dialect,identify=_B)for col in source_columns_to_types})
				local_df.createOrReplaceTempView(temp_table.sql(dialect=self.dialect,identify=_B))
			elif isinstance(df,pd.DataFrame):
				from snowflake.connector.pandas_tools import write_pandas;ordered_df=df[list(source_columns_to_types)];schema=temp_table.db
				if temp_table.catalog:schema=f"{temp_table.catalog}.{schema}"
				self.set_current_schema(schema)
				for(column,kind)in source_columns_to_types.items():
					if is_datetime64_any_dtype(ordered_df.dtypes[column]):
						if kind.is_type('date'):ordered_df[column]=pd.to_datetime(ordered_df[column]).dt.date
						elif getattr(ordered_df.dtypes[column],'tz',_A)is not _A:ordered_df[column]=pd.to_datetime(ordered_df[column]).dt.strftime('%Y-%m-%d %H:%M:%S.%f%z')
						else:ordered_df[column]=pd.to_datetime(ordered_df[column]).dt.strftime('%Y-%m-%d %H:%M:%S.%f')
				self.create_table(temp_table,source_columns_to_types,table_kind=_O);write_pandas(self._connection_pool.get(),ordered_df,temp_table.name,schema=temp_table.db or _A,database=database.sql(dialect=self.dialect)if database else _A,chunk_size=self.DEFAULT_BATCH_SIZE,overwrite=_B,table_type='temp')
			else:raise VulcanError(f"Unknown dataframe type: {type(df)} for {target_table}. Expecting pandas or snowpark.")
			return exp.select(*self._casted_columns(target_columns_to_types,source_columns=source_columns)).from_(temp_table)
		def cleanup()->_A:
			if is_snowpark_dataframe:
				if hasattr(df,'table_name'):
					if isinstance(df.table_name,str):self.drop_table(df.table_name)
				self.drop_view(temp_table)
			else:self.drop_table(temp_table)
		return[SourceQuery(query_factory=query_factory,cleanup_func=cleanup)]
	def _fetch_native_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_C)->DF:
		import pandas as pd;from snowflake.connector.errors import NotSupportedError;self.execute(query,quote_identifiers=quote_identifiers)
		try:return self.cursor.fetch_pandas_all()
		except NotSupportedError:rows=self.cursor.fetchall();columns=self.cursor._result_set.batches[0].column_names;return pd.DataFrame([dict(zip(columns,row))for row in rows])
	def _fetch_native_df_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_C)->DF:
		import pandas as pd;from snowflake.connector.errors import NotSupportedError;self.execute(query,params=params,quote_identifiers=quote_identifiers)
		try:return self.cursor.fetch_pandas_all()
		except NotSupportedError:rows=self.cursor.fetchall();columns=self.cursor._result_set.batches[0].column_names;return pd.DataFrame([dict(zip(columns,row))for row in rows])
	def _native_df_to_pandas_df(self,query_or_df:QueryOrDF)->t.Union[Query,pd.DataFrame]:
		if snowpark and isinstance(query_or_df,snowpark.DataFrame):return query_or_df.to_pandas()
		return super()._native_df_to_pandas_df(query_or_df)
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		D='BASE TABLE';C='TABLE_SCHEMA';B='TABLE_NAME';A='TABLE_TYPE';schema=to_schema(schema_name);catalog_name=schema.catalog or self.get_current_catalog();query=exp.select(exp.column('TABLE_CATALOG').as_(_E),exp.column(B).as_('name'),exp.column(C).as_('schema_name'),exp.case().when(exp.And(this=exp.column(A).eq(D),expression=exp.column('IS_DYNAMIC').eq('YES')),exp.Literal.string('MANAGED_TABLE')).when(exp.column(A).eq(D),exp.Literal.string(_D)).when(exp.column(A).eq(_O),exp.Literal.string(_D)).when(exp.column(A).eq('LOCAL TEMPORARY'),exp.Literal.string(_D)).when(exp.column(A).eq('EXTERNAL TABLE'),exp.Literal.string(_D)).when(exp.column(A).eq('EVENT TABLE'),exp.Literal.string(_D)).when(exp.column(A).eq(_G),exp.Literal.string(_G)).when(exp.column(A).eq(_L),exp.Literal.string('MATERIALIZED_VIEW')).else_(exp.column(A)).as_('type'),exp.column('CLUSTERING_KEY').as_('clustering_key')).from_(exp.table_('TABLES',db='INFORMATION_SCHEMA',catalog=catalog_name)).where(exp.column(C).eq(schema.db)).distinct()
		if object_names:query=query.where(exp.column(B).isin(*object_names))
		query=query.where(exp.column(B).like('SNOWPARK_TEMP_TABLE%').not_());df=self.fetchdf(query,quote_identifiers=_B)
		if df.empty:return[]
		return[DataObject(catalog=row.catalog,schema=row.schema_name,name=row.name,type=DataObjectType.from_str(row.type),clustering_key=row.clustering_key)for row in df.rename(columns={col:col.lower()for col in df.columns}).itertuples()]
	def _get_grant_expression(self,table:exp.Table)->exp.Expression:
		A='placeholder';expression=super()._get_grant_expression(table)
		for col_exp in expression.find_all(exp.Column):
			if col_exp.this.name=='table_catalog':and_exp=col_exp.parent;assert and_exp is not _A,'Expected column expression to have a parent';assert and_exp.expression,'Expected AND expression to have an expression';normalized_catalog=self._normalize_catalog(exp.table_(A,db=A,catalog=and_exp.expression.this));and_exp.set('expression',exp.Literal.string(normalized_catalog.args[_E].alias_or_name))
		return expression
	def set_current_catalog(self,catalog:str)->_A:self.execute(exp.Use(this=exp.to_identifier(catalog)))
	def set_current_schema(self,schema:str)->_A:self.execute(exp.Use(kind=_J,this=to_schema(schema)))
	def _normalize_catalog(self,expression:exp.Expression)->exp.Expression:
		if self._default_catalog:
			def unquote_and_lower(identifier:str)->str:return exp.parse_identifier(identifier).name.lower()
			default_catalog_unquoted=unquote_and_lower(self._default_catalog);default_catalog_normalized=normalize_identifiers(self._default_catalog,dialect=self.dialect)
			def catalog_rewriter(node:exp.Expression)->exp.Expression:
				if isinstance(node,exp.Table):
					if node.catalog:
						if unquote_and_lower(node.catalog)==default_catalog_unquoted:node.set(_E,default_catalog_normalized)
				elif isinstance(node,exp.Use)and isinstance(node.this,exp.Identifier):
					if unquote_and_lower(node.this.output_name)==default_catalog_unquoted:node.set('this',default_catalog_normalized)
				return node
			expression=expression.transform(catalog_rewriter)
		return expression
	def _to_sql(self,expression:exp.Expression,quote:bool=_B,**kwargs:t.Any)->str:return super()._to_sql(expression=self._normalize_catalog(expression),quote=quote,**kwargs)
	def _create_column_comments(self,table_name:TableName,column_comments:t.Dict[str,str],table_kind:str=_D,materialized_view:bool=_C)->_A:
		if not column_comments:return
		table=exp.to_table(table_name);table_sql=self._to_sql(table);list_comment_sql=[]
		for(column_name,column_comment)in column_comments.items():column_sql=exp.column(column_name).sql(dialect=self.dialect,identify=_B);truncated_comment=self._truncate_column_comment(column_comment);comment_sql=exp.Literal.string(truncated_comment).sql(dialect=self.dialect);list_comment_sql.append(f"COLUMN {column_sql} COMMENT {comment_sql}")
		combined_sql=f"ALTER {table_kind} {table_sql} ALTER {', '.join(list_comment_sql)}"
		try:self.execute(combined_sql)
		except Exception:logger.warning(f"Column comments for table '{table.alias_or_name}' not registered - this may be due to limited permissions.",exc_info=_B)
	def clone_table(self,target_table_name:TableName,source_table_name:TableName,replace:bool=_C,exists:bool=_B,clone_kwargs:t.Optional[t.Dict[str,t.Any]]=_A,**kwargs:t.Any)->_A:
		if(physical_properties:=kwargs.get('rendered_physical_properties')):
			table_type=self._pop_creatable_type_from_properties(physical_properties)
			if isinstance(table_type,exp.TransientProperty):kwargs[_N]=exp.Properties(expressions=[table_type])
		super().clone_table(target_table_name,source_table_name,replace=replace,clone_kwargs=clone_kwargs,**kwargs)
	@t.overload
	def _columns_to_types(self,query_or_df:DF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A)->t.Tuple[t.Dict[str,exp.DataType],t.List[str]]:...
	@t.overload
	def _columns_to_types(self,query_or_df:Query,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A)->t.Tuple[t.Optional[t.Dict[str,exp.DataType]],t.Optional[t.List[str]]]:...
	def _columns_to_types(self,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A)->t.Tuple[t.Optional[t.Dict[str,exp.DataType]],t.Optional[t.List[str]]]:
		if not target_columns_to_types and snowpark and isinstance(query_or_df,snowpark.DataFrame):target_columns_to_types=columns_to_types_from_dtypes(query_or_df.sample(n=1).to_pandas().dtypes.items());return target_columns_to_types,list(source_columns or target_columns_to_types)
		return super()._columns_to_types(query_or_df,target_columns_to_types,source_columns=source_columns)
	def close(self)->t.Any:
		if(snowpark_session:=self._connection_pool.get_attribute(self.SNOWPARK)):snowpark_session.close();self._connection_pool.set_attribute(self.SNOWPARK,_A)
		return super().close()
	def get_table_last_modified_ts(self,table_names:t.List[TableName])->t.List[int]:
		from vulcan.utils.date import to_timestamp;num_tables=len(table_names);query='SELECT LAST_ALTERED FROM INFORMATION_SCHEMA.TABLES WHERE'
		for(i,table_name)in enumerate(table_names):
			table=exp.to_table(table_name);query+=f"(TABLE_NAME = '{table.name}' AND TABLE_SCHEMA = '{table.db}' AND TABLE_CATALOG = '{table.catalog}')"
			if i<num_tables-1:query+=' OR '
		result=self.fetchall(query);return[to_timestamp(row[0])for row in result]