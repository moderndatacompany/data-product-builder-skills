from __future__ import annotations
_J='mssql_merge_exists'
_I='nvarchar'
_H='varchar'
_G='varbinary'
_F='NVARCHAR'
_E='VARCHAR'
_D='VARBINARY'
_C=True
_B=False
_A=None
import typing as t,logging
from sqlglot import exp
from vulcan.core.dialect import to_schema,add_table
from vulcan.core.engine_adapter.base import EngineAdapterWithIndexSupport,EngineAdapter,InsertOverwriteStrategy,MERGE_SOURCE_ALIAS,MERGE_TARGET_ALIAS,_get_data_object_cache_key
from vulcan.core.engine_adapter.mixins import GetCurrentCatalogFromFunctionMixin,PandasNativeFetchDFSupportMixin,VarcharSizeWorkaroundMixin,RowDiffMixin
from vulcan.core.engine_adapter.shared import CatalogSupport,CommentCreationTable,CommentCreationView,DataObject,DataObjectType,SourceQuery,set_catalog
from vulcan.utils import get_source_columns_to_types
if t.TYPE_CHECKING:from vulcan.core._typing import SchemaName,TableName;from vulcan.core.engine_adapter._typing import DF,Query,QueryOrDF
logger=logging.getLogger(__name__)
@set_catalog()
class MSSQLEngineAdapter(EngineAdapterWithIndexSupport,PandasNativeFetchDFSupportMixin,GetCurrentCatalogFromFunctionMixin,VarcharSizeWorkaroundMixin,RowDiffMixin):
	DIALECT:str='tsql';SUPPORTS_TUPLE_IN=_B;SUPPORTS_MATERIALIZED_VIEWS=_B;CURRENT_CATALOG_EXPRESSION=exp.func('db_name');COMMENT_CREATION_TABLE=CommentCreationTable.UNSUPPORTED;COMMENT_CREATION_VIEW=CommentCreationView.UNSUPPORTED;SUPPORTS_REPLACE_TABLE=_B;MAX_IDENTIFIER_LENGTH=128;SUPPORTS_QUERY_EXECUTION_TRACKING=_C;SCHEMA_DIFFER_KWARGS={'parameterized_type_defaults':{exp.DataType.build('DECIMAL',dialect=DIALECT).this:[(18,0),(0,)],exp.DataType.build('BINARY',dialect=DIALECT).this:[(1,)],exp.DataType.build(_D,dialect=DIALECT).this:[(1,)],exp.DataType.build('CHAR',dialect=DIALECT).this:[(1,)],exp.DataType.build(_E,dialect=DIALECT).this:[(1,)],exp.DataType.build('NCHAR',dialect=DIALECT).this:[(1,)],exp.DataType.build(_F,dialect=DIALECT).this:[(1,)],exp.DataType.build('TIME',dialect=DIALECT).this:[(7,)],exp.DataType.build('DATETIME2',dialect=DIALECT).this:[(7,)],exp.DataType.build('DATETIMEOFFSET',dialect=DIALECT).this:[(7,)]},'max_parameter_length':{exp.DataType.build(_D,dialect=DIALECT).this:2147483647,exp.DataType.build(_E,dialect=DIALECT).this:2147483647,exp.DataType.build(_F,dialect=DIALECT).this:2147483647}};VARIABLE_LENGTH_DATA_TYPES={'binary',_G,'char',_H,'nchar',_I};INSERT_OVERWRITE_STRATEGY=InsertOverwriteStrategy.MERGE
	@property
	def catalog_support(self)->CatalogSupport:return self._extra_config['catalog_support']
	def columns(self,table_name:TableName,include_pseudo_columns:bool=_C)->t.Dict[str,exp.DataType]:
		table=exp.to_table(table_name);sql=exp.select('COLUMN_NAME','DATA_TYPE','CHARACTER_MAXIMUM_LENGTH','NUMERIC_PRECISION','NUMERIC_SCALE').from_('INFORMATION_SCHEMA.COLUMNS').where(f"TABLE_NAME = '{table.name}'");database_name=table.db
		if database_name:sql=sql.where(f"TABLE_SCHEMA = '{database_name}'")
		columns_raw=self.fetchall(sql,quote_identifiers=_C)
		def build_var_length_col(column_name:str,data_type:str,character_maximum_length:t.Optional[int]=_A,numeric_precision:t.Optional[int]=_A,numeric_scale:t.Optional[int]=_A)->tuple:
			data_type=data_type.lower()
			if data_type in self.VARIABLE_LENGTH_DATA_TYPES and character_maximum_length is not _A and character_maximum_length>0:return column_name,f"{data_type}({character_maximum_length})"
			if data_type in(_G,_H,_I)and character_maximum_length is not _A and character_maximum_length==-1:return column_name,f"{data_type}(max)"
			if data_type in('decimal','numeric'):return column_name,f"{data_type}({numeric_precision}, {numeric_scale})"
			if data_type=='float':return column_name,f"{data_type}({numeric_precision})"
			return column_name,data_type
		columns=[build_var_length_col(*row)for row in columns_raw];return{column_name:exp.DataType.build(data_type,dialect=self.dialect)for(column_name,data_type)in columns}
	def table_exists(self,table_name:TableName)->bool:
		table=exp.to_table(table_name);data_object_cache_key=_get_data_object_cache_key(table.catalog,table.db,table.name)
		if data_object_cache_key in self._data_object_cache:logger.debug('Table existence cache hit: %s',data_object_cache_key);return self._data_object_cache[data_object_cache_key]is not _A
		sql=exp.select('1').from_('INFORMATION_SCHEMA.TABLES').where(f"TABLE_NAME = '{table.alias_or_name}'");database_name=table.db
		if database_name:sql=sql.where(f"TABLE_SCHEMA = '{database_name}'")
		result=self.fetchone(sql,quote_identifiers=_C);return result[0]==1 if result else _B
	def set_current_catalog(self,catalog_name:str)->_A:self.execute(exp.Use(this=exp.to_identifier(catalog_name)))
	def drop_schema(self,schema_name:SchemaName,ignore_if_not_exists:bool=_C,cascade:bool=_B,**drop_args:t.Dict[str,exp.Expression])->_A:
		if cascade:
			objects=self._get_data_objects(schema_name)
			for obj in objects:
				object_table=exp.table_(obj.name,obj.schema_name)
				if obj.type==DataObjectType.VIEW:self.drop_view(object_table,ignore_if_not_exists=ignore_if_not_exists)
				else:self.drop_table(object_table,exists=ignore_if_not_exists)
		super().drop_schema(schema_name,ignore_if_not_exists=ignore_if_not_exists,cascade=_B)
	def merge(self,target_table:TableName,source_table:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],unique_key:t.Sequence[exp.Expression],when_matched:t.Optional[exp.Whens]=_A,merge_filter:t.Optional[exp.Expression]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:
		mssql_merge_exists=kwargs.get('physical_properties',{}).get(_J);source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(source_table,target_columns_to_types,target_table=target_table,source_columns=source_columns);target_columns_to_types=target_columns_to_types or self.columns(target_table);on=exp.and_(*(add_table(part,MERGE_TARGET_ALIAS).eq(add_table(part,MERGE_SOURCE_ALIAS))for part in unique_key))
		if merge_filter:on=exp.and_(merge_filter,on)
		match_expressions=[]
		if not when_matched:
			unique_key_names=[y.name for y in unique_key];columns_to_types_no_keys=[c for c in target_columns_to_types if c not in unique_key_names];target_columns_no_keys=[exp.column(c,MERGE_TARGET_ALIAS)for c in columns_to_types_no_keys];source_columns_no_keys=[exp.column(c,MERGE_SOURCE_ALIAS)for c in columns_to_types_no_keys];match_condition=exp.Exists(this=exp.select(*target_columns_no_keys).except_(exp.select(*source_columns_no_keys)))if mssql_merge_exists else _A
			if target_columns_no_keys:match_expressions.append(exp.When(matched=_C,source=_B,condition=match_condition,then=exp.Update(expressions=[exp.column(col,MERGE_TARGET_ALIAS).eq(exp.column(col,MERGE_SOURCE_ALIAS))for col in columns_to_types_no_keys])))
		else:match_expressions.extend(when_matched.copy().expressions)
		match_expressions.append(exp.When(matched=_B,source=_B,then=exp.Insert(this=exp.Tuple(expressions=[exp.column(col)for col in target_columns_to_types]),expression=exp.Tuple(expressions=[exp.column(col,MERGE_SOURCE_ALIAS)for col in target_columns_to_types]))))
		for source_query in source_queries:
			with source_query as query:self._merge(target_table=target_table,query=query,on=on,whens=exp.Whens(expressions=match_expressions))
	def _convert_df_datetime(self,df:DF,columns_to_types:t.Dict[str,exp.DataType])->_A:
		import pandas as pd;from pandas.api.types import is_datetime64_any_dtype
		for(column,kind)in columns_to_types.items():
			if kind.is_type('date'):df[column]=pd.to_datetime(df[column]).dt.strftime('%Y-%m-%d')
			elif is_datetime64_any_dtype(df.dtypes[column]):
				if getattr(df.dtypes[column],'tz',_A)is not _A:df[column]=pd.to_datetime(df[column]).map(lambda x:x.isoformat(' '));columns_to_types[column]=exp.DataType.build('TEXT')
				else:df[column]=pd.to_datetime(df[column]).dt.strftime('%Y-%m-%d %H:%M:%S.%f')
	def _df_to_source_queries(self,df:DF,target_columns_to_types:t.Dict[str,exp.DataType],batch_size:int,target_table:TableName,source_columns:t.Optional[t.List[str]]=_A)->t.List[SourceQuery]:
		import pandas as pd,numpy as np;assert isinstance(df,pd.DataFrame);temp_table=self._get_temp_table(target_table or'pandas')
		if not hasattr(self._connection_pool.get(),'bulk_copy'):return super()._df_to_source_queries(df,target_columns_to_types,batch_size,target_table,source_columns=source_columns)
		def query_factory()->Query:
			if not self.table_exists(temp_table):source_columns_to_types=get_source_columns_to_types(target_columns_to_types,source_columns);ordered_df=df[list(source_columns_to_types)];self._convert_df_datetime(ordered_df,source_columns_to_types);self.create_table(temp_table,source_columns_to_types);rows:t.List[t.Tuple[t.Any,...]]=list(ordered_df.replace({np.nan:_A}).itertuples(index=_B,name=_A));conn=self._connection_pool.get();conn.bulk_copy(temp_table.sql(dialect=self.dialect),rows)
			return exp.select(*self._casted_columns(target_columns_to_types,source_columns=source_columns)).from_(temp_table)
		return[SourceQuery(query_factory=query_factory,cleanup_func=lambda:self.drop_table(temp_table))]
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		C='TABLE_TYPE';B='TABLE_SCHEMA';A='TABLE_NAME';import pandas as pd;catalog=self.get_current_catalog();query=exp.select(exp.column(A).as_('name'),exp.column(B).as_('schema_name'),exp.case().when(exp.column(C).eq('BASE TABLE'),exp.Literal.string('TABLE')).else_(exp.column(C)).as_('type')).from_(exp.table_('TABLES',db='INFORMATION_SCHEMA')).where(exp.column(B).eq(to_schema(schema_name).db))
		if object_names:query=query.where(exp.column(A).isin(*object_names))
		dataframe:pd.DataFrame=self.fetchdf(query);return[DataObject(catalog=catalog,schema=row.schema_name,name=row.name,type=DataObjectType.from_str(row.type))for row in dataframe.itertuples()]
	def _to_sql(self,expression:exp.Expression,quote:bool=_C,**kwargs:t.Any)->str:sql=super()._to_sql(expression,quote=quote,**kwargs);return f"{sql};"
	def _rename_table(self,old_table_name:TableName,new_table_name:TableName)->_A:self.execute(exp.rename_table(old_table_name,new_table_name),quote_identifiers=_B)
	def _insert_overwrite_by_condition(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,where:t.Optional[exp.Condition]=_A,insert_overwrite_strategy_override:t.Optional[InsertOverwriteStrategy]=_A,**kwargs:t.Any)->_A:
		use_merge_strategy=kwargs.get('table_properties',{}).get(_J)
		if(not where or where==exp.true())and not use_merge_strategy:return EngineAdapter._insert_overwrite_by_condition(self,table_name=table_name,source_queries=source_queries,target_columns_to_types=target_columns_to_types,where=where,insert_overwrite_strategy_override=InsertOverwriteStrategy.DELETE_INSERT,**kwargs)
		return super()._insert_overwrite_by_condition(table_name=table_name,source_queries=source_queries,target_columns_to_types=target_columns_to_types,where=where,insert_overwrite_strategy_override=insert_overwrite_strategy_override,**kwargs)
	def delete_from(self,table_name:TableName,where:t.Union[str,exp.Expression])->_A:
		if where==exp.true():return self.execute(exp.TruncateTable(expressions=[exp.to_table(table_name,dialect=self.dialect)]))
		return super().delete_from(table_name,where)
	def _fetch_native_df_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_B)->DF:return super()._fetch_native_df_with_params(query,params,quote_identifiers)