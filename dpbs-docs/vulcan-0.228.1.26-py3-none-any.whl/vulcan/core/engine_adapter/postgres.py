from __future__ import annotations
_F='VARCHAR'
_E='CHAR'
_D=False
_C='BPCHAR'
_B=None
_A=True
import logging,re,typing as t
from functools import cached_property,partial
from sqlglot import exp
from vulcan.core.engine_adapter.base_postgres import BasePostgresEngineAdapter
from vulcan.core.engine_adapter.mixins import GetCurrentCatalogFromFunctionMixin,PandasNativeFetchDFSupportMixin,RowDiffMixin,logical_merge,GrantsFromInfoSchemaMixin
from vulcan.core.engine_adapter.shared import set_catalog
if t.TYPE_CHECKING:from vulcan.core._typing import TableName;from vulcan.core.engine_adapter._typing import DF,QueryOrDF
logger=logging.getLogger(__name__)
@set_catalog()
class PostgresEngineAdapter(BasePostgresEngineAdapter,PandasNativeFetchDFSupportMixin,GetCurrentCatalogFromFunctionMixin,RowDiffMixin,GrantsFromInfoSchemaMixin):
	DIALECT='postgres';SUPPORTS_GRANTS=_A;SUPPORTS_INDEXES=_A;HAS_VIEW_BINDING=_A;CURRENT_CATALOG_EXPRESSION=exp.column('current_catalog');SUPPORTS_REPLACE_TABLE=_D;MAX_IDENTIFIER_LENGTH:t.Optional[int]=63;SUPPORTS_QUERY_EXECUTION_TRACKING=_A;GRANT_INFORMATION_SCHEMA_TABLE_NAME='role_table_grants';CURRENT_USER_OR_ROLE_EXPRESSION:exp.Expression=exp.column('current_role');SUPPORTS_MULTIPLE_GRANT_PRINCIPALS=_A;SCHEMA_DIFFER_KWARGS={'parameterized_type_defaults':{exp.DataType.build('DECIMAL',dialect=DIALECT).this:[(147455,16383),(0,)],exp.DataType.build(_E,dialect=DIALECT).this:[(1,)],exp.DataType.build('TIME',dialect=DIALECT).this:[(6,)],exp.DataType.build('TIMESTAMP',dialect=DIALECT).this:[(6,)]},'types_with_unlimited_length':{exp.DataType.build('TEXT',dialect=DIALECT).this:{exp.DataType.build(_F,dialect=DIALECT).this,exp.DataType.build(_E,dialect=DIALECT).this,exp.DataType.build(_C,dialect=DIALECT).this},exp.DataType.build(_F,dialect=DIALECT).this:{exp.DataType.build(_F,dialect=DIALECT).this,exp.DataType.build(_E,dialect=DIALECT).this,exp.DataType.build(_C,dialect=DIALECT).this,exp.DataType.build('TEXT',dialect=DIALECT).this},exp.DataType.build(_C,dialect=DIALECT).this:{exp.DataType.build(_C,dialect=DIALECT).this}},'drop_cascade':_A}
	def _fetch_native_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_D)->DF:
		df=super()._fetch_native_df(query,quote_identifiers)
		if not self._connection_pool.is_transaction_active:self._connection_pool.commit()
		return df
	def _fetch_native_df_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_D)->DF:
		df=super()._fetch_native_df_with_params(query,params,quote_identifiers=quote_identifiers)
		if not self._connection_pool.is_transaction_active:self._connection_pool.commit()
		return df
	def _create_table_like(self,target_table_name:TableName,source_table_name:TableName,exists:bool,**kwargs:t.Any)->_B:self.execute(exp.Create(this=exp.Schema(this=exp.to_table(target_table_name),expressions=[exp.LikeProperty(this=exp.to_table(source_table_name),expressions=[exp.Property(this='INCLUDING',value=exp.Var(this='ALL'))])]),kind='TABLE',exists=exists))
	def merge(self,target_table:TableName,source_table:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],unique_key:t.Sequence[exp.Expression],when_matched:t.Optional[exp.Whens]=_B,merge_filter:t.Optional[exp.Expression]=_B,source_columns:t.Optional[t.List[str]]=_B,**kwargs:t.Any)->_B:major,minor=self.server_version;merge_impl=super().merge if major>=15 else partial(logical_merge,self);merge_impl(target_table,source_table,target_columns_to_types,unique_key,when_matched=when_matched,merge_filter=merge_filter,source_columns=source_columns)
	@cached_property
	def server_version(self)->t.Tuple[int,int]:
		if(result:=self.fetchone('SHOW server_version')):
			server_version,*_=result;match=re.search('(\\d+)\\.(\\d+)',server_version)
			if match:return int(match.group(1)),int(match.group(2))
		return 0,0