from __future__ import annotations
_E='hive'
_D='delta_lake'
_C=True
_B=False
_A=None
import contextlib,re,typing as t
from functools import lru_cache
from sqlglot import exp
from sqlglot.helper import seq_get
from tenacity import retry,wait_fixed,stop_after_attempt,retry_if_result
from vulcan.core.dialect import schema_,to_schema
from vulcan.core.engine_adapter.mixins import GetCurrentCatalogFromFunctionMixin,HiveMetastoreTablePropertiesMixin,PandasNativeFetchDFSupportMixin,RowDiffMixin
from vulcan.core.engine_adapter.shared import CatalogSupport,CommentCreationTable,CommentCreationView,DataObject,DataObjectType,InsertOverwriteStrategy,SourceQuery,set_catalog
from vulcan.utils import get_source_columns_to_types
from vulcan.utils.errors import VulcanError
from vulcan.utils.date import TimeLike
if t.TYPE_CHECKING:from vulcan.core._typing import SchemaName,SessionProperties,TableName;from vulcan.core.engine_adapter._typing import DF,QueryOrDF
CATALOG_TYPES_SUPPORTING_REPLACE_TABLE={'iceberg',_D}
@set_catalog()
class TrinoEngineAdapter(PandasNativeFetchDFSupportMixin,HiveMetastoreTablePropertiesMixin,GetCurrentCatalogFromFunctionMixin,RowDiffMixin):
	DIALECT='trino';INSERT_OVERWRITE_STRATEGY=InsertOverwriteStrategy.INTO_IS_OVERWRITE;SUPPORTS_TRANSACTIONS=_B;CURRENT_CATALOG_EXPRESSION=exp.column('current_catalog');COMMENT_CREATION_TABLE=CommentCreationTable.IN_SCHEMA_DEF_NO_CTAS;COMMENT_CREATION_VIEW=CommentCreationView.COMMENT_COMMAND_ONLY;SUPPORTS_REPLACE_TABLE=_B;SUPPORTED_DROP_CASCADE_OBJECT_KINDS=['SCHEMA'];DEFAULT_CATALOG_TYPE=_E;QUOTE_IDENTIFIERS_IN_VIEWS=_B;SUPPORTS_QUERY_EXECUTION_TRACKING=_C;SCHEMA_DIFFER_KWARGS={'parameterized_type_defaults':{exp.DataType.build('DECIMAL',dialect=DIALECT).this:[(),(0,)],exp.DataType.build('CHAR',dialect=DIALECT).this:[(1,)],exp.DataType.build('TIMESTAMP',dialect=DIALECT).this:[(3,)]}};MAX_TIMESTAMP_PRECISION=3
	@property
	def schema_location_mapping(self)->t.Optional[t.Dict[re.Pattern,str]]:return self._extra_config.get('schema_location_mapping')
	@property
	def catalog_support(self)->CatalogSupport:return CatalogSupport.FULL_SUPPORT
	def set_current_catalog(self,catalog:str)->_A:self.execute(exp.Use(this=schema_(db='information_schema',catalog=catalog)))
	@lru_cache()
	def get_catalog_type(self,catalog:t.Optional[str])->str:
		row:t.Tuple=tuple()
		if catalog:
			if(catalog_type_override:=self._catalog_type_overrides.get(catalog)):return catalog_type_override
			row=self.fetchone(f"select connector_name from system.metadata.catalogs where catalog_name='{catalog}'")or()
		return seq_get(row,0)or self.DEFAULT_CATALOG_TYPE
	@contextlib.contextmanager
	def session(self,properties:SessionProperties)->t.Iterator[_A]:
		authorization=properties.get('authorization')
		if not authorization:yield;return
		if not isinstance(authorization,exp.Expression):authorization=exp.Literal.string(authorization)
		if not authorization.is_string:raise VulcanError('Invalid value for `session_properties.authorization`. Must be a string literal.')
		authorization_sql=authorization.sql(dialect=self.dialect);self.execute(f"SET SESSION AUTHORIZATION {authorization_sql}")
		try:yield
		finally:self.execute(f"RESET SESSION AUTHORIZATION")
	def replace_query(self,table_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,source_columns:t.Optional[t.List[str]]=_A,supports_replace_table_override:t.Optional[bool]=_A,**kwargs:t.Any)->_A:
		catalog_type=self.get_catalog_type_from_table(table_name);supports_replace_table_override=_A
		for replace_table_catalog_type in CATALOG_TYPES_SUPPORTING_REPLACE_TABLE:
			if replace_table_catalog_type in catalog_type:supports_replace_table_override=_C;break
		super().replace_query(table_name=table_name,query_or_df=query_or_df,target_columns_to_types=target_columns_to_types,table_description=table_description,column_descriptions=column_descriptions,source_columns=source_columns,supports_replace_table_override=supports_replace_table_override,**kwargs)
	def _insert_overwrite_by_condition(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,where:t.Optional[exp.Condition]=_A,insert_overwrite_strategy_override:t.Optional[InsertOverwriteStrategy]=_A,**kwargs:t.Any)->_A:
		catalog=exp.to_table(table_name).catalog or self.get_current_catalog()
		if where and self.get_catalog_type(catalog)==_E:self.execute(f"SET SESSION {catalog}.insert_existing_partitions_behavior='OVERWRITE'");super()._insert_overwrite_by_condition(table_name,source_queries,target_columns_to_types,where);self.execute(f"SET SESSION {catalog}.insert_existing_partitions_behavior='APPEND'")
		else:super()._insert_overwrite_by_condition(table_name,source_queries,target_columns_to_types,where,insert_overwrite_strategy_override=InsertOverwriteStrategy.DELETE_INSERT)
	def _truncate_table(self,table_name:TableName)->_A:table=exp.to_table(table_name);self.execute(f"DELETE FROM {table.sql(dialect=self.dialect,identify=_C)}")
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:
		I='table_type';H='table_catalog';G='schema_name';F='catalog_name';E='name';D='table_name';C='table_schema';B='mv';A='t';schema_name=to_schema(schema_name);schema=schema_name.db;catalog=schema_name.catalog or self.get_current_catalog();query=exp.select(exp.column(H,table=A).as_('catalog'),exp.column(C,table=A).as_('schema'),exp.column(D,table=A).as_(E),exp.case().when(exp.column(E,table=B).is_(exp.null()).not_(),exp.Literal.string('materialized_view')).when(exp.column(I,table=A).eq('BASE TABLE'),exp.Literal.string('table')).else_(exp.column(I,table=A)).as_('type')).from_(exp.to_table(f"{catalog}.information_schema.tables",alias=A)).join(exp.to_table('system.metadata.materialized_views',alias=B),on=exp.and_(exp.column(F,table=B).eq(exp.column(H,table=A)),exp.column(G,table=B).eq(exp.column(C,table=A)),exp.column(E,table=B).eq(exp.column(D,table=A))),join_type='left').where(exp.and_(exp.column(C,table=A).eq(schema),exp.or_(exp.column(F,table=B).is_(exp.null()),exp.column(F,table=B).eq(catalog)),exp.or_(exp.column(G,table=B).is_(exp.null()),exp.column(G,table=B).eq(schema))))
		if object_names:query=query.where(exp.column(D,table=A).isin(*object_names))
		df=self.fetchdf(query);return[DataObject(catalog=row.catalog,schema=row.schema,name=row.name,type=DataObjectType.from_str(row.type))for row in df.itertuples()]
	def _df_to_source_queries(self,df:DF,target_columns_to_types:t.Dict[str,exp.DataType],batch_size:int,target_table:TableName,source_columns:t.Optional[t.List[str]]=_A)->t.List[SourceQuery]:
		import pandas as pd;from pandas.api.types import is_datetime64_any_dtype;assert isinstance(df,pd.DataFrame);source_columns_to_types=get_source_columns_to_types(target_columns_to_types,source_columns)
		for(column,kind)in source_columns_to_types.items():
			dtype=df.dtypes[column]
			if is_datetime64_any_dtype(dtype)and getattr(dtype,'tz',_A)is not _A:df[column]=pd.to_datetime(df[column]).map(lambda x:x.isoformat(' '))
		return super()._df_to_source_queries(df,target_columns_to_types,batch_size,target_table,source_columns=source_columns)
	def _build_schema_exp(self,table:exp.Table,target_columns_to_types:t.Dict[str,exp.DataType],column_descriptions:t.Optional[t.Dict[str,str]]=_A,expressions:t.Optional[t.List[exp.PrimaryKey]]=_A,is_view:bool=_B,materialized:bool=_B)->exp.Schema:
		if _D in self.get_catalog_type_from_table(table):target_columns_to_types=self._to_delta_ts(target_columns_to_types)
		return super()._build_schema_exp(table,target_columns_to_types,column_descriptions,expressions,is_view)
	def _scd_type_2(self,target_table:TableName,source_table:QueryOrDF,unique_key:t.Sequence[exp.Expression],valid_from_col:exp.Column,valid_to_col:exp.Column,execution_time:t.Union[TimeLike,exp.Column],invalidate_hard_deletes:bool=_C,updated_at_col:t.Optional[exp.Column]=_A,check_columns:t.Optional[t.Union[exp.Star,t.Sequence[exp.Expression]]]=_A,updated_at_as_valid_from:bool=_B,execution_time_as_valid_from:bool=_B,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,truncate:bool=_B,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:
		if target_columns_to_types and _D in self.get_catalog_type_from_table(target_table):target_columns_to_types=self._to_delta_ts(target_columns_to_types)
		return super()._scd_type_2(target_table,source_table,unique_key,valid_from_col,valid_to_col,execution_time,invalidate_hard_deletes,updated_at_col,check_columns,updated_at_as_valid_from,execution_time_as_valid_from,target_columns_to_types,table_description,column_descriptions,truncate,source_columns,**kwargs)
	def _to_delta_ts(self,columns_to_types:t.Dict[str,exp.DataType])->t.Dict[str,exp.DataType]:ts6=exp.DataType.build('timestamp(6)');ts3_tz=exp.DataType.build('timestamp(3) with time zone');delta_columns_to_types={k:ts6 if v.is_type(exp.DataType.Type.TIMESTAMP)else v for(k,v)in columns_to_types.items()};delta_columns_to_types={k:ts3_tz if v.is_type(exp.DataType.Type.TIMESTAMPTZ)else v for(k,v)in delta_columns_to_types.items()};return delta_columns_to_types
	@retry(wait=wait_fixed(1),stop=stop_after_attempt(10),retry=retry_if_result(lambda v:not v))
	def _block_until_table_exists(self,table_name:TableName)->bool:return self.table_exists(table_name)
	def _create_schema(self,schema_name:SchemaName,ignore_if_exists:bool,warn_on_error:bool,properties:t.List[exp.Expression],kind:str)->_A:
		if(mapped_location:=self._schema_location(schema_name)):properties.append(exp.LocationProperty(this=exp.Literal.string(mapped_location)))
		return super()._create_schema(schema_name=schema_name,ignore_if_exists=ignore_if_exists,warn_on_error=warn_on_error,properties=properties,kind=kind)
	def _create_table(self,table_name_or_schema:t.Union[exp.Schema,TableName],expression:t.Optional[exp.Expression],exists:bool=_C,replace:bool=_B,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,table_kind:t.Optional[str]=_A,track_rows_processed:bool=_C,**kwargs:t.Any)->_A:
		super()._create_table(table_name_or_schema=table_name_or_schema,expression=expression,exists=exists,replace=replace,target_columns_to_types=target_columns_to_types,table_description=table_description,column_descriptions=column_descriptions,table_kind=table_kind,track_rows_processed=track_rows_processed,**kwargs)
		if isinstance(table_name_or_schema,exp.Schema):table_name=table_name_or_schema.this;assert isinstance(table_name,exp.Table)
		else:table_name=table_name_or_schema
		if _E in self.get_catalog_type_from_table(table_name):self._block_until_table_exists(table_name)
	def _schema_location(self,schema_name:SchemaName)->t.Optional[str]:
		if(mapping:=self.schema_location_mapping):
			schema=to_schema(schema_name);match_key=schema.db
			if schema.catalog:match_key=f"{schema.catalog}.{match_key}"
			for(k,v)in mapping.items():
				if re.match(k,match_key):return v.replace('@{schema_name}',schema.db).replace('@{catalog_name}',schema.catalog)