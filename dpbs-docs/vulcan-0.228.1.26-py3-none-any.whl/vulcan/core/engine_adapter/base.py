from __future__ import annotations
_K='SCHEMA'
_J='catalog'
_I='format'
_H='VIEW'
_G='qmark'
_F='expressions'
_E='TABLE'
_D='this'
_C=True
_B=False
_A=None
import contextlib,itertools,logging,sys,typing as t
from functools import cached_property,partial
from sqlglot import Dialect,exp
from sqlglot.errors import ErrorLevel
from sqlglot.helper import ensure_list,seq_get
from sqlglot.optimizer.qualify_columns import quote_identifiers
from vulcan.core.dialect import add_table,schema_,select_from_values_for_batch_range,to_schema
from vulcan.core.engine_adapter.shared import CatalogSupport,CommentCreationTable,CommentCreationView,DataObject,DataObjectType,EngineRunMode,InsertOverwriteStrategy,SourceQuery,set_catalog
from vulcan.core.model.kind import TimeColumn
from vulcan.core.schema_diff import SchemaDiffer,TableAlterOperation
from vulcan.core.snapshot.execution_tracker import QueryExecutionTracker
from vulcan.utils import CorrelationId,columns_to_types_all_known,random_id,get_source_columns_to_types
from vulcan.utils.connection_pool import ConnectionPool,create_connection_pool
from vulcan.utils.date import TimeLike,make_inclusive,to_time_column
from vulcan.utils.errors import MissingDefaultCatalogError,VulcanError,UnsupportedCatalogOperationError
from vulcan.utils.pandas import columns_to_types_from_df
if t.TYPE_CHECKING:import pandas as pd;from vulcan.core._typing import SchemaName,SessionProperties,TableName;from vulcan.core.engine_adapter._typing import DF,BigframeSession,GrantsConfig,PySparkDataFrame,PySparkSession,Query,QueryOrDF,SnowparkSession;from vulcan.core.node import IntervalUnit
logger=logging.getLogger(__name__)
MERGE_TARGET_ALIAS='__MERGE_TARGET__'
MERGE_SOURCE_ALIAS='__MERGE_SOURCE__'
KEY_FOR_CREATABLE_TYPE='CREATABLE_TYPE'
@set_catalog()
class EngineAdapter:
	DIALECT='';DEFAULT_BATCH_SIZE=10000;DATA_OBJECT_FILTER_BATCH_SIZE=4000;SUPPORTS_TRANSACTIONS=_C;SUPPORTS_INDEXES=_B;COMMENT_CREATION_TABLE=CommentCreationTable.IN_SCHEMA_DEF_CTAS;COMMENT_CREATION_VIEW=CommentCreationView.IN_SCHEMA_DEF_AND_COMMANDS;MAX_TABLE_COMMENT_LENGTH:t.Optional[int]=_A;MAX_COLUMN_COMMENT_LENGTH:t.Optional[int]=_A;INSERT_OVERWRITE_STRATEGY=InsertOverwriteStrategy.DELETE_INSERT;SUPPORTS_MATERIALIZED_VIEWS=_B;SUPPORTS_MATERIALIZED_VIEW_SCHEMA=_B;SUPPORTS_VIEW_SCHEMA=_C;SUPPORTS_CLONING=_B;SUPPORTS_MANAGED_MODELS=_B;SUPPORTS_CREATE_DROP_CATALOG=_B;SUPPORTED_DROP_CASCADE_OBJECT_KINDS:t.List[str]=[];SCHEMA_DIFFER_KWARGS:t.Dict[str,t.Any]={};SUPPORTS_TUPLE_IN=_C;HAS_VIEW_BINDING=_B;SUPPORTS_REPLACE_TABLE=_C;SUPPORTS_GRANTS=_B;DEFAULT_CATALOG_TYPE=DIALECT;QUOTE_IDENTIFIERS_IN_VIEWS=_C;MAX_IDENTIFIER_LENGTH:t.Optional[int]=_A;ATTACH_CORRELATION_ID=_C;SUPPORTS_QUERY_EXECUTION_TRACKING=_B;SUPPORTS_METADATA_TABLE_LAST_MODIFIED_TS=_B
	def __init__(self,connection_factory_or_pool:t.Union[t.Callable[[],t.Any],ConnectionPool],dialect:str='',sql_gen_kwargs:t.Optional[t.Dict[str,Dialect|bool|str]]=_A,multithreaded:bool=_B,cursor_init:t.Optional[t.Callable[[t.Any],_A]]=_A,default_catalog:t.Optional[str]=_A,execute_log_level:int=logging.DEBUG,register_comments:bool=_C,pre_ping:bool=_B,pretty_sql:bool=_B,shared_connection:bool=_B,correlation_id:t.Optional[CorrelationId]=_A,schema_differ_overrides:t.Optional[t.Dict[str,t.Any]]=_A,query_execution_tracker:t.Optional[QueryExecutionTracker]=_A,user_agent:t.Optional[str]=_A,**kwargs:t.Any):self.dialect=dialect.lower()or self.DIALECT;self._connection_pool=connection_factory_or_pool if isinstance(connection_factory_or_pool,ConnectionPool)else create_connection_pool(connection_factory_or_pool,multithreaded,shared_connection=shared_connection,cursor_init=cursor_init);self._sql_gen_kwargs=sql_gen_kwargs or{};self._default_catalog=default_catalog;self._execute_log_level=execute_log_level;self._extra_config=kwargs;self._register_comments=register_comments;self._pre_ping=pre_ping;self._pretty_sql=pretty_sql;self._multithreaded=multithreaded;self.correlation_id=correlation_id;self._user_agent=user_agent;self._schema_differ_overrides=schema_differ_overrides;self._query_execution_tracker=query_execution_tracker;(self._data_object_cache):t.Dict[str,t.Optional[DataObject]]={}
	def with_settings(self,**kwargs:t.Any)->EngineAdapter:D='query_execution_tracker';C='user_agent';B='correlation_id';A='execute_log_level';extra_kwargs={'null_connection':_C,A:kwargs.pop(A,self._execute_log_level),B:kwargs.pop(B,self.correlation_id),C:kwargs.pop(C,self._user_agent),D:kwargs.pop(D,self._query_execution_tracker),**self._extra_config,**kwargs};adapter=self.__class__(self._connection_pool,dialect=self.dialect,sql_gen_kwargs=self._sql_gen_kwargs,default_catalog=self._default_catalog,register_comments=self._register_comments,multithreaded=self._multithreaded,pretty_sql=self._pretty_sql,**extra_kwargs);return adapter
	@property
	def cursor(self)->t.Any:return self._connection_pool.get_cursor()
	@property
	def connection(self)->t.Any:return self._connection_pool.get()
	def _dbapi_paramstyle(self)->t.Optional[str]:
		C='__module__';B='__class__';A='paramstyle';valid_styles={_G,'numeric','named',_I,'pyformat'};cursor_paramstyle=getattr(self.cursor,A,_A)
		if cursor_paramstyle in valid_styles:return t.cast(str,cursor_paramstyle)
		connection_paramstyle=getattr(self.connection,A,_A)
		if connection_paramstyle in valid_styles:return t.cast(str,connection_paramstyle)
		def _paramstyle_from_module(module_name:str)->t.Optional[str]:
			import importlib;current=module_name
			while _C:
				try:mod=importlib.import_module(current)
				except Exception:mod=_A
				paramstyle=getattr(mod,A,_A)if mod is not _A else _A
				if paramstyle in valid_styles:return t.cast(str,paramstyle)
				if'.'not in current:break
				current=current.rsplit('.',1)[0]
		for module_name in(getattr(getattr(self.connection,B,object),C,_A),getattr(getattr(self.cursor,B,object),C,_A)):
			if module_name:
				module_paramstyle=_paramstyle_from_module(module_name)
				if module_paramstyle in valid_styles:return module_paramstyle
	@property
	def spark(self)->t.Optional[PySparkSession]:0
	@property
	def snowpark(self)->t.Optional[SnowparkSession]:0
	@property
	def bigframe(self)->t.Optional[BigframeSession]:0
	@property
	def comments_enabled(self)->bool:return self._register_comments and self.COMMENT_CREATION_TABLE.is_supported
	@property
	def catalog_support(self)->CatalogSupport:return CatalogSupport.UNSUPPORTED
	@cached_property
	def schema_differ(self)->SchemaDiffer:return SchemaDiffer(**{**self.SCHEMA_DIFFER_KWARGS,**(self._schema_differ_overrides or{})})
	@property
	def _catalog_type_overrides(self)->t.Dict[str,str]:return self._extra_config.get('catalog_type_overrides')or{}
	@classmethod
	def _casted_columns(cls,target_columns_to_types:t.Dict[str,exp.DataType],source_columns:t.Optional[t.List[str]]=_A)->t.List[exp.Alias]:source_columns_lookup=set(source_columns or target_columns_to_types);return[exp.alias_(exp.cast(exp.column(column,quoted=_C)if column in source_columns_lookup else exp.Null(),to=kind),column,copy=_B,quoted=_C)for(column,kind)in target_columns_to_types.items()]
	@property
	def default_catalog(self)->t.Optional[str]:
		if self.catalog_support.is_unsupported:return
		default_catalog=self._default_catalog or self.get_current_catalog()
		if not default_catalog:raise MissingDefaultCatalogError('Could not determine a default catalog despite it being supported.')
		return default_catalog
	@property
	def engine_run_mode(self)->EngineRunMode:return EngineRunMode.SINGLE_MODE_ENGINE
	def _get_source_queries(self,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],target_table:TableName,*,batch_size:t.Optional[int]=_A,source_columns:t.Optional[t.List[str]]=_A)->t.List[SourceQuery]:
		import pandas as pd;batch_size=self.DEFAULT_BATCH_SIZE if batch_size is _A else batch_size
		if isinstance(query_or_df,exp.Query):
			query_factory=lambda:query_or_df
			if source_columns:
				source_columns_lookup=set(source_columns)
				if not target_columns_to_types:raise VulcanError('columns_to_types must be set if source_columns is set')
				if not set(target_columns_to_types).issubset(source_columns_lookup):select_columns=[exp.column(c,quoted=_C)if c in source_columns_lookup else exp.cast(exp.Null(),target_columns_to_types[c],copy=_B).as_(c,copy=_B,quoted=_C)for c in target_columns_to_types];query_factory=lambda:exp.Select().select(*select_columns).from_(query_or_df.subquery('select_source_columns'))
			return[SourceQuery(query_factory=query_factory)]
		if not target_columns_to_types:raise VulcanError('It is expected that if a DataFrame is passed in then columns_to_types is set')
		if isinstance(query_or_df,pd.DataFrame)and query_or_df.empty:raise VulcanError('Cannot construct source query from an empty DataFrame. This error is commonly related to Python models that produce no data. For such models, consider yielding from an empty generator if the resulting set is empty, i.e. use `yield from ()`.')
		return self._df_to_source_queries(query_or_df,target_columns_to_types,batch_size,target_table=target_table,source_columns=source_columns)
	def _df_to_source_queries(self,df:DF,target_columns_to_types:t.Dict[str,exp.DataType],batch_size:int,target_table:TableName,source_columns:t.Optional[t.List[str]]=_A)->t.List[SourceQuery]:import pandas as pd;assert isinstance(df,pd.DataFrame);num_rows=len(df.index);batch_size=sys.maxsize if batch_size==0 else batch_size;df=df[list(source_columns or target_columns_to_types)];values=list(df.itertuples(index=_B,name=_A));return[SourceQuery(query_factory=partial(self._values_to_sql,values=values,target_columns_to_types=target_columns_to_types,batch_start=i,batch_end=min(i+batch_size,num_rows),source_columns=source_columns))for i in range(0,num_rows,batch_size)]
	def _get_source_queries_and_columns_to_types(self,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],target_table:TableName,*,batch_size:t.Optional[int]=_A,source_columns:t.Optional[t.List[str]]=_A)->t.Tuple[t.List[SourceQuery],t.Optional[t.Dict[str,exp.DataType]]]:target_columns_to_types,source_columns=self._columns_to_types(query_or_df,target_columns_to_types,source_columns);source_queries=self._get_source_queries(query_or_df,target_columns_to_types,target_table=target_table,batch_size=batch_size,source_columns=source_columns);return source_queries,target_columns_to_types
	@t.overload
	def _columns_to_types(self,query_or_df:DF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A)->t.Tuple[t.Dict[str,exp.DataType],t.List[str]]:...
	@t.overload
	def _columns_to_types(self,query_or_df:Query,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A)->t.Tuple[t.Optional[t.Dict[str,exp.DataType]],t.Optional[t.List[str]]]:...
	def _columns_to_types(self,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A)->t.Tuple[t.Optional[t.Dict[str,exp.DataType]],t.Optional[t.List[str]]]:
		import pandas as pd
		if not target_columns_to_types and isinstance(query_or_df,pd.DataFrame):target_columns_to_types=columns_to_types_from_df(t.cast(pd.DataFrame,query_or_df))
		if not source_columns and target_columns_to_types:source_columns=list(target_columns_to_types)
		source_columns=[x for x in source_columns if x in target_columns_to_types]if source_columns and target_columns_to_types else _A;return target_columns_to_types,source_columns
	def recycle(self)->_A:self._connection_pool.close_all(exclude_calling_thread=_C)
	def close(self)->t.Any:self._connection_pool.close_all()
	def shutdown(self)->_A:0
	def get_current_catalog(self)->t.Optional[str]:raise NotImplementedError
	def set_current_catalog(self,catalog:str)->_A:raise NotImplementedError
	def get_catalog_type(self,catalog:t.Optional[str])->str:
		if self.catalog_support.is_unsupported:raise UnsupportedCatalogOperationError(f"{self.dialect} does not support catalogs and a catalog was provided: {catalog}")
		return self._catalog_type_overrides.get(catalog,self.DEFAULT_CATALOG_TYPE)if catalog else self.DEFAULT_CATALOG_TYPE
	def get_catalog_type_from_table(self,table:TableName)->str:catalog=exp.to_table(table).catalog or self.get_current_catalog();return self.get_catalog_type(catalog)
	@property
	def current_catalog_type(self)->str:return self.get_catalog_type(self.get_current_catalog())
	def replace_query(self,table_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,source_columns:t.Optional[t.List[str]]=_A,supports_replace_table_override:t.Optional[bool]=_A,**kwargs:t.Any)->_A:
		target_table=exp.to_table(table_name);target_data_object=self.get_data_object(target_table);table_exists=target_data_object is not _A
		if self.drop_data_object_on_type_mismatch(target_data_object,DataObjectType.TABLE):table_exists=_B
		source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types,target_table=target_table,source_columns=source_columns)
		if not target_columns_to_types and table_exists:target_columns_to_types=self.columns(target_table)
		query=source_queries[0].query_factory();self_referencing=any(quote_identifiers(table)==quote_identifiers(target_table)for table in query.find_all(exp.Table))
		if self_referencing:
			if not target_columns_to_types:raise VulcanError(f"Cannot create a self-referencing table {target_table.sql(dialect=self.dialect)} without knowing the column types. Try casting the columns to an expected type or defining the columns in the model metadata. ")
			self._create_table_from_columns(target_table,target_columns_to_types,exists=_C,table_description=table_description,column_descriptions=column_descriptions,**kwargs)
		supports_replace_table=self.SUPPORTS_REPLACE_TABLE if supports_replace_table_override is _A else supports_replace_table_override
		if supports_replace_table or not table_exists:return self._create_table_from_source_queries(target_table,source_queries,target_columns_to_types,replace=supports_replace_table,table_description=table_description,column_descriptions=column_descriptions,**kwargs)
		if self_referencing:
			assert target_columns_to_types is not _A
			with self.temp_table(self._select_columns(target_columns_to_types).from_(target_table),name=target_table,target_columns_to_types=target_columns_to_types,**kwargs)as temp_table:
				for source_query in source_queries:source_query.add_transform(lambda node:temp_table if isinstance(node,exp.Table)and quote_identifiers(node)==quote_identifiers(target_table)else node)
				return self._insert_overwrite_by_condition(target_table,source_queries,target_columns_to_types,**kwargs)
		return self._insert_overwrite_by_condition(target_table,source_queries,target_columns_to_types,**kwargs)
	def create_index(self,table_name:TableName,index_name:str,columns:t.Tuple[str,...],exists:bool=_C)->_A:
		if not self.SUPPORTS_INDEXES:return
		expression=exp.Create(this=exp.Index(this=exp.to_identifier(index_name),table=exp.to_table(table_name),params=exp.IndexParameters(columns=[exp.to_column(c)for c in columns])),kind='INDEX',exists=exists);self.execute(expression)
	def _pop_creatable_type_from_properties(self,properties:t.Dict[str,exp.Expression])->t.Optional[exp.Property]:
		for key in list(properties.keys()):
			upper_key=key.upper()
			if upper_key==KEY_FOR_CREATABLE_TYPE:
				value=properties.pop(key).name;parsed_properties=exp.maybe_parse(value,into=exp.Properties,dialect=self.dialect);property,*others=parsed_properties.expressions
				if others:raise VulcanError(f"Invalid creatable_type value with multiple properties: {value}")
				if isinstance(property,exp.MaterializedProperty):raise VulcanError(f"Cannot use {value} as a creatable_type as it conflicts with the `materialize` parameter.")
				return property
	def create_table(self,table_name:TableName,target_columns_to_types:t.Dict[str,exp.DataType],primary_key:t.Optional[t.Tuple[str,...]]=_A,exists:bool=_C,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,**kwargs:t.Any)->_A:self._create_table_from_columns(table_name,target_columns_to_types,primary_key,exists,table_description,column_descriptions,**kwargs)
	def create_managed_table(self,table_name:TableName,query:Query,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,clustered_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:raise NotImplementedError(f"Engine does not support managed tables: {type(self)}")
	def ctas(self,table_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,exists:bool=_C,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types,target_table=table_name,source_columns=source_columns);return self._create_table_from_source_queries(table_name,source_queries,target_columns_to_types,exists,table_description=table_description,column_descriptions=column_descriptions,**kwargs)
	def create_state_table(self,table_name:str,target_columns_to_types:t.Dict[str,exp.DataType],primary_key:t.Optional[t.Tuple[str,...]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A)->_A:self.create_table(table_name,target_columns_to_types,primary_key=primary_key,table_description=table_description,column_descriptions=column_descriptions)
	def _create_table_from_columns(self,table_name:TableName,target_columns_to_types:t.Dict[str,exp.DataType],primary_key:t.Optional[t.Tuple[str,...]]=_A,exists:bool=_C,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,**kwargs:t.Any)->_A:
		table=exp.to_table(table_name)
		if not columns_to_types_all_known(target_columns_to_types):
			if exists and self.table_exists(table_name):return
			raise VulcanError(f"Cannot create a table without knowing the column types. Try casting the columns to an expected type or defining the columns in the model metadata. Columns to types: {target_columns_to_types}")
		primary_key_expression=[exp.PrimaryKey(expressions=[exp.to_column(k)for k in primary_key])]if primary_key and self.SUPPORTS_INDEXES else[]
		if exists:existing_object=self.get_data_object(table_name);self.drop_data_object_on_type_mismatch(existing_object,DataObjectType.TABLE)
		schema=self._build_schema_exp(table,target_columns_to_types,column_descriptions,primary_key_expression);self._create_table(schema,_A,exists=exists,target_columns_to_types=target_columns_to_types,table_description=table_description,**kwargs)
		if table_description and self.COMMENT_CREATION_TABLE.is_comment_command_only and self.comments_enabled:self._create_table_comment(table_name,table_description)
		if column_descriptions and self.COMMENT_CREATION_TABLE.is_comment_command_only and self.comments_enabled:self._create_column_comments(table_name,column_descriptions)
	def _build_schema_exp(self,table:exp.Table,target_columns_to_types:t.Dict[str,exp.DataType],column_descriptions:t.Optional[t.Dict[str,str]]=_A,expressions:t.Optional[t.List[exp.PrimaryKey]]=_A,is_view:bool=_B,materialized:bool=_B)->exp.Schema:expressions=expressions or[];return exp.Schema(this=table,expressions=self._build_column_defs(target_columns_to_types=target_columns_to_types,column_descriptions=column_descriptions,is_view=is_view,materialized=materialized)+expressions)
	def _build_column_defs(self,target_columns_to_types:t.Dict[str,exp.DataType],column_descriptions:t.Optional[t.Dict[str,str]]=_A,is_view:bool=_B,materialized:bool=_B)->t.List[exp.ColumnDef]:engine_supports_schema_comments=self.COMMENT_CREATION_VIEW.supports_schema_def if is_view else self.COMMENT_CREATION_TABLE.supports_schema_def;return[self._build_column_def(column,column_descriptions=column_descriptions,engine_supports_schema_comments=engine_supports_schema_comments,col_type=_A if is_view else kind)for(column,kind)in target_columns_to_types.items()]
	def _build_column_def(self,col_name:str,column_descriptions:t.Optional[t.Dict[str,str]]=_A,engine_supports_schema_comments:bool=_B,col_type:t.Optional[exp.DATA_TYPE]=_A,nested_names:t.List[str]=[])->exp.ColumnDef:return exp.ColumnDef(this=exp.to_identifier(col_name),kind=col_type,constraints=self._build_col_comment_exp(col_name,column_descriptions)if engine_supports_schema_comments and self.comments_enabled and column_descriptions else _A)
	def _build_col_comment_exp(self,col_name:str,column_descriptions:t.Dict[str,str])->t.List[exp.ColumnConstraint]:
		comment=column_descriptions.get(col_name,_A)
		if comment:return[exp.ColumnConstraint(kind=exp.CommentColumnConstraint(this=exp.Literal.string(self._truncate_column_comment(comment))))]
		return[]
	def _create_table_from_source_queries(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,exists:bool=_C,replace:bool=_B,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,table_kind:t.Optional[str]=_A,track_rows_processed:bool=_C,**kwargs:t.Any)->_A:
		table=exp.to_table(table_name);schema=_A;target_columns_to_types_known=target_columns_to_types and columns_to_types_all_known(target_columns_to_types)
		if column_descriptions and target_columns_to_types_known and self.COMMENT_CREATION_TABLE.is_in_schema_def_ctas and self.comments_enabled:schema=self._build_schema_exp(table,target_columns_to_types,column_descriptions)
		with self.transaction(condition=len(source_queries)>1):
			for(i,source_query)in enumerate(source_queries):
				with source_query as query:
					if target_columns_to_types and target_columns_to_types_known:query=self._order_projections_and_filter(query,target_columns_to_types,coerce_types=_C)
					if i==0:self._create_table(schema if schema else table,query,target_columns_to_types=target_columns_to_types,exists=exists,replace=replace,table_description=table_description,table_kind=table_kind,track_rows_processed=track_rows_processed,**kwargs)
					else:self._insert_append_query(table_name,query,target_columns_to_types or self.columns(table),track_rows_processed=track_rows_processed)
		if table_description and self.COMMENT_CREATION_TABLE.is_comment_command_only and self.comments_enabled:self._create_table_comment(table_name,table_description)
		if column_descriptions and schema is _A and self.comments_enabled:self._create_column_comments(table_name,column_descriptions)
	def _create_table(self,table_name_or_schema:t.Union[exp.Schema,TableName],expression:t.Optional[exp.Expression],exists:bool=_C,replace:bool=_B,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,table_kind:t.Optional[str]=_A,track_rows_processed:bool=_C,**kwargs:t.Any)->_A:self.execute(self._build_create_table_exp(table_name_or_schema,expression=expression,exists=exists,replace=replace,target_columns_to_types=target_columns_to_types,table_description=table_description if self.COMMENT_CREATION_TABLE.supports_schema_def and self.comments_enabled else _A,table_kind=table_kind,**kwargs),track_rows_processed=track_rows_processed);table_name=table_name_or_schema.this if isinstance(table_name_or_schema,exp.Schema)else table_name_or_schema;self._clear_data_object_cache(table_name)
	def _build_create_table_exp(self,table_name_or_schema:t.Union[exp.Schema,TableName],expression:t.Optional[exp.Expression],exists:bool=_C,replace:bool=_B,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,**kwargs:t.Any)->exp.Create:
		exists=_B if replace else exists;catalog_name=_A
		if not isinstance(table_name_or_schema,exp.Schema):table_name_or_schema=exp.to_table(table_name_or_schema);catalog_name=table_name_or_schema.catalog
		elif isinstance(table_name_or_schema.this,exp.Table):catalog_name=table_name_or_schema.this.catalog
		properties=self._build_table_properties_exp(**kwargs,catalog_name=catalog_name,target_columns_to_types=target_columns_to_types,table_description=table_description,table_kind=table_kind)if kwargs or table_description else _A;return exp.Create(this=table_name_or_schema,kind=table_kind or _E,replace=replace,exists=exists,expression=expression,properties=properties)
	def create_table_like(self,target_table_name:TableName,source_table_name:TableName,exists:bool=_C,**kwargs:t.Any)->_A:self._create_table_like(target_table_name,source_table_name,exists=exists,**kwargs);self._clear_data_object_cache(target_table_name)
	def clone_table(self,target_table_name:TableName,source_table_name:TableName,replace:bool=_B,exists:bool=_C,clone_kwargs:t.Optional[t.Dict[str,t.Any]]=_A,**kwargs:t.Any)->_A:
		if not self.SUPPORTS_CLONING:raise NotImplementedError(f"Engine does not support cloning: {type(self)}")
		kwargs.pop('rendered_physical_properties',_A);self.execute(exp.Create(this=exp.to_table(target_table_name),kind=_E,replace=replace,exists=exists,clone=exp.Clone(this=exp.to_table(source_table_name),**clone_kwargs or{}),**kwargs));self._clear_data_object_cache(target_table_name)
	def drop_data_object(self,data_object:DataObject,ignore_if_not_exists:bool=_C)->_A:
		if data_object.type.is_view:self.drop_view(data_object.to_table(),ignore_if_not_exists=ignore_if_not_exists)
		elif data_object.type.is_materialized_view:self.drop_view(data_object.to_table(),ignore_if_not_exists=ignore_if_not_exists,materialized=_C)
		elif data_object.type.is_table:self.drop_table(data_object.to_table(),exists=ignore_if_not_exists)
		elif data_object.type.is_managed_table:self.drop_managed_table(data_object.to_table(),exists=ignore_if_not_exists)
		else:raise VulcanError(f"Can't drop data object '{data_object.to_table().sql(dialect=self.dialect)}' of type '{data_object.type.value}'")
	def drop_table(self,table_name:TableName,exists:bool=_C,**kwargs:t.Any)->_A:self._drop_object(name=table_name,exists=exists,**kwargs)
	def drop_managed_table(self,table_name:TableName,exists:bool=_C)->_A:raise NotImplementedError(f"Engine does not support managed tables: {type(self)}")
	def _drop_object(self,name:TableName|SchemaName,exists:bool=_C,kind:str=_E,cascade:bool=_B,**drop_args:t.Any)->_A:
		if cascade and kind.upper()in self.SUPPORTED_DROP_CASCADE_OBJECT_KINDS:drop_args['cascade']=cascade
		self.execute(exp.Drop(this=exp.to_table(name),kind=kind,exists=exists,**drop_args));self._clear_data_object_cache(name)
	def get_alter_operations(self,current_table_name:TableName,target_table_name:TableName,*,ignore_destructive:bool=_B,ignore_additive:bool=_B)->t.List[TableAlterOperation]:return t.cast(t.List[TableAlterOperation],self.schema_differ.compare_columns(current_table_name,self.columns(current_table_name),self.columns(target_table_name),ignore_destructive=ignore_destructive,ignore_additive=ignore_additive))
	def alter_table(self,alter_expressions:t.Union[t.List[exp.Alter],t.List[TableAlterOperation]])->_A:
		with self.transaction():
			for alter_expression in[x.expression if isinstance(x,TableAlterOperation)else x for x in alter_expressions]:self.execute(alter_expression)
	def create_view(self,view_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,replace:bool=_C,materialized:bool=_B,materialized_properties:t.Optional[t.Dict[str,t.Any]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,view_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,source_columns:t.Optional[t.List[str]]=_A,**create_kwargs:t.Any)->_A:
		A='properties';import pandas as pd
		if materialized_properties and not materialized:raise VulcanError('Materialized properties are only supported for materialized views')
		query_or_df=self._native_df_to_pandas_df(query_or_df)
		if isinstance(query_or_df,pd.DataFrame):
			values:t.List[t.Tuple[t.Any,...]]=list(query_or_df.itertuples(index=_B,name=_A));target_columns_to_types,source_columns=self._columns_to_types(query_or_df,target_columns_to_types,source_columns)
			if not target_columns_to_types:raise VulcanError('columns_to_types must be provided for dataframes')
			source_columns_to_types=get_source_columns_to_types(target_columns_to_types,source_columns);query_or_df=self._values_to_sql(values,source_columns_to_types,batch_start=0,batch_end=len(values))
		source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types,batch_size=0,target_table=view_name,source_columns=source_columns)
		if len(source_queries)!=1:raise VulcanError('Only one source query is supported for creating views')
		schema:t.Union[exp.Table,exp.Schema]=exp.to_table(view_name)
		if target_columns_to_types:schema=self._build_schema_exp(exp.to_table(view_name),target_columns_to_types,column_descriptions,is_view=_C,materialized=materialized)
		properties=create_kwargs.pop(A,_A)
		if not properties:properties=exp.Properties(expressions=[])
		if view_properties:
			table_type=self._pop_creatable_type_from_properties(view_properties)
			if table_type:properties.append(_F,table_type)
		if materialized and self.SUPPORTS_MATERIALIZED_VIEWS:
			properties.append(_F,exp.MaterializedProperty())
			if not self.SUPPORTS_MATERIALIZED_VIEW_SCHEMA and isinstance(schema,exp.Schema):schema=schema.this
		if not self.SUPPORTS_VIEW_SCHEMA and isinstance(schema,exp.Schema):schema=schema.this
		if materialized_properties:
			partitioned_by=materialized_properties.pop('partitioned_by',_A);clustered_by=materialized_properties.pop('clustered_by',_A)
			if partitioned_by and(partitioned_by_prop:=self._build_partitioned_by_exp(partitioned_by,**materialized_properties))is not _A:materialized_properties['catalog_name']=exp.to_table(view_name).catalog;properties.append(_F,partitioned_by_prop)
			if clustered_by and(clustered_by_prop:=self._build_clustered_by_exp(clustered_by,**materialized_properties))is not _A:properties.append(_F,clustered_by_prop)
		create_view_properties=self._build_view_properties_exp(view_properties,table_description if self.COMMENT_CREATION_VIEW.supports_schema_def and self.comments_enabled else _A,physical_cluster=create_kwargs.pop('physical_cluster',_A))
		if create_view_properties:
			for view_property in create_view_properties.expressions:
				if isinstance(view_property,exp.SecureProperty):properties.set(_F,view_property,index=0,overwrite=_B)
				else:properties.append(_F,view_property)
		if properties.expressions:create_kwargs[A]=properties
		if replace:self.drop_data_object_on_type_mismatch(self.get_data_object(view_name),DataObjectType.VIEW if not materialized else DataObjectType.MATERIALIZED_VIEW)
		with source_queries[0]as query:self.execute(exp.Create(this=schema,kind=_H,replace=replace,expression=query,**create_kwargs),quote_identifiers=self.QUOTE_IDENTIFIERS_IN_VIEWS)
		self._clear_data_object_cache(view_name)
		if table_description and self.COMMENT_CREATION_VIEW.is_comment_command_only and self.comments_enabled:self._create_table_comment(view_name,table_description,_H)
		if column_descriptions and(self.COMMENT_CREATION_VIEW.is_comment_command_only or self.COMMENT_CREATION_VIEW.is_in_schema_def_and_commands and not target_columns_to_types)and self.comments_enabled:self._create_column_comments(view_name,column_descriptions,_H,materialized)
	@set_catalog()
	def create_schema(self,schema_name:SchemaName,ignore_if_exists:bool=_C,warn_on_error:bool=_C,properties:t.Optional[t.List[exp.Expression]]=_A)->_A:properties=properties or[];return self._create_schema(schema_name=schema_name,ignore_if_exists=ignore_if_exists,warn_on_error=warn_on_error,properties=properties,kind=_K)
	def _create_schema(self,schema_name:SchemaName,ignore_if_exists:bool,warn_on_error:bool,properties:t.List[exp.Expression],kind:str)->_A:
		try:self.execute(exp.Create(this=to_schema(schema_name),kind=kind,exists=ignore_if_exists,properties=exp.Properties(expressions=properties)))
		except Exception as e:
			if not warn_on_error:raise
			logger.warning("Failed to create %s '%s': %s",kind.lower(),schema_name,e)
	def drop_schema(self,schema_name:SchemaName,ignore_if_not_exists:bool=_C,cascade:bool=_B,**drop_args:t.Dict[str,exp.Expression])->_A:return self._drop_object(name=schema_name,exists=ignore_if_not_exists,kind=_K,cascade=cascade,**drop_args)
	def drop_view(self,view_name:TableName,ignore_if_not_exists:bool=_C,materialized:bool=_B,**kwargs:t.Any)->_A:self._drop_object(name=view_name,exists=ignore_if_not_exists,kind=_H,materialized=materialized and self.SUPPORTS_MATERIALIZED_VIEWS,**kwargs)
	def create_catalog(self,catalog_name:str|exp.Identifier)->_A:return self._create_catalog(exp.parse_identifier(catalog_name,dialect=self.dialect))
	def _create_catalog(self,catalog_name:exp.Identifier)->_A:raise VulcanError(f"Unable to create catalog '{catalog_name.sql(dialect=self.dialect)}' as automatic catalog management is not implemented in the {self.dialect} engine.")
	def drop_catalog(self,catalog_name:str|exp.Identifier)->_A:return self._drop_catalog(exp.parse_identifier(catalog_name,dialect=self.dialect))
	def _drop_catalog(self,catalog_name:exp.Identifier)->_A:raise VulcanError(f"Unable to drop catalog '{catalog_name.sql(dialect=self.dialect)}' as automatic catalog management is not implemented in the {self.dialect} engine.")
	def columns(self,table_name:TableName,include_pseudo_columns:bool=_B)->t.Dict[str,exp.DataType]:self.execute(exp.Describe(this=exp.to_table(table_name),kind=_E));describe_output=self.cursor.fetchall();return{column_name:exp.DataType.build(_decoded_str(column_type),dialect=self.dialect)for(column_name,column_type,*_)in itertools.takewhile(lambda t:not t[0].startswith('#'),describe_output)if column_name and column_name.strip()and column_type and column_type.strip()}
	def table_exists(self,table_name:TableName)->bool:
		table=exp.to_table(table_name);data_object_cache_key=_get_data_object_cache_key(table.catalog,table.db,table.name)
		if data_object_cache_key in self._data_object_cache:logger.debug('Table existence cache hit: %s',data_object_cache_key);return self._data_object_cache[data_object_cache_key]is not _A
		try:self.execute(exp.Describe(this=table,kind=_E));return _C
		except Exception:return _B
	def delete_from(self,table_name:TableName,where:t.Union[str,exp.Expression])->_A:self.execute(exp.delete(table_name,where))
	def insert_append(self,table_name:TableName,query_or_df:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,track_rows_processed:bool=_C,source_columns:t.Optional[t.List[str]]=_A)->_A:source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types,target_table=table_name,source_columns=source_columns);self._insert_append_source_queries(table_name,source_queries,target_columns_to_types,track_rows_processed)
	def _insert_append_source_queries(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,track_rows_processed:bool=_C)->_A:
		with self.transaction(condition=len(source_queries)>0):
			target_columns_to_types=target_columns_to_types or self.columns(table_name)
			for source_query in source_queries:
				with source_query as query:self._insert_append_query(table_name,query,target_columns_to_types,track_rows_processed=track_rows_processed)
	def _insert_append_query(self,table_name:TableName,query:Query,target_columns_to_types:t.Dict[str,exp.DataType],order_projections:bool=_C,track_rows_processed:bool=_C)->_A:
		if order_projections:query=self._order_projections_and_filter(query,target_columns_to_types)
		self.execute(exp.insert(query,table_name,columns=list(target_columns_to_types)),track_rows_processed=track_rows_processed)
	def insert_overwrite_by_partition(self,table_name:TableName,query_or_df:QueryOrDF,partitioned_by:t.List[exp.Expression],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A)->_A:
		if self.INSERT_OVERWRITE_STRATEGY.is_insert_overwrite:target_table=exp.to_table(table_name);source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types,target_table=target_table,source_columns=source_columns);self._insert_overwrite_by_condition(table_name,source_queries,target_columns_to_types=target_columns_to_types)
		else:self._replace_by_key(table_name,query_or_df,target_columns_to_types,partitioned_by,is_unique_key=_B,source_columns=source_columns)
	def insert_overwrite_by_time_partition(self,table_name:TableName,query_or_df:QueryOrDF,start:TimeLike,end:TimeLike,time_formatter:t.Callable[[TimeLike,t.Optional[t.Dict[str,exp.DataType]]],exp.Expression],time_column:TimeColumn|exp.Expression|str,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:
		source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types,target_table=table_name,source_columns=source_columns)
		if not target_columns_to_types or not columns_to_types_all_known(target_columns_to_types):target_columns_to_types=self.columns(table_name)
		low,high=[time_formatter(dt,target_columns_to_types)for dt in make_inclusive(start,end,self.dialect)]
		if isinstance(time_column,TimeColumn):time_column=time_column.column
		where=exp.Between(this=exp.to_column(time_column)if isinstance(time_column,str)else time_column,low=low,high=high);return self._insert_overwrite_by_time_partition(table_name,source_queries,target_columns_to_types,where,**kwargs)
	def _insert_overwrite_by_time_partition(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Dict[str,exp.DataType],where:exp.Condition,**kwargs:t.Any)->_A:return self._insert_overwrite_by_condition(table_name,source_queries,target_columns_to_types,where,**kwargs)
	def _values_to_sql(self,values:t.List[t.Tuple[t.Any,...]],target_columns_to_types:t.Dict[str,exp.DataType],batch_start:int,batch_end:int,alias:str='t',source_columns:t.Optional[t.List[str]]=_A)->Query:return select_from_values_for_batch_range(values=values,target_columns_to_types=target_columns_to_types,batch_start=batch_start,batch_end=batch_end,alias=alias,source_columns=source_columns)
	def _insert_overwrite_by_condition(self,table_name:TableName,source_queries:t.List[SourceQuery],target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,where:t.Optional[exp.Condition]=_A,insert_overwrite_strategy_override:t.Optional[InsertOverwriteStrategy]=_A,**kwargs:t.Any)->_A:
		table=exp.to_table(table_name);insert_overwrite_strategy=insert_overwrite_strategy_override or self.INSERT_OVERWRITE_STRATEGY
		with self.transaction(condition=len(source_queries)>0 or insert_overwrite_strategy.is_delete_insert):
			target_columns_to_types=target_columns_to_types or self.columns(table_name)
			for(i,source_query)in enumerate(source_queries):
				with source_query as query:
					query=self._order_projections_and_filter(query,target_columns_to_types,where=where)
					if i>0 or insert_overwrite_strategy.is_delete_insert:
						if i==0:self.delete_from(table_name,where=where or exp.true())
						self._insert_append_query(table_name,query,target_columns_to_types=target_columns_to_types,order_projections=_B)
					elif insert_overwrite_strategy.is_merge:columns=[exp.column(col)for col in target_columns_to_types];when_not_matched_by_source=exp.When(matched=_B,source=_C,condition=where,then=exp.Delete());when_not_matched_by_target=exp.When(matched=_B,source=_B,then=exp.Insert(this=exp.Tuple(expressions=columns),expression=exp.Tuple(expressions=columns)));self._merge(target_table=table_name,query=query,on=exp.false(),whens=exp.Whens(expressions=[when_not_matched_by_source,when_not_matched_by_target]))
					else:
						insert_exp=exp.insert(query,table,columns=list(target_columns_to_types)if not insert_overwrite_strategy.is_replace_where else _A,overwrite=insert_overwrite_strategy.is_insert_overwrite)
						if insert_overwrite_strategy.is_replace_where:insert_exp.set('where',where or exp.true())
						self.execute(insert_exp,track_rows_processed=_C)
	def update_table(self,table_name:TableName,properties:t.Dict[str,t.Any],where:t.Optional[str|exp.Condition]=_A)->_A:self.execute(exp.update(table_name,properties,where=where))
	def _merge(self,target_table:TableName,query:Query,on:exp.Expression,whens:exp.Whens)->_A:this=exp.alias_(exp.to_table(target_table),alias=MERGE_TARGET_ALIAS,table=_C);using=exp.alias_(exp.Subquery(this=query),alias=MERGE_SOURCE_ALIAS,copy=_B,table=_C);self.execute(exp.Merge(this=this,using=using,on=on,whens=whens),track_rows_processed=_C)
	def scd_type_2_by_time(self,target_table:TableName,source_table:QueryOrDF,unique_key:t.Sequence[exp.Expression],valid_from_col:exp.Column,valid_to_col:exp.Column,execution_time:t.Union[TimeLike,exp.Column],updated_at_col:exp.Column,invalidate_hard_deletes:bool=_C,updated_at_as_valid_from:bool=_B,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,truncate:bool=_B,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:self._scd_type_2(target_table=target_table,source_table=source_table,unique_key=unique_key,valid_from_col=valid_from_col,valid_to_col=valid_to_col,execution_time=execution_time,updated_at_col=updated_at_col,invalidate_hard_deletes=invalidate_hard_deletes,updated_at_as_valid_from=updated_at_as_valid_from,target_columns_to_types=target_columns_to_types,table_description=table_description,column_descriptions=column_descriptions,truncate=truncate,source_columns=source_columns,**kwargs)
	def scd_type_2_by_column(self,target_table:TableName,source_table:QueryOrDF,unique_key:t.Sequence[exp.Expression],valid_from_col:exp.Column,valid_to_col:exp.Column,execution_time:t.Union[TimeLike,exp.Column],check_columns:t.Union[exp.Star,t.Sequence[exp.Expression]],invalidate_hard_deletes:bool=_C,execution_time_as_valid_from:bool=_B,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,truncate:bool=_B,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:self._scd_type_2(target_table=target_table,source_table=source_table,unique_key=unique_key,valid_from_col=valid_from_col,valid_to_col=valid_to_col,execution_time=execution_time,check_columns=check_columns,target_columns_to_types=target_columns_to_types,invalidate_hard_deletes=invalidate_hard_deletes,execution_time_as_valid_from=execution_time_as_valid_from,table_description=table_description,column_descriptions=column_descriptions,truncate=truncate,source_columns=source_columns,**kwargs)
	def _scd_type_2(self,target_table:TableName,source_table:QueryOrDF,unique_key:t.Sequence[exp.Expression],valid_from_col:exp.Column,valid_to_col:exp.Column,execution_time:t.Union[TimeLike,exp.Column],invalidate_hard_deletes:bool=_C,updated_at_col:t.Optional[exp.Column]=_A,check_columns:t.Optional[t.Union[exp.Star,t.Sequence[exp.Expression]]]=_A,updated_at_as_valid_from:bool=_B,execution_time_as_valid_from:bool=_B,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,column_descriptions:t.Optional[t.Dict[str,str]]=_A,truncate:bool=_B,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:
		L='deleted';K='inserted_rows';J='updated_rows';I='COALESCE';H='left';G='table';F='static';E='latest_deleted';D='source';C='joined';B='_exists';A='latest'
		def remove_managed_columns(cols_to_types:t.Dict[str,exp.DataType])->t.Dict[str,exp.DataType]:return{k:v for(k,v)in cols_to_types.items()if k not in{valid_from_name,valid_to_name}}
		valid_from_name=valid_from_col.name;valid_to_name=valid_to_col.name;target_columns_to_types=target_columns_to_types or self.columns(target_table)
		if valid_from_name not in target_columns_to_types or valid_to_name not in target_columns_to_types or not columns_to_types_all_known(target_columns_to_types):target_columns_to_types=self.columns(target_table)
		unmanaged_columns_to_types=remove_managed_columns(target_columns_to_types)if target_columns_to_types else _A;source_queries,unmanaged_columns_to_types=self._get_source_queries_and_columns_to_types(source_table,unmanaged_columns_to_types,target_table=target_table,batch_size=0,source_columns=source_columns);updated_at_name=updated_at_col.name if updated_at_col else _A
		if not target_columns_to_types:raise VulcanError(f"Could not get columns_to_types. Does {target_table} exist?")
		unmanaged_columns_to_types=unmanaged_columns_to_types or remove_managed_columns(target_columns_to_types)
		if not unique_key:raise VulcanError('unique_key must be provided for SCD Type 2')
		if check_columns and updated_at_col:raise VulcanError('Cannot use both `check_columns` and `updated_at_name` for SCD Type 2')
		if check_columns and updated_at_as_valid_from:raise VulcanError('Cannot use both `check_columns` and `updated_at_as_valid_from` for SCD Type 2')
		if execution_time_as_valid_from and not check_columns:raise VulcanError('Cannot use `execution_time_as_valid_from` without `check_columns` for SCD Type 2')
		if updated_at_name and updated_at_name not in target_columns_to_types:raise VulcanError(f"Column {updated_at_name} not found in {target_table}. Table must contain an `updated_at` timestamp for SCD Type 2")
		time_data_type=target_columns_to_types[valid_from_name];select_source_columns:t.List[t.Union[str,exp.Alias]]=[col for col in unmanaged_columns_to_types if col!=updated_at_name];table_columns=[exp.column(c,quoted=_C)for c in target_columns_to_types]
		if updated_at_name:select_source_columns.append(exp.cast(updated_at_col,time_data_type).as_(updated_at_col.this))
		if check_columns:
			if isinstance(seq_get(ensure_list(check_columns),0),exp.Star):check_columns=[exp.column(col)for col in unmanaged_columns_to_types]
		execution_ts=exp.cast(execution_time,time_data_type,dialect=self.dialect)if isinstance(execution_time,exp.Column)else to_time_column(execution_time,time_data_type,self.dialect,nullable=_C)
		if updated_at_as_valid_from:
			if not updated_at_col:raise VulcanError('Cannot use `updated_at_as_valid_from` without `updated_at_name` for SCD Type 2')
			update_valid_from_start:t.Union[str,exp.Expression]=updated_at_col
		elif check_columns and(execution_time_as_valid_from or not truncate):update_valid_from_start=execution_ts
		else:update_valid_from_start=to_time_column('1970-01-01 00:00:00+00:00',time_data_type,self.dialect,nullable=_C)
		insert_valid_from_start=execution_ts if check_columns else updated_at_col;delete_check=exp.column(B,C).is_(exp.Null())if invalidate_hard_deletes else _A;prefixed_valid_to_col=valid_to_col.copy();prefixed_valid_to_col.this.set(_D,f"t_{prefixed_valid_to_col.name}");prefixed_valid_from_col=valid_from_col.copy();prefixed_valid_from_col.this.set(_D,f"t_{valid_from_col.name}")
		if check_columns:
			row_check_conditions=[]
			for col in check_columns:
				col_qualified=col.copy();col_qualified.set(G,exp.to_identifier(C));t_col=col_qualified.copy()
				for column in t_col.find_all(exp.Column):column.this.set(_D,f"t_{column.name}")
				row_check_conditions.extend([col_qualified.neq(t_col),exp.and_(t_col.is_(exp.Null()),col_qualified.is_(exp.Null()).not_()),exp.and_(t_col.is_(exp.Null()).not_(),col_qualified.is_(exp.Null()))])
			row_value_check=exp.or_(*row_check_conditions);unique_key_conditions=[]
			for key in unique_key:
				key_qualified=key.copy();key_qualified.set(G,exp.to_identifier(C));t_key=key_qualified.copy()
				for col in t_key.find_all(exp.Column):col.this.set(_D,f"t_{col.name}")
				unique_key_conditions.extend([t_key.is_(exp.Null()).not_(),key_qualified.is_(exp.Null()).not_()])
			unique_key_check=exp.and_(*unique_key_conditions);updated_row_filter=exp.and_(unique_key_check,row_value_check);valid_to_case_stmt=exp.Case().when(exp.and_(exp.or_(delete_check,updated_row_filter)),execution_ts).else_(prefixed_valid_to_col).as_(valid_to_col.this);valid_from_case_stmt=exp.func(I,prefixed_valid_from_col,update_valid_from_start).as_(valid_from_col.this)
		else:
			assert updated_at_col is not _A;updated_at_col_qualified=updated_at_col.copy();updated_at_col_qualified.set(G,exp.to_identifier(C));prefixed_updated_at_col=updated_at_col_qualified.copy();prefixed_updated_at_col.this.set(_D,f"t_{updated_at_col_qualified.name}");updated_row_filter=updated_at_col_qualified>prefixed_updated_at_col;valid_to_case_stmt_builder=exp.Case().when(updated_row_filter,updated_at_col_qualified)
			if delete_check:valid_to_case_stmt_builder=valid_to_case_stmt_builder.when(delete_check,execution_ts)
			valid_to_case_stmt=valid_to_case_stmt_builder.else_(prefixed_valid_to_col).as_(valid_to_col.this);valid_from_case_stmt=exp.Case().when(exp.and_(prefixed_valid_from_col.is_(exp.Null()),exp.column(B,E).is_(exp.Null()).not_()),exp.Case().when(exp.column(valid_to_col.this,E)>updated_at_col,exp.column(valid_to_col.this,E)).else_(updated_at_col)).when(prefixed_valid_from_col.is_(exp.Null()),update_valid_from_start).else_(prefixed_valid_from_col).as_(valid_from_col.this)
		existing_rows_query=exp.select(*table_columns,exp.true().as_(B)).from_(target_table)
		if truncate:existing_rows_query=existing_rows_query.limit(0)
		with source_queries[0]as source_query:
			prefixed_columns_to_types=[]
			for column in target_columns_to_types:prefixed_col=exp.column(column).copy();prefixed_col.this.set(_D,f"t_{prefixed_col.name}");prefixed_columns_to_types.append(prefixed_col)
			prefixed_unmanaged_columns=[]
			for column in unmanaged_columns_to_types:prefixed_col=exp.column(column).copy();prefixed_col.this.set(_D,f"t_{prefixed_col.name}");prefixed_unmanaged_columns.append(prefixed_col)
			query=exp.Select().select(*table_columns).from_(F).union(exp.select(*table_columns).from_(J),distinct=_B).union(exp.select(*table_columns).from_(K),distinct=_B).with_(D,exp.select(exp.true().as_(B),*select_source_columns).distinct(*unique_key).from_(self.use_server_nulls_for_unmatched_after_join(source_query).subquery('raw_source'))).with_(F,existing_rows_query.where(valid_to_col.is_(exp.Null()).not_())).with_(A,existing_rows_query.where(valid_to_col.is_(exp.Null()))).with_(L,exp.select(*[exp.column(col,F)for col in target_columns_to_types]).from_(F).join(A,on=exp.and_(*[add_table(key,F).eq(add_table(key,A))for key in unique_key]),join_type=H).where(exp.column(valid_to_col.this,A).is_(exp.Null()))).with_(E,exp.select(exp.true().as_(B),*(part.as_(f"_key{i}")for(i,part)in enumerate(unique_key)),exp.Max(this=valid_to_col).as_(valid_to_col.this)).from_(L).group_by(*unique_key)).with_(C,exp.select(exp.column(B,table=D).as_(B),*(exp.column(col,table=A).as_(prefixed_columns_to_types[i].this)for(i,col)in enumerate(target_columns_to_types)),*(exp.column(col,table=D).as_(col)for col in unmanaged_columns_to_types)).from_(A).join(D,on=exp.and_(*[add_table(key,A).eq(add_table(key,D))for key in unique_key]),join_type=H).union(exp.select(exp.column(B,table=D).as_(B),*(exp.column(col,table=A).as_(prefixed_columns_to_types[i].this)for(i,col)in enumerate(target_columns_to_types)),*(exp.column(col,table=D).as_(col)for col in unmanaged_columns_to_types)).from_(A).join(D,on=exp.and_(*[add_table(key,A).eq(add_table(key,D))for key in unique_key]),join_type='right').where(exp.column(B,table=A).is_(exp.Null())),distinct=_B)).with_(J,exp.select(*(exp.func(I,exp.column(prefixed_unmanaged_columns[i].this,table=C),exp.column(col,table=C)).as_(col)for(i,col)in enumerate(unmanaged_columns_to_types)),valid_from_case_stmt,valid_to_case_stmt).from_(C).join(E,on=exp.and_(*[add_table(part,C).eq(exp.column(f"_key{i}",E))for(i,part)in enumerate(unique_key)]),join_type=H)).with_(K,exp.select(*unmanaged_columns_to_types,insert_valid_from_start.as_(valid_from_col.this),to_time_column(exp.null(),time_data_type,self.dialect,nullable=_C).as_(valid_to_col.this)).from_(C).where(updated_row_filter));self.replace_query(target_table,self.ensure_nulls_for_unmatched_after_join(query),target_columns_to_types=target_columns_to_types,table_description=table_description,column_descriptions=column_descriptions,**kwargs)
	def merge(self,target_table:TableName,source_table:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],unique_key:t.Sequence[exp.Expression],when_matched:t.Optional[exp.Whens]=_A,merge_filter:t.Optional[exp.Expression]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->_A:
		source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(source_table,target_columns_to_types,target_table=target_table,source_columns=source_columns);target_columns_to_types=target_columns_to_types or self.columns(target_table);on=exp.and_(*(add_table(part,MERGE_TARGET_ALIAS).eq(add_table(part,MERGE_SOURCE_ALIAS))for part in unique_key))
		if merge_filter:on=exp.and_(merge_filter,on)
		if not when_matched:match_expressions=[exp.When(matched=_C,source=_B,then=exp.Update(expressions=[exp.column(col,MERGE_TARGET_ALIAS).eq(exp.column(col,MERGE_SOURCE_ALIAS))for col in target_columns_to_types]))]
		else:match_expressions=when_matched.copy().expressions
		match_expressions.append(exp.When(matched=_B,source=_B,then=exp.Insert(this=exp.Tuple(expressions=[exp.column(col)for col in target_columns_to_types]),expression=exp.Tuple(expressions=[exp.column(col,MERGE_SOURCE_ALIAS)for col in target_columns_to_types]))))
		for source_query in source_queries:
			with source_query as query:self._merge(target_table=target_table,query=query,on=on,whens=exp.Whens(expressions=match_expressions))
	def rename_table(self,old_table_name:TableName,new_table_name:TableName)->_A:
		new_table=exp.to_table(new_table_name)
		if new_table.catalog:
			old_table=exp.to_table(old_table_name);catalog=old_table.catalog or self.get_current_catalog()
			if catalog!=new_table.catalog:raise UnsupportedCatalogOperationError('Tried to rename table across catalogs which is not supported')
		self._rename_table(old_table_name,new_table_name);self._clear_data_object_cache(old_table_name);self._clear_data_object_cache(new_table_name)
	def get_data_object(self,target_name:TableName,safe_to_cache:bool=_B)->t.Optional[DataObject]:
		target_table=exp.to_table(target_name);existing_data_objects=self.get_data_objects(schema_(target_table.db,target_table.catalog),{target_table.name},safe_to_cache=safe_to_cache)
		if existing_data_objects:return existing_data_objects[0]
	def get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A,safe_to_cache:bool=_B)->t.List[DataObject]:
		if object_names is not _A:
			if not object_names:return[]
			target_schema=to_schema(schema_name);cached_objects=[];missing_names=set()
			for name in object_names:
				cache_key=_get_data_object_cache_key(target_schema.catalog,target_schema.db,name)
				if cache_key in self._data_object_cache:
					logger.debug('Data object cache hit: %s',cache_key);data_object=self._data_object_cache[cache_key]
					if data_object:cached_objects.append(data_object)
				else:logger.debug('Data object cache miss: %s',cache_key);missing_names.add(name)
			if missing_names:
				object_names_list=list(missing_names);batches=[object_names_list[i:i+self.DATA_OBJECT_FILTER_BATCH_SIZE]for i in range(0,len(object_names_list),self.DATA_OBJECT_FILTER_BATCH_SIZE)];fetched_objects=[];fetched_object_names=set()
				for batch in batches:
					objects=self._get_data_objects(schema_name,set(batch))
					for obj in objects:
						if safe_to_cache:cache_key=_get_data_object_cache_key(obj.catalog,obj.schema_name,obj.name);self._data_object_cache[cache_key]=obj
						fetched_objects.append(obj);fetched_object_names.add(obj.name)
				if safe_to_cache:
					for missing_name in missing_names-fetched_object_names:cache_key=_get_data_object_cache_key(target_schema.catalog,target_schema.db,missing_name);self._data_object_cache[cache_key]=_A
				return cached_objects+fetched_objects
			return cached_objects
		fetched_objects=self._get_data_objects(schema_name)
		if safe_to_cache:
			for obj in fetched_objects:cache_key=_get_data_object_cache_key(obj.catalog,obj.schema_name,obj.name);self._data_object_cache[cache_key]=obj
		return fetched_objects
	def fetchone(self,query:t.Union[exp.Expression,str],ignore_unsupported_errors:bool=_B,quote_identifiers:bool=_B)->t.Optional[t.Tuple]:
		with self.transaction():self.execute(query,ignore_unsupported_errors=ignore_unsupported_errors,quote_identifiers=quote_identifiers);return self.cursor.fetchone()
	def fetchall(self,query:t.Union[exp.Expression,str],ignore_unsupported_errors:bool=_B,quote_identifiers:bool=_B)->t.List[t.Tuple]:
		with self.transaction():self.execute(query,ignore_unsupported_errors=ignore_unsupported_errors,quote_identifiers=quote_identifiers);return self.cursor.fetchall()
	def _fetch_native_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_B)->DF:
		with self.transaction():self.execute(query,quote_identifiers=quote_identifiers);return self.cursor.fetchdf()
	def _fetch_native_df_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_B)->DF:
		with self.transaction():self.execute(query,params=params,quote_identifiers=quote_identifiers);return self.cursor.fetchdf()
	def _native_df_to_pandas_df(self,query_or_df:QueryOrDF)->t.Union[Query,pd.DataFrame]:
		import pandas as pd
		if isinstance(query_or_df,(exp.Query,pd.DataFrame)):return query_or_df
		raise NotImplementedError(f"Unable to convert {type(query_or_df)} to Pandas")
	def fetchdf(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_B)->pd.DataFrame:
		import pandas as pd;df=self._fetch_native_df(query,quote_identifiers=quote_identifiers)
		if not isinstance(df,pd.DataFrame):raise NotImplementedError("The cursor's `fetch_native_df` method is not returning a pandas DataFrame. Need to update `fetchdf` so a Pandas DataFrame is returned")
		return df
	def fetchdf_with_params(self,query:t.Union[exp.Expression,str],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any]],quote_identifiers:bool=_B)->pd.DataFrame:
		import pandas as pd;df=self._fetch_native_df_with_params(query,params=params,quote_identifiers=quote_identifiers)
		if not isinstance(df,pd.DataFrame):raise NotImplementedError("The cursor's `fetch_native_df_with_params` method is not returning a pandas DataFrame. Need to update `fetchdf_with_params` so a Pandas DataFrame is returned")
		return df
	def fetch_pyspark_df(self,query:t.Union[exp.Expression,str],quote_identifiers:bool=_B)->PySparkDataFrame:raise NotImplementedError(f"Engine does not support PySpark DataFrames: {type(self)}")
	@property
	def wap_enabled(self)->bool:return self._extra_config.get('wap_enabled',_B)
	def wap_supported(self,table_name:TableName)->bool:return _B
	def wap_table_name(self,table_name:TableName,wap_id:str)->str:raise NotImplementedError(f"Engine does not support WAP: {type(self)}")
	def wap_prepare(self,table_name:TableName,wap_id:str)->str:raise NotImplementedError(f"Engine does not support WAP: {type(self)}")
	def wap_publish(self,table_name:TableName,wap_id:str)->_A:raise NotImplementedError(f"Engine does not support WAP: {type(self)}")
	def sync_grants_config(self,table:exp.Table,grants_config:GrantsConfig,table_type:DataObjectType=DataObjectType.TABLE)->_A:
		if not self.SUPPORTS_GRANTS:raise NotImplementedError(f"Engine does not support grants: {type(self)}")
		current_grants=self._get_current_grants_config(table);new_grants,revoked_grants=self._diff_grants_configs(grants_config,current_grants);revoke_exprs=self._revoke_grants_config_expr(table,revoked_grants,table_type);grant_exprs=self._apply_grants_config_expr(table,new_grants,table_type);dcl_exprs=revoke_exprs+grant_exprs
		if dcl_exprs:self.execute(dcl_exprs)
	@contextlib.contextmanager
	def transaction(self,condition:t.Optional[bool]=_A)->t.Iterator[_A]:
		if self._connection_pool.is_transaction_active or not self.SUPPORTS_TRANSACTIONS or condition is not _A and not condition:yield;return
		if self._pre_ping:
			try:logger.debug('Pinging the database to check the connection');self.ping()
			except Exception:logger.info('Connection to the database was lost. Reconnecting...');self._connection_pool.close()
		self._connection_pool.begin()
		try:yield
		except Exception as e:self._connection_pool.rollback();raise e
		else:self._connection_pool.commit()
	@contextlib.contextmanager
	def session(self,properties:SessionProperties)->t.Iterator[_A]:
		if self._is_session_active():yield;return
		self._begin_session(properties)
		try:yield
		finally:self._end_session()
	def _begin_session(self,properties:SessionProperties)->t.Any:0
	def _end_session(self)->_A:0
	def _is_session_active(self)->bool:return _B
	def execute(self,expressions:t.Union[str,exp.Expression,t.Sequence[exp.Expression]],params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any],_A]=_A,ignore_unsupported_errors:bool=_B,quote_identifiers:bool=_C,track_rows_processed:bool=_B,**kwargs:t.Any)->_A:
		to_sql_kwargs={'unsupported_level':ErrorLevel.IGNORE}if ignore_unsupported_errors else{}
		with self.transaction():
			for e in ensure_list(expressions):
				if isinstance(e,exp.Expression):self._check_identifier_length(e);sql=self._to_sql(e,quote=quote_identifiers,**to_sql_kwargs)
				else:sql=t.cast(str,e)
				sql=self._attach_correlation_id(sql);self._log_sql(sql,expression=e if isinstance(e,exp.Expression)else _A,quote_identifiers=quote_identifiers);self._execute(sql,track_rows_processed,params=params,**kwargs)
	def _attach_correlation_id(self,sql:str)->str:
		if not self.ATTACH_CORRELATION_ID:return sql
		parts=[]
		if self._user_agent:parts.append(f"{self._user_agent}")
		if self.correlation_id:parts.append(f"{self.correlation_id}")
		if parts:return f"/* {'; '.join(parts)} */ {sql}"
		return sql
	def _log_sql(self,sql:str,expression:t.Optional[exp.Expression]=_A,quote_identifiers:bool=_C)->_A:
		if not logger.isEnabledFor(self._execute_log_level):return
		sql_to_log=sql
		if expression is not _A and not isinstance(expression,exp.Query):
			values=expression.find(exp.Values)
			if values:values.set(_F,[exp.to_identifier('<REDACTED VALUES>')]);sql_to_log=self._to_sql(expression,quote=quote_identifiers)
		logger.log(self._execute_log_level,'[%s] Executing SQL: %s',self.dialect,sql_to_log)
	def _record_execution_stats(self,sql:str,rowcount:t.Optional[int]=_A,bytes_processed:t.Optional[int]=_A)->_A:
		if self._query_execution_tracker:self._query_execution_tracker.record_execution(sql,rowcount,bytes_processed)
	def _execute(self,sql:str,track_rows_processed:bool=_B,params:t.Union[t.Dict[str,t.Any],t.Sequence[t.Any],_A]=_A,**kwargs:t.Any)->_A:
		if params is not _A:
			from vulcan.core.engine_adapter._parameter_utils import normalize_query_params;out_style=self._dbapi_paramstyle()
			if out_style is _A:dialect_paramstyle_defaults={'duckdb':_G,'trino':_G,'fabric':_G,'databricks':_G,'mysql':_I};out_style=dialect_paramstyle_defaults.get(self.dialect,_I)
			if self.dialect=='snowflake'and not isinstance(params,dict):out_style=_G
			sql,params=normalize_query_params(sql,params,output_style=out_style);self.cursor.execute(sql,params,**kwargs)
		else:self.cursor.execute(sql,**kwargs)
		if self.SUPPORTS_QUERY_EXECUTION_TRACKING and track_rows_processed and self._query_execution_tracker and self._query_execution_tracker.is_tracking():
			if(rowcount:=getattr(self.cursor,'rowcount',_A))is not _A and rowcount is not _A:
				try:self._record_execution_stats(sql,int(rowcount))
				except(TypeError,ValueError):return
	@contextlib.contextmanager
	def temp_table(self,query_or_df:QueryOrDF,name:TableName='diff',target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,source_columns:t.Optional[t.List[str]]=_A,**kwargs:t.Any)->t.Iterator[exp.Table]:
		name=exp.to_table(name)
		if isinstance(name,exp.Table)and not name.catalog and name.db and self.default_catalog:name.set(_J,exp.parse_identifier(self.default_catalog))
		source_queries,target_columns_to_types=self._get_source_queries_and_columns_to_types(query_or_df,target_columns_to_types=target_columns_to_types,target_table=name,source_columns=source_columns)
		with self.transaction():
			table=self._get_temp_table(name)
			if table.db:self.create_schema(schema_(table.args['db'],table.args.get(_J)))
			self._create_table_from_source_queries(table,source_queries,target_columns_to_types,exists=_C,table_description=_A,column_descriptions=_A,track_rows_processed=_B,**kwargs)
			try:yield table
			finally:self.drop_table(table)
	def _table_or_view_properties_to_expressions(self,table_or_view_properties:t.Optional[t.Dict[str,exp.Expression]]=_A)->t.List[exp.Property]:
		if not table_or_view_properties:return[]
		return[exp.Property(this=key,value=value.copy())for(key,value)in table_or_view_properties.items()]
	def _build_partitioned_by_exp(self,partitioned_by:t.List[exp.Expression],*,partition_interval_unit:t.Optional[IntervalUnit]=_A,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,catalog_name:t.Optional[str]=_A,**kwargs:t.Any)->t.Optional[t.Union[exp.PartitionedByProperty,exp.Property]]:0
	def _build_clustered_by_exp(self,clustered_by:t.List[exp.Expression],**kwargs:t.Any)->t.Optional[exp.Cluster]:0
	def _build_table_properties_exp(self,catalog_name:t.Optional[str]=_A,table_format:t.Optional[str]=_A,storage_format:t.Optional[str]=_A,partitioned_by:t.Optional[t.List[exp.Expression]]=_A,partition_interval_unit:t.Optional[IntervalUnit]=_A,clustered_by:t.Optional[t.List[exp.Expression]]=_A,table_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]]=_A,table_description:t.Optional[str]=_A,table_kind:t.Optional[str]=_A,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties:t.List[exp.Expression]=[]
		if table_description:properties.append(exp.SchemaCommentProperty(this=exp.Literal.string(self._truncate_table_comment(table_description))))
		if table_properties:table_type=self._pop_creatable_type_from_properties(table_properties);properties.extend(ensure_list(table_type))
		if properties:return exp.Properties(expressions=properties)
	def _build_view_properties_exp(self,view_properties:t.Optional[t.Dict[str,exp.Expression]]=_A,table_description:t.Optional[str]=_A,**kwargs:t.Any)->t.Optional[exp.Properties]:
		properties:t.List[exp.Expression]=[]
		if table_description:properties.append(exp.SchemaCommentProperty(this=exp.Literal.string(self._truncate_table_comment(table_description))))
		if properties:return exp.Properties(expressions=properties)
	def _truncate_comment(self,comment:str,length:t.Optional[int])->str:return comment[:length]if length else comment
	def _truncate_table_comment(self,comment:str)->str:return self._truncate_comment(comment,self.MAX_TABLE_COMMENT_LENGTH)
	def _truncate_column_comment(self,comment:str)->str:return self._truncate_comment(comment,self.MAX_COLUMN_COMMENT_LENGTH)
	def _to_sql(self,expression:exp.Expression,quote:bool=_C,**kwargs:t.Any)->str:
		sql_gen_kwargs={'dialect':self.dialect,'pretty':self._pretty_sql,'comments':_B,**self._sql_gen_kwargs,**kwargs};expression=expression.copy()
		if quote:quote_identifiers(expression)
		return expression.sql(**sql_gen_kwargs,copy=_B)
	def _clear_data_object_cache(self,table_name:t.Optional[TableName]=_A)->_A:
		if table_name is _A:logger.debug('Clearing entire data object cache');self._data_object_cache.clear()
		else:table=exp.to_table(table_name);cache_key=_get_data_object_cache_key(table.catalog,table.db,table.name);logger.debug('Clearing data object cache key: %s',cache_key);self._data_object_cache.pop(cache_key,_A)
	def _get_data_objects(self,schema_name:SchemaName,object_names:t.Optional[t.Set[str]]=_A)->t.List[DataObject]:raise NotImplementedError
	def _get_temp_table(self,table:TableName,table_only:bool=_B,quoted:bool=_C)->exp.Table:
		table=t.cast(exp.Table,exp.to_table(table).copy());table.set(_D,exp.to_identifier(f"__temp_{table.name}_{random_id(short=_C)}",quoted=quoted))
		if table_only:table.set('db',_A);table.set(_J,_A)
		return table
	def _order_projections_and_filter(self,query:Query,target_columns_to_types:t.Dict[str,exp.DataType],where:t.Optional[exp.Expression]=_A,coerce_types:bool=_B)->Query:
		A='with'
		if not isinstance(query,exp.Query)or not where and not coerce_types and query.named_selects==list(target_columns_to_types):return query
		query=t.cast(exp.Query,query.copy());with_=query.args.pop(A,_A);select_exprs:t.List[exp.Expression]=[exp.column(c,quoted=_C)for c in target_columns_to_types]
		if coerce_types and columns_to_types_all_known(target_columns_to_types):select_exprs=[exp.cast(select_exprs[i],col_tpe).as_(col,quoted=_C)for(i,(col,col_tpe))in enumerate(target_columns_to_types.items())]
		query=exp.select(*select_exprs).from_(query.subquery('_subquery',copy=_B),copy=_B)
		if where:query=query.where(where,copy=_B)
		if with_:query.set(A,with_)
		return query
	def _truncate_table(self,table_name:TableName)->_A:table=exp.to_table(table_name);self.execute(f"TRUNCATE TABLE {table.sql(dialect=self.dialect,identify=_C)}")
	def drop_data_object_on_type_mismatch(self,data_object:t.Optional[DataObject],expected_type:DataObjectType)->bool:
		if data_object is _A or data_object.type==expected_type:return _B
		logger.warning("Target data object '%s' is a %s and not a %s, dropping it",data_object.to_table().sql(dialect=self.dialect),data_object.type.value,expected_type.value);self.drop_data_object(data_object);return _C
	def _replace_by_key(self,target_table:TableName,source_table:QueryOrDF,target_columns_to_types:t.Optional[t.Dict[str,exp.DataType]],key:t.Sequence[exp.Expression],is_unique_key:bool,source_columns:t.Optional[t.List[str]]=_A)->_A:
		if target_columns_to_types is _A:target_columns_to_types=self.columns(target_table)
		temp_table=self._get_temp_table(target_table);key_exp=exp.func('CONCAT_WS',"'__SQLMESH_DELIM__'",*key)if len(key)>1 else key[0];column_names=list(target_columns_to_types or[])
		with self.transaction():
			self.ctas(temp_table,source_table,target_columns_to_types=target_columns_to_types,exists=_B,source_columns=source_columns)
			try:
				delete_query=exp.select(key_exp).from_(temp_table);insert_query=self._select_columns(target_columns_to_types).from_(temp_table)
				if not is_unique_key:delete_query=delete_query.distinct()
				else:insert_query=insert_query.distinct(*key)
				insert_statement=exp.insert(insert_query,target_table,columns=column_names);delete_filter=key_exp.isin(query=delete_query)
				if not self.INSERT_OVERWRITE_STRATEGY.is_replace_where:self.delete_from(target_table,delete_filter)
				else:insert_statement.set('where',delete_filter);insert_statement.set(_D,exp.to_table(target_table))
				self.execute(insert_statement,track_rows_processed=_C)
			finally:self.drop_table(temp_table)
	def _build_create_comment_table_exp(self,table:exp.Table,table_comment:str,table_kind:str)->exp.Comment|str:return exp.Comment(this=table,kind=table_kind,expression=exp.Literal.string(self._truncate_table_comment(table_comment)))
	def _create_table_comment(self,table_name:TableName,table_comment:str,table_kind:str=_E)->_A:
		table=exp.to_table(table_name)
		try:self.execute(self._build_create_comment_table_exp(table,table_comment,table_kind))
		except Exception:logger.warning(f"Table comment for '{table.alias_or_name}' not registered - this may be due to limited permissions",exc_info=_C)
	def _build_create_comment_column_exp(self,table:exp.Table,column_name:str,column_comment:str,table_kind:str=_E)->exp.Comment|str:return exp.Comment(this=exp.column(column_name,*reversed(table.parts)),kind='COLUMN',expression=exp.Literal.string(self._truncate_column_comment(column_comment)))
	def _create_column_comments(self,table_name:TableName,column_comments:t.Dict[str,str],table_kind:str=_E,materialized_view:bool=_B)->_A:
		table=exp.to_table(table_name)
		for(col,comment)in column_comments.items():
			try:self.execute(self._build_create_comment_column_exp(table,col,comment,table_kind))
			except Exception:logger.warning(f"Column comments for column '{col}' in table '{table.alias_or_name}' not registered - this may be due to limited permissions",exc_info=_C)
	def _create_table_like(self,target_table_name:TableName,source_table_name:TableName,exists:bool,**kwargs:t.Any)->_A:self.create_table(target_table_name,self.columns(source_table_name),exists=exists)
	def _rename_table(self,old_table_name:TableName,new_table_name:TableName)->_A:self.execute(exp.rename_table(old_table_name,new_table_name))
	def ensure_nulls_for_unmatched_after_join(self,query:Query)->Query:return query
	def use_server_nulls_for_unmatched_after_join(self,query:Query)->Query:return query
	def ping(self)->_A:
		try:self._execute(exp.select('1').sql(dialect=self.dialect))
		finally:self._connection_pool.close_cursor()
	@classmethod
	def _select_columns(cls,columns:t.Iterable[str],source_columns:t.Optional[t.List[str]]=_A)->exp.Select:return exp.select(*(exp.column(c,quoted=_C)if c in(source_columns or columns)else exp.alias_(exp.Null(),c,quoted=_C)for c in columns))
	def _check_identifier_length(self,expression:exp.Expression)->_A:
		if self.MAX_IDENTIFIER_LENGTH is _A or not isinstance(expression,exp.DDL):return
		for identifier in expression.find_all(exp.Identifier):
			name=identifier.name;name_length=len(name)
			if name_length>self.MAX_IDENTIFIER_LENGTH:raise VulcanError(f"Identifier name '{name}' (length {name_length}) exceeds {self.dialect.capitalize()}'s max identifier limit of {self.MAX_IDENTIFIER_LENGTH} characters")
	def get_table_last_modified_ts(self,table_names:t.List[TableName])->t.List[int]:raise NotImplementedError
	@classmethod
	def _diff_grants_configs(cls,new_config:GrantsConfig,old_config:GrantsConfig)->t.Tuple[GrantsConfig,GrantsConfig]:
		def _diffs(config1:GrantsConfig,config2:GrantsConfig)->GrantsConfig:
			diffs:GrantsConfig={};cf_config2={k.casefold():{g.casefold()for g in v}for(k,v)in config2.items()}
			for(key,grantees)in config1.items():
				cf_key=key.casefold()
				if cf_key not in cf_config2:diffs[key]=grantees.copy();continue
				cf_grantees2=cf_config2[cf_key];diff_grantees=[]
				for grantee in grantees:
					if grantee.casefold()not in cf_grantees2:diff_grantees.append(grantee)
				if diff_grantees:diffs[key]=diff_grantees
			return diffs
		return _diffs(new_config,old_config),_diffs(old_config,new_config)
	def _get_current_grants_config(self,table:exp.Table)->GrantsConfig:
		if not self.SUPPORTS_GRANTS:raise NotImplementedError(f"Engine does not support grants: {type(self)}")
		raise NotImplementedError('Subclass must implement get_current_grants')
	def _apply_grants_config_expr(self,table:exp.Table,grants_config:GrantsConfig,table_type:DataObjectType=DataObjectType.TABLE)->t.List[exp.Expression]:
		if not self.SUPPORTS_GRANTS:raise NotImplementedError(f"Engine does not support grants: {type(self)}")
		raise NotImplementedError('Subclass must implement _apply_grants_config_expr')
	def _revoke_grants_config_expr(self,table:exp.Table,grants_config:GrantsConfig,table_type:DataObjectType=DataObjectType.TABLE)->t.List[exp.Expression]:
		if not self.SUPPORTS_GRANTS:raise NotImplementedError(f"Engine does not support grants: {type(self)}")
		raise NotImplementedError('Subclass must implement _revoke_grants_config_expr')
class EngineAdapterWithIndexSupport(EngineAdapter):SUPPORTS_INDEXES=_C
def _decoded_str(value:t.Union[str,bytes])->str:
	if isinstance(value,bytes):return value.decode('utf-8')
	return value
def _get_data_object_cache_key(catalog:t.Optional[str],schema_name:str,object_name:str)->str:catalog=f"{catalog}."if catalog else'';return f"{catalog}{schema_name}.{object_name}"