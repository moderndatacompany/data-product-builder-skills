from __future__ import annotations
from vulcan.core.config.base import BaseConfig
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import field_validator
class RunConfig(BaseConfig):
	environment_check_interval:int=30;environment_check_max_wait:int=21600
	@field_validator('environment_check_interval','environment_check_max_wait',mode='after')
	@classmethod
	def _validate_positive_int(cls,v:int)->int:
		if v<=0:raise ConfigError(f"Value must be a positive integer, got {v}")
		return v