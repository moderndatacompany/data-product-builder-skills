from __future__ import annotations
from vulcan.core.config.base import BaseConfig
class NameInferenceConfig(BaseConfig):infer_names:bool=False