from __future__ import annotations
_A=False
import typing as t
from pydantic import Field,SecretStr
from vulcan.core.config.base import BaseConfig
from vulcan.utils.pydantic import model_validator
class HeraConfig(BaseConfig):
	enabled:bool=_A;url:str='';token:t.Optional[SecretStr]=Field(default=None,repr=_A);verify_ssl:bool=_A
	@model_validator(mode='after')
	def _require_fields_when_enabled(self)->'HeraConfig':
		if self.enabled:
			if not self.url.strip():raise ValueError('hera.url is required when hera.enabled=true')
			if not self.token or not self.token.get_secret_value().strip():raise ValueError('hera.token is required when hera.enabled=true')
		return self