from __future__ import annotations
from vulcan.core.config.base import BaseConfig
from vulcan.utils.pydantic import model_validator
import typing as t
class PGQConfig(BaseConfig):
	concurrency_limit:int=5;batch_size:int=10;max_concurrent_tasks:int=20;requests_per_second:float=1e1;dequeue_timeout:int=5
	@model_validator(mode='after')
	def validate_max_concurrent_tasks(self)->t.Any:
		if self.max_concurrent_tasks<2*self.batch_size:raise ValueError(f"max_concurrent_tasks ({self.max_concurrent_tasks}) must be >= 2 * batch_size ({2*self.batch_size})")
		return self