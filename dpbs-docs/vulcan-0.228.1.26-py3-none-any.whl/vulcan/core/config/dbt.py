from vulcan.core.config.base import BaseConfig
class DbtConfig(BaseConfig):infer_state_schema_name:bool=False