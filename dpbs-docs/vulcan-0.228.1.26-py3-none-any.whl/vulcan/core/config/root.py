from __future__ import annotations
_N='heimdall'
_M='auto_categorize_changes'
_L='default_gateway'
_K='physical_schema_mapping'
_J='physical_schema_override'
_I='description'
_H='name'
_G='connection'
_F='notification_targets'
_E='gateways'
_D='after'
_C='before'
_B=False
_A=None
import pickle,re,typing as t,zlib,os
from pydantic import Field,field_validator
from pydantic.functional_validators import BeforeValidator
from sqlglot import exp
from sqlglot.helper import first
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from vulcan.cicd.config import CICDBotConfig
from vulcan.core import constants as c
from vulcan.core.console import get_console
from vulcan.core.config.common import DataProductAlignment,EnvironmentSuffixTarget,TableNamingConvention,VirtualEnvironmentMode
from vulcan.core.config.base import BaseConfig,UpdateStrategy
from vulcan.core.config.common import variables_validator,compile_regex_mapping
from vulcan.core.config.connection import ConnectionConfig,DuckDBConnectionConfig,SerializableConnectionConfig,connection_config_validator
from vulcan.core.config.format import FormatConfig
from vulcan.core.config.gateway import GatewayConfig
from vulcan.core.config.janitor import JanitorConfig
from vulcan.core.config.migration import MigrationConfig
from vulcan.core.config.model import ModelDefaultsConfig
from vulcan.core.config.naming import NameInferenceConfig as NameInferenceConfig
from vulcan.core.config.linter import LinterConfig as LinterConfig
from vulcan.core.config.plan import PlanConfig
from vulcan.core.config.run import RunConfig
from vulcan.core.config.dbt import DbtConfig
from vulcan.core.config.scheduler import BuiltInSchedulerConfig,SchedulerConfig,scheduler_config_validator
from vulcan.core.config.ui import UIConfig
from vulcan.core.config.object_store import ObjectStoreConfig
from vulcan.core.config.transpiler import TranspilerConfig
from vulcan.core.config.graphql import GraphQLConfig
from vulcan.core.config.pgq import PGQConfig
from vulcan.core.config.prometheus import PrometheusConfig
from vulcan.core.config.heimdall import HeimdallConfig
from vulcan.core.config.before_after import BeforeAfterEntry
from vulcan.core.config.hera import HeraConfig
from vulcan.core.loader import Loader,SqlMeshLoader
from vulcan.core.notification import NotificationTarget,validate_notification_target_config
from vulcan.core.types import Tag,Term
from vulcan.core.user import User
from schema.product import IssueTracker,Usage
from vulcan.utils.date import to_timestamp,now
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import model_validator
def match_merge_or_log_with_env(*,env_key:str,current_value:t.Any,config_label:str,match:bool,merge_tags:bool=_B,log_override_message:t.Optional[str]=_A)->t.Any:
	raw=os.getenv(env_key)
	if raw is _A:return current_value
	raw=raw.strip()
	if not raw:return current_value
	if merge_tags:
		raw_tags=[s.strip()for s in raw.split(',')];parsed_tags=[Tag(s)for s in raw_tags if s]
		if not parsed_tags:return list(current_value or[])
		existing=list(current_value or[]);existing_set={str(t)for t in existing};merged_set=existing_set|{str(t)for t in parsed_tags};merged=[Tag(t)for t in sorted(merged_set)]
		if log_override_message and(merged_set!=existing_set or len(existing)!=len(existing_set)):get_console().log_warning(log_override_message)
		return merged
	if match:
		if raw!=current_value:raise ConfigError(f"Config validation failed: config.yaml {config_label}='{current_value}' does not match {config_label} ='{raw}'.")
		return current_value
	if log_override_message and raw!=current_value and raw!=str(current_value or''):get_console().log_warning(f"{log_override_message} (env {env_key}='{raw}', config.yaml {config_label}='{current_value}')")
	return raw
def validate_no_past_ttl(v:str)->str:
	current_time=now()
	if to_timestamp(v,relative_base=current_time)<to_timestamp(current_time):raise ValueError(f"TTL '{v}' is in the past. Please specify a relative time in the future. Ex: `in 1 week` instead of `1 week`.")
	return v
def gateways_ensure_dict(value:t.Dict[str,t.Any])->t.Dict[str,t.Any]:
	try:
		if not isinstance(value,GatewayConfig):GatewayConfig.parse_obj(value)
		return{'':value}
	except Exception:
		if isinstance(value,dict):return{k.lower():v for(k,v)in value.items()}
		return value
def validate_regex_key_dict(value:t.Dict[str|re.Pattern,t.Any])->t.Dict[re.Pattern,t.Any]:return compile_regex_mapping(value)
if t.TYPE_CHECKING:from vulcan.core._typing import Self;NoPastTTLString=str;GatewayDict=t.Dict[str,GatewayConfig];RegexKeyDict=t.Dict[re.Pattern,str]
else:NoPastTTLString=t.Annotated[str,BeforeValidator(validate_no_past_ttl)];GatewayDict=t.Annotated[t.Dict[str,GatewayConfig],BeforeValidator(gateways_ensure_dict)];RegexKeyDict=t.Annotated[t.Dict[re.Pattern,str],BeforeValidator(validate_regex_key_dict)]
_VDE_FORBIDDEN_WAREHOUSE_TYPES=frozenset({'spark','trino'})
_DATA_PRODUCT_VERSION_PATTERN=re.compile('^(?:0|[1-9]\\d*)\\.(?:0|[1-9]\\d*)\\.(?:0|[1-9]\\d*)(?:-(?:0|[1-9]\\d*|\\d*[a-zA-Z-][0-9a-zA-Z-]*)(?:\\.(?:0|[1-9]\\d*|\\d*[a-zA-Z-][0-9a-zA-Z-]*))*)?(?:\\+[0-9a-zA-Z-]+(?:\\.[0-9a-zA-Z-]+)*)?$')
class Config(BaseConfig):
	gateways:GatewayDict={'':GatewayConfig()};default_connection:t.Optional[SerializableConnectionConfig]=_A;default_test_connection_:t.Optional[SerializableConnectionConfig]=Field(default=_A,alias='default_test_connection');default_scheduler:SchedulerConfig=BuiltInSchedulerConfig();default_gateway:str='';notification_targets:t.List[NotificationTarget]=[];name:str;tenant:t.Optional[str]=_A;display_name:t.Optional[str]=_A;description:str=Field(default='DataOS Vulcan Data Product. This is a default description for the data product.');domain:t.Optional[str]=_A;discoverable:bool=c.DEFAULT_DISCOVERABLE;version:str=c.DEFAULT_VERSION;alignment:DataProductAlignment=Field(default_factory=lambda:DataProductAlignment(c.DEFAULT_ALIGNMENT));tags:t.List[Tag]=[];terms:t.List[Term]=[];usage:Usage=Field(default_factory=Usage);issue_tracker:t.Optional[IssueTracker]=_A;hera:HeraConfig=Field(default_factory=HeraConfig);project:str='';snapshot_ttl:NoPastTTLString=c.DEFAULT_SNAPSHOT_TTL;environment_ttl:t.Optional[NoPastTTLString]=c.DEFAULT_ENVIRONMENT_TTL;ignore_patterns:t.List[str]=c.IGNORE_PATTERNS;time_column_format:str=c.DEFAULT_TIME_COLUMN_FORMAT;users:t.List[User]=[];model_defaults:ModelDefaultsConfig=ModelDefaultsConfig();pinned_environments:t.Set[str]=set();loader:t.Type[Loader]=SqlMeshLoader;loader_kwargs:t.Dict[str,t.Any]={};env_vars:t.Dict[str,str]={};username:str='';physical_schema_mapping:RegexKeyDict={};environment_suffix_target:EnvironmentSuffixTarget=EnvironmentSuffixTarget.default;physical_table_naming_convention:TableNamingConvention=TableNamingConvention.default;vde:bool=_B;virtual_environment_mode:VirtualEnvironmentMode=VirtualEnvironmentMode.default;gateway_managed_virtual_layer:bool=_B;infer_python_dependencies:bool=True;environment_catalog_mapping:RegexKeyDict={};default_target_environment:str=c.PROD;log_limit:int=c.DEFAULT_LOG_LIMIT;cicd_bot:t.Optional[CICDBotConfig]=_A;run:RunConfig=RunConfig();format:FormatConfig=FormatConfig();ui:UIConfig=UIConfig();plan:PlanConfig=PlanConfig();migration:MigrationConfig=MigrationConfig();model_naming:NameInferenceConfig=NameInferenceConfig();variables:t.Dict[str,t.Any]={};before_all:t.Optional[t.List[BeforeAfterEntry]]=_A;after_all:t.Optional[t.List[BeforeAfterEntry]]=_A;linter:LinterConfig=LinterConfig();janitor:JanitorConfig=JanitorConfig();cache_dir:t.Optional[str]=_A;dbt:t.Optional[DbtConfig]=_A;object_store:t.Optional[ObjectStoreConfig]=_A;transpiler:TranspilerConfig=TranspilerConfig();graphql:GraphQLConfig=GraphQLConfig();state:t.Optional[SerializableConnectionConfig]=_A;pgq:PGQConfig=PGQConfig();prometheus:PrometheusConfig=PrometheusConfig();heimdall:HeimdallConfig=HeimdallConfig()
	@field_validator('version')
	@classmethod
	def _validate_version_semver(cls,value:str)->str:
		stripped=value.strip()
		if not stripped:raise ValueError('version cannot be empty or whitespace')
		if not _DATA_PRODUCT_VERSION_PATTERN.fullmatch(stripped):raise ValueError('version must be a valid SemVer 2.0 string (e.g. 0.0.0, 1.2.3, 1.0.0-alpha.1+build.42)')
		return stripped
	@field_validator('domain')
	@classmethod
	def _validate_domain(cls,value:t.Optional[str])->t.Optional[str]:
		if value is _A:return value
		stripped=value.strip()
		if not stripped:raise ValueError('domain cannot be empty or whitespace')
		return stripped
	@field_validator(_L,mode=_C)
	@classmethod
	def _normalize_default_gateway(cls,value:t.Any)->t.Any:
		if isinstance(value,str):return value.lower()
		return value
	@field_validator(_F,mode=_D)
	@classmethod
	def _validate_notification_targets(cls,value:t.List[NotificationTarget])->t.List[NotificationTarget]:validate_notification_target_config(value);return value
	@staticmethod
	def _get_gateway_raw_config(gateways:t.Any,name:str)->t.Optional[t.Dict[str,t.Any]]:
		if not isinstance(gateways,dict):return
		if name=='':gateway=gateways.get('');return gateway if isinstance(gateway,dict)else _A
		lowered=name.lower()
		for(key,gateway)in gateways.items():
			if isinstance(key,str)and key.lower()==lowered and isinstance(gateway,dict):return gateway
	@model_validator(mode=_C)
	@classmethod
	def _capture_depot_address(cls,values:t.Any)->t.Any:
		if not isinstance(values,dict):return values
		gateways=values.get(_E,{})
		if not isinstance(gateways,dict):return values
		default_gw=str(values.get(_L,'')).lower()
		for gw_key in(default_gw,'default',''):
			gw=cls._get_gateway_raw_config(gateways,gw_key)
			if gw is not _A:
				conn=gw.get(_G)
				if isinstance(conn,dict)and conn.get('type')=='depot':
					address=conn.get('address','')
					if address:os.environ['DATAOS_SOURCE_DEPOT_ADDRESS']=address
				break
		return values
	@model_validator(mode=_D)
	def _validate_dataos_name_env(self)->'Self':self.name=match_merge_or_log_with_env(env_key='DATAOS_RESOURCE_NAME',current_value=self.name,config_label=_H,match=_B,log_override_message='DATAOS_RESOURCE_NAME is set, overriding config.yaml name for data product identity.');self.tenant=(os.getenv('DATAOS_TENANT_ID')or'').strip()or self.tenant;self.description=match_merge_or_log_with_env(env_key='DATAOS_RESOURCE_DESCRIPTION',current_value=self.description,config_label=_I,match=_B,log_override_message='resource description is provided in vulcan resource, config.yaml description will be overwritten with the resource description.');self.tags=match_merge_or_log_with_env(env_key='DATAOS_RESOURCE_TAGS',current_value=self.tags or[],config_label='tags',match=_B,merge_tags=True,log_override_message='resource tags are provided in vulcan resource, config.yaml tags will be merged with the resource tags.');return self
	_FIELD_UPDATE_STRATEGY:t.ClassVar[t.Dict[str,UpdateStrategy]]={_E:UpdateStrategy.NESTED_UPDATE,_F:UpdateStrategy.EXTEND,'ignore_patterns':UpdateStrategy.EXTEND,'users':UpdateStrategy.EXTEND,'model_defaults':UpdateStrategy.NESTED_UPDATE,_M:UpdateStrategy.NESTED_UPDATE,'pinned_environments':UpdateStrategy.EXTEND,_J:UpdateStrategy.KEY_UPDATE,'run':UpdateStrategy.NESTED_UPDATE,'format':UpdateStrategy.NESTED_UPDATE,'ui':UpdateStrategy.NESTED_UPDATE,'loader_kwargs':UpdateStrategy.KEY_UPDATE,'plan':UpdateStrategy.NESTED_UPDATE,'before_all':UpdateStrategy.EXTEND,'after_all':UpdateStrategy.EXTEND,'linter':UpdateStrategy.NESTED_UPDATE,'dbt':UpdateStrategy.NESTED_UPDATE,'object_store':UpdateStrategy.NESTED_UPDATE,'transpiler':UpdateStrategy.NESTED_UPDATE,'graphql':UpdateStrategy.NESTED_UPDATE,'pgq':UpdateStrategy.NESTED_UPDATE,'analytics':UpdateStrategy.NESTED_UPDATE,'prometheus':UpdateStrategy.NESTED_UPDATE,_N:UpdateStrategy.NESTED_UPDATE};_connection_config_validator=connection_config_validator;_scheduler_config_validator=scheduler_config_validator;_variables_validator=variables_validator
	@model_validator(mode=_C)
	def _load_state_connection_from_file(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		import os,pathlib;from vulcan.utils.yaml import load as yaml_load;from vulcan.utils.errors import ConfigError;secret_dir=os.getenv('DATAOS_SECRET_DIR','/etc/dataos/secret');state_config_path=pathlib.Path(secret_dir)/f"state_connection_config.yaml"
		if state_config_path.exists()and state_config_path.is_file():
			try:
				state_config=yaml_load(state_config_path)
				if isinstance(state_config,dict)and _G in state_config:data['state']=state_config[_G];get_console().log_status_update(f"Loaded state connection from {state_config_path}")
			except Exception as e:raise ConfigError(f"Failed to load state connection from {state_config_path}: {e}")
		return data
	@model_validator(mode=_C)
	def _normalize_and_validate_fields(cls,data:t.Any)->t.Any:
		C='project';B='gateway';A='after_authorize'
		if not isinstance(data,dict):return data
		if _E not in data and B in data:data[_E]=data.pop(B)
		if A in data:
			after_authorize_hook=data.pop(A);heimdall=data.setdefault(_N,{})
			if isinstance(heimdall,dict):heimdall[A]=after_authorize_hook
		if _H not in data and C in data:data[_H]=data[C]
		if _I not in data:data[_I]=''
		for plan_deprecated in(_M,'include_unmodified'):
			if plan_deprecated in data:raise ConfigError(f"The `{plan_deprecated}` config is deprecated. Please use the `plan.{plan_deprecated}` config instead.")
		if _J in data:
			get_console().log_warning('`physical_schema_override` is deprecated. Please use `physical_schema_mapping` instead.')
			if _K in data:raise ConfigError('Only one of `physical_schema_override` and `physical_schema_mapping` can be specified.')
			physical_schema_override:t.Dict[str,str]=data.pop(_J);data[_K]={f"^{k}$":v for(k,v)in physical_schema_override.items()}
		return data
	def _validate_vde_warehouse_engines(self)->_A:
		if not self.vde or not isinstance(self.gateways,dict):return
		forbidden_list=', '.join(sorted(_VDE_FORBIDDEN_WAREHOUSE_TYPES))
		for(gw_name,gw)in self.gateways.items():
			conn=gw.connection or self.default_connection
			if conn is _A:continue
			if conn.type_ in _VDE_FORBIDDEN_WAREHOUSE_TYPES:label=repr(gw_name)if gw_name else"''";raise ConfigError(f"`vde: true` is not supported for engine types ({forbidden_list}); gateway {label} has `{conn.type_}`.")
	@model_validator(mode=_D)
	def _normalize_fields_after(self)->Self:
		dialect=self.model_defaults.dialect
		def _normalize_identifiers(key:str)->_A:setattr(self,key,{k:normalize_identifiers(v,dialect=dialect).name for(k,v)in getattr(self,key,{}).items()})
		if not self.name or not self.name.strip():raise ConfigError("The 'name' field is required and cannot be empty.")
		if not self.tenant or not self.tenant.strip():raise ConfigError('Tenant must be provided via DATAOS_TENANT_ID environment variable.')
		if self.tenant and not self.domain:raise ConfigError("The 'domain' field is required in config.yaml (e.g. domain: marketing).")
		if not self.description or not self.description.strip():raise ConfigError("The 'description' field is required and cannot be empty.")
		if not self.users:raise ConfigError("The 'users' field is required and must contain at least one user.")
		known_usernames=frozenset((user.username or'').strip()for user in self.users)-{''}
		if not(default_owner:=(self.model_defaults.owner or'').strip()):default_owner=(self.users[0].username or'').strip();self.model_defaults=self.model_defaults.model_copy(update={'owner':default_owner})
		if default_owner not in known_usernames:raise ConfigError(f"model_defaults.owner '{default_owner}' is not listed in config.users.")
		if self.name:self.project=self.name
		self.virtual_environment_mode=VirtualEnvironmentMode.FULL if self.vde else VirtualEnvironmentMode.DEV_ONLY;self._validate_vde_warehouse_engines()
		if self.environment_suffix_target==EnvironmentSuffixTarget.CATALOG and self.environment_catalog_mapping:raise ConfigError(f"'environment_suffix_target: catalog' is mutually exclusive with 'environment_catalog_mapping'.\nPlease specify one or the other")
		if self.plan.use_finalized_state and not self.virtual_environment_mode.is_full:raise ConfigError('Using the finalized state is only supported when full Virtual Data Environments are enabled (`vde: true`).')
		if self.environment_catalog_mapping:_normalize_identifiers('environment_catalog_mapping')
		if self.physical_schema_mapping:_normalize_identifiers(_K)
		return self
	@model_validator(mode=_D)
	def _inherit_project_config_in_cicd_bot(self)->Self:
		if self.cicd_bot:
			if self.cicd_bot.auto_categorize_changes_ is _A:self.cicd_bot.auto_categorize_changes_=self.plan.auto_categorize_changes
			if self.cicd_bot.pr_include_unmodified_ is _A:self.cicd_bot.pr_include_unmodified_=self.plan.include_unmodified
		return self
	def get_default_test_connection(self,default_catalog:t.Optional[str]=_A,default_catalog_dialect:t.Optional[str]=_A)->ConnectionConfig:return self.default_test_connection_ or DuckDBConnectionConfig(catalogs=_A if default_catalog is _A else{exp.parse_identifier(default_catalog,dialect=default_catalog_dialect).sql(dialect='duckdb'):':memory:'})
	def get_gateway(self,name:t.Optional[str]=_A)->GatewayConfig:
		if isinstance(self.gateways,dict):
			if name is _A:
				if self.default_gateway:
					default_key=self.default_gateway.lower()
					if default_key not in self.gateways:raise ConfigError(f"Missing gateway with name '{self.default_gateway}'")
					return self.gateways[default_key]
				if''in self.gateways:return self.gateways['']
				return first(self.gateways.values())
			lookup_key=name.lower()
			if lookup_key not in self.gateways:raise ConfigError(f"Missing gateway with name '{name}'.")
			return self.gateways[lookup_key]
		if name is not _A:raise ConfigError('Gateway name is not supported when only one gateway is configured.')
		return self.gateways
	def get_connection(self,gateway_name:t.Optional[str]=_A)->ConnectionConfig:
		connection=self.get_gateway(gateway_name).connection or self.default_connection
		if connection is _A:msg=f" for gateway '{gateway_name}'"if gateway_name else'';raise ConfigError(f"No connection configured{msg}.")
		return connection
	def get_state_connection(self,gateway_name:t.Optional[str]=_A)->t.Optional[ConnectionConfig]:return self.state or self.get_gateway(gateway_name).state_connection
	def get_test_connection(self,gateway_name:t.Optional[str]=_A,default_catalog:t.Optional[str]=_A,default_catalog_dialect:t.Optional[str]=_A)->ConnectionConfig:return self.get_gateway(gateway_name).test_connection or self.get_default_test_connection(default_catalog=default_catalog,default_catalog_dialect=default_catalog_dialect)
	def get_scheduler(self,gateway_name:t.Optional[str]=_A)->SchedulerConfig:return self.get_gateway(gateway_name).scheduler or self.default_scheduler
	def get_state_schema(self,gateway_name:t.Optional[str]=_A)->t.Optional[str]:
		if self.state and self.tenant and self.name:
			def normalize(value:str)->str:A='_';return value.lower().replace('-',A).replace('.',A).replace(' ',A)
			return f"{normalize(self.tenant)}_{normalize(self.name)}"
		return self.get_gateway(gateway_name).state_schema
	@property
	def default_gateway_name(self)->str:
		if self.default_gateway:return self.default_gateway
		if''in self.gateways:return''
		return first(self.gateways)
	@property
	def dialect(self)->t.Optional[str]:return self.model_defaults.dialect
	@property
	def fingerprint(self)->str:return str(zlib.crc32(pickle.dumps(self.dict(exclude={'loader',_F}))))