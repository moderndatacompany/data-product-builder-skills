from __future__ import annotations
_A=False
import typing as t
from vulcan.core.config.base import BaseConfig
class FormatConfig(BaseConfig):
	normalize:bool=_A;pad:int=2;indent:int=2;normalize_functions:t.Optional[str]=None;leading_comma:bool=_A;max_text_width:int=80;append_newline:bool=_A;no_rewrite_casts:bool=_A
	@property
	def generator_options(self)->t.Dict[str,t.Any]:return self.dict(exclude={'append_newline','no_rewrite_casts'})