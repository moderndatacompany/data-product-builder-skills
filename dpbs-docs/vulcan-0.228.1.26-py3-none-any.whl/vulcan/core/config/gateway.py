from __future__ import annotations
_A=None
import typing as t
from vulcan.core import constants as c
from vulcan.core.config.base import BaseConfig
from vulcan.core.config.model import ModelDefaultsConfig
from vulcan.core.config.common import variables_validator
from vulcan.core.config.connection import SerializableConnectionConfig,connection_config_validator
from vulcan.core.config.scheduler import SchedulerConfig,scheduler_config_validator
class GatewayConfig(BaseConfig):connection:t.Optional[SerializableConnectionConfig]=_A;state_connection:t.Optional[SerializableConnectionConfig]=_A;test_connection:t.Optional[SerializableConnectionConfig]=_A;scheduler:t.Optional[SchedulerConfig]=_A;state_schema:t.Optional[str]=c.SQLMESH;variables:t.Dict[str,t.Any]={};model_defaults:t.Optional[ModelDefaultsConfig]=_A;_connection_config_validator=connection_config_validator;_scheduler_config_validator=scheduler_config_validator;_variables_validator=variables_validator