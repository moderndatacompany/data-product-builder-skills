_A='snappy'
from vulcan.core.config.base import BaseConfig
import typing as t
class ObjectStoreConfig(BaseConfig):provider:t.Literal['s3','gcs','azure','minio']='minio';bucket:str='warehouse';base_path:str='queries';compression:t.Literal[_A,'gzip','zstd']=_A;presigned_url_expiry_mins:int=60;credentials:t.Dict[str,t.Any]={}