from __future__ import annotations
import typing as t
from pathlib import Path
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import PydanticModel
class BeforeAfterFileRef(PydanticModel):file:str
BeforeAfterEntry=t.Union[str,BeforeAfterFileRef]
def _read_sql_file(root:Path,rel:str,index:int)->str:
	rel=rel.strip()
	if not rel:raise ConfigError(f"Invalid empty path in file reference at index {index}.")
	path=(root/rel).resolve()
	try:path.relative_to(root)
	except ValueError as ex:raise ConfigError(f"File path {rel!r} resolves outside the project directory {root}.")from ex
	if not path.is_file():raise ConfigError(f"SQL file not found: {rel!r} (project root: {root}).")
	text=path.read_text(encoding='utf-8')
	if not text.strip():raise ConfigError(f"SQL file is empty: {rel!r} (resolved path: {path})")
	return text
def _resolve_entries(project_root:Path,entries:t.Optional[t.List[BeforeAfterEntry]])->t.List[str]:
	if not entries:return[]
	root=project_root.resolve();return[entry if isinstance(entry,str)else _read_sql_file(root,entry.file,index)for(index,entry)in enumerate(entries)]
def resolve_before(project_root:Path,entries:t.Optional[t.List[BeforeAfterEntry]])->t.List[str]:return _resolve_entries(project_root,entries)
def resolve_after(project_root:Path,entries:t.Optional[t.List[BeforeAfterEntry]])->t.List[str]:return _resolve_entries(project_root,entries)