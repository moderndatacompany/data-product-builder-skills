from __future__ import annotations
from vulcan.core.config.base import BaseConfig
import typing as t
class TranspilerConfig(BaseConfig):base_url:str='http://127.0.0.1:8100';timeout:int=30;token:t.Optional[str]=None