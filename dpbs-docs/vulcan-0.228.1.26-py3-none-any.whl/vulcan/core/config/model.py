from __future__ import annotations
_C='before'
_B='audits'
_A=None
import typing as t
from sqlglot import exp
from vulcan.core.dialect import parse_one,extract_func_call
from vulcan.core.config.base import BaseConfig
from vulcan.core.model.kind import ModelKind,OnDestructiveChange,model_kind_validator,on_destructive_change_validator,on_additive_change_validator,OnAdditiveChange
from vulcan.core.model.meta import FunctionCall
from vulcan.core.node import IntervalUnit
from vulcan.utils.date import TimeLike
from vulcan.utils.pydantic import field_validator,model_validator
class ModelDefaultsConfig(BaseConfig):
	kind:t.Optional[ModelKind]=_A;dialect:t.Optional[str]=_A;cron:t.Optional[str]=_A;owner:t.Optional[str]=_A;start:t.Optional[TimeLike]=_A;table_format:t.Optional[str]=_A;storage_format:t.Optional[str]=_A;on_destructive_change:t.Optional[OnDestructiveChange]=_A;on_additive_change:t.Optional[OnAdditiveChange]=_A;physical_properties:t.Optional[t.Dict[str,t.Any]]=_A;virtual_properties:t.Optional[t.Dict[str,t.Any]]=_A;session_properties:t.Optional[t.Dict[str,t.Any]]=_A;audits:t.Optional[t.List[FunctionCall]]=_A;optimize_query:t.Optional[t.Union[str,bool]]=_A;allow_partials:t.Optional[t.Union[str,bool]]=_A;interval_unit:t.Optional[t.Union[str,IntervalUnit]]=_A;enabled:t.Optional[t.Union[str,bool]]=_A;formatting:t.Optional[t.Union[str,bool]]=_A;batch_concurrency:t.Optional[int]=_A;pre_statements:t.Optional[t.List[t.Union[str,exp.Expression]]]=_A;post_statements:t.Optional[t.List[t.Union[str,exp.Expression]]]=_A;on_virtual_update:t.Optional[t.List[t.Union[str,exp.Expression]]]=_A;_model_kind_validator=model_kind_validator;_on_destructive_change_validator=on_destructive_change_validator;_on_additive_change_validator=on_additive_change_validator
	@field_validator(_B,mode=_C)
	def _audits_validator(cls,v:t.Any)->t.Any:
		if isinstance(v,list):return[extract_func_call(parse_one(audit))for audit in v]
		return v
	@model_validator(mode=_C)
	def _normalize_assertions(cls,values:t.Any)->t.Any:
		A='assertions'
		if isinstance(values,dict):
			if A in values:
				if _B in values:raise ValueError("Cannot specify both 'audits' and 'assertions' in model defaults")
				values[_B]=values.pop(A)
		return values