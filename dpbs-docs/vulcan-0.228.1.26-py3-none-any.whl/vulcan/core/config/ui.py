from __future__ import annotations
from vulcan.core.config.base import BaseConfig
class UIConfig(BaseConfig):format_on_save:bool=True