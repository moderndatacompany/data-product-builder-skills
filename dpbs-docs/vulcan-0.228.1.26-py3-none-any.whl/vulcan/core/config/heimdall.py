from __future__ import annotations
_A=None
import re,typing as t
from pydantic import Field,field_validator,model_validator
from vulcan.core.config.base import BaseConfig
_HOOK_SPEC_PATTERN=re.compile('^[a-zA-Z_][a-zA-Z0-9_.]*:[a-zA-Z_][a-zA-Z0-9_]*$',re.ASCII)
class HeimdallConfig(BaseConfig):
	base_url:str='';run_as_token:t.Optional[str]=_A;timeout:float=Field(default=1e1,ge=.05,le=3e2);enabled:bool=False;after_authorize:t.Optional[str]=_A;cache_timeout:float=Field(default=3e1,ge=.0,le=3e2)
	@field_validator('after_authorize')
	@classmethod
	def _normalize_and_validate_hook_spec(cls,v:t.Optional[str])->t.Optional[str]:
		stripped=_A if v is _A else str(v).strip()
		if not stripped:return
		if not _HOOK_SPEC_PATTERN.fullmatch(stripped):raise ValueError(f"Invalid heimdall.after_authorize hook {stripped!r}; expected '<dotted_python_module>:<callable_name>' (ASCII; exactly one ':').")
		return stripped
	@model_validator(mode='after')
	def validate_base_url_required_when_enabled(self)->'HeimdallConfig':
		if self.enabled and not self.base_url:raise ValueError('heimdall.base_url is required when heimdall.enabled=true. Either provide a valid Heimdall URL or set heimdall.enabled=false.')
		return self