from __future__ import annotations
from vulcan.core.config.base import BaseConfig
class MigrationConfig(BaseConfig):promoted_snapshots_only:bool=True