from __future__ import annotations
from enum import Enum
from vulcan.core.config.base import BaseConfig
class AutoCategorizationMode(Enum):FULL='full';SEMI='semi';OFF='off'
class CategorizerConfig(BaseConfig):
	external:AutoCategorizationMode=AutoCategorizationMode.FULL;python:AutoCategorizationMode=AutoCategorizationMode.FULL;sql:AutoCategorizationMode=AutoCategorizationMode.FULL;seed:AutoCategorizationMode=AutoCategorizationMode.FULL;semantic:AutoCategorizationMode=AutoCategorizationMode.FULL;metric:AutoCategorizationMode=AutoCategorizationMode.FULL
	@classmethod
	def all_off(cls)->CategorizerConfig:return cls(external=AutoCategorizationMode.OFF,python=AutoCategorizationMode.OFF,sql=AutoCategorizationMode.OFF,seed=AutoCategorizationMode.OFF,semantic=AutoCategorizationMode.OFF,metric=AutoCategorizationMode.OFF)
	@classmethod
	def all_semi(cls)->CategorizerConfig:return cls(external=AutoCategorizationMode.SEMI,python=AutoCategorizationMode.SEMI,sql=AutoCategorizationMode.SEMI,seed=AutoCategorizationMode.SEMI,semantic=AutoCategorizationMode.SEMI,metric=AutoCategorizationMode.SEMI)
	@classmethod
	def all_full(cls)->CategorizerConfig:return cls(external=AutoCategorizationMode.FULL,python=AutoCategorizationMode.FULL,sql=AutoCategorizationMode.FULL,seed=AutoCategorizationMode.FULL,semantic=AutoCategorizationMode.FULL,metric=AutoCategorizationMode.FULL)