from __future__ import annotations
_B='builtin'
_A='type'
import abc,typing as t
from pydantic import Field,ValidationError
from sqlglot.helper import subclasses
from vulcan.core.config.base import BaseConfig
from vulcan.core.console import get_console
from vulcan.core.plan import BuiltInPlanEvaluator,PlanEvaluator
from vulcan.core.config import DuckDBConnectionConfig
from vulcan.core.state_sync import EngineAdapterStateSync,StateSync
from vulcan.utils.errors import ConfigError
from vulcan.utils.hashing import md5
from vulcan.utils.pydantic import field_validator,validation_error_message
if t.TYPE_CHECKING:from vulcan.core.context import GenericContext
from vulcan.utils.config import sensitive_fields,excluded_fields
class SchedulerConfig(abc.ABC):
	@abc.abstractmethod
	def create_plan_evaluator(self,context:GenericContext)->PlanEvaluator:0
	@abc.abstractmethod
	def create_state_sync(self,context:GenericContext)->StateSync:0
	@abc.abstractmethod
	def get_default_catalog_per_gateway(self,context:GenericContext)->t.Dict[str,str]:0
	@abc.abstractmethod
	def state_sync_fingerprint(self,context:GenericContext)->str:0
class _EngineAdapterStateSyncSchedulerConfig(SchedulerConfig):
	def create_state_sync(self,context:GenericContext)->StateSync:
		state_connection=context.config.get_state_connection(context.gateway)or context.connection_config;warehouse_connection=context.config.get_connection(context.gateway)
		if isinstance(state_connection,DuckDBConnectionConfig)and state_connection.concurrent_tasks<=1:
			if warehouse_connection.concurrent_tasks>1:state_connection.concurrent_tasks=warehouse_connection.concurrent_tasks
		engine_adapter=state_connection.create_engine_adapter()
		if state_connection.is_forbidden_for_state_sync:raise ConfigError(f"The {engine_adapter.DIALECT.upper()} engine cannot be used to store Vulcan state - please specify a different `state_connection` engine."+' See https://vulcan.readthedocs.io/en/stable/reference/configuration/#gateways for more information.')
		if not isinstance(state_connection,DuckDBConnectionConfig)or not isinstance(warehouse_connection,DuckDBConnectionConfig):
			if not state_connection.is_recommended_for_state_sync:get_console().log_warning(f"The {state_connection.type_} ({state_connection.database}) engine is not recommended for storing Vulcan state in production deployments.")
		schema=context.config.get_state_schema(context.gateway);return EngineAdapterStateSync(engine_adapter,schema=schema,cache_dir=context.cache_dir,console=context.console)
	def state_sync_fingerprint(self,context:GenericContext)->str:state_connection=context.config.get_state_connection(context.gateway)or context.connection_config;return md5([state_connection.json(sort_keys=True,exclude=sensitive_fields.union(excluded_fields))])
class BuiltInSchedulerConfig(_EngineAdapterStateSyncSchedulerConfig,BaseConfig):
	type_:t.Literal[_B]=Field(alias=_A,default=_B)
	def create_plan_evaluator(self,context:GenericContext)->PlanEvaluator:return BuiltInPlanEvaluator(state_sync=context.state_sync,snapshot_evaluator=context.snapshot_evaluator,create_scheduler=context.create_scheduler,default_catalog=context.default_catalog,console=context.console)
	def get_default_catalog_per_gateway(self,context:GenericContext)->t.Dict[str,str]:
		default_catalogs_per_gateway:t.Dict[str,str]={}
		for(gateway,adapter)in context.engine_adapters.items():
			if(catalog:=adapter.default_catalog):default_catalogs_per_gateway[gateway]=catalog
		return default_catalogs_per_gateway
SCHEDULER_CONFIG_TO_TYPE={tpe.all_field_infos()['type_'].default:tpe for tpe in subclasses(__name__,BaseConfig,exclude=(BaseConfig,))}
def _scheduler_config_validator(cls:t.Type,v:SchedulerConfig|t.Dict[str,t.Any]|None)->SchedulerConfig|None:
	if v is None or isinstance(v,SchedulerConfig):return v
	if _A not in v:raise ConfigError('Missing scheduler type.')
	scheduler_type=v[_A]
	if scheduler_type not in SCHEDULER_CONFIG_TO_TYPE:raise ConfigError(f"Unknown scheduler type '{scheduler_type}'.")
	try:return SCHEDULER_CONFIG_TO_TYPE[scheduler_type](**v)
	except ValidationError as e:raise ConfigError(validation_error_message(e,f"Invalid '{scheduler_type}' scheduler config:")+'\n\nVerify your config.yaml and environment variables.')
scheduler_config_validator=field_validator('scheduler','default_scheduler',mode='before',check_fields=False)(_scheduler_config_validator)