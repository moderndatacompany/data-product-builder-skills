from __future__ import annotations
import typing as t
from pydantic import Field
from vulcan.core.config.base import BaseConfig
class PrometheusConfig(BaseConfig):pushgateway_url:str=Field(default='');job:str=Field(default='vulcan-v2');push_interval_sec:int=Field(default=10,ge=1,le=300);push_timeout_sec:float=Field(default=2.,ge=.1,le=3e1);grouping_key:t.Dict[str,str]=Field(default_factory=dict,description='Explicit grouping_key override; auto-built from DATAOS_* env vars when empty')