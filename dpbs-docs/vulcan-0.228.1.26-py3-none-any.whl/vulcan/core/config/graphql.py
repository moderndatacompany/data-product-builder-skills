from __future__ import annotations
from vulcan.core.config.base import BaseConfig
class GraphQLConfig(BaseConfig):base_url:str='http://127.0.0.1:3000';timeout:int=30