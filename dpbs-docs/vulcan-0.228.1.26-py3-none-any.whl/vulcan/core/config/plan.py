from __future__ import annotations
_A=False
import typing as t
from vulcan.core.config.base import BaseConfig
from vulcan.core.config.categorizer import CategorizerConfig
class PlanConfig(BaseConfig):forward_only:bool=_A;auto_categorize_changes:CategorizerConfig=CategorizerConfig();include_unmodified:bool=_A;enable_preview:t.Optional[bool]=None;no_diff:bool=_A;no_prompts:bool=True;auto_apply:bool=_A;use_finalized_state:bool=_A;always_recreate_environment:bool=_A