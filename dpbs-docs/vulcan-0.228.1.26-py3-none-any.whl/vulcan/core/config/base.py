from __future__ import annotations
import typing as t
from enum import Enum,auto
import pydantic
from pydantic import AliasGenerator
from pydantic.alias_generators import to_camel
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import PydanticModel
T=t.TypeVar('T',bound='BaseConfig')
class UpdateStrategy(Enum):REPLACE=auto();EXTEND=auto();KEY_UPDATE=auto();KEY_EXTEND=auto();IMMUTABLE=auto();NESTED_UPDATE=auto()
def update_field(old:t.Optional[t.Any],new:t.Any,update_strategy:t.Optional[UpdateStrategy]=None)->t.Any:
	A='KEY_EXTEND behavior requires list values in dictionary.'
	def _update_pydantic_config(old:BaseConfig,new:BaseConfig)->PydanticModel:
		if type(new)!=type(old):raise ConfigError(f"NESTED_UPDATE behavior requires both values to have the same type. {type(old)} and {type(new)} were given instead.")
		return old.update_with(new)
	if not old:return new
	update_strategy=update_strategy or UpdateStrategy.REPLACE
	if update_strategy==UpdateStrategy.IMMUTABLE:raise ConfigError(f"Cannot modify property: {old}.")
	if update_strategy==UpdateStrategy.REPLACE:return new
	if update_strategy==UpdateStrategy.EXTEND:
		if not isinstance(old,list)or not isinstance(new,list):raise ConfigError('EXTEND behavior requires list field.')
		return old+new
	if update_strategy==UpdateStrategy.KEY_UPDATE:
		if not isinstance(old,dict)or not isinstance(new,dict):raise ConfigError('KEY_UPDATE behavior requires dictionary field.')
		combined=old.copy();combined.update(new);return combined
	if update_strategy==UpdateStrategy.KEY_EXTEND:
		if not isinstance(old,dict)or not isinstance(new,dict):raise ConfigError('KEY_EXTEND behavior requires dictionary field.')
		combined=old.copy()
		for(key,value)in new.items():
			if not isinstance(value,list):raise ConfigError(A)
			old_value=combined.get(key)
			if old_value:
				if not isinstance(old_value,list):raise ConfigError(A)
				combined[key]=old_value+value
			else:combined[key]=value
		return combined
	if update_strategy==UpdateStrategy.NESTED_UPDATE:
		if new is None:return
		if not isinstance(old,BaseConfig)and not isinstance(old,dict):raise ConfigError(f"NESTED_UPDATE behavior requires a config object and a dict of config objects as values. {type(old)} was given instead.")
		if isinstance(old,dict):
			for(k,pydantic_model)in new.items():
				if k in old:old[k]=_update_pydantic_config(old[k],pydantic_model)
				else:old[k]=pydantic_model
			return old
		return _update_pydantic_config(old,new)
	raise ConfigError(f"Unknown update strategy {update_strategy}.")
class BaseConfig(PydanticModel):
	model_config=pydantic.ConfigDict(populate_by_name=True,alias_generator=AliasGenerator(validation_alias=to_camel));_FIELD_UPDATE_STRATEGY:t.ClassVar[t.Dict[str,UpdateStrategy]]={}
	def update_with(self:T,other:t.Union[t.Dict[str,t.Any],T])->T:
		if isinstance(other,dict):other=self.__class__(**other)
		updated_fields={}
		for field in other.fields_set:
			if field in self.all_field_infos():updated_fields[field]=update_field(getattr(self,field),getattr(other,field),self._FIELD_UPDATE_STRATEGY.get(field))
			else:updated_fields[field]=getattr(other,field)
		updated=self.copy()
		for(field,value)in updated_fields.items():setattr(updated,field,value)
		return updated