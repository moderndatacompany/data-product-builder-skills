from __future__ import annotations
_A=None
import typing as t
from functools import cached_property
from vulcan import Model
from vulcan.core.context import ExecutionContext
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.test.definition import ModelTest
from vulcan.utils import UniqueKeyDict
class TestExecutionContext(ExecutionContext):
	__test__=False
	def __init__(self,engine_adapter:EngineAdapter,models:UniqueKeyDict[str,Model],test:ModelTest,default_dialect:t.Optional[str]=_A,default_catalog:t.Optional[str]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A):self._engine_adapter=engine_adapter;self._models=models;self._test=test;self._default_catalog=default_catalog;self._default_dialect=default_dialect;self._variables=variables or{};self._blueprint_variables=variables or{}
	@cached_property
	def _model_tables(self)->t.Dict[str,str]:return{name:self._test._test_fixture_table(name).sql()for(normalized_model_name,model)in self._models.items()for name in[normalized_model_name,*model.depends_on]}
	def with_variables(self,variables:t.Dict[str,t.Any],blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A)->TestExecutionContext:return TestExecutionContext(self._engine_adapter,self._models,self._test,self._default_dialect,self._default_catalog,variables=variables,blueprint_variables=blueprint_variables)