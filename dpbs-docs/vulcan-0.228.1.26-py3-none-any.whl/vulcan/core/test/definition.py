from __future__ import annotations
_P='execution_time'
_O='alias'
_N='columns'
_M='1970-01-01'
_L='records'
_K='ctes'
_J='model'
_I='vars'
_H='partial'
_G='outputs'
_F='inputs'
_E='rows'
_D='query'
_C=True
_B=False
_A=None
import sys,datetime,threading,typing as t,unittest
from collections import Counter
from contextlib import nullcontext,contextmanager,AbstractContextManager
from itertools import chain
from pathlib import Path
from unittest.mock import patch
from io import StringIO
from sqlglot import Dialect,exp
from sqlglot.optimizer.annotate_types import annotate_types
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from vulcan.core import constants as c
from vulcan.core.dialect import normalize_model_name,schema_
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.core.macros import RuntimeStage
from vulcan.core.model import Model,PythonModel,SeedModel,SqlModel
from vulcan.utils import UniqueKeyDict,random_id,type_is_known,yaml
from vulcan.utils.date import date_dict,pandas_timestamp_to_pydatetime,to_datetime
from vulcan.utils.errors import ConfigError,TestError
from vulcan.utils.yaml import load as yaml_load
from vulcan.utils import Verbosity
from vulcan.utils.rich import df_to_table
if t.TYPE_CHECKING:import pandas as pd;from sqlglot.dialects.dialect import DialectType;Row=t.Dict[str,t.Any]
TIME_KWARG_KEYS={'start','end',_P,'latest',*date_dict(execution_time=_M,start=_M,end=_M).keys()}
class ModelTest(unittest.TestCase):
	__test__=_B;CONCURRENT_RENDER_LOCK=threading.Lock()
	def __init__(self,body:t.Dict[str,t.Any],test_name:str,model:Model,models:UniqueKeyDict[str,Model],engine_adapter:EngineAdapter,dialect:str|_A=_A,path:Path|_A=_A,preserve_fixtures:bool=_B,default_catalog:str|_A=_A,concurrency:bool=_B,verbosity:Verbosity=Verbosity.DEFAULT)->_A:
		self.body=body;self.test_name=test_name;self.model=model;self.models=models;self.engine_adapter=engine_adapter;self.path=path;self.preserve_fixtures=preserve_fixtures;self.default_catalog=default_catalog;self.dialect=dialect;self.concurrency=concurrency;self.verbosity=verbosity;(self._fixture_table_cache):t.Dict[str,exp.Table]={};(self._normalized_column_name_cache):t.Dict[str,str]={};(self._normalized_model_name_cache):t.Dict[t.Tuple[str,bool],str]={};self._test_adapter_dialect=Dialect.get_or_raise(self.engine_adapter.dialect);self._validate_and_normalize_test()
		if self.engine_adapter.default_catalog:(self._fixture_catalog):t.Optional[exp.Identifier]=normalize_identifiers(exp.parse_identifier(self.engine_adapter.default_catalog,dialect=self._test_adapter_dialect),dialect=self._test_adapter_dialect)
		else:self._fixture_catalog=_A
		self._fixture_schema=exp.parse_identifier(self.body.get('schema')or f"vulcan_test_{random_id(short=_C)}");self._qualified_fixture_schema=schema_(self._fixture_schema,self._fixture_catalog);self._transforms=self._test_adapter_dialect.generator_class.TRANSFORMS;self._execution_time=str(self.body.get(_I,{}).get(_P)or'')
		if self._execution_time:self._execution_time=str(to_datetime(self._execution_time))
		if self._execution_time:exec_time=exp.Literal.string(self._execution_time);self._transforms={**self._transforms,exp.CurrentDate:lambda self,_:self.sql(exp.cast(exec_time,'date',dialect=dialect)),exp.CurrentDatetime:lambda self,_:self.sql(exp.cast(exec_time,'datetime',dialect=dialect)),exp.CurrentTime:lambda self,_:self.sql(exp.cast(exec_time,'time',dialect=dialect)),exp.CurrentTimestamp:lambda self,_:self.sql(exp.cast(exec_time,'timestamp',dialect=dialect))}
		super().__init__()
	def defaultTestResult(self)->unittest.TestResult:from vulcan.core.test.result import ModelTextTestResult;return ModelTextTestResult(stream=sys.stdout,descriptions=_C,verbosity=self.verbosity)
	def shortDescription(self)->t.Optional[str]:return self.body.get('description')
	def setUp(self)->_A:
		import pandas as pd,numpy as np;self.engine_adapter.create_schema(self._qualified_fixture_schema)
		for(name,values)in self.body.get(_F,{}).items():
			all_types_are_known=_B;columns_to_known_types:t.Dict[str,exp.DataType]={};model=self.models.get(name)
			if model:inferred_columns_to_types=model.columns_to_types or{};columns_to_known_types={c:t for(c,t)in inferred_columns_to_types.items()if type_is_known(t)};all_types_are_known=bool(inferred_columns_to_types)and len(columns_to_known_types)==len(inferred_columns_to_types)
			columns_to_known_types.update(values.get(_N,{}));rows=values.get(_E)
			if not all_types_are_known and rows:
				for(col,value)in rows[0].items():
					if col not in columns_to_known_types:
						v_type=annotate_types(exp.convert(value)).type or type(value).__name__;v_type=exp.maybe_parse(v_type,into=exp.DataType,dialect=self._test_adapter_dialect)
						if not type_is_known(v_type):_raise_error(f"Failed to infer the data type of column '{col}' for '{name}'. This issue can be mitigated by casting the column in the model definition, setting its type in inputs.yaml if it's an external model, setting the model's 'columns' property, or setting its 'columns' mapping in the test itself",self.path)
						columns_to_known_types[col]=v_type
			if rows is _A:
				query_or_df:exp.Query|pd.DataFrame=self._add_missing_columns(values[_D],columns_to_known_types)
				if columns_to_known_types:columns_to_known_types={col:columns_to_known_types[col]for col in query_or_df.named_selects}
			else:query_or_df=self._create_df(values,columns=columns_to_known_types)
			if isinstance(query_or_df,pd.DataFrame):query_or_df=query_or_df.replace({np.nan:_A})
			self.engine_adapter.create_view(self._test_fixture_table(name),query_or_df,columns_to_known_types)
	def tearDown(self)->_A:
		if not self.preserve_fixtures:self.engine_adapter.drop_schema(self._qualified_fixture_schema,cascade=_C)
	def assert_equal(self,expected:pd.DataFrame,actual:pd.DataFrame,sort:bool,partial:t.Optional[bool]=_B)->_A:
		C='act';B='exp';A='ignore';import numpy as np,pandas as pd;from pandas.api.types import is_object_dtype
		if partial:
			intersection=actual[actual.columns.intersection(expected.columns)]
			if len(intersection.columns)>0:actual=intersection
		actual_types=actual.dtypes.to_dict();expected=expected.astype(actual_types,errors=A).astype(actual_types,errors=A);object_sentinel_values={col:actual[col][0]for col in actual_types if is_object_dtype(actual_types[col])and len(actual[col])!=0}
		for(col,value)in object_sentinel_values.items():
			try:
				if type(value)is datetime.date:expected[col]=pd.to_datetime(expected[col]).dt.date
				elif type(value)is datetime.time:expected[col]=pd.to_datetime(expected[col]).dt.time
				elif type(value)is datetime.datetime:expected[col]=pd.to_datetime(expected[col]).dt.to_pydatetime()
			except Exception as e:from vulcan.core.console import get_console;get_console().log_warning(f"Failed to convert expected value for {col} into `datetime` for unit test '{str(self)}'. {str(e)}.")
		actual=actual.replace({np.nan:_A});expected=expected.replace({np.nan:_A});DATETIME_TYPES=datetime.datetime,datetime.date,datetime.time,np.datetime64,pd.Timestamp
		def _to_hashable(x:t.Any)->t.Any:
			if isinstance(x,(list,np.ndarray)):return tuple(_to_hashable(v)for v in x)
			if isinstance(x,dict):return tuple((k,_to_hashable(v))for(k,v)in x.items())
			return str(x)if isinstance(x,DATETIME_TYPES)or not isinstance(x,t.Hashable)else x
		actual=actual.apply(lambda col:col.map(_to_hashable));expected=expected.apply(lambda col:col.map(_to_hashable))
		if sort:actual=actual.sort_values(by=actual.columns.to_list()).reset_index(drop=_C);expected=expected.sort_values(by=expected.columns.to_list()).reset_index(drop=_C)
		try:pd.testing.assert_frame_equal(expected,actual,check_dtype=_B,check_datetimelike_compat=_C,check_like=_C)
		except AssertionError as e:
			args:t.List[t.Any]=[];failed_subtest=''
			if(subtest:=getattr(self,'_subtest',_A)):
				if(cte:=subtest.params.get('cte')):failed_subtest=f" (CTE {cte})"
			if expected.shape!=actual.shape:
				_raise_if_unexpected_columns(expected.columns,actual.columns);args.append('Data mismatch (rows are different)');missing_rows=_row_difference(expected,actual)
				if not missing_rows.empty:args[0]+=f"\n\nMissing rows:\n\n{missing_rows}";args.append(df_to_table(f"Missing rows{failed_subtest}",missing_rows))
				unexpected_rows=_row_difference(actual,expected)
				if not unexpected_rows.empty:args[0]+=f"\n\nUnexpected rows:\n\n{unexpected_rows}";args.append(df_to_table(f"Unexpected rows{failed_subtest}",unexpected_rows))
			else:
				diff=expected.compare(actual).rename(columns={'self':B,'other':C});args.append(f"Data mismatch (exp: expected, act: actual)\n\n{diff}");diff.rename(columns={B:'Expected',C:'Actual'},inplace=_C)
				if self.verbosity==Verbosity.DEFAULT:args.extend(df_to_table(f"Data mismatch{failed_subtest}",df)for df in _split_df_by_column_pairs(diff))
				else:
					from pandas import MultiIndex;levels=t.cast(MultiIndex,diff.columns).levels[0]
					for col in levels:
						col_diff=diff[col]
						if not col_diff.empty:table=df_to_table(f"[bold red]Column '{col}' mismatch{failed_subtest}[/bold red]",col_diff);args.append(table)
			e.args=*args,;raise e
	def runTest(self)->_A:raise NotImplementedError
	def path_relative_to(self,other:Path)->Path|_A:return self.path.relative_to(other)if self.path else _A
	@staticmethod
	def create_test(body:t.Dict[str,t.Any],test_name:str,models:UniqueKeyDict[str,Model],engine_adapter:EngineAdapter,dialect:str|_A,path:Path|_A,preserve_fixtures:bool=_B,default_catalog:str|_A=_A,concurrency:bool=_B,verbosity:Verbosity=Verbosity.DEFAULT)->t.Optional[ModelTest]:
		name=body.get(_J)
		if name is _A:_raise_error("Missing required 'model' field",path)
		name=normalize_model_name(name,default_catalog=default_catalog,dialect=dialect);model=models.get(name)
		if not model:from vulcan.core.console import get_console;get_console().log_warning(f"Model '{name}' was not found{' at '+str(path)if path else''}");return
		if isinstance(model,SqlModel):test_type:t.Type[ModelTest]=SqlModelTest
		elif isinstance(model,PythonModel):test_type=PythonModelTest
		else:_raise_error(f"Model '{name}' is an unsupported model type for testing",path)
		try:return test_type(body,test_name,t.cast(Model,model),models,engine_adapter,dialect,path,preserve_fixtures,default_catalog,concurrency,verbosity)
		except Exception as e:raise TestError(f"Failed to create test {test_name} ({path})\n{str(e)}")
	def __str__(self)->str:return f"{self.test_name} ({self.path})"
	def _fixture_path(self,path:str|Path)->Path:
		fixture_path=Path(path)
		if fixture_path.is_absolute():return fixture_path
		if self.path is _A:_raise_error(f"Relative fixture path '{path}' requires a test definition file path",self.path)
		return self.path.parent/fixture_path
	def _validate_and_normalize_test(self)->_A:
		inputs=self.body.get(_F);outputs=self.body.get(_G,{})
		if not outputs:_raise_error('Incomplete test, missing outputs',self.path)
		ctes=outputs.get(_K);query=outputs.get(_D);partial=outputs.pop(_H,_A)
		if ctes is _A and query is _A:_raise_error("Incomplete test, outputs must contain 'query' or 'ctes'",self.path)
		def _normalize_rows(values:t.List[Row]|t.Dict,name:str,partial:bool=_B,dialect:DialectType=_A)->t.Dict:
			import pandas as pd
			if not isinstance(values,dict):values={_E:values}
			rows=values.get(_E);query=values.get(_D);fmt=values.get('format');path=values.get('path')
			if fmt=='csv':csv_settings=values.get('csv_settings')or{};rows=pd.read_csv(self._fixture_path(path)if path else StringIO(rows),**csv_settings).to_dict(orient=_L)
			elif fmt in(_A,'yaml'):
				if path:input_rows=yaml_load(self._fixture_path(path));rows=input_rows.get(_E)if isinstance(input_rows,dict)else input_rows
			else:_raise_error(f"Unsupported data format '{fmt}' for '{name}'",self.path)
			if query is not _A:
				if rows is not _A:_raise_error(f"Invalid test, cannot set both 'query' and 'rows' for '{name}'",self.path)
				values[_D]=normalize_identifiers(exp.maybe_parse(query,dialect=self._test_adapter_dialect),dialect=dialect);return values
			if rows is _A:_raise_error(f"Incomplete test, missing row data for '{name}'",self.path)
			assert isinstance(rows,list);values[_E]=[{self._normalize_column_name(column):value for(column,value)in row.items()}for row in rows]
			if partial:values[_H]=_C
			return values
		def _normalize_sources(sources:t.Dict,partial:bool=_B,with_default_catalog:bool=_C)->t.Dict:
			normalized_sources={}
			for(name,values)in sources.items():normalized_name=self._normalize_model_name(name,with_default_catalog=with_default_catalog);model=self.models.get(normalized_name);dialect=model.dialect if model else self.dialect;normalized_sources[normalized_name]=_normalize_rows(values,name,partial=partial,dialect=dialect)
			return normalized_sources
		normalized_model_name=self._normalize_model_name(self.body[_J]);self.body[_J]=normalized_model_name
		if inputs:
			inputs=_normalize_sources(inputs)
			for(name,values)in inputs.items():
				columns=values.get(_N)
				if columns is _A:continue
				if not isinstance(columns,dict):_raise_error(f"Invalid 'columns' value for model '{name}', expected a mapping name -> type",self.path)
				values[_N]={self._normalize_column_name(c):exp.DataType.build(t,dialect=self._test_adapter_dialect)for(c,t)in columns.items()}
			for depends_on in self.model.depends_on:
				if depends_on not in inputs:_raise_error(f"Incomplete test, missing input model '{depends_on}'",self.path)
			if self.model.depends_on_self and normalized_model_name not in inputs:inputs[normalized_model_name]={_E:[]}
			self.body[_F]=inputs
		if ctes:outputs[_K]=_normalize_sources(ctes,partial=partial,with_default_catalog=_B)
		if query or query==[]:outputs[_D]=_normalize_rows(query,self.model.name,partial=partial,dialect=self.model.dialect)
	def _test_fixture_table(self,name:str)->exp.Table:
		table=self._fixture_table_cache.get(name)
		if not table:
			table=exp.to_table(name,dialect=self._test_adapter_dialect);table.this.set('this','__'.join(part.name for part in table.parts));table.set('db',self._fixture_schema.copy())
			if self._fixture_catalog:table.set('catalog',self._fixture_catalog.copy())
			self._fixture_table_cache[name]=table
		return table
	def _normalize_model_name(self,name:str,with_default_catalog:bool=_C)->str:
		normalized_name=self._normalized_model_name_cache.get((name,with_default_catalog))
		if normalized_name is _A:default_catalog=self.default_catalog if with_default_catalog else _A;normalized_name=normalize_model_name(name,default_catalog=default_catalog,dialect=self.dialect);self._normalized_model_name_cache[name,with_default_catalog]=normalized_name
		return normalized_name
	def _normalize_column_name(self,name:str)->str:
		normalized_name=self._normalized_column_name_cache.get(name)
		if normalized_name is _A:normalized_name=normalize_identifiers(name,dialect=self.dialect).name;self._normalized_column_name_cache[name]=normalized_name
		return normalized_name
	@contextmanager
	def _concurrent_render_context(self)->t.Iterator[_A]:
		import time_machine;lock_ctx:AbstractContextManager=self.CONCURRENT_RENDER_LOCK if self.concurrency else nullcontext();time_ctx:AbstractContextManager=nullcontext();dialect_patch_ctx:AbstractContextManager=nullcontext()
		if self._execution_time:time_ctx=time_machine.travel(self._execution_time,tick=_B);dialect_patch_ctx=patch.dict(self._test_adapter_dialect.generator_class.TRANSFORMS,self._transforms)
		with lock_ctx,time_ctx,dialect_patch_ctx:yield
	def _execute(self,query:exp.Query|str)->pd.DataFrame:return self.engine_adapter.fetchdf(query)
	def _create_df(self,values:t.Dict[str,t.Any],columns:t.Optional[t.Collection]=_A,partial:t.Optional[bool]=_B)->pd.DataFrame:
		import pandas as pd;query=values.get(_D)
		if query:
			if not partial:query=self._add_missing_columns(query,columns)
			return self._execute(query)
		rows=values[_E];columns_str:t.Optional[t.List[str]]=_A
		if columns:
			columns_str=[str(c)for c in columns];referenced_columns=list(dict.fromkeys(col for row in rows for col in row));_raise_if_unexpected_columns(columns,referenced_columns)
			if partial:columns_str=[c for c in columns_str if c in referenced_columns]
		return pd.DataFrame.from_records(rows,columns=columns_str)
	def _add_missing_columns(self,query:exp.Query,all_columns:t.Optional[t.Collection[str]]=_A)->exp.Query:
		if not all_columns or query.is_star:return query
		query_columns=set(query.named_selects);missing_columns=[col for col in all_columns if col not in query_columns]
		if missing_columns:query.select(*[exp.null().as_(col)for col in missing_columns],copy=_B)
		return query
class SqlModelTest(ModelTest):
	def test_ctes(self,ctes:t.Dict[str,exp.Expression],recursive:bool=_B)->_A:
		for(cte_name,values)in self.body[_G].get(_K,{}).items():
			with self.subTest(cte=cte_name):
				if cte_name not in ctes:_raise_error(f"No CTE named {cte_name} found in model {self.model.name}",self.path)
				cte_query=ctes[cte_name].this;sort=cte_query.args.get('order')is _A;partial=values.get(_H);cte_query=exp.select(*_projection_identifiers(cte_query)).from_(cte_name)
				for(alias,cte)in ctes.items():cte_query=cte_query.with_(alias,cte.this,recursive=recursive)
				with self._concurrent_render_context():sql=cte_query.sql(self._test_adapter_dialect,pretty=self.engine_adapter._pretty_sql)
				actual=self._execute(sql);expected=self._create_df(values,columns=cte_query.named_selects,partial=partial);self.assert_equal(expected,actual,sort=sort,partial=partial)
	def runTest(self)->_A:
		with self._concurrent_render_context():query=self._render_model_query();sql=query.sql(self._test_adapter_dialect,pretty=self.engine_adapter._pretty_sql)
		with_clause=query.args.get('with')
		if with_clause:self.test_ctes({self._normalize_model_name(cte.alias,with_default_catalog=_B):cte for cte in query.ctes},recursive=with_clause.recursive)
		values=self.body[_G].get(_D)
		if values is not _A:partial=values.get(_H);sort=query.args.get('order')is _A;actual=self._execute(sql);expected=self._create_df(values,columns=self.model.columns_to_types,partial=partial);self.assert_equal(expected,actual,sort=sort,partial=partial)
	def _render_model_query(self)->exp.Query:variables=self.body.get(_I,{}).copy();time_kwargs={key:variables.pop(key)for key in TIME_KWARG_KEYS if key in variables};query=self.model.render_query_or_raise(**time_kwargs,variables=variables,engine_adapter=self.engine_adapter,table_mapping={name:self._test_fixture_table(name).sql()for name in self.body.get(_F,{})},runtime_stage=RuntimeStage.TESTING);return query
class PythonModelTest(ModelTest):
	def __init__(self,body:t.Dict[str,t.Any],test_name:str,model:Model,models:UniqueKeyDict[str,Model],engine_adapter:EngineAdapter,dialect:str|_A=_A,path:Path|_A=_A,preserve_fixtures:bool=_B,default_catalog:str|_A=_A,concurrency:bool=_B,verbosity:Verbosity=Verbosity.DEFAULT)->_A:from vulcan.core.test.context import TestExecutionContext;super().__init__(body,test_name,model,models,engine_adapter,dialect,path,preserve_fixtures,default_catalog,concurrency,verbosity);self.context=TestExecutionContext(engine_adapter=engine_adapter,models=models,test=self,default_dialect=dialect,default_catalog=default_catalog)
	def runTest(self)->_A:
		values=self.body[_G].get(_D)
		if values is not _A:partial=values.get(_H);actual_df=self._execute_model();actual_df.reset_index(drop=_C,inplace=_C);expected=self._create_df(values,columns=self.model.columns_to_types,partial=partial);self.assert_equal(expected,actual_df,sort=_C,partial=partial)
	def _execute_model(self)->pd.DataFrame:
		import pandas as pd
		with self._concurrent_render_context():variables=self.body.get(_I,{}).copy();time_kwargs={key:variables.pop(key)for key in TIME_KWARG_KEYS if key in variables};df=next(self.model.render(context=self.context,variables=variables,**time_kwargs))
		assert not isinstance(df,exp.Expression);return df if isinstance(df,pd.DataFrame)else df.toPandas()
def generate_test(model:Model,input_queries:t.Dict[str,str],models:UniqueKeyDict[str,Model],engine_adapter:EngineAdapter,test_engine_adapter:EngineAdapter,project_path:Path,overwrite:bool=_B,variables:t.Optional[t.Dict[str,str]]=_A,path:t.Optional[str]=_A,name:t.Optional[str]=_A,include_ctes:bool=_B)->_A:
	import numpy as np,pandas as pd;test_name=name or f"test_{model.view_name}";path=path or f"{test_name}.yaml";extension=path.split('.')[-1].lower()
	if extension not in('yaml','yml'):path=f"{path}.yaml"
	fixture_path=project_path/c.TESTS/path
	if not overwrite and fixture_path.exists():raise ConfigError(f"Fixture '{fixture_path}' already exists, make sure to set --overwrite if it can be safely overwritten.")
	inputs={dep:pandas_timestamp_to_pydatetime(engine_adapter.fetchdf(query).apply(lambda col:col.map(_normalize_df_value)),models[dep].columns_to_types).replace({np.nan:_A}).to_dict(orient=_L)for(dep,query)in input_queries.items()};outputs:t.Dict[str,t.Any]={_D:{}};variables=variables or{};test_body={_J:model.fqn,_F:inputs,_G:outputs}
	if variables:test_body[_I]=variables
	test=ModelTest.create_test(body=test_body.copy(),test_name=test_name,models=models,engine_adapter=test_engine_adapter,dialect=model.dialect,path=fixture_path,default_catalog=model.default_catalog)
	if not test:return
	test.setUp()
	if isinstance(model,SqlModel):
		assert isinstance(test,SqlModelTest);model_query=test._render_model_query();with_clause=model_query.args.get('with')
		if with_clause and include_ctes:
			ctes={};recursive=with_clause.recursive;previous_ctes:t.List[exp.CTE]=[]
			for cte in model_query.ctes:
				cte_query=cte.this;cte_identifier=cte.args[_O].this;cte_query=exp.select(*_projection_identifiers(cte_query)).from_(cte_identifier)
				for prev in chain(previous_ctes,[cte]):cte_query=cte_query.with_(prev.args[_O].this,prev.this,recursive=recursive)
				cte_output=test._execute(cte_query);ctes[cte.alias]=pandas_timestamp_to_pydatetime(df=cte_output.apply(lambda col:col.map(_normalize_df_value))).replace({np.nan:_A}).to_dict(orient=_L);previous_ctes.append(cte)
			if ctes:outputs[_K]=ctes
		output=test._execute(model_query)
	else:output=t.cast(PythonModelTest,test)._execute_model()
	outputs[_D]=pandas_timestamp_to_pydatetime(output.apply(lambda col:col.map(_normalize_df_value)),model.columns_to_types).replace({np.nan:_A}).to_dict(orient=_L);test.tearDown();fixture_path.parent.mkdir(exist_ok=_C,parents=_C)
	with open(fixture_path,'w',encoding='utf-8')as file:yaml.dump({test_name:test_body},file)
def _projection_identifiers(query:exp.Query)->t.List[str|exp.Identifier]:
	identifiers:t.List[str|exp.Identifier]=[]
	for select in query.selects:
		if isinstance(select,exp.Alias):identifiers.append(select.args[_O])
		elif isinstance(select,exp.Column):identifiers.append(select.this)
		else:identifiers.append(select.output_name)
	return identifiers
def _raise_if_unexpected_columns(expected_cols:t.Collection[str],actual_cols:t.Collection[str])->_A:
	unique_expected_cols=set(expected_cols);unknown_cols=[col for col in actual_cols if col not in unique_expected_cols]
	if unknown_cols:expected=f"Expected column(s): {', '.join(list(expected_cols))}\n";unknown=f"Unknown column(s): {', '.join(unknown_cols)}";_raise_error(f"Detected unknown column(s)\n\n{expected}{unknown}")
def _row_difference(left:pd.DataFrame,right:pd.DataFrame)->pd.DataFrame:
	import numpy as np,pandas as pd;rows_missing_from_right=[];right_row_count:t.MutableMapping[t.Tuple,int]=Counter(right.replace({np.nan:_A}).itertuples(index=_B,name=_A))
	for left_row in left.replace({np.nan:_A}).itertuples(index=_B):
		left_row_tuple=tuple(left_row)
		if right_row_count[left_row_tuple]<=0:rows_missing_from_right.append(left_row)
		else:right_row_count[left_row_tuple]-=1
	return pd.DataFrame(rows_missing_from_right)
def _raise_error(msg:str,path:Path|_A=_A)->_A:
	if path:raise TestError(f"Failed to run test at {path}:\n{msg}")
	raise TestError(f"Failed to run test:\n{msg}")
def _normalize_df_value(value:t.Any)->t.Any:
	B='value';A='key';import numpy as np
	if isinstance(value,(list,np.ndarray)):return[_normalize_df_value(v)for v in value]
	if isinstance(value,dict):
		if A in value and B in value:return{k:_normalize_df_value(v)for(k,v)in zip(value[A],value[B])}
		return{k:_normalize_df_value(v)for(k,v)in value.items()}
	return value
def _split_df_by_column_pairs(df:pd.DataFrame,pairs_per_chunk:int=4)->t.List[pd.DataFrame]:
	total_columns=len(df.columns)
	if total_columns<=pairs_per_chunk*2:return[df]
	num_chunks=(total_columns+(pairs_per_chunk*2-1))//(pairs_per_chunk*2);columns_per_chunk=total_columns//num_chunks&~1;remainder=total_columns-columns_per_chunk*num_chunks;chunks=[];start_idx=0
	for i in range(num_chunks):extra=2 if i<remainder//2 else 0;end_idx=start_idx+columns_per_chunk+extra;chunk=df.iloc[:,start_idx:end_idx];chunks.append(chunk);start_idx=end_idx
	return chunks