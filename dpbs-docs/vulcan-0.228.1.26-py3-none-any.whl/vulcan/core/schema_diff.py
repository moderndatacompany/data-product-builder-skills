from __future__ import annotations
_D='kind'
_C=True
_B=None
_A=False
import abc,logging,typing as t
from dataclasses import dataclass
from collections import defaultdict
from enum import Enum
from pydantic import Field
from sqlglot import exp
from sqlglot.helper import ensure_list,seq_get
from vulcan.utils import columns_to_types_to_struct
from vulcan.utils.pydantic import PydanticModel
from vulcan.utils.errors import VulcanError
if t.TYPE_CHECKING:from vulcan.core._typing import TableName
logger=logging.getLogger(__name__)
@dataclass(frozen=_C)
class TableAlterOperation(abc.ABC):
	target_table:exp.Table
	@property
	@abc.abstractmethod
	def is_destructive(self)->bool:0
	@property
	@abc.abstractmethod
	def is_additive(self)->bool:0
	@property
	@abc.abstractmethod
	def _alter_actions(self)->t.List[exp.Expression]:0
	@property
	def expression(self)->exp.Alter:return exp.Alter(this=self.target_table,kind='TABLE',actions=self._alter_actions)
@dataclass(frozen=_C)
class TableAlterColumnOperation(TableAlterOperation,abc.ABC):
	column_parts:t.List[TableAlterColumn];expected_table_struct:exp.DataType;array_element_selector:str
	@property
	def column_identifiers(self)->t.List[exp.Identifier]:
		results=[]
		for column in self.column_parts:
			results.append(column.identifier)
			if column.is_array_of_struct and len(self.column_parts)>1 and self.array_element_selector:results.append(exp.to_identifier(self.array_element_selector))
		return results
	@property
	def column(self)->t.Union[exp.Dot,exp.Identifier]:
		columns=self.column_identifiers
		if len(columns)==1:return columns[0]
		return exp.Dot.build(columns)
@dataclass(frozen=_C)
class TableAlterTypedColumnOperation(TableAlterColumnOperation,abc.ABC):
	column_type:exp.DataType
	@property
	def column_def(self)->exp.ColumnDef:
		if not self.column_type:raise VulcanError("Tried to access column type when it shouldn't be needed")
		return exp.ColumnDef(this=self.column,kind=self.column_type)
@dataclass(frozen=_C)
class TableAlterAddColumnOperation(TableAlterTypedColumnOperation):
	position:t.Optional[TableAlterColumnPosition]=_B;is_part_of_destructive_change:bool=_A
	@property
	def is_additive(self)->bool:return not self.is_part_of_destructive_change
	@property
	def is_destructive(self)->bool:return self.is_part_of_destructive_change
	@property
	def _alter_actions(self)->t.List[exp.Expression]:
		column_def=exp.ColumnDef(this=self.column,kind=self.column_type)
		if self.position:column_def.set('position',self.position.column_position_node)
		return[column_def]
@dataclass(frozen=_C)
class TableAlterDropColumnOperation(TableAlterColumnOperation):
	cascade:bool=_A
	@property
	def is_additive(self)->bool:return _A
	@property
	def is_destructive(self)->bool:return _C
	@property
	def _alter_actions(self)->t.List[exp.Expression]:return[exp.Drop(this=self.column,kind='COLUMN',cascade=self.cascade)]
@dataclass(frozen=_C)
class TableAlterChangeColumnTypeOperation(TableAlterTypedColumnOperation):
	current_type:exp.DataType;is_part_of_destructive_change:bool=_A
	@property
	def is_additive(self)->bool:return not self.is_part_of_destructive_change
	@property
	def is_destructive(self)->bool:return self.is_part_of_destructive_change
	@property
	def _alter_actions(self)->t.List[exp.Expression]:return[exp.AlterColumn(this=self.column,dtype=self.column_type)]
@dataclass(frozen=_C)
class TableAlterColumn:
	name:str;is_struct:bool;is_array_of_struct:bool;is_array_of_primitive:bool;quoted:bool=_A
	@classmethod
	def primitive(cls,name:str,quoted:bool=_A)->TableAlterColumn:return cls(name=name,is_struct=_A,is_array_of_struct=_A,is_array_of_primitive=_A,quoted=quoted)
	@classmethod
	def struct(cls,name:str,quoted:bool=_A)->TableAlterColumn:return cls(name=name,is_struct=_C,is_array_of_struct=_A,is_array_of_primitive=_A,quoted=quoted)
	@classmethod
	def array_of_struct(cls,name:str,quoted:bool=_A)->TableAlterColumn:return cls(name=name,is_struct=_A,is_array_of_struct=_C,is_array_of_primitive=_A,quoted=quoted)
	@classmethod
	def array_of_primitive(cls,name:str,quoted:bool=_A)->TableAlterColumn:return cls(name=name,is_struct=_A,is_array_of_struct=_A,is_array_of_primitive=_C,quoted=quoted)
	@classmethod
	def from_struct_kwarg(cls,struct:exp.ColumnDef)->TableAlterColumn:
		name=struct.alias_or_name;quoted=struct.this.quoted;kwarg_type=struct.args[_D]
		if kwarg_type.is_type(exp.DataType.Type.STRUCT):return cls.struct(name,quoted=quoted)
		if kwarg_type.is_type(exp.DataType.Type.ARRAY):
			if kwarg_type.expressions and kwarg_type.expressions[0].is_type(exp.DataType.Type.STRUCT):return cls.array_of_struct(name,quoted=quoted)
			return cls.array_of_primitive(name,quoted=quoted)
		return cls.primitive(name,quoted=quoted)
	@property
	def is_array(self)->bool:return self.is_array_of_struct or self.is_array_of_primitive
	@property
	def is_primitive(self)->bool:return not self.is_struct and not self.is_array
	@property
	def is_nested(self)->bool:return not self.is_primitive
	@property
	def identifier(self)->exp.Identifier:return exp.to_identifier(self.name,quoted=self.quoted)
@dataclass(frozen=_C)
class TableAlterColumnPosition:
	is_first:bool;is_last:bool;after:t.Optional[exp.Identifier]=_B
	@classmethod
	def first(cls)->TableAlterColumnPosition:return cls(is_first=_C,is_last=_A,after=_B)
	@classmethod
	def last(cls,after:t.Optional[t.Union[str,exp.Identifier]]=_B)->TableAlterColumnPosition:return cls(is_first=_A,is_last=_C,after=exp.to_identifier(after)if after else _B)
	@classmethod
	def middle(cls,after:t.Union[str,exp.Identifier])->TableAlterColumnPosition:return cls(is_first=_A,is_last=_A,after=exp.to_identifier(after))
	@classmethod
	def create(cls,pos:int,current_kwargs:t.List[exp.ColumnDef],replacing_col:bool=_A)->TableAlterColumnPosition:
		is_first=pos==0;is_last=pos==len(current_kwargs)-int(replacing_col);after=_B
		if not is_first:prior_kwarg=current_kwargs[pos-1];after,_=_get_name_and_type(prior_kwarg)
		return cls(is_first=is_first,is_last=is_last,after=after)
	@property
	def column_position_node(self)->t.Optional[exp.ColumnPosition]:
		column=self.after if not self.is_last else _B;position=_B
		if self.is_first:position='FIRST'
		elif column and not self.is_last:position='AFTER'
		return exp.ColumnPosition(this=column,position=position)
class NestedSupport(str,Enum):
	ALL='ALL';NONE='NONE';ALL_BUT_DROP='ALL_BUT_DROP';IGNORE='IGNORE'
	@property
	def is_all(self)->bool:return self==NestedSupport.ALL
	@property
	def is_none(self)->bool:return self==NestedSupport.NONE
	@property
	def is_all_but_drop(self)->bool:return self==NestedSupport.ALL_BUT_DROP
	@property
	def is_ignore(self)->bool:return self==NestedSupport.IGNORE
class SchemaDiffer(PydanticModel):
	support_positional_add:bool=_A;nested_support:NestedSupport=NestedSupport.NONE;array_element_selector:str='';compatible_types:t.Dict[exp.DataType,t.Set[exp.DataType]]={};coerceable_types_:t.Dict[exp.DataType,t.Set[exp.DataType]]=Field(default_factory=dict,alias='coerceable_types');precision_increase_allowed_types:t.Optional[t.Set[exp.DataType.Type]]=_B;support_coercing_compatible_types:bool=_A;drop_cascade:bool=_A;parameterized_type_defaults:t.Dict[exp.DataType.Type,t.List[t.Tuple[t.Union[int,float],...]]]={};max_parameter_length:t.Dict[exp.DataType.Type,t.Union[int,float]]={};types_with_unlimited_length:t.Dict[exp.DataType.Type,t.Set[exp.DataType.Type]]={};treat_alter_data_type_as_destructive:bool=_A;_coerceable_types:t.Dict[exp.DataType,t.Set[exp.DataType]]={}
	@property
	def coerceable_types(self)->t.Dict[exp.DataType,t.Set[exp.DataType]]:
		if not self._coerceable_types:
			if not self.support_coercing_compatible_types or not self.compatible_types:return self.coerceable_types_
			coerceable_types:t.Dict[exp.DataType,t.Set[exp.DataType]]=defaultdict(set);coerceable_types.update(self.coerceable_types_)
			for(source_type,target_types)in self.compatible_types.items():
				for target_type in target_types:coerceable_types[target_type].add(source_type)
			self._coerceable_types=coerceable_types
		return self._coerceable_types
	def _is_compatible_type(self,current_type:exp.DataType,new_type:exp.DataType)->bool:
		if current_type==new_type or self._is_precision_increase_allowed(current_type)and self._is_precision_increase(current_type,new_type):return _C
		if current_type in self.compatible_types:return new_type in self.compatible_types[current_type]
		if not new_type.expressions and new_type.this in self.types_with_unlimited_length:return current_type.this in self.types_with_unlimited_length[new_type.this]
		return _A
	def _is_coerceable_type(self,current_type:exp.DataType,new_type:exp.DataType)->bool:
		if current_type in self.coerceable_types:
			is_coerceable=new_type in self.coerceable_types[current_type]
			if is_coerceable:from vulcan.core.console import get_console;get_console().log_warning(f"Coercing type {current_type} to {new_type} which means an alter will not be performed and therefore the resulting table structure will not match what is in the query.\nUpdate your model to cast the value to {current_type} type in order to remove this warning.")
			return is_coerceable
		return _A
	def _is_precision_increase_allowed(self,current_type:exp.DataType)->bool:return self.precision_increase_allowed_types is _B or current_type.this in self.precision_increase_allowed_types
	def _is_precision_increase(self,current_type:exp.DataType,new_type:exp.DataType)->bool:
		if current_type.this==new_type.this and not current_type.is_type(*exp.DataType.NESTED_TYPES):
			current_params=self.get_type_parameters(current_type);new_params=self.get_type_parameters(new_type)
			if len(current_params)!=len(new_params):return _A
			return all(new>=current for(current,new)in zip(current_params,new_params))
		return _A
	def get_type_parameters(self,type:exp.DataType)->t.List[t.Union[int,float]]:
		def _str_to_number(string:str,allows_max_param:bool)->t.Union[int,float]:
			try:return int(string)
			except ValueError:
				try:return float(string)
				except ValueError:
					if allows_max_param and string.upper()=='MAX':return self.max_parameter_length[type.this]
					raise ValueError(f"Could not convert '{string}' to a number")
		params=[_str_to_number(param.this.this,type.this in self.max_parameter_length)for param in type.expressions];param_defaults:t.Tuple[t.Union[int,float],...]=()
		if type.this in self.parameterized_type_defaults:
			param_defaults_list=self.parameterized_type_defaults[type.this]
			if len(params)<len(param_defaults_list):param_defaults=param_defaults_list[len(params)]
		return[*params,*param_defaults]
	def _get_matching_kwarg(self,current_kwarg:t.Union[str,exp.ColumnDef],new_struct:exp.DataType,current_pos:int)->t.Tuple[t.Optional[int],t.Optional[exp.ColumnDef]]:
		current_name=exp.to_identifier(current_kwarg)if isinstance(current_kwarg,str)else _get_name_and_type(current_kwarg)[0];new_kwarg=seq_get(new_struct.expressions,current_pos)
		if new_kwarg:
			new_name,new_type=_get_name_and_type(new_kwarg)
			if current_name.this==new_name.this:return current_pos,new_kwarg
		for(i,new_kwarg)in enumerate(new_struct.expressions):
			new_name,new_type=_get_name_and_type(new_kwarg)
			if current_name.this==new_name.this:return i,new_kwarg
		return _B,_B
	def _drop_operation(self,columns:t.Union[TableAlterColumn,t.List[TableAlterColumn]],struct:exp.DataType,pos:int,root_struct:exp.DataType,table_name:TableName)->t.List[TableAlterColumnOperation]:
		columns=ensure_list(columns);operations:t.List[TableAlterColumnOperation]=[];column_pos,column_kwarg=self._get_matching_kwarg(columns[-1].name,struct,pos)
		if column_pos is _B or not column_kwarg:raise VulcanError(f"Cannot drop column '{columns[-1].name}' from table '{table_name}' - column not found. This may indicate a mismatch between the expected and actual table schemas.")
		struct.expressions.pop(column_pos);operations.append(TableAlterDropColumnOperation(target_table=exp.to_table(table_name),column_parts=columns,expected_table_struct=root_struct.copy(),cascade=self.drop_cascade,array_element_selector=self.array_element_selector));return operations
	def _requires_drop_alteration(self,current_struct:exp.DataType,new_struct:exp.DataType)->bool:
		for(current_pos,current_kwarg)in enumerate(current_struct.expressions.copy()):
			new_pos,_=self._get_matching_kwarg(current_kwarg,new_struct,current_pos)
			if new_pos is _B:return _C
		return _A
	def _resolve_drop_operation(self,parent_columns:t.List[TableAlterColumn],current_struct:exp.DataType,new_struct:exp.DataType,root_struct:exp.DataType,table_name:TableName)->t.List[TableAlterColumnOperation]:
		operations=[]
		for(current_pos,current_kwarg)in enumerate(current_struct.expressions.copy()):
			new_pos,_=self._get_matching_kwarg(current_kwarg,new_struct,current_pos);columns=parent_columns+[TableAlterColumn.from_struct_kwarg(current_kwarg)]
			if new_pos is _B:operations.extend(self._drop_operation(columns,current_struct,current_pos,root_struct,table_name))
		return operations
	def _add_operation(self,columns:t.List[TableAlterColumn],new_pos:int,new_kwarg:exp.ColumnDef,current_struct:exp.DataType,root_struct:exp.DataType,table_name:TableName,is_part_of_destructive_change:bool=_A)->t.List[TableAlterColumnOperation]:
		if self.support_positional_add:col_pos=TableAlterColumnPosition.create(new_pos,current_struct.expressions);current_struct.expressions.insert(new_pos,new_kwarg)
		else:col_pos=_B;current_struct.expressions.append(new_kwarg)
		return[TableAlterAddColumnOperation(target_table=exp.to_table(table_name),column_parts=columns,column_type=new_kwarg.args[_D],expected_table_struct=root_struct.copy(),position=col_pos,is_part_of_destructive_change=is_part_of_destructive_change,array_element_selector=self.array_element_selector)]
	def _resolve_add_operations(self,parent_columns:t.List[TableAlterColumn],current_struct:exp.DataType,new_struct:exp.DataType,root_struct:exp.DataType,table_name:TableName)->t.List[TableAlterColumnOperation]:
		operations=[]
		for(new_pos,new_kwarg)in enumerate(new_struct.expressions):
			possible_current_pos,_=self._get_matching_kwarg(new_kwarg,current_struct,new_pos)
			if possible_current_pos is _B:columns=parent_columns+[TableAlterColumn.from_struct_kwarg(new_kwarg)];operations.extend(self._add_operation(columns,new_pos,new_kwarg,current_struct,root_struct,table_name))
		return operations
	def _alter_operation(self,columns:t.List[TableAlterColumn],pos:int,struct:exp.DataType,new_type:exp.DataType,current_type:t.Union[str,exp.DataType],root_struct:exp.DataType,new_kwarg:exp.ColumnDef,table_name:TableName,*,ignore_destructive:bool=_A,ignore_additive:bool=_A)->t.List[TableAlterColumnOperation]:
		current_type=exp.DataType.build(current_type,copy=_A)
		if not self.nested_support.is_none:
			if new_type.this==current_type.this==exp.DataType.Type.STRUCT:
				if self.nested_support.is_ignore:return[]
				if self.nested_support.is_all or not self._requires_drop_alteration(current_type,new_type):return self._get_operations(columns,current_type,new_type,root_struct,table_name,ignore_destructive=ignore_destructive,ignore_additive=ignore_additive)
			if new_type.this==current_type.this==exp.DataType.Type.ARRAY:
				if not new_type.expressions or not current_type.expressions:return[]
				new_array_type=new_type.expressions[0];current_array_type=current_type.expressions[0]
				if new_array_type.this==current_array_type.this==exp.DataType.Type.STRUCT:
					if self.nested_support.is_ignore:return[]
					if self.nested_support.is_all or not self._requires_drop_alteration(current_array_type,new_array_type):return self._get_operations(columns,current_array_type,new_array_type,root_struct,table_name,ignore_destructive=ignore_destructive,ignore_additive=ignore_additive)
		if self._is_coerceable_type(current_type,new_type):return[]
		if self._is_compatible_type(current_type,new_type):
			if ignore_additive:return[]
			struct.expressions.pop(pos);struct.expressions.insert(pos,new_kwarg);return[TableAlterChangeColumnTypeOperation(target_table=exp.to_table(table_name),column_parts=columns,column_type=new_type,current_type=current_type,expected_table_struct=root_struct.copy(),array_element_selector=self.array_element_selector,is_part_of_destructive_change=self.treat_alter_data_type_as_destructive)]
		if ignore_destructive:return[]
		return self._drop_operation(columns,root_struct,pos,root_struct,table_name)+self._add_operation(columns,pos,new_kwarg,struct,root_struct,table_name,is_part_of_destructive_change=_C)
	def _resolve_alter_operations(self,parent_columns:t.List[TableAlterColumn],current_struct:exp.DataType,new_struct:exp.DataType,root_struct:exp.DataType,table_name:TableName,*,ignore_destructive:bool=_A,ignore_additive:bool=_A)->t.List[TableAlterColumnOperation]:
		operations=[]
		for(current_pos,current_kwarg)in enumerate(current_struct.expressions.copy()):
			_,new_kwarg=self._get_matching_kwarg(current_kwarg,new_struct,current_pos)
			if new_kwarg is _B:
				if ignore_destructive:continue
				raise ValueError('Cannot alter a column that is being dropped')
			_,new_type=_get_name_and_type(new_kwarg);_,current_type=_get_name_and_type(current_kwarg);columns=parent_columns+[TableAlterColumn.from_struct_kwarg(current_kwarg)]
			if new_type==current_type:continue
			operations.extend(self._alter_operation(columns,current_pos,current_struct,new_type,current_type,root_struct,new_kwarg,table_name,ignore_destructive=ignore_destructive,ignore_additive=ignore_additive))
		return operations
	def _get_operations(self,parent_columns:t.List[TableAlterColumn],current_struct:exp.DataType,new_struct:exp.DataType,root_struct:exp.DataType,table_name:TableName,*,ignore_destructive:bool=_A,ignore_additive:bool=_A)->t.List[TableAlterColumnOperation]:
		root_struct=root_struct or current_struct;parent_columns=parent_columns or[];operations=[]
		if not ignore_destructive:operations.extend(self._resolve_drop_operation(parent_columns,current_struct,new_struct,root_struct,table_name))
		if not ignore_additive:operations.extend(self._resolve_add_operations(parent_columns,current_struct,new_struct,root_struct,table_name))
		operations.extend(self._resolve_alter_operations(parent_columns,current_struct,new_struct,root_struct,ignore_destructive=ignore_destructive,ignore_additive=ignore_additive,table_name=table_name));return operations
	def _from_structs(self,current_struct:exp.DataType,new_struct:exp.DataType,table_name:TableName,*,ignore_destructive:bool=_A,ignore_additive:bool=_A)->t.List[TableAlterColumnOperation]:return self._get_operations([],current_struct,new_struct,current_struct,table_name=table_name,ignore_destructive=ignore_destructive,ignore_additive=ignore_additive)
	def _compare_structs(self,table_name:t.Union[str,exp.Table],current:exp.DataType,new:exp.DataType,*,ignore_destructive:bool=_A,ignore_additive:bool=_A)->t.List[TableAlterColumnOperation]:return self._from_structs(current,new,table_name=table_name,ignore_destructive=ignore_destructive,ignore_additive=ignore_additive)
	def compare_columns(self,table_name:TableName,current:t.Dict[str,exp.DataType],new:t.Dict[str,exp.DataType],*,ignore_destructive:bool=_A,ignore_additive:bool=_A)->t.List[TableAlterColumnOperation]:return self._compare_structs(table_name,columns_to_types_to_struct(current),columns_to_types_to_struct(new),ignore_destructive=ignore_destructive,ignore_additive=ignore_additive)
def has_drop_alteration(alter_operations:t.List[TableAlterOperation])->bool:return any(op.is_destructive for op in alter_operations)
def has_additive_alteration(alter_operations:t.List[TableAlterOperation])->bool:return any(op.is_additive for op in alter_operations)
def get_additive_changes(alter_operations:t.List[TableAlterOperation])->t.List[TableAlterOperation]:return[x for x in alter_operations if x.is_additive]
def get_dropped_column_names(alter_expressions:t.List[TableAlterOperation])->t.List[str]:return[op.column.alias_or_name for op in alter_expressions if isinstance(op,TableAlterDropColumnOperation)]
def get_additive_column_names(alter_expressions:t.List[TableAlterOperation])->t.List[str]:return[op.column.alias_or_name for op in alter_expressions if op.is_additive and isinstance(op,TableAlterColumnOperation)]
def get_schema_differ(dialect:str,overrides:t.Optional[t.Dict[str,t.Any]]=_B)->SchemaDiffer:from vulcan.core.engine_adapter import DIALECT_TO_ENGINE_ADAPTER,DIALECT_ALIASES,EngineAdapter;dialect=dialect.lower();dialect=DIALECT_ALIASES.get(dialect,dialect);engine_adapter_class=DIALECT_TO_ENGINE_ADAPTER.get(dialect,EngineAdapter);return SchemaDiffer(**{**getattr(engine_adapter_class,'SCHEMA_DIFFER_KWARGS'),**(overrides or{})})
def _get_name_and_type(struct:exp.ColumnDef)->t.Tuple[exp.Identifier,exp.DataType]:return struct.this,struct.args[_D]