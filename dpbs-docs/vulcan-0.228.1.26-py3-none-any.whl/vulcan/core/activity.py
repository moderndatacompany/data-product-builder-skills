from __future__ import annotations
_M='_run_success'
_L='_audits'
_K='_errors'
_J='_models'
_I='_wrapped'
_H='unknown'
_G='BREAKING'
_F='Plan'
_E='INDIRECT_BREAKING'
_D='ignore'
_C=True
_B=False
_A=None
import typing as t
from pathlib import Path
from typing import Any,Literal
from pydantic import ConfigDict,Field
import logging,os,time
_activity_logger=logging.getLogger(__name__)
from vulcan.core import constants as c
from vulcan.core.node import NodeType,SchemaDrift
from vulcan.core.model.kind import ModelKindName
from vulcan.core.snapshot.definition import Intervals
from vulcan.core.model.definition import AuditResult
from vulcan.core.snapshot import SnapshotChangeCategory,Snapshot,SnapshotIntervals,SnapshotTableInfo
from vulcan.core.soda3.spec import CheckOutcome,QualitySummary,CheckResult,ModelProfile
SnapshotChangeCategoryLiteral=Literal[_G,'NON_BREAKING','FORWARD_ONLY',_E,'INDIRECT_NON_BREAKING','METADATA']
from vulcan.utils.pydantic import PydanticModel,model_validator
from vulcan.utils.errors import NodeAuditsErrors
from vulcan.utils.concurrency import NodeExecutionFailedError
from vulcan.utils.date import TimeLike,to_timestamp
from sqlglot import exp
if t.TYPE_CHECKING:from vulcan.core.plan import Plan;from vulcan.core.context_diff import ContextDiff;from vulcan.core.environment import EnvironmentNamingInfo;from vulcan.core.snapshot import Snapshot;from vulcan.core.console import Console,QueryExecutionStats;from vulcan.core.snapshot.definition import Interval;from vulcan.utils.git import GitClient
ImpactType=Literal['direct','indirect']
class ErrorExec(PydanticModel):
	model_config=ConfigDict(exclude_none=_C,extra=_D);model_fqn:t.Optional[str]=_A;model_name:t.Optional[str]=_A;error_class:str;message:str;is_audit_error:bool=_B;audit_name:t.Optional[str]=_A;audit_failed_rows:t.Optional[int]=_A;audit_sql:t.Optional[str]=_A;audit_args:t.Optional[t.Dict[str,t.Any]]=_A;audit_adapter_dialect:t.Optional[str]=_A
	@staticmethod
	def serialize_audit_args(audit_args:t.Optional[t.Dict[str,t.Any]],dialect:t.Optional[str]=_A)->t.Optional[t.Dict[str,t.Any]]:
		if audit_args is _A or not audit_args:return audit_args
		def _serialize_value(value:t.Any)->t.Any:
			if isinstance(value,exp.Expression):return value.sql(dialect=dialect)if dialect else value.sql()
			elif isinstance(value,dict):return{k:_serialize_value(v)for(k,v)in value.items()}
			elif isinstance(value,(list,tuple)):serialized_list=[_serialize_value(item)for item in value];return tuple(serialized_list)if isinstance(value,tuple)else serialized_list
			else:return value
		serialized={}
		for(key,value)in audit_args.items():serialized[key]=_serialize_value(value)
		return serialized
	@model_validator(mode='before')
	@classmethod
	def _serialize_audit_args_on_init(cls,data:t.Any)->t.Any:
		A='audit_args'
		if isinstance(data,dict):
			dialect=data.get('audit_adapter_dialect')
			if A in data and data[A]is not _A:data[A]=cls.serialize_audit_args(data[A],dialect=dialect)
		return data
class EnvironmentChange(PydanticModel):environment:str;has_plan:bool=_B;has_run:bool=_B
class ModelLatestAction(PydanticModel):
	model_name:str;plan_id:t.Optional[str]=_A;plan_start_ts:t.Optional[int]=_A;plan_end_ts:t.Optional[int]=_A;impact_type:t.Optional[ImpactType]=_A;run_id:t.Optional[str]=_A;run_start_ts:t.Optional[int]=_A;run_end_ts:t.Optional[int]=_A;rows_affected:t.Optional[int]=_A;bytes_processed:t.Optional[int]=_A;evaluation_ms:t.Optional[int]=_A;success:t.Optional[bool]=_A
	@property
	def plan_duration(self)->t.Optional[int]:
		if self.plan_start_ts and self.plan_end_ts:return self.plan_end_ts-self.plan_start_ts
	@property
	def run_duration(self)->t.Optional[int]:
		if self.run_start_ts and self.run_end_ts:return self.run_end_ts-self.run_start_ts
	@property
	def has_plan(self)->bool:return self.plan_id is not _A
	@property
	def has_run(self)->bool:return self.run_id is not _A
class BackfillInfo(PydanticModel):
	model_config=ConfigDict(extra=_D);name:str;fqn:str;node_type:NodeType;snapshot_id:str;version:str;model_kind:t.Optional[ModelKindName]=_A;intervals:Intervals;is_directly_modified:bool=_B
	@property
	def merged_intervals(self)->Intervals:from vulcan.core.snapshot.definition import merge_intervals;return merge_intervals(self.intervals)
	def format_intervals(self,unit:t.Optional[str]=_A)->str:from vulcan.core.snapshot.definition import format_intervals;return format_intervals(self.merged_intervals,unit)
	@classmethod
	def from_plan(cls,plan:_F,default_catalog:t.Optional[str]=_A)->t.List['BackfillInfo']:
		context_diff=plan.context_diff;environment_naming_info=plan.environment_naming_info;backfills=[]
		for snapshot_intervals in plan.missing_intervals or[]:
			snapshot_id=snapshot_intervals.snapshot_id
			if not snapshot_intervals.intervals or snapshot_id not in context_diff.snapshots:continue
			snapshot=context_diff.snapshots[snapshot_id];is_directly_modified=snapshot.name in context_diff.modified_snapshots and context_diff.directly_modified(snapshot.name);name=plan.get_snapshot_display_name(snapshot,default_catalog);model_kind=snapshot.model_kind_name if snapshot.node_type==NodeType.MODEL else _A;backfills.append(cls(name=name,fqn=snapshot.name,node_type=snapshot.node_type,snapshot_id=snapshot.identifier,version=snapshot.version,model_kind=model_kind,intervals=snapshot_intervals.intervals,is_directly_modified=is_directly_modified))
		return backfills
class ChangeDisplay(PydanticModel):model_config=ConfigDict(extra=_D);name:str;fqn:str;snapshot_id:str;version:str;node_type:NodeType;model_kind:t.Optional[ModelKindName]=_A;parents:t.Set[str]=Field(default_factory=set)
class ChangeDirect(ChangeDisplay):diff:str;indirect:t.List[ChangeDisplay]=Field(default_factory=list);direct:t.List[ChangeDisplay]=Field(default_factory=list);change_category:t.Optional[SnapshotChangeCategoryLiteral]=_A;data_hash_changed:bool=_B;metadata_hash_changed:bool=_B;parent_data_hash_changed:bool=_B;old_version:str='';old_snapshot_id:str='';schema_diff:t.Optional['SchemaDrift']=_A;needs_backfill:bool=_B
class ChangeIndirect(ChangeDisplay):change_category:t.Optional[SnapshotChangeCategoryLiteral]=_A;needs_backfill:bool=_B
class ChangeAdded(ChangeDisplay):0
class ChangeRemoved(ChangeDisplay):0
class ModelsDiff(PydanticModel):
	model_config=ConfigDict(extra=_D);direct:t.List[ChangeDirect]=Field(default_factory=list);indirect:t.List[ChangeIndirect]=Field(default_factory=list);added:t.List[ChangeAdded]=Field(default_factory=list);removed:t.List[ChangeRemoved]=Field(default_factory=list);metadata:t.List[ChangeDisplay]=Field(default_factory=list)
	@classmethod
	def from_plan(cls,plan:_F,default_catalog:t.Optional[str]=_A)->'ModelsDiff':
		from vulcan.core.snapshot.definition import SnapshotId;context_diff=plan.context_diff;environment_naming_info=plan.environment_naming_info;modified_snapshots=context_diff.modified_snapshots.items()
		def model_kind(snapshot:Snapshot)->t.Optional[ModelKindName]:
			if snapshot.node_type==NodeType.MODEL:return snapshot.model_kind_name
		def _get_parents(current:Snapshot,visited:t.Optional[t.Dict[str,t.Set[str]]]=_A)->t.Set[str]:
			current_fqn=current.name;visited=visited or{current_fqn:{p.name for p in current.parents}};parents:t.Set[str]=set()
			for parent in current.parents:
				parent_fqn=parent.name
				if parent.name not in context_diff.modified_snapshots:continue
				snapshot,_=context_diff.modified_snapshots[parent.name];parents=parents|{parent_fqn}|visited.get(parent_fqn,_get_parents(snapshot,visited))
			return parents
		def _build_change_display(snapshot:Snapshot,parents:t.Set[str])->ChangeDisplay:return ChangeDisplay(name=plan.get_snapshot_display_name(snapshot,default_catalog),fqn=snapshot.name,snapshot_id=snapshot.identifier,version=snapshot.version,node_type=snapshot.node_type,model_kind=model_kind(snapshot),parents=parents)
		metadata:t.List[ChangeDisplay]=[];direct:t.List[ChangeDirect]=[];indirect:t.List[ChangeIndirect]=[];added:t.List[ChangeAdded]=[];removed:t.List[ChangeRemoved]=[]
		for(name,(current,old_snap))in modified_snapshots:
			parents=_get_parents(current);base_change=_build_change_display(current,parents)
			if context_diff.directly_modified(name):change_direct=ChangeDirect(**base_change.model_dump(),diff=context_diff.text_diff(name)or'',change_category=current.change_category.name if current.change_category else _A,data_hash_changed=old_snap.fingerprint.data_hash!=current.fingerprint.data_hash if old_snap else _B,metadata_hash_changed=old_snap.fingerprint.metadata_hash!=current.fingerprint.metadata_hash if old_snap else _B,parent_data_hash_changed=old_snap.fingerprint.parent_data_hash!=current.fingerprint.parent_data_hash if old_snap else _B,old_version=old_snap.version or''if old_snap else'',old_snapshot_id=old_snap.identifier if old_snap else'',schema_diff=context_diff.schema_diff(name),needs_backfill=current.is_new_version);direct.append(change_direct)
			elif context_diff.indirectly_modified(name):change_indirect=ChangeIndirect(**base_change.model_dump(),change_category=current.change_category.name if current.change_category else _A,needs_backfill=current.is_new_version);indirect.append(change_indirect)
			elif context_diff.metadata_updated(name):metadata.append(base_change)
		for snapshot_id in context_diff.added:
			if snapshot_id in context_diff.snapshots:snapshot=context_diff.snapshots[snapshot_id];parents=_get_parents(snapshot);base_change=_build_change_display(snapshot,parents);added.append(ChangeAdded(**base_change.model_dump()))
		for(snapshot_id,snapshot_info)in context_diff.removed_snapshots.items():name=snapshot_info.display_name(environment_naming_info,default_catalog,dialect=_A);removed.append(ChangeRemoved(name=name,fqn=snapshot_info.name,snapshot_id=snapshot_info.identifier,version=snapshot_info.version or'',node_type=snapshot_info.node_type,model_kind=snapshot_info.kind_name,parents=set()))
		for change_direct in direct:change_direct.indirect=[ChangeDisplay(**c.model_dump())for c in indirect if change_direct.fqn in c.parents];change_direct.direct=[ChangeDisplay(**c.model_dump())for c in direct if change_direct.fqn in c.parents]
		return cls(direct=direct,indirect=indirect,added=added,removed=removed,metadata=metadata)
class PlanActivity(PydanticModel):
	model_config=ConfigDict(extra=_D,frozen=_C);plan_id:str;environment:str;start_ts:int;end_ts:int;executor:str=_H;git_commit_sha:t.Optional[str]=_A;git_commit_url:t.Optional[str]=_A;prev_plan_id:t.Optional[str]=_A;plan_seq:int=0;version:str=c.DEFAULT_VERSION;requirements_diff:t.Optional[str]=_A;env_statements_diff:t.Optional[str]=_A;changes:ModelsDiff=Field(default_factory=ModelsDiff);backfills:t.List[BackfillInfo]=Field(default_factory=list);errors:t.List[ErrorExec]=Field(default_factory=list);success:bool=_C
	@property
	def apply_duration_ts(self)->float:return float(self.end_ts-self.start_ts)
	@property
	def has_changes(self)->bool:req_note=(self.requirements_diff or'').strip();env_note=(self.env_statements_diff or'').strip();return bool(self.changes.direct or self.changes.indirect or self.changes.added or self.changes.removed or self.changes.metadata or self.backfills or req_note or env_note)
	@property
	def has_breaking_changes(self)->bool:
		for change in self.changes.direct:
			if change.change_category in(_G,_E):return _C
		for change in self.changes.indirect:
			if change.change_category==_E:return _C
		return _B
	@property
	def requires_backfill(self)->bool:return len(self.backfills)>0
	@property
	def models_affected_directly(self)->t.List[str]:
		models=set()
		for change in self.changes.direct+self.changes.added+self.changes.removed:
			if change.node_type==NodeType.MODEL:models.add(change.name)
		return sorted(models)
	@property
	def models_affected_indirectly(self)->t.List[str]:
		models=set()
		for change in self.changes.indirect:
			if change.node_type==NodeType.MODEL:models.add(change.name)
		return sorted(models)
class AuditOutcomeItem(PydanticModel):model_config=ConfigDict(extra=_D);audit_name:str;skipped:bool;blocking:bool;failed_row_count:t.Optional[int]=_A;passed:bool;query_sql:t.Optional[str]=_A
class ModelIntervalAudits(PydanticModel):model_config=ConfigDict(extra=_D);model_fqn:str;model_name:t.Optional[str]=_A;interval_start:t.Optional[str]=_A;interval_end:t.Optional[str]=_A;outcomes:t.List[AuditOutcomeItem]=Field(default_factory=list)
class IntervalExec(PydanticModel):model_config=ConfigDict(extra=_D);start_ts:int;end_ts:int;evaluation_ms:int=0;rows_affected:int
class ModelExec(PydanticModel):name:str;fqn:str;model_kind:t.Optional[ModelKindName]=_A;start_ts:int;end_ts:int=0;total_batches:int=0;evaluation_ms:int=0;rows_affected:int=0;bytes_processed:int=0;intervals:t.List[IntervalExec]=Field(default_factory=list)
class RunActivity(PydanticModel):
	model_config=ConfigDict(extra=_D,frozen=_C);run_id:str;plan_id:str;environment:str;start_ts:int;end_ts:int;models_affected:t.List[ModelExec];errors:t.List[ErrorExec]=Field(default_factory=list);audits:t.List[ModelIntervalAudits]=Field(default_factory=list);success:bool;run_seq:int=0
	@property
	def run_duration_ts(self)->float:return float(self.end_ts-self.start_ts)
	@property
	def total_evaluation_ms(self)->int:return sum(m.evaluation_ms for m in self.models_affected)
	@property
	def parallelism_factor(self)->t.Optional[float]:
		if self.run_duration_ts==0:return
		return self.total_evaluation_ms/self.run_duration_ts
	@property
	def rows_affected(self)->int:return sum(m.rows_affected for m in self.models_affected)
	@property
	def bytes_processed(self)->int:return sum(m.bytes_processed for m in self.models_affected)
class RunActivityWithChecksAndProfile(RunActivity):
	quality:t.List[CheckResult]=Field(default_factory=list,description='Quality check results.');profile:t.List[ModelProfile]=Field(default_factory=list,description='Profile metrics')
	def is_healthy(self)->bool:
		if not self.quality:return _C
		for check_result in self.quality:
			if check_result.outcome==CheckOutcome.FAIL:return _B
		return _C
def build_run_activity(run_id:str,plan_id:str,environment:str,start_ts:int,end_ts:int,models:t.List[ModelExec],errors:t.List[ErrorExec],success:bool,audits:t.Optional[t.List[ModelIntervalAudits]]=_A)->RunActivity:return RunActivity(run_id=run_id,plan_id=plan_id,environment=environment,start_ts=start_ts,end_ts=end_ts,models_affected=models,errors=errors,audits=audits or[],success=success)
def _get_executor()->str:return os.environ.get('SQLMESH_USER',os.environ.get('USER',_H))
def build_plan_activity(plan:_F,start_ts:int,end_ts:int,git_client:'GitClient',default_catalog:t.Optional[str]=_A,errors:t.Optional[t.List[ErrorExec]]=_A,success:bool=_C,version:str=c.DEFAULT_VERSION)->PlanActivity:
	context_diff=plan.context_diff;req_diff:t.Optional[str]=_A
	if context_diff.has_requirement_changes:req_raw=context_diff.requirements_diff();req_diff=req_raw.strip()if req_raw.strip()else _A
	env_diff:t.Optional[str]=_A
	if context_diff.has_environment_statements_changes:env_raw=context_diff.environment_statements_diff_text(include_python_env=not context_diff.is_new_environment);env_diff=env_raw.strip()if env_raw.strip()else _A
	git_commit_sha=_A;git_commit_url=_A
	try:commit_info=git_client.commit_info();git_commit_sha=commit_info.sha;git_commit_url=commit_info.url
	except Exception:pass
	changes=ModelsDiff.from_plan(plan,default_catalog);backfills=BackfillInfo.from_plan(plan,default_catalog);return PlanActivity(plan_id=plan.plan_id,environment=plan.environment.name,start_ts=start_ts,end_ts=end_ts,executor=_get_executor(),git_commit_sha=git_commit_sha,git_commit_url=git_commit_url,prev_plan_id=plan.previous_plan_id,changes=changes,backfills=backfills,errors=errors or[],success=success,version=version,requirements_diff=req_diff,env_statements_diff=env_diff)
class ActivityCapturingConsoleWrapper:
	def __init__(self,wrapped_console:'Console'):object.__setattr__(self,_I,wrapped_console);object.__setattr__(self,_J,{});object.__setattr__(self,_K,[]);object.__setattr__(self,_L,[]);object.__setattr__(self,_M,_C)
	def __getattr__(self,name:str)->t.Any:return getattr(self._wrapped,name)
	def __setattr__(self,name:str,value:t.Any)->_A:
		if name in(_I,_J,_K,_L,_M):object.__setattr__(self,name,value)
		else:setattr(self._wrapped,name,value)
	def start_snapshot_evaluation_progress(self,snapshot:Snapshot,audit_only:bool=_B)->_A:
		if snapshot.is_model:fqn=snapshot.name;name=snapshot.node.name;self._models[fqn]=ModelExec(name=name,fqn=fqn,model_kind=snapshot.model_kind_name,start_ts=int(time.time()))
		return self._wrapped.start_snapshot_evaluation_progress(snapshot,audit_only)
	def on_audits_completed(self,snapshot:Snapshot,audit_results:t.List[AuditResult],*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,adapter_dialect:str='')->_A:
		outcomes:t.List[AuditOutcomeItem]=[]
		for ar in audit_results:
			if ar.skipped:passed=_B
			elif ar.count is _A:passed=_B
			else:passed=ar.count==0
			qsql=ar.query.sql(dialect=adapter_dialect)if ar.query is not _A else _A;outcomes.append(AuditOutcomeItem(audit_name=ar.audit.name,skipped=ar.skipped,blocking=ar.blocking,failed_row_count=ar.count,passed=passed,query_sql=qsql))
		capture=ModelIntervalAudits(model_fqn=snapshot.name,model_name=snapshot.node.name if snapshot.is_model else _A,interval_start=str(start)if start is not _A else _A,interval_end=str(end)if end is not _A else _A,outcomes=outcomes);self._audits.append(capture);summary='; '.join(f"{it.audit_name}:{'skip'if it.skipped else'pass'if it.passed else f'fail({it.failed_row_count})'}"for it in capture.outcomes)or'none';_activity_logger.info('[audits] %s | %s [%s..%s] %s',capture.model_name or'-',capture.model_fqn,capture.interval_start or'?',capture.interval_end or'?',summary);return self._wrapped.on_audits_completed(snapshot,audit_results,start=start,end=end,adapter_dialect=adapter_dialect)
	def update_snapshot_evaluation_progress(self,snapshot:Snapshot,interval:'Interval',batch_idx:int,evaluation_duration_ms:t.Optional[int],num_audits_passed:int,num_audits_failed:int,audit_only:bool=_B,execution_stats:t.Optional['QueryExecutionStats']=_A,auto_restatement_triggers:t.Optional[t.Any]=_A)->_A:
		if snapshot.is_model:
			fqn=snapshot.name;model=self._models.get(fqn)
			if model is not _A:
				model.total_batches+=1
				if evaluation_duration_ms:model.evaluation_ms+=evaluation_duration_ms
				if execution_stats:
					if execution_stats.total_rows_processed is not _A:model.rows_affected+=execution_stats.total_rows_processed
					if execution_stats.total_bytes_processed is not _A:model.bytes_processed+=execution_stats.total_bytes_processed
				interval_exec=IntervalExec(start_ts=int(to_timestamp(interval[0]))if interval else 0,end_ts=int(to_timestamp(interval[1]))if interval else 0,evaluation_ms=evaluation_duration_ms if evaluation_duration_ms else 0,rows_affected=execution_stats.total_rows_processed if execution_stats and execution_stats.total_rows_processed is not _A else 0);model.intervals.append(interval_exec);model.end_ts=int(time.time())
		return self._wrapped.update_snapshot_evaluation_progress(snapshot,interval,batch_idx,evaluation_duration_ms,num_audits_passed,num_audits_failed,audit_only,execution_stats,auto_restatement_triggers)
	def stop_evaluation_progress(self,success:bool=_C)->_A:self._run_success=success;return self._wrapped.stop_evaluation_progress(success)
	def log_failed_models(self,errors:t.List[NodeExecutionFailedError])->_A:
		from vulcan.core.snapshot import SnapshotId
		for error in errors:
			model_fqn=_A;model_name=_A
			if isinstance(error.node,SnapshotId):model_fqn=error.node.name
			elif hasattr(error.node,'snapshot_name'):model_fqn=error.node.snapshot_name
			if model_fqn and model_fqn in self._models:model_name=self._models[model_fqn].name
			if isinstance(error.__cause__,NodeAuditsErrors):
				for audit_error in error.__cause__.errors:exec_error=ErrorExec(model_fqn=model_fqn,model_name=model_name,error_class='AuditError',message=str(audit_error),is_audit_error=_C,audit_name=audit_error.audit_name,audit_failed_rows=audit_error.count,audit_sql=audit_error.query.sql()if audit_error.query else _A,audit_args=audit_error.audit_args,audit_adapter_dialect=audit_error.adapter_dialect);self._errors.append(exec_error)
			else:
				cause=error.__cause__ if error.__cause__ else error;error_msg=str(cause)
				if len(error_msg)>2000:error_msg=error_msg[:2000]+'... (truncated)'
				exec_error=ErrorExec(model_fqn=model_fqn,model_name=model_name,error_class=cause.__class__.__name__,message=error_msg,is_audit_error=_B);self._errors.append(exec_error)
		if errors:self._run_success=_B
		return self._wrapped.log_failed_models(errors)
	def get_captured_data(self)->t.Tuple[t.List[ModelExec],t.List[ModelIntervalAudits],t.List[ErrorExec],bool]:models=list(self._models.values());audits=list(self._audits);errors=list(self._errors);return models,audits,errors,self._run_success