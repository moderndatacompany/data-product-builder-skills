from __future__ import annotations
_j='recreate view'
_i='console'
_h='success'
_g='warnings'
_f='Test Failure Summary'
_e='Apply - Virtual Update'
_d='backfill'
_c='preview'
_b='{task.description}'
_a='State Connection'
_Z='Evaluating'
_Y='duration'
_X='annotation'
_W='simpleDots'
_V='{task.fields[view_name]}'
_U='Connection'
_T='8rem'
_S='[indirect]Indirectly Modified Children:'
_R='Auditing'
_Q='green'
_P='value'
_O='new'
_N='  '
_M='sql'
_L='right'
_K='\n\n'
_J='failed'
_I='succeeded'
_H='\n  '
_G=', '
_F='name'
_E='width'
_D='\n'
_C=False
_B=True
_A=None
import abc,datetime,typing as t,unittest,uuid,logging,textwrap
from humanize import metric,naturalsize
from itertools import zip_longest
from pathlib import Path
from hyperscript import h
from rich.console import Console as RichConsole
from rich.live import Live
from rich.progress import BarColumn,Progress,SpinnerColumn,TaskID,TextColumn,TimeElapsedColumn
from rich.prompt import Confirm,Prompt
from rich.status import Status
from rich.syntax import Syntax
from rich.table import Table
from rich.tree import Tree
from sqlglot import exp
from vulcan.core.schema_diff import TableAlterOperation
from vulcan.core.test.result import ModelTextTestResult
from vulcan.core.environment import EnvironmentNamingInfo,EnvironmentSummary
from vulcan.core.linter.source import LintSource,lint_source_path
from vulcan.core.linter.rule import RuleViolation
from vulcan.core.model import Model
from vulcan.core.model.definition import AuditResult
from vulcan.core.snapshot import Snapshot,SnapshotChangeCategory,SnapshotId,SnapshotInfoLike
from vulcan.core.snapshot.definition import Interval,Intervals,SnapshotTableInfo
from vulcan.core.snapshot.execution_tracker import QueryExecutionStats
from vulcan.core.test import ModelTest
from vulcan.utils import rich as srich
from vulcan.utils import Verbosity
from vulcan.utils.concurrency import NodeExecutionFailedError
from vulcan.utils.date import TimeLike,time_like_to_str,to_date,yesterday_ds,to_ds,make_inclusive
from vulcan.utils.errors import AuditError,PythonModelEvalError,NodeAuditsErrors,format_destructive_change_msg,format_additive_change_msg,rebrand
from vulcan.utils.rich import strip_ansi_codes
from vulcan.utils.sql import format_sql_for_display
if t.TYPE_CHECKING:import ipywidgets as widgets;from sqlglot import exp;from sqlglot.dialects.dialect import DialectType;from vulcan.core.context_diff import ContextDiff;from vulcan.core.plan import Plan,EvaluatablePlan,PlanBuilder,SnapshotIntervals;from vulcan.core.table_diff import TableDiff,RowDiff,SchemaDiff;from vulcan.core.config.connection import ConnectionConfig;from vulcan.core.state_sync import Versions;LayoutWidget=t.TypeVar('LayoutWidget',bound=t.Union[widgets.VBox,widgets.HBox])
logger=logging.getLogger(__name__)
SNAPSHOT_CHANGE_CATEGORY_STR={_A:'Unknown',SnapshotChangeCategory.BREAKING:'Breaking',SnapshotChangeCategory.NON_BREAKING:'Non-breaking',SnapshotChangeCategory.FORWARD_ONLY:'Forward-only',SnapshotChangeCategory.INDIRECT_BREAKING:'Indirect Breaking',SnapshotChangeCategory.INDIRECT_NON_BREAKING:'Indirect Non-breaking',SnapshotChangeCategory.METADATA:'Metadata'}
PROGRESS_BAR_WIDTH=40
LINE_WRAP_WIDTH=100
class LinterConsole(abc.ABC):
	@abc.abstractmethod
	def show_linter_violations(self,violations:t.List[RuleViolation],source:LintSource,is_error:bool=_C)->_A:0
class StateExporterConsole(abc.ABC):
	@abc.abstractmethod
	def start_state_export(self,output_file:Path,gateway:t.Optional[str]=_A,state_connection_config:t.Optional[ConnectionConfig]=_A,environment_names:t.Optional[t.List[str]]=_A,local_only:bool=_C,confirm:bool=_B)->bool:0
	@abc.abstractmethod
	def update_state_export_progress(self,version_count:t.Optional[int]=_A,versions_complete:bool=_C,snapshot_count:t.Optional[int]=_A,snapshots_complete:bool=_C,environment_count:t.Optional[int]=_A,environments_complete:bool=_C)->_A:0
	@abc.abstractmethod
	def stop_state_export(self,success:bool,output_file:Path)->_A:0
class StateImporterConsole(abc.ABC):
	@abc.abstractmethod
	def start_state_import(self,input_file:Path,gateway:str,state_connection_config:ConnectionConfig,clear:bool=_C,confirm:bool=_B)->bool:0
	@abc.abstractmethod
	def update_state_import_progress(self,timestamp:t.Optional[str]=_A,state_file_version:t.Optional[int]=_A,versions:t.Optional[Versions]=_A,snapshot_count:t.Optional[int]=_A,snapshots_complete:bool=_C,environment_count:t.Optional[int]=_A,environments_complete:bool=_C)->_A:0
	@abc.abstractmethod
	def stop_state_import(self,success:bool,input_file:Path)->_A:0
class JanitorConsole(abc.ABC):
	@abc.abstractmethod
	def start_cleanup(self,ignore_ttl:bool)->bool:0
	@abc.abstractmethod
	def update_cleanup_progress(self,object_name:str)->_A:0
	@abc.abstractmethod
	def stop_cleanup(self,success:bool=_B)->_A:0
class DestroyConsole(abc.ABC):
	@abc.abstractmethod
	def start_destroy(self,schemas_to_delete:t.Optional[t.Set[str]]=_A,views_to_delete:t.Optional[t.Set[str]]=_A,tables_to_delete:t.Optional[t.Set[str]]=_A)->bool:0
	@abc.abstractmethod
	def stop_destroy(self,success:bool=_B)->_A:0
class EnvironmentsConsole(abc.ABC):
	@abc.abstractmethod
	def print_environments(self,environments_summary:t.List[EnvironmentSummary])->_A:0
	@abc.abstractmethod
	def show_intervals(self,snapshot_intervals:t.Dict[Snapshot,SnapshotIntervals])->_A:0
class DifferenceConsole(abc.ABC):
	@abc.abstractmethod
	def show_environment_difference_summary(self,context_diff:ContextDiff,no_diff:bool=_B)->_A:0
	@abc.abstractmethod
	def show_model_difference_summary(self,context_diff:ContextDiff,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],no_diff:bool=_B)->_A:0
class TableDiffConsole(abc.ABC):
	@abc.abstractmethod
	def show_table_diff(self,table_diffs:t.List[TableDiff],show_sample:bool=_B,skip_grain_check:bool=_C,temp_schema:t.Optional[str]=_A)->_A:0
	@abc.abstractmethod
	def update_table_diff_progress(self,model:str)->_A:0
	@abc.abstractmethod
	def start_table_diff_progress(self,models_to_diff:int)->_A:0
	@abc.abstractmethod
	def start_table_diff_model_progress(self,model:str)->_A:0
	@abc.abstractmethod
	def stop_table_diff_progress(self,success:bool)->_A:0
	@abc.abstractmethod
	def show_table_diff_details(self,models_to_diff:t.List[str])->_A:0
	@abc.abstractmethod
	def show_table_diff_summary(self,table_diff:TableDiff)->_A:0
	@abc.abstractmethod
	def show_schema_diff(self,schema_diff:SchemaDiff)->_A:0
	@abc.abstractmethod
	def show_row_diff(self,row_diff:RowDiff,show_sample:bool=_B,skip_grain_check:bool=_C)->_A:0
class BaseConsole(abc.ABC):
	@abc.abstractmethod
	def log_error(self,message:str,*args:t.Any,**kwargs:t.Any)->_A:0
	@abc.abstractmethod
	def log_warning(self,short_message:str,long_message:t.Optional[str]=_A,*args:t.Any,**kwargs:t.Any)->_A:0
	@abc.abstractmethod
	def log_success(self,message:str)->_A:0
class PlanBuilderConsole(BaseConsole,abc.ABC):
	@abc.abstractmethod
	def log_destructive_change(self,snapshot_name:str,alter_operations:t.List[TableAlterOperation],dialect:str,error:bool=_B)->_A:0
	@abc.abstractmethod
	def log_additive_change(self,snapshot_name:str,alter_operations:t.List[TableAlterOperation],dialect:str,error:bool=_B)->_A:0
class UnitTestConsole(abc.ABC):
	@abc.abstractmethod
	def log_test_results(self,result:ModelTextTestResult,target_dialect:str)->_A:0
class SignalConsole(abc.ABC):
	@abc.abstractmethod
	def start_signal_progress(self,snapshot:Snapshot,default_catalog:t.Optional[str],environment_naming_info:EnvironmentNamingInfo)->_A:0
	@abc.abstractmethod
	def update_signal_progress(self,snapshot:Snapshot,signal_name:str,signal_idx:int,total_signals:int,ready_intervals:Intervals,check_intervals:Intervals,duration:float)->_A:0
	@abc.abstractmethod
	def stop_signal_progress(self)->_A:0
class Console(SignalConsole,PlanBuilderConsole,LinterConsole,StateExporterConsole,StateImporterConsole,JanitorConsole,DestroyConsole,EnvironmentsConsole,DifferenceConsole,TableDiffConsole,BaseConsole,UnitTestConsole,abc.ABC):
	INDIRECTLY_MODIFIED_DISPLAY_THRESHOLD=10
	@abc.abstractmethod
	def start_plan_evaluation(self,plan:EvaluatablePlan)->_A:0
	@abc.abstractmethod
	def stop_plan_evaluation(self)->_A:0
	@abc.abstractmethod
	def start_evaluation_progress(self,batched_intervals:t.Dict[Snapshot,Intervals],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],audit_only:bool=_C)->_A:0
	@abc.abstractmethod
	def start_snapshot_evaluation_progress(self,snapshot:Snapshot,audit_only:bool=_C)->_A:0
	@abc.abstractmethod
	def update_snapshot_evaluation_progress(self,snapshot:Snapshot,interval:Interval,batch_idx:int,duration_ms:t.Optional[int],num_audits_passed:int,num_audits_failed:int,audit_only:bool=_C,execution_stats:t.Optional[QueryExecutionStats]=_A,auto_restatement_triggers:t.Optional[t.List[SnapshotId]]=_A)->_A:0
	def on_audits_completed(self,snapshot:Snapshot,audit_results:t.List[AuditResult],*,start:t.Optional[TimeLike]=_A,end:t.Optional[TimeLike]=_A,adapter_dialect:str='')->_A:0
	@abc.abstractmethod
	def stop_evaluation_progress(self,success:bool=_B)->_A:0
	@abc.abstractmethod
	def start_creation_progress(self,snapshots:t.List[Snapshot],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:0
	@abc.abstractmethod
	def update_creation_progress(self,snapshot:SnapshotInfoLike)->_A:0
	@abc.abstractmethod
	def stop_creation_progress(self,success:bool=_B)->_A:0
	@abc.abstractmethod
	def start_promotion_progress(self,snapshots:t.List[SnapshotTableInfo],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:0
	@abc.abstractmethod
	def update_promotion_progress(self,snapshot:SnapshotInfoLike,promoted:bool)->_A:0
	@abc.abstractmethod
	def stop_promotion_progress(self,success:bool=_B)->_A:0
	@abc.abstractmethod
	def start_snapshot_migration_progress(self,total_tasks:int)->_A:0
	@abc.abstractmethod
	def update_snapshot_migration_progress(self,num_tasks:int)->_A:0
	@abc.abstractmethod
	def log_migration_status(self,success:bool=_B)->_A:0
	@abc.abstractmethod
	def stop_snapshot_migration_progress(self,success:bool=_B)->_A:0
	@abc.abstractmethod
	def start_env_migration_progress(self,total_tasks:int)->_A:0
	@abc.abstractmethod
	def update_env_migration_progress(self,num_tasks:int)->_A:0
	@abc.abstractmethod
	def stop_env_migration_progress(self,success:bool=_B)->_A:0
	@abc.abstractmethod
	def plan(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str],no_diff:bool=_C,no_prompts:bool=_C)->_A:0
	@abc.abstractmethod
	def show_sql(self,sql:str)->_A:0
	@abc.abstractmethod
	def log_status_update(self,message:str)->_A:0
	@abc.abstractmethod
	def log_skipped_models(self,snapshot_names:t.Set[str])->_A:0
	@abc.abstractmethod
	def log_failed_models(self,errors:t.List[NodeExecutionFailedError])->_A:0
	@abc.abstractmethod
	def log_models_updated_during_restatement(self,snapshots:t.List[t.Tuple[SnapshotTableInfo,SnapshotTableInfo]],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:0
	@abc.abstractmethod
	def loading_start(self,message:t.Optional[str]=_A)->uuid.UUID:0
	@abc.abstractmethod
	def loading_stop(self,id:uuid.UUID)->_A:0
class NoopConsole(Console):
	def start_plan_evaluation(self,plan:EvaluatablePlan)->_A:0
	def stop_plan_evaluation(self)->_A:0
	def start_evaluation_progress(self,batched_intervals:t.Dict[Snapshot,Intervals],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],audit_only:bool=_C)->_A:0
	def start_snapshot_evaluation_progress(self,snapshot:Snapshot,audit_only:bool=_C)->_A:0
	def update_snapshot_evaluation_progress(self,snapshot:Snapshot,interval:Interval,batch_idx:int,duration_ms:t.Optional[int],num_audits_passed:int,num_audits_failed:int,audit_only:bool=_C,execution_stats:t.Optional[QueryExecutionStats]=_A,auto_restatement_triggers:t.Optional[t.List[SnapshotId]]=_A)->_A:0
	def stop_evaluation_progress(self,success:bool=_B)->_A:0
	def start_signal_progress(self,snapshot:Snapshot,default_catalog:t.Optional[str],environment_naming_info:EnvironmentNamingInfo)->_A:0
	def update_signal_progress(self,snapshot:Snapshot,signal_name:str,signal_idx:int,total_signals:int,ready_intervals:Intervals,check_intervals:Intervals,duration:float)->_A:0
	def stop_signal_progress(self)->_A:0
	def start_creation_progress(self,snapshots:t.List[Snapshot],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:0
	def update_creation_progress(self,snapshot:SnapshotInfoLike)->_A:0
	def stop_creation_progress(self,success:bool=_B)->_A:0
	def start_cleanup(self,ignore_ttl:bool)->bool:return _B
	def update_cleanup_progress(self,object_name:str)->_A:0
	def stop_cleanup(self,success:bool=_B)->_A:0
	def start_promotion_progress(self,snapshots:t.List[SnapshotTableInfo],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:0
	def update_promotion_progress(self,snapshot:SnapshotInfoLike,promoted:bool)->_A:0
	def stop_promotion_progress(self,success:bool=_B)->_A:0
	def start_snapshot_migration_progress(self,total_tasks:int)->_A:0
	def update_snapshot_migration_progress(self,num_tasks:int)->_A:0
	def log_migration_status(self,success:bool=_B)->_A:0
	def stop_snapshot_migration_progress(self,success:bool=_B)->_A:0
	def start_env_migration_progress(self,total_tasks:int)->_A:0
	def update_env_migration_progress(self,num_tasks:int)->_A:0
	def stop_env_migration_progress(self,success:bool=_B)->_A:0
	def start_state_export(self,output_file:Path,gateway:t.Optional[str]=_A,state_connection_config:t.Optional[ConnectionConfig]=_A,environment_names:t.Optional[t.List[str]]=_A,local_only:bool=_C,confirm:bool=_B)->bool:return confirm
	def update_state_export_progress(self,version_count:t.Optional[int]=_A,versions_complete:bool=_C,snapshot_count:t.Optional[int]=_A,snapshots_complete:bool=_C,environment_count:t.Optional[int]=_A,environments_complete:bool=_C)->_A:0
	def stop_state_export(self,success:bool,output_file:Path)->_A:0
	def start_state_import(self,input_file:Path,gateway:str,state_connection_config:ConnectionConfig,clear:bool=_C,confirm:bool=_B)->bool:return confirm
	def update_state_import_progress(self,timestamp:t.Optional[str]=_A,state_file_version:t.Optional[int]=_A,versions:t.Optional[Versions]=_A,snapshot_count:t.Optional[int]=_A,snapshots_complete:bool=_C,environment_count:t.Optional[int]=_A,environments_complete:bool=_C)->_A:0
	def stop_state_import(self,success:bool,input_file:Path)->_A:0
	def show_environment_difference_summary(self,context_diff:ContextDiff,no_diff:bool=_B)->_A:0
	def show_model_difference_summary(self,context_diff:ContextDiff,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],no_diff:bool=_B)->_A:0
	def plan(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str],no_diff:bool=_C,no_prompts:bool=_C)->_A:
		if auto_apply:plan_builder.apply()
	def log_test_results(self,result:ModelTextTestResult,target_dialect:str)->_A:0
	def show_sql(self,sql:str)->_A:0
	def log_status_update(self,message:str)->_A:0
	def log_skipped_models(self,snapshot_names:t.Set[str])->_A:0
	def log_failed_models(self,errors:t.List[NodeExecutionFailedError])->_A:0
	def log_models_updated_during_restatement(self,snapshots:t.List[t.Tuple[SnapshotTableInfo,SnapshotTableInfo]],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:0
	def log_destructive_change(self,snapshot_name:str,alter_operations:t.List[TableAlterOperation],dialect:str,error:bool=_B)->_A:0
	def log_additive_change(self,snapshot_name:str,alter_operations:t.List[TableAlterOperation],dialect:str,error:bool=_B)->_A:0
	def log_error(self,message:str)->_A:0
	def log_warning(self,short_message:str,long_message:t.Optional[str]=_A)->_A:logger.warning(rebrand(long_message or short_message))
	def log_success(self,message:str)->_A:0
	def loading_start(self,message:t.Optional[str]=_A)->uuid.UUID:return uuid.uuid4()
	def loading_stop(self,id:uuid.UUID)->_A:0
	def show_table_diff(self,table_diffs:t.List[TableDiff],show_sample:bool=_B,skip_grain_check:bool=_C,temp_schema:t.Optional[str]=_A)->_A:
		for table_diff in table_diffs:self.show_table_diff_summary(table_diff);self.show_schema_diff(table_diff.schema_diff());self.show_row_diff(table_diff.row_diff(temp_schema=temp_schema,skip_grain_check=skip_grain_check),show_sample=show_sample,skip_grain_check=skip_grain_check)
	def update_table_diff_progress(self,model:str)->_A:0
	def start_table_diff_progress(self,models_to_diff:int)->_A:0
	def start_table_diff_model_progress(self,model:str)->_A:0
	def stop_table_diff_progress(self,success:bool)->_A:0
	def show_table_diff_details(self,models_to_diff:t.List[str])->_A:0
	def show_table_diff_summary(self,table_diff:TableDiff)->_A:0
	def show_schema_diff(self,schema_diff:SchemaDiff)->_A:0
	def show_row_diff(self,row_diff:RowDiff,show_sample:bool=_B,skip_grain_check:bool=_C)->_A:0
	def print_environments(self,environments_summary:t.List[EnvironmentSummary])->_A:0
	def show_intervals(self,snapshot_intervals:t.Dict[Snapshot,SnapshotIntervals])->_A:0
	def show_linter_violations(self,violations:t.List[RuleViolation],source:LintSource,is_error:bool=_C)->_A:0
	def print_connection_config(self,config:ConnectionConfig,title:t.Optional[str]=_U)->_A:0
	def start_destroy(self,schemas_to_delete:t.Optional[t.Set[str]]=_A,views_to_delete:t.Optional[t.Set[str]]=_A,tables_to_delete:t.Optional[t.Set[str]]=_A)->bool:return _B
	def stop_destroy(self,success:bool=_B)->_A:0
def make_progress_bar(message:str,console:t.Optional[RichConsole]=_A,justify:t.Literal['default','left','center',_L,'full']=_L)->Progress:return Progress(TextColumn(f"[bold blue]{message}",justify=justify),BarColumn(bar_width=PROGRESS_BAR_WIDTH),'[progress.percentage]{task.percentage:>3.1f}%','•',srich.BatchColumn(),'•',TimeElapsedColumn(),console=console)
class TerminalConsole(Console):
	TABLE_DIFF_SOURCE_BLUE='#0248ff';TABLE_DIFF_TARGET_GREEN=_Q;AUDIT_PASS_MARK='✔';GREEN_AUDIT_PASS_MARK=f"[green]{AUDIT_PASS_MARK}[/green]";AUDIT_FAIL_MARK='❌';AUDIT_PADDING=0;CHECK_MARK=f"{AUDIT_PASS_MARK} "
	def __init__(self,console:t.Optional[RichConsole]=_A,verbosity:Verbosity=Verbosity.DEFAULT,dialect:DialectType=_A,ignore_warnings:bool=_C,**kwargs:t.Any)->_A:super().__init__(**kwargs);(self.console):RichConsole=console or srich.console;(self.evaluation_progress_live):t.Optional[Live]=_A;(self.evaluation_total_progress):t.Optional[Progress]=_A;(self.evaluation_total_task):t.Optional[TaskID]=_A;(self.evaluation_model_progress):t.Optional[Progress]=_A;(self.evaluation_model_tasks):t.Dict[str,TaskID]={};(self.evaluation_model_batch_sizes):t.Dict[Snapshot,int]={};(self.evaluation_column_widths):t.Dict[str,int]={};self.environment_naming_info=EnvironmentNamingInfo();(self.default_catalog):t.Optional[str]=_A;(self.creation_progress):t.Optional[Progress]=_A;(self.creation_column_widths):t.Dict[str,int]={};(self.creation_task):t.Optional[TaskID]=_A;(self.promotion_progress):t.Optional[Progress]=_A;(self.promotion_column_widths):t.Dict[str,int]={};(self.promotion_task):t.Optional[TaskID]=_A;(self.migration_progress):t.Optional[Progress]=_A;(self.migration_task):t.Optional[TaskID]=_A;(self.env_migration_progress):t.Optional[Progress]=_A;(self.env_migration_task):t.Optional[TaskID]=_A;(self.loading_status):t.Dict[uuid.UUID,Status]={};(self.state_export_progress):t.Optional[Progress]=_A;(self.state_export_version_task):t.Optional[TaskID]=_A;(self.state_export_snapshot_task):t.Optional[TaskID]=_A;(self.state_export_environment_task):t.Optional[TaskID]=_A;(self.state_import_progress):t.Optional[Progress]=_A;(self.state_import_version_task):t.Optional[TaskID]=_A;(self.state_import_snapshot_task):t.Optional[TaskID]=_A;(self.state_import_environment_task):t.Optional[TaskID]=_A;(self.table_diff_progress):t.Optional[Progress]=_A;(self.table_diff_model_progress):t.Optional[Progress]=_A;(self.table_diff_model_tasks):t.Dict[str,TaskID]={};(self.table_diff_progress_live):t.Optional[Live]=_A;self.signal_progress_logged=_C;(self.signal_status_tree):t.Optional[Tree]=_A;self.verbosity=verbosity;self.dialect=dialect;self.ignore_warnings=ignore_warnings
	def _limit_model_names(self,tree:Tree,verbosity:Verbosity=Verbosity.DEFAULT)->Tree:
		modified_length=len(tree.children)
		if verbosity<Verbosity.VERY_VERBOSE and modified_length>self.INDIRECTLY_MODIFIED_DISPLAY_THRESHOLD:tree.children=[tree.children[0],Tree(f".... {modified_length-2} more ...."),tree.children[-1]]
		return tree
	def _print(self,value:t.Any,**kwargs:t.Any)->_A:self.console.print(rebrand(value),**kwargs)
	def _prompt(self,message:str,**kwargs:t.Any)->t.Any:return Prompt.ask(rebrand(message),console=self.console,**kwargs)
	def _confirm(self,message:str,**kwargs:t.Any)->bool:return Confirm.ask(rebrand(message),console=self.console,**kwargs)
	def start_plan_evaluation(self,plan:EvaluatablePlan)->_A:0
	def stop_plan_evaluation(self)->_A:0
	def start_evaluation_progress(self,batched_intervals:t.Dict[Snapshot,Intervals],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],audit_only:bool=_C)->_A:
		if self.signal_progress_logged:self._print('')
		if not self.evaluation_progress_live:self.evaluation_total_progress=make_progress_bar('Executing model batches'if not audit_only else'Auditing models',self.console);self.evaluation_model_progress=Progress(TextColumn(_V,justify=_L),SpinnerColumn(spinner_name=_W),console=self.console);progress_table=Table.grid();progress_table.add_row(self.evaluation_total_progress);progress_table.add_row(self.evaluation_model_progress);self.evaluation_progress_live=Live(progress_table,console=self.console,refresh_per_second=10);self.evaluation_progress_live.start();batch_sizes={snapshot:len(intervals)for(snapshot,intervals)in batched_intervals.items()};message='Executing'if not audit_only else _R;self.evaluation_total_task=self.evaluation_total_progress.add_task(f"{message} models...",total=sum(batch_sizes.values()));self.evaluation_column_widths[_X]=_calculate_annotation_str_len(batched_intervals,self.AUDIT_PADDING,len(' (123.4m rows, 123.4 KiB)'))+3;self.evaluation_column_widths[_F]=max(len(snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect))for snapshot in batched_intervals);largest_batch_size=max(batch_sizes.values());self.evaluation_column_widths['batch']=len(str(largest_batch_size))*2+3;self.evaluation_column_widths[_Y]=8;self.evaluation_model_batch_sizes=batch_sizes;self.environment_naming_info=environment_naming_info;self.default_catalog=default_catalog
	def start_snapshot_evaluation_progress(self,snapshot:Snapshot,audit_only:bool=_C)->_A:
		if self.evaluation_model_progress and snapshot.name not in self.evaluation_model_tasks:display_name=snapshot.display_name(self.environment_naming_info,self.default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect);self.evaluation_model_tasks[snapshot.name]=self.evaluation_model_progress.add_task(f"{_Z if not audit_only else _R} {display_name}...",view_name=display_name,total=self.evaluation_model_batch_sizes[snapshot])
	def update_snapshot_evaluation_progress(self,snapshot:Snapshot,interval:Interval,batch_idx:int,duration_ms:t.Optional[int],num_audits_passed:int,num_audits_failed:int,audit_only:bool=_C,execution_stats:t.Optional[QueryExecutionStats]=_A,auto_restatement_triggers:t.Optional[t.List[SnapshotId]]=_A)->_A:
		if self.evaluation_total_progress and self.evaluation_model_progress and self.evaluation_progress_live:
			total_batches=self.evaluation_model_batch_sizes[snapshot];batch_num=str(batch_idx+1).rjust(len(str(total_batches)));batch=f"[{batch_num}/{total_batches}]".ljust(self.evaluation_column_widths['batch'])
			if duration_ms:
				display_name=snapshot.display_name(self.environment_naming_info,self.default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect).ljust(self.evaluation_column_widths[_F]);annotation=_create_evaluation_model_annotation(snapshot,_format_evaluation_model_interval(snapshot,interval),execution_stats);audits_str=''
				if num_audits_passed:audits_str+=f" {self.AUDIT_PASS_MARK}{num_audits_passed}"
				if num_audits_failed:audits_str+=f" {self.AUDIT_FAIL_MARK}{num_audits_failed}"
				audits_str=f", audits{audits_str}"if audits_str else'';annotation_len=self.evaluation_column_widths[_X];annotation=f"\\[{annotation+audits_str}]".ljust(annotation_len-1 if num_audits_failed and self.AUDIT_PADDING==0 else annotation_len);duration=f"{duration_ms/1e3:.2f}s".ljust(self.evaluation_column_widths[_Y]);msg=f"{f'{batch} 'if not audit_only else''}{display_name}   {annotation}   {duration}".replace(self.AUDIT_PASS_MARK,self.GREEN_AUDIT_PASS_MARK);self.evaluation_progress_live.console.print(msg)
			self.evaluation_total_progress.update(self.evaluation_total_task or TaskID(0),refresh=_B,advance=1);model_task_id=self.evaluation_model_tasks[snapshot.name];self.evaluation_model_progress.update(model_task_id,refresh=_B,advance=1)
			if self.evaluation_model_progress._tasks[model_task_id].completed>=total_batches or audit_only:self.evaluation_model_progress.remove_task(model_task_id)
	def stop_evaluation_progress(self,success:bool=_B)->_A:
		if self.evaluation_progress_live:
			self.evaluation_progress_live.stop()
			if success:self.log_success(f"{self.CHECK_MARK}Model batches executed")
		self.evaluation_progress_live=_A;self.evaluation_total_progress=_A;self.evaluation_total_task=_A;self.evaluation_model_progress=_A;self.evaluation_model_tasks={};self.evaluation_model_batch_sizes={};self.evaluation_column_widths={};self.environment_naming_info=EnvironmentNamingInfo();self.default_catalog=_A
	def start_signal_progress(self,snapshot:Snapshot,default_catalog:t.Optional[str],environment_naming_info:EnvironmentNamingInfo)->_A:display_name=snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect);self.signal_status_tree=Tree(f"Checking signals for {display_name}")
	def update_signal_progress(self,snapshot:Snapshot,signal_name:str,signal_idx:int,total_signals:int,ready_intervals:Intervals,check_intervals:Intervals,duration:float)->_A:
		A='no intervals';tree=Tree(f"[{signal_idx+1}/{total_signals}] {signal_name} {duration:.2f}s");formatted_check_intervals=[_format_signal_interval(snapshot,i)for i in check_intervals];formatted_ready_intervals=[_format_signal_interval(snapshot,i)for i in ready_intervals]
		if not formatted_check_intervals:formatted_check_intervals=[A]
		if not formatted_ready_intervals:formatted_ready_intervals=[A]
		if ready_intervals==check_intervals:msg='All ready';color=_Q
		elif ready_intervals:msg='Some ready';color='yellow'
		else:msg='None ready';color='red'
		if self.verbosity<Verbosity.VERY_VERBOSE:
			num_check_intervals=len(formatted_check_intervals)
			if num_check_intervals>3:formatted_check_intervals=formatted_check_intervals[:3];formatted_check_intervals.append(f"... and {num_check_intervals-3} more")
			num_ready_intervals=len(formatted_ready_intervals)
			if num_ready_intervals>3:formatted_ready_intervals=formatted_ready_intervals[:3];formatted_ready_intervals.append(f"... and {num_ready_intervals-3} more")
			check=_G.join(formatted_check_intervals);tree.add(f"Check: {check}");ready=_G.join(formatted_ready_intervals);tree.add(f"[{color}]{msg}: {ready}[/{color}]")
		else:
			check_tree=Tree('Check');tree.add(check_tree)
			for interval in formatted_check_intervals:check_tree.add(interval)
			ready_tree=Tree(f"[{color}]{msg}[/{color}]");tree.add(ready_tree)
			for interval in formatted_ready_intervals:ready_tree.add(f"[{color}]{interval}[/{color}]")
		if self.signal_status_tree is not _A:self.signal_status_tree.add(tree)
	def stop_signal_progress(self)->_A:
		if self.signal_status_tree is not _A:self._print(self.signal_status_tree);self.signal_status_tree=_A;self.signal_progress_logged=_B
	def start_creation_progress(self,snapshots:t.List[Snapshot],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:
		if self.creation_progress is _A:
			self.creation_progress=make_progress_bar('Updating physical layer',self.console);self._print('');self.creation_progress.start();self.creation_task=self.creation_progress.add_task('Updating physical layer...',total=len(snapshots))
			if self.verbosity>=Verbosity.VERBOSE:self.creation_column_widths[_F]=max(len(snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect))for snapshot in snapshots)
			self.environment_naming_info=environment_naming_info;self.default_catalog=default_catalog
	def update_creation_progress(self,snapshot:SnapshotInfoLike)->_A:
		if self.creation_progress is not _A and self.creation_task is not _A:
			if self.verbosity>=Verbosity.VERBOSE:msg=snapshot.display_name(self.environment_naming_info,self.default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect).ljust(self.creation_column_widths[_F]);self.creation_progress.live.console.print(msg+'  [green]created[/green]')
			self.creation_progress.update(self.creation_task,refresh=_B,advance=1)
	def stop_creation_progress(self,success:bool=_B)->_A:
		self.creation_task=_A
		if self.creation_progress is not _A:
			self.creation_progress.stop();self.creation_progress=_A
			if success:self.log_success(f"\n{self.CHECK_MARK}Physical layer updated")
		self.environment_naming_info=EnvironmentNamingInfo();self.default_catalog=_A;self.creation_column_widths={}
	def start_cleanup(self,ignore_ttl:bool)->bool:
		if ignore_ttl:
			self._print('Are you sure you want to delete all snapshots that are not referenced in any environment?');self._print('Note that this may cause a race condition if there are any concurrently running plans.');self._print('It may also confuse users who were expecting to be able to rollback changes in their development environments.')
			if not self._confirm('Proceed?'):self.log_error('Cleanup aborted');return _C
		return _B
	def update_cleanup_progress(self,object_name:str)->_A:self._print(f"Deleted object {object_name}")
	def stop_cleanup(self,success:bool=_C)->_A:
		if success:self.log_success('Cleanup complete.')
		else:self.log_error('Cleanup failed!')
	def start_destroy(self,schemas_to_delete:t.Optional[t.Set[str]]=_A,views_to_delete:t.Optional[t.Set[str]]=_A,tables_to_delete:t.Optional[t.Set[str]]=_A)->bool:
		self.log_warning('This will permanently delete all engine-managed objects, state tables and Vulcan cache.\nThe operation may disrupt any currently running or scheduled plans.\n')
		if schemas_to_delete or views_to_delete or tables_to_delete:
			if schemas_to_delete:
				self.log_error('Schemas to be deleted:')
				for schema in sorted(schemas_to_delete):self.log_error(f"  • {schema}")
			if views_to_delete:
				self.log_error('\nEnvironment views to be deleted:')
				for view in sorted(views_to_delete):self.log_error(f"  • {view}")
			if tables_to_delete:
				self.log_error('\nSnapshot tables to be deleted:')
				for table in sorted(tables_to_delete):self.log_error(f"  • {table}")
			self.log_error('\nThis action will DELETE ALL the above resources managed by Vulcan AND\npotentially external resources created by other tools in these schemas.\n')
		if not self._confirm('Are you ABSOLUTELY SURE you want to proceed with deletion?'):self.log_error('Destroy operation cancelled.');return _C
		return _B
	def stop_destroy(self,success:bool=_C)->_A:
		if success:self.log_success('Destroy completed successfully.')
		else:self.log_error('Destroy failed!')
	def start_promotion_progress(self,snapshots:t.List[SnapshotTableInfo],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:
		if snapshots and self.promotion_progress is _A:
			self.promotion_progress=make_progress_bar('Updating virtual layer ',self.console,justify='left');snapshots_with_virtual_views=[s for s in snapshots if s.is_model and not s.is_symbolic];self.promotion_progress.start();self.promotion_task=self.promotion_progress.add_task(f"Virtually updating {environment_naming_info.name}...",total=len(snapshots_with_virtual_views))
			if self.verbosity>=Verbosity.VERBOSE:self.promotion_column_widths[_F]=max(len(snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect))for snapshot in snapshots_with_virtual_views)
			self.environment_naming_info=environment_naming_info;self.default_catalog=default_catalog
	def update_promotion_progress(self,snapshot:SnapshotInfoLike,promoted:bool)->_A:
		if self.promotion_progress is not _A and self.promotion_task is not _A and snapshot.is_model and not snapshot.is_symbolic:
			if self.verbosity>=Verbosity.VERBOSE:
				display_name=snapshot.display_name(self.environment_naming_info,self.default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect).ljust(self.promotion_column_widths[_F]);action_str=''
				if promoted:action_str='[yellow]updated[/yellow]'if snapshot.previous_version else'[green]created[/green]'
				action_str=action_str or'[red]dropped[/red]';self.promotion_progress.live.console.print(f"{display_name}  {action_str}")
			self.promotion_progress.update(self.promotion_task,refresh=_B,advance=1)
	def stop_promotion_progress(self,success:bool=_B)->_A:
		self.promotion_task=_A
		if self.promotion_progress is not _A:
			self.promotion_progress.stop();self.promotion_progress=_A
			if success:self.log_success(f"\n{self.CHECK_MARK}Virtual layer updated")
		self.environment_naming_info=EnvironmentNamingInfo();self.default_catalog=_A;self.promotion_column_widths={}
	def start_snapshot_migration_progress(self,total_tasks:int)->_A:
		if self.migration_progress is _A:self.migration_progress=make_progress_bar('Migrating snapshots',self.console);self.migration_progress.start();self.migration_task=self.migration_progress.add_task('Migrating snapshots...',total=total_tasks)
	def update_snapshot_migration_progress(self,num_tasks:int)->_A:
		if self.migration_progress is not _A and self.migration_task is not _A:self.migration_progress.update(self.migration_task,refresh=_B,advance=num_tasks)
	def log_migration_status(self,success:bool=_B)->_A:
		if self.migration_progress is not _A:
			self.migration_progress=_A
			if success:self.log_success('Migration completed successfully')
	def stop_snapshot_migration_progress(self,success:bool=_B)->_A:
		self.migration_task=_A
		if self.migration_progress is not _A:
			self.migration_progress.stop()
			if success:self.log_success('Snapshots migrated successfully')
	def start_env_migration_progress(self,total_tasks:int)->_A:
		if self.env_migration_progress is _A:self.env_migration_progress=make_progress_bar('Migrating environments',self.console);self.env_migration_progress.start();self.env_migration_task=self.env_migration_progress.add_task('Migrating environments...',total=total_tasks)
	def update_env_migration_progress(self,num_tasks:int)->_A:
		if self.env_migration_progress is not _A and self.env_migration_task is not _A:self.env_migration_progress.update(self.env_migration_task,refresh=_B,advance=num_tasks)
	def stop_env_migration_progress(self,success:bool=_B)->_A:
		self.env_migration_task=_A
		if self.env_migration_progress is not _A:
			self.env_migration_progress.stop();self.env_migration_progress=_A
			if success:self.log_success('Environments migrated successfully')
	def start_state_export(self,output_file:Path,gateway:t.Optional[str]=_A,state_connection_config:t.Optional[ConnectionConfig]=_A,environment_names:t.Optional[t.List[str]]=_A,local_only:bool=_C,confirm:bool=_B)->bool:
		self.state_export_progress=_A
		if local_only:self.log_status_update(f"Exporting [b]local[/b] state to '{output_file.as_posix()}'\n");self.log_warning('Local state exports just contain the model versions in your local context. Therefore, the resulting file cannot be imported.')
		else:
			self.log_status_update(f"Exporting state to '{output_file.as_posix()}' from the following connection:\n")
			if gateway:self.log_status_update(f"[b]Gateway[/b]: [green]{gateway}[/green]")
			if state_connection_config:self.print_connection_config(state_connection_config,title=_a)
			if environment_names:heading='Environments'if len(environment_names)>1 else'Environment';self.log_status_update(f"[b]{heading}[/b]: [yellow]{_G.join(environment_names)}[/yellow]")
		should_continue=_B
		if confirm:should_continue=self._confirm('\nContinue?');self.log_status_update('')
		if should_continue:self.state_export_progress=make_progress_bar(_b,self.console);assert isinstance(self.state_export_progress,Progress);self.state_export_version_task=self.state_export_progress.add_task('Exporting versions',start=_C);self.state_export_snapshot_task=self.state_export_progress.add_task('Exporting snapshots',start=_C);self.state_export_environment_task=self.state_export_progress.add_task('Exporting environments',start=_C);self.state_export_progress.start()
		return should_continue
	def update_state_export_progress(self,version_count:t.Optional[int]=_A,versions_complete:bool=_C,snapshot_count:t.Optional[int]=_A,snapshots_complete:bool=_C,environment_count:t.Optional[int]=_A,environments_complete:bool=_C)->_A:
		if self.state_export_progress:
			if self.state_export_version_task is not _A:
				if version_count is not _A:self.state_export_progress.start_task(self.state_export_version_task);self.state_export_progress.update(self.state_export_version_task,total=version_count,completed=version_count,refresh=_B)
				if versions_complete:self.state_export_progress.stop_task(self.state_export_version_task)
			if self.state_export_snapshot_task is not _A:
				if snapshot_count is not _A:self.state_export_progress.start_task(self.state_export_snapshot_task);self.state_export_progress.update(self.state_export_snapshot_task,total=snapshot_count,completed=snapshot_count,refresh=_B)
				if snapshots_complete:self.state_export_progress.stop_task(self.state_export_snapshot_task)
			if self.state_export_environment_task is not _A:
				if environment_count is not _A:self.state_export_progress.start_task(self.state_export_environment_task);self.state_export_progress.update(self.state_export_environment_task,total=environment_count,completed=environment_count,refresh=_B)
				if environments_complete:self.state_export_progress.stop_task(self.state_export_environment_task)
	def stop_state_export(self,success:bool,output_file:Path)->_A:
		if self.state_export_progress:
			self.state_export_progress.stop();self.state_export_progress=_A;self.log_status_update('')
			if success:self.log_success(f"State exported successfully to '{output_file.as_posix()}'")
			else:self.log_error('State export failed!')
	def start_state_import(self,input_file:Path,gateway:str,state_connection_config:ConnectionConfig,clear:bool=_C,confirm:bool=_B)->bool:
		self.log_status_update(f"Loading state from '{input_file.as_posix()}' into the following connection:\n");self.log_status_update(f"[b]Gateway[/b]: [green]{gateway}[/green]");self.print_connection_config(state_connection_config,title=_a);self.log_status_update('')
		if clear:self.log_warning(f"This [b]destructive[/b] operation will delete all existing state against the '{gateway}' gateway \nand replace it with what's in the '{input_file.as_posix()}' file.\n")
		else:self.log_warning(f"This operation will [b]merge[/b] the contents of the state file to the state located at the '{gateway}' gateway.\nMatching snapshots or environments will be replaced.\nNon-matching snapshots or environments will be ignored.\n")
		should_continue=_B
		if confirm:should_continue=self._confirm('[red]Are you sure?[/red]');self.log_status_update('')
		if should_continue:self.state_import_progress=make_progress_bar(_b,self.console);self.state_import_info=Tree('[bold]State File Information:');self.state_import_version_task=self.state_import_progress.add_task('Importing versions',start=_C);self.state_import_snapshot_task=self.state_import_progress.add_task('Importing snapshots',start=_C);self.state_import_environment_task=self.state_import_progress.add_task('Importing environments',start=_C);self.state_import_progress.start()
		return should_continue
	def update_state_import_progress(self,timestamp:t.Optional[str]=_A,state_file_version:t.Optional[int]=_A,versions:t.Optional[Versions]=_A,snapshot_count:t.Optional[int]=_A,snapshots_complete:bool=_C,environment_count:t.Optional[int]=_A,environments_complete:bool=_C)->_A:
		if self.state_import_progress:
			if self.state_import_info:
				if timestamp:self.state_import_info.add(f"Creation Timestamp: {timestamp}")
				if state_file_version:self.state_import_info.add(f"File Version: {state_file_version}")
				if versions:
					self.state_import_info.add(f"Vulcan version: {versions.vulcan_version}");self.state_import_info.add(f"Vulcan migration version: {versions.schema_version}");self.state_import_info.add(f"SQLGlot version: {versions.sqlglot_version}\n");self._print(self.state_import_info);version_count=len(versions.model_dump())
					if self.state_import_version_task is not _A:self.state_import_progress.start_task(self.state_import_version_task);self.state_import_progress.update(self.state_import_version_task,total=version_count,completed=version_count);self.state_import_progress.stop_task(self.state_import_version_task)
			if self.state_import_snapshot_task is not _A:
				if snapshot_count is not _A:self.state_import_progress.start_task(self.state_import_snapshot_task);self.state_import_progress.update(self.state_import_snapshot_task,completed=snapshot_count,total=snapshot_count,refresh=_B)
				if snapshots_complete:self.state_import_progress.stop_task(self.state_import_snapshot_task)
			if self.state_import_environment_task is not _A:
				if environment_count is not _A:self.state_import_progress.start_task(self.state_import_environment_task);self.state_import_progress.update(self.state_import_environment_task,completed=environment_count,total=environment_count,refresh=_B)
				if environments_complete:self.state_import_progress.stop_task(self.state_import_environment_task)
	def stop_state_import(self,success:bool,input_file:Path)->_A:
		if self.state_import_progress:
			self.state_import_progress.stop();self.state_import_progress=_A;self.log_status_update('')
			if success:self.log_success(f"State imported successfully from '{input_file.as_posix()}'")
			else:self.log_error('State import failed!')
	def show_environment_difference_summary(self,context_diff:ContextDiff,no_diff:bool=_B)->_A:
		if context_diff.is_new_environment:
			msg=f"\n`{context_diff.environment}` environment will be initialized"if not context_diff.create_from_env_exists else f"\nNew environment `{context_diff.environment}` will be created from `{context_diff.create_from}`";self._print(Tree(f"[bold]{msg}\n"))
			if not context_diff.has_snapshot_changes:return
		if not context_diff.has_changes:self._print(Tree(f"\n[bold]No changes to plan: project files match the `{context_diff.environment}` environment\n"));return
		if not context_diff.is_new_environment or context_diff.is_new_environment and context_diff.create_from_env_exists:self._print(Tree(f"\n[bold]Differences from the `{context_diff.create_from if context_diff.is_new_environment else context_diff.environment}` environment:\n"))
		if context_diff.has_requirement_changes:self._print(f"[bold]Requirements:\n{context_diff.requirements_diff()}")
		if context_diff.has_environment_statements_changes and not no_diff:
			self._print('[bold]Environment statements:\n')
			for(type,diff)in context_diff.environment_statements_diff(include_python_env=not context_diff.is_new_environment):self._print(Syntax(diff,type,line_numbers=_C))
	def show_model_difference_summary(self,context_diff:ContextDiff,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],no_diff:bool=_B)->_A:
		self._show_summary_tree_for(context_diff,'Models',lambda x:x.is_model,environment_naming_info,default_catalog,no_diff=no_diff);self._show_summary_tree_for(context_diff,'Standalone Audits',lambda x:x.is_audit,environment_naming_info,default_catalog,no_diff=no_diff)
		for(title,predicate)in[('Semantics',lambda x:x.is_semantic_model),('Metrics',lambda x:x.is_semantic_metric)]:self._show_summary_tree_for(context_diff,title,predicate,environment_naming_info,default_catalog,no_diff=no_diff)
	def plan(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str],no_diff:bool=_C,no_prompts:bool=_C)->_A:
		self._prompt_categorize(plan_builder,auto_apply,no_diff=no_diff,no_prompts=no_prompts,default_catalog=default_catalog);self._show_options_after_categorization(plan_builder,auto_apply,default_catalog=default_catalog,no_prompts=no_prompts)
		if auto_apply:plan_builder.apply()
	def _show_summary_tree_for(self,context_diff:ContextDiff,header:str,snapshot_selector:t.Callable[[SnapshotInfoLike],bool],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],no_diff:bool=_B)->_A:
		added_snapshot_ids={s_id for s_id in context_diff.added if snapshot_selector(context_diff.snapshots[s_id])};removed_snapshot_ids={s_id for(s_id,snapshot)in context_diff.removed_snapshots.items()if snapshot_selector(snapshot)};modified_snapshot_ids={current_snapshot.snapshot_id for(_,(current_snapshot,_))in context_diff.modified_snapshots.items()if snapshot_selector(current_snapshot)};tree_sets=added_snapshot_ids,removed_snapshot_ids,modified_snapshot_ids
		if all(not s_ids for s_ids in tree_sets):return
		tree=Tree(f"[bold]{header}:")
		if added_snapshot_ids:
			added_tree=Tree('[bold][added]Added:')
			for s_id in sorted(added_snapshot_ids):snapshot=context_diff.snapshots[s_id];added_tree.add(f"[added]{snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}")
			tree.add(self._limit_model_names(added_tree,self.verbosity))
		if removed_snapshot_ids:
			removed_tree=Tree('[bold][removed]Removed:')
			for s_id in sorted(removed_snapshot_ids):snapshot_table_info=context_diff.removed_snapshots[s_id];removed_tree.add(f"[removed]{snapshot_table_info.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}")
			tree.add(self._limit_model_names(removed_tree,self.verbosity))
		if modified_snapshot_ids:tree=self._add_modified_models(context_diff,modified_snapshot_ids,tree,environment_naming_info,default_catalog,no_diff)
		self._print(tree)
	def _add_modified_models(self,context_diff:ContextDiff,modified_snapshot_ids:t.Set[SnapshotId],tree:Tree,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str]=_A,no_diff:bool=_B)->Tree:
		direct=Tree('[bold][direct]Directly Modified:');indirect=Tree('[bold][indirect]Indirectly Modified:');metadata=Tree('[bold][metadata]Metadata Updated:')
		for s_id in modified_snapshot_ids:
			name=s_id.name;display_name=context_diff.snapshots[s_id].display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)
			if context_diff.directly_modified(name):direct.add(f"[direct]{display_name}"if no_diff else Syntax(f"{display_name}\n{context_diff.text_diff(name)}",_M))
			elif context_diff.indirectly_modified(name):indirect.add(f"[indirect]{display_name}")
			elif context_diff.metadata_updated(name):metadata.add(f"[metadata]{display_name}"if no_diff else Syntax(f"{display_name}\n{context_diff.text_diff(name)}",_M))
		if direct.children:tree.add(direct)
		if indirect.children:tree.add(self._limit_model_names(indirect,self.verbosity))
		if metadata.children:tree.add(metadata)
		return tree
	def _show_options_after_categorization(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str],no_prompts:bool)->_A:
		plan=plan_builder.build()
		if not no_prompts and plan.forward_only and plan.new_snapshots:self._prompt_effective_from(plan_builder,auto_apply,default_catalog)
		if plan.requires_backfill:
			self._show_missing_dates(plan_builder.build(),default_catalog)
			if not no_prompts:self._prompt_backfill(plan_builder,auto_apply,default_catalog)
			backfill_or_preview=_c if plan.is_dev and plan.forward_only else _d
			if not auto_apply and self._confirm(f"Apply - {backfill_or_preview.capitalize()} Tables"):plan_builder.apply()
		elif plan.has_changes and not auto_apply:self._prompt_promote(plan_builder)
		elif plan.has_unmodified_unpromoted and not auto_apply:self.log_status_update('\n[bold]Virtually updating unmodified models\n');self._prompt_promote(plan_builder)
	def _prompt_categorize(self,plan_builder:PlanBuilder,auto_apply:bool,no_diff:bool,no_prompts:bool,default_catalog:t.Optional[str])->_A:
		plan=plan_builder.build()
		if plan.restatements:
			if plan.selected_models_to_restate:
				tree=Tree('[bold]Models selected for restatement:[/bold]\nThis causes backfill of the model itself as well as affected downstream models');model_fqn_to_snapshot={s.name:s for s in plan.snapshots.values()}
				for model_fqn in plan.selected_models_to_restate:snapshot=model_fqn_to_snapshot[model_fqn];display_name=snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect);tree.add(display_name)
				self._print(tree)
			else:0
		else:self.show_environment_difference_summary(plan.context_diff,no_diff=no_diff)
		if plan.context_diff.has_changes:self.show_model_difference_summary(plan.context_diff,plan.environment_naming_info,default_catalog=default_catalog)
		if not no_diff:self._show_categorized_snapshots(plan,default_catalog)
		for snapshot in plan.uncategorized:
			if snapshot.is_model and snapshot.model.forward_only:continue
			if not no_diff:self.show_sql(plan.context_diff.text_diff(snapshot.name))
			tree=Tree(f"[bold][direct]Directly Modified: {snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}");indirect_tree=_A
			for child_sid in sorted(plan.indirectly_modified.get(snapshot.snapshot_id,set())):
				child_snapshot=plan.context_diff.snapshots[child_sid]
				if not indirect_tree:indirect_tree=Tree(_S);tree.add(indirect_tree)
				indirect_tree.add(f"[indirect]{child_snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}")
			if indirect_tree:indirect_tree=self._limit_model_names(indirect_tree,self.verbosity)
			self._print(tree)
			if not no_prompts:self._get_snapshot_change_category(snapshot,plan_builder,auto_apply,default_catalog)
	def _show_categorized_snapshots(self,plan:Plan,default_catalog:t.Optional[str])->_A:
		context_diff=plan.context_diff
		for snapshot in plan.categorized:
			if context_diff.directly_modified(snapshot.name):
				category_str=SNAPSHOT_CHANGE_CATEGORY_STR[snapshot.change_category];tree=Tree(f"\n[bold][direct]Directly Modified: {snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)} ({category_str})");indirect_tree=_A
				for child_sid in sorted(plan.indirectly_modified.get(snapshot.snapshot_id,set())):
					child_snapshot=context_diff.snapshots[child_sid]
					if not indirect_tree:indirect_tree=Tree(_S);tree.add(indirect_tree)
					child_category_str=SNAPSHOT_CHANGE_CATEGORY_STR[child_snapshot.change_category];indirect_tree.add(f"[indirect]{child_snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)} ({child_category_str})")
				if indirect_tree:indirect_tree=self._limit_model_names(indirect_tree,self.verbosity)
			elif context_diff.metadata_updated(snapshot.name):tree=Tree(f"\n[bold][metadata]Metadata Updated: {snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}")
			else:continue
			text_diff=context_diff.text_diff(snapshot.name)
			if text_diff:self._print('');self._print(Syntax(text_diff,_M,word_wrap=_B))
			self._print(tree)
	def _show_missing_dates(self,plan:Plan,default_catalog:t.Optional[str])->_A:
		missing_intervals=plan.missing_intervals
		if not missing_intervals:return
		backfill=Tree('[bold]Models needing backfill:[/bold]')
		for missing in missing_intervals:
			snapshot=plan.context_diff.snapshots[missing.snapshot_id]
			if not snapshot.is_model:continue
			preview_modifier=''
			if not plan.deployability_index.is_deployable(snapshot):preview_modifier=' ([orange1]preview[/orange1])'
			display_name=snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect);backfill.add(f"{display_name}: \\[{_format_missing_intervals(snapshot,missing)}]{preview_modifier}")
		if backfill:backfill=self._limit_model_names(backfill,self.verbosity)
		self._print(backfill)
	def _prompt_effective_from(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str])->_A:
		if not plan_builder.build().effective_from:
			effective_from=self._prompt("Enter the effective date (eg. '1 year', '2020-01-01') to apply forward-only changes retroactively or blank to only apply them going forward once changes are deployed to prod")
			if effective_from:plan_builder.set_effective_from(effective_from)
	def _prompt_backfill(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str])->_A:
		plan=plan_builder.build();is_forward_only_dev=plan.is_dev and plan.forward_only;backfill_or_preview=_c if is_forward_only_dev else _d
		if plan_builder.is_start_and_end_allowed:
			if not plan_builder.override_start:
				if is_forward_only_dev:
					if plan.effective_from:blank_meaning=f"to preview starting from the effective date ('{time_like_to_str(plan.effective_from)}')";default_start=plan.effective_from
					else:blank_meaning='to preview starting from yesterday';default_start=yesterday_ds()
				else:
					if plan.provided_start:blank_meaning=f"starting from '{time_like_to_str(plan.provided_start)}'"
					else:blank_meaning='from the beginning of history'
					default_start=_A
				start=self._prompt(f"Enter the {backfill_or_preview} start date (eg. '1 year', '2020-01-01') or blank to backfill {blank_meaning}")
				if start:plan_builder.set_start(start)
				elif default_start:plan_builder.set_start(default_start)
			if not plan_builder.override_end:
				if plan.provided_end:blank_meaning=f"'{time_like_to_str(plan.provided_end)}'"
				elif plan.end_override_per_model:max_end=max(plan.end_override_per_model.values());blank_meaning=f"'{time_like_to_str(max_end)}'"
				else:blank_meaning='now'
				end=self._prompt(f"Enter the {backfill_or_preview} end date (eg. '1 month ago', '2020-01-01') or blank to {backfill_or_preview} up until {blank_meaning}")
				if end:plan_builder.set_end(end)
			plan=plan_builder.build()
	def _prompt_promote(self,plan_builder:PlanBuilder)->_A:
		if self._confirm(_e):plan_builder.apply()
	def log_test_results(self,result:ModelTextTestResult,target_dialect:str)->_A:
		if not result.testsRun:return
		divider_length=70;self._log_test_details(result);message=f"Ran {result.testsRun} tests against {target_dialect} in {result.duration} seconds."
		if result.wasSuccessful():self._print('='*divider_length);self._print(f"Successfully {message}",style=_Q);self._print('-'*divider_length)
		else:
			self._print('-'*divider_length);self._print(_f,style='red');self._print('='*divider_length);fail_and_error_tests=result.get_fail_and_error_tests();self._print(f"{message} \n");self._print(f"Failed tests ({len(fail_and_error_tests)}):")
			for test in fail_and_error_tests:self._print(f" • {test.path}::{test.test_name}")
			self._print('='*divider_length,end=_K)
	def _captured_unit_test_results(self,result:ModelTextTestResult)->str:
		with self.console.capture()as capture:self._log_test_details(result)
		return strip_ansi_codes(capture.get())
	def show_sql(self,sql:str)->_A:self._print(Syntax(sql,_M,word_wrap=_B),crop=_C)
	def log_status_update(self,message:str)->_A:self._print(message)
	def log_skipped_models(self,snapshot_names:t.Set[str])->_A:
		if snapshot_names:msg=_N+_H.join(snapshot_names);self._print(f"[dark_orange3]Skipped models[/dark_orange3]\n\n{msg}")
	def log_failed_models(self,errors:t.List[NodeExecutionFailedError])->_A:
		if errors:
			self._print('\n[red]Failed models[/red]\n');error_messages=_format_node_errors(errors)
			for(node_name,msg)in error_messages.items():self._print(f"  [red]{node_name}[/red]\n\n{msg}")
	def log_models_updated_during_restatement(self,snapshots:t.List[t.Tuple[SnapshotTableInfo,SnapshotTableInfo]],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str]=_A)->_A:
		if snapshots:
			tree=Tree(f"[yellow]The following models had new versions deployed while data was being restated:[/yellow]")
			for(restated_snapshot,updated_snapshot)in snapshots:display_name=restated_snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect);current_branch=tree.add(display_name);current_branch.add(f"restated version: '{restated_snapshot.version}'");current_branch.add(f"currently active version: '{updated_snapshot.version}'")
			self._print(tree);self._print('')
	def log_destructive_change(self,snapshot_name:str,alter_operations:t.List[TableAlterOperation],dialect:str,error:bool=_B)->_A:
		if error:self._print(format_destructive_change_msg(snapshot_name,alter_operations,dialect))
		else:self.log_warning(format_destructive_change_msg(snapshot_name,alter_operations,dialect,error))
	def log_additive_change(self,snapshot_name:str,alter_operations:t.List[TableAlterOperation],dialect:str,error:bool=_B)->_A:
		if error:self._print(format_additive_change_msg(snapshot_name,alter_operations,dialect))
		else:self.log_warning(format_additive_change_msg(snapshot_name,alter_operations,dialect,error))
	def log_error(self,message:str)->_A:self._print(f"[red]{rebrand(message)}[/red]")
	def log_warning(self,short_message:str,long_message:t.Optional[str]=_A)->_A:
		short_message=rebrand(short_message);long_message=rebrand(long_message);logger.warning(long_message or short_message)
		if not self.ignore_warnings:
			if long_message:
				file_path=_A
				for handler in logger.root.handlers:
					if isinstance(handler,logging.FileHandler):file_path=handler.baseFilename;break
				file_path_msg=f" Learn more in logs: {file_path}\n"if file_path else'';short_message=f"{short_message}{file_path_msg}"
			message_lstrip=short_message.lstrip();leading_ws=short_message[:-len(message_lstrip)];message_formatted=f"{leading_ws}[yellow]\\[WARNING] {message_lstrip}[/yellow]";self._print(message_formatted)
	def log_success(self,message:str)->_A:self._print(f"[green]{message}[/green]\n")
	def loading_start(self,message:t.Optional[str]=_A)->uuid.UUID:id=uuid.uuid4();self.loading_status[id]=Status(message or'',console=self.console,spinner='line');self.loading_status[id].start();return id
	def loading_stop(self,id:uuid.UUID)->_A:self.loading_status[id].stop();del self.loading_status[id]
	def show_table_diff_details(self,models_to_diff:t.List[str])->_A:
		if models_to_diff:
			m_tree=Tree('\n[b]Models to compare:')
			for m in models_to_diff:m_tree.add(f"[{self.TABLE_DIFF_SOURCE_BLUE}]{m}[/{self.TABLE_DIFF_SOURCE_BLUE}]")
			self._print(m_tree);self._print('')
	def start_table_diff_progress(self,models_to_diff:int)->_A:
		if not self.table_diff_progress:self.table_diff_progress=make_progress_bar('Calculating model differences',self.console);self.table_diff_model_progress=Progress(TextColumn(_V,justify=_L),SpinnerColumn(spinner_name=_W),console=self.console);progress_table=Table.grid();progress_table.add_row(self.table_diff_progress);progress_table.add_row(self.table_diff_model_progress);self.table_diff_progress_live=Live(progress_table,refresh_per_second=10);self.table_diff_progress_live.start();self.table_diff_model_task=self.table_diff_progress.add_task('Diffing',total=models_to_diff)
	def start_table_diff_model_progress(self,model:str)->_A:
		if self.table_diff_model_progress and model not in self.table_diff_model_tasks:self.table_diff_model_tasks[model]=self.table_diff_model_progress.add_task(f"Diffing {model}...",view_name=model,total=1)
	def update_table_diff_progress(self,model:str)->_A:
		if self.table_diff_progress:self.table_diff_progress.update(self.table_diff_model_task,refresh=_B,advance=1)
		if self.table_diff_model_progress and model in self.table_diff_model_tasks:model_task_id=self.table_diff_model_tasks[model];self.table_diff_model_progress.remove_task(model_task_id)
	def stop_table_diff_progress(self,success:bool)->_A:
		if self.table_diff_progress_live:
			self.table_diff_progress_live.stop();self.table_diff_progress_live=_A;self.log_status_update('')
			if success:self.log_success(f"Table diff completed successfully!")
			else:self.log_error('Table diff failed!')
		self.table_diff_progress=_A;self.table_diff_model_progress=_A;self.table_diff_model_tasks={}
	def show_table_diff_summary(self,table_diff:TableDiff)->_A:
		tree=Tree('\n[b]Table Diff')
		if table_diff.model_name:model=Tree('Model:');model.add(f"[blue]{table_diff.model_name}[/blue]");tree.add(model);envs=Tree('Environment:');source=Tree(f"Source: [{self.TABLE_DIFF_SOURCE_BLUE}]{table_diff.source_alias}[/{self.TABLE_DIFF_SOURCE_BLUE}]");envs.add(source);target=Tree(f"Target: [{self.TABLE_DIFF_TARGET_GREEN}]{table_diff.target_alias}[/{self.TABLE_DIFF_TARGET_GREEN}]");envs.add(target);tree.add(envs)
		tables=Tree('Tables:');tables.add(f"Source: [{self.TABLE_DIFF_SOURCE_BLUE}]{table_diff.source}[/{self.TABLE_DIFF_SOURCE_BLUE}]");tables.add(f"Target: [{self.TABLE_DIFF_TARGET_GREEN}]{table_diff.target}[/{self.TABLE_DIFF_TARGET_GREEN}]");tree.add(tables);join=Tree('Join On:');_,_,key_column_names=table_diff.key_columns
		for col_name in key_column_names:join.add(f"[yellow]{col_name}[/yellow]")
		tree.add(join);self._print(tree)
	def show_schema_diff(self,schema_diff:SchemaDiff)->_A:
		source_name=schema_diff.source
		if schema_diff.source_alias:source_name=schema_diff.source_alias.upper()
		target_name=schema_diff.target
		if schema_diff.target_alias:target_name=schema_diff.target_alias.upper()
		first_line=f"\n[b]Schema Diff Between '[{self.TABLE_DIFF_SOURCE_BLUE}]{source_name}[/{self.TABLE_DIFF_SOURCE_BLUE}]' and '[{self.TABLE_DIFF_TARGET_GREEN}]{target_name}[/{self.TABLE_DIFF_TARGET_GREEN}]'"
		if schema_diff.model_name:first_line=first_line+f" environments for model '[blue]{schema_diff.model_name}[/blue]'"
		tree=Tree(first_line+':')
		if any([schema_diff.added,schema_diff.removed,schema_diff.modified]):
			if schema_diff.added:
				added=Tree('[green]Added Columns:')
				for(c,t)in schema_diff.added:added.add(f"[green]{c} ({t})")
				tree.add(added)
			if schema_diff.removed:
				removed=Tree('[red]Removed Columns:')
				for(c,t)in schema_diff.removed:removed.add(f"[red]{c} ({t})")
				tree.add(removed)
			if schema_diff.modified:
				modified=Tree('[magenta]Modified Columns:')
				for(c,(ft,tt))in schema_diff.modified.items():modified.add(f"[magenta]{c} ({ft} -> {tt})")
				tree.add(modified)
		else:tree.add('[b]Schemas match')
		self.console.print(tree)
	def show_row_diff(self,row_diff:RowDiff,show_sample:bool=_B,skip_grain_check:bool=_C)->_A:
		if row_diff.empty:self.console.print('\n[b][red]Neither the source nor the target table contained any records[/red][/b]');return
		source_name=row_diff.source
		if row_diff.source_alias:source_name=row_diff.source_alias.upper()
		target_name=row_diff.target
		if row_diff.target_alias:target_name=row_diff.target_alias.upper()
		if row_diff.stats['null_grain_count']>0 or not skip_grain_check and(row_diff.stats['distinct_count_s']!=row_diff.stats['s_count']or row_diff.stats['distinct_count_t']!=row_diff.stats['t_count']):self.console.print('[b][red]\nGrain should have unique and not-null audits for accurate results.[/red][/b]')
		tree=Tree('[b]Row Counts:[/b]')
		if row_diff.full_match_count:tree.add(f" [b][cyan]FULL MATCH[/cyan]:[/b] {row_diff.full_match_count} rows ({row_diff.full_match_pct}%)")
		if row_diff.partial_match_count:tree.add(f" [b][blue]PARTIAL MATCH[/blue]:[/b] {row_diff.partial_match_count} rows ({row_diff.partial_match_pct}%)")
		if row_diff.s_only_count:tree.add(f" [b][yellow]{source_name} ONLY[/yellow]:[/b] {row_diff.s_only_count} rows ({row_diff.s_only_pct}%)")
		if row_diff.t_only_count:tree.add(f" [b][green]{target_name} ONLY[/green]:[/b] {row_diff.t_only_count} rows ({row_diff.t_only_pct}%)")
		self.console.print(_D,tree);self.console.print('\n[b][blue]COMMON ROWS[/blue] column comparison stats:[/b]')
		if row_diff.column_stats.shape[0]>0:self.console.print(row_diff.column_stats.to_string(index=_B),end=_K)
		else:self.console.print('  No columns with same name and data type in both tables')
		if show_sample:
			sample=row_diff.joined_sample;self.console.print('\n[b][blue]COMMON ROWS[/blue] sample data differences:[/b]')
			if sample.shape[0]>0:
				keys:list[str]=[];columns:dict[str,list[str]]={};source_prefix,source_name=(f"{source_name}__",source_name)if source_name.lower()!=row_diff.source.lower()else('s__','SOURCE');target_prefix,target_name=(f"{target_name}__",target_name)if target_name.lower()!=row_diff.target.lower()else('t__','TARGET')
				for column in row_diff.joined_sample.columns:
					if source_prefix in column:column_name='__'.join(column.split(source_prefix)[1:]);columns[column_name]=[column,target_prefix+column_name]
					elif target_prefix not in column:keys.append(column)
				column_styles={source_name:self.TABLE_DIFF_SOURCE_BLUE,target_name:self.TABLE_DIFF_TARGET_GREEN}
				for(column,[source_column,target_column])in columns.items():
					column_table=row_diff.joined_sample[keys+[source_column,target_column]];column_table=column_table[column_table.apply(lambda row:not _cells_match(row[source_column],row[target_column]),axis=1)];column_table=column_table.rename(columns={source_column:source_name,target_column:target_name});table=Table(show_header=_B)
					for column_name in column_table.columns:style=column_styles.get(column_name,'');table.add_column(column_name,style=style,header_style=style)
					for(_,row)in column_table.iterrows():table.add_row(*[str(round(cell,row_diff.decimals)if isinstance(cell,float)else cell)for cell in row])
					self.console.print(f"Column: [underline][bold cyan]{column}[/bold cyan][/underline]",table,end=_D)
			else:self.console.print('  All joined rows match')
			if row_diff.s_sample.shape[0]>0:self.console.print(f"\n[b][yellow]{source_name} ONLY[/yellow] sample rows:[/b]");self.console.print(row_diff.s_sample.to_string(index=_C),end=_K)
			if row_diff.t_sample.shape[0]>0:self.console.print(f"\n[b][green]{target_name} ONLY[/green] sample rows:[/b]");self.console.print(row_diff.t_sample.to_string(index=_C),end=_K)
	def show_table_diff(self,table_diffs:t.List[TableDiff],show_sample:bool=_B,skip_grain_check:bool=_C,temp_schema:t.Optional[str]=_A)->_A:
		if len(table_diffs)>1:
			mismatched_tables=[];fully_matched=[]
			for table_diff in table_diffs:
				if table_diff.schema_diff().source_schema==table_diff.schema_diff().target_schema and table_diff.row_diff(temp_schema=temp_schema,skip_grain_check=skip_grain_check).full_match_pct==100:fully_matched.append(table_diff)
				else:mismatched_tables.append(table_diff)
			table_diffs=mismatched_tables if mismatched_tables else[]
			if fully_matched:
				m_tree=Tree('\n[b]Identical Tables')
				for m in fully_matched:m_tree.add(f"[{self.TABLE_DIFF_SOURCE_BLUE}]{m.source}[/{self.TABLE_DIFF_SOURCE_BLUE}] - [{self.TABLE_DIFF_TARGET_GREEN}]{m.target}[/{self.TABLE_DIFF_TARGET_GREEN}]")
				self._print(m_tree)
			if mismatched_tables:
				m_tree=Tree('\n[b]Mismatched Tables')
				for m in mismatched_tables:m_tree.add(f"[{self.TABLE_DIFF_SOURCE_BLUE}]{m.source}[/{self.TABLE_DIFF_SOURCE_BLUE}] - [{self.TABLE_DIFF_TARGET_GREEN}]{m.target}[/{self.TABLE_DIFF_TARGET_GREEN}]")
				self._print(m_tree)
		for table_diff in table_diffs:self.show_table_diff_summary(table_diff);self.show_schema_diff(table_diff.schema_diff());self.show_row_diff(table_diff.row_diff(temp_schema=temp_schema,skip_grain_check=skip_grain_check),show_sample=show_sample,skip_grain_check=skip_grain_check)
	def print_environments(self,environments_summary:t.List[EnvironmentSummary])->_A:output=[f"{summary.name} - {time_like_to_str(summary.expiration_ts)}"if summary.expiration_ts else f"{summary.name} - No Expiry"for summary in environments_summary];output_str=_D.join([str(len(output)),*output]);self.log_status_update(f"Number of Vulcan environments are: {output_str}")
	def show_intervals(self,snapshot_intervals:t.Dict[Snapshot,SnapshotIntervals])->_A:
		complete=Tree(f"[b]Complete Intervals[/b]");incomplete=Tree(f"[b]Missing Intervals[/b]")
		for(snapshot,intervals)in sorted(snapshot_intervals.items(),key=lambda s:s[0].node.name):
			if intervals.intervals:incomplete.add(f"{snapshot.node.name}: [{intervals.format_intervals(snapshot.node.interval_unit)}]")
			else:complete.add(snapshot.node.name)
		if complete.children:self._print(complete)
		if incomplete.children:self._print(incomplete)
	def print_connection_config(self,config:ConnectionConfig,title:str=_U)->_A:
		tree=Tree(f"[b]{title}:[/b]");tree.add(f"Type: [bold cyan]{config.type_}[/bold cyan]");tree.add(f"Catalog: [bold cyan]{config.get_catalog()}[/bold cyan]")
		try:engine_adapter_type=config._engine_adapter;tree.add(f"Dialect: [bold cyan]{engine_adapter_type.DIALECT}[/bold cyan]")
		except NotImplementedError:pass
		self._print(tree)
	def _get_snapshot_change_category(self,snapshot:Snapshot,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str])->_A:choices=self._snapshot_change_choices(snapshot,plan_builder.environment_naming_info,default_catalog);response=self._prompt(_D.join([f"[{i+1}] {choice}"for(i,choice)in enumerate(choices.values())]),show_choices=_C,choices=[f"{i+1}"for i in range(len(choices))]);choice=list(choices)[int(response)-1];plan_builder.set_choice(snapshot,choice)
	def _snapshot_change_choices(self,snapshot:Snapshot,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],use_rich_formatting:bool=_B)->t.Dict[SnapshotChangeCategory,str]:
		direct=snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)
		if use_rich_formatting:direct=f"[direct]{direct}[/direct]"
		indirect='indirectly modified children'
		if use_rich_formatting:indirect=f"[indirect]{indirect}[/indirect]"
		if snapshot.is_view:choices={SnapshotChangeCategory.BREAKING:f"Update {direct} and backfill {indirect}",SnapshotChangeCategory.NON_BREAKING:f"Update {direct} but don't backfill {indirect}"}
		elif snapshot.is_symbolic:choices={SnapshotChangeCategory.BREAKING:f"Backfill {indirect}",SnapshotChangeCategory.NON_BREAKING:f"Don't backfill {indirect}"}
		else:choices={SnapshotChangeCategory.BREAKING:f"Backfill {direct} and {indirect}",SnapshotChangeCategory.NON_BREAKING:f"Backfill {direct} but not {indirect}"}
		labeled_choices={k:f"[{SNAPSHOT_CHANGE_CATEGORY_STR[k]}] {v}"for(k,v)in choices.items()};return labeled_choices
	def show_linter_violations(self,violations:t.List[RuleViolation],source:LintSource,is_error:bool=_C)->_A:
		severity='errors'if is_error else _g;path=lint_source_path(source);sorted_violations=sorted(violations,key=lambda v:(v.violation_range.start.line if v.violation_range else-1,v.rule.name.lower()));violations_text=[f" - Line {v.violation_range.start.line+1}: {v.rule.name} - {v.violation_msg}"if v.violation_range else f" - {v.rule.name}: {v.violation_msg}"for v in sorted_violations];violations_msg=_D.join(violations_text);msg=f"Linter {severity} for {path}:\n{violations_msg}"
		if is_error:self.log_error(msg)
		else:self.log_warning(msg)
	def _log_test_details(self,result:ModelTextTestResult,unittest_char_separator:bool=_B)->_A:
		if result.wasSuccessful():self._print(_D,end='');return
		if unittest_char_separator:self._print(f"\n{unittest.TextTestResult.separator1}\n\n",end='')
		for((test_case,failure),test_failure_tables)in zip_longest(result.failures,result.failure_tables):
			self._print(unittest.TextTestResult.separator2);self._print(f"FAIL: {test_case}")
			if(test_description:=test_case.shortDescription()):self._print(test_description)
			self._print(f"{unittest.TextTestResult.separator2}")
			if not test_failure_tables:self._print(failure)
			else:
				for failure_table in test_failure_tables:self._print(failure_table);self._print(_D,end='')
		for(test_case,error)in result.errors:self._print(unittest.TextTestResult.separator2);self._print(f"ERROR: {test_case}");self._print(f"{unittest.TextTestResult.separator2}");self._print(error)
def _cells_match(x:t.Any,y:t.Any)->bool:
	import pandas as pd,numpy as np
	def _normalize(val:t.Any)->t.Any:
		isnull=pd.isnull(val)
		if isinstance(isnull,bool):
			if isnull:val=_A
		elif all(isnull):val=_A
		return list(val)if isinstance(val,(pd.Series,np.ndarray))else val
	return _normalize(x)==_normalize(y)
def add_to_layout_widget(target_widget:LayoutWidget,*widgets:widgets.Widget)->LayoutWidget:target_widget.children+=tuple(widgets);return target_widget
class NotebookMagicConsole(TerminalConsole):
	def __init__(self,display:t.Optional[t.Callable]=_A,console:t.Optional[RichConsole]=_A,dialect:DialectType=_A,**kwargs:t.Any)->_A:import ipywidgets as widgets;from IPython import get_ipython;from IPython.display import display as ipython_display;super().__init__(console,**kwargs);self.display=display or get_ipython().user_ns.get('display',ipython_display);self.missing_dates_output=widgets.Output();self.dynamic_options_after_categorization_output=widgets.VBox();self.dialect=dialect
	def _show_missing_dates(self,plan:Plan,default_catalog:t.Optional[str])->_A:
		self._add_to_dynamic_options(self.missing_dates_output);self.missing_dates_output.outputs=()
		with self.missing_dates_output:super()._show_missing_dates(plan,default_catalog)
	def _apply(self,button:widgets.Button)->_A:
		button.disabled=_B
		with button.output:button.plan_builder.apply()
	def _prompt_promote(self,plan_builder:PlanBuilder)->_A:import ipywidgets as widgets;button=widgets.Button(description=_e,disabled=_C,button_style=_h,layout={_E:'10rem'});self._add_to_dynamic_options(button);output=widgets.Output();self._add_to_dynamic_options(output);button.plan_builder=plan_builder;button.on_click(self._apply);button.output=output
	def _prompt_effective_from(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str])->_A:
		import ipywidgets as widgets;prompt=widgets.VBox()
		def effective_from_change_callback(change:t.Dict[str,datetime.datetime])->_A:plan_builder.set_effective_from(change[_O]);self._show_options_after_categorization(plan_builder,auto_apply,default_catalog,no_prompts=_C)
		def going_forward_change_callback(change:t.Dict[str,bool])->_A:checked=change[_O];plan_builder.set_effective_from(_A if checked else yesterday_ds());self._show_options_after_categorization(plan_builder,auto_apply=auto_apply,default_catalog=default_catalog,no_prompts=_C)
		date_picker=widgets.DatePicker(disabled=plan_builder.build().effective_from is _A,value=to_date(plan_builder.build().effective_from or yesterday_ds()),layout={_E:'auto'});date_picker.observe(effective_from_change_callback,_P);going_forward_checkbox=widgets.Checkbox(value=plan_builder.build().effective_from is _A,description='Apply Going Forward Once Deployed To Prod',disabled=_C,indent=_C);going_forward_checkbox.observe(going_forward_change_callback,_P);add_to_layout_widget(prompt,widgets.HBox([widgets.Label('Effective From Date:',layout={_E:_T}),date_picker,going_forward_checkbox]));self._add_to_dynamic_options(prompt)
	def _prompt_backfill(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str])->_A:
		import ipywidgets as widgets;prompt=widgets.VBox();backfill_or_preview='Preview'if plan_builder.build().is_dev and plan_builder.build().forward_only else'Backfill'
		def _date_picker(plan_builder:PlanBuilder,value:t.Any,on_change:t.Callable,disabled:bool=_C)->widgets.DatePicker:picker=widgets.DatePicker(disabled=disabled,value=value,layout={_E:'auto'});picker.observe(on_change,_P);return picker
		def start_change_callback(change:t.Dict[str,datetime.datetime])->_A:plan_builder.set_start(change[_O]);self._show_options_after_categorization(plan_builder,auto_apply,default_catalog,no_prompts=_C)
		def end_change_callback(change:t.Dict[str,datetime.datetime])->_A:plan_builder.set_end(change[_O]);self._show_options_after_categorization(plan_builder,auto_apply,default_catalog,no_prompts=_C)
		if plan_builder.is_start_and_end_allowed:add_to_layout_widget(prompt,widgets.HBox([widgets.Label(f"Start {backfill_or_preview} Date:",layout={_E:_T}),_date_picker(plan_builder,to_date(plan_builder.build().start),start_change_callback)]));add_to_layout_widget(prompt,widgets.HBox([widgets.Label(f"End {backfill_or_preview} Date:",layout={_E:_T}),_date_picker(plan_builder,to_date(plan_builder.build().end),end_change_callback)]))
		self._add_to_dynamic_options(prompt)
		if not auto_apply:button=widgets.Button(description=f"Apply - {backfill_or_preview} Tables",disabled=_C,button_style=_h);self._add_to_dynamic_options(button);output=widgets.Output();self._add_to_dynamic_options(output);button.plan_builder=plan_builder;button.on_click(self._apply);button.output=output
	def _show_options_after_categorization(self,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str],no_prompts:bool)->_A:self.dynamic_options_after_categorization_output.children=();self.display(self.dynamic_options_after_categorization_output);super()._show_options_after_categorization(plan_builder,auto_apply,default_catalog,no_prompts)
	def _add_to_dynamic_options(self,*widgets:widgets.Widget)->_A:add_to_layout_widget(self.dynamic_options_after_categorization_output,*widgets)
	def _get_snapshot_change_category(self,snapshot:Snapshot,plan_builder:PlanBuilder,auto_apply:bool,default_catalog:t.Optional[str])->_A:
		import ipywidgets as widgets;choice_mapping=self._snapshot_change_choices(snapshot,plan_builder.environment_naming_info,default_catalog,use_rich_formatting=_C);choices=list(choice_mapping);plan_builder.set_choice(snapshot,choices[0])
		def radio_button_selected(change:t.Dict[str,t.Any])->_A:plan_builder.set_choice(snapshot,choices[change['owner'].index]);self._show_options_after_categorization(plan_builder,auto_apply,default_catalog,no_prompts=_C)
		radio=widgets.RadioButtons(options=choice_mapping.values(),layout={_E:'max-content'},disabled=_C);radio.observe(radio_button_selected,_P);self.display(radio)
	def log_test_results(self,result:ModelTextTestResult,target_dialect:str)->_A:
		E='100%';D='color';C='<br>';B='style';A='span'
		if not result.testsRun:return
		import ipywidgets as widgets;divider_length=70;shared_style={'font-size':'11px','font-weight':'bold','font-family':"Menlo,'DejaVu Sans Mono',consolas,'Courier New',monospace"};message=f"Ran {result.testsRun} tests against {target_dialect} in {result.duration} seconds."
		if result.wasSuccessful():success_color={D:'#008000'};header=str(h(A,{B:shared_style},'-'*divider_length));message=str(h(A,{B:{**shared_style,**success_color}},f"Successfully {message}"));footer=str(h(A,{B:shared_style},'='*divider_length));self.display(widgets.HTML(C.join([header,message,footer])))
		else:
			output=self._captured_unit_test_results(result);fail_color={D:'#db3737'};fail_shared_style={**shared_style,**fail_color};header=str(h(A,{B:fail_shared_style},'-'*divider_length));message=str(h(A,{B:fail_shared_style},_f));fail_and_error_tests=result.get_fail_and_error_tests();failed_tests=[str(h(A,{B:fail_shared_style},f"Failed tests ({len(fail_and_error_tests)}):"))]
			for test in fail_and_error_tests:failed_tests.append(str(h(A,{B:fail_shared_style},f" • {test.model.name}::{test.test_name}")))
			failures=C.join(failed_tests);footer=str(h(A,{B:fail_shared_style},'='*divider_length));error_output=widgets.Textarea(output,layout={'height':'300px',_E:E});test_info=widgets.HTML(C.join([header,message,footer,failures,footer]));self.display(widgets.VBox(children=[test_info,error_output],layout={_E:E}))
class CaptureTerminalConsole(TerminalConsole):
	def __init__(self,console:t.Optional[RichConsole]=_A,**kwargs:t.Any)->_A:super().__init__(console=console,**kwargs);(self._captured_outputs):t.List[str]=[];(self._warnings):t.List[str]=[];(self._errors):t.List[str]=[]
	@property
	def captured_output(self)->str:return''.join(self._captured_outputs)
	@property
	def captured_warnings(self)->str:return''.join(self._warnings)
	@property
	def captured_errors(self)->str:return''.join(self._errors)
	def consume_captured_output(self)->str:
		try:return self.captured_output
		finally:self._captured_outputs=[]
	def consume_captured_warnings(self)->str:
		try:return self.captured_warnings
		finally:self._warnings=[]
	def consume_captured_errors(self)->str:
		try:return self.captured_errors
		finally:self._errors=[]
	def log_warning(self,short_message:str,long_message:t.Optional[str]=_A,*args:t.Any,**kwargs:t.Any)->_A:
		if short_message not in self._warnings:self._warnings.append(short_message)
		if kwargs.pop('print',_B):super().log_warning(short_message,long_message)
	def log_error(self,message:str,*args:t.Any,**kwargs:t.Any)->_A:
		if message not in self._errors:self._errors.append(message)
		if kwargs.pop('print',_B):super().log_error(message)
	def log_skipped_models(self,snapshot_names:t.Set[str])->_A:
		if snapshot_names:self._captured_outputs.append(_D.join([f"SKIPPED snapshot {skipped}\n"for skipped in snapshot_names]));super().log_skipped_models(snapshot_names)
	def log_failed_models(self,errors:t.List[NodeExecutionFailedError])->_A:self._errors.extend([str(ex)for ex in errors if str(ex)not in self._errors]);super().log_failed_models(errors)
	def _print(self,value:t.Any,**kwargs:t.Any)->_A:
		with self.console.capture()as capture:self.console.print(value,**kwargs)
		self._captured_outputs.append(capture.get())
class MarkdownConsole(CaptureTerminalConsole):
	CHECK_MARK='';AUDIT_PASS_MARK='passed ';GREEN_AUDIT_PASS_MARK=AUDIT_PASS_MARK;AUDIT_FAIL_MARK='failed ';AUDIT_PADDING=7
	def __init__(self,**kwargs:t.Any)->_A:self.alert_block_max_content_length=int(kwargs.pop('alert_block_max_content_length',500));self.alert_block_collapsible_threshold=int(kwargs.pop('alert_block_collapsible_threshold',200));self.warning_capture_only=kwargs.pop('warning_capture_only',_C);self.error_capture_only=kwargs.pop('error_capture_only',_C);super().__init__(**{**kwargs,_i:RichConsole(no_color=_B,width=kwargs.pop(_E,_A))})
	def show_environment_difference_summary(self,context_diff:ContextDiff,no_diff:bool=_B)->_A:
		if context_diff.is_new_environment:
			msg=f"\n**`{context_diff.environment}` environment will be initialized**"if not context_diff.create_from_env_exists else f"\n**New environment `{context_diff.environment}` will be created from `{context_diff.create_from}`**";self._print(msg)
			if not context_diff.has_snapshot_changes:return
		if not context_diff.has_changes:self._print(f"\n**No changes to plan: project files match the `{context_diff.environment}` environment**\n");return
		self._print(f"\n**Summary of differences from `{context_diff.environment}`:**")
		if context_diff.has_requirement_changes:self._print(f"\nRequirements:\n{context_diff.requirements_diff()}")
		if context_diff.has_environment_statements_changes and not no_diff:
			self._print('\nEnvironment statements:\n')
			for(_,diff)in context_diff.environment_statements_diff(include_python_env=not context_diff.is_new_environment):self._print(diff)
	def show_model_difference_summary(self,context_diff:ContextDiff,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],no_diff:bool=_B)->_A:
		added_snapshots={context_diff.snapshots[s_id]for s_id in context_diff.added}
		if added_snapshots:self._print('\n**Added Models:**');self._print_models_with_threshold(environment_naming_info,{s for s in added_snapshots if s.is_model},default_catalog)
		added_snapshot_audits={s for s in added_snapshots if s.is_audit}
		if added_snapshot_audits:
			self._print('\n**Added Standalone Audits:**')
			for snapshot in sorted(added_snapshot_audits):self._print(f"- `{snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}`")
		removed_snapshot_table_infos=set(context_diff.removed_snapshots.values())
		if removed_snapshot_table_infos:self._print('\n**Removed Models:**');self._print_models_with_threshold(environment_naming_info,{s for s in removed_snapshot_table_infos if s.is_model},default_catalog)
		removed_audit_snapshot_table_infos={s for s in removed_snapshot_table_infos if s.is_audit}
		if removed_audit_snapshot_table_infos:
			self._print('\n**Removed Standalone Audits:**')
			for snapshot_table_info in sorted(removed_audit_snapshot_table_infos):self._print(f"- `{snapshot_table_info.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}`")
		modified_snapshots={current_snapshot for(current_snapshot,_)in context_diff.modified_snapshots.values()}
		if modified_snapshots:self._print_modified_models(context_diff,modified_snapshots,environment_naming_info,default_catalog,no_diff)
	def _print_models_with_threshold(self,environment_naming_info:EnvironmentNamingInfo,snapshot_table_infos:t.Set[SnapshotInfoLike],default_catalog:t.Optional[str]=_A)->_A:
		models=sorted(snapshot_table_infos);list_length=len(models)
		if self.verbosity<Verbosity.VERY_VERBOSE and list_length>self.INDIRECTLY_MODIFIED_DISPLAY_THRESHOLD:self._print(f"- `{models[0].display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}`");self._print(f"- `.... {list_length-2} more ....`\n");self._print(f"- `{models[-1].display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}`")
		else:
			for snapshot_table_info in models:category_str=SNAPSHOT_CHANGE_CATEGORY_STR[snapshot_table_info.change_category];self._print(f"- `{snapshot_table_info.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}` ({category_str})")
	def _print_modified_models(self,context_diff:ContextDiff,modified_snapshots:t.Set[Snapshot],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str]=_A,no_diff:bool=_B)->_A:
		directly_modified=[];indirectly_modified:t.List[Snapshot]=[];metadata_modified=[]
		for snapshot in modified_snapshots:
			if context_diff.directly_modified(snapshot.name):directly_modified.append(snapshot)
			elif context_diff.indirectly_modified(snapshot.name):indirectly_modified.append(snapshot)
			elif context_diff.metadata_updated(snapshot.name):metadata_modified.append(snapshot)
		if directly_modified:
			self._print('\n**Directly Modified:**')
			for snapshot in sorted(directly_modified):
				category_str=SNAPSHOT_CHANGE_CATEGORY_STR[snapshot.change_category];self._print(f"* `{snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}` ({category_str})");indirectly_modified_children=sorted([s for s in indirectly_modified if snapshot.snapshot_id in s.parents])
				if not no_diff:
					diff_text=context_diff.text_diff(snapshot.name)
					if diff_text:diff_text=f"\n```diff\n{diff_text}\n```";diff_text_indented=_D.join([f"  {line}"for line in diff_text.splitlines()]);self._print(diff_text_indented)
					elif indirectly_modified_children:self._print(_D)
				if indirectly_modified_children:
					self._print('  Indirectly Modified Children:')
					for child_snapshot in indirectly_modified_children:child_category_str=SNAPSHOT_CHANGE_CATEGORY_STR[child_snapshot.change_category];self._print(f"    - `{child_snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}` ({child_category_str})")
					self._print(_D)
		if indirectly_modified:self._print('\n**Indirectly Modified:**');self._print_models_with_threshold(environment_naming_info,set(indirectly_modified),default_catalog)
		if metadata_modified:
			self._print('\n**Metadata Updated:**')
			for snapshot in sorted(metadata_modified):self._print(f"- `{snapshot.display_name(environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}`")
	def _show_missing_dates(self,plan:Plan,default_catalog:t.Optional[str])->_A:
		missing_intervals=plan.missing_intervals
		if not missing_intervals:return
		self._print('\n**Models needing backfill:**');snapshots=[]
		for missing in missing_intervals:
			snapshot=plan.context_diff.snapshots[missing.snapshot_id]
			if not snapshot.is_model:continue
			preview_modifier=''
			if not plan.deployability_index.is_deployable(snapshot):preview_modifier=' (**preview**)'
			display_name=snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect);snapshots.append(f"* `{display_name}`: \\[{_format_missing_intervals(snapshot,missing)}]{preview_modifier}")
		length=len(snapshots)
		if self.verbosity<Verbosity.VERY_VERBOSE and length>self.INDIRECTLY_MODIFIED_DISPLAY_THRESHOLD:self._print(snapshots[0]);self._print(f"- `.... {length-2} more ....`\n");self._print(snapshots[-1])
		else:
			for snap in snapshots:self._print(snap)
	def _show_categorized_snapshots(self,plan:Plan,default_catalog:t.Optional[str])->_A:
		context_diff=plan.context_diff
		for snapshot in plan.categorized:
			if context_diff.directly_modified(snapshot.name):
				category_str=SNAPSHOT_CHANGE_CATEGORY_STR[snapshot.change_category];tree=Tree(f"[bold][direct]Directly Modified: {snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)} ({category_str})");indirect_tree=_A
				for child_sid in sorted(plan.indirectly_modified.get(snapshot.snapshot_id,set())):
					child_snapshot=context_diff.snapshots[child_sid]
					if not indirect_tree:indirect_tree=Tree(_S);tree.add(indirect_tree)
					child_category_str=SNAPSHOT_CHANGE_CATEGORY_STR[child_snapshot.change_category];indirect_tree.add(f"[indirect]{child_snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)} ({child_category_str})")
				if indirect_tree:indirect_tree=self._limit_model_names(indirect_tree,self.verbosity)
			elif context_diff.metadata_updated(snapshot.name):tree=Tree(f"[bold][metadata]Metadata Updated: {snapshot.display_name(plan.environment_naming_info,default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect)}")
			else:continue
			self._print(f"```diff\n{context_diff.text_diff(snapshot.name)}\n```\n");self._print('```\n');self._print(tree);self._print('\n```')
	def stop_evaluation_progress(self,success:bool=_B)->_A:super().stop_evaluation_progress(success);self._print(_D)
	def stop_creation_progress(self,success:bool=_B)->_A:super().stop_creation_progress(success);self._print(_D)
	def stop_promotion_progress(self,success:bool=_B)->_A:super().stop_promotion_progress(success);self._print(_D)
	def log_warning(self,short_message:str,long_message:t.Optional[str]=_A)->_A:super().log_warning(short_message,long_message,print=not self.warning_capture_only)
	def log_error(self,message:str)->_A:super().log_error(message,print=not self.error_capture_only)
	def log_success(self,message:str)->_A:self._print(message)
	def log_test_results(self,result:ModelTextTestResult,target_dialect:str)->_A:
		if not result.testsRun:return
		message=f"Ran `{result.testsRun}` Tests Against `{target_dialect}`"
		if result.wasSuccessful():self._print(f"**Successfully {message}**\n\n")
		else:
			self._print('```');self._log_test_details(result,unittest_char_separator=_C);self._print('```\n\n');fail_and_error_tests=result.get_fail_and_error_tests();self._print(f"**{message}**\n");self._print(f"**Failed tests ({len(fail_and_error_tests)}):**")
			for test in fail_and_error_tests:
				if isinstance(test,ModelTest):self._print(f" • `{test.model.name}`::`{test.test_name}`\n\n")
	def log_skipped_models(self,snapshot_names:t.Set[str])->_A:
		if snapshot_names:
			self._print(f"**Skipped models**")
			for snapshot_name in snapshot_names:self._print(f"* `{snapshot_name}`")
			self._print('')
	def log_failed_models(self,errors:t.List[NodeExecutionFailedError])->_A:
		A='  ```'
		if errors:
			self._print('**Failed models**');error_messages=_format_node_errors(errors)
			for(node_name,msg)in error_messages.items():self._print(f"* `{node_name}`\n");self._print(A);self._print(msg);self._print(A)
			self._print('')
	def show_linter_violations(self,violations:t.List[RuleViolation],source:LintSource,is_error:bool=_C)->_A:
		severity='**errors**'if is_error else _g;path=lint_source_path(source);violations_msg=_D.join(f" - {violation}"for violation in violations);msg=f"\nLinter {severity} for `{path}`:\n{violations_msg}\n";self._print(msg)
		if is_error:self._errors.append(msg)
		else:self._warnings.append(msg)
	@property
	def captured_warnings(self)->str:return self._render_alert_block('WARNING',self._warnings)
	@property
	def captured_errors(self)->str:return self._render_alert_block('CAUTION',self._errors)
	def _render_alert_block(self,block_type:str,items:t.List[str])->str:
		if items:
			item_contents='';list_indicator='- 'if len(items)>1 else''
			for item in items:
				item=item.replace(_D,'\n> ');item_contents+=f">\n> {list_indicator}{item}\n"
				if len(item_contents)>self.alert_block_max_content_length:truncation_msg='...\n>\n> Truncated. Please check the console for full information.\n';item_contents=item_contents[0:self.alert_block_max_content_length-len(truncation_msg)];item_contents+=truncation_msg;break
			if len(item_contents)>self.alert_block_collapsible_threshold:item_contents=f"> <details>\n{item_contents}> </details>"
			return f"> [!{block_type}]\n{item_contents}\n"
		return''
	def _print(self,value:t.Any,**kwargs:t.Any)->_A:
		self.console.print(value,**kwargs)
		with self.console.capture()as capture:self.console.print(value,**kwargs)
		self._captured_outputs.append(capture.get())
class DatabricksMagicConsole(CaptureTerminalConsole):
	def __init__(self,*args:t.Any,**kwargs:t.Any)->_A:super().__init__(*args,**kwargs);(self.evaluation_batch_progress):t.Dict[SnapshotId,t.Tuple[str,int]]={};(self.promotion_status):t.Tuple[int,int]=(0,0);(self.model_creation_status):t.Tuple[int,int]=(0,0);(self.migration_status):t.Tuple[int,int]=(0,0)
	def _print(self,value:t.Any,**kwargs:t.Any)->_A:
		super()._print(value,**kwargs)
		for captured_output in self._captured_outputs:print(captured_output)
		self.consume_captured_output()
	def _prompt(self,message:str,**kwargs:t.Any)->t.Any:self._print(message);return super()._prompt('',**kwargs)
	def _confirm(self,message:str,**kwargs:t.Any)->bool:message=f"{message} [y/n]";self._print(message);return super()._confirm('',**kwargs)
	def start_evaluation_progress(self,batched_intervals:t.Dict[Snapshot,Intervals],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],audit_only:bool=_C)->_A:self.evaluation_model_batch_sizes={snapshot:len(intervals)for(snapshot,intervals)in batched_intervals.items()};self.evaluation_environment_naming_info=environment_naming_info;self.default_catalog=default_catalog
	def start_snapshot_evaluation_progress(self,snapshot:Snapshot,audit_only:bool=_C)->_A:
		if not self.evaluation_batch_progress.get(snapshot.snapshot_id):display_name=snapshot.display_name(self.evaluation_environment_naming_info,self.default_catalog if self.verbosity<Verbosity.VERY_VERBOSE else _A,dialect=self.dialect);self.evaluation_batch_progress[snapshot.snapshot_id]=display_name,0;print(f"Starting '{display_name}', Total batches: {self.evaluation_model_batch_sizes[snapshot]}")
	def update_snapshot_evaluation_progress(self,snapshot:Snapshot,interval:Interval,batch_idx:int,duration_ms:t.Optional[int],num_audits_passed:int,num_audits_failed:int,audit_only:bool=_C,execution_stats:t.Optional[QueryExecutionStats]=_A,auto_restatement_triggers:t.Optional[t.List[SnapshotId]]=_A)->_A:
		view_name,loaded_batches=self.evaluation_batch_progress[snapshot.snapshot_id]
		if audit_only:print(f"Completed Auditing {view_name}");return
		total_batches=self.evaluation_model_batch_sizes[snapshot];loaded_batches+=1;self.evaluation_batch_progress[snapshot.snapshot_id]=view_name,loaded_batches;finished_loading=loaded_batches==total_batches;status='Loaded'if finished_loading else'Loading';print(f"{status} '{view_name}', Completed Batches: {loaded_batches}/{total_batches}")
		if finished_loading:total_finished_loading=len([s for(s,total)in self.evaluation_model_batch_sizes.items()if self.evaluation_batch_progress.get(s.snapshot_id,(_A,-1))[1]==total]);total=len(self.evaluation_batch_progress);print(f"Completed Loading {total_finished_loading}/{total} Models")
	def stop_evaluation_progress(self,success:bool=_B)->_A:self.evaluation_batch_progress={};super().stop_evaluation_progress(success);print(f"Loading {_I if success else _J}")
	def start_creation_progress(self,snapshots:t.List[Snapshot],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:self.model_creation_status=0,len(snapshots);print('Starting Creating New Model Versions')
	def update_creation_progress(self,snapshot:SnapshotInfoLike)->_A:
		num_creations,total_creations=self.model_creation_status;num_creations+=1;self.model_creation_status=num_creations,total_creations
		if num_creations%5==0:print(f"Created New Model Versions: {num_creations}/{total_creations}")
	def stop_creation_progress(self,success:bool=_B)->_A:self.model_creation_status=0,0;print(f"New Model Creation {_I if success else _J}")
	def start_promotion_progress(self,snapshots:t.List[SnapshotTableInfo],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:self.promotion_status=0,len(snapshots);print(f"Virtually Updating '{environment_naming_info.name}'")
	def update_promotion_progress(self,snapshot:SnapshotInfoLike,promoted:bool)->_A:
		num_promotions,total_promotions=self.promotion_status;num_promotions+=1;self.promotion_status=num_promotions,total_promotions
		if num_promotions%5==0:print(f"Virtually Updated {num_promotions}/{total_promotions}")
	def stop_promotion_progress(self,success:bool=_B)->_A:self.promotion_status=0,0;print(f"Virtual Update {_I if success else _J}")
	def start_snapshot_migration_progress(self,total_tasks:int)->_A:self.migration_status=0,total_tasks;print('Starting Migration')
	def update_snapshot_migration_progress(self,num_tasks:int)->_A:
		num_migrations,total_migrations=self.migration_status;num_migrations+=num_tasks;self.migration_status=num_migrations,total_migrations
		if num_migrations%5==0:print(f"Migration Updated {num_migrations}/{total_migrations}")
	def log_migration_status(self,success:bool=_B)->_A:print(f"Migration {_I if success else _J}")
	def stop_snapshot_migration_progress(self,success:bool=_B)->_A:self.migration_status=0,0;print(f"Snapshot migration {_I if success else _J}")
	def start_env_migration_progress(self,total_tasks:int)->_A:self.env_migration_status=0,total_tasks;print('Starting Environment migration')
	def update_env_migration_progress(self,num_tasks:int)->_A:
		num_migrations,total_migrations=self.env_migration_status;num_migrations+=num_tasks;self.env_migration_status=num_migrations,total_migrations
		if num_migrations%5==0:print(f"Environment migration Updated {num_migrations}/{total_migrations}")
	def stop_env_migration_progress(self,success:bool=_B)->_A:self.env_migration_status=0,0;print(f"Environment migration {_I if success else _J}")
class DebuggerTerminalConsole(TerminalConsole):
	def __init__(self,console:t.Optional[RichConsole],*args:t.Any,dialect:DialectType=_A,ignore_warnings:bool=_C,**kwargs:t.Any)->_A:(self.console):RichConsole=console or srich.console;self.dialect=dialect;self.verbosity=Verbosity.DEFAULT;self.ignore_warnings=ignore_warnings
	def _write(self,msg:t.Any,*args:t.Any,**kwargs:t.Any)->_A:self.console.log(rebrand(msg),*[rebrand(a)for a in args],**kwargs)
	def start_plan_evaluation(self,plan:EvaluatablePlan)->_A:self._write('Starting plan',plan.plan_id)
	def stop_plan_evaluation(self)->_A:self._write('Stopping plan')
	def start_evaluation_progress(self,batched_intervals:t.Dict[Snapshot,Intervals],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],audit_only:bool=_C)->_A:message='evaluation'if not audit_only else'auditing';self._write(f"Starting {message} for {sum(len(intervals)for intervals in batched_intervals.values())} snapshots")
	def start_snapshot_evaluation_progress(self,snapshot:Snapshot,audit_only:bool=_C)->_A:self._write(f"{_Z if not audit_only else _R} {snapshot.name}")
	def update_snapshot_evaluation_progress(self,snapshot:Snapshot,interval:Interval,batch_idx:int,duration_ms:t.Optional[int],num_audits_passed:int,num_audits_failed:int,audit_only:bool=_C,execution_stats:t.Optional[QueryExecutionStats]=_A,auto_restatement_triggers:t.Optional[t.List[SnapshotId]]=_A)->_A:
		message=f"Evaluated {snapshot.name} | batch={batch_idx} | duration={duration_ms}ms | num_audits_passed={num_audits_passed} | num_audits_failed={num_audits_failed}"
		if auto_restatement_triggers:message+=f" | auto_restatement_triggers=[{_G.join(trigger.name for trigger in auto_restatement_triggers)}]"
		if audit_only:message=f"Audited {snapshot.name} | duration={duration_ms}ms | num_audits_passed={num_audits_passed} | num_audits_failed={num_audits_failed}"
		self._write(message)
	def stop_evaluation_progress(self,success:bool=_B)->_A:self._write(f"Stopping evaluation with success={success}")
	def start_creation_progress(self,snapshots:t.List[Snapshot],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:self._write(f"Starting creation for {len(snapshots)} snapshots")
	def update_creation_progress(self,snapshot:SnapshotInfoLike)->_A:self._write(f"Creating {snapshot.name}")
	def stop_creation_progress(self,success:bool=_B)->_A:self._write(f"Stopping creation with success={success}")
	def update_cleanup_progress(self,object_name:str)->_A:self._write(f"Cleaning up {object_name}")
	def start_promotion_progress(self,snapshots:t.List[SnapshotTableInfo],environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str])->_A:
		if snapshots:self._write(f"Starting promotion for {len(snapshots)} snapshots")
	def update_promotion_progress(self,snapshot:SnapshotInfoLike,promoted:bool)->_A:self._write(f"Promoting {snapshot.name}")
	def stop_promotion_progress(self,success:bool=_B)->_A:self._write(f"Stopping promotion with success={success}")
	def start_snapshot_migration_progress(self,total_tasks:int)->_A:self._write(f"Starting migration for {total_tasks} snapshots")
	def update_snapshot_migration_progress(self,num_tasks:int)->_A:self._write(f"Migration {num_tasks}")
	def log_migration_status(self,success:bool=_B)->_A:self._write(f"Migration finished with success={success}")
	def stop_snapshot_migration_progress(self,success:bool=_B)->_A:self._write(f"Stopping snapshot migration with success={success}")
	def start_env_migration_progress(self,total_tasks:int)->_A:self._write(f"Starting migration for {total_tasks} environments")
	def update_env_migration_progress(self,num_tasks:int)->_A:self._write(f"Environment migration {num_tasks}")
	def stop_env_migration_progress(self,success:bool=_B)->_A:self._write(f"Stopping environment migration with success={success}")
	def show_environment_difference_summary(self,context_diff:ContextDiff,no_diff:bool=_B)->_A:
		self._write('Environment Difference Summary:')
		if context_diff.has_requirement_changes:self._write(f"Requirements:\n{context_diff.requirements_diff()}")
		if context_diff.has_environment_statements_changes and not no_diff:
			self._write('Environment statements:\n')
			for(_,diff)in context_diff.environment_statements_diff(include_python_env=not context_diff.is_new_environment):self._write(diff)
	def show_model_difference_summary(self,context_diff:ContextDiff,environment_naming_info:EnvironmentNamingInfo,default_catalog:t.Optional[str],no_diff:bool=_B)->_A:
		self._write('Model Difference Summary:')
		for added in context_diff.new_snapshots:self._write(f"  Added: {added}")
		for removed in context_diff.removed_snapshots:self._write(f"  Removed: {removed}")
		for modified in context_diff.modified_snapshots:self._write(f"  Modified: {modified}")
	def log_test_results(self,result:ModelTextTestResult,target_dialect:str)->_A:self._write('Test Results:',result)
	def show_sql(self,sql:str)->_A:self._write(sql)
	def log_status_update(self,message:str)->_A:self._write(message,style='bold blue')
	def log_error(self,message:str)->_A:self._write(rebrand(message),style='bold red')
	def log_warning(self,short_message:str,long_message:t.Optional[str]=_A)->_A:
		short_message=rebrand(short_message);long_message=rebrand(long_message);logger.warning(long_message or short_message)
		if not self.ignore_warnings:self._write(short_message,style='bold yellow')
	def log_success(self,message:str)->_A:self._write(message,style='bold green')
	def loading_start(self,message:t.Optional[str]=_A)->uuid.UUID:self._write(message);return uuid.uuid4()
	def loading_stop(self,id:uuid.UUID)->_A:self._write('Done')
	def show_schema_diff(self,schema_diff:SchemaDiff)->_A:self._write(schema_diff)
	def show_row_diff(self,row_diff:RowDiff,show_sample:bool=_B,skip_grain_check:bool=_C)->_A:self._write(row_diff)
	def show_table_diff(self,table_diffs:t.List[TableDiff],show_sample:bool=_B,skip_grain_check:bool=_C,temp_schema:t.Optional[str]=_A)->_A:
		for table_diff in table_diffs:self.show_table_diff_summary(table_diff);self.show_schema_diff(table_diff.schema_diff());self.show_row_diff(table_diff.row_diff(temp_schema=temp_schema,skip_grain_check=skip_grain_check),show_sample=show_sample,skip_grain_check=skip_grain_check)
	def update_table_diff_progress(self,model:str)->_A:self._write(f"Finished table diff for: {model}")
	def start_table_diff_progress(self,models_to_diff:int)->_A:self._write('Table diff started')
	def start_table_diff_model_progress(self,model:str)->_A:self._write(f"Calculating differences for: {model}")
	def stop_table_diff_progress(self,success:bool)->_A:self._write(f"Table diff finished with success={success}")
	def show_table_diff_details(self,models_to_diff:t.List[str])->_A:
		if models_to_diff:models=_D.join(models_to_diff);self._write(f"Models to compare: {models}")
	def show_table_diff_summary(self,table_diff:TableDiff)->_A:
		if table_diff.model_name:self._write(f"Model: {table_diff.model_name}");self._write(f"Source env: {table_diff.source_alias}");self._write(f"Target env: {table_diff.target_alias}")
		self._write(f"Source table: {table_diff.source}");self._write(f"Target table: {table_diff.target}");_,_,key_column_names=table_diff.key_columns;keys=_G.join(key_column_names);self._write(f"Join On: {keys}")
_CONSOLE:Console=NoopConsole()
def set_console(console:Console)->_A:global _CONSOLE;_CONSOLE=console
def configure_console(**kwargs:t.Any)->_A:global _CONSOLE;_CONSOLE=create_console(**kwargs)
def get_console()->Console:
	global _CONSOLE;from vulcan.core.activity import ActivityCapturingConsoleWrapper
	if not isinstance(_CONSOLE,ActivityCapturingConsoleWrapper):_CONSOLE=ActivityCapturingConsoleWrapper(_CONSOLE)
	return _CONSOLE
def create_console(**kwargs:t.Any)->TerminalConsole|DatabricksMagicConsole|NotebookMagicConsole:
	from vulcan import RuntimeEnv;runtime_env=RuntimeEnv.get();runtime_env_mapping={RuntimeEnv.DATABRICKS:DatabricksMagicConsole,RuntimeEnv.JUPYTER:NotebookMagicConsole,RuntimeEnv.TERMINAL:TerminalConsole,RuntimeEnv.GOOGLE_COLAB:NotebookMagicConsole,RuntimeEnv.DEBUGGER:DebuggerTerminalConsole,RuntimeEnv.CI:MarkdownConsole};rich_console_kwargs:t.Dict[str,t.Any]={'theme':srich.theme}
	if runtime_env.is_jupyter or runtime_env.is_google_colab:rich_console_kwargs['force_jupyter']=_B
	return runtime_env_mapping[runtime_env](**{**{_i:RichConsole(**rich_console_kwargs)},**kwargs})
def _format_missing_intervals(snapshot:Snapshot,missing:SnapshotIntervals)->str:return missing.format_intervals(snapshot.node.interval_unit)if snapshot.is_incremental else _j if snapshot.is_view else'full refresh'
def _format_node_errors(errors:t.List[NodeExecutionFailedError])->t.Dict[str,str]:
	def _format_node_error(ex:NodeExecutionFailedError)->str:
		cause=ex.__cause__ if ex.__cause__ else ex;error_msg=str(cause)
		if isinstance(cause,NodeAuditsErrors):error_msg=_format_audits_errors(cause)
		elif not isinstance(cause,(NodeExecutionFailedError,PythonModelEvalError)):error_msg=_N+error_msg.replace(_D,_H);error_msg=f"  {cause.__class__.__name__}:\n{error_msg}"
		error_msg=error_msg.replace(_D,_H);error_msg=error_msg+_D if not error_msg.rstrip(' ').endswith(_D)else error_msg;return error_msg
	error_messages={};num_fails=len(errors)
	for(i,error)in enumerate(errors):
		node_name=''
		if isinstance(error.node,SnapshotId):node_name=error.node.name
		elif hasattr(error.node,'snapshot_name'):node_name=error.node.snapshot_name
		msg=_format_node_error(error);msg=_N+msg.replace(_D,_H)
		if i==num_fails-1:msg=msg if msg.rstrip(' ').endswith(_D)else msg+_D
		error_messages[node_name]=msg
	return error_messages
def _format_audits_errors(error:NodeAuditsErrors)->str:
	error_messages=[]
	for err in error.errors:
		audit_args_sql=[]
		for(arg_name,arg_value)in err.audit_args.items():audit_args_sql.append(f"{arg_name} := {arg_value.sql(dialect=err.adapter_dialect)}")
		audit_args_sql_msg=_D.join(audit_args_sql)+_K if audit_args_sql else'';err_msg=f"'{err.audit_name}' audit error: {err.count} {'row'if err.count==1 else'rows'} failed";query_sql=err.sql(err.adapter_dialect);formatted_query=format_sql_for_display(query_sql,dialect=err.adapter_dialect,max_text_width=LINE_WRAP_WIDTH);query=_H.join(formatted_query.split(_D));msg=f"""{err_msg}

Audit arguments
  {audit_args_sql_msg}Audit query
  {query}

""";msg=msg.replace(_D,_H);error_messages.append(msg)
	return _N+_D.join(error_messages)
def _format_interval(snapshot:Snapshot,interval:Interval)->str:
	B='%Y-%m-%d %H:%M:%S';A='%H:%M:%S';inclusive_interval=make_inclusive(interval[0],interval[1])
	if snapshot.model.interval_unit.is_date_granularity:return f"{to_ds(inclusive_interval[0])} - {to_ds(inclusive_interval[1])}"
	if inclusive_interval[0].date()==inclusive_interval[1].date():return f"{to_ds(inclusive_interval[0])} {inclusive_interval[0].strftime(A)}-{inclusive_interval[1].strftime(A)}"
	return f"{inclusive_interval[0].strftime(B)} - {inclusive_interval[1].strftime(B)}"
def _format_signal_interval(snapshot:Snapshot,interval:Interval)->str:return _format_interval(snapshot,interval)
def _format_evaluation_model_interval(snapshot:Snapshot,interval:Interval)->str:
	if snapshot.is_model and(snapshot.model.kind.is_incremental or snapshot.model.kind.is_managed or snapshot.model.kind.is_custom):formatted_interval=_format_interval(snapshot,interval);return f"insert {formatted_interval}"
	return''
def _create_evaluation_model_annotation(snapshot:Snapshot,interval_info:t.Optional[str],execution_stats:t.Optional[QueryExecutionStats])->str:
	annotation=_A;execution_stats_str=''
	if execution_stats:
		rows_processed=execution_stats.total_rows_processed
		if rows_processed:rows_processed_str=metric(rows_processed).replace('.00','').replace('.0','');execution_stats_str+=f"{rows_processed_str} row{'s'if rows_processed>1 else''}"
		bytes_processed=execution_stats.total_bytes_processed;execution_stats_str+=f"{_G if execution_stats_str else''}{naturalsize(bytes_processed,binary=_B)}"if bytes_processed else''
	execution_stats_str=f" ({execution_stats_str})"if execution_stats_str else''
	if snapshot.is_audit:annotation='run standalone audit'
	if snapshot.is_model:
		if snapshot.model.kind.is_external:annotation='run external audits'
		if snapshot.model.kind.is_view:annotation=_j
		if snapshot.model.kind.is_seed:annotation=f"insert seed file{execution_stats_str}"
		if snapshot.model.kind.is_full:annotation=f"full refresh{execution_stats_str}"
		if snapshot.model.kind.is_incremental_by_unique_key:annotation=f"insert/update rows{execution_stats_str}"
		if snapshot.model.kind.is_incremental_by_partition:annotation=f"insert partitions{execution_stats_str}"
	if annotation:return annotation
	return f"{interval_info}{execution_stats_str}"if interval_info else''
def _calculate_interval_str_len(snapshot:Snapshot,intervals:t.List[Interval],execution_stats:t.Optional[QueryExecutionStats]=_A)->int:
	interval_str_len=0
	for interval in intervals:interval_str_len=max(interval_str_len,len(_create_evaluation_model_annotation(snapshot,_format_evaluation_model_interval(snapshot,interval),execution_stats)))
	return interval_str_len
def _calculate_audit_str_len(snapshot:Snapshot,audit_padding:int=0)->int:
	A='blocking';audit_str_len=0;audit_base_str_len=len(f", audits ")+1
	if snapshot.is_audit:audit_str_len=max(audit_str_len,audit_base_str_len+(2 if not snapshot.audit.blocking else 1))
	if snapshot.is_model and snapshot.model.audits:
		num_audits=len(snapshot.model.audits_with_args);num_nonblocking_audits=sum(1 for audit in snapshot.model.audits_with_args if not audit[0].blocking or A in audit[1]and audit[1][A]==exp.false())
		if num_audits==1:audit_len=audit_base_str_len+(2 if num_nonblocking_audits else 1)+(audit_padding-1 if num_nonblocking_audits and audit_padding>0 else audit_padding)
		else:
			audit_len=audit_base_str_len+len(str(num_audits))+audit_padding
			if num_nonblocking_audits:audit_len+=len(str(num_nonblocking_audits))+2+(audit_padding-1 if audit_padding>0 else audit_padding)
		audit_str_len=max(audit_str_len,audit_len)
	return audit_str_len
def _calculate_annotation_str_len(batched_intervals:t.Dict[Snapshot,t.List[Interval]],audit_padding:int=0,execution_stats_len:int=0)->int:
	annotation_str_len=0
	for(snapshot,intervals)in batched_intervals.items():annotation_str_len=max(annotation_str_len,_calculate_interval_str_len(snapshot,intervals)+_calculate_audit_str_len(snapshot,audit_padding)+execution_stats_len)
	return annotation_str_len