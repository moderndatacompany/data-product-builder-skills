from __future__ import annotations
_L='Model name is not available in the macro evaluator.'
_K='runtime_stage'
_J='MacroEvaluator'
_I='loading'
_H='COALESCE'
_G='this_model'
_F='engine_adapter'
_E='SQL'
_D='this'
_C=True
_B=False
_A=None
import inspect,sys,types,typing as t
from enum import Enum
from functools import lru_cache,reduce
from itertools import chain
from pathlib import Path
from string import Template
from datetime import datetime,date
import sqlglot
from sqlglot import Generator,exp,parse_one
from sqlglot.executor.env import ENV
from sqlglot.executor.python import Python
from sqlglot.helper import csv,ensure_collection
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.schema import MappingSchema
from vulcan.core import constants as c
from vulcan.core.dialect import SQLMESH_MACRO_PREFIX,Dialect,MacroDef,MacroFunc,MacroSQL,MacroStrReplace,MacroVar,StagedFilePath,normalize_model_name
from vulcan.utils import DECORATOR_RETURN_TYPE,UniqueKeyDict,columns_to_types_all_known,registry_decorator
from vulcan.utils.date import DatetimeRanges,to_datetime,to_date
from vulcan.utils.errors import MacroEvalError,VulcanError
from vulcan.utils.metaprogramming import Executable,SqlValue,format_evaluated_code_exception,prepare_env
if t.TYPE_CHECKING:from sqlglot.dialects.dialect import DialectType;from vulcan.core._typing import TableName;from vulcan.core.engine_adapter import EngineAdapter;from vulcan.core.snapshot import Snapshot;from vulcan.core.environment import EnvironmentNamingInfo
if sys.version_info>=(3,10):UNION_TYPES=t.Union,types.UnionType
else:UNION_TYPES=t.Union,
class RuntimeStage(Enum):LOADING=_I;CREATING='creating';EVALUATING='evaluating';PROMOTING='promoting';DEMOTING='demoting';AUDITING='auditing';TESTING='testing';BEFORE_ALL='before_all';AFTER_ALL='after_all'
class MacroStrTemplate(Template):delimiter=SQLMESH_MACRO_PREFIX
EXPRESSIONS_NAME_MAP={}
SQL=t.NewType(_E,str)
@lru_cache()
def get_supported_types()->t.Dict[str,t.Any]:from vulcan.core.context import ExecutionContext;return{'t':t,'typing':t,'List':t.List,'Tuple':t.Tuple,'Union':t.Union,'DatetimeRanges':DatetimeRanges,'exp':exp,_E:SQL,_J:MacroEvaluator,'ExecutionContext':ExecutionContext}
for klass in sqlglot.Parser.EXPRESSION_PARSERS:name=klass if isinstance(klass,str)else klass.__name__;EXPRESSIONS_NAME_MAP[name.lower()]=name
def _macro_sql(sql:str,into:t.Optional[str]=_A)->str:
	args=[_macro_str_replace(sql)]
	if into in EXPRESSIONS_NAME_MAP:args.append(f"into=exp.{EXPRESSIONS_NAME_MAP[into]}")
	return f"self.parse_one({', '.join(args)})"
def _macro_func_sql(self:Generator,e:exp.Expression)->str:
	func=e.this
	if isinstance(func,exp.Anonymous):return f"""self.send({csv("'"+func.name+"'",self.expressions(func))})"""
	return self.sql(func)
def _macro_str_replace(text:str)->str:return f"self.template({text}, locals())"
class CaseInsensitiveMapping(t.Dict[str,t.Any]):
	def __init__(self,data:t.Dict[str,t.Any])->_A:super().__init__(data)
	def __getitem__(self,key:str)->t.Any:return super().__getitem__(key.lower())
	def get(self,key:str,default:t.Any=_A)->t.Any:return super().get(key.lower(),default)
class MacroDialect(Python):
	class Generator(Python.Generator):TRANSFORMS={**Python.Generator.TRANSFORMS,exp.Column:lambda self,e:f"exp.to_column('{self.sql(e,_D)}')",exp.Lambda:lambda self,e:f"lambda {self.expressions(e)}: {self.sql(e,_D)}",MacroFunc:_macro_func_sql,MacroSQL:lambda self,e:_macro_sql(self.sql(e,_D),e.args.get('into')),MacroStrReplace:lambda self,e:_macro_str_replace(self.sql(e,_D))}
class MacroEvaluator:
	def __init__(self,dialect:DialectType='',python_env:t.Optional[t.Dict[str,Executable]]=_A,schema:t.Optional[MappingSchema]=_A,runtime_stage:RuntimeStage=RuntimeStage.LOADING,resolve_table:t.Optional[t.Callable[[str|exp.Table],str]]=_A,resolve_tables:t.Optional[t.Callable[[exp.Expression],exp.Expression]]=_A,snapshots:t.Optional[t.Dict[str,Snapshot]]=_A,default_catalog:t.Optional[str]=_A,path:t.Optional[Path]=_A,environment_naming_info:t.Optional[EnvironmentNamingInfo]=_A,model_fqn:t.Optional[str]=_A):
		self.dialect=dialect;self.generator=MacroDialect().generator();(self.locals):t.Dict[str,t.Any]={_K:runtime_stage.value,'default_catalog':default_catalog};self.env={**ENV,'self':self,_E:SQL,_J:MacroEvaluator};self.python_env=python_env or{};self.macros={normalize_macro_name(k):v.func for(k,v)in macro.get_registry().items()};self.columns_to_types_called=_B;self.default_catalog=default_catalog;self._schema=schema;self._resolve_table=resolve_table;self._resolve_tables=resolve_tables;self._snapshots=snapshots if snapshots is not _A else{};self._path=path;self._environment_naming_info=environment_naming_info;self._model_fqn=model_fqn;prepare_env(self.python_env,self.env)
		for(k,v)in self.python_env.items():
			if v.is_definition:self.macros[normalize_macro_name(k)]=self.env[v.name or k]
			elif v.is_import and getattr(self.env.get(k),c.SQLMESH_MACRO,_A):self.macros[normalize_macro_name(k)]=self.env[k]
			elif v.is_value:
				value=self.env[k]
				if k in(c.SQLMESH_VARS,c.SQLMESH_VARS_METADATA,c.SQLMESH_BLUEPRINT_VARS,c.SQLMESH_BLUEPRINT_VARS_METADATA):value={var_name:self.parse_one(var_value.sql)if isinstance(var_value,SqlValue)else var_value for(var_name,var_value)in value.items()}
				self.locals[k]=value
	def send(self,name:str,*args:t.Any,**kwargs:t.Any)->t.Union[_A,exp.Expression,t.List[exp.Expression]]:
		func=self.macros.get(normalize_macro_name(name))
		if not callable(func):raise MacroEvalError(f"Macro '{name}' does not exist.")
		try:return call_macro(func,self.dialect,self._path,provided_args=(self,*args),provided_kwargs=kwargs)
		except Exception as e:raise MacroEvalError(f"An error occurred during evaluation of '{name}'\n\n"+format_evaluated_code_exception(e,self.python_env))
	def transform(self,expression:exp.Expression)->exp.Expression|t.List[exp.Expression]|_A:
		changed=_B
		def evaluate_macros(node:exp.Expression)->exp.Expression|t.List[exp.Expression]|_A:
			nonlocal changed
			if isinstance(node,MacroVar):
				changed=_C;variables=self.variables;var_name=node.name.lower()
				if var_name not in self.locals and var_name not in variables:
					if not isinstance(node.parent,StagedFilePath):raise VulcanError(f"Macro variable '{node.name}' is undefined.")
					return node
				value=self.locals.get(var_name,variables.get(var_name))
				if isinstance(value,list):return exp.convert(tuple(self.transform(v)if isinstance(v,exp.Expression)else v for v in value))
				return exp.convert(self.transform(value)if isinstance(value,exp.Expression)else value)
			if isinstance(node,exp.Identifier)and'@'in node.this:
				text=self.template(node.this,{})
				if node.this!=text:changed=_C;return exp.to_identifier(text,quoted=node.quoted or _A)
			if isinstance(node,MacroFunc):changed=_C;return self.evaluate(node)
			return node
		transformed=exp.replace_tree(expression.copy(),evaluate_macros,prune=lambda n:isinstance(n,exp.Lambda))
		if changed:
			if isinstance(transformed,list):return[self.parse_one(node.sql(dialect=self.dialect,copy=_B))for node in transformed]
			if isinstance(transformed,exp.Expression):return self.parse_one(transformed.sql(dialect=self.dialect,copy=_B))
		return transformed
	def template(self,text:t.Any,local_variables:t.Dict[str,t.Any])->str:base_mapping={k.lower():convert_sql(v,self.dialect)for(k,v)in chain(self.variables.items(),self.locals.items(),local_variables.items())if k.lower()not in(_F,'snapshot')};return MacroStrTemplate(str(text)).safe_substitute(CaseInsensitiveMapping(base_mapping))
	def evaluate(self,node:MacroFunc)->exp.Expression|t.List[exp.Expression]|_A:
		if isinstance(node,MacroDef):
			if isinstance(node.expression,exp.Lambda):_,fn=_norm_var_arg_lambda(self,node.expression);self.macros[normalize_macro_name(node.name)]=lambda _,*args:fn(args[0]if len(args)==1 else exp.Tuple(expressions=list(args)))
			else:self.locals[node.name.lower()]=self.transform(node.expression)
			return node
		if isinstance(node,(MacroSQL,MacroStrReplace)):result:t.Optional[exp.Expression|t.List[exp.Expression]]=exp.convert(self.eval_expression(node))
		else:
			func=t.cast(exp.Anonymous,node.this);args=[];kwargs={}
			for e in func.expressions:
				if isinstance(e,exp.PropertyEQ):kwargs[e.this.name]=e.expression
				else:
					if kwargs:raise MacroEvalError(f"Positional argument cannot follow keyword argument.\n  {func.sql(dialect=self.dialect)} at '{self._path}'")
					args.append(e)
			result=self.send(func.name,*args,**kwargs)
		if result is _A:return
		if isinstance(result,(tuple,list)):
			result=[self.parse_one(item)for item in result if item is not _A]
			if len(result)==1 and isinstance(result[0],(exp.Array,exp.Tuple))and node.find_ancestor(MacroFunc):result=[exp.Array(expressions=result)]
		else:result=self.parse_one(result)
		return result
	def eval_expression(self,node:t.Any)->t.Any:
		if not isinstance(node,exp.Expression):return node
		code=node.sql()
		try:code=self.generator.generate(node);return eval(code,self.env,self.locals)
		except Exception as e:raise MacroEvalError(f"""Error trying to eval macro.

Generated code: {code}

Original sql: {node}

"""+format_evaluated_code_exception(e,self.python_env))
	def parse_one(self,sql:str|exp.Expression,into:t.Optional[exp.IntoType]=_A,**opts:t.Any)->exp.Expression:return sqlglot.maybe_parse(sql,dialect=self.dialect,into=into,**opts)
	def columns_to_types(self,model_name:TableName|exp.Column)->t.Dict[str,exp.DataType]:
		if(self._schema is _A or self._schema.empty)and self.runtime_stage==_I:self.columns_to_types_called=_C;return{'__schema_unavailable_at_load__':exp.DataType.build('unknown')}
		normalized_model_name=normalize_model_name(model_name,default_catalog=self.default_catalog,dialect=self.dialect);model_name=exp.to_table(normalized_model_name);columns_to_types=self._schema.find(model_name,ensure_data_types=_C)if self._schema else _A
		if columns_to_types is _A:
			snapshot=self.get_snapshot(model_name)
			if snapshot and snapshot.node.is_model:columns_to_types=snapshot.node.columns_to_types
		if columns_to_types is _A:raise VulcanError(f"Schema for model '{model_name}' can't be statically determined.")
		return columns_to_types
	def get_snapshot(self,model_name:TableName|exp.Column)->t.Optional[Snapshot]:return self._snapshots.get(normalize_model_name(model_name,default_catalog=self.default_catalog,dialect=self.dialect))
	def resolve_table(self,table:str|exp.Table)->str:
		if not self._resolve_table:raise VulcanError('Macro evaluator not properly initialized with resolve_table lambda.')
		return self._resolve_table(table)
	def resolve_tables(self,query:exp.Expression)->exp.Expression:
		if not self._resolve_tables:raise VulcanError('Macro evaluator not properly initialized with resolve_tables lambda.')
		return self._resolve_tables(query)
	@property
	def runtime_stage(self)->RuntimeStage:return self.locals[_K]
	@property
	def this_model(self)->str:
		this_model=self.locals.get(_G)
		if not this_model:raise VulcanError(_L)
		return this_model.sql(dialect=self.dialect,identify=_C,comments=_B)
	@property
	def this_model_fqn(self)->str:
		if self._model_fqn is _A:raise VulcanError(_L)
		return self._model_fqn
	@property
	def engine_adapter(self)->EngineAdapter:
		engine_adapter=self.locals.get(_F)
		if not engine_adapter:raise VulcanError("The engine adapter is not available while models are loading. You can gate these calls by checking in Python: evaluator.runtime_stage != 'loading' or SQL: @runtime_stage <> 'loading'.")
		return self.locals[_F]
	@property
	def gateway(self)->t.Optional[str]:return self.var(c.GATEWAY)
	@property
	def snapshots(self)->t.Dict[str,Snapshot]:return self._snapshots
	@property
	def this_env(self)->str:
		A='this_env'
		if A not in self.locals:raise VulcanError('Environment name is only available in before_all and after_all')
		return self.locals[A]
	@property
	def schemas(self)->t.List[str]:
		A='schemas'
		if A not in self.locals:raise VulcanError('Schemas are only available in before_all and after_all')
		return self.locals[A]
	@property
	def views(self)->t.List[str]:
		A='views'
		if A not in self.locals:raise VulcanError('Views are only available in before_all and after_all')
		return self.locals[A]
	def var(self,var_name:str,default:t.Optional[t.Any]=_A)->t.Optional[t.Any]:return{**(self.locals.get(c.SQLMESH_VARS)or{}),**(self.locals.get(c.SQLMESH_VARS_METADATA)or{})}.get(var_name.lower(),default)
	def blueprint_var(self,var_name:str,default:t.Optional[t.Any]=_A)->t.Optional[t.Any]:return{**(self.locals.get(c.SQLMESH_BLUEPRINT_VARS)or{}),**(self.locals.get(c.SQLMESH_BLUEPRINT_VARS_METADATA)or{})}.get(var_name.lower(),default)
	@property
	def variables(self)->t.Dict[str,t.Any]:return{**self.locals.get(c.SQLMESH_VARS,{}),**self.locals.get(c.SQLMESH_VARS_METADATA,{}),**self.locals.get(c.SQLMESH_BLUEPRINT_VARS,{}),**self.locals.get(c.SQLMESH_BLUEPRINT_VARS_METADATA,{})}
	def _coerce(self,expr:exp.Expression,typ:t.Any,strict:bool=_B)->t.Any:return _coerce(expr,typ,self.dialect,self._path,strict)
class macro(registry_decorator):
	registry_name='macros'
	def __init__(self,*args:t.Any,metadata_only:bool=_B,**kwargs:t.Any)->_A:super().__init__(*args,**kwargs);self.metadata_only=metadata_only
	def __call__(self,func:t.Callable[...,DECORATOR_RETURN_TYPE])->t.Callable[...,DECORATOR_RETURN_TYPE]:
		if self.metadata_only:setattr(func,c.SQLMESH_METADATA,self.metadata_only)
		wrapper=super().__call__(func);setattr(wrapper,c.SQLMESH_MACRO,_C);return wrapper
ExecutableOrMacro=t.Union[Executable,macro]
MacroRegistry=UniqueKeyDict[str,ExecutableOrMacro]
def _norm_var_arg_lambda(evaluator:MacroEvaluator,func:exp.Lambda,*items:t.Any)->t.Tuple[t.Iterable,t.Callable]:
	def substitute(node:exp.Expression,args:t.Dict[str,exp.Expression])->exp.Expression|t.List[exp.Expression]|_A:
		if isinstance(node,(exp.Identifier,exp.Var)):
			if not isinstance(node.parent,exp.Column):
				name=node.name.lower()
				if name in args:return args[name].copy()
				if name in evaluator.locals:return exp.convert(evaluator.locals[name])
			if SQLMESH_MACRO_PREFIX in node.name:return node.__class__(this=evaluator.template(node.name,{k:v.name for(k,v)in args.items()}))
		elif isinstance(node,MacroFunc):local_copy=evaluator.locals.copy();evaluator.locals.update(args);result=evaluator.transform(node);evaluator.locals=local_copy;return result
		return node
	if len(items)==1:item=items[0];expressions=item.expressions if isinstance(item,(exp.Array,exp.Tuple))else[item.this]if isinstance(item,exp.Paren)else item
	else:expressions=items
	if not callable(func):return expressions,lambda args:func.this.transform(substitute,{expression.name.lower():arg for(expression,arg)in zip(func.expressions,args.expressions if isinstance(args,exp.Tuple)else[args])})
	return expressions,func
@macro()
def each(evaluator:MacroEvaluator,*args:t.Any)->t.List[t.Any]:*items,func=args;items,func=_norm_var_arg_lambda(evaluator,func,*items);return[item for item in map(func,ensure_collection(items))if item is not _A]
@macro('IF')
def if_(evaluator:MacroEvaluator,condition:t.Any,true:t.Any,false:t.Any=_A)->t.Any:
	if evaluator.eval_expression(condition):return true
	return false
@macro('REDUCE')
def reduce_(evaluator:MacroEvaluator,*args:t.Any)->t.Any:*items,func=args;items,func=_norm_var_arg_lambda(evaluator,func,*items);return reduce(lambda a,b:func(exp.Tuple(expressions=[a,b])),ensure_collection(items))
@macro('FILTER')
def filter_(evaluator:MacroEvaluator,*args:t.Any)->t.List[t.Any]:*items,func=args;items,func=_norm_var_arg_lambda(evaluator,func,*items);return list(filter(lambda arg:evaluator.eval_expression(func(arg)),items))
def _optional_expression(evaluator:MacroEvaluator,condition:exp.Condition,expression:exp.Expression)->t.Optional[exp.Expression]:return expression if evaluator.eval_expression(condition)else _A
with_=macro('WITH')(_optional_expression)
join=macro('JOIN')(_optional_expression)
where=macro('WHERE')(_optional_expression)
group_by=macro('GROUP_BY')(_optional_expression)
having=macro('HAVING')(_optional_expression)
order_by=macro('ORDER_BY')(_optional_expression)
limit=macro('LIMIT')(_optional_expression)
@macro('eval')
def eval_(evaluator:MacroEvaluator,condition:exp.Condition)->t.Any:return evaluator.eval_expression(condition)
@macro()
def star(evaluator:MacroEvaluator,relation:exp.Table,alias:exp.Column=t.cast(exp.Column,exp.column('')),exclude:t.Union[exp.Array,exp.Tuple]=exp.Tuple(expressions=[]),prefix:exp.Literal=exp.Literal.string(''),suffix:exp.Literal=exp.Literal.string(''),quote_identifiers:exp.Boolean=exp.true(),except_:t.Union[exp.Array,exp.Tuple]=exp.Tuple(expressions=[]))->t.List[exp.Alias]:
	if alias and not isinstance(alias,(exp.Identifier,exp.Column)):raise VulcanError(f"Invalid alias '{alias}'. Expected an identifier.")
	if exclude and not isinstance(exclude,(exp.Array,exp.Tuple)):raise VulcanError(f"Invalid exclude '{exclude}'. Expected an array.")
	if except_!=exp.tuple_():
		from vulcan.core.console import get_console;get_console().log_warning("The 'except_' argument in @STAR will soon be deprecated. Use 'exclude' instead.")
		if not isinstance(exclude,(exp.Array,exp.Tuple)):raise VulcanError(f"Invalid exclude_ '{exclude}'. Expected an array.")
	if prefix and not isinstance(prefix,exp.Literal):raise VulcanError(f"Invalid prefix '{prefix}'. Expected a literal.")
	if suffix and not isinstance(suffix,exp.Literal):raise VulcanError(f"Invalid suffix '{suffix}'. Expected a literal.")
	if not isinstance(quote_identifiers,exp.Boolean):raise VulcanError(f"Invalid quote_identifiers '{quote_identifiers}'. Expected a boolean.")
	excluded_names={normalize_identifiers(excluded,dialect=evaluator.dialect).name for excluded in exclude.expressions or except_.expressions};quoted=quote_identifiers.this;table_identifier=normalize_identifiers(alias if alias.name else relation,dialect=evaluator.dialect).name;columns_to_types={k:v for(k,v)in evaluator.columns_to_types(relation).items()if k not in excluded_names}
	if columns_to_types_all_known(columns_to_types):return[exp.cast(exp.column(column,table=table_identifier,quoted=quoted),dtype,dialect=evaluator.dialect).as_(f"{prefix.this}{column}{suffix.this}",quoted=quoted)for(column,dtype)in columns_to_types.items()]
	return[exp.column(column,table=table_identifier,quoted=quoted).as_(f"{prefix.this}{column}{suffix.this}",quoted=quoted)for(column,type_)in columns_to_types.items()]
@macro()
def generate_surrogate_key(evaluator:MacroEvaluator,*fields:exp.Expression,hash_function:exp.Literal=exp.Literal.string('MD5'))->exp.Func:
	string_fields:t.List[exp.Expression]=[]
	for(i,field)in enumerate(fields):
		if i>0:string_fields.append(exp.Literal.string('|'))
		string_fields.append(exp.func(_H,exp.cast(field,exp.DataType.build('text')),exp.Literal.string('_vulcan_surrogate_key_null_')))
	func=exp.func(hash_function.name,exp.func('CONCAT',*string_fields),dialect=evaluator.dialect)
	if isinstance(func,exp.MD5Digest):func=exp.MD5(this=func.this)
	return func
@macro()
def safe_add(_:MacroEvaluator,*fields:exp.Expression)->exp.Case:return exp.Case().when(exp.and_(*(field.is_(exp.null())for field in fields)),exp.null()).else_(reduce(lambda a,b:a+b,[exp.func(_H,field,0)for field in fields]))
@macro()
def safe_sub(_:MacroEvaluator,*fields:exp.Expression)->exp.Case:return exp.Case().when(exp.and_(*(field.is_(exp.null())for field in fields)),exp.null()).else_(reduce(lambda a,b:a-b,[exp.func(_H,field,0)for field in fields]))
@macro()
def safe_div(_:MacroEvaluator,numerator:exp.Expression,denominator:exp.Expression)->exp.Div:return numerator/exp.func('NULLIF',denominator,0)
@macro()
def union(evaluator:MacroEvaluator,*args:exp.Expression)->exp.Query:
	B='DISTINCT';A='ALL'
	if not args:raise VulcanError('At least one table is required for the @UNION macro.')
	arg_idx=0;condition=evaluator.eval_expression(args[arg_idx])
	if isinstance(condition,bool):
		arg_idx+=1
		if arg_idx>=len(args):raise VulcanError('Expected more arguments after the condition of the `@UNION` macro.')
	type_=exp.Literal.string(A)
	if isinstance(args[arg_idx],exp.Literal):type_=args[arg_idx];arg_idx+=1
	kind=type_.name.upper()
	if kind not in(A,B):raise VulcanError(f"Invalid type '{type_}'. Expected 'ALL' or 'DISTINCT'.")
	tables=[exp.to_table(e.sql(evaluator.dialect),dialect=evaluator.dialect)for e in args[arg_idx:]];columns={column for(column,_)in reduce(lambda a,b:a&b,(evaluator.columns_to_types(table).items()for table in tables))};projections=[exp.cast(column,type_,dialect=evaluator.dialect).as_(column)for(column,type_)in evaluator.columns_to_types(tables[0]).items()if column in columns]
	if condition==_B:return exp.select(*projections).from_(tables[0])
	return reduce(lambda a,b:a.union(b,distinct=kind==B),[exp.select(*projections).from_(t)for t in tables])
@macro()
def haversine_distance(_:MacroEvaluator,lat1:exp.Expression,lon1:exp.Expression,lat2:exp.Expression,lon2:exp.Expression,unit:exp.Literal=exp.Literal.string('mi'))->exp.Mul:
	D='COS';C='SIN';B='POWER';A='RADIANS'
	if unit.this=='mi':conversion_rate=1.
	elif unit.this=='km':conversion_rate=1.60934
	else:raise VulcanError(f"Invalid unit '{unit}'. Expected 'mi' or 'km'.")
	return 7922*exp.func('ASIN',exp.func('SQRT',exp.func(B,exp.func(C,exp.func(A,(lat2-lat1)/2)),2)+exp.func(D,exp.func(A,lat1))*exp.func(D,exp.func(A,lat2))*exp.func(B,exp.func(C,exp.func(A,(lon2-lon1)/2)),2)))*conversion_rate
@macro()
def pivot(evaluator:MacroEvaluator,column:SQL,values:t.List[exp.Expression],alias:bool=_C,agg:exp.Expression=exp.Literal.string('SUM'),cmp:exp.Expression=exp.Literal.string('='),prefix:exp.Expression=exp.Literal.string(''),suffix:exp.Expression=exp.Literal.string(''),then_value:SQL=SQL('1'),else_value:SQL=SQL('0'),quote:bool=_C,distinct:bool=_B)->t.List[exp.Expression]:
	aggregates:t.List[exp.Expression]=[]
	for value in values:
		proj=f"{agg.name}("
		if distinct:proj+='DISTINCT '
		proj+=f"CASE WHEN {column} {cmp.name} {value.sql(evaluator.dialect)} THEN {then_value} ELSE {else_value} END) ";node=evaluator.parse_one(proj)
		if alias:node=node.as_(f"{prefix.name}{value.name}{suffix.name}",quoted=quote,copy=_B,dialect=evaluator.dialect)
		aggregates.append(node)
	return aggregates
@macro('AND')
def and_(evaluator:MacroEvaluator,*expressions:t.Optional[exp.Expression])->exp.Condition:
	conditions=[e for e in expressions if not isinstance(e,exp.Null)]
	if not conditions:return exp.true()
	return exp.and_(*conditions,dialect=evaluator.dialect)
@macro('OR')
def or_(evaluator:MacroEvaluator,*expressions:t.Optional[exp.Expression])->exp.Condition:
	conditions=[e for e in expressions if not isinstance(e,exp.Null)]
	if not conditions:return exp.true()
	return exp.or_(*conditions,dialect=evaluator.dialect)
@macro('VAR')
def var(evaluator:MacroEvaluator,var_name:exp.Expression,default:t.Optional[exp.Expression]=_A)->exp.Expression:
	if not var_name.is_string:raise VulcanError(f"Invalid variable name '{var_name.sql()}'. Expected a string literal.")
	return exp.convert(evaluator.var(var_name.this,default))
@macro('BLUEPRINT_VAR')
def blueprint_var(evaluator:MacroEvaluator,var_name:exp.Expression,default:t.Optional[exp.Expression]=_A)->exp.Expression:
	if not var_name.is_string:raise VulcanError(f"Invalid blueprint variable name '{var_name.sql()}'. Expected a string literal.")
	return exp.convert(evaluator.blueprint_var(var_name.this,default))
@macro()
def deduplicate(evaluator:MacroEvaluator,relation:exp.Expression,partition_by:t.List[exp.Expression],order_by:t.List[str])->exp.Query:
	A="order_by must be a list of strings, optional - nulls ordering: ['<column> <asc|desc> nulls <first|last>']"
	if not isinstance(partition_by,list):raise VulcanError('partition_by must be a list of columns: [<column>, cast(<column> as <type>)]')
	if not isinstance(order_by,list):raise VulcanError(A)
	partition_clause=exp.tuple_(*partition_by);order_expressions=[evaluator.transform(parse_one(order_item,into=exp.Ordered,dialect=evaluator.dialect))for order_item in order_by]
	if not order_expressions:raise VulcanError(A)
	order_clause=exp.Order(expressions=order_expressions);window_function=exp.Window(this=exp.RowNumber(),partition_by=partition_clause,order=order_clause);first_unique_row=window_function.eq(1);query=exp.select('*').from_(relation).qualify(first_unique_row);return query
@macro()
def date_spine(evaluator:MacroEvaluator,datepart:exp.Expression,start_date:exp.Expression,end_date:exp.Expression)->exp.Select:
	D='DATE';C='%Y-%m-%d';B='quarter';A='month';datepart_name=datepart.name.lower()
	if datepart_name not in('day','week',A,B,'year'):raise VulcanError(f"Invalid datepart '{datepart_name}'. Expected: 'day', 'week', 'month', 'quarter', or 'year'")
	start_date_name=start_date.name;end_date_name=end_date.name
	try:
		if start_date.is_string and end_date.is_string:start_date_obj=datetime.strptime(start_date_name,C).date();end_date_obj=datetime.strptime(end_date_name,C).date()
		else:start_date_obj=_A;end_date_obj=_A
	except Exception as e:raise VulcanError(f"Invalid date format - start_date and end_date must be in format: YYYY-MM-DD. Error: {e}")
	if start_date_obj and end_date_obj:
		if start_date_obj>end_date_obj:raise VulcanError(f"Invalid date range - start_date '{start_date_name}' is after end_date '{end_date_name}'.")
		start_date=exp.cast(start_date,D);end_date=exp.cast(end_date,D)
	if datepart_name==B and evaluator.dialect in('spark','spark2','databricks','postgres'):date_interval=exp.Interval(this=exp.Literal.number(3),unit=exp.var(A))
	else:date_interval=exp.Interval(this=exp.Literal.number(1),unit=exp.var(datepart_name))
	generate_date_array=exp.func('GENERATE_DATE_ARRAY',start_date,end_date,date_interval);alias_name=f"date_{datepart_name}";exploded=exp.alias_(exp.func('unnest',generate_date_array),'_exploded',table=[alias_name]);return exp.select(alias_name).from_(exploded)
@macro()
def resolve_template(evaluator:MacroEvaluator,template:exp.Literal,mode:str='literal')->t.Union[exp.Literal,exp.Table]:
	if _G in evaluator.locals:
		this_model=exp.to_table(evaluator.locals[_G],dialect=evaluator.dialect);template_str:str=template.this;result=template_str.replace('@{catalog_name}',this_model.catalog).replace('@{schema_name}',this_model.db).replace('@{table_name}',this_model.name)
		if mode.lower()=='table':return exp.to_table(result,dialect=evaluator.dialect)
		return exp.Literal.string(result)
	if evaluator.runtime_stage!=RuntimeStage.LOADING.value:raise VulcanError('@this_model must be present in the macro evaluation context in order to use @resolve_template')
	return template
def normalize_macro_name(name:str)->str:return f"@{name.upper()}"
for m in macro.get_registry().values():setattr(m,c.SQLMESH_BUILTIN,_C)
def call_macro(func:t.Callable,dialect:DialectType,path:t.Optional[Path],provided_args:t.Tuple[t.Any,...],provided_kwargs:t.Dict[str,t.Any],**optional_kwargs:t.Any)->t.Any:
	sig=inspect.signature(func)
	if optional_kwargs:provided_kwargs=provided_kwargs.copy()
	for(k,v)in optional_kwargs.items():
		if k in sig.parameters:provided_kwargs[k]=v
	bound=sig.bind(*provided_args,**provided_kwargs);bound.apply_defaults()
	try:annotations=t.get_type_hints(func,localns=get_supported_types())
	except(NameError,TypeError):annotations={}
	if annotations:
		for(arg,value)in bound.arguments.items():
			typ=annotations.get(arg)
			if not typ:continue
			param=sig.parameters[arg]
			if param.kind is inspect.Parameter.VAR_POSITIONAL:bound.arguments[arg]=tuple(_coerce(v,typ,dialect,path)for v in value)
			elif param.kind is inspect.Parameter.VAR_KEYWORD:bound.arguments[arg]={k:_coerce(v,typ,dialect,path)for(k,v)in value.items()}
			else:bound.arguments[arg]=_coerce(value,typ,dialect,path)
	return func(*bound.args,**bound.kwargs)
def _coerce(expr:t.Any,typ:t.Any,dialect:DialectType,path:t.Optional[Path]=_A,strict:bool=_B)->t.Any:
	base_err_msg=f"Failed to coerce expression '{expr}' to type '{typ}'."
	try:
		if typ is _A or typ is t.Any or not isinstance(expr,exp.Expression):return expr
		base=t.get_origin(typ)or typ
		if base in UNION_TYPES:
			for branch in t.get_args(typ):
				try:return _coerce(expr,branch,dialect,path,strict=_C)
				except Exception:pass
			raise VulcanError(base_err_msg)
		if base is SQL and isinstance(expr,exp.Expression):return expr.sql(dialect)
		if base is t.Literal:
			if not isinstance(expr,(exp.Literal,exp.Boolean)):raise VulcanError(f"{base_err_msg} Coercion to {base} requires a literal expression.")
			literal_type_args=t.get_args(typ)
			try:
				for literal_type_arg in literal_type_args:
					expr_is_bool=isinstance(expr.this,bool);literal_is_bool=isinstance(literal_type_arg,bool)
					if expr_is_bool and literal_is_bool and literal_type_arg==expr.this or not expr_is_bool and not literal_is_bool and str(literal_type_arg)==str(expr.this):return type(literal_type_arg)(expr.this)
			except Exception:raise VulcanError(base_err_msg)
			raise VulcanError(base_err_msg)
		if isinstance(expr,base):return expr
		if issubclass(base,exp.Expression):
			d=Dialect.get_or_raise(dialect);into=base if base in d.parser_class.EXPRESSION_PARSERS else _A
			if into is _A:
				if isinstance(expr,exp.Literal):coerced=parse_one(expr.this)
				else:raise VulcanError(f"{base_err_msg} Coercion to {base} requires a literal expression.")
			else:coerced=parse_one(expr.this if isinstance(expr,exp.Literal)else expr.sql(),into=into)
			if isinstance(coerced,base):return coerced
			raise VulcanError(base_err_msg)
		if base in(int,float,str)and isinstance(expr,exp.Literal):return base(expr.this)
		if base is str and isinstance(expr,exp.Column)and not expr.table:return expr.name
		if base is bool and isinstance(expr,exp.Boolean):return expr.this
		if base is datetime and isinstance(expr,exp.Literal):return to_datetime(expr.this)
		if base is date and isinstance(expr,exp.Literal):return to_date(expr.this)
		if base is tuple and isinstance(expr,(exp.Tuple,exp.Array)):
			generic=t.get_args(typ)
			if not generic:return tuple(expr.expressions)
			if generic[-1]is...:return tuple(_coerce(expr,generic[0],dialect,path)for expr in expr.expressions)
			if len(generic)==len(expr.expressions):return tuple(_coerce(expr,generic[i],dialect,path)for(i,expr)in enumerate(expr.expressions))
			raise VulcanError(f"{base_err_msg} Expected {len(generic)} items.")
		if base is list and isinstance(expr,(exp.Array,exp.Tuple)):
			generic=t.get_args(typ)
			if not generic:return expr.expressions
			return[_coerce(expr,generic[0],dialect,path)for expr in expr.expressions]
		raise VulcanError(base_err_msg)
	except Exception:
		if strict:raise
		from vulcan.core.console import get_console;get_console().log_error(f"Coercion of expression '{expr}' to type '{typ}' failed. Using non coerced expression at '{path}'");return expr
def convert_sql(v:t.Any,dialect:DialectType)->t.Any:
	try:return _cache_convert_sql(v,dialect,v.__class__)
	except TypeError:return _convert_sql(v,dialect)
def _convert_sql(v:t.Any,dialect:DialectType)->t.Any:
	if not isinstance(v,str):
		try:v=exp.convert(v)
		except Exception:pass
	if isinstance(v,exp.Expression):
		if isinstance(v,exp.Column)and not v.table or(isinstance(v,exp.Identifier)or v.is_string):return v.name
		v=v.sql(dialect=dialect)
	return v
@lru_cache(maxsize=16384)
def _cache_convert_sql(v:t.Any,dialect:DialectType,t:type)->t.Any:return _convert_sql(v,dialect)