from __future__ import annotations
import re,typing as t
from pydantic import GetCoreSchemaHandler
from pydantic_core import core_schema
class Tag(str):
	ALLOWED_CHARS='a-zA-Z0-9.:_-';TAG_PATTERN=re.compile(f"^[{ALLOWED_CHARS}]+$")
	@classmethod
	def __get_pydantic_core_schema__(cls,source_type:type,handler:GetCoreSchemaHandler)->core_schema.CoreSchema:return core_schema.no_info_after_validator_function(cls._validate,core_schema.str_schema())
	@classmethod
	def _validate(cls,value:str)->str:
		if not isinstance(value,str):raise ValueError(f"Tag must be a string, got {type(value)}")
		value=value.strip()
		if not value:raise ValueError('Tag cannot be empty')
		if not cls.TAG_PATTERN.match(value):suggested=re.sub(f"[^{cls.ALLOWED_CHARS}]",'_',value);suggestion=f" (Hint: try '{suggested}')"if suggested!=value else'';raise ValueError(f"Invalid tag format: '{value}'. Tags must contain only alphanumeric characters, colons, hyphens, and underscores.{suggestion}")
		return cls(value)
class Term(str):
	ALLOWED_CHARS='a-zA-Z0-9._-';TERM_PATTERN=re.compile(f"^[{ALLOWED_CHARS}]+$")
	@classmethod
	def __get_pydantic_core_schema__(cls,source_type:type,handler:GetCoreSchemaHandler)->core_schema.CoreSchema:return core_schema.no_info_after_validator_function(cls._validate,core_schema.str_schema())
	@classmethod
	def _validate(cls,value:str)->str:
		if not isinstance(value,str):raise ValueError(f"Term must be a string, got {type(value)}")
		value=value.strip()
		if not value:raise ValueError('Term cannot be empty')
		if not cls.TERM_PATTERN.match(value):suggested=re.sub(f"[^{cls.ALLOWED_CHARS}]",'_',value);suggestion=f" (Hint: try '{suggested}')"if suggested!=value else'';raise ValueError(f"Invalid term format: '{value}'. Terms must contain only alphanumeric characters, dots, hyphens, and underscores.{suggestion}")
		return cls(value)