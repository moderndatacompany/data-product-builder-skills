from __future__ import annotations
_F='jinja_macros'
_E='macros'
_D='dialect'
_C='default_catalog'
_B='columns'
_A=None
import typing as t
from pathlib import Path
import inspect,re
from sqlglot import exp
from sqlglot.dialects.dialect import DialectType
from vulcan.core.config.common import VirtualEnvironmentMode
from vulcan.core.macros import MacroRegistry
from vulcan.core.signal import SignalRegistry
from vulcan.utils.jinja import JinjaMacroRegistry
from vulcan.core import constants as c
from vulcan.core.dialect import MacroFunc,parse_one
from vulcan.core.model.definition import Model,create_python_model,create_sql_model,create_models_from_blueprints,get_model_name,parse_defaults_properties,render_meta_fields,render_model_defaults
from vulcan.core.model.kind import ModelKindName,_ModelKind
from vulcan.utils import registry_decorator,DECORATOR_RETURN_TYPE
from vulcan.utils.errors import ConfigError,raise_config_error
from vulcan.utils.metaprogramming import build_env,serialize_env
if t.TYPE_CHECKING:from vulcan.core.audit import ModelAudit
class model(registry_decorator):
	registry_name='python_models';_dialect:DialectType=_A
	def __init__(self,name:t.Optional[str]=_A,is_sql:bool=False,**kwargs:t.Any)->_A:
		B='assertions';A='audits'
		if not is_sql and _B not in kwargs:raise ConfigError('Python model must define column schema.')
		self.name_provided=bool(name);self.name=name or'';self.is_sql=is_sql;self.kwargs=kwargs
		if B in self.kwargs:
			if A in self.kwargs:raise ConfigError("Cannot specify both 'audits' and 'assertions' - use one or the other")
			self.kwargs[A]=self.kwargs.pop(B)
		for function_call_attribute in(A,'signals'):calls=self.kwargs.pop(function_call_attribute,[]);self.kwargs[function_call_attribute]=[(call,{})if isinstance(call,str)else(call[0],{arg_key:exp.convert(tuple(arg_value)if isinstance(arg_value,list)else arg_value)for(arg_key,arg_value)in call[1].items()})for call in calls]
		if _C in kwargs:raise ConfigError('`default_catalog` cannot be set on a per-model basis.')
		self.columns={column_name:column_type if isinstance(column_type,exp.DataType)else exp.DataType.build(str(column_type),dialect=self.kwargs.get(_D,self._dialect))for(column_name,column_type)in self.kwargs.pop(_B,{}).items()}
	def __call__(self,func:t.Callable[...,DECORATOR_RETURN_TYPE])->t.Callable[...,DECORATOR_RETURN_TYPE]:
		if not self.name_provided:self.name=get_model_name(Path(inspect.getfile(func)))
		return super().__call__(func)
	def models(self,get_variables:t.Callable[[t.Optional[str]],t.Dict[str,str]],path:Path,module_path:Path,dialect:t.Optional[str]=_A,default_catalog_per_gateway:t.Optional[t.Dict[str,str]]=_A,**loader_kwargs:t.Any)->t.List[Model]:
		blueprints=self.kwargs.pop('blueprints',_A)
		if isinstance(blueprints,str):blueprints=parse_one(blueprints,dialect=dialect)
		if isinstance(blueprints,MacroFunc):
			from vulcan.core.model.definition import render_expression;blueprints=render_expression(expression=blueprints,module_path=module_path,macros=loader_kwargs.get(_E),jinja_macros=loader_kwargs.get(_F),variables=get_variables(_A),path=path,dialect=dialect,default_catalog=loader_kwargs.get(_C))
			if not blueprints:raise_config_error('Failed to render blueprints property',path)
			if len(blueprints)>1:blueprints=[exp.Tuple(expressions=blueprints)]
			blueprints=blueprints[0]
		return create_models_from_blueprints(gateway=self.kwargs.get('gateway'),blueprints=blueprints,get_variables=get_variables,loader=self.model,path=path,module_path=module_path,dialect=dialect,default_catalog_per_gateway=default_catalog_per_gateway,**loader_kwargs)
	def model(self,*,module_path:Path,path:Path,defaults:t.Optional[t.Dict[str,t.Any]]=_A,macros:t.Optional[MacroRegistry]=_A,jinja_macros:t.Optional[JinjaMacroRegistry]=_A,signal_definitions:t.Optional[SignalRegistry]=_A,audit_definitions:t.Optional[t.Dict[str,ModelAudit]]=_A,dialect:t.Optional[str]=_A,time_column_format:str=c.DEFAULT_TIME_COLUMN_FORMAT,physical_schema_mapping:t.Optional[t.Dict[re.Pattern,str]]=_A,project:str='',default_catalog:t.Optional[str]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,infer_names:t.Optional[bool]=False,blueprint_variables:t.Optional[t.Dict[str,t.Any]]=_A,virtual_environment_mode:VirtualEnvironmentMode=VirtualEnvironmentMode.default)->Model:
		A='name';env:t.Dict[str,t.Tuple[t.Any,t.Optional[bool]]]={};entrypoint=self.func.__name__
		if not self.name_provided and not infer_names:raise ConfigError('Python model must have a name.')
		kind=self.kwargs.get('kind',_A)
		if kind is not _A:
			if isinstance(kind,_ModelKind):from vulcan.core.console import get_console;get_console().log_warning(f'Python model "{self.name}"\'s `kind` argument was passed a Vulcan `{type(kind).__name__}` object. This may result in unexpected behavior - provide a dictionary instead.')
			elif isinstance(kind,dict):
				if A not in kind or not isinstance(kind.get(A),ModelKindName):raise ConfigError(f'Python model "{self.name}"\'s `kind` dictionary must contain a `name` key with a valid ModelKindName enum value.')
		build_env(self.func,env=env,name=entrypoint,path=module_path);rendered_fields=render_meta_fields(fields={A:self.name,**self.kwargs},module_path=module_path,macros=macros,jinja_macros=jinja_macros,variables=variables,path=path,dialect=dialect,default_catalog=default_catalog,blueprint_variables=blueprint_variables);rendered_name=rendered_fields[A]
		if isinstance(rendered_name,exp.Expression):rendered_fields[A]=rendered_name.sql(dialect=dialect)
		rendered_defaults=render_model_defaults(defaults=defaults,module_path=module_path,macros=macros,jinja_macros=jinja_macros,variables=variables,path=path,dialect=dialect,default_catalog=default_catalog)if defaults else{};rendered_defaults=parse_defaults_properties(rendered_defaults,dialect=dialect);common_kwargs={'defaults':rendered_defaults,'path':path,'time_column_format':time_column_format,'python_env':serialize_env(env,path=module_path),'physical_schema_mapping':physical_schema_mapping,'project':project,_C:default_catalog,'variables':variables,_D:dialect,_B:self.columns if self.columns else _A,'module_path':module_path,_E:macros,_F:jinja_macros,'audit_definitions':audit_definitions,'signal_definitions':signal_definitions,'blueprint_variables':blueprint_variables,'virtual_environment_mode':virtual_environment_mode,**rendered_fields}
		for key in('pre_statements','post_statements','on_virtual_update'):
			statements=common_kwargs.get(key)
			if statements:common_kwargs[key]=[parse_one(s,dialect=common_kwargs.get(_D))if isinstance(s,str)else s for s in statements]
		if self.is_sql:query=MacroFunc(this=exp.Anonymous(this=entrypoint));return create_sql_model(query=query,**common_kwargs)
		return create_python_model(entrypoint=entrypoint,**common_kwargs)
asset=model