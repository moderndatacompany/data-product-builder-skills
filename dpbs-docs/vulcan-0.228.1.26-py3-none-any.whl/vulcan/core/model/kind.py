from __future__ import annotations
_b='materialization_properties'
_a='adapter'
_Z='updated_at_name'
_Y='time_data_type'
_X='valid_to_name'
_W='valid_from_name'
_V='unique_key'
_U='merge_filter'
_T='when_matched'
_S='auto_restatement_intervals'
_R='lookback'
_Q='auto_restatement_cron'
_P='column'
_O='time_column'
_N='IGNORE'
_M='name'
_L='batch_concurrency'
_K='batch_size'
_J='on_destructive_change'
_I='on_additive_change'
_H='disable_restatement'
_G='materialization'
_F='forward_only'
_E='dialect'
_D='before'
_C=False
_B=True
_A=None
import typing as t
from enum import Enum
from typing_extensions import Self
from pydantic import Field
from sqlglot import exp
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from sqlglot.optimizer.qualify_columns import quote_identifiers
from sqlglot.optimizer.simplify import gen
from sqlglot.time import format_time
from vulcan.core import dialect as d
from vulcan.core.model.common import parse_properties,properties_validator,validate_extra_and_required_fields
from vulcan.core.model.seed import CsvSettings
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import PydanticModel,SQLGlotBool,SQLGlotColumn,SQLGlotListOfFieldsOrStar,SQLGlotListOfFields,SQLGlotPositiveInt,SQLGlotString,SQLGlotCron,ValidationInfo,column_validator,field_validator,get_dialect,validate_string,validate_expression
if t.TYPE_CHECKING:from vulcan.core._typing import CustomMaterializationProperties;MODEL_KIND=t.TypeVar('MODEL_KIND',bound='_ModelKind')
class ModelKindMixin:
	@property
	def model_kind_name(self)->t.Optional[ModelKindName]:raise NotImplementedError
	@property
	def is_incremental_by_time_range(self)->bool:return self.model_kind_name==ModelKindName.INCREMENTAL_BY_TIME_RANGE
	@property
	def is_incremental_by_unique_key(self)->bool:return self.model_kind_name==ModelKindName.INCREMENTAL_BY_UNIQUE_KEY
	@property
	def is_incremental_by_partition(self)->bool:return self.model_kind_name==ModelKindName.INCREMENTAL_BY_PARTITION
	@property
	def is_incremental_unmanaged(self)->bool:return self.model_kind_name==ModelKindName.INCREMENTAL_UNMANAGED
	@property
	def is_incremental(self)->bool:return self.is_incremental_by_time_range or self.is_incremental_by_unique_key or self.is_incremental_by_partition or self.is_incremental_unmanaged or self.is_scd_type_2
	@property
	def is_full(self)->bool:return self.model_kind_name==ModelKindName.FULL
	@property
	def is_view(self)->bool:return self.model_kind_name==ModelKindName.VIEW
	@property
	def is_embedded(self)->bool:return self.model_kind_name==ModelKindName.EMBEDDED
	@property
	def is_seed(self)->bool:return self.model_kind_name==ModelKindName.SEED
	@property
	def is_external(self)->bool:return self.model_kind_name==ModelKindName.EXTERNAL
	@property
	def is_scd_type_2(self)->bool:return self.model_kind_name in{ModelKindName.SCD_TYPE_2,ModelKindName.SCD_TYPE_2_BY_TIME,ModelKindName.SCD_TYPE_2_BY_COLUMN}
	@property
	def is_scd_type_2_by_time(self)->bool:return self.model_kind_name in{ModelKindName.SCD_TYPE_2,ModelKindName.SCD_TYPE_2_BY_TIME}
	@property
	def is_scd_type_2_by_column(self)->bool:return self.model_kind_name==ModelKindName.SCD_TYPE_2_BY_COLUMN
	@property
	def is_custom(self)->bool:return self.model_kind_name==ModelKindName.CUSTOM
	@property
	def is_managed(self)->bool:return self.model_kind_name==ModelKindName.MANAGED
	@property
	def is_dbt_custom(self)->bool:return self.model_kind_name==ModelKindName.DBT_CUSTOM
	@property
	def is_semantic_layer_kind(self)->bool:return self.model_kind_name in(ModelKindName.SEMANTIC,ModelKindName.METRIC)
	@property
	def is_symbolic(self)->bool:return self.model_kind_name in(ModelKindName.EMBEDDED,ModelKindName.EXTERNAL,ModelKindName.SEMANTIC,ModelKindName.METRIC)
	@property
	def is_materialized(self)->bool:return self.model_kind_name is not _A and not(self.is_symbolic or self.is_view)
	@property
	def only_execution_time(self)->bool:return self.is_view or self.is_full
	@property
	def full_history_restatement_only(self)->bool:return self.is_incremental_unmanaged or self.is_incremental_by_unique_key or self.is_incremental_by_partition or self.is_scd_type_2 or self.is_managed or self.is_full or self.is_view
	@property
	def supports_python_models(self)->bool:return _B
	@property
	def supports_grants(self)->bool:return self.is_materialized or self.is_view
class ModelKindName(str,ModelKindMixin,Enum):
	INCREMENTAL_BY_TIME_RANGE='INCREMENTAL_BY_TIME_RANGE';INCREMENTAL_BY_UNIQUE_KEY='INCREMENTAL_BY_UNIQUE_KEY';INCREMENTAL_BY_PARTITION='INCREMENTAL_BY_PARTITION';INCREMENTAL_UNMANAGED='INCREMENTAL_UNMANAGED';FULL='FULL';SCD_TYPE_2='SCD_TYPE_2';SCD_TYPE_2_BY_TIME='SCD_TYPE_2_BY_TIME';SCD_TYPE_2_BY_COLUMN='SCD_TYPE_2_BY_COLUMN';VIEW='VIEW';EMBEDDED='EMBEDDED';SEED='SEED';EXTERNAL='EXTERNAL';CUSTOM='CUSTOM';MANAGED='MANAGED';DBT_CUSTOM='DBT_CUSTOM';SEMANTIC='SEMANTIC';METRIC='METRIC'
	@property
	def model_kind_name(self)->t.Optional[ModelKindName]:return self
	def __str__(self)->str:return self.name
	def __repr__(self)->str:return str(self)
class OnDestructiveChange(str,Enum):
	ERROR='ERROR';WARN='WARN';ALLOW='ALLOW';IGNORE=_N
	@property
	def is_error(self)->bool:return self==OnDestructiveChange.ERROR
	@property
	def is_warn(self)->bool:return self==OnDestructiveChange.WARN
	@property
	def is_allow(self)->bool:return self==OnDestructiveChange.ALLOW
	@property
	def is_ignore(self)->bool:return self==OnDestructiveChange.IGNORE
class OnAdditiveChange(str,Enum):
	ERROR='ERROR';WARN='WARN';ALLOW='ALLOW';IGNORE=_N
	@property
	def is_error(self)->bool:return self==OnAdditiveChange.ERROR
	@property
	def is_warn(self)->bool:return self==OnAdditiveChange.WARN
	@property
	def is_allow(self)->bool:return self==OnAdditiveChange.ALLOW
	@property
	def is_ignore(self)->bool:return self==OnAdditiveChange.IGNORE
def _on_destructive_change_validator(cls:t.Type,v:t.Union[OnDestructiveChange,str,exp.Identifier])->t.Any:
	if v and not isinstance(v,OnDestructiveChange):return OnDestructiveChange(v.this.upper()if isinstance(v,(exp.Identifier,exp.Literal))else v.upper())
	return v
def _on_additive_change_validator(cls:t.Type,v:t.Union[OnAdditiveChange,str,exp.Identifier])->t.Any:
	if v and not isinstance(v,OnAdditiveChange):return OnAdditiveChange(v.this.upper()if isinstance(v,(exp.Identifier,exp.Literal))else v.upper())
	return v
on_additive_change_validator=field_validator(_I,mode=_D)(_on_additive_change_validator)
on_destructive_change_validator=field_validator(_J,mode=_D)(_on_destructive_change_validator)
class _ModelKind(PydanticModel,ModelKindMixin):
	name:ModelKindName
	@property
	def model_kind_name(self)->t.Optional[ModelKindName]:return self.name
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:kwargs['expressions']=expressions;return d.ModelKind(this=self.name.value.upper(),**kwargs)
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[self.name.value]
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[]
class TimeColumn(PydanticModel):
	column:exp.Expression;format:t.Optional[str]=_A
	@classmethod
	def validator(cls)->classmethod:
		def _time_column_validator(v:t.Any,info:ValidationInfo)->TimeColumn:return TimeColumn.create(v,get_dialect(info.data))
		return field_validator(_O,mode=_D)(_time_column_validator)
	@field_validator(_P,mode=_D)
	@classmethod
	def _column_validator(cls,v:t.Union[str,exp.Expression])->exp.Expression:
		if not v:raise ConfigError('Time Column cannot be empty.')
		if isinstance(v,str):return exp.to_column(v)
		return v
	@property
	def expression(self)->exp.Expression:
		if not self.format:return self.column
		return exp.Tuple(expressions=[self.column,exp.Literal.string(self.format)])
	def to_expression(self,dialect:str)->exp.Expression:
		if not self.format:return self.column
		return exp.Tuple(expressions=[self.column,exp.Literal.string(format_time(self.format,d.Dialect.get_or_raise(dialect).INVERSE_TIME_MAPPING))])
	def to_property(self,dialect:str='')->exp.Property:return exp.Property(this=_O,value=self.to_expression(dialect))
	@classmethod
	def create(cls,v:t.Any,dialect:str)->Self:
		if isinstance(v,exp.Tuple):column_expr=v.expressions[0];column=exp.column(column_expr)if isinstance(column_expr,exp.Identifier)else column_expr;format=v.expressions[1].name if len(v.expressions)>1 else _A
		elif isinstance(v,exp.Expression):column=exp.column(v)if isinstance(v,exp.Identifier)else v;format=_A
		elif isinstance(v,str):column=d.parse_one(v,dialect=dialect);column.meta.pop('sql');format=_A
		elif isinstance(v,dict):column_raw=v[_P];column=d.parse_one(column_raw,dialect=dialect)if isinstance(column_raw,str)else column_raw;format=v.get('format')
		elif isinstance(v,TimeColumn):column=v.column;format=v.format
		else:raise ConfigError(f"Invalid time_column: '{v}'.")
		column=quote_identifiers(normalize_identifiers(column,dialect=dialect),dialect=dialect);column.meta[_E]=dialect;return cls(column=column,format=format)
def _kind_dialect_validator(cls:t.Type,v:t.Optional[str])->str:
	if v is _A:return get_dialect({})
	return v
kind_dialect_validator=field_validator(_E,mode=_D)(_kind_dialect_validator)
class _Incremental(_ModelKind):
	on_destructive_change:OnDestructiveChange=OnDestructiveChange.ERROR;on_additive_change:OnAdditiveChange=OnAdditiveChange.ALLOW;auto_restatement_cron:t.Optional[SQLGlotCron]=_A;_on_destructive_change_validator=on_destructive_change_validator;_on_additive_change_validator=on_additive_change_validator
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[*super().metadata_hash_values,str(self.on_destructive_change),str(self.on_additive_change),self.auto_restatement_cron]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({_J:self.on_destructive_change.value,_I:self.on_additive_change.value,_Q:self.auto_restatement_cron})])
class _IncrementalBy(_Incremental):
	dialect:t.Optional[str]=Field(_A,validate_default=_B);batch_size:t.Optional[SQLGlotPositiveInt]=_A;batch_concurrency:t.Optional[SQLGlotPositiveInt]=_A;lookback:t.Optional[SQLGlotPositiveInt]=_A;forward_only:SQLGlotBool=_C;disable_restatement:SQLGlotBool=_C;_dialect_validator=kind_dialect_validator
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,self.dialect,str(self.lookback)if self.lookback is not _A else _A]
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[*super().metadata_hash_values,str(self.batch_size)if self.batch_size is not _A else _A,str(self.forward_only),str(self.disable_restatement)]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({_K:self.batch_size,_L:self.batch_concurrency,_R:self.lookback,_F:self.forward_only,_H:self.disable_restatement})])
class IncrementalByTimeRangeKind(_IncrementalBy):
	name:t.Literal[ModelKindName.INCREMENTAL_BY_TIME_RANGE]=ModelKindName.INCREMENTAL_BY_TIME_RANGE;time_column:TimeColumn;auto_restatement_intervals:t.Optional[SQLGlotPositiveInt]=_A;partition_by_time_column:SQLGlotBool=_B;_time_column_validator=TimeColumn.validator()
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),self.time_column.to_property(kwargs.get(_E)or''),*_properties({'partition_by_time_column':self.partition_by_time_column}),*([_property(_S,self.auto_restatement_intervals)]if self.auto_restatement_intervals is not _A else[])])
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,gen(self.time_column.column),self.time_column.format]
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[*super().metadata_hash_values,str(self.partition_by_time_column),str(self.auto_restatement_intervals)if self.auto_restatement_intervals is not _A else _A]
class IncrementalByUniqueKeyKind(_IncrementalBy):
	name:t.Literal[ModelKindName.INCREMENTAL_BY_UNIQUE_KEY]=ModelKindName.INCREMENTAL_BY_UNIQUE_KEY;unique_key:SQLGlotListOfFields;when_matched:t.Optional[exp.Whens]=_A;merge_filter:t.Optional[exp.Expression]=_A;batch_concurrency:t.Literal[1]=1
	@field_validator(_T,mode=_D)
	def _when_matched_validator(cls,v:t.Optional[t.Union[str,list,exp.Whens]],info:ValidationInfo)->t.Optional[exp.Whens]:
		if v is _A:return v
		if isinstance(v,list):v=' '.join(v)
		dialect=get_dialect(info.data)
		if isinstance(v,str):
			v=v.strip()
			if v.startswith('('):v=v[1:-1]
			v=t.cast(exp.Whens,d.parse_one(v,into=exp.Whens,dialect=dialect))
		v=validate_expression(v,dialect=dialect);return t.cast(exp.Whens,v.transform(d.replace_merge_table_aliases,dialect=dialect))
	@field_validator(_U,mode=_D)
	def _merge_filter_validator(cls,v:t.Optional[exp.Expression],info:ValidationInfo)->t.Optional[exp.Expression]:
		if v is _A:return v
		dialect=get_dialect(info.data)
		if isinstance(v,str):v=v.strip();v=d.parse_one(v,dialect=dialect)
		v=validate_expression(v,dialect=dialect);return v.transform(d.replace_merge_table_aliases,dialect=dialect)
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,*(gen(k)for k in self.unique_key),gen(self.when_matched)if self.when_matched is not _A else _A,gen(self.merge_filter)if self.merge_filter is not _A else _A]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({_V:exp.Tuple(expressions=self.unique_key),_T:self.when_matched,_U:self.merge_filter})])
class IncrementalByPartitionKind(_Incremental):
	name:t.Literal[ModelKindName.INCREMENTAL_BY_PARTITION]=ModelKindName.INCREMENTAL_BY_PARTITION;forward_only:t.Literal[_B]=_B;disable_restatement:SQLGlotBool=_C
	@field_validator(_F,mode=_D)
	def _forward_only_validator(cls,v:t.Union[bool,exp.Expression])->t.Literal[_B]:
		if v is not _B:raise ConfigError('Do not specify the `forward_only` configuration key - INCREMENTAL_BY_PARTITION models are always forward_only.')
		return v
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[*super().metadata_hash_values,str(self.forward_only),str(self.disable_restatement)]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({_F:self.forward_only,_H:self.disable_restatement})])
class IncrementalUnmanagedKind(_Incremental):
	name:t.Literal[ModelKindName.INCREMENTAL_UNMANAGED]=ModelKindName.INCREMENTAL_UNMANAGED;insert_overwrite:SQLGlotBool=_C;forward_only:SQLGlotBool=_B;disable_restatement:SQLGlotBool=_B
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,str(self.insert_overwrite)]
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[*super().metadata_hash_values,str(self.forward_only),str(self.disable_restatement)]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({'insert_overwrite':self.insert_overwrite,_F:self.forward_only,_H:self.disable_restatement})])
class ViewKind(_ModelKind):
	name:t.Literal[ModelKindName.VIEW]=ModelKindName.VIEW;materialized:SQLGlotBool=_C
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,str(self.materialized)]
	@property
	def supports_python_models(self)->bool:return _C
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),_property('materialized',self.materialized)])
class SeedKind(_ModelKind):
	name:t.Literal[ModelKindName.SEED]=ModelKindName.SEED;path:SQLGlotString;batch_size:SQLGlotPositiveInt=1000;csv_settings:t.Optional[CsvSettings]=_A
	@field_validator('csv_settings',mode=_D)
	@classmethod
	def _parse_csv_settings(cls,v:t.Any)->t.Optional[CsvSettings]:
		if v is _A or isinstance(v,CsvSettings):return v
		if isinstance(v,exp.Expression):
			tuple_exp=parse_properties(cls,v,_A)
			if not tuple_exp:return
			return CsvSettings(**{e.left.name:e.right for e in tuple_exp.expressions})
		if isinstance(v,dict):return CsvSettings(**v)
		return v
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({'path':exp.Literal.string(self.path),_K:self.batch_size})])
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:csv_setting_values=(self.csv_settings or CsvSettings()).dict().values();return[*super().data_hash_values,*(v if isinstance(v,(str,type(_A)))else str(v)for v in csv_setting_values)]
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[*super().metadata_hash_values,str(self.batch_size)]
	@property
	def supports_python_models(self)->bool:return _C
class FullKind(_ModelKind):name:t.Literal[ModelKindName.FULL]=ModelKindName.FULL
class _SCDType2Kind(_Incremental):
	dialect:t.Optional[str]=Field(_A,validate_default=_B);unique_key:SQLGlotListOfFields;valid_from_name:SQLGlotColumn=Field(exp.column('valid_from'),validate_default=_B);valid_to_name:SQLGlotColumn=Field(exp.column('valid_to'),validate_default=_B);invalidate_hard_deletes:SQLGlotBool=_C;time_data_type:exp.DataType=Field(exp.DataType.build('TIMESTAMP'),validate_default=_B);batch_size:t.Optional[SQLGlotPositiveInt]=_A;forward_only:SQLGlotBool=_B;disable_restatement:SQLGlotBool=_B;_dialect_validator=kind_dialect_validator;_always_validate_column=field_validator(_W,_X,mode=_D)(column_validator)
	@field_validator(_Y,mode=_D)
	@classmethod
	def _time_data_type_validator(cls,v:t.Union[str,exp.Expression],values:t.Any)->exp.Expression:
		if isinstance(v,exp.Expression)and not isinstance(v,exp.DataType):v=v.name
		dialect=get_dialect(values);data_type=exp.DataType.build(v,dialect=dialect);data_type.meta[_E]=dialect;return data_type
	@property
	def managed_columns(self)->t.Dict[str,exp.DataType]:return{self.valid_from_name.name:self.time_data_type,self.valid_to_name.name:self.time_data_type}
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,self.dialect,*(gen(k)for k in self.unique_key),gen(self.valid_from_name),gen(self.valid_to_name),str(self.invalidate_hard_deletes),self.time_data_type.sql(self.dialect),gen(self.batch_size)if self.batch_size is not _A else _A]
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[*super().metadata_hash_values,str(self.forward_only),str(self.disable_restatement)]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({_V:exp.Tuple(expressions=self.unique_key),_W:self.valid_from_name,_X:self.valid_to_name,'invalidate_hard_deletes':self.invalidate_hard_deletes,_Y:self.time_data_type,_F:self.forward_only,_H:self.disable_restatement})])
class SCDType2ByTimeKind(_SCDType2Kind):
	name:t.Literal[ModelKindName.SCD_TYPE_2,ModelKindName.SCD_TYPE_2_BY_TIME]=ModelKindName.SCD_TYPE_2_BY_TIME;updated_at_name:SQLGlotColumn=Field(exp.column('updated_at'),validate_default=_B);updated_at_as_valid_from:SQLGlotBool=_C;_always_validate_updated_at=field_validator(_Z,mode=_D)(column_validator)
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,gen(self.updated_at_name),str(self.updated_at_as_valid_from)]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({_Z:self.updated_at_name,'updated_at_as_valid_from':self.updated_at_as_valid_from})])
class SCDType2ByColumnKind(_SCDType2Kind):
	name:t.Literal[ModelKindName.SCD_TYPE_2_BY_COLUMN]=ModelKindName.SCD_TYPE_2_BY_COLUMN;columns:SQLGlotListOfFieldsOrStar;execution_time_as_valid_from:SQLGlotBool=_C;updated_at_name:t.Optional[SQLGlotColumn]=_A
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:columns_sql=[gen(c)for c in self.columns]if isinstance(self.columns,list)else[gen(self.columns)];return[*super().data_hash_values,*columns_sql,str(self.execution_time_as_valid_from),gen(self.updated_at_name)if self.updated_at_name is not _A else _A]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({'columns':exp.Tuple(expressions=self.columns)if isinstance(self.columns,list)else self.columns,'execution_time_as_valid_from':self.execution_time_as_valid_from})])
class ManagedKind(_ModelKind):
	name:t.Literal[ModelKindName.MANAGED]=ModelKindName.MANAGED;disable_restatement:t.Literal[_B]=_B
	@property
	def supports_python_models(self)->bool:return _C
class DbtCustomKind(_ModelKind):
	name:t.Literal[ModelKindName.DBT_CUSTOM]=ModelKindName.DBT_CUSTOM;materialization:str;adapter:str='default';definition:str;dialect:t.Optional[str]=Field(_A,validate_default=_B);_dialect_validator=kind_dialect_validator
	@field_validator(_G,_a,'definition',mode=_D)
	@classmethod
	def _validate_fields(cls,v:t.Any)->str:return validate_string(v)
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,self.materialization,self.definition,self.adapter,self.dialect]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({_G:exp.Literal.string(self.materialization),_a:exp.Literal.string(self.adapter)})])
class EmbeddedKind(_ModelKind):
	name:t.Literal[ModelKindName.EMBEDDED]=ModelKindName.EMBEDDED
	@property
	def supports_python_models(self)->bool:return _C
class ExternalKind(_ModelKind):name:t.Literal[ModelKindName.EXTERNAL]=ModelKindName.EXTERNAL
class SemanticKind(_ModelKind):
	name:t.Literal[ModelKindName.SEMANTIC]=ModelKindName.SEMANTIC
	@property
	def supports_python_models(self)->bool:return _C
class MetricKind(_ModelKind):
	name:t.Literal[ModelKindName.METRIC]=ModelKindName.METRIC
	@property
	def supports_python_models(self)->bool:return _C
class CustomKind(_ModelKind):
	name:t.Literal[ModelKindName.CUSTOM]=ModelKindName.CUSTOM;materialization:str;materialization_properties_:t.Optional[exp.Tuple]=Field(default=_A,alias=_b);forward_only:SQLGlotBool=_C;disable_restatement:SQLGlotBool=_C;batch_size:t.Optional[SQLGlotPositiveInt]=_A;batch_concurrency:t.Optional[SQLGlotPositiveInt]=_A;lookback:t.Optional[SQLGlotPositiveInt]=_A;auto_restatement_cron:t.Optional[SQLGlotCron]=_A;auto_restatement_intervals:t.Optional[SQLGlotPositiveInt]=_A;dialect:str=Field(exclude=_B);_properties_validator=properties_validator
	@field_validator(_G,mode=_D)
	@classmethod
	def _validate_materialization(cls,v:t.Any)->str:return validate_string(v)
	@property
	def materialization_properties(self)->CustomMaterializationProperties:
		if not self.materialization_properties_:return{}
		return d.interpret_key_value_pairs(self.materialization_properties_)
	@property
	def data_hash_values(self)->t.List[t.Optional[str]]:return[*super().data_hash_values,self.materialization,gen(self.materialization_properties_)if self.materialization_properties_ else _A,str(self.lookback)if self.lookback is not _A else _A]
	@property
	def metadata_hash_values(self)->t.List[t.Optional[str]]:return[*super().metadata_hash_values,str(self.batch_size)if self.batch_size is not _A else _A,str(self.batch_concurrency)if self.batch_concurrency is not _A else _A,str(self.forward_only),str(self.disable_restatement),self.auto_restatement_cron,str(self.auto_restatement_intervals)if self.auto_restatement_intervals is not _A else _A]
	def to_expression(self,expressions:t.Optional[t.List[exp.Expression]]=_A,**kwargs:t.Any)->d.ModelKind:return super().to_expression(expressions=[*(expressions or[]),*_properties({_G:exp.Literal.string(self.materialization),_b:self.materialization_properties_,_F:self.forward_only,_H:self.disable_restatement,_K:self.batch_size,_L:self.batch_concurrency,_R:self.lookback,_Q:self.auto_restatement_cron,_S:self.auto_restatement_intervals})])
ModelKind=t.Annotated[t.Union[EmbeddedKind,ExternalKind,SemanticKind,MetricKind,FullKind,IncrementalByTimeRangeKind,IncrementalByUniqueKeyKind,IncrementalByPartitionKind,IncrementalUnmanagedKind,SeedKind,ViewKind,SCDType2ByTimeKind,SCDType2ByColumnKind,CustomKind,ManagedKind,DbtCustomKind],Field(discriminator=_M)]
MODEL_KIND_NAME_TO_TYPE:t.Dict[str,t.Type[ModelKind]]={ModelKindName.EMBEDDED:EmbeddedKind,ModelKindName.EXTERNAL:ExternalKind,ModelKindName.SEMANTIC:SemanticKind,ModelKindName.METRIC:MetricKind,ModelKindName.FULL:FullKind,ModelKindName.INCREMENTAL_BY_TIME_RANGE:IncrementalByTimeRangeKind,ModelKindName.INCREMENTAL_BY_UNIQUE_KEY:IncrementalByUniqueKeyKind,ModelKindName.INCREMENTAL_BY_PARTITION:IncrementalByPartitionKind,ModelKindName.INCREMENTAL_UNMANAGED:IncrementalUnmanagedKind,ModelKindName.SEED:SeedKind,ModelKindName.VIEW:ViewKind,ModelKindName.SCD_TYPE_2:SCDType2ByTimeKind,ModelKindName.SCD_TYPE_2_BY_TIME:SCDType2ByTimeKind,ModelKindName.SCD_TYPE_2_BY_COLUMN:SCDType2ByColumnKind,ModelKindName.CUSTOM:CustomKind,ModelKindName.MANAGED:ManagedKind,ModelKindName.DBT_CUSTOM:DbtCustomKind}
def model_kind_type_from_name(name:t.Optional[str])->t.Type[ModelKind]:
	klass=MODEL_KIND_NAME_TO_TYPE.get(name)if name else _A
	if not klass:raise ConfigError(f"Invalid model kind '{name}'")
	return t.cast(t.Type[ModelKind],klass)
def create_model_kind(v:t.Any,dialect:str,defaults:t.Dict[str,t.Any])->ModelKind:
	if isinstance(v,_ModelKind):return t.cast(ModelKind,v)
	if isinstance(v,(d.ModelKind,dict)):
		props={prop.name:prop.args.get('value')for prop in v.expressions}if isinstance(v,d.ModelKind)else v;name=v.this if isinstance(v,d.ModelKind)else props.get(_M);props[_M]=name;kind_type=model_kind_type_from_name(name)
		if _E in kind_type.all_fields()and props.get(_E)is _A:props[_E]=dialect
		if issubclass(kind_type,_Incremental):
			for on_change_property in(_I,_J):
				if props.get(on_change_property)is _A and defaults.get(on_change_property)is not _A:props[on_change_property]=defaults.get(on_change_property)
		if issubclass(kind_type,_IncrementalBy):
			BATCH_CONCURRENCY:t.Final=_L
			if props.get(BATCH_CONCURRENCY)is _A and defaults.get(BATCH_CONCURRENCY)is not _A and kind_type.all_field_infos()[BATCH_CONCURRENCY].default is _A:props[BATCH_CONCURRENCY]=defaults.get(BATCH_CONCURRENCY)
		if kind_type==CustomKind:
			from vulcan.core.snapshot.evaluator import get_custom_materialization_type
			if _G not in props:raise ConfigError("The 'materialization' property is required for models of the CUSTOM kind")
			custom_materialization=get_custom_materialization_type(validate_string(props.get(_G)),raise_errors=_C)
			if custom_materialization is not _A:actual_kind_type,_=custom_materialization;return actual_kind_type(**props)
		validate_extra_and_required_fields(kind_type,set(props),f"MODEL block 'kind {name}' field");return kind_type(**props)
	name=(v.name if isinstance(v,exp.Expression)else str(v)).upper();return model_kind_type_from_name(name)(name=name)
def _model_kind_validator(cls:t.Type,v:t.Any,info:t.Optional[ValidationInfo])->ModelKind:dialect=get_dialect(info.data)if info else'';return create_model_kind(v,dialect,{})
model_kind_validator:t.Callable=field_validator('kind',mode=_D)(_model_kind_validator)
def _property(name:str,value:t.Any)->exp.Property:return exp.Property(this=exp.var(name),value=exp.convert(value))
def _properties(name_value_pairs:t.Dict[str,t.Any])->t.List[exp.Property]:return[_property(k,v)for(k,v)in name_value_pairs.items()if v is not _A]