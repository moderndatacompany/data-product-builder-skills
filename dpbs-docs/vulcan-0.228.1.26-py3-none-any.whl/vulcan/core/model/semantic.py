from __future__ import annotations
_k='metric'
_j='depends_on'
_i='semantic'
_h='mask_expression'
_g='format'
_f='interval'
_e='BOOLEAN'
_d='count_distinct_approx'
_c='count_distinct'
_b='boolean'
_a='joins'
_Z='measures'
_Y='granularities'
_X='expression'
_W='number'
_V='string'
_U='granularity'
_T='ref'
_S='time'
_R='measure'
_Q='public'
_P='behavior'
_O='ts'
_N='count'
_M='type'
_L='segments'
_K='after'
_J='dimensions'
_I='terms'
_H='tags'
_G='before'
_F='description'
_E='ai_context'
_D='name'
_C='json'
_B=True
_A=None
import json,re,typing as t
from functools import cached_property
from typing import get_args
from pydantic import Field,field_validator,model_validator
from typing_extensions import Literal
from sqlglot import exp
from schema.types import AiContextSpec,DimensionBehaviorSpec,JoinRelationshipValue as JoinRelationshipValue,LogicalTypeValue as LogicalTypeValue,MeasureBehaviorSpec,MeasureTypeValue as MeasureTypeValue,MetricGranularityValue as MetricGranularityValue,RollingWindowSpec as RollingWindowSpec,TimeGranularitySpec as _WireTimeGranularitySpec
from schema.filters import PolicyFilterExpression,PolicyMask
from vulcan.core.types import Tag,Term
from vulcan.utils.errors import ConfigError
from vulcan.utils.hashing import hash_data
from vulcan.utils.pydantic import PydanticModel
MAX_IDENTIFIER_LENGTH=64
VALID_IDENTIFIER_PATTERN=re.compile('^[a-zA-Z_][a-zA-Z0-9_]{0,63}$')
_METRIC_ADJUNCT_NAME_RESERVED=frozenset({_R,_S,_O})
MaskExpression=t.Union[str,int,float,bool]
STRICT_TIMESTAMP_TYPES:t.Final[t.Tuple[exp.DataType.Type,...]]=(exp.DataType.Type.TIMESTAMP,exp.DataType.Type.TIMESTAMPTZ,exp.DataType.Type.TIMESTAMPNTZ,exp.DataType.Type.TIMESTAMPLTZ,exp.DataType.Type.DATETIME)
class NamingError(ValueError):0
def _hash(obj:t.Any)->str:return hash_data([json.dumps(obj,sort_keys=_B,default=str)])
_BEHAVIOR_LEGACY_YAML_ALIASES='behaviour','semantic_config'
def _normalize_behavior_alias(data:t.Any,*,context:str)->t.Any:
	if not isinstance(data,dict):return data
	canonical=data.get(_P);legacy_present=[key for key in _BEHAVIOR_LEGACY_YAML_ALIASES if data.get(key)is not _A]
	if canonical is not _A and legacy_present:raise ValueError(f"{context}: 'behavior' cannot be combined with legacy aliases ({', '.join(repr(k)for k in legacy_present)}); use 'behavior' only.")
	if len(legacy_present)>1:raise ValueError(f"{context}: only one legacy behavior alias may be set; use 'behavior' instead.")
	if canonical is not _A or not legacy_present:return data
	legacy_key=legacy_present[0];member_name=data.get(_D,'<unknown>');from vulcan.core.console import get_console;get_console().log_warning(f"{context} '{member_name}' uses deprecated '{legacy_key}'; use 'behavior' instead.");out=dict(data);out[_P]=data[legacy_key]
	for key in _BEHAVIOR_LEGACY_YAML_ALIASES:out.pop(key,_A)
	return out
def sql_dtype_to_logical_type(col_type:t.Optional[exp.DataType])->LogicalTypeValue:
	if not col_type:return _V
	if col_type.is_type(*exp.DataType.INTEGER_TYPES,*exp.DataType.REAL_TYPES):return _W
	if col_type.is_type(*STRICT_TIMESTAMP_TYPES):return _S
	if col_type.is_type(exp.DataType.Type.BOOLEAN):return _b
	return _V
def _parse_qualified_reference(ref:str)->t.Tuple[str,str]|_A:
	parts=ref.split('.')
	if len(parts)!=2 or not parts[0]or not parts[1]:return
	return parts[0],parts[1]
def _validate_identifier(value:str,*,context:str='identifier')->str:
	if not value:raise NamingError(f"{context} must not be empty")
	if not VALID_IDENTIFIER_PATTERN.match(value):raise NamingError(f"{context} must match {VALID_IDENTIFIER_PATTERN.pattern}, got {value!r}")
	return value
def _validate_qualified_reference(ref:str,*,context:str='reference')->str:
	parsed=_parse_qualified_reference(ref)
	if not parsed:raise NamingError(f"{context} must be exactly one qualified reference in the form 'name.field', got {ref!r}")
	semantic_name,field=parsed;_validate_identifier(semantic_name,context=f"{context} (semantic model name)");_validate_identifier(field,context=f"{context} (field)");return ref
def _literal(s:str)->exp.Expression:return exp.Literal.string(s)
def _text(s:str)->exp.Expression:return exp.Identifier(this=s,quoted=_B)
def _upper(s:str)->exp.Expression:return exp.to_identifier(s.upper().replace('-','_'))
def _is_unquoted_identifier(s:str)->bool:return bool(re.match('^[a-zA-Z_][a-zA-Z0-9_]*$',s))
def _entry(d:'DimensionSpec')->exp.Expression:name=d.name;return exp.to_identifier(name)if _is_unquoted_identifier(name)else _literal(name)
def _require_unique(kind:str,values:t.List[str])->_A:
	dupes={x for x in values if values.count(x)>1}
	if dupes:raise ValueError(f"duplicate {kind}: {sorted(dupes)}")
def _mask_property_value(value:MaskExpression)->exp.Expression:
	if isinstance(value,str):return _text(value)
	return exp.convert(value)
def _segment_name_from_ref(ref:str)->str:
	parsed=_parse_qualified_reference(ref)
	if not parsed:raise NamingError(f"segment ref must be exactly one qualified reference in the form 'name.field', got {ref!r}")
	semantic_name,field=parsed;return f"{semantic_name}_{field}".lower()
def _coerce_metric_dimensions_yaml(entries:t.Any,*,context:str=_J)->t.List[t.Dict[str,t.Any]]:
	if not isinstance(entries,list):raise ValueError(f"{context} must be a list")
	shorthand_refs_by_derived_name:t.Dict[str,t.List[str]]={};out:t.List[t.Dict[str,t.Any]]=[]
	for(i,x)in enumerate(entries):
		loc=f"{context}[{i}]"
		if isinstance(x,str):
			ref=_validate_qualified_reference(x.strip(),context=loc);parsed=_parse_qualified_reference(ref)
			if not parsed:raise NamingError(f"{loc}: invalid qualified reference {ref!r}")
			_,field_name=parsed;_validate_identifier(field_name,context=f"{loc} (name derived from ref field)");shorthand_refs_by_derived_name.setdefault(field_name,[]).append(ref);out.append({_D:field_name,_T:ref})
		elif isinstance(x,dict):out.append(dict(x))
		else:raise ValueError(f"{loc}: entry must be a qualified reference string or a dict, got {type(x).__name__}")
	clashes={name:refs for(name,refs)in shorthand_refs_by_derived_name.items()if len(set(refs))>1}
	if clashes:detail='; '.join(f"{name!r}: {refs}"for(name,refs)in sorted(clashes.items()));raise ValueError(f"duplicate dimension name derived from qualified refs; use an explicit object entry with 'name' for one dimension: {detail}")
	return out
def _coerce_metric_segments_yaml(entries:t.Any,*,context:str=_L)->t.List[t.Dict[str,t.Any]]:
	if not isinstance(entries,list):raise ValueError(f"{context} must be a list")
	out:t.List[t.Dict[str,t.Any]]=[]
	for(i,x)in enumerate(entries):
		loc=f"{context}[{i}]"
		if not isinstance(x,str):raise ValueError(f"{loc}: segment must be a qualified reference string, got {type(x).__name__}")
		ref=_validate_qualified_reference(x.strip(),context=loc);derived=_segment_name_from_ref(ref);_validate_identifier(derived,context=f"{loc} (name derived as semantic_field)");out.append({_D:derived,_T:ref})
	return out
class MeasureSpec(PydanticModel):
	_MEASURE_TYPES:t.ClassVar[frozenset[str]]=frozenset(get_args(MeasureTypeValue));_RESERVED_MEASURE_NAMES:t.ClassVar[frozenset[str]]=frozenset({_N});_MEASURE_TYPES_ALLOWING_FILTERS:t.ClassVar[frozenset[str]]=frozenset({'sum','avg','min','max',_N,_c,_d});name:str;type:MeasureTypeValue;expression:str='';description:str='';filters:t.List[str]=Field(default_factory=list);rolling_window:t.Optional[RollingWindowSpec]=_A;public:bool=_B;tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);behavior:t.Optional[MeasureBehaviorSpec]=_A;ai_context:t.Optional[AiContextSpec]=_A
	@model_validator(mode=_G)
	@classmethod
	def normalize_behavior_alias(cls,data:t.Any)->t.Any:return _normalize_behavior_alias(data,context=_R)
	@model_validator(mode=_G)
	@classmethod
	def normalize_type(cls,data:t.Any)->t.Any:
		if isinstance(data,dict)and _M in data and isinstance(data[_M],str):data={**data,_M:data[_M].strip().lower()}
		return data
	@model_validator(mode=_K)
	def validate_measure_name(self)->MeasureSpec:_validate_identifier(self.name,context='measure name');return self
	@model_validator(mode=_K)
	def validate_expression_required(self)->MeasureSpec:
		if self.type==_N:return self
		if not self.expression.strip():raise ValueError(f"Measure {self.name!r} of type {self.type!r} requires a non-empty expression")
		return self
	@model_validator(mode=_K)
	def validate_filters_nonempty(self)->MeasureSpec:
		for(i,f)in enumerate(self.filters):
			if not str(f).strip():raise ValueError(f"Measure {self.name!r} has empty filter at index {i}")
		return self
	@model_validator(mode=_K)
	def validate_number_no_filters(self)->MeasureSpec:
		if self.type==_W and self.filters:raise ValueError(f"Measure {self.name!r}: type 'number' cannot be combined with filters")
		return self
	@model_validator(mode=_K)
	def validate_filters_allowed_for_type(self)->MeasureSpec:
		if self.filters and self.type not in type(self)._MEASURE_TYPES_ALLOWING_FILTERS:raise ValueError(f"Measure {self.name!r}: filters are not allowed for type {self.type!r}")
		return self
	@classmethod
	def implicit_count(cls)->MeasureSpec:return cls(name=_N,type=_N,expression='*',description='',filters=[],rolling_window=_A,public=_B,tags=[],terms=[],behavior=_A,ai_context=_A)
	def data_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,exclude={_F,_Q,_H,_I,_E,_P});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,include={_D,_F,_H,_I,_E,_P,_Q});return _hash(raw)
	@cached_property
	def exp(self)->exp.DataType:
		k=self.type
		if k in('sum','avg','min','max',_W):return exp.DataType.build('DOUBLE')
		if k in(_N,_c,_d):return exp.DataType.build('BIGINT')
		if k==_V:return exp.DataType.build('VARCHAR')
		if k==_S:return exp.DataType.build('TIMESTAMP')
		if k==_b:return exp.DataType.build(_e)
		return exp.DataType.build('UNKNOWN')
	def render_exp(self)->exp.Expression:
		inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier(_M),value=_upper(self.type))]
		if self.expression:inner.append(exp.Property(this=exp.to_identifier(_X),value=_text(self.expression)))
		if self.filters:inner.append(exp.Property(this=exp.to_identifier('filters'),value=exp.Tuple(expressions=[_text(str(f))for f in self.filters])))
		if self.rolling_window is not _A:rw=self.rolling_window.model_dump(mode=_C,exclude_none=_B);inner.append(exp.Property(this=exp.to_identifier('rolling_window'),value=_literal(json.dumps(rw,sort_keys=_B))))
		return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=inner))
class TimeGranularitySpec(_WireTimeGranularitySpec):
	ai_context:t.Optional[AiContextSpec]=_A
	def data_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,exclude={_F,_E});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,include={_D,_f,_F,_E});return _hash(raw)
	def render_exp(self)->exp.Expression:
		inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier(_f),value=_text(self.interval))]
		for(key,val)in(('offset',self.offset),('origin',self.origin)):
			if val is not _A:inner.append(exp.Property(this=exp.to_identifier(key),value=_text(val)))
		return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=inner))
class DimensionSpec(PydanticModel):
	name:str;description:t.Optional[str]=_A;tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);format:t.Optional[str]=_A;granularities:t.List[TimeGranularitySpec]=Field(default_factory=list);behavior:t.Optional[DimensionBehaviorSpec]=_A;ai_context:t.Optional[AiContextSpec]=_A;public:bool=_B;mask_expression:t.Optional[MaskExpression]=_A
	@model_validator(mode=_G)
	@classmethod
	def normalize_behavior_alias(cls,data:t.Any)->t.Any:return _normalize_behavior_alias(data,context='dimension')
	@classmethod
	def implicit_grain(cls,grain:exp.Expression)->DimensionSpec:
		e=grain.unnest()
		if isinstance(e,exp.Tuple):raise ConfigError(f"MODEL grains must list each column separately (e.g. grains (a, b)); got a composite grain expression: {e.sql()}")
		if isinstance(e,exp.Column):name=str(e.name)
		elif isinstance(e,exp.Identifier):name=str(e.name)
		else:raise ConfigError(f"MODEL grains must be simple column identifiers; got {e.sql()} ({type(e).__name__})")
		return cls(name=_validate_identifier(name,context='implicit grain dimension name'),description=_A,tags=[],terms=[],format=_A,granularities=[],behavior=_A,ai_context=_A,public=False)
	@field_validator(_D)
	@classmethod
	def validate_name(cls,v:str)->str:return _validate_identifier(v,context='dimension name')
	@model_validator(mode=_K)
	def validate_granularity_names_unique(self)->DimensionSpec:
		names=[g.name for g in self.granularities];dupes={n for n in names if names.count(n)>1}
		if dupes:raise ValueError(f"Duplicate granularity names on dimension {self.name!r}: {sorted(dupes)}")
		return self
	def render_exp(self)->exp.Expression:
		inner:t.List[exp.Expression]=[]
		if self.format:inner.append(exp.Property(this=exp.to_identifier(_g),value=_text(self.format)))
		if self.granularities:inner.append(exp.Property(this=exp.to_identifier(_Y),value=exp.Tuple(expressions=[g.render_exp()for g in sorted(self.granularities,key=lambda x:x.name)])))
		if self.mask_expression is not _A:inner.append(exp.Property(this=exp.to_identifier(_h),value=_mask_property_value(self.mask_expression)))
		if not inner:return _entry(self)
		return exp.Property(this=exp.to_identifier(self.name)if _is_unquoted_identifier(self.name)else _literal(self.name),value=exp.Tuple(expressions=inner))
	def data_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,include={_D,_g,_Q,_h});raw[_Y]=[g.data_hash()for g in sorted(self.granularities,key=lambda x:x.name)];return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,include={_D,_F,_H,_I,_E,_P});raw[_Y]=[g.metadata_hash()for g in sorted(self.granularities,key=lambda x:x.name)];return _hash(raw)
class SegmentSpec(PydanticModel):
	name:str;expression:str;description:str='';public:bool=_B;tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);ai_context:t.Optional[AiContextSpec]=_A
	@field_validator(_D)
	@classmethod
	def validate_name(cls,v:str)->str:return _validate_identifier(v,context='segment name')
	@cached_property
	def exp(self)->exp.DataType:return exp.DataType.build(_e)
	def data_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,exclude={_F,_H,_I,_E,_Q});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,include={_D,_F,_H,_I,_E,_Q});return _hash(raw)
	def render_exp(self)->exp.Expression:return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=[exp.Property(this=exp.to_identifier(_X),value=_text(self.expression))]))
class JoinSpec(PydanticModel):
	name:str;type:JoinRelationshipValue;expression:str;ai_context:t.Optional[AiContextSpec]=_A;fqn:t.Optional[str]=Field(default=_A)
	@field_validator(_D)
	@classmethod
	def validate_name(cls,v:str)->str:return _validate_identifier(v,context='join name')
	@field_validator(_M,mode=_G)
	@classmethod
	def normalize_relationship(cls,v:t.Any)->t.Any:
		if isinstance(v,str):return v.strip().lower()
		return v
	def data_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,exclude={_E});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,include={_D,_E});return _hash(raw)
	def render_exp(self)->exp.Expression:return exp.Property(this=exp.to_identifier(self.name),value=exp.Tuple(expressions=[exp.Property(this=exp.to_identifier(_M),value=_upper(self.type)),exp.Property(this=exp.to_identifier(_X),value=_text(self.expression))]))
class PolicySpec(PydanticModel):
	group:str;filter:t.List[PolicyFilterExpression]|_A=_A;mask:PolicyMask|_A=_A
	@field_validator('group')
	@classmethod
	def validate_group(cls,value:str)->str:return _validate_identifier(value.strip(),context='policy group')
	@field_validator('mask',mode=_G)
	@classmethod
	def reject_list_wildcard_mask(cls,value:t.Any)->t.Any:
		if value==['*']:raise ValueError("mask must be scalar '*' not ['*']")
		return value
	def metadata_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,by_alias=_B);return _hash(raw)
class SemanticModelSpec(PydanticModel):
	kind:Literal[_i]=_i;name:str;depends_on:str;description:t.Optional[str]=_A;owner:t.Optional[str]=_A;tags:t.Optional[t.List[Tag]]=_A;terms:t.Optional[t.List[Term]]=_A;ai_context:t.Optional[AiContextSpec]=_A;measures:t.List[MeasureSpec]=Field(default_factory=list);segments:t.List[SegmentSpec]=Field(default_factory=list);joins:t.List[JoinSpec]=Field(default_factory=list);dimensions:t.List[DimensionSpec]=Field(...);policies:t.List[PolicySpec]=Field(default_factory=list)
	@field_validator(_J,mode=_G)
	@classmethod
	def coerce_dimension_inputs(cls,v:t.Any)->t.List[DimensionSpec]:
		if not isinstance(v,list):raise ValueError('dimensions must be a list')
		def _coerce_dimension(x:t.Any)->DimensionSpec:
			if isinstance(x,DimensionSpec):return x
			if isinstance(x,str):return DimensionSpec(name=_validate_identifier(x,context='dimension column'))
			if isinstance(x,dict):return DimensionSpec.model_validate(x)
			raise ValueError(f"dimension entry must be str, dict, or DimensionSpec, got {type(x).__name__}")
		return[_coerce_dimension(x)for x in v]
	@model_validator(mode=_K)
	def validate_root(self)->SemanticModelSpec:
		_validate_identifier(self.name,context='semantic model name')
		if not self.dimensions:raise ValueError("semantic model must declare a non-empty 'dimensions' allow-list")
		_require_unique('measure names',[m.name for m in self.measures]);_require_unique('segment names',[s.name for s in self.segments]);_require_unique('join names',[j.name for j in self.joins]);reserved=MeasureSpec._RESERVED_MEASURE_NAMES
		for m in self.measures:
			if m.name in reserved:raise ValueError(f"Measure name {m.name!r} is reserved (automatic count is implied)")
		for j in self.joins:
			if j.name==self.name:raise ValueError(f"join name {j.name!r} must not equal to name {self.name!r}")
		_require_unique('policy groups',[p.group for p in self.policies]);return self
	def data_hash(self)->str:top=self.model_dump(mode=_C,exclude_none=_B,include={'kind',_D,_j});payload={**top,_J:[d.data_hash()for d in self.dimensions],_Z:[m.data_hash()for m in sorted(self.measures,key=lambda x:x.name)],_L:[s.data_hash()for s in sorted(self.segments,key=lambda x:x.name)],_a:[j.data_hash()for j in sorted(self.joins,key=lambda x:x.name)]};return _hash(payload)
	def metadata_hash(self)->str:top=self.model_dump(mode=_C,exclude_none=_B,include={_D,_F,'owner',_H,_I,_E});payload={**top,_J:[d.metadata_hash()for d in self.dimensions],_Z:[m.metadata_hash()for m in sorted(self.measures,key=lambda x:x.name)],_L:[s.metadata_hash()for s in sorted(self.segments,key=lambda x:x.name)],_a:[j.metadata_hash()for j in sorted(self.joins,key=lambda x:x.name)],'policies':[p.metadata_hash()for p in sorted(self.policies,key=lambda x:x.group)]};return _hash(payload)
	def render_exps(self)->t.List[exp.Property]:
		out:t.List[exp.Property]=[exp.Property(this=exp.to_identifier(_j),value=_literal(self.depends_on)),exp.Property(this=exp.to_identifier(_J),value=exp.Tuple(expressions=[d.render_exp()for d in sorted(self.dimensions,key=lambda x:x.name)]))]
		if self.measures:out.append(exp.Property(this=exp.to_identifier(_Z),value=exp.Tuple(expressions=[m.render_exp()for m in sorted(self.measures,key=lambda x:x.name)])))
		if self.segments:out.append(exp.Property(this=exp.to_identifier(_L),value=exp.Tuple(expressions=[s.render_exp()for s in sorted(self.segments,key=lambda x:x.name)])))
		if self.joins:out.append(exp.Property(this=exp.to_identifier(_a),value=exp.Tuple(expressions=[j.render_exp()for j in sorted(self.joins,key=lambda x:x.name)])))
		return out
class MetricNamedRefSpec(PydanticModel):
	name:str;ref:str;description:str='';tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);ai_context:t.Optional[AiContextSpec]=_A
	@model_validator(mode=_K)
	def validate_name_and_ref(self)->MetricNamedRefSpec:_validate_identifier(self.name,context='metric dimension or segment name');_validate_qualified_reference(self.ref,context='metric dimension or segment ref');return self
	def data_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,exclude={_F,_H,_I,_E});return _hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode=_C,exclude_none=_B,include={_D,_T,_F,_H,_I,_E});return _hash(raw)
	def render_exp(self)->exp.Property:
		name_expr=exp.to_identifier(self.name)if _is_unquoted_identifier(self.name)else _literal(self.name)
		if not self.description.strip()and not self.tags and not self.terms:return exp.Property(this=name_expr,value=_literal(self.ref))
		inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier(_T),value=_literal(self.ref))]
		if self.description.strip():inner.append(exp.Property(this=exp.to_identifier(_F),value=_text(self.description.strip())))
		if self.tags:inner.append(exp.Property(this=exp.to_identifier(_H),value=exp.Tuple(expressions=[_literal(str(tag))for tag in self.tags])))
		if self.terms:inner.append(exp.Property(this=exp.to_identifier(_I),value=exp.Tuple(expressions=[_literal(str(term))for term in self.terms])))
		return exp.Property(this=name_expr,value=exp.Tuple(expressions=inner))
MetricDimensionSpec=MetricNamedRefSpec
MetricSegmentSpec=MetricNamedRefSpec
class MetricSpec(PydanticModel):
	kind:Literal[_k]=_k;name:str;measure:str;ts:str;granularity:MetricGranularityValue;dimensions:t.List[MetricNamedRefSpec]=Field(default_factory=list);segments:t.List[MetricNamedRefSpec]=Field(default_factory=list);description:str='';owner:t.Optional[str]=_A;tags:t.List[Tag]=Field(default_factory=list);terms:t.List[Term]=Field(default_factory=list);ai_context:t.Optional[AiContextSpec]=_A
	@model_validator(mode=_G)
	@classmethod
	def reject_legacy_metric_yaml_keys(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		forbidden=[k for k in(_S,'slices')if k in data]
		if forbidden:raise ValueError(f"invalid metric YAML keys {forbidden!r}: use top-level 'ts', 'granularity', and 'dimensions' instead")
		return data
	@field_validator(_U,mode=_G)
	@classmethod
	def normalize_granularity(cls,v:t.Any)->t.Any:
		if isinstance(v,str):return v.strip().lower()
		return v
	@field_validator(_O)
	@classmethod
	def validate_ts(cls,v:str)->str:
		if not isinstance(v,str):raise ValueError(f"metric ts must be a string qualified reference, got {type(v).__name__}")
		return _validate_qualified_reference(v.strip(),context='metric ts')
	@field_validator(_J,mode=_G)
	@classmethod
	def coerce_dimensions(cls,v:t.Any)->t.List[t.Dict[str,t.Any]]:return _coerce_metric_dimensions_yaml(v if v is not _A else[])
	@field_validator(_L,mode=_G)
	@classmethod
	def coerce_segments(cls,v:t.Any)->t.List[t.Dict[str,t.Any]]:return _coerce_metric_segments_yaml(v if v is not _A else[])
	@model_validator(mode=_K)
	def validate_metric(self)->MetricSpec:
		_validate_identifier(self.name,context='metric name');all_refs=[self.measure,self.ts,*[s.ref for s in self.dimensions],*[s.ref for s in self.segments]]
		for ref in all_refs:_validate_qualified_reference(ref,context='metric item')
		_require_unique('metric refs',all_refs);all_names=[s.name for s in self.dimensions]+[s.name for s in self.segments];_require_unique('dimension/segment names',all_names)
		for n in all_names:
			if n.lower()in _METRIC_ADJUNCT_NAME_RESERVED:raise ValueError(f"name {n!r} is reserved")
		return self
	@property
	def depends_on_semantic_names(self)->t.FrozenSet[str]:
		names:t.Set[str]=set()
		for ref in(self.measure,self.ts,*[s.ref for s in self.dimensions],*[s.ref for s in self.segments]):
			parsed=_parse_qualified_reference(ref)
			if parsed:names.add(parsed[0])
		return frozenset(names)
	def data_hash(self)->str:top=self.model_dump(mode=_C,exclude_none=_B,include={'kind',_D,_R});payload={**top,_O:self.ts,_U:self.granularity,_J:[s.data_hash()for s in sorted(self.dimensions,key=lambda x:x.name)],_L:[s.data_hash()for s in sorted(self.segments,key=lambda x:x.name)]};return _hash(payload)
	def metadata_hash(self)->str:top=self.model_dump(mode=_C,exclude_none=_B,include={_D,_F,'owner',_H,_I});payload={**top,_E:self.ai_context.model_dump(mode=_C,exclude_none=_B)if self.ai_context else _A,_O:self.ts,_U:self.granularity,_J:[s.metadata_hash()for s in sorted(self.dimensions,key=lambda x:x.name)],_L:[s.metadata_hash()for s in sorted(self.segments,key=lambda x:x.name)]};return _hash(payload)
	def render_exps(self)->t.List[exp.Property]:
		out:t.List[exp.Property]=[exp.Property(this=exp.to_identifier(_R),value=_literal(self.measure)),exp.Property(this=exp.to_identifier(_O),value=_literal(self.ts)),exp.Property(this=exp.to_identifier(_U),value=_literal(self.granularity))]
		if self.dimensions:out.append(exp.Property(this=exp.to_identifier(_J),value=exp.Tuple(expressions=[s.render_exp()for s in sorted(self.dimensions,key=lambda x:x.name)])))
		if self.segments:out.append(exp.Property(this=exp.to_identifier(_L),value=exp.Tuple(expressions=[s.render_exp()for s in sorted(self.segments,key=lambda x:x.name)])))
		return out