from __future__ import annotations
_B='before'
_A=None
import logging,typing as t,zlib
from io import StringIO
from pathlib import Path
from sqlglot import exp
from sqlglot.dialects.dialect import UNESCAPED_SEQUENCES
from sqlglot.helper import seq_get
from sqlglot.optimizer.normalize_identifiers import normalize_identifiers
from vulcan.core.model.common import parse_bool
from vulcan.utils.pandas import columns_to_types_from_df
from vulcan.utils.pydantic import PydanticModel,field_validator
if t.TYPE_CHECKING:import pandas as pd
logger=logging.getLogger(__name__)
NaHashables=t.List[t.Union[int,str,bool,t.Literal[_A]]]
NaValues=t.Union[NaHashables,t.Dict[str,NaHashables]]
class CsvSettings(PydanticModel):
	delimiter:t.Optional[str]=_A;quotechar:t.Optional[str]=_A;doublequote:t.Optional[bool]=_A;escapechar:t.Optional[str]=_A;skipinitialspace:t.Optional[bool]=_A;lineterminator:t.Optional[str]=_A;encoding:t.Optional[str]=_A;na_values:t.Optional[NaValues]=_A;keep_default_na:t.Optional[bool]=_A
	@field_validator('doublequote','skipinitialspace','keep_default_na',mode=_B)
	@classmethod
	def _bool_validator(cls,v:t.Any)->t.Optional[bool]:
		if v is _A:return v
		return parse_bool(v)
	@field_validator('delimiter','quotechar','escapechar','lineterminator','encoding',mode=_B)
	@classmethod
	def _str_validator(cls,v:t.Any)->t.Optional[str]:
		if v is _A or not isinstance(v,exp.Expression):return v
		v=v.this;return UNESCAPED_SEQUENCES.get(v,v)
	@field_validator('na_values',mode=_B)
	@classmethod
	def _na_values_validator(cls,v:t.Any)->t.Optional[NaValues]:
		if v is _A or not isinstance(v,exp.Expression):return v
		try:
			if isinstance(v,exp.Paren)or not isinstance(v,(exp.Tuple,exp.Array)):v=exp.Tuple(expressions=[v.unnest()])
			expressions=v.expressions
			if isinstance(seq_get(expressions,0),(exp.PropertyEQ,exp.EQ)):return{e.left.name:[rhs_val.to_py()for rhs_val in([e.right.unnest()]if isinstance(e.right,exp.Paren)else e.right.expressions)]for e in expressions}
			return[e.to_py()for e in expressions]
		except ValueError as e:logger.warning(f"Failed to coerce na_values '{v}', proceeding with defaults. {str(e)}")
class CsvSeedReader:
	def __init__(self,content:str,dialect:str,settings:CsvSettings):self.content=content;self.dialect=dialect;self.settings=settings;(self._df):t.Optional[pd.DataFrame]=_A
	@property
	def columns_to_types(self)->t.Dict[str,exp.DataType]:return columns_to_types_from_df(self._get_df())
	@property
	def column_hashes(self)->t.Dict[str,str]:df=self._get_df();return{column_name:str(zlib.crc32(df[column_name].to_json().encode('utf-8')))for column_name in df.columns}
	def read(self,batch_size:t.Optional[int]=_A)->t.Generator[pd.DataFrame,_A,_A]:
		df=self._get_df();batch_size=batch_size or df.size;batch_start=0
		while batch_start<df.shape[0]:yield df.iloc[batch_start:batch_start+batch_size,:];batch_start+=batch_size
	def _get_df(self)->pd.DataFrame:
		A=False;import pandas as pd
		if self._df is _A:self._df=pd.read_csv(StringIO(self.content),index_col=A,on_bad_lines='error',low_memory=A,**{k:v for(k,v)in self.settings.dict().items()if v is not _A});self._df=self._df.rename(columns={col:normalize_identifiers(col,dialect=self.dialect).name for col in self._df.columns})
		return self._df
class Seed(PydanticModel):
	content:str
	def reader(self,dialect:str='',settings:t.Optional[CsvSettings]=_A)->CsvSeedReader:return CsvSeedReader(self.content,dialect,settings or CsvSettings())
def create_seed(path:str|Path)->Seed:
	with open(Path(path),'r',encoding='utf-8')as fd:return Seed(content=fd.read())