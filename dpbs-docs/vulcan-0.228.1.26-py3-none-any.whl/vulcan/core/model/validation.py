from __future__ import annotations
_B=False
_A=None
import typing as t
from collections import Counter
from dataclasses import dataclass,field
from functools import cached_property
from pathlib import Path
from sqlglot import ParseError,parse_one
from sqlglot import expressions as exp
from vulcan.core.dialect import extract_expression_references
from schema.filters import PolicyFilterExpression,PolicyLogicalFilter,PolicyUnaryFilter
from vulcan.core.model.definition import MetricModel,Model,SemanticModel
from vulcan.core.model.semantic import STRICT_TIMESTAMP_TYPES,_parse_qualified_reference,sql_dtype_to_logical_type
from vulcan.utils.dag import DAG
from vulcan.utils.errors import ConfigError
class JoinDAG(DAG[str]):
	@classmethod
	def from_models(cls,models:t.Iterable[Model])->JoinDAG:
		joinables=[m for m in models if isinstance(m,SemanticModel)];names={s.name for s in joinables};dag=cls()
		for s in joinables:dag.add(s.name)
		for s in joinables:
			targets=[j.name for j in s.joins if j.name in names]
			if targets:dag.add(s.name,targets)
		return dag
	def join_path_exists(self,start:str,end:str)->bool:
		if start==end:return True
		try:return end in set(self.downstream(start))or start in set(self.downstream(end))
		except ValueError:return _B
	def cycles(self)->t.List[str]:
		graph=self.graph
		if not graph:return[]
		visited:t.Set[str]=set();rec_stack:t.Set[str]=set();path:t.List[str]=[]
		def directed_cycle_from(node:str)->t.Optional[t.List[str]]:
			visited.add(node);rec_stack.add(node);path.append(node)
			for nb in sorted(graph.get(node,())):
				if nb not in visited:
					c=directed_cycle_from(nb)
					if c:return c
				elif nb in rec_stack:i=path.index(nb);return path[i:]+[nb]
			path.pop();rec_stack.remove(node)
		for n in sorted(graph):
			if n not in visited:
				cycle=directed_cycle_from(n)
				if cycle:cycle_fmt=' -> '.join(f"'{x}'"for x in cycle);return[f"Circular join dependency detected: {cycle_fmt}. Declare joins so the relationship graph between semantic models is acyclic."]
		return[]
@dataclass(frozen=True)
class Issue:
	message:str;fqn:t.Optional[str]=_A;hint:t.Optional[str]=_A
	@classmethod
	def with_fqn(cls,fqn:t.Optional[str],msg:str,*,hint:t.Optional[str]=_A)->Issue:return cls(message=msg,fqn=fqn,hint=hint)
def _resolve_name_casefold(name:str,known:t.AbstractSet[str])->t.Optional[str]:
	if name in known:return name
	folded=name.casefold();matches=[candidate for candidate in known if candidate.casefold()==folded]
	if len(matches)==1:return matches[0]
def _physical_column_type(columns:t.Mapping[str,exp.DataType],name:str)->t.Optional[exp.DataType]:resolved=_resolve_name_casefold(name,frozenset(columns));return columns.get(resolved)if resolved is not _A else _A
@dataclass(frozen=True)
class _LinkedSemantic:name:str;semantic:SemanticModel;physical:Model;physical_columns:t.Mapping[str,exp.DataType];physical_column_names:frozenset[str];dimension_names:frozenset[str];measure_names:frozenset[str];segment_names:frozenset[str];members:frozenset[str]
@dataclass
class ModelValidationContext:
	models:t.Mapping[str,Model];dialect:str;config_path:Path;default_catalog:t.Optional[str]=_A;semantic_bases:t.Dict[str,t.Tuple[SemanticModel,Model]]=field(init=_B,default_factory=dict,repr=_B);issues:t.List[Issue]=field(init=_B,default_factory=list,repr=_B)
	@cached_property
	def semantic_models(self)->t.Tuple[SemanticModel,...]:return tuple(m for m in self.models.values()if isinstance(m,SemanticModel))
	@cached_property
	def metric_models(self)->t.Tuple[MetricModel,...]:return tuple(m for m in self.models.values()if isinstance(m,MetricModel))
	@cached_property
	def semantic_by_name(self)->t.Dict[str,SemanticModel]:return{sm.name:sm for sm in self.semantic_models}
	@cached_property
	def declared_semantic_names(self)->frozenset[str]:return frozenset(self.semantic_by_name.keys())
	@cached_property
	def join_dag(self)->JoinDAG:return JoinDAG.from_models(self.models.values())
	def __post_init__(self)->_A:
		bases:t.Dict[str,t.Tuple[SemanticModel,Model]]={};dep_issues:t.List[Issue]=[]
		for sm in self.semantic_models:
			deps=sm.depends_on
			if not deps:dep_issues.append(Issue.with_fqn(sm.fqn,'semantic model has empty depends_on.'));continue
			if len(deps)!=1:dep_issues.append(Issue.with_fqn(sm.fqn,'semantic model must depend on exactly one physical model.'));continue
			dep_fqn=next(iter(deps));base=self.models.get(dep_fqn)
			if base is _A:dep_issues.append(Issue.with_fqn(sm.fqn,f"depends_on {dep_fqn!r} not found in loaded models (semantic YAML 'depends_on' must match a physical model name in this project)."));continue
			bases[sm.name]=sm,base
		self.semantic_bases=bases;self.issues=dep_issues
	def extend_issues(self,found:t.Iterable[Issue])->_A:self.issues.extend(found)
	def linked_semantic(self,semantic_name:str)->_LinkedSemantic:sm,physical=self.semantic_bases[semantic_name];physical_columns=physical.columns_to_types or{};physical_column_names=frozenset(physical_columns.keys());dimension_names=frozenset(d.name for d in sm.dimensions);measure_names=frozenset(m.name for m in sm.measures);segment_names=frozenset(s.name for s in sm.segments);members=dimension_names|measure_names|segment_names;return _LinkedSemantic(name=semantic_name,semantic=sm,physical=physical,physical_columns=physical_columns,physical_column_names=physical_column_names,dimension_names=dimension_names,measure_names=measure_names,segment_names=segment_names,members=members)
	def format_issues(self,issues:t.Optional[t.Sequence[Issue]]=_A)->str:
		rows=self.issues if issues is _A else issues;lines:t.List[str]=[]
		for issue in rows:
			prefix=self._issue_location_prefix(issue.fqn);lines.append(f"{prefix} -");lines.append(f"  {issue.message}")
			if issue.hint:lines.append(f"  HINT: {issue.hint}")
		return'\n'.join(lines)
	def _path_relative_to_config(self,path:Path)->str:
		try:return str(path.resolve().relative_to(self.config_path.resolve()))
		except ValueError:return str(path)
	def _issue_location_prefix(self,fqn:t.Optional[str])->str:
		if fqn and fqn in self.models:
			m=self.models[fqn]
			if m._path:return self._path_relative_to_config(m._path)
			return f"{m.name} ({fqn})"
		if fqn:return fqn
		return str(self.config_path)
def _strict_ts_message_and_hint(column_type:exp.DataType,field_name:str)->t.Optional[t.Tuple[str,t.Optional[str]]]:
	if not column_type:return f"'{field_name}' has unknown column type",_A
	if column_type.is_type(*STRICT_TIMESTAMP_TYPES):return
	if column_type.is_type(exp.DataType.Type.DATE):return f"'{field_name}' uses DATE type. Time dimensions require TIMESTAMP.",f"CAST({field_name} AS TIMESTAMP) AS {field_name}"
	if column_type.is_type(exp.DataType.Type.TIME):return f"'{field_name}' uses TIME type (time-of-day only). Time dimensions need full timestamps.",f"CAST(CONCAT(date_column, ' ', {field_name}) AS TIMESTAMP)"
	if column_type.is_type(exp.DataType.Type.INTERVAL):return f"'{field_name}' uses INTERVAL type (duration). Time dimensions need point-in-time values.",f"base_timestamp + {field_name}"
	return f"'{field_name}' requires TIMESTAMP type for time dimensions, got {column_type}",_A
def _qualified_refs_in_expression(expression:str,dialect:str,*,into:t.Optional[t.Type[exp.Expression]]=_A)->t.Tuple[t.Optional[t.List[t.Tuple[str,str,str]]],t.Optional[str]]:
	try:cols=extract_expression_references(expression,dialect,into=into)
	except(ParseError,ValueError)as e:return _A,str(e)
	out:t.List[t.Tuple[str,str,str]]=[]
	for col in cols:
		if not col.table or not col.name:continue
		ref=f"{col.table}.{col.name}";parsed=_parse_qualified_reference(ref)
		if not parsed:continue
		model_name,field=parsed;out.append((ref,model_name,field))
	return out,_A
def _declared_but_unresolved_msg(ctx:ModelValidationContext,model_name:str)->str:
	if model_name not in ctx.declared_semantic_names:return f"semantic model {model_name!r} is not declared (declared: {sorted(ctx.declared_semantic_names)})."
	return f"semantic model {model_name!r} is declared but has no linked physical base (check depends_on)."
def _semantic_grains(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;physical=ls.physical;sm_fqn=sm.fqn;grains_ok=bool(physical.grains);out:t.List[Issue]=[]
	if not grains_ok:out.append(Issue.with_fqn(sm_fqn,f"physical model {physical.name!r} must define grains."))
	if sm.joins and not grains_ok:out.append(Issue.with_fqn(sm_fqn,f"semantic model {ls.name!r} declares joins but physical model {physical.name!r} has no grains."))
	return out
def _semantic_dimensions(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;sm_fqn=sm.fqn;out:t.List[Issue]=[]
	if ls.physical_column_names:
		missing_dims={dim for dim in ls.dimension_names if _resolve_name_casefold(dim,ls.physical_column_names)is _A}
		if missing_dims:out.append(Issue.with_fqn(sm_fqn,f"dimensions reference unknown columns: {sorted(missing_dims)}."))
		for d in sm.dimensions:
			phys_col=_resolve_name_casefold(d.name,ls.physical_column_names)
			if d.granularities and phys_col is not _A:
				msg_hint=_strict_ts_message_and_hint(ls.physical_columns[phys_col],d.name)
				if msg_hint:msg,hint=msg_hint;out.append(Issue.with_fqn(sm_fqn,msg,hint=hint))
	return out
def _semantic_field_uniqueness(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;sm_fqn=sm.fqn;all_field_names=[m.name for m in sm.measures]+[s.name for s in sm.segments]+sorted(ls.dimension_names);dupes={n for(n,c)in Counter(all_field_names).items()if c>1}
	if not dupes:return[]
	return[Issue.with_fqn(sm_fqn,f"duplicate names across dimensions, measures, segments: {sorted(dupes)}.")]
def _semantic_measures(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;semantic_name=ls.name;sm_fqn=sm.fqn;bases=ctx.semantic_bases;out:t.List[Issue]=[]
	for measure in sm.measures:
		mname=measure.name
		for filt in measure.filters:
			qrefs,parse_err=_qualified_refs_in_expression(filt,ctx.dialect,into=exp.Condition)
			if parse_err is not _A:out.append(Issue.with_fqn(sm_fqn,f"measure {mname!r} filter could not be parsed ({parse_err}): {filt!r}."));continue
			if qrefs is _A:continue
			for(ref,model_name,field)in qrefs:
				if model_name!=semantic_name:
					if not ctx.join_dag.join_path_exists(semantic_name,model_name):out.append(Issue.with_fqn(sm_fqn,f"measure {mname!r} filter {ref!r}: no join path between {semantic_name!r} and {model_name!r}."));continue
				if model_name not in bases:out.append(Issue.with_fqn(sm_fqn,f"measure {mname!r} filter {ref!r}: {_declared_but_unresolved_msg(ctx,model_name)}"));continue
				target_ls=ctx.linked_semantic(model_name)
				if field not in target_ls.dimension_names:out.append(Issue.with_fqn(sm_fqn,f"measure {mname!r} filter {ref!r}: unknown dimension {field!r} in {model_name!r}."))
		if measure.expression.strip():
			qrefs,parse_err=_qualified_refs_in_expression(measure.expression,ctx.dialect)
			if parse_err is not _A:out.append(Issue.with_fqn(sm_fqn,f"measure {mname!r} expression could not be parsed ({parse_err})."))
			elif qrefs is not _A:
				for(ref,model_name,field)in qrefs:
					if model_name!=semantic_name:
						if not ctx.join_dag.join_path_exists(semantic_name,model_name):out.append(Issue.with_fqn(sm_fqn,f"measure {mname!r} {ref!r}: no join path between {semantic_name!r} and {model_name!r}."));continue
					if model_name not in bases:out.append(Issue.with_fqn(sm_fqn,f"measure {mname!r} {ref!r}: {_declared_but_unresolved_msg(ctx,model_name)}"));continue
					target_dims=ctx.linked_semantic(model_name).dimension_names
					if field not in target_dims:out.append(Issue.with_fqn(sm_fqn,f"measure {mname!r}: unknown dimension {field!r} in {model_name!r}."))
	return out
def _semantic_segments(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;semantic_name=ls.name;sm_fqn=sm.fqn;out:t.List[Issue]=[]
	for seg in sm.segments:
		sname=seg.name;qrefs,parse_err=_qualified_refs_in_expression(seg.expression,ctx.dialect,into=exp.Condition)
		if parse_err is not _A:out.append(Issue.with_fqn(sm_fqn,f"segment {sname!r} expression could not be parsed ({parse_err}): {seg.expression!r}."));continue
		if qrefs is _A:continue
		for(ref,model_name,field)in qrefs:
			if model_name!=semantic_name:out.append(Issue.with_fqn(sm_fqn,f"segment {sname!r} may only reference the current semantic model, not {ref!r}."))
			elif field not in ls.dimension_names:out.append(Issue.with_fqn(sm_fqn,f"segment {sname!r}: unknown dimension {field!r}."))
	return out
def _semantic_joins(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;semantic_name=ls.name;physical=ls.physical;sm_fqn=sm.fqn;bases=ctx.semantic_bases;grains_ok=bool(physical.grains);out:t.List[Issue]=[]
	for join in sm.joins:
		jn=join.name
		if jn not in ctx.declared_semantic_names:out.append(Issue.with_fqn(sm_fqn,f"join {jn!r} target is not a declared semantic model name."));continue
		if jn not in bases:out.append(Issue.with_fqn(sm_fqn,f"join {jn!r} has no linked physical model."));continue
		if not grains_ok:continue
		target_ls=ctx.linked_semantic(jn);qrefs,parse_err=_qualified_refs_in_expression(join.expression,ctx.dialect,into=exp.Condition)
		if parse_err is not _A:out.append(Issue.with_fqn(sm_fqn,f"join {jn!r} expression could not be parsed ({parse_err}): {join.expression!r}."));continue
		if qrefs is _A:continue
		for(_ref,table_name,column_name)in qrefs:
			if table_name not in(semantic_name,jn):out.append(Issue.with_fqn(sm_fqn,f"join {jn!r}: expected tables {semantic_name!r} or {jn!r}, got {table_name!r}."))
			elif table_name==semantic_name and column_name not in ls.dimension_names:out.append(Issue.with_fqn(sm_fqn,f"join {jn!r}: unknown dimension {column_name!r} for {semantic_name!r}."))
			elif table_name==jn and column_name not in target_ls.dimension_names:out.append(Issue.with_fqn(sm_fqn,f"join {jn!r}: unknown dimension {column_name!r} for {jn!r}."))
	return out
def _metric_field_and_time_checks(ctx:ModelValidationContext,mm:MetricModel,ref:str)->t.List[Issue]:
	parsed=_parse_qualified_reference(ref)
	if not parsed:return[]
	model_name,field_name=parsed;mm_fqn=mm.fqn;out:t.List[Issue]=[];ls_ref=ctx.linked_semantic(model_name);cols_t=ls_ref.physical_columns
	if field_name not in ls_ref.members:out.append(Issue.with_fqn(mm_fqn,f"unknown field {field_name!r} in semantic model {model_name!r}."))
	if ref==mm.ts:
		ct=_physical_column_type(cols_t,field_name)
		if ct:
			msg_hint=_strict_ts_message_and_hint(ct,field_name)
			if msg_hint:msg,hint=msg_hint;out.append(Issue.with_fqn(mm_fqn,msg,hint=hint))
	return out
def _metric_ref_strings(mm:MetricModel)->t.List[str]:return[mm.measure,mm.ts,*[s.ref for s in mm.dimensions],*[s.ref for s in mm.segments]]
def _metric_reference_issues(ctx:ModelValidationContext,mm:MetricModel)->t.List[Issue]:
	out:t.List[Issue]=[];mm_fqn=mm.fqn;metric_reported:t.Set[str]=set()
	for ref in _metric_ref_strings(mm):
		parsed=_parse_qualified_reference(ref)
		if not parsed:continue
		model_name,_=parsed
		if model_name not in ctx.semantic_by_name:
			if model_name not in metric_reported:metric_reported.add(model_name);out.append(Issue.with_fqn(mm_fqn,f"unknown semantic model {model_name!r} (see {ref!r}); declared: {sorted(ctx.declared_semantic_names)}."))
			continue
		if model_name not in ctx.semantic_bases:
			if model_name not in metric_reported:metric_reported.add(model_name);out.append(Issue.with_fqn(mm_fqn,f"{ref!r}: {_declared_but_unresolved_msg(ctx,model_name)}"))
			continue
		out.extend(_metric_field_and_time_checks(ctx,mm,ref))
	return out
def _metric_join_pairs(ctx:ModelValidationContext,mm:MetricModel)->t.List[Issue]:
	out:t.List[Issue]=[];resolved=list({n for ref in _metric_ref_strings(mm)if(p:=_parse_qualified_reference(ref))and(n:=p[0])in ctx.semantic_bases})
	for(i,a)in enumerate(resolved):
		for b in resolved[i+1:]:
			if not ctx.join_dag.join_path_exists(a,b):out.append(Issue.with_fqn(mm.fqn,f"no join path between semantic models {a!r} and {b!r}."))
	return out
def _validate_semantic_joins_unlinked(ctx:ModelValidationContext)->t.List[Issue]:
	out:t.List[Issue]=[];linked=frozenset(ctx.semantic_bases.keys());declared=ctx.declared_semantic_names
	for sm in ctx.semantic_models:
		if sm.name in linked:continue
		for join in sm.joins:
			jn=join.name
			if jn not in declared:out.append(Issue.with_fqn(sm.fqn,f"join {jn!r} target is not a declared semantic model name."))
	return out
def _semantic_mask_expression_issues(ctx:ModelValidationContext,ls:_LinkedSemantic,*,member_kind:str,member_name:str,expression:str)->t.List[Issue]:
	semantic_name=ls.name;sm_fqn=ls.semantic.fqn;out:t.List[Issue]=[]
	try:parsed=parse_one(expression.strip(),dialect=ctx.dialect)
	except ParseError:return out
	is_scalar_sql_literal=isinstance(parsed,(exp.Literal,exp.Null,exp.Boolean))or isinstance(parsed,exp.Neg)and isinstance(parsed.this,(exp.Literal,exp.Null,exp.Boolean))
	if is_scalar_sql_literal:return out
	qrefs,parse_err=_qualified_refs_in_expression(expression,ctx.dialect)
	if parse_err is not _A:out.append(Issue.with_fqn(sm_fqn,f"{member_kind} {member_name!r} mask_expression could not be parsed ({parse_err})."));return out
	if qrefs is _A:return out
	for(ref,model_name,field)in qrefs:
		if model_name!=semantic_name:out.append(Issue.with_fqn(sm_fqn,f"{member_kind} {member_name!r} mask_expression may only reference the current semantic model, not {ref!r}."))
		elif field not in ls.dimension_names:out.append(Issue.with_fqn(sm_fqn,f"{member_kind} {member_name!r} mask_expression: unknown dimension {field!r}."))
	return out
def _semantic_masks(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;out:t.List[Issue]=[]
	for dim in sm.dimensions:
		if isinstance(dim.mask_expression,str)and dim.mask_expression.strip():out.extend(_semantic_mask_expression_issues(ctx,ls,member_kind='dimension',member_name=dim.name,expression=dim.mask_expression))
	return out
def _policy_filter_field_names(filters:t.Iterable[PolicyFilterExpression])->t.Set[str]:
	names:t.Set[str]=set()
	for expr in filters:
		if isinstance(expr,PolicyUnaryFilter):names.add(expr.field_name)
		elif isinstance(expr,PolicyLogicalFilter):children=expr.and_ or expr.or_ or[];names.update(_policy_filter_field_names(children))
	return names
def _semantic_policies(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	sm=ls.semantic;dimension_names=ls.dimension_names;dimensions_with_mask_expression={d.name for d in sm.dimensions if d.mask_expression is not _A};out:t.List[Issue]=[]
	for policy in sm.policies:
		if policy.filter:
			unknown_filters=_policy_filter_field_names(policy.filter)-dimension_names
			if unknown_filters:out.append(Issue.with_fqn(sm.fqn,f"policy group {policy.group!r} on {ls.name!r} references unknown filter dimensions: {sorted(unknown_filters)}"))
		if policy.mask=='*':masked=dimension_names
		elif policy.mask:
			unknown_masks=set(policy.mask)-dimension_names
			if unknown_masks:out.append(Issue.with_fqn(sm.fqn,f"policy group {policy.group!r} on {ls.name!r} references unknown mask dimensions: {sorted(unknown_masks)}"))
			masked=set(policy.mask)
		else:masked=set()
		missing=sorted(masked-dimensions_with_mask_expression)
		if missing:out.append(Issue.with_fqn(sm.fqn,f"policy group {policy.group!r} on {ls.name!r} masks {missing} without mask_expression on those dimensions"))
	return out
def _semantic_measure_behaviors(ctx:ModelValidationContext,ls:_LinkedSemantic)->t.List[Issue]:
	del ctx;sm=ls.semantic;sm_fqn=sm.fqn;out:t.List[Issue]=[]
	for measure in sm.measures:
		cfg=measure.behavior
		if cfg is _A:continue
		m_name=measure.name
		if(td:=cfg.time_dimension.strip()):
			if td not in ls.dimension_names:out.append(Issue.with_fqn(sm_fqn,f"measure {m_name!r} behavior.time_dimension {td!r} is not a declared dimension."))
			elif(col_type:=_physical_column_type(ls.physical_columns,td))is not _A and sql_dtype_to_logical_type(col_type)!='time':msg,hint=_strict_ts_message_and_hint(col_type,td)or(f"'{td}' must reference a dimension with ltype 'time'.",_A);out.append(Issue.with_fqn(sm_fqn,f"measure {m_name!r} behavior.time_dimension {msg}",hint=hint))
		refs=[(field_name,name)for(field_name,raw)in(('numerator',cfg.numerator),('denominator',cfg.denominator),*(('measure_refs',r)for r in cfg.measure_refs))if(name:=raw.strip())]
		for(field_name,name)in refs:
			if name not in ls.measure_names:out.append(Issue.with_fqn(sm_fqn,f"measure {m_name!r} behavior.{field_name} {name!r} is not a declared measure."))
			elif name==m_name:out.append(Issue.with_fqn(sm_fqn,f"measure {m_name!r} behavior.{field_name} must not reference the measure itself."))
	return out
def _validate_semantics(ctx:ModelValidationContext)->t.List[Issue]:
	out:t.List[Issue]=[]
	for msg in ctx.join_dag.cycles():out.append(Issue.with_fqn(_A,msg))
	out.extend(_validate_semantic_joins_unlinked(ctx))
	for semantic_name in ctx.semantic_bases:
		ls=ctx.linked_semantic(semantic_name)
		for fn in(_semantic_grains,_semantic_dimensions,_semantic_field_uniqueness,_semantic_measures,_semantic_measure_behaviors,_semantic_segments,_semantic_joins,_semantic_masks,_semantic_policies):out.extend(fn(ctx,ls))
	return out
def _validate_metrics(ctx:ModelValidationContext)->t.List[Issue]:
	out:t.List[Issue]=[]
	for mm in ctx.metric_models:
		for fn in(_metric_reference_issues,_metric_join_pairs):out.extend(fn(ctx,mm))
	return out
def validate_owners(models:t.Mapping[str,Model],*,users:t.Sequence[str],config_path:Path)->_A:
	known=frozenset(username for user in users if(username:=user.strip()));issues:t.List[Issue]=[]
	for model in models.values():
		owner=(model.owner or'').strip()
		if not owner:issues.append(Issue.with_fqn(model.fqn,'Model is missing an owner.',hint='Set `owner` on the model or in `model_defaults.owner`.'))
		elif owner not in known:known_str=', '.join(sorted(known))or'(none)';issues.append(Issue.with_fqn(model.fqn,f"Model owner '{owner}' is not listed in config.users.",hint=f"Known users: {known_str}"))
	if issues:ctx=ModelValidationContext(models=models,dialect='',config_path=config_path);ctx.extend_issues(issues);raise ModelValidationError(ctx)
class ModelValidationError(ConfigError):
	def __init__(self,ctx:ModelValidationContext)->_A:self.ctx=ctx;text='Model validation failed:\n'+ctx.format_issues()if ctx.issues else'Model validation failed.';super().__init__(text,location=ctx.config_path)
	@property
	def issues(self)->t.List[Issue]:return self.ctx.issues
def validate(models:t.Mapping[str,Model],*,dialect:str,config_path:Path,default_catalog:t.Optional[str]=_A)->_A:
	ctx=ModelValidationContext(models=models,dialect=dialect,config_path=config_path,default_catalog=default_catalog)
	if ctx.semantic_models or ctx.metric_models:ctx.extend_issues(_validate_semantics(ctx));ctx.extend_issues(_validate_metrics(ctx))
	if ctx.issues:raise ModelValidationError(ctx)