from __future__ import annotations
_c='dimensions'
_b='profiles'
_a='dimension cannot be empty'
_Z='dimension is required'
_Y='uniqueness'
_X='conformity'
_W='timeliness'
_V='warned'
_U='failed'
_T='passed'
_S='filter'
_R='depends_on'
_Q='description'
_P='before'
_O='expression'
_N='completeness'
_M='dim'
_L='not_evaluated'
_K='rules'
_J='yellow'
_I='dimension'
_H='validity'
_G='red'
_F=False
_E='name'
_D=True
_C='_'
_B='accuracy'
_A=None
import hashlib,json,re,typing as t
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING
from pydantic import ConfigDict,Field,PrivateAttr,TypeAdapter,ValidationError,field_validator,model_validator
from soda.execution.check.profile_columns_run import ProfileColumnsResultTable
from sqlglot import exp
from vulcan.core.dialect import normalize_identifier
from vulcan.core.soda3 import _NAME_ATTR_KEY,_DESCRIPTION_ATTR_KEY,_DIMENSION_ATTR_KEY
from vulcan.utils.hashing import hash_data
from vulcan.utils.pydantic import PydanticModel
from vulcan.utils.yaml import dump as yaml_dump
if TYPE_CHECKING:from rich.tree import Tree;from sqlglot.dialects.dialect import DialectType
from schema.types import DQDimension as DQDimension
_DQ_DIMENSION_ADAPTER:TypeAdapter[DQDimension]=TypeAdapter(DQDimension)
_VALID_RULE_NAME=re.compile('^[a-zA-Z][a-zA-Z0-9_]{0,63}$')
_SIMPLE_EXTRA_KEY=re.compile('^[a-zA-Z_][a-zA-Z0-9_]*$')
_CHECK_PATTERN_DEFAULTS:t.List[t.Tuple[re.Pattern[str],DQDimension]]=[(re.compile('^change(?:\\s+same day last week|\\s+avg last \\d+)?\\s+for\\s+',re.IGNORECASE),_W),(re.compile('^anomaly detection for\\s+',re.IGNORECASE),_B),(re.compile('^failed rows$',re.IGNORECASE),_H),(re.compile('^schema(?:\\s+evolution)?$',re.IGNORECASE),_X),(re.compile('^freshness\\s*\\(',re.IGNORECASE),_W),(re.compile('^values in .+ must exist in ',re.IGNORECASE),'consistency'),(re.compile('^distribution(?:_difference)?\\s*\\(',re.IGNORECASE),_X)]
_METRIC_DEFAULTS:t.Dict[str,DQDimension]={'row_count':_N,'missing_count':_N,'missing_percent':_N,'duplicate_count':_Y,'duplicate_percent':_Y,'invalid_count':_H,'invalid_percent':_H,'valid_count':_H,'avg':_B,'min':_B,'max':_B,'sum':_B,'min_length':_B,'max_length':_B,'avg_length':_B,'stddev':_B,'stddev_pop':_B,'stddev_samp':_B,'variance':_B,'var_pop':_B,'var_samp':_B,'percentile':_B}
_LEADING_METRIC_RE=re.compile('^([a-z][a-z0-9_]*)\\s*(?:\\(|(?=\\s*[<>=!]))',re.IGNORECASE)
_FALLBACK_DIMENSION:DQDimension=_H
def validate_dq_dimension(value:t.Any)->DQDimension:
	if value is _A:raise ValueError(_Z)
	if not isinstance(value,str):raise ValueError(f"invalid dq dimension {value!r}")
	normalized=value.lower().strip()
	if not normalized:raise ValueError(_a)
	try:return _DQ_DIMENSION_ADAPTER.validate_python(normalized)
	except ValidationError as e:raise ValueError(f"invalid dq dimension {value!r}")from e
def _stable_hash(obj:t.Any)->str:return hash_data([json.dumps(obj,sort_keys=_D,default=str)])
def _generate_check_name(expression:str,existing_names:t.Set[str])->str:
	replacements={'>=':'_gte_','<=':'_lte_','!=':'_ne_','>':'_gt_','<':'_lt_','=':'_eq_',' ':_C,'(':_C,')':'',',':_C,'.':_C,'-':_C,'/':_C,'*':_C,'+':_C};sanitized=expression
	for(old,new)in replacements.items():sanitized=sanitized.replace(old,new)
	sanitized=re.sub('[^a-zA-Z0-9_]',_C,sanitized);sanitized=re.sub('_+',_C,sanitized);sanitized=sanitized.strip(_C).lower()
	if not sanitized:sanitized='check'
	elif not sanitized[0].isalpha():sanitized=f"check_{sanitized}"
	if len(sanitized)>64:digest=hashlib.md5(expression.encode(),usedforsecurity=_F).hexdigest()[:4];sanitized=f"{sanitized[:59]}_{digest}"
	if sanitized not in existing_names:return sanitized
	counter=2
	while _D:
		suffix=f"_{counter}";max_base=64-len(suffix);base=sanitized[:max_base].rstrip(_C)or'c'
		if not base[0].isalpha():base=f"c{base[1:]}".rstrip(_C)[:max_base]or'c'
		candidate=f"{base}{suffix}"
		if candidate not in existing_names:return candidate
		counter+=1
def _dq_text(s:str)->exp.Expression:return exp.Identifier(this=s,quoted=_D)
def _dq_extra_key_exp(key:str)->exp.Expression:
	if _SIMPLE_EXTRA_KEY.match(key):return exp.to_identifier(key)
	return exp.Identifier(this=key,quoted=_D)
def _dq_extra_value_to_exp(val:t.Any)->exp.Expression:
	if val is _A:return exp.null()
	if isinstance(val,bool):return exp.true()if val else exp.false()
	if isinstance(val,int):return exp.Literal.number(val)
	if isinstance(val,float):return exp.Literal.number(val)
	if isinstance(val,str):return _dq_text(val)
	if isinstance(val,dict):
		parts:t.List[exp.Expression]=[]
		for k in sorted(val.keys()):parts.append(exp.Kwarg(this=_dq_extra_key_exp(str(k)),value=_dq_extra_value_to_exp(val[k])))
		return exp.Tuple(expressions=parts)
	if isinstance(val,(list,tuple)):return exp.Tuple(expressions=[_dq_extra_value_to_exp(x)for x in val])
	return _dq_text(str(val))
class QualityRule(PydanticModel):
	name:str;expression:str;dimension:DQDimension;description:t.Optional[str]=_A;extra:t.Dict[str,t.Any]=Field(default_factory=dict)
	@field_validator(_E)
	@classmethod
	def _name(cls,v:str)->str:
		if not _VALID_RULE_NAME.match(v):raise ValueError(f"Invalid dq rule name {v!r}. Names must start with a letter, contain only letters, numbers, and underscores, and be at most 64 characters.")
		return v
	@field_validator(_O)
	@classmethod
	def _expression(cls,v:str)->str:
		s=str(v).strip()
		if not s:raise ValueError('expression cannot be empty')
		return s
	@field_validator(_I,mode=_P)
	@classmethod
	def _dimension(cls,v:t.Any)->DQDimension:
		if v is _A:raise ValueError(_Z)
		s=str(v).lower().strip()
		if not s:raise ValueError(_a)
		try:return _DQ_DIMENSION_ADAPTER.validate_python(s)
		except ValidationError as e:raise ValueError(f"invalid dq dimension {v!r}")from e
	@field_validator(_Q)
	@classmethod
	def _description(cls,v:t.Any)->t.Optional[str]:
		if v is _A:return
		s=str(v).strip();return s or _A
	@model_validator(mode='after')
	def _failed_rows_requires_fail_query(self)->'QualityRule':
		if self.expression.strip().lower()=='failed rows':
			rb=self.extra;fq=rb.get('fail query')or rb.get('fail_query')
			if not fq or not str(fq).strip():raise ValueError(f"DQ rule {self.name!r}: for expression 'failed rows', extra must include non-empty 'fail query' (or 'fail_query').")
		return self
	def data_hash(self)->str:raw=self.model_dump(mode='json',exclude_none=_D,exclude={_Q});return _stable_hash(raw)
	def metadata_hash(self)->str:raw=self.model_dump(mode='json',exclude_none=_D,include={_E,_Q});return _stable_hash(raw)
	def render_exp(self)->exp.Expression:
		inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier(_E),value=exp.to_identifier(self.name)),exp.Property(this=exp.to_identifier(_I),value=exp.to_identifier(str(self.dimension)))]
		for k in sorted(self.extra.keys()):inner.append(exp.Property(this=_dq_extra_key_exp(str(k)),value=_dq_extra_value_to_exp(self.extra[k])))
		return exp.EQ(this=exp.Identifier(this=self.expression.strip(),quoted=_D),expression=exp.Tuple(expressions=inner))
class DataQualitySpec(PydanticModel):
	kind:t.Literal['dq']='dq';name:t.Optional[str]=_A;depends_on:str=Field(min_length=1);filter:t.Optional[str]=_A;profiles:t.List[str]=Field(default_factory=list);rules:t.List[QualityRule]=Field(min_length=1);_path:t.Optional[Path]=PrivateAttr(default=_A);_rel_path:t.Optional[Path]=PrivateAttr(default=_A)
	@field_validator(_R,mode=_P)
	@classmethod
	def _strip_depends(cls,v:t.Any)->str:
		s=str(v).strip()
		if not s:raise ValueError('depends_on cannot be empty')
		return s
	@field_validator(_K)
	@classmethod
	def _unique_rule_names(cls,rules:t.List[QualityRule])->t.List[QualityRule]:
		seen:t.Set[str]=set()
		for r in rules:
			if r.name in seen:raise ValueError(f"Duplicate DQ rule name: {r.name!r}")
			seen.add(r.name)
		return rules
	def data_hash(self)->str:rules_sorted=sorted(self.rules,key=lambda r:r.name);payload={'kind':self.kind,_R:self.depends_on,_S:self.filter,_b:sorted(self.profiles),_K:[r.data_hash()for r in rules_sorted]};return _stable_hash(payload)
	def metadata_hash(self)->str:rules_sorted=sorted(self.rules,key=lambda r:r.name);payload={_E:self.name,_K:[r.metadata_hash()for r in rules_sorted]};return _stable_hash(payload)
	def render_exp(self)->exp.Expression:
		dq_path=getattr(self,'_rel_path',_A)or getattr(self,'_path',_A);inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier('kind'),value=exp.to_identifier(self.kind)),exp.Property(this=exp.to_identifier(_R),value=_dq_text(self.depends_on)),exp.Property(this=exp.to_identifier('file'),value=_dq_text(str(dq_path)))]
		if self.name is not _A:inner.append(exp.Property(this=exp.to_identifier(_E),value=_dq_text(self.name)))
		if self.filter is not _A:inner.append(exp.Property(this=exp.to_identifier(_S),value=_dq_text(self.filter)))
		if self.profiles:inner.append(exp.Property(this=exp.to_identifier(_b),value=exp.Tuple(expressions=[_dq_text(p)for p in sorted(self.profiles)])))
		rules_render_order=sorted(self.rules,key=lambda r:(r.expression,r.name));inner.append(exp.Property(this=exp.to_identifier(_K),value=exp.Tuple(expressions=[r.render_exp()for r in rules_render_order])));return exp.Tuple(expressions=inner)
class CheckExecutionSummary(PydanticModel):
	results:t.Dict[str,t.Dict[str,t.Any]]=Field(default_factory=dict)
	def format_tree(self,verbosity:int=0)->'Tree':
		B='warned_checks';A='failed_checks';from rich.tree import Tree;model_count=len(self.results);tree=Tree(f"[bold]Check Executions[/bold] ({model_count} Models)")
		for(model_name,model_data)in sorted(self.results.items()):
			filter_expr=model_data.get(_S);model_label=f"[bold]{model_name}[/bold]"
			if filter_expr:model_label+=f" (filter: {filter_expr})"
			model_branch=tree.add(model_label);dimensions=model_data.get(_c,{})
			for(dimension,stats)in sorted(dimensions.items()):
				passed=stats[_T];failed=stats[_U];warned=stats[_V];not_evaluated=stats[_L];total=passed+failed+warned+not_evaluated
				if not_evaluated==total:symbol='~';style=_M
				elif failed>0 or warned>0:symbol='✗';style=_G
				else:symbol='✓';style='green'
				label=f"[bold]{dimension}[/bold] ({passed}/{total})";details=[]
				if failed>0:details.append(f"{failed} failed")
				if warned>0:details.append(f"{warned} warned")
				if not_evaluated>0:details.append(f"{not_evaluated} not evaluated")
				if details:label+=f" - {', '.join(details)}"
				dimension_branch=model_branch.add(f"[{style}]{symbol}[/{style}] {label}");has_issues=failed>0 or warned>0
				if verbosity==0:0
				elif verbosity==1:
					if has_issues:
						failed_checks=stats.get(A,[]);warned_checks=stats.get(B,[])
						for check in failed_checks:self._add_check_to_tree(dimension_branch,check,_G,show_sql=_F)
						for check in warned_checks:self._add_check_to_tree(dimension_branch,check,_J,show_sql=_F)
				elif verbosity>=2:
					failed_checks=stats.get(A,[]);warned_checks=stats.get(B,[]);not_evaluated_checks=stats.get('not_evaluated_checks',[])
					for check in failed_checks:self._add_check_to_tree(dimension_branch,check,_G,show_sql=_D)
					for check in warned_checks:self._add_check_to_tree(dimension_branch,check,_J,show_sql=_D)
					for check in not_evaluated_checks:self._add_check_to_tree(dimension_branch,check,_M,show_sql=_F)
					if passed>0:dimension_branch.add(f"[dim]+ {passed} passed checks[/dim]")
		return tree
	def _add_check_to_tree(self,parent_branch:'Tree',check:t.Dict[str,t.Any],status_style:str,show_sql:bool=_F)->_A:
		A='definition'
		if status_style==_G:status_symbol='✗'
		elif status_style==_J:status_symbol='⚠'
		elif status_style==_M:status_symbol='~'
		else:status_symbol='✓'
		check_name=check.get(_NAME_ATTR_KEY,'unnamed');check_branch=parent_branch.add(f"[{status_style}]{status_symbol} {check_name}[/{status_style}]");reasons=check.get('outcome_reasons',[])
		if reasons:
			reason=reasons[0]if isinstance(reasons,list)else reasons
			if isinstance(reason,dict):msg=reason.get('message',str(reason))
			else:msg=str(reason)
		elif status_style==_G:msg=f"Check failed: {check.get(A,check_name)}"
		elif status_style==_J:msg=f"Check warning: {check.get(A,check_name)}"
		elif status_style==_M:msg='Check could not be evaluated'
		else:msg=_A
		if msg:check_branch.add(f"[{status_style}]→ {msg}[/{status_style}]")
		if(value:=check.get('value'))is not _A:check_branch.add(f"[dim]Measured: {value}[/dim]")
		if show_sql:
			if(query:=check.get('query')):
				query_branch=check_branch.add('[dim]Query:[/dim]');query_lines=query.strip().split('\n')
				for line in query_lines[:10]:query_branch.add(f"[dim cyan]{line}[/dim cyan]")
				if len(query_lines)>10:query_branch.add(f"[dim]... ({len(query_lines)-10} more lines)[/dim]")
	def summarize(self)->str:
		total_checks=0;passed_checks=0;failed_checks=0;warned_checks=0;not_evaluated_checks=0
		for model_data in self.results.values():
			for stats in model_data.get(_c,{}).values():total_checks+=stats[_T]+stats[_U]+stats[_V]+stats[_L];passed_checks+=stats[_T];failed_checks+=stats[_U];warned_checks+=stats[_V];not_evaluated_checks+=stats[_L]
		summary=f"\n[bold]Quality Summary:[/bold] [green]{passed_checks} passed[/green] | [red]{failed_checks} failed[/red]"
		if warned_checks>0:summary+=f" | [yellow]{warned_checks} warned[/yellow]"
		if not_evaluated_checks>0:summary+=f" | [dim]{not_evaluated_checks} not evaluated[/dim]"
		summary+=f" ({total_checks} total)";pass_rate=passed_checks/total_checks*1e2 if total_checks>0 else 1e2;score_style='green'if pass_rate>=90 else _J if pass_rate>=70 else _G;summary+=f"\n[bold]Score:[/bold] [{score_style}]{pass_rate:.1f}%[/{score_style}]\n";return summary
class SchemaStats(t.NamedTuple):tables:int;columns:int
class SchemaProfileResult(t.TypedDict):prefix:str;profiles:t.List[ProfileColumnsResultTable];table_to_model_name:t.Dict[str,str]
class ScanResults(t.TypedDict,total=_F):scanId:str;definitionName:str;defaultDataSource:str;dataTimestamp:t.Optional[int];scanStartTimestamp:int;scanEndTimestamp:int;hasErrors:bool;hasWarnings:bool;hasFailures:bool;sodaCoreVersion:str;checks:t.List[t.Dict[str,t.Any]];automatedMonitoringChecks:t.List[t.Dict[str,t.Any]];metrics:t.List[t.Dict[str,t.Any]];profiling:t.List[t.Dict[str,t.Any]];queries:t.List[t.Dict[str,t.Any]];metadata:t.List[t.Dict[str,t.Any]];logs:t.List[t.Dict[str,t.Any]]
class ProfileExecutionSummary(PydanticModel):
	run_id:str;environment:str;model_profiles:t.Dict[str,t.List[str]];prefix_stats:t.Dict[str,SchemaStats]
	def summarize(self,verbosity:int=0)->str:
		model_count=len(self.model_profiles);total_columns=sum(len(cols)for cols in self.model_profiles.values());lines=[f"\n[bold]Profiled {model_count} model{'s'if model_count!=1 else''}[/bold] ({total_columns} columns):"]
		for model_name in sorted(self.model_profiles.keys()):
			columns=self.model_profiles[model_name];col_count=len(columns)
			if verbosity>=1:
				sorted_columns=sorted(columns)
				if len(sorted_columns)<=5:col_list=', '.join(sorted_columns)
				else:col_list=', '.join(sorted_columns[:5]);remaining=len(sorted_columns)-5;col_list+=f", ... (+{remaining} more)"
				lines.append(f"  ✓ [bold]{model_name}[/bold]: {col_list}")
			else:lines.append(f"  ✓ [bold]{model_name}[/bold]: {col_count} columns")
		return'\n'.join(lines)
class CheckOutcome(str,Enum):PASS='pass';WARN='warn';FAIL='fail';ERROR='error';NOT_EVALUATED=_L
class CheckMetadata(PydanticModel):
	model_config=ConfigDict(populate_by_name=_D);check_identity:str;check_name:t.Optional[str]=Field(default=_A,alias=_E,serialization_alias='check_name');check_type:t.Optional[str]=Field(default=_A,alias='type',serialization_alias='check_type');column_name:t.Optional[str]=Field(default=_A,alias='column',serialization_alias='column_name');dimension:DQDimension;definition:t.Optional[str]=_A;model_name:t.Optional[str]=_A
	@field_validator(_I,mode=_P)
	@classmethod
	def _validate_dimension(cls,v:t.Any)->DQDimension:return validate_dq_dimension(v)
class CheckResult(CheckMetadata):outcome:CheckOutcome;outcome_reasons:t.Optional[t.Dict[str,t.Any]]=_A;diagnostics:t.Dict[str,t.Any]=Field(default_factory=dict)
class CheckResultWithRunId(CheckResult):run_id:str;start_ts:int;end_ts:t.Optional[int]=_A
class CheckRuns(CheckMetadata):runs:t.List[CheckResultWithRunId]=Field(default_factory=list)
class FieldStatistics(PydanticModel):model_config=ConfigDict(extra='allow',populate_by_name=_D);min:t.Optional[t.Union[float,int]]=_A;max:t.Optional[t.Union[float,int]]=_A;avg:t.Optional[float]=_A;sum:t.Optional[t.Union[float,int]]=_A;stddev:t.Optional[float]=_A;variance:t.Optional[float]=_A;distinct:t.Optional[int]=Field(default=_A,alias='distinct_count');distinct_count:t.Optional[int]=_A;missing_count:t.Optional[int]=_A;null_count:t.Optional[int]=_A;duplicate_count:t.Optional[int]=_A;min_length:t.Optional[int]=_A;max_length:t.Optional[int]=_A;avg_length:t.Optional[float]=_A;stddev_length:t.Optional[float]=_A;frequent_values:t.Optional[t.List[t.Dict[str,t.Any]]]=_A;histogram:t.Optional[t.Dict[str,t.Any]]=_A;quantiles:t.Optional[t.Dict[str,t.Any]]=_A
class ModelProfile(PydanticModel):model_config=ConfigDict(extra='allow');model_name:str;profiled_at:t.Optional[int]=_A;row_count:t.Optional[int]=_A;columns:t.Dict[str,FieldStatistics]=Field(default_factory=dict)
class QualitySummary(PydanticModel):model_config=ConfigDict(populate_by_name=_D);pass_:int=Field(alias='pass');fail:int;warn:int;error:int;not_evaluated:int;total:int;pass_rate:float
class ProductQualitySummary(PydanticModel):environment:str;as_of_ts:t.Optional[int]=_A;latest_evaluated_at:int;checks_count:int;dimensions:t.Dict[DQDimension,QualitySummary]=Field(default_factory=dict);summary:QualitySummary
def _table_alias(model_name:str,dialect:t.Optional['DialectType']=_A)->str:return normalize_identifier(model_name.split('.')[-1],dialect=dialect)
def _rule_to_soda_check(rule:QualityRule)->t.Dict[str,t.Any]:
	A='attributes';expr=rule.expression;body=dict(rule.extra);body[_NAME_ATTR_KEY]=rule.name;attributes:t.Dict[str,t.Any]=dict(body.get(A)or{});attributes[_DIMENSION_ATTR_KEY]=rule.dimension
	if rule.description:attributes[_DESCRIPTION_ATTR_KEY]=rule.description
	body[A]=attributes;return{expr:body}
def _infer_dq_dimension(expression:str)->DQDimension:
	expr=expression.strip()
	if not expr:return _FALLBACK_DIMENSION
	for(pattern,dimension)in _CHECK_PATTERN_DEFAULTS:
		if pattern.search(expr):return dimension
	metric_match=_LEADING_METRIC_RE.match(expr)
	if metric_match:
		metric_name=metric_match.group(1).lower()
		if metric_name in _METRIC_DEFAULTS:return _METRIC_DEFAULTS[metric_name]
	return _FALLBACK_DIMENSION
def _dq_optional_str(v:t.Any)->t.Optional[str]:
	if v is _A:return
	s=str(v).strip();return s or _A
def _dq_merge_inline_extra(body:t.Dict[str,t.Any])->_A:
	nested=body.pop('extra',_A)
	if isinstance(nested,dict):body.update({**nested,**body})
def _resolve_rule_dimension(expression:str,dimension_by_author:t.Any)->DQDimension:
	explicit=_dq_optional_str(dimension_by_author)
	if explicit is not _A:
		try:return _DQ_DIMENSION_ADAPTER.validate_python(explicit)
		except ValidationError as e:raise ValueError(f"invalid dq dimension {dimension_by_author!r}")from e
	return _infer_dq_dimension(expression)
def _coerce_dq_rule_item(item:t.Any,label:str,used_names:t.Set[str])->QualityRule:
	if isinstance(item,QualityRule):return item
	if isinstance(item,str):
		expr=item.strip()
		if not expr:raise ValueError(f"{label}: rule expression cannot be empty")
		return QualityRule(name=_generate_check_name(expr,used_names),expression=expr,dimension=_resolve_rule_dimension(expr,_A),extra={})
	if not isinstance(item,dict):raise ValueError(f'{label}: each rule must be a string, a one-key mapping ("<expression>": {{{{config}}}}), or a flat dict with keys name, expression, dimension, description, extra')
	if _O in item:
		payload=dict(item);expr=str(payload.get(_O,'')).strip()
		if _dq_optional_str(payload.get(_E))is _A:payload[_E]=_generate_check_name(expr,used_names)
		if _dq_optional_str(payload.get(_I))is _A:payload[_I]=_resolve_rule_dimension(expr,_A)
		try:return QualityRule.model_validate(payload)
		except Exception as e:raise ValueError(f"{label}: {e}")from e
	if len(item)!=1:raise ValueError(f'{label}: each rule must be a string, a one-key mapping ("<expression>": {{{{config}}}}), or a flat dict with keys name, expression, dimension, description, extra')
	expr_key,inner=next(iter(item.items()))
	if inner is not _A and not isinstance(inner,dict):raise ValueError(f"{label}: rule configuration must be a mapping or null")
	extra={}if inner is _A else dict(inner);name_raw=extra.pop(_NAME_ATTR_KEY,_A);dimension_by_author=extra.pop(_DIMENSION_ATTR_KEY,_A);description=_dq_optional_str(extra.pop(_DESCRIPTION_ATTR_KEY,_A));_dq_merge_inline_extra(extra);expr=str(expr_key).strip();name=_generate_check_name(expr,used_names)if _dq_optional_str(name_raw)is _A else str(name_raw).strip();dimension_value=_resolve_rule_dimension(expr,dimension_by_author)
	try:return QualityRule(name=name,expression=expr,dimension=dimension_value,description=description,extra=extra)
	except Exception as e:raise ValueError(f"{label}: {e}")from e
def build_dq_rules(raw_rules:t.List[t.Any])->t.List[QualityRule]:
	out:t.List[QualityRule]=[];used_names:t.Set[str]=set()
	for(i,item)in enumerate(raw_rules):rule=_coerce_dq_rule_item(item,f"rules[{i}]",used_names);out.append(rule);used_names.add(rule.name)
	return out
def build_sodacl_yaml(spec:DataQualitySpec,model_name:str)->str:
	table_alias=_table_alias(model_name);soda_checks=[_rule_to_soda_check(r)for r in spec.rules];dataset_filter=spec.filter.strip()if spec.filter else _A
	if dataset_filter:fname=f"{table_alias.replace('.',_C)}_filter";parts={f"filter {table_alias} [{fname}]":{'where':dataset_filter},f"checks for {table_alias} [{fname}]":soda_checks}
	else:parts={f"checks for {table_alias}":soda_checks}
	combined:t.Dict[str,t.Any]=dict(parts)
	if spec.profiles:cols=[f"{table_alias}.{c}"for c in spec.profiles];combined['profile columns']={'columns':cols}
	return yaml_dump(combined)