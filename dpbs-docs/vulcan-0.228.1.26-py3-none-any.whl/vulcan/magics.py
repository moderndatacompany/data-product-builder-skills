from __future__ import annotations
_f='--model'
_e='--limit'
_d='--migrate'
_c='--ignore-cron'
_b='Select specific model changes that should be included in the plan.'
_a='--dialect'
_Z='--dlt-path'
_Y='context'
_X='Verbose output. Use -vv for very verbose.'
_W='count'
_V='--verbose'
_U='End date to render.'
_T='Start date to render.'
_S='-v'
_R='The model.'
_Q='utf-8'
_P='-t'
_O=False
_N='--select-model'
_M='environment'
_L='Execution time.'
_K='--execution-time'
_J='?'
_I='-e'
_H='--end'
_G='-s'
_F='--start'
_E='model'
_D=True
_C='*'
_B='store_true'
_A=None
from io import StringIO
import functools,logging,typing as t
from collections import defaultdict
from pathlib import Path
from hyperscript import h
try:from IPython.core.display import display
except ImportError:from IPython.display import display
from IPython.core.magic import Magics,cell_magic,line_cell_magic,line_magic,magics_class
from IPython.core.magic_arguments import argument,magic_arguments,parse_argstring
from rich.jupyter import JupyterRenderable
from vulcan.cli.project_init import ProjectTemplate,init_example_project
from vulcan.core.config import load_configs
from vulcan.core.config.connection import INIT_DISPLAY_INFO_TO_TYPE
from vulcan.core.console import create_console,set_console,configure_console
from vulcan.core.context import Context
from vulcan.core.dialect import format_model_expressions,parse
from vulcan.core.model import load_sql_based_model
from vulcan.core.test import ModelTestMetadata
from vulcan.utils import yaml,Verbosity,optional_import
from vulcan.utils.errors import MagicError,MissingContextException,VulcanError
logger=logging.getLogger(__name__)
CONTEXT_VARIABLE_NAMES=[_Y,'ctx','vulcan']
def pass_vulcan_context(func:t.Callable)->t.Callable:
	@functools.wraps(func)
	def wrapper(self:VulcanMagics,*args:t.Any,**kwargs:t.Any)->_A:
		for variable_name in CONTEXT_VARIABLE_NAMES:
			context=self._shell.user_ns.get(variable_name)
			if isinstance(context,Context):break
		else:raise MissingContextException(f"Context must be defined and initialized with one of these names: {', '.join(CONTEXT_VARIABLE_NAMES)}")
		old_console=context.console;new_console=create_console(display=self.display);context.console=new_console;set_console(new_console);context.refresh();func(self,context,*args,**kwargs);context.console=old_console;set_console(old_console)
	return wrapper
def format_arguments(func:t.Callable)->t.Callable:func=argument('--normalize',action=_B,help='Whether or not to normalize identifiers to lowercase.',default=_A)(func);func=argument('--pad',type=int,help='Determines the pad size in a formatted string.')(func);func=argument('--indent',type=int,help='Determines the indentation size in a formatted string.')(func);func=argument('--normalize-functions',type=str,help="Whether or not to normalize all function names. Possible values are: 'upper', 'lower'")(func);func=argument('--leading-comma',action=_B,help='Determines whether or not the comma is leading or trailing in select expressions. Default is trailing.',default=_A)(func);func=argument('--max-text-width',type=int,help='The max number of characters in a segment before creating new lines in pretty mode.')(func);return func
@magics_class
class VulcanMagics(Magics):
	@property
	def display(self)->t.Callable:
		from vulcan import RuntimeEnv
		if RuntimeEnv.get().is_databricks:return self._shell.user_ns['display']
		return display
	@property
	def _shell(self)->t.Any:
		if not self.shell:raise RuntimeError('IPython Magics are in invalid state')
		return self.shell
	@magic_arguments()
	@argument('paths',type=str,nargs='+',default='',help='The path(s) to the Vulcan project(s).')
	@argument('--config',type=str,help='Name of the config object. Only applicable to configuration defined using Python script.')
	@argument('--gateway',type=str,help='The name of the gateway.')
	@argument('--ignore-warnings',action=_B,help='Ignore warnings.')
	@argument('--debug',action=_B,help='Enable debug mode.')
	@argument('--log-file-dir',type=str,help='The directory to write the log file to.')
	@argument('--dotenv',type=str,help='Path to a custom .env file to load environment variables from.')
	@line_magic
	def context(self,line:str)->_A:
		from vulcan import configure_logging,remove_excess_logs;args=parse_argstring(self.context,line);log_file_dir=args.log_file_dir;configure_logging(args.debug,log_file_dir=log_file_dir,ignore_warnings=args.ignore_warnings);configure_console(ignore_warnings=args.ignore_warnings);dotenv_path=Path(args.dotenv)if args.dotenv else _A;configs=load_configs(args.config,Context.CONFIG_TYPE,args.paths,dotenv_path=dotenv_path);log_limit=list(configs.values())[0].log_limit;remove_excess_logs(log_file_dir,log_limit)
		try:context=Context(paths=args.paths,config=configs,gateway=args.gateway);self._shell.user_ns[_Y]=context
		except Exception:
			if args.debug:logger.exception('Failed to initialize Vulcan context')
			raise
		context.console.log_success(f"Vulcan project context set to: {', '.join(args.paths)}")
	@magic_arguments()
	@argument('path',type=str,help='The path where the new Vulcan project should be created.')
	@argument('engine',type=str,help=f"Project SQL engine. Supported values: '{', '.join([info[1]for info in sorted(INIT_DISPLAY_INFO_TO_TYPE.values(),key=(lambda x:x[0]))])}'.")
	@argument('--template',_P,type=str,help='Project template. Supported values: dbt, default, empty.')
	@argument('--dlt-pipeline',type=str,help='DLT pipeline for which to generate a Vulcan project. Use alongside template: dlt')
	@argument(_Z,type=str,help='The directory where the DLT pipeline resides. Use alongside template: dlt')
	@line_magic
	def init(self,line:str)->_A:
		args=parse_argstring(self.init,line)
		try:project_template=ProjectTemplate(args.template.lower()if args.template else'default')
		except ValueError:raise MagicError(f"Invalid project template '{args.template}'")
		init_example_project(path=args.path,engine_type=args.engine,dialect=_A,template=project_template,pipeline=args.dlt_pipeline,dlt_path=args.dlt_path);html=str(h('div',h('span',{'style':{'color':'green','font-weight':'bold'}},'Vulcan project scaffold created')));self.display(JupyterRenderable(html=html,text=''))
	@magic_arguments()
	@argument(_E,type=str,help=_R)
	@argument(_F,_G,type=str,help=_T)
	@argument(_H,_I,type=str,help=_U)
	@argument(_K,type=str,help=_L)
	@argument(_a,'-d',type=str,help='The rendered dialect.')
	@line_cell_magic
	@pass_vulcan_context
	def model(self,context:Context,line:str,sql:t.Optional[str]=_A)->_A:
		args=parse_argstring(self.model,line);model=context.get_model(args.model,raise_if_missing=_D);config=context.config_for_node(model)
		if sql:
			expressions=parse(sql,default_dialect=config.dialect);loaded=load_sql_based_model(expressions,macros=context._macros,jinja_macros=context._jinja_macros,path=model._path,dialect=config.dialect,time_column_format=config.time_column_format,physical_schema_mapping=context.config.physical_schema_mapping,default_catalog=context.default_catalog)
			if loaded.name==args.model:model=loaded
		elif model._path:
			with open(model._path,'r',encoding=_Q)as file:expressions=parse(file.read(),default_dialect=config.dialect)
		formatted=format_model_expressions(expressions,model.dialect,rewrite_casts=not config.format.no_rewrite_casts,**config.format.generator_options);self._shell.set_next_input('\n'.join([' '.join(['%%model',line]),formatted]),replace=_D)
		if model._path:
			with open(model._path,'w',encoding=_Q)as file:file.write(formatted)
		if sql:context.console.log_success(f"Model `{args.model}` updated")
		context.upsert_model(model);context.console.show_sql(context.render(model.name,start=args.start,end=args.end,execution_time=args.execution_time).sql(pretty=_D,dialect=args.dialect or model.dialect))
	@magic_arguments()
	@argument(_E,type=str,help=_R)
	@argument('test_name',type=str,nargs=_J,default=_A,help='The test name to display')
	@argument('--ls',action=_B,help='List tests associated with a model')
	@line_cell_magic
	@pass_vulcan_context
	def test(self,context:Context,line:str,test_def_raw:t.Optional[str]=_A)->_A:
		args=parse_argstring(self.test,line)
		if not args.test_name and not args.ls:raise MagicError('Must provide either test name or `--ls` to list tests')
		test_meta=context.select_tests();tests:t.Dict[str,t.Dict[str,ModelTestMetadata]]=defaultdict(dict)
		for model_test_metadata in test_meta:
			model=model_test_metadata.body.get(_E)
			if not model:context.console.log_error(f"Test found that does not have `model` defined: {model_test_metadata.path}")
			else:tests[model][model_test_metadata.test_name]=model_test_metadata
		model=context.get_model(args.model,raise_if_missing=_D)
		if args.ls:
			for test_name in tests[model.name]:context.console.log_status_update(test_name)
			return
		test=tests[model.name][args.test_name];test_def=yaml.load(test_def_raw)if test_def_raw else test.body;test_def_output=yaml.dump(test_def);self._shell.set_next_input('\n'.join([' '.join(['%%test',line]),test_def_output]),replace=_D)
		with open(test.path,'r+',encoding=_Q)as file:content=yaml.load(file.read());content[args.test_name]=test_def;file.seek(0);yaml.dump(content,file);file.truncate()
	@magic_arguments()
	@argument(_M,nargs=_J,type=str,help='The environment to run the plan against')
	@argument(_F,_G,type=str,help='Start date to backfill.')
	@argument(_H,_I,type=str,help='End date to backfill.')
	@argument(_K,type=str,help=_L)
	@argument('--create-from',type=str,help="The environment to create the target environment from if it doesn't exist. Default: prod.")
	@argument('--skip-tests',_P,action=_B,help='Skip the unit tests defined for the model.')
	@argument('--skip-linter',action=_B,help='Skip the linter for the model.')
	@argument('--restate-model','-r',type=str,nargs=_C,help='Restate data for specified models (and models downstream from the one specified). For production environment, all related model versions will have their intervals wiped, but only the current versions will be backfilled. For development environment, only the current model versions will be affected.')
	@argument('--no-gaps','-g',action=_B,help='Ensure that new snapshots have no data gaps when comparing to existing snapshots for matching models in the target environment.')
	@argument('--skip-backfill','--dry-run',action=_B,help='Skip the backfill step and only create a virtual update for the plan.')
	@argument('--empty-backfill',action=_B,help='Produce empty backfill. Like --skip-backfill no models will be backfilled, unlike --skip-backfill missing intervals will be recorded as if they were backfilled.')
	@argument('--forward-only',action=_B,help='Create a plan for forward-only changes.',default=_A)
	@argument('--effective-from',type=str,help='The effective date from which to apply forward-only changes on production.')
	@argument('--no-prompts',action=_B,help='Disables interactive prompts for the backfill time range. Please note that if this flag is set and there are uncategorized changes, plan creation will fail.',default=_A)
	@argument('--auto-apply',action=_B,help='Automatically applies the new plan after creation.',default=_A)
	@argument('--no-auto-categorization',action=_B,help='Disable automatic change categorization.',default=_A)
	@argument('--include-unmodified',action=_B,help='Include unmodified models in the target environment.',default=_A)
	@argument(_N,type=str,nargs=_C,help=_b)
	@argument('--backfill-model',type=str,nargs=_C,help='Backfill only the models whose names match the expression.')
	@argument('--no-diff',action=_B,help='Hide text differences for changed models.',default=_A)
	@argument('--run',action=_B,help='Run latest intervals as part of the plan application (prod environment only).')
	@argument(_c,action=_B,help='Run for all missing intervals, ignoring individual cron schedules. Only applies if --run is set.',default=_A)
	@argument('--enable-preview',action=_B,help='Enable preview for forward-only models when targeting a development environment.',default=_A)
	@argument('--diff-rendered',action=_B,help='Output text differences for the rendered versions of the models and standalone audits')
	@argument(_V,_S,action=_W,default=0,help=_X)
	@argument(_d,action=_B,help='Run state migration before planning.')
	@line_magic
	@pass_vulcan_context
	def plan(self,context:Context,line:str)->_A:
		args=parse_argstring(self.plan,line);setattr(context.console,'verbosity',Verbosity(args.verbose))
		if args.migrate:context.migrate()
		context.plan(args.environment,start=args.start,end=args.end,execution_time=args.execution_time,create_from=args.create_from,skip_tests=args.skip_tests,restate_models=args.restate_model,backfill_models=args.backfill_model,no_gaps=args.no_gaps,skip_backfill=args.skip_backfill,empty_backfill=args.empty_backfill,forward_only=args.forward_only,no_prompts=args.no_prompts,auto_apply=args.auto_apply,no_auto_categorization=args.no_auto_categorization,effective_from=args.effective_from,include_unmodified=args.include_unmodified,select_models=args.select_model,no_diff=args.no_diff,run=args.run,ignore_cron=args.run,enable_preview=args.enable_preview,diff_rendered=args.diff_rendered)
	@magic_arguments()
	@argument(_M,nargs=_J,type=str,help='The environment to run against')
	@argument(_F,_G,type=str,help='Start date to evaluate.')
	@argument(_H,_I,type=str,help='End date to evaluate.')
	@argument('--skip-janitor',action=_B,help='Skip the janitor task.')
	@argument(_c,action=_B,help='Run for all missing intervals, ignoring individual cron schedules.')
	@argument(_N,type=str,nargs=_C,help='Select specific models to run. Note: this always includes upstream dependencies.')
	@argument('--exit-on-env-update',type=int,help='If set, the command will exit with the specified code if the run is interrupted by an update to the target environment.')
	@argument('--no-auto-upstream',action=_B,help='Do not automatically include upstream models. Only applicable when --select-model is used. Note: this may result in missing / invalid data for the selected models.')
	@argument(_d,action=_B,help='Run state migration before run.')
	@line_magic
	@pass_vulcan_context
	def run_dag(self,context:Context,line:str)->_A:
		args=parse_argstring(self.run_dag,line)
		if args.migrate:context.migrate()
		completion_status=context.run(args.environment,start=args.start,end=args.end,skip_janitor=args.skip_janitor,ignore_cron=args.ignore_cron,select_models=args.select_model,exit_on_env_update=args.exit_on_env_update,no_auto_upstream=args.no_auto_upstream)
		if completion_status.is_failure:raise VulcanError('Error Running DAG. Check logs for details.')
	@magic_arguments()
	@argument(_E,type=str,help=_R)
	@argument(_F,_G,type=str,help=_T)
	@argument(_H,_I,type=str,help=_U)
	@argument(_K,type=str,help=_L)
	@argument(_e,type=int,help='The number of rows which the query should be limited to.')
	@line_magic
	@pass_vulcan_context
	def evaluate(self,context:Context,line:str)->_A:
		context.refresh();snowpark=optional_import('snowflake.snowpark');args=parse_argstring(self.evaluate,line);df=context.evaluate(args.model,start=args.start,end=args.end,execution_time=args.execution_time,limit=args.limit)
		if snowpark and isinstance(df,snowpark.DataFrame):df=df.limit(args.limit or 100).to_pandas()
		self.display(df)
	@magic_arguments()
	@argument(_E,type=str,help=_R)
	@argument(_F,_G,type=str,help=_T)
	@argument(_H,_I,type=str,help=_U)
	@argument(_K,type=str,help=_L)
	@argument('--expand',type=t.Union[bool,t.Iterable[str]],help='Whether or not to use expand materialized models, defaults to False. If True, all referenced models are expanded as raw queries. If a list, only referenced models are expanded as raw queries.')
	@argument(_a,type=str,help='SQL dialect to render.')
	@argument('--no-format',action=_B,help='Disable fancy formatting of the query.')
	@format_arguments
	@line_magic
	@pass_vulcan_context
	def render(self,context:Context,line:str)->_A:
		context.refresh();render_opts=vars(parse_argstring(self.render,line));model=render_opts.pop(_E);dialect=render_opts.pop('dialect',_A);model=context.get_model(model,raise_if_missing=_D);query=context.render(model,start=render_opts.pop('start',_A),end=render_opts.pop('end',_A),execution_time=render_opts.pop('execution_time',_A),expand=render_opts.pop('expand',_O));no_format=render_opts.pop('no_format',_O);format_config=context.config_for_node(model).format;format_options={**format_config.generator_options,**{k:v for(k,v)in render_opts.items()if v is not _A}};sql=query.sql(pretty=_D,dialect=context.config.dialect if dialect is _A else dialect,**format_options)
		if no_format:context.console.log_status_update(sql)
		else:context.console.show_sql(sql)
	@magic_arguments()
	@argument('df_var',default=_A,nargs=_J,type=str,help='An optional variable name to store the resulting dataframe.')
	@cell_magic
	@pass_vulcan_context
	def fetchdf(self,context:Context,line:str,sql:str)->_A:
		args=parse_argstring(self.fetchdf,line);df=context.fetchdf(sql)
		if args.df_var:self._shell.user_ns[args.df_var]=df
		self.display(df)
	@magic_arguments()
	@argument('--file','-f',type=str,help='An optional file path to write the HTML output to.')
	@argument(_N,type=str,nargs=_C,help='Select specific models to include in the dag.')
	@line_magic
	@pass_vulcan_context
	def dag(self,context:Context,line:str)->_A:
		args=parse_argstring(self.dag,line);dag=context.get_dag(args.select_model)
		if args.file:
			with open(args.file,'w',encoding=_Q)as file:file.write(str(dag))
		self.display(dag)
	@magic_arguments()
	@line_magic
	@pass_vulcan_context
	def migrate(self,context:Context,line:str)->_A:context.migrate();context.console.log_success('Migration complete')
	@magic_arguments()
	@argument('--strict',action=_B,help='Raise an error if the external model is missing in the database')
	@line_magic
	@pass_vulcan_context
	def create_external_models(self,context:Context,line:str)->_A:args=parse_argstring(self.create_external_models,line);context.create_external_models(strict=args.strict)
	@magic_arguments()
	@argument('source_to_target',type=str,metavar='SOURCE:TARGET',help='Source and target in `SOURCE:TARGET` format')
	@argument('--on',type=str,nargs=_C,help='The column to join on. Can be specified multiple times. The model grain will be used if not specified.')
	@argument('--skip-columns',type=str,nargs=_C,help='The column(s) to skip when comparing the source and target table.')
	@argument(_f,type=str,help='The model to diff against when source and target are environments and not tables.')
	@argument('--where',type=str,help='An optional where statement to filter results.')
	@argument(_e,type=int,default=20,help='The limit of the sample dataframe.')
	@argument('--show-sample',action=_B,help='Show a sample of the rows that differ. With many columns, the output can be very wide.')
	@argument('--decimals',type=int,default=3,help='The number of decimal places to keep when comparing floating point columns. Default: 3')
	@argument(_N,type=str,nargs=_C,help="Specify one or more models to data diff. Use wildcards to diff multiple models. Ex: '*' (all models with applied plan diffs), 'demo.model+' (this and downstream models), 'git:feature_branch' (models with direct modifications in this branch only)")
	@argument('--skip-grain-check',action=_B,help='Disable the check for a primary key (grain) that is missing or is not unique.')
	@argument('--warn-grain-check',action=_B,help='Warn if any selected model is missing a grain, and compute diffs for the remaining models.')
	@argument('--schema-diff-ignore-case',action=_B,help="If set, when performing a schema diff the case of column names is ignored when matching between the two schemas. For example, 'col_a' in the source schema and 'COL_A' in the target schema will be treated as the same column.")
	@line_magic
	@pass_vulcan_context
	def table_diff(self,context:Context,line:str)->_A:args=parse_argstring(self.table_diff,line);source,target=args.source_to_target.split(':');select_models={args.model}if args.model else args.select_model or _A;context.table_diff(source=source,target=target,on=args.on,skip_columns=args.skip_columns,select_models=select_models,where=args.where,limit=args.limit,show_sample=args.show_sample,decimals=args.decimals,skip_grain_check=args.skip_grain_check,warn_grain_check=args.warn_grain_check,schema_diff_ignore_case=args.schema_diff_ignore_case)
	@magic_arguments()
	@argument('model_name',nargs=_J,type=str,help='The name of the model to get the table name for.')
	@argument('--environment',type=str,help='The environment to source the model version from.')
	@argument('--prod',action=_B,help='If set, return the name of the physical table that will be used in production for the model version promoted in the target environment.')
	@line_magic
	@pass_vulcan_context
	def table_name(self,context:Context,line:str)->_A:args=parse_argstring(self.table_name,line);context.console.log_status_update(context.table_name(args.model_name,args.environment,args.prod))
	@magic_arguments()
	@argument('pipeline',nargs=_J,type=str,help='The dlt pipeline to attach for this Vulcan project.')
	@argument('--table',_P,type=str,nargs=_C,help='The specific dlt tables to refresh in the Vulcan models.')
	@argument('--force','-f',action=_B,help='If set, existing models are overwritten with the new DLT tables.')
	@argument(_Z,type=str,help='The directory where the DLT pipeline resides.')
	@line_magic
	@pass_vulcan_context
	def dlt_refresh(self,context:Context,line:str)->_A:
		from vulcan.integrations.dlt import generate_dlt_models;args=parse_argstring(self.dlt_refresh,line);vulcan_models=generate_dlt_models(context,args.pipeline,list(args.table or[]),args.force,args.dlt_path)
		if vulcan_models:model_names='\n'.join([f"- {model_name}"for model_name in vulcan_models]);context.console.log_success(f"Updated Vulcan project with models:\n{model_names}")
		else:context.console.log_success('All Vulcan models are up to date.')
	@magic_arguments()
	@argument('--read',type=str,default='',help='The input dialect of the sql string.')
	@argument('--write',type=str,default='',help='The output dialect of the sql string.')
	@line_cell_magic
	@pass_vulcan_context
	def rewrite(self,context:Context,line:str,sql:str)->_A:args=parse_argstring(self.rewrite,line);context.console.show_sql(context.rewrite(sql,args.read).sql(dialect=args.write or context.config.dialect,pretty=_D))
	@magic_arguments()
	@argument('--transpile',_P,type=str,help='Transpile project models to the specified dialect.')
	@argument('--check',action=_B,help='Whether or not to check formatting (but not actually format anything).',default=_A)
	@argument('--append-newline',action=_B,help='Include a newline at the end of the output.',default=_A)
	@argument('--no-rewrite-casts',action=_B,help='Preserve the existing casts, without rewriting them to use the :: syntax.',default=_A)
	@format_arguments
	@line_magic
	@pass_vulcan_context
	def format(self,context:Context,line:str)->bool:
		format_opts=vars(parse_argstring(self.format,line))
		if format_opts.pop('no_rewrite_casts',_A):format_opts['rewrite_casts']=_O
		return context.format(**{k:v for(k,v)in format_opts.items()if v is not _A})
	@magic_arguments()
	@argument(_M,type=str,help='The environment to diff local state against.')
	@line_magic
	@pass_vulcan_context
	def diff(self,context:Context,line:str)->_A:args=parse_argstring(self.diff,line);context.diff(args.environment)
	@magic_arguments()
	@argument(_M,type=str,help='The environment to invalidate.')
	@line_magic
	@pass_vulcan_context
	def invalidate(self,context:Context,line:str)->_A:args=parse_argstring(self.invalidate,line);context.invalidate_environment(args.environment)
	@magic_arguments()
	@argument('--ignore-ttl',action=_B,help="Cleanup snapshots that are not referenced in any environment, regardless of when they're set to expire")
	@line_magic
	@pass_vulcan_context
	def janitor(self,context:Context,line:str)->_A:args=parse_argstring(self.janitor,line);context.run_janitor(ignore_ttl=args.ignore_ttl)
	@magic_arguments()
	@argument(_E,type=str)
	@argument('--query','-q',type=str,nargs='+',default=[],help="Queries that will be used to generate data for the model's dependencies.")
	@argument('--overwrite','-o',action=_B,help='When true, the fixture file will be overwritten in case it already exists.')
	@argument('--var',_S,type=str,nargs='+',help='Key-value pairs that will define variables needed by the model.')
	@argument('--path','-p',type=str,help="The file path corresponding to the fixture, relative to the test directory. By default, the fixture will be created under the test directory and the file name will be inferred based on the test's name.")
	@argument('--name','-n',type=str,help="The name of the test that will be created. By default, it's inferred based on the model's name.")
	@argument('--include-ctes',action=_B,help='When true, CTE fixtures will also be generated.')
	@line_magic
	@pass_vulcan_context
	def create_test(self,context:Context,line:str)->_A:args=parse_argstring(self.create_test,line);queries=iter(args.query);variables=iter(args.var)if args.var else _A;context.create_test(args.model,input_queries={k:v.strip('"')for(k,v)in dict(zip(queries,queries)).items()},overwrite=args.overwrite,variables=dict(zip(variables,variables))if variables else _A,path=args.path,name=args.name,include_ctes=args.include_ctes)
	@magic_arguments()
	@argument('tests',nargs=_C,type=str)
	@argument('--pattern','-k',nargs=_C,type=str,help='Only run tests that match the pattern of substring.')
	@argument(_V,_S,action=_W,default=0,help=_X)
	@argument('--preserve-fixtures',action=_B,help='Preserve the fixture tables in the testing database, useful for debugging.')
	@line_magic
	@pass_vulcan_context
	def run_test(self,context:Context,line:str)->_A:args=parse_argstring(self.run_test,line);context.test(match_patterns=args.pattern,tests=args.tests,verbosity=Verbosity(args.verbose),preserve_fixtures=args.preserve_fixtures,stream=StringIO())
	@magic_arguments()
	@argument('models',type=str,nargs=_C,help='A model to audit. Multiple models can be audited.')
	@argument(_F,_G,type=str,help='Start date to audit.')
	@argument(_H,_I,type=str,help='End date to audit.')
	@argument(_K,type=str,help=_L)
	@line_magic
	@pass_vulcan_context
	def audit(self,context:Context,line:str)->bool:args=parse_argstring(self.audit,line);return context.audit(models=args.models,start=args.start,end=args.end,execution_time=args.execution_time)
	@magic_arguments()
	@argument(_M,nargs=_J,type=str,help='The environment to check intervals for.')
	@argument('--no-signals',action=_B,help='Disable signal checks and only show missing intervals.',default=_O)
	@argument(_N,type=str,nargs=_C,help=_b)
	@argument(_F,_G,type=str,help='Start date of intervals to check for.')
	@argument(_H,_I,type=str,help='End date of intervals to check for.')
	@line_magic
	@pass_vulcan_context
	def check_intervals(self,context:Context,line:str)->_A:args=parse_argstring(self.check_intervals,line);context.console.show_intervals(context.check_intervals(environment=args.environment,no_signals=args.no_signals,select_models=args.select_model,start=args.start,end=args.end))
	@magic_arguments()
	@argument('--skip-connection',action=_B,help='Skip the connection test.',default=_O)
	@argument(_V,_S,action=_W,default=0,help=_X)
	@line_magic
	@pass_vulcan_context
	def info(self,context:Context,line:str)->_A:args=parse_argstring(self.info,line);context.print_info(skip_connection=args.skip_connection,verbosity=Verbosity(args.verbose))
	@magic_arguments()
	@line_magic
	@pass_vulcan_context
	def rollback(self,context:Context,line:str)->_A:context.rollback()
	@magic_arguments()
	@line_magic
	@pass_vulcan_context
	def clean(self,context:Context,line:str)->_A:context.clear_caches();context.console.log_success('Vulcan cache and build artifacts cleared')
	@magic_arguments()
	@line_magic
	@pass_vulcan_context
	def environments(self,context:Context,line:str)->_A:context.print_environment_names()
	@magic_arguments()
	@argument('--models',_f,type=str,nargs=_C,help='A model to lint. Multiple models can be linted. If no models are specified, every model will be linted.')
	@line_magic
	@pass_vulcan_context
	def lint(self,context:Context,line:str)->_A:args=parse_argstring(self.lint,line);context.lint_models(args.models)
	@magic_arguments()
	@line_magic
	@pass_vulcan_context
	def destroy(self,context:Context,line:str)->_A:context.destroy()
def register_magics()->_A:
	try:shell=get_ipython();shell.register_magics(VulcanMagics)
	except NameError:pass