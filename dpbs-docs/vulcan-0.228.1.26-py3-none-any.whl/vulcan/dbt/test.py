from __future__ import annotations
_C='before'
_B='schema'
_A=None
import re,typing as t
from enum import Enum
from pathlib import Path
from pydantic import Field
import vulcan.core.dialect as d
from vulcan.core.audit import Audit,ModelAudit,StandaloneAudit
from vulcan.core.node import DbtNodeInfo
from vulcan.dbt.common import Dependencies,GeneralConfig,SqlStr,sql_str_validator
from vulcan.utils import AttributeDict
from vulcan.utils.pydantic import field_validator
if t.TYPE_CHECKING:from vulcan.dbt.context import DbtContext
class Severity(str,Enum):ERROR='error';WARN='warn'
class TestConfig(GeneralConfig):
	__test__=False;path:Path=Path();name:str;sql:SqlStr;test_kwargs:t.Dict[str,t.Any]={};model_name:t.Optional[str]=_A;owner:t.Optional[str]=_A;stamp:t.Optional[str]=_A;cron:t.Optional[str]=_A;interval_unit:t.Optional[str]=_A;column_name:t.Optional[str]=_A;dependencies:Dependencies=Dependencies();dialect_:t.Optional[str]=Field(_A,alias='dialect');unique_id:str='';package_name:str='';alias:t.Optional[str]=_A;fqn:t.List[str]=[];schema_:t.Optional[str]=Field('',alias=_B);database:t.Optional[str]=_A;severity:Severity=Severity.ERROR;store_failures:t.Optional[bool]=_A;where:t.Optional[str]=_A;limit:t.Optional[int]=_A;fail_calc:str='count(*)';warn_if:str='!=0';error_if:str='!=0';quoting:t.Dict[str,t.Optional[bool]]={};_sql_validator=sql_str_validator
	@field_validator('severity',mode=_C)
	@classmethod
	def _validate_severity(cls,v:t.Union[Severity,str])->Severity:
		if isinstance(v,Severity):return v
		return Severity(v.lower())
	@field_validator('name',mode=_C)
	@classmethod
	def _lowercase_name(cls,v:str)->str:return v.lower()
	@property
	def canonical_name(self)->str:return f"{self.package_name}.{self.name}".lower()if self.package_name else self.name
	@property
	def is_standalone(self)->bool:
		if not self.model_name:return True
		self_refs={self.model_name}
		for ref in self.dependencies.refs:
			if ref.startswith(f"{self.model_name}_v"):self_refs.add(ref)
		other_refs={ref for ref in self.dependencies.refs if ref not in self_refs};return bool(other_refs)
	@property
	def vulcan_config_fields(self)->t.Set[str]:return{'description','owner','stamp','cron','interval_unit'}
	def dialect(self,context:DbtContext)->str:return self.dialect_ or context.default_dialect
	def to_vulcan(self,context:DbtContext)->Audit:
		test_context=context.context_for_dependencies(self.dependencies);jinja_macros=test_context.jinja_macros.trim(self.dependencies.macros,package=self.package_name);jinja_macros.add_globals({'config':self.config_attribute_dict,**test_context.jinja_globals});query=d.jinja_query(self.sql.replace('**_dbt_generic_test_kwargs',self._kwargs()));skip=not self.enabled;blocking=self.severity==Severity.ERROR;audit:Audit
		if self.is_standalone:jinja_macros.add_globals({'this':self.relation_info});audit=StandaloneAudit(name=self.name,dbt_node_info=self.node_info,dialect=self.dialect(context),skip=skip,query=query,jinja_macros=jinja_macros,depends_on={model.canonical_name(context)for model in test_context.refs.values()}.union({source.canonical_name(context)for source in test_context.sources.values()}),tags=self.tags,default_catalog=context.target.database,**self.vulcan_config_kwargs)
		else:audit=ModelAudit(name=self.name,dbt_node_info=self.node_info,dialect=self.dialect(context),skip=skip,blocking=blocking,query=query,jinja_macros=jinja_macros)
		audit._path=self.path;return audit
	def _kwargs(self)->str:
		kwargs={}
		for(key,value)in self.test_kwargs.items():
			if isinstance(value,str):
				value=value.rstrip();no_braces=_remove_jinja_braces(value);jinja_function_regex='^\\s*(env_var|ref|var|source|doc)\\s*\\(.+\\)\\s*$'
				if key!='column_name'and(value!=no_braces or re.match(jinja_function_regex,value)):kwargs[key]=no_braces
				else:kwargs[key]=f'"{escape_quotes(value)}"'
			else:kwargs[key]=value
		return', '.join(f"{key}={value}"for(key,value)in kwargs.items())
	@property
	def relation_info(self)->AttributeDict:return AttributeDict({'name':self.name,'database':self.database,_B:self.schema_,'identifier':self.name,'type':_A,'quote_policy':AttributeDict()})
	@property
	def node_info(self)->DbtNodeInfo:return DbtNodeInfo(unique_id=self.unique_id,name=self.name,fqn='.'.join(self.fqn),alias=self.alias)
def _remove_jinja_braces(jinja_str:str)->str:
	no_braces=jinja_str;cursor=0;quotes:t.List[str]=[]
	while cursor<len(no_braces):
		val=no_braces[cursor]
		if val in('"',"'"):
			if quotes and quotes[-1]==val:quotes.pop()
			else:quotes.append(no_braces[cursor])
		if cursor+1<len(no_braces)and no_braces[cursor:cursor+2]in('{{','}}')and not quotes:no_braces=no_braces[:cursor]+no_braces[cursor+2:]
		else:cursor+=1
	return no_braces.strip()
def escape_quotes(v:str)->str:return v.replace('"','\\"')