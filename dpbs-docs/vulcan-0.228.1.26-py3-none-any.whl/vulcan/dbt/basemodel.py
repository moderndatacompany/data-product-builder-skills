from __future__ import annotations
_G='columns'
_F='grants'
_E='before'
_D='post-hook'
_C='pre-hook'
_B='schema'
_A=None
import typing as t
from abc import abstractmethod
from enum import Enum
from pathlib import Path
import logging
from pydantic import Field
from sqlglot.helper import ensure_list
from vulcan.core import dialect as d
from vulcan.core.config.base import UpdateStrategy
from vulcan.core.config.common import VirtualEnvironmentMode
from vulcan.core.model import Model
from vulcan.core.model.common import ParsableSql
from vulcan.core.node import DbtNodeInfo
from vulcan.dbt.column import ColumnConfig,column_descriptions_to_vulcan,column_types_to_vulcan
from vulcan.dbt.common import DbtConfig,Dependencies,GeneralConfig,RAW_CODE_KEY,SqlStr,sql_str_validator
from vulcan.dbt.relation import Policy,RelationType
from vulcan.dbt.test import TestConfig
from vulcan.dbt.util import DBT_VERSION
from vulcan.utils import AttributeDict
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import field_validator
if t.TYPE_CHECKING:from vulcan.core.audit.definition import ModelAudit;from vulcan.dbt.context import DbtContext
BMC=t.TypeVar('BMC',bound='BaseModelConfig')
logger=logging.getLogger(__name__)
class Materialization(str,Enum):
	TABLE='table';VIEW='view';INCREMENTAL='incremental';EPHEMERAL='ephemeral';SNAPSHOT='snapshot';DYNAMIC_TABLE='dynamic_table';CUSTOM='custom'
	@classmethod
	def _missing_(cls,value):return cls.CUSTOM
class SnapshotStrategy(str,Enum):
	TIMESTAMP='timestamp';CHECK='check'
	@property
	def is_timestamp(self)->bool:return self==SnapshotStrategy.TIMESTAMP
	@property
	def is_check(self)->bool:return self==SnapshotStrategy.CHECK
class Hook(DbtConfig):sql:SqlStr;transaction:bool=True;_sql_validator=sql_str_validator
class BaseModelConfig(GeneralConfig):
	owner:t.Optional[str]=_A;stamp:t.Optional[str]=_A;table_format:t.Optional[str]=_A;storage_format:t.Optional[str]=_A;path:Path=Path();dependencies:Dependencies=Dependencies();tests:t.List[TestConfig]=[];dialect_:t.Optional[str]=Field(_A,alias='dialect');grain:t.Union[str,t.List[str]]=[];unique_id:str='';name:str='';package_name:str='';fqn_:t.List[str]=Field(default_factory=list,alias='fqn');schema_:str=Field('',alias=_B);database:t.Optional[str]=_A;alias:t.Optional[str]=_A;pre_hook:t.List[Hook]=Field([],alias=_C);post_hook:t.List[Hook]=Field([],alias=_D);full_refresh:t.Optional[bool]=_A;grants:t.Dict[str,t.List[str]]={};columns:t.Dict[str,ColumnConfig]={};quoting:t.Dict[str,t.Optional[bool]]={};event_time:t.Optional[str]=_A;version:t.Optional[int]=_A;latest_version:t.Optional[int]=_A;_canonical_name:t.Optional[str]=_A
	@field_validator('pre_hook','post_hook',mode=_E)
	@classmethod
	def _validate_hooks(cls,v:t.Union[str,t.List[t.Union[SqlStr,str]]])->t.List[Hook]:
		hooks=[]
		for hook in ensure_list(v):
			if isinstance(hook,Hook):hooks.append(hook)
			elif isinstance(hook,str):hooks.append(Hook(sql=hook))
			elif isinstance(hook,dict):hooks.append(Hook(**hook))
			else:raise ConfigError(f"Invalid hook data: {hook}")
		return hooks
	@field_validator(_F,mode=_E)
	@classmethod
	def _validate_grants(cls,v:t.Optional[t.Dict[str,str]])->t.Optional[t.Dict[str,t.List[str]]]:
		if v is _A:return
		return{key:ensure_list(value)for(key,value)in v.items()}
	_FIELD_UPDATE_STRATEGY:t.ClassVar[t.Dict[str,UpdateStrategy]]={**GeneralConfig._FIELD_UPDATE_STRATEGY,**{_F:UpdateStrategy.KEY_EXTEND,'path':UpdateStrategy.IMMUTABLE,_C:UpdateStrategy.EXTEND,_D:UpdateStrategy.EXTEND,_G:UpdateStrategy.KEY_EXTEND}}
	@property
	def table_schema(self)->str:return self.schema_
	@property
	def table_name(self)->str:return self.alias or self.path.stem
	@property
	def config_name(self)->str:return f"{self.package_name}.{self.name}"
	def dialect(self,context:DbtContext)->str:return self.dialect_ or context.default_dialect
	def canonical_name(self,context:DbtContext)->str:
		A=False
		if not self._canonical_name:
			relation=context.create_relation(self.relation_info,quote_policy=Policy(database=A,schema=A,identifier=A))
			if relation.database==context.target.database:relation=relation.include(database=A)
			self._canonical_name=relation.render()
		return self._canonical_name
	@property
	def model_materialization(self)->Materialization:return Materialization.TABLE
	@property
	def relation_info(self)->AttributeDict[str,t.Any]:
		if self.model_materialization==Materialization.VIEW:relation_type=RelationType.View
		elif self.model_materialization==Materialization.EPHEMERAL:relation_type=RelationType.CTE
		else:relation_type=RelationType.Table
		extras={}
		if DBT_VERSION>=(1,9,0)and self.event_time:extras['event_time_filter']={'field_name':self.event_time}
		return AttributeDict({'database':self.database,_B:self.table_schema,'identifier':self.table_name,'type':relation_type.value,'quote_policy':AttributeDict(self.quoting),**extras})
	@property
	def tests_ref_source_dependencies(self)->Dependencies:
		dependencies=Dependencies()
		for test in self.tests:dependencies=dependencies.union(test.dependencies)
		if self.name in dependencies.refs:dependencies.refs.remove(self.name)
		dependencies.macros=[];return dependencies
	def remove_tests_with_invalid_refs(self,context:DbtContext)->_A:self.tests=[test for test in self.tests if all(ref in context.refs for ref in test.dependencies.refs)and all(source in context.sources for source in test.dependencies.sources)]
	@property
	def fqn(self)->str:return'.'.join(self.fqn_)
	@property
	def vulcan_config_fields(self)->t.Set[str]:return{'description','owner','stamp','storage_format'}
	@property
	def node_info(self)->DbtNodeInfo:return DbtNodeInfo(unique_id=self.unique_id,name=self.name,fqn=self.fqn,alias=self.alias)
	def vulcan_model_kwargs(self,context:DbtContext,column_types_override:t.Optional[t.Dict[str,ColumnConfig]]=_A)->t.Dict[str,t.Any]:
		self.remove_tests_with_invalid_refs(context);dependencies=self.dependencies.copy()
		if dependencies.has_dynamic_var_names:dependencies.variables|=set(context.variables)
		if getattr(self,'model_materialization',_A)==Materialization.CUSTOM and hasattr(self,'_get_custom_materialization')and(custom_mat:=self._get_custom_materialization(context)):dependencies=dependencies.union(custom_mat.dependencies)
		model_dialect=self.dialect(context);dependencies.refs.intersection_update(context.refs);dependencies.sources.intersection_update(context.sources);model_context=context.context_for_dependencies(dependencies.union(self.tests_ref_source_dependencies));jinja_macros=model_context.jinja_macros.trim(dependencies.macros,package=self.package_name);jinja_macros.add_globals(self._model_jinja_context(model_context,dependencies));model_kwargs={'audits':[(test.canonical_name,{})for test in self.tests],'column_descriptions':column_descriptions_to_vulcan(self.columns)or _A,'depends_on':{model.canonical_name(context)for model in model_context.refs.values()}.union({source.canonical_name(context)for source in model_context.sources.values()if source.fqn not in context.model_fqns}),'jinja_macros':jinja_macros,'path':self.path,'pre_statements':[ParsableSql(sql=d.jinja_statement(hook.sql).sql(),transaction=hook.transaction)for hook in self.pre_hook],'post_statements':[ParsableSql(sql=d.jinja_statement(hook.sql).sql(),transaction=hook.transaction)for hook in self.post_hook],'tags':self.tags,'physical_schema_mapping':context.vulcan_config.physical_schema_mapping,'default_catalog':context.target.database,'grain':[d.parse_one(g,dialect=model_dialect)for g in ensure_list(self.grain)],**self.vulcan_config_kwargs}
		if column_types_override:model_kwargs[_G]=column_types_to_vulcan(column_types_override,self.dialect(context))or _A
		return model_kwargs
	@abstractmethod
	def to_vulcan(self,context:DbtContext,audit_definitions:t.Optional[t.Dict[str,ModelAudit]]=_A,virtual_environment_mode:VirtualEnvironmentMode=VirtualEnvironmentMode.default)->Model:0
	def _model_jinja_context(self,context:DbtContext,dependencies:Dependencies)->t.Dict[str,t.Any]:
		if context._manifest and self.unique_id in context._manifest._manifest.nodes:
			attributes=context._manifest._manifest.nodes[self.unique_id].to_dict()
			if dependencies.model_attrs.all_attrs:model_node:AttributeDict[str,t.Any]=AttributeDict(attributes)
			else:model_node=AttributeDict(filter(lambda kv:kv[0]in dependencies.model_attrs.attrs,attributes.items()))
			model_node.pop(RAW_CODE_KEY,_A)
		else:model_node=AttributeDict({})
		return{'this':self.relation_info,'model':model_node,_B:self.table_schema,'config':self.config_attribute_dict,**context.jinja_globals}