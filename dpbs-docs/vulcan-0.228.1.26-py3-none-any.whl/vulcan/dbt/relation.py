from vulcan.dbt.util import DBT_VERSION
if DBT_VERSION>=(1,8,0):from dbt.adapters.contracts.relation import*
else:from dbt.contracts.relation import*