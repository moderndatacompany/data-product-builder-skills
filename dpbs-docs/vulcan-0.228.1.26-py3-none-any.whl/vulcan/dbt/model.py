from __future__ import annotations
_T='allow_partials'
_S='TIMESTAMP'
_R='time_column'
_Q='unique_key'
_P='ignore'
_O='delete+insert'
_N='interval_unit'
_M='date'
_L='day'
_K='field'
_J='incremental_by_time_range'
_I='microbatch'
_H=False
_G=True
_F='start'
_E='data_type'
_D='before'
_C='bigquery'
_B='granularity'
_A=None
import datetime,typing as t,logging
from sqlglot import exp
from sqlglot.errors import SqlglotError
from sqlglot.helper import ensure_list
from vulcan.core import dialect as d
from vulcan.core.config.base import UpdateStrategy
from vulcan.core.config.common import VirtualEnvironmentMode
from vulcan.core.console import get_console
from vulcan.core.model import EmbeddedKind,FullKind,IncrementalByTimeRangeKind,IncrementalByUniqueKeyKind,IncrementalUnmanagedKind,Model,ModelKind,SCDType2ByColumnKind,ViewKind,ManagedKind,create_sql_model
from vulcan.core.model.kind import SCDType2ByTimeKind,OnDestructiveChange,OnAdditiveChange,on_destructive_change_validator,on_additive_change_validator,DbtCustomKind
from vulcan.dbt.basemodel import BaseModelConfig,Materialization,SnapshotStrategy
from vulcan.dbt.common import SqlStr,sql_str_validator
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import field_validator
if t.TYPE_CHECKING:from vulcan.core.audit.definition import ModelAudit;from vulcan.dbt.context import DbtContext;from vulcan.dbt.package import MaterializationConfig
logger=logging.getLogger(__name__)
logger=logging.getLogger(__name__)
INCREMENTAL_BY_TIME_RANGE_STRATEGIES=set([_O,'insert_overwrite',_I,_J])
INCREMENTAL_BY_UNIQUE_KEY_STRATEGIES=set(['merge'])
def collection_to_str(collection:t.Iterable)->str:return', '.join(f"'{item}'"for item in sorted(collection))
class ModelConfig(BaseModelConfig):
	sql:SqlStr=SqlStr('');time_column:t.Optional[t.Union[str,t.Dict[str,str]]]=_A;cron:t.Optional[str]=_A;interval_unit:t.Optional[str]=_A;batch_concurrency:t.Optional[int]=_A;forward_only:bool=_G;disable_restatement:t.Optional[bool]=_A;allow_partials:bool=_G;physical_version:t.Optional[str]=_A;auto_restatement_cron:t.Optional[str]=_A;auto_restatement_intervals:t.Optional[int]=_A;partition_by_time_column:t.Optional[bool]=_A;on_destructive_change:t.Optional[OnDestructiveChange]=_A;on_additive_change:t.Optional[OnAdditiveChange]=_A;cluster_by:t.Optional[t.List[str]]=_A;incremental_strategy:t.Optional[str]=_A;materialized:str=Materialization.VIEW.value;sql_header:t.Optional[str]=_A;unique_key:t.Optional[t.List[str]]=_A;partition_by:t.Optional[t.Union[t.List[str],t.Dict[str,t.Any]]]=_A;full_refresh:t.Optional[bool]=_A;on_schema_change:str=_P;updated_at:t.Optional[str]=_A;strategy:t.Optional[str]=_A;invalidate_hard_deletes:bool=_H;target_schema:t.Optional[str]=_A;check_cols:t.Optional[t.Union[t.List[str],str]]=_A;event_time:t.Optional[str]=_A;begin:t.Optional[datetime.datetime]=_A;concurrent_batches:t.Optional[bool]=_A;batch_size:t.Optional[t.Union[int,str]]=_A;lookback:t.Optional[int]=_A;bind:t.Optional[bool]=_A;require_partition_filter:t.Optional[bool]=_A;partition_expiration_days:t.Optional[int]=_A;snowflake_warehouse:t.Optional[str]=_A;target_lag:t.Optional[str]=_A;engine:t.Optional[str]=_A;order_by:t.Optional[t.Union[t.List[str],str]]=_A;primary_key:t.Optional[t.Union[t.List[str],str]]=_A;sharding_key:t.Optional[t.Union[t.List[str],str]]=_A;ttl:t.Optional[t.Union[t.List[str],str]]=_A;settings:t.Optional[t.Dict[str,t.Any]]=_A;query_settings:t.Optional[t.Dict[str,t.Any]]=_A;inserts_only:t.Optional[bool]=_A;incremental_predicates:t.Optional[t.List[str]]=_A;_sql_validator=sql_str_validator;_on_destructive_change_validator=on_destructive_change_validator;_on_additive_change_validator=on_additive_change_validator
	@field_validator(_Q,'cluster_by','tags',mode=_D)
	@classmethod
	def _validate_list(cls,v:t.Union[str,t.List[str]])->t.List[str]:return ensure_list(v)
	@field_validator('check_cols',mode=_D)
	@classmethod
	def _validate_check_cols(cls,v:t.Union[str,t.List[str]])->t.Union[str,t.List[str]]:
		if isinstance(v,str)and v.lower()=='all':return'*'
		return ensure_list(v)
	@field_validator('updated_at',mode=_D)
	@classmethod
	def _validate_updated_at(cls,v:t.Optional[str])->t.Optional[str]:
		if v is _A:return
		parsed=d.parse_one(v)
		if isinstance(parsed,exp.Cast)and isinstance(parsed.this,exp.Column):return parsed.this.name
		return v
	@field_validator('sql',mode=_D)
	@classmethod
	def _validate_sql(cls,v:t.Union[str,SqlStr])->SqlStr:return SqlStr(v)
	@field_validator('partition_by',mode=_D)
	@classmethod
	def _validate_partition_by(cls,v:t.Any)->t.Optional[t.Union[t.List[str],t.Dict[str,t.Any]]]:
		if v is _A:return
		if isinstance(v,str):return[v]
		if isinstance(v,list):return v
		if isinstance(v,dict):
			if not v.get(_K):raise ConfigError("'field' key required for partition_by.")
			if _B in v and v[_B].lower()not in(_L,'month','year','hour'):granularity=v[_B];raise ConfigError(f"Unexpected granularity '{granularity}' in partition_by '{v}'.")
			if _E in v and v[_E].lower()not in('timestamp',_M,'datetime','int64'):data_type=v[_E];raise ConfigError(f"Unexpected data_type '{data_type}' in partition_by '{v}'.")
			return{_E:_M,_B:_L,**v}
		raise ConfigError(f"Invalid format for partition_by '{v}'")
	@field_validator('materialized',mode=_D)
	@classmethod
	def _validate_materialized(cls,v:str)->str:
		unsupported_materializations=['materialized_view','dictionary','distributed_table','distributed_incremental']
		if v in unsupported_materializations:
			fallback=v.split('_');msg=f"Vulcan does not support the '{v}' model materialization."
			if len(fallback)==1:raise ConfigError(msg)
			else:get_console().log_warning(f"{msg} Falling back to the '{fallback[1]}' materialization.")
			return fallback[1]
		return v
	_FIELD_UPDATE_STRATEGY:t.ClassVar[t.Dict[str,UpdateStrategy]]={**BaseModelConfig._FIELD_UPDATE_STRATEGY,**{'sql':UpdateStrategy.IMMUTABLE,_R:UpdateStrategy.IMMUTABLE}}
	@property
	def model_materialization(self)->Materialization:return Materialization(self.materialized.lower())
	@property
	def snapshot_strategy(self)->t.Optional[SnapshotStrategy]:return SnapshotStrategy(self.strategy.lower())if self.strategy else _A
	@property
	def table_schema(self)->str:return self.target_schema or super().table_schema
	def model_kind(self,context:DbtContext)->ModelKind:
		H='disable_restatement';G='forward_only';F='dialect';E='auto_restatement_cron';D='on_additive_change';C='on_destructive_change';B='append_new_columns';A='batch_size';target=context.target;materialization=self.model_materialization;incremental_kind_kwargs:t.Dict[str,t.Any]={};on_schema_change=self.on_schema_change.lower()
		if materialization==Materialization.SNAPSHOT:on_schema_change=B
		if on_schema_change==_P:on_destructive_change=OnDestructiveChange.IGNORE;on_additive_change=OnAdditiveChange.IGNORE
		elif on_schema_change=='fail':on_destructive_change=OnDestructiveChange.ERROR;on_additive_change=OnAdditiveChange.ERROR
		elif on_schema_change==B:on_destructive_change=OnDestructiveChange.IGNORE;on_additive_change=OnAdditiveChange.ALLOW
		elif on_schema_change=='sync_all_columns':on_destructive_change=OnDestructiveChange.ALLOW;on_additive_change=OnAdditiveChange.ALLOW
		else:raise ConfigError(f"{self.canonical_name(context)}: Invalid on_schema_change value '{on_schema_change}'. Valid values are 'ignore', 'fail', 'append_new_columns', 'sync_all_columns'.")
		incremental_kind_kwargs[C]=self._get_field_value(C)or on_destructive_change;incremental_kind_kwargs[D]=self._get_field_value(D)or on_additive_change;auto_restatement_cron_value=self._get_field_value(E)
		if auto_restatement_cron_value is not _A:incremental_kind_kwargs[E]=auto_restatement_cron_value
		if materialization==Materialization.TABLE:return FullKind()
		if materialization==Materialization.VIEW:return ViewKind()
		if materialization==Materialization.INCREMENTAL:
			incremental_by_kind_kwargs:t.Dict[str,t.Any]={F:self.dialect(context)};forward_only_value=self._get_field_value(G)
			if forward_only_value is not _A:incremental_kind_kwargs[G]=forward_only_value
			is_incremental_by_time_range=self.time_column or self.incremental_strategy and self.incremental_strategy in{_I,_J}
			for field in(A,'batch_concurrency','lookback'):
				field_val=self._get_field_value(field)
				if field_val is not _A:
					if field==A and isinstance(field_val,str):continue
					incremental_by_kind_kwargs[field]=field_val
			disable_restatement=self.disable_restatement
			if disable_restatement is _A:
				if is_incremental_by_time_range:disable_restatement=_H
				else:disable_restatement=not self.full_refresh if self.full_refresh is not _A else _H
			incremental_by_kind_kwargs[H]=disable_restatement
			if is_incremental_by_time_range:
				strategy=self.incremental_strategy or target.default_incremental_strategy(IncrementalByTimeRangeKind)
				if strategy not in INCREMENTAL_BY_TIME_RANGE_STRATEGIES:get_console().log_warning(f"Vulcan incremental by time strategy is not compatible with '{strategy}' incremental strategy in model '{self.canonical_name(context)}'. Supported strategies include {collection_to_str(INCREMENTAL_BY_TIME_RANGE_STRATEGIES)}.")
				if self.time_column and strategy!=_J:get_console().log_warning(f"Using `time_column` on a model with incremental_strategy '{strategy}' has been deprecated. Please use `incremental_by_time_range` instead in model '{self.canonical_name(context)}'.")
				if strategy==_I:
					if self.time_column:raise ConfigError(f"{self.canonical_name(context)}: 'time_column' cannot be used with 'microbatch' incremental strategy. Use 'event_time' instead.")
					time_column=self._get_field_value('event_time')
					if not time_column:raise ConfigError(f"{self.canonical_name(context)}: 'event_time' is required for microbatch incremental strategy.")
					incremental_by_kind_kwargs[A]=1
				else:
					if not self.time_column:raise ConfigError(f"{self.canonical_name(context)}: 'time_column' is required for incremental by time range models not defined using microbatch.")
					time_column=self.time_column
				incremental_by_time_range_kwargs={_R:time_column}
				if self.auto_restatement_intervals:incremental_by_time_range_kwargs['auto_restatement_intervals']=self.auto_restatement_intervals
				if self.partition_by_time_column is not _A:incremental_by_time_range_kwargs['partition_by_time_column']=self.partition_by_time_column
				return IncrementalByTimeRangeKind(**incremental_kind_kwargs,**incremental_by_kind_kwargs,**incremental_by_time_range_kwargs)
			if self.unique_key:
				strategy=self.incremental_strategy or target.default_incremental_strategy(IncrementalByUniqueKeyKind)
				if self.incremental_strategy and strategy not in INCREMENTAL_BY_UNIQUE_KEY_STRATEGIES:get_console().log_warning(f"Unique key is not compatible with '{strategy}' incremental strategy in model '{self.canonical_name(context)}'. Supported strategies include {collection_to_str(INCREMENTAL_BY_UNIQUE_KEY_STRATEGIES)}. Falling back to 'merge' strategy.")
				merge_filter=_A
				if self.incremental_predicates:dialect=self.dialect(context);merge_filter=exp.and_(*[d.parse_one(predicate,dialect=dialect)for predicate in self.incremental_predicates],dialect=dialect).transform(d.replace_merge_table_aliases)
				return IncrementalByUniqueKeyKind(unique_key=self.unique_key,merge_filter=merge_filter,**incremental_kind_kwargs,**incremental_by_kind_kwargs)
			strategy=self.incremental_strategy or target.default_incremental_strategy(IncrementalUnmanagedKind);return IncrementalUnmanagedKind(insert_overwrite=strategy in INCREMENTAL_BY_TIME_RANGE_STRATEGIES,disable_restatement=incremental_by_kind_kwargs[H],**incremental_kind_kwargs)
		if materialization==Materialization.EPHEMERAL:return EmbeddedKind()
		if materialization==Materialization.SNAPSHOT:
			if not self.snapshot_strategy:raise ConfigError(f"{self.canonical_name(context)}: Vulcan snapshot strategy is required for snapshot materialization.")
			shared_kwargs={F:self.dialect(context),_Q:self.unique_key,'invalidate_hard_deletes':self.invalidate_hard_deletes,'valid_from_name':'dbt_valid_from','valid_to_name':'dbt_valid_to','time_data_type':exp.DataType.build('TIMESTAMPTZ')if target.dialect==_C else exp.DataType.build(_S),**incremental_kind_kwargs}
			if self.snapshot_strategy.is_check:return SCDType2ByColumnKind(columns=self.check_cols,execution_time_as_valid_from=_G,**shared_kwargs)
			return SCDType2ByTimeKind(updated_at_name=self.updated_at,updated_at_as_valid_from=_G,**shared_kwargs)
		if materialization==Materialization.DYNAMIC_TABLE:return ManagedKind()
		if materialization==Materialization.CUSTOM:
			if(custom_materialization:=self._get_custom_materialization(context)):return DbtCustomKind(materialization=self.materialized,adapter=custom_materialization.adapter,dialect=self.dialect(context),definition=custom_materialization.definition)
			raise ConfigError(f"Unknown materialization '{self.materialized}'. Custom materializations must be defined in your dbt project.")
		raise ConfigError(f"{materialization.value} materialization not supported.")
	def _big_query_partition_by_expr(self,context:DbtContext)->exp.Expression:
		A='range';assert isinstance(self.partition_by,dict);data_type=self.partition_by[_E].lower();raw_field=self.partition_by[_K]
		try:field=d.parse_one(raw_field,dialect=_C)
		except SqlglotError as e:raise ConfigError(f"Failed to parse model '{self.canonical_name(context)}' partition_by field '{raw_field}' in '{self.path}': {e}")from e
		if data_type==_M and self.partition_by[_B].lower()==_L:return field
		if data_type=='int64':
			if A not in self.partition_by:raise ConfigError(f"Range is required for int64 partitioning in model '{self.canonical_name(context)}'.")
			range_=self.partition_by[A];start=range_[_F];end=range_['end'];interval=range_['interval'];return exp.func('RANGE_BUCKET',field,exp.func('GENERATE_ARRAY',start,end,interval,dialect=_C),dialect=_C)
		return d.parse_one(f"{data_type}_trunc({self.partition_by[_K]}, {self.partition_by[_B].upper()})",dialect=_C)
	def _get_custom_materialization(self,context:DbtContext)->t.Optional[MaterializationConfig]:
		materializations=context.manifest.materializations();name,target_adapter=self.materialized,context.target.dialect;adapter_specific_key=f"{name}_{target_adapter}";default_key=f"{name}_default"
		if adapter_specific_key in materializations:return materializations[adapter_specific_key]
		if default_key in materializations:return materializations[default_key]
	@property
	def vulcan_config_fields(self)->t.Set[str]:return super().vulcan_config_fields|{'cron',_N,_T,'physical_version',_F,'begin'}
	def to_vulcan(self,context:DbtContext,audit_definitions:t.Optional[t.Dict[str,ModelAudit]]=_A,virtual_environment_mode:VirtualEnvironmentMode=VirtualEnvironmentMode.default)->Model:
		F='warehouse';E='pre_statements';D='snowflake';C='ephemeral models';B='views';A='physical_properties';model_dialect=self.dialect(context);query=d.jinja_query(self.sql);kind=self.model_kind(context);optional_kwargs:t.Dict[str,t.Any]={};physical_properties:t.Dict[str,t.Any]={}
		if self.partition_by:
			if isinstance(kind,(ViewKind,EmbeddedKind)):logger.warning("Ignoring partition_by config for model '%s'; partition_by is not supported for %s.",self.name,B if isinstance(kind,ViewKind)else C)
			elif context.target.dialect==D:logger.warning("Ignoring partition_by config for model '%s' targeting %s. The partition_by config is not supported for Snowflake.",self.name,context.target.dialect)
			else:
				partitioned_by=[]
				if isinstance(self.partition_by,list):
					for p in self.partition_by:
						try:partitioned_by.append(d.parse_one(p,dialect=model_dialect))
						except SqlglotError as e:raise ConfigError(f"Failed to parse model '{self.canonical_name(context)}' partition_by field '{p}' in '{self.path}': {e}")from e
				elif isinstance(self.partition_by,dict):
					if context.target.dialect==_C:partitioned_by.append(self._big_query_partition_by_expr(context))
					else:logger.warning("Ignoring partition_by config for model '%s' targeting %s. The format of the config field is only supported for BigQuery.",self.name,context.target.dialect)
				if partitioned_by:optional_kwargs['partitioned_by']=partitioned_by
		if self.cluster_by:
			if isinstance(kind,(ViewKind,EmbeddedKind)):logger.warning("Ignoring cluster_by config for model '%s'; cluster_by is not supported for %s.",self.name,B if isinstance(kind,ViewKind)else C)
			else:
				clustered_by=[]
				for c in self.cluster_by:
					try:
						cluster_expr=exp.maybe_parse(c,into=exp.Cluster,prefix='CLUSTER BY',dialect=model_dialect)
						for expr in cluster_expr.expressions:clustered_by.append(expr.this if isinstance(expr,exp.Ordered)else expr)
					except SqlglotError as e:raise ConfigError(f"Failed to parse model '{self.canonical_name(context)}' cluster_by field '{c}' in '{self.path}': {e}")from e
				optional_kwargs['clustered_by']=clustered_by
		model_kwargs=self.vulcan_model_kwargs(context)
		if self.sql_header:model_kwargs[E].insert(0,d.jinja_statement(self.sql_header))
		if context.target.dialect==_C:
			dbt_max_partition_blob=self._dbt_max_partition_blob()
			if dbt_max_partition_blob:model_kwargs[E].append(d.jinja_statement(dbt_max_partition_blob))
			if self.partition_expiration_days is not _A:physical_properties['partition_expiration_days']=self.partition_expiration_days
			if self.require_partition_filter is not _A:physical_properties['require_partition_filter']=self.require_partition_filter
			if physical_properties:model_kwargs[A]=physical_properties
		if context.target.dialect==D:
			if self.snowflake_warehouse is not _A:model_kwargs['session_properties']={F:self.snowflake_warehouse}
			if self.model_materialization==Materialization.DYNAMIC_TABLE:
				if not self.snowflake_warehouse:raise ConfigError('`snowflake_warehouse` must be set for dynamic tables')
				if not self.target_lag:raise ConfigError('`target_lag` must be set for dynamic tables')
				model_kwargs[A]={F:self.snowflake_warehouse,'target_lag':self.target_lag}
		if context.target.dialect=='clickhouse':
			if self.model_materialization==Materialization.INCREMENTAL:
				if self.inserts_only:self.incremental_strategy='append'
				if self.incremental_strategy==_O:get_console().log_warning(f"The '{self.incremental_strategy}' incremental strategy is not supported - Vulcan will use the temp table/partition swap strategy.")
				if self.incremental_predicates:get_console().log_warning("Vulcan does not support 'incremental_predicates' - they will not be applied.")
			if self.query_settings:get_console().log_warning("Vulcan does not support the 'query_settings' model configuration parameter. Specify the query settings directly in the model query.")
			if self.engine:optional_kwargs['storage_format']=self.engine
			if self.order_by:
				order_by=[]
				for o in self.order_by if isinstance(self.order_by,list)else[self.order_by]:
					try:order_by.append(d.parse_one(o,dialect=model_dialect))
					except SqlglotError as e:raise ConfigError(f"Failed to parse model '{self.canonical_name(context)}' 'order_by' field '{o}' in '{self.path}': {e}")from e
				physical_properties['order_by']=order_by
			if self.primary_key:
				primary_key=[]
				for p in self.primary_key:
					try:primary_key.append(d.parse_one(p,dialect=model_dialect))
					except SqlglotError as e:raise ConfigError(f"Failed to parse model '{self.canonical_name(context)}' 'primary_key' field '{p}' in '{self.path}': {e}")from e
				physical_properties['primary_key']=primary_key
			if self.sharding_key:get_console().log_warning("Vulcan does not support the 'sharding_key' model configuration parameter or distributed materializations.")
			if self.ttl:physical_properties['ttl']=exp.var(self.ttl[0]if isinstance(self.ttl,list)else self.ttl)
			if self.settings:physical_properties.update({k:exp.var(v)for(k,v)in self.settings.items()})
			if physical_properties:model_kwargs[A]=physical_properties
		kind=self.model_kind(context)
		if self.grants and kind.supports_grants:model_kwargs['grants']=self.grants
		allow_partials=model_kwargs.pop(_T,_A)
		if allow_partials is _A:allow_partials=_G
		begin=model_kwargs.pop('begin',_A)
		if kind.is_incremental:
			if self.batch_size and isinstance(self.batch_size,str):
				if _N in model_kwargs:get_console().log_warning(f"Both 'interval_unit' and 'batch_size' are set for model '{self.canonical_name(context)}'. 'interval_unit' will be used.")
				else:model_kwargs[_N]=self.batch_size;self.batch_size=_A
			if begin:
				if _F in model_kwargs:get_console().log_warning(f"Both 'begin' and 'start' are set for model '{self.canonical_name(context)}'. 'start' will be used.")
				else:model_kwargs[_F]=begin
			if self.concurrent_batches is not _A and self.concurrent_batches is _H:depends_on=model_kwargs.get('depends_on',set());depends_on.add(self.canonical_name(context))
		model_kwargs[_F]=model_kwargs.get(_F,context.vulcan_config.model_defaults.start);model=create_sql_model(self.canonical_name(context),query,dialect=model_dialect,kind=kind,audit_definitions=audit_definitions,extract_dependencies_from_query=_H,allow_partials=allow_partials,virtual_environment_mode=virtual_environment_mode,dbt_node_info=self.node_info,**optional_kwargs,**model_kwargs);return model
	def _dbt_max_partition_blob(self)->t.Optional[str]:
		if not isinstance(self.partition_by,dict)or self.model_materialization!=Materialization.INCREMENTAL:return
		from vulcan.core.engine_adapter.bigquery import select_partitions_expr;data_type=self.partition_by[_E];select_max_partition_expr=select_partitions_expr('{{ adapter.resolve_schema(this) }}','{{ adapter.resolve_identifier(this) }}',data_type,granularity=self.partition_by.get(_B),catalog='{{ target.database }}');data_type=data_type.upper();default_value='NULL'
		if data_type in('DATE','DATETIME',_S):default_value=f"CAST('1970-01-01' AS {data_type})"
		return f"""
{{% if is_incremental() %}}
  DECLARE _dbt_max_partition {data_type} DEFAULT (
    COALESCE(({select_max_partition_expr}), {default_value})
  );
{{% endif %}}
"""