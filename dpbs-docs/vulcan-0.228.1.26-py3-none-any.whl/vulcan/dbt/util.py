from __future__ import annotations
import typing as t,agate
from dbt.version import get_installed_version
if t.TYPE_CHECKING:import pandas as pd
def _get_dbt_version()->t.Tuple[int,int,int]:A='0';dbt_version=get_installed_version();return int(dbt_version.major or A),int(dbt_version.minor or A),int(dbt_version.patch or A)
DBT_VERSION=_get_dbt_version()
if DBT_VERSION>=(1,8,0):from dbt_common.clients.agate_helper import table_from_data_flat,empty_table,as_matrix
else:from dbt.clients.agate_helper import table_from_data_flat,empty_table,as_matrix
def pandas_to_agate(df:pd.DataFrame)->agate.Table:return table_from_data_flat(df.to_dict(orient='records'),df.columns.tolist())