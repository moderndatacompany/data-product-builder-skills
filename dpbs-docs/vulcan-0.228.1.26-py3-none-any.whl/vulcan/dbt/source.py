from __future__ import annotations
_B='schema'
_A=None
import typing as t
from pydantic import Field
from vulcan.core.config.base import UpdateStrategy
from vulcan.dbt.column import ColumnConfig
from vulcan.dbt.common import GeneralConfig
from vulcan.dbt.relation import RelationType
from vulcan.dbt.util import DBT_VERSION
from vulcan.utils import AttributeDict
from vulcan.utils.errors import ConfigError
if t.TYPE_CHECKING:from vulcan.dbt.context import DbtContext
class SourceConfig(GeneralConfig):
	name:str='';source_name_:str=Field('',alias='source_name');fqn_:t.List[str]=Field(default_factory=list,alias='fqn');database:t.Optional[str]=_A;schema_:t.Optional[str]=Field(_A,alias=_B);identifier:t.Optional[str]=_A;loader:t.Optional[str]=_A;overrides:t.Optional[str]=_A;freshness:t.Optional[t.Dict[str,t.Any]]={};loaded_at_field:t.Optional[str]=_A;quoting:t.Dict[str,t.Optional[bool]]={};external:t.Optional[t.Dict[str,t.Any]]={};source_meta:t.Optional[t.Dict[str,t.Any]]={};columns:t.Dict[str,ColumnConfig]={};event_time:t.Optional[str]=_A;_canonical_name:t.Optional[str]=_A;_FIELD_UPDATE_STRATEGY:t.ClassVar[t.Dict[str,UpdateStrategy]]={**GeneralConfig._FIELD_UPDATE_STRATEGY,**{'columns':UpdateStrategy.KEY_EXTEND}}
	@property
	def table_name(self)->t.Optional[str]:return self.identifier or self.name
	@property
	def config_name(self)->str:return f"{self.source_name_}.{self.name}"
	@property
	def fqn(self)->str:return'.'.join(self.fqn_)
	def canonical_name(self,context:DbtContext)->str:
		A=False
		if self._canonical_name is _A:
			source=context.get_callable_macro('source')
			if not source:raise ConfigError("'source' macro not found.")
			try:relation=source(self.source_name_,self.name)
			except Exception as e:raise ConfigError(f"'source' macro failed for '{self.config_name}' with exception '{e}'.")
			relation=relation.quote(database=A,schema=A,identifier=A)
			if relation.database==context.target.database:relation=relation.include(database=A)
			self._canonical_name=relation.render()
		return self._canonical_name
	@property
	def relation_info(self)->AttributeDict:
		extras={};external_location=self.source_meta.get('external_location',_A)if self.source_meta else _A
		if external_location:extras['external']=external_location.replace('{name}',self.table_name)
		if DBT_VERSION>=(1,9,0)and self.event_time:extras['event_time_filter']={'field_name':self.event_time}
		return AttributeDict({'database':self.database,_B:self.schema_,'identifier':self.table_name,'type':RelationType.External.value,'quote_policy':AttributeDict(self.quoting),**extras})