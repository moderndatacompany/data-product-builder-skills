from __future__ import annotations
_O='version'
_N='test_metadata'
_M='materialization_'
_L='sources'
_K='vulcan_partial_parse.msgpack'
_J='source'
_I='snapshot'
_H='seed'
_G='dbt'
_F='__'
_E='.'
_D='model'
_C=True
_B=False
_A=None
import json,logging,os,re,typing as t
from argparse import Namespace
from collections import defaultdict
from functools import cached_property
from pathlib import Path
from dbt import flags
from vulcan.dbt.util import DBT_VERSION
from vulcan.utils.conversions import make_serializable
if DBT_VERSION>=(1,6,0):from dbt import constants as dbt_constants;dbt_constants.PARTIAL_PARSE_FILE_NAME=_K
else:from dbt.parser import manifest as dbt_manifest;dbt_manifest.PARTIAL_PARSE_FILE_NAME=_K
import jinja2
from dbt.adapters.factory import register_adapter,reset_adapters
from dbt.config import Profile,Project,RuntimeConfig
from dbt.config.profile import read_profile
from dbt.config.renderer import DbtProjectYamlRenderer,ProfileRenderer
from dbt.parser.manifest import ManifestLoader
try:from dbt.parser.sources import merge_freshness
except ImportError:from dbt.parser.sources import merge_source_freshness as merge_freshness
from dbt.tracking import do_not_track
from vulcan.core import constants as c
from vulcan.utils.errors import VulcanError
from vulcan.core.config import ModelDefaultsConfig
from vulcan.dbt.builtin import BUILTIN_FILTERS,BUILTIN_GLOBALS,OVERRIDDEN_MACROS
from vulcan.dbt.common import Dependencies
from vulcan.dbt.model import ModelConfig
from vulcan.dbt.package import HookConfig,MacroConfig,MaterializationConfig
from vulcan.dbt.seed import SeedConfig
from vulcan.dbt.source import SourceConfig
from vulcan.dbt.target import TargetConfig
from vulcan.dbt.test import TestConfig
from vulcan.dbt.util import DBT_VERSION
from vulcan.utils.cache import FileCache
from vulcan.utils.errors import ConfigError
from vulcan.utils.jinja import MacroInfo,MacroReference,extract_call_names,jinja_call_arg_name
from sqlglot.helper import ensure_list
if t.TYPE_CHECKING:from dbt.contracts.graph.manifest import Macro,Manifest;from dbt.contracts.graph.nodes import ManifestNode,SourceDefinition;from vulcan.utils.jinja import CallNames
logger=logging.getLogger(__name__)
TestConfigs=t.Dict[str,TestConfig]
ModelConfigs=t.Dict[str,ModelConfig]
SeedConfigs=t.Dict[str,SeedConfig]
SourceConfigs=t.Dict[str,SourceConfig]
MacroConfigs=t.Dict[str,MacroConfig]
HookConfigs=t.Dict[str,HookConfig]
MaterializationConfigs=t.Dict[str,MaterializationConfig]
IGNORED_PACKAGES={'elementary'}
BUILTIN_CALLS={*BUILTIN_GLOBALS,*BUILTIN_FILTERS}
if DBT_VERSION>=(1,6,0):from dbt.contracts.graph.semantic_manifest import SemanticManifest;SemanticManifest.validate=lambda _:_C
class ManifestHelper:
	def __init__(self,project_path:Path,profiles_path:Path,profile_name:str,target:TargetConfig,variable_overrides:t.Optional[t.Dict[str,t.Any]]=_A,cache_dir:t.Optional[str]=_A,model_defaults:t.Optional[ModelDefaultsConfig]=_A):
		self.project_path=project_path;self.profiles_path=profiles_path;self.profile_name=profile_name;self.target=target;self.variable_overrides=variable_overrides or{};self.model_defaults=model_defaults or ModelDefaultsConfig();(self.__manifest):t.Optional[Manifest]=_A;(self._project_name):str='';(self._is_loaded):bool=_B;(self._tests_per_package):t.Dict[str,TestConfigs]=defaultdict(dict);(self._models_per_package):t.Dict[str,ModelConfigs]=defaultdict(dict);(self._seeds_per_package):t.Dict[str,SeedConfigs]=defaultdict(dict);(self._sources_per_package):t.Dict[str,SourceConfigs]=defaultdict(dict);(self._macros_per_package):t.Dict[str,MacroConfigs]=defaultdict(dict);(self._macro_flatten_dependencies):t.Dict[str,t.Dict[str,Dependencies]]=defaultdict(dict);(self._tests_by_owner):t.Dict[str,t.List[TestConfig]]=defaultdict(list);(self._disabled_refs):t.Optional[t.Set[str]]=_A;(self._disabled_sources):t.Optional[t.Set[str]]=_A
		if cache_dir is not _A:
			cache_path=Path(cache_dir)
			if not cache_path.is_absolute():cache_path=self.project_path/cache_path
		else:cache_path=self.project_path/c.CACHE
		(self._call_cache):FileCache[t.Dict[str,t.List[CallNames]]]=FileCache(cache_path,'jinja_calls');(self._on_run_start_per_package):t.Dict[str,HookConfigs]=defaultdict(dict);(self._on_run_end_per_package):t.Dict[str,HookConfigs]=defaultdict(dict);(self._materializations):MaterializationConfigs={}
	def tests(self,package_name:t.Optional[str]=_A)->TestConfigs:self._load_all();return self._tests_per_package[package_name or self._project_name]
	def models(self,package_name:t.Optional[str]=_A)->ModelConfigs:self._load_all();return self._models_per_package[package_name or self._project_name]
	def seeds(self,package_name:t.Optional[str]=_A)->SeedConfigs:self._load_all();return self._seeds_per_package[package_name or self._project_name]
	def sources(self,package_name:t.Optional[str]=_A)->SourceConfigs:self._load_all();return self._sources_per_package[package_name or self._project_name]
	def macros(self,package_name:t.Optional[str]=_A)->MacroConfigs:self._load_all();return self._macros_per_package[package_name or self._project_name]
	def on_run_start(self,package_name:t.Optional[str]=_A)->HookConfigs:self._load_all();return self._on_run_start_per_package[package_name or self._project_name]
	def on_run_end(self,package_name:t.Optional[str]=_A)->HookConfigs:self._load_all();return self._on_run_end_per_package[package_name or self._project_name]
	def materializations(self)->MaterializationConfigs:self._load_all();return self._materializations
	@property
	def all_macros(self)->t.Dict[str,t.Dict[str,MacroInfo]]:
		self._load_all();result:t.Dict[str,t.Dict[str,MacroInfo]]=defaultdict(dict)
		for(package_name,macro_configs)in self._macros_per_package.items():
			for(macro_name,macro_config)in macro_configs.items():result[package_name][macro_name]=macro_config.info
		return result
	@cached_property
	def flat_graph(self)->t.Dict[str,t.Any]:E='saved_queries';D='semantic_models';C='metrics';B='groups';A='exposures';return{A:{k:make_serializable(v.to_dict(omit_none=_B))for(k,v)in getattr(self._manifest,A,{}).items()},B:{k:make_serializable(v.to_dict(omit_none=_B))for(k,v)in getattr(self._manifest,B,{}).items()},C:{k:make_serializable(v.to_dict(omit_none=_B))for(k,v)in getattr(self._manifest,C,{}).items()},'nodes':{k:make_serializable(v.to_dict(omit_none=_B))for(k,v)in self._manifest.nodes.items()},_L:{k:make_serializable(v.to_dict(omit_none=_B))for(k,v)in self._manifest.sources.items()},D:{k:make_serializable(v.to_dict(omit_none=_B))for(k,v)in getattr(self._manifest,D,{}).items()},E:{k:make_serializable(v.to_dict(omit_none=_B))for(k,v)in getattr(self._manifest,E,{}).items()}}
	def _load_all(self)->_A:
		if self._is_loaded:return
		self._calls={k:(v,_B)for(k,v)in(self._call_cache.get('')or{}).items()};self._load_macros();self._load_materializations();self._load_sources();self._load_tests();self._load_models_and_seeds();self._load_on_run_start_end();self._is_loaded=_C;self._call_cache.put('',value={k:v for(k,(v,used))in self._calls.items()if used})
	def _load_sources(self)->_A:
		A='freshness'
		for source in self._manifest.sources.values():source_dict=source.to_dict();source_dict.pop(A,_A);source_config_dict=_config(source);source_config_dict.pop(A,_A);source_config_freshness=getattr(source.config,A,_A);freshness=merge_freshness(source.freshness,source_config_freshness)if source_config_freshness else source.freshness;source_config=SourceConfig(**{**source_dict,**source_config_dict,A:freshness.to_dict()if freshness else _A});self._sources_per_package[source.package_name][source_config.config_name]=source_config
	def _load_macros(self)->_A:
		A='test_'
		for macro in self._manifest.macros.values():
			if macro.name.startswith(_M):continue
			if macro.name.startswith(A):macro.macro_sql=_convert_jinja_test_to_macro(macro.macro_sql)
			dependencies=Dependencies(macros=_macro_references(self._manifest,macro))
			if not macro.name.startswith(A):dependencies=dependencies.union(self._extra_dependencies(macro.macro_sql,macro.package_name))
			self._macros_per_package[macro.package_name][macro.name]=MacroConfig(info=MacroInfo(definition=macro.macro_sql,depends_on=dependencies.macros),dependencies=dependencies,path=Path(macro.original_file_path))
		adapter_macro_names={name[name.find(_F)+2:]for name in self._macros_per_package.get(_G,{})if _F in name}
		for macros in self._macros_per_package.values():
			for(name,macro_config)in macros.items():
				pos=name.find(_F)
				if pos>0 and name[pos+2:]in adapter_macro_names:macro_config.info.is_top_level=_C
	def _load_materializations(self)->_A:
		for macro in self._manifest.macros.values():
			if macro.name.startswith(_M):
				name_parts=macro.name.split('_')
				if len(name_parts)>=3:mat_name='_'.join(name_parts[1:-1]);adapter=name_parts[-1];dependencies=Dependencies(macros=_macro_references(self._manifest,macro));macro.macro_sql=_strip_jinja_materialization_tags(macro.macro_sql);dependencies=dependencies.union(self._extra_dependencies(macro.macro_sql,macro.package_name));materialization_config=MaterializationConfig(name=mat_name,adapter=adapter,definition=macro.macro_sql,dependencies=dependencies,path=Path(macro.original_file_path));key=f"{mat_name}_{adapter}";self._materializations[key]=materialization_config
	def _load_tests(self)->_A:
		for node in self._manifest.nodes.values():
			if node.resource_type!='test':continue
			skip_test=_B;refs=_refs(node)
			for ref in refs:
				if self._is_disabled_ref(ref):logger.info("Skipping test '%s' which references a disabled model '%s'",node.name,ref);skip_test=_C;break
			if skip_test:continue
			dependencies=Dependencies(macros=_macro_references(self._manifest,node),refs=refs,sources=_sources(node));dependencies.macros.append(MacroReference(package=_G,name='get_where_subquery'));dependencies.macros.append(MacroReference(package=_G,name='should_store_failures'));sql=node.raw_code if DBT_VERSION>=(1,3,0)else node.raw_sql;dependencies=dependencies.union(self._extra_dependencies(sql,node.package_name));dependencies=dependencies.union(self._flatten_dependencies_from_macros(dependencies.macros,node.package_name));test_model=_test_model(node);node_config=_node_base_config(node);node_config['name']=_build_test_name(node,dependencies);test=TestConfig(sql=sql,model_name=test_model,test_kwargs=node.test_metadata.kwargs if hasattr(node,_N)else{},dependencies=dependencies,**node_config);self._tests_per_package[node.package_name][node.unique_id]=test
			if test_model:self._tests_by_owner[test_model].append(test)
	def _load_models_and_seeds(self)->_A:
		for node in self._manifest.nodes.values():
			if node.resource_type not in(_D,_H,_I)or node.package_name in IGNORED_PACKAGES:continue
			macro_references=_macro_references(self._manifest,node);all_tests=self._tests_by_owner[node.name]+self._tests_by_owner[f"{node.package_name}.{node.name}"];tests=[test for test in all_tests if not test.is_standalone];node_config=_node_base_config(node);node_name=node.name;node_version=getattr(node,_O,_A)
			if node_version:node_name=f"{node_name}_v{node_version}"
			if node.resource_type in{_D,_I}:
				sql=node.raw_code if DBT_VERSION>=(1,3,0)else node.raw_sql;dependencies=Dependencies(macros=macro_references,refs=_refs(node),sources=_sources(node));dependencies=dependencies.union(self._extra_dependencies(sql,node.package_name,track_all_model_attrs=_C))
				for hook in[*node_config.get('pre-hook',[]),*node_config.get('post-hook',[])]:dependencies=dependencies.union(self._extra_dependencies(hook['sql'],node.package_name,track_all_model_attrs=_C))
				dependencies=dependencies.union(self._flatten_dependencies_from_macros(dependencies.macros,node.package_name));self._models_per_package[node.package_name][node_name]=ModelConfig(**dict(node_config,sql=sql,dependencies=dependencies,tests=tests))
			else:self._seeds_per_package[node.package_name][node_name]=SeedConfig(**dict(node_config,dependencies=Dependencies(macros=macro_references),tests=tests))
	def _load_on_run_start_end(self)->_A:
		B='index';A='on-run-start'
		for node in self._manifest.nodes.values():
			if node.resource_type=='operation'and set(node.tags)&{A,'on-run-end'}:
				sql=node.raw_code if DBT_VERSION>=(1,3,0)else node.raw_sql;node_name=node.name;node_path=Path(node.original_file_path);dependencies=Dependencies(macros=_macro_references(self._manifest,node),refs=_refs(node),sources=_sources(node));dependencies=dependencies.union(self._extra_dependencies(sql,node.package_name));dependencies=dependencies.union(self._flatten_dependencies_from_macros(dependencies.macros,node.package_name))
				if A in node.tags:self._on_run_start_per_package[node.package_name][node_name]=HookConfig(sql=sql,index=getattr(node,B,_A)or 0,path=node_path,dependencies=dependencies)
				else:self._on_run_end_per_package[node.package_name][node_name]=HookConfig(sql=sql,index=getattr(node,B,_A)or 0,path=node_path,dependencies=dependencies)
	@property
	def _manifest(self)->Manifest:
		if not self.__manifest:
			try:self.__manifest=self._load_manifest()
			except Exception as ex:raise VulcanError(f"Failed to load dbt manifest: {ex}")from ex
		return self.__manifest
	def _load_manifest(self)->Manifest:
		do_not_track();variables=self.variable_overrides if DBT_VERSION>=(1,5,0)else json.dumps(self.variable_overrides);args:Namespace=Namespace(vars=variables,profile=self.profile_name,project_dir=str(self.project_path),profiles_dir=str(self.profiles_path),target=self.target.name,macro_debugging=_B,REQUIRE_RESOURCE_NAMES_WITHOUT_SPACES=_C);flags.set_from_args(args,_A)
		if DBT_VERSION>=(1,8,0):from dbt_common.context import set_invocation_context;set_invocation_context(os.environ)
		profile=self._load_profile();project=self._load_project(profile)
		if not any(k in project.models for k in('start','+start'))and not self.model_defaults.start:raise ConfigError("Vulcan requires a start date in order to have a finite range of backfilling data. Add start to the 'models:' block in dbt_project.yml. https://vulcan.readthedocs.io/en/stable/integrations/dbt/#setting-model-backfill-start-dates")
		runtime_config=RuntimeConfig.from_parts(project,profile,args);self._project_name=project.project_name
		if DBT_VERSION>=(1,8,0):from dbt.mp_context import get_mp_context;register_adapter(runtime_config,get_mp_context())
		else:register_adapter(runtime_config)
		manifest=ManifestLoader.get_full_manifest(runtime_config);manifest.semantic_models={};reset_adapters();return manifest
	def _load_project(self,profile:Profile)->Project:project_renderer=DbtProjectYamlRenderer(profile,cli_vars=self.variable_overrides);return Project.from_project_root(str(self.project_path),project_renderer)
	def _load_profile(self)->Profile:profile_renderer=ProfileRenderer(cli_vars=self.variable_overrides);raw_profiles=read_profile(str(self.profiles_path));return Profile.from_raw_profiles(raw_profiles=raw_profiles,profile_name=self.profile_name,renderer=profile_renderer,target_override=self.target.name)
	def _is_disabled_ref(self,ref:str)->bool:
		if self._disabled_refs is _A:self._load_disabled()
		return ref in self._disabled_refs
	def _is_disabled_source(self,source:str)->bool:
		if self._disabled_sources is _A:self._load_disabled()
		return source in self._disabled_sources
	def _load_disabled(self)->_A:
		self._disabled_refs=set();self._disabled_sources=set()
		for nodes in self._manifest.disabled.values():
			for node in nodes:
				if node.resource_type in(_D,_I,_H):self._disabled_refs.add(f"{node.package_name}.{node.name}");self._disabled_refs.add(node.name)
				elif node.resource_type==_J:self._disabled_sources.add(f"{node.package_name}.{node.name}")
		for node in self._manifest.nodes.values():
			if node.resource_type in(_D,_I,_H):self._disabled_refs.discard(node.name)
			elif node.resource_type==_J:self._disabled_sources.discard(node.name)
	def _flatten_dependencies_from_macros(self,macros:t.List[MacroReference],default_package:str,visited:t.Optional[t.Set[t.Tuple[str,str]]]=_A)->Dependencies:
		if visited is _A:visited=set()
		dependencies=Dependencies()
		for macro in macros:
			macro_package=macro.package or default_package
			if(macro_package,macro.name)in visited:continue
			visited.add((macro_package,macro.name));macro_dependencies=self._macro_flatten_dependencies.get(macro_package,{}).get(macro.name)
			if not macro_dependencies:
				macro_config=self._macros_per_package[macro_package].get(macro.name)
				if not macro_config:continue
				macro_dependencies=macro_config.dependencies.union(self._flatten_dependencies_from_macros(macro_config.dependencies.macros,macro_package,visited=visited));macro_dependencies.macros=[];self._macro_flatten_dependencies[macro_package][macro.name]=macro_dependencies
			dependencies=dependencies.union(macro_dependencies)
		return dependencies
	def _extra_dependencies(self,target:str,package:str,track_all_model_attrs:bool=_B)->Dependencies:
		B='var';A='ref';dependencies=Dependencies();all_model_attrs=_B
		for(call_name,node)in extract_call_names(target,cache=self._calls):
			if call_name[0]=='config':continue
			if track_all_model_attrs and not all_model_attrs and isinstance(node,jinja2.nodes.Call)and any(isinstance(a,jinja2.nodes.Name)and a.name==_D for a in node.args):all_model_attrs=_C
			if isinstance(node,jinja2.nodes.Getattr):
				if call_name[0]==_D:dependencies.model_attrs.attrs.add(call_name[1])
			elif call_name[0]==_J:
				args=[jinja_call_arg_name(arg)for arg in node.args]
				if args and all(arg for arg in args):
					source=_E.join(args)
					if not self._is_disabled_source(source):dependencies.sources.add(source)
				dependencies.macros.append(MacroReference(name=_J))
			elif call_name[0]==A:
				args=[jinja_call_arg_name(arg)for arg in node.args]
				if args and all(arg for arg in args):
					ref=_E.join(args)
					if not self._is_disabled_ref(ref):dependencies.refs.add(ref)
				dependencies.macros.append(MacroReference(name=A))
			elif call_name[0]==B:
				args=[jinja_call_arg_name(arg)for arg in node.args]
				if args and args[0]:dependencies.variables.add(args[0])
				else:dependencies.has_dynamic_var_names=_C
				dependencies.macros.append(MacroReference(name=B))
			elif len(call_name)==1:
				macro_name=call_name[0]
				if macro_name in BUILTIN_CALLS:continue
				if f"macro.{package}.{macro_name}"not in self._manifest.macros and f"macro.dbt.{macro_name}"in self._manifest.macros:package_name:t.Optional[str]=_G
				else:package_name=package if package!=self._project_name else _A
				_macro_reference_if_not_overridden(package_name,macro_name,dependencies.macros.append)
			elif call_name[0]!='adapter':_macro_reference_if_not_overridden(call_name[0],call_name[1],dependencies.macros.append)
		if all_model_attrs:dependencies.model_attrs.all_attrs=_C
		return dependencies
def _macro_reference_if_not_overridden(package:t.Optional[str],name:str,if_not_overridden:t.Callable[[MacroReference],_A])->_A:
	reference=MacroReference(package=package,name=name)
	if reference not in OVERRIDDEN_MACROS:if_not_overridden(reference)
def _config(node:t.Union[ManifestNode,SourceDefinition])->t.Dict[str,t.Any]:return node.config.to_dict()
def _macro_references(manifest:Manifest,node:t.Union[ManifestNode,Macro])->t.Set[MacroReference]:
	result:t.Set[MacroReference]=set()
	if not hasattr(node,'depends_on'):return result
	for macro_node_id in node.depends_on.macros:
		if not macro_node_id or macro_node_id=='None':continue
		macro_node=manifest.macros[macro_node_id];macro_name=macro_node.name;macro_package=macro_node.package_name if macro_node.package_name!=node.package_name else _A;_macro_reference_if_not_overridden(macro_package,macro_name,result.add)
	return result
def _refs(node:ManifestNode)->t.Set[str]:
	if DBT_VERSION>=(1,5,0):
		result:t.Set[str]=set()
		if not hasattr(node,'refs'):return result
		for r in node.refs:
			ref_name=f"{r.package}.{r.name}"if r.package else r.name
			if getattr(r,_O,_A):ref_name=f"{ref_name}_v{r.version}"
			result.add(ref_name)
		return result
	return{_E.join(r)for r in node.refs}
def _sources(node:ManifestNode)->t.Set[str]:return{_E.join(s)for s in getattr(node,_L,[])}
def _model_node_id(model_name:str,package:str)->str:return f"model.{package}.{model_name}"
def _test_model(node:ManifestNode)->t.Optional[str]:
	attached_node=getattr(node,'attached_node',_A)
	if attached_node:
		pieces=attached_node.split(_E)
		if pieces[0]in[_D,_H]:
			if len(pieces)==4:return f"{pieces[2]}_{pieces[3]}"
			return pieces[-1]
		return
	key_name=getattr(node,'file_key_name',_A)
	if key_name:pieces=key_name.split(_E);return pieces[-1]if pieces[0]in['models','seeds']else _A
def _node_base_config(node:ManifestNode)->t.Dict[str,t.Any]:return{**_config(node),**node.to_dict(),'path':Path(node.original_file_path)}
def _convert_jinja_test_to_macro(test_jinja:str)->str:
	TEST_TAG_REGEX='\\s*{%-?\\s*test\\s+';ENDTEST_REGEX='{%-?\\s*endtest\\s*-?%}';match=re.match(TEST_TAG_REGEX,test_jinja)
	if not match:return test_jinja
	test_tag=test_jinja[:match.span()[-1]];macro_tag=re.sub('({%-?\\s*)test\\s+','\\1macro test_',test_tag);macro=macro_tag+test_jinja[match.span()[-1]:];return re.sub(ENDTEST_REGEX,lambda m:m.group(0).replace('endtest','endmacro'),macro)
def _strip_jinja_materialization_tags(materialization_jinja:str)->str:
	MATERIALIZATION_TAG_REGEX='\\s*{%-?\\s*materialization\\s+[^%]*%}\\s*\\n?';ENDMATERIALIZATION_REGEX='{%-?\\s*endmaterialization\\s*-?%}\\s*\\n?'
	if not re.match(MATERIALIZATION_TAG_REGEX,materialization_jinja):return materialization_jinja
	materialization_jinja=re.sub(MATERIALIZATION_TAG_REGEX,'',materialization_jinja,flags=re.IGNORECASE);materialization_jinja=re.sub(ENDMATERIALIZATION_REGEX,'',materialization_jinja,flags=re.IGNORECASE);return materialization_jinja.strip()
def _build_test_name(node:ManifestNode,dependencies:Dependencies)->str:
	if not hasattr(node,_N):return node.name
	model_name=_test_model(node);source_name=_A
	if not model_name and dependencies.sources:source_parts=list(dependencies.sources)[0].split(_E);source_name='_'.join(source_parts)if len(source_parts)==2 else source_parts[-1]
	entity_name=model_name or source_name or'';entity_name=f"_{entity_name}"if entity_name else'';name_prefix=''
	if(namespace:=getattr(node.test_metadata,'namespace',_A)):name_prefix+=f"{namespace}_"
	if source_name and not model_name:name_prefix+='source_'
	metadata_kwargs=node.test_metadata.kwargs;arg_val_parts=[]
	for(arg,val)in sorted(metadata_kwargs.items()):
		if arg==_D:continue
		if isinstance(val,dict):val=list(val.values())
		val=[re.sub('[^0-9a-zA-Z_]+','_',str(v))for v in ensure_list(val)];arg_val_parts.extend(val)
	unique_args=_F.join(arg_val_parts)if arg_val_parts else'';unique_args=f"_{unique_args}"if unique_args else'';auto_name=f"{name_prefix}{node.test_metadata.name}{entity_name}{unique_args}"
	if node.name==auto_name:return node.name
	custom_prefix=name_prefix if source_name and not model_name else'';return f"{custom_prefix}{node.name}{entity_name}{unique_args}"