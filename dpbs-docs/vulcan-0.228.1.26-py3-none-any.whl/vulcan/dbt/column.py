from __future__ import annotations
import typing as t,logging
from sqlglot import exp,parse_one
from sqlglot.helper import ensure_list
from vulcan.dbt.common import GeneralConfig
from vulcan.utils.conversions import ensure_bool
from vulcan.utils.pydantic import field_validator
logger=logging.getLogger(__name__)
def yaml_to_columns(yaml:t.Dict[str,ColumnConfig]|t.List[t.Dict[str,ColumnConfig]])->t.Dict[str,ColumnConfig]:
	columns={};mappings:t.List[t.Dict[str,ColumnConfig]]=ensure_list(yaml)
	for column in mappings:config=ColumnConfig(**column);columns[config.name]=config
	return columns
def column_types_to_vulcan(columns:t.Dict[str,ColumnConfig],dialect:t.Optional[str]=None)->t.Dict[str,exp.DataType]:
	col_types_to_vulcan:t.Dict[str,exp.DataType]={}
	for(name,column)in columns.items():
		if column.enabled and column.data_type:
			column_def=parse_one(f"{name} {column.data_type}",into=exp.ColumnDef,dialect=dialect or'')
			if column_def.args.get('constraints'):logger.warning(f"Ignoring unsupported constraints for column '{name}' with definition '{column.data_type}'. Please refer to github.com/TobikoData/vulcan/issues/4717 for more information.")
			kind=column_def.kind
			if kind:col_types_to_vulcan[name]=kind
	return col_types_to_vulcan
def column_descriptions_to_vulcan(columns:t.Dict[str,ColumnConfig])->t.Dict[str,str]:return{name:column.description for(name,column)in columns.items()if column.enabled and column.description}
class ColumnConfig(GeneralConfig):
	name:str;data_type:t.Optional[str]=None;quote:t.Optional[bool]=False
	@field_validator('quote',mode='before')
	@classmethod
	def _validate_bool(cls,v:str)->bool:return ensure_bool(v)