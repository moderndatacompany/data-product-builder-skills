from __future__ import annotations
_B="Converting '%s' to vulcan format"
_A=None
import logging,sys,typing as t,vulcan.core.dialect as d
from pathlib import Path
from collections import defaultdict
from vulcan.core.config import Config,ConnectionConfig,GatewayConfig,ModelDefaultsConfig,DbtConfig as RootDbtConfig
from vulcan.core.environment import EnvironmentStatements
from vulcan.core.loader import CacheBase,LoadedProject,Loader
from vulcan.core.macros import MacroRegistry,macro
from vulcan.core.model import Model,ModelCache
from vulcan.core.signal import signal
from vulcan.dbt.basemodel import BMC,BaseModelConfig
from vulcan.dbt.common import Dependencies
from vulcan.dbt.context import DbtContext
from vulcan.dbt.model import ModelConfig
from vulcan.dbt.profile import Profile
from vulcan.dbt.project import Project
from vulcan.dbt.target import TargetConfig
from vulcan.utils import UniqueKeyDict
from vulcan.utils.errors import ConfigError,MissingModelError,BaseMissingReferenceError
from vulcan.utils.jinja import JinjaMacroRegistry,make_jinja_registry
if sys.version_info>=(3,12):from importlib import metadata
else:import importlib_metadata as metadata
if t.TYPE_CHECKING:from vulcan.core.audit import Audit,ModelAudit;from vulcan.core.context import GenericContext
logger=logging.getLogger(__name__)
def vulcan_config(project_root:t.Optional[Path]=_A,state_connection:t.Optional[ConnectionConfig]=_A,dbt_profile_name:t.Optional[str]=_A,dbt_target_name:t.Optional[str]=_A,variables:t.Optional[t.Dict[str,t.Any]]=_A,threads:t.Optional[int]=_A,register_comments:t.Optional[bool]=_A,infer_state_schema_name:bool=False,profiles_dir:t.Optional[Path]=_A,**kwargs:t.Any)->Config:
	A='gateways';project_root=project_root or Path();context=DbtContext(project_root=project_root,profiles_dir=profiles_dir,profile_name=dbt_profile_name);profile=Profile.load(context,target_name=dbt_target_name);model_defaults=kwargs.pop('model_defaults',ModelDefaultsConfig())
	if model_defaults.dialect is _A:model_defaults.dialect=profile.target.dialect
	target_to_vulcan_args={'register_comments':register_comments or False};loader=kwargs.pop('loader',DbtLoader)
	if not issubclass(loader,DbtLoader):raise ConfigError('The loader must be a DbtLoader.')
	if threads is not _A:profile.target.threads=threads
	gateway_kwargs={}
	if infer_state_schema_name:
		profile_name=context.profile_name;target_schema=profile.target.schema_
		if not target_schema:raise ConfigError(f"Target '{profile.target_name}' does not specify a schema.\nA schema is required in order to infer where to store Vulcan state")
		inferred_state_schema_name=f"vulcan_state_{profile_name}_{target_schema}";logger.info('Inferring state schema: %s',inferred_state_schema_name);gateway_kwargs['state_schema']=inferred_state_schema_name
	return Config(loader=loader,loader_kwargs=dict(profiles_dir=profiles_dir),model_defaults=model_defaults,variables=variables or{},dbt=RootDbtConfig(infer_state_schema_name=infer_state_schema_name),**{'default_gateway':profile.target_name if A not in kwargs else'',A:{profile.target_name:GatewayConfig(connection=profile.target.to_vulcan(**target_to_vulcan_args),state_connection=state_connection,**gateway_kwargs)},**kwargs})
class DbtLoader(Loader):
	def __init__(self,context:GenericContext,path:Path,profiles_dir:t.Optional[Path]=_A)->_A:(self._projects):t.List[Project]=[];(self._macros_max_mtime):t.Optional[float]=_A;self._profiles_dir=profiles_dir;super().__init__(context,path)
	def load(self,*,validate_models:bool=True)->LoadedProject:self._projects=[];return super().load(validate_models=validate_models)
	def _load_scripts(self)->t.Tuple[MacroRegistry,JinjaMacroRegistry]:
		macro_files=list(Path(self.config_path,'macros').glob('**/*.sql'))
		for file in macro_files:self._track_file(file)
		return macro.get_registry(),JinjaMacroRegistry()
	def _load_models(self,macros:MacroRegistry,jinja_macros:JinjaMacroRegistry,gateway:t.Optional[str],audits:UniqueKeyDict[str,ModelAudit],signals:UniqueKeyDict[str,signal])->UniqueKeyDict[str,Model]:
		models:UniqueKeyDict[str,Model]=UniqueKeyDict('models')
		def _to_vulcan(config:BMC,context:DbtContext)->Model:logger.debug(_B,config.canonical_name(context));return config.to_vulcan(context,audit_definitions=audits,virtual_environment_mode=self.config.virtual_environment_mode)
		for project in self._load_projects():
			macros_max_mtime=self._macros_max_mtime;yaml_max_mtimes=self._compute_yaml_max_mtime_per_subfolder(project.context.project_root);cache=DbtLoader._Cache(self,project,macros_max_mtime,yaml_max_mtimes);logger.debug('Converting models to vulcan')
			for package in project.packages.values():
				package_context=project.context.copy();package_context.set_and_render_variables(package.variables,package.name);package_models:t.Dict[str,BaseModelConfig]={**package.models,**package.seeds};package_models_by_path:t.Dict[Path,t.List[BaseModelConfig]]=defaultdict(list)
				for model in package_models.values():
					if isinstance(model,ModelConfig)and not model.sql.strip():logger.info(f"Skipping empty model '{model.name}' at path '{model.path}'.");continue
					package_models_by_path[model.path].append(model)
				for(path,path_models)in package_models_by_path.items():
					vulcan_models=cache.get_or_load_models(path,loader=lambda:[_to_vulcan(model,package_context)for model in path_models])
					for vulcan_model in vulcan_models:models[vulcan_model.fqn]=vulcan_model
			models.update(self._load_external_models(audits,cache))
		return models
	def _load_audits(self,macros:MacroRegistry,jinja_macros:JinjaMacroRegistry)->UniqueKeyDict[str,Audit]:
		audits:UniqueKeyDict=UniqueKeyDict('audits')
		for project in self._load_projects():
			logger.debug('Converting audits to vulcan')
			for package in project.packages.values():
				package_context=project.context.copy();package_context.set_and_render_variables(package.variables,package.name)
				for test in package.tests.values():
					logger.debug(_B,test.name)
					try:audits[test.canonical_name]=test.to_vulcan(package_context)
					except BaseMissingReferenceError as e:ref_type='model'if isinstance(e,MissingModelError)else'source';logger.warning("Skipping audit '%s' because %s '%s' is not a valid ref",test.name,ref_type,e.ref)
		return audits
	def _load_projects(self)->t.List[Project]:
		if not self._projects:
			target_name=self.context.selected_gateway;self._projects=[];project=Project.load(DbtContext(project_root=self.config_path,profiles_dir=self._profiles_dir,target_name=target_name,vulcan_config=self.config),variables=self.config.variables);self._projects.append(project);context_default_catalog=self.context.default_catalog or''
			if project.context.target.database!=context_default_catalog:raise ConfigError(f"Project default catalog ('{project.context.target.database}') does not match context default catalog ('{context_default_catalog}').")
			for path in project.project_files:self._track_file(path)
			context=project.context;macros_mtimes:t.List[float]=[]
			for(package_name,package)in project.packages.items():context.add_sources(package.sources);context.add_seeds(package.seeds);context.add_models(package.models);macros_mtimes.extend([self._path_mtimes[m.path]for m in package.macros.values()if m.path in self._path_mtimes])
			for(package_name,macro_infos)in context.manifest.all_macros.items():context.add_macros(macro_infos,package=package_name)
			self._macros_max_mtime=max(macros_mtimes)if macros_mtimes else _A
		return self._projects
	def _load_requirements(self)->t.Tuple[t.Dict[str,str],t.Set[str]]:
		requirements,excluded_requirements=super()._load_requirements();target_packages=['dbt-core']
		for project in self._load_projects():target_packages.append(f"dbt-{project.context.target.type}")
		for target_package in target_packages:
			if target_package in requirements or target_package in excluded_requirements:continue
			try:requirements[target_package]=metadata.version(target_package)
			except metadata.PackageNotFoundError:from vulcan.core.console import get_console;get_console().log_warning(f"dbt package {target_package} is not installed.")
		return requirements,excluded_requirements
	def _load_environment_statements(self,macros:MacroRegistry)->t.List[EnvironmentStatements]:
		product_details=dict(discoverable=self.config.discoverable,version=self.config.version,alignment=self.config.alignment);hooks_by_package_name:t.Dict[str,EnvironmentStatements]={};project_names:t.Set[str]=set();dialect=self.config.dialect
		for project in self._load_projects():
			for(package_name,package)in project.packages.items():
				package_context=project.context.copy();package_context.set_and_render_variables(package.variables,package_name);on_run_start:t.List[str]=[on_run_hook.sql for on_run_hook in sorted(package.on_run_start.values(),key=lambda h:h.index)];on_run_end:t.List[str]=[on_run_hook.sql for on_run_hook in sorted(package.on_run_end.values(),key=lambda h:h.index)]
				if on_run_start or on_run_end:
					dependencies=Dependencies()
					for hook in[*package.on_run_start.values(),*package.on_run_end.values()]:dependencies=dependencies.union(hook.dependencies)
					statements_context=package_context.context_for_dependencies(dependencies);jinja_registry=make_jinja_registry(statements_context.jinja_macros,package_name,set(dependencies.macros));jinja_registry.add_globals(statements_context.jinja_globals);hooks_by_package_name[package_name]=EnvironmentStatements(before_all=[d.jinja_statement(stmt).sql(dialect=dialect)for stmt in on_run_start or[]],after_all=[d.jinja_statement(stmt).sql(dialect=dialect)for stmt in on_run_end or[]],python_env={},jinja_macros=jinja_registry,project=package_name,**product_details);project_names.add(package_name)
		statements_list=[statements for(_,statements)in sorted(hooks_by_package_name.items(),key=lambda item:0 if item[0]in project_names else 1)]
		if statements_list:return statements_list
		return[EnvironmentStatements(before_all=[],after_all=[],python_env={},jinja_macros=_A,project=self.config.project or _A,**product_details)]
	def _compute_yaml_max_mtime_per_subfolder(self,root:Path,visited:t.Optional[t.Set[Path]]=_A)->t.Dict[Path,float]:
		root=root.resolve();visited=visited or set()
		if not root.is_dir()or root in visited:return{}
		visited.add(root);result={};max_mtime:t.Optional[float]=_A
		for nested in root.iterdir():
			try:
				if nested.is_dir():result.update(self._compute_yaml_max_mtime_per_subfolder(nested,visited=visited))
				elif nested.suffix.lower()in('.yaml','.yml'):
					yaml_mtime=self._path_mtimes.get(nested)
					if yaml_mtime:max_mtime=max(max_mtime,yaml_mtime)if max_mtime is not _A else yaml_mtime
			except PermissionError:pass
		if max_mtime is not _A:result[root]=max_mtime
		return result
	class _Cache(CacheBase):
		MAX_ENTRY_NAME_LENGTH=200
		def __init__(self,loader:DbtLoader,project:Project,macros_max_mtime:t.Optional[float],yaml_max_mtimes:t.Dict[Path,float]):self._loader=loader;self._project=project;self._macros_max_mtime=macros_max_mtime;self._yaml_max_mtimes=yaml_max_mtimes;target=t.cast(TargetConfig,project.context.target);cache_dir=loader.context.cache_dir/target.name;self._model_cache=ModelCache(cache_dir)
		def get_or_load_models(self,target_path:Path,loader:t.Callable[[],t.List[Model]])->t.List[Model]:
			models=self._model_cache.get_or_load(self._cache_entry_name(target_path),self._cache_entry_id(target_path),loader=loader)
			for model in models:model._path=target_path
			return models
		def put(self,models:t.List[Model],path:Path)->bool:return self._model_cache.put(models,self._cache_entry_name(path),self._cache_entry_id(path))
		def get(self,path:Path)->t.List[Model]:return self._model_cache.get(self._cache_entry_name(path),self._cache_entry_id(path))
		def _cache_entry_name(self,target_path:Path)->str:
			try:path_for_name=target_path.absolute().relative_to(self._project.context.project_root.absolute())
			except ValueError:path_for_name=target_path
			name='__'.join(path_for_name.parts).replace(path_for_name.suffix,'')
			if len(name)>self.MAX_ENTRY_NAME_LENGTH:return name[len(name)-self.MAX_ENTRY_NAME_LENGTH:]
			return name
		def _cache_entry_id(self,target_path:Path)->str:max_mtime=self._max_mtime_for_path(target_path);return'__'.join([str(int(max_mtime))if max_mtime is not _A else'na',self._loader.config.fingerprint])
		def _max_mtime_for_path(self,target_path:Path)->t.Optional[float]:
			project_root=self._project.context.project_root
			try:target_path.absolute().relative_to(project_root.absolute())
			except ValueError:return
			mtimes=[self._loader._path_mtimes.get(target_path),self._loader._path_mtimes.get(self._project.profile.path),self._macros_max_mtime];cursor=target_path
			while cursor!=project_root:cursor=cursor.parent;mtimes.append(self._yaml_max_mtimes.get(cursor))
			non_null_mtimes=[t for t in mtimes if t is not _A];return max(non_null_mtimes)if non_null_mtimes else _A