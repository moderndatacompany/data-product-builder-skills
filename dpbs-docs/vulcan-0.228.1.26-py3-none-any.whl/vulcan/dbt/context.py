from __future__ import annotations
_A=None
import logging,typing as t
from dataclasses import dataclass,field,replace
from pathlib import Path
from dbt.adapters.base import BaseRelation
from vulcan.core.config import Config as VulcanConfig
from vulcan.dbt.builtin import _relation_info_to_relation
from vulcan.dbt.common import Dependencies
from vulcan.dbt.manifest import ManifestHelper
from vulcan.dbt.target import TargetConfig
from vulcan.utils import AttributeDict
from vulcan.utils.errors import ConfigError,VulcanError,MissingModelError,MissingSourceError
from vulcan.utils.jinja import JinjaGlobalAttribute,JinjaMacroRegistry,MacroInfo,MacroReference
if t.TYPE_CHECKING:from jinja2 import Environment;from vulcan.dbt.model import ModelConfig;from vulcan.dbt.relation import Policy;from vulcan.dbt.seed import SeedConfig;from vulcan.dbt.source import SourceConfig
logger=logging.getLogger(__name__)
@dataclass
class DbtContext:
	project_root:Path=Path();profiles_dir:t.Optional[Path]=_A;target_name:t.Optional[str]=_A;profile_name:t.Optional[str]=_A;project_schema:t.Optional[str]=_A;jinja_macros:JinjaMacroRegistry=field(default_factory=lambda:JinjaMacroRegistry(create_builtins_module=SQLMESH_DBT_PACKAGE,top_level_packages=['dbt']));vulcan_config:VulcanConfig=field(default_factory=VulcanConfig);_project_name:t.Optional[str]=_A;_variables:t.Dict[str,t.Any]=field(default_factory=dict);_models:t.Dict[str,ModelConfig]=field(default_factory=dict);_model_fqns:t.Set[str]=field(default_factory=set);_seeds:t.Dict[str,SeedConfig]=field(default_factory=dict);_sources:t.Dict[str,SourceConfig]=field(default_factory=dict);_refs:t.Dict[str,t.Union[ModelConfig,SeedConfig]]=field(default_factory=dict);_target:t.Optional[TargetConfig]=_A;_jinja_environment:t.Optional[Environment]=_A;_manifest:t.Optional[ManifestHelper]=_A
	@property
	def default_dialect(self)->str:
		if self.vulcan_config.dialect:return self.vulcan_config.dialect
		if not self.target:raise VulcanError('Target must be configured before calling the default_dialect property.')
		return self.target.dialect
	@property
	def project_name(self)->t.Optional[str]:return self._project_name
	@project_name.setter
	def project_name(self,project_name:str)->_A:self._project_name=project_name;self.jinja_macros.root_package_name=project_name
	@property
	def manifest(self)->ManifestHelper:
		if self._manifest is _A:raise VulcanError('Manifest is not set in the context.')
		return self._manifest
	@manifest.setter
	def manifest(self,mainfest:ManifestHelper)->_A:self._manifest=mainfest
	@property
	def variables(self)->t.Dict[str,t.Any]:return self._variables
	@variables.setter
	def variables(self,variables:t.Dict[str,t.Any])->_A:self._variables={};self.add_variables(variables)
	def add_variables(self,variables:t.Dict[str,t.Any])->_A:self._variables.update(variables);self._jinja_environment=_A
	def set_and_render_variables(self,variables:t.Dict[str,t.Any],package:str)->_A:
		package_macros=self.jinja_macros.copy(update={'top_level_packages':[*self.jinja_macros.top_level_packages,package]});jinja_environment=package_macros.build_environment(**self.jinja_globals)
		def _render_var(value:t.Any)->t.Any:
			if isinstance(value,str):return jinja_environment.from_string(value).render()
			if isinstance(value,list):return[_render_var(v)for v in value]
			if isinstance(value,dict):return{k:_render_var(v)for(k,v)in value.items()}
			return value
		def _var(name:str,default:t.Optional[t.Any]=_A)->t.Any:return _render_var(variables.get(name,default))
		jinja_environment.globals['var']=_var;rendered_variables={}
		for(k,v)in variables.items():
			try:rendered_variables[k]=_render_var(v)
			except Exception as ex:logger.warning(f"Failed to render variable '{k}', value '{v}': {ex}")
		self.variables=rendered_variables
	def add_macros(self,macros:t.Dict[str,MacroInfo],package:str)->_A:self.jinja_macros.add_macros(macros,package=package);self._jinja_environment=_A
	@property
	def models(self)->t.Dict[str,ModelConfig]:return self._models
	@models.setter
	def models(self,models:t.Dict[str,ModelConfig])->_A:self._models={};self._refs={};self._model_fqns=set();self.add_models(models)
	def add_models(self,models:t.Dict[str,ModelConfig])->_A:self._refs={};self._models.update(models);self._jinja_environment=_A
	@property
	def model_fqns(self)->t.Set[str]:
		if not self._model_fqns:self._model_fqns={model.fqn for model in self._models.values()}
		return self._model_fqns
	@property
	def seeds(self)->t.Dict[str,SeedConfig]:return self._seeds
	@seeds.setter
	def seeds(self,seeds:t.Dict[str,SeedConfig])->_A:self._seeds={};self._refs={};self.add_seeds(seeds)
	def add_seeds(self,seeds:t.Dict[str,SeedConfig])->_A:self._refs={};self._seeds.update(seeds);self._jinja_environment=_A
	@property
	def sources(self)->t.Dict[str,SourceConfig]:return self._sources
	@sources.setter
	def sources(self,sources:t.Dict[str,SourceConfig])->_A:self._sources={};self.add_sources(sources)
	def add_sources(self,sources:t.Dict[str,SourceConfig])->_A:self._sources.update(sources);self._jinja_environment=_A
	@property
	def refs(self)->t.Dict[str,t.Union[ModelConfig,SeedConfig]]:
		from vulcan.dbt.model import ModelConfig;from vulcan.dbt.seed import SeedConfig
		if not self._refs:
			for model in t.cast(t.Dict[str,t.Union[ModelConfig,SeedConfig]],{**self._seeds,**self._models}).values():
				name=model.name;config_name=model.config_name
				if model.version==model.latest_version:self._refs[name]=model;self._refs[config_name]=model
				if model.version:self._refs[f"{name}_v{model.version}"]=model;self._refs[f"{config_name}_v{model.version}"]=model
		return self._refs
	@property
	def target(self)->TargetConfig:
		if not self._target:raise VulcanError('Target has not been set in the context.')
		return self._target
	@target.setter
	def target(self,value:TargetConfig)->_A:
		if not self.project_name:raise ConfigError('Project name must be set in the context in order to use a target.')
		self._target=value;self._jinja_environment=_A
	def render(self,source:str,**kwargs:t.Any)->str:return self.jinja_environment.from_string(source).render(**kwargs)
	def get_callable_macro(self,name:str,package:t.Optional[str]=_A)->t.Optional[t.Callable]:return self.jinja_macros.build_macro(MacroReference(name=name,package=package),**self.jinja_globals)
	def copy(self)->DbtContext:return replace(self)
	@property
	def jinja_environment(self)->Environment:
		if self._jinja_environment is _A:self._jinja_environment=self.jinja_macros.build_environment(**self.jinja_globals)
		return self._jinja_environment
	@property
	def jinja_globals(self)->t.Dict[str,JinjaGlobalAttribute]:
		output:t.Dict[str,JinjaGlobalAttribute]={'vars':AttributeDict(self.variables),'refs':AttributeDict({k:v.relation_info for(k,v)in self.refs.items()}),'sources':AttributeDict({k:v.relation_info for(k,v)in self.sources.items()})}
		if self.project_name is not _A:output['project_name']=self.project_name
		if self._target is not _A:output['target']=self._target.attribute_dict()
		if self.vulcan_config.dialect:output['dialect']=self.vulcan_config.dialect
		if self._manifest is not _A:output['flat_graph']=AttributeDict(self.manifest.flat_graph)
		return output
	def context_for_dependencies(self,dependencies:Dependencies)->DbtContext:
		from vulcan.dbt.model import ModelConfig;from vulcan.dbt.seed import SeedConfig;dependency_context=self.copy();models={};seeds={};sources={}
		for ref in dependencies.refs:
			model=self.refs.get(ref)
			if model:
				if isinstance(model,SeedConfig):seeds[ref]=t.cast(SeedConfig,model)
				else:models[ref]=t.cast(ModelConfig,model)
			else:raise MissingModelError(ref)
		for source in dependencies.sources:
			if source in self.sources:sources[source]=self.sources[source]
			else:raise MissingSourceError(source)
		variables={k:v for(k,v)in self.variables.items()if k in dependencies.variables};dependency_context.sources=sources;dependency_context.seeds=seeds;dependency_context.models=models;dependency_context.variables=variables;dependency_context._refs={**dependency_context._seeds,**dependency_context._models};return dependency_context
	def create_relation(self,relation_info:AttributeDict[str,t.Any],quote_policy:t.Optional[Policy]=_A)->BaseRelation:
		if not self.target:raise VulcanError('Target must be configured before calling create_relation.')
		return _relation_info_to_relation(relation_info,self.target.relation_class,quote_policy or self.target.quote_policy)
SQLMESH_DBT_PACKAGE='vulcan.dbt'