from __future__ import annotations
_H='raw_code'
_G='persist_docs'
_F='docs'
_E='macros'
_D=True
_C=False
_B='before'
_A=None
import re,typing as t
from dataclasses import dataclass
from pathlib import Path
from ruamel.yaml.constructor import DuplicateKeyError
from sqlglot.helper import ensure_list
from vulcan.dbt.util import DBT_VERSION
from vulcan.core.config.base import BaseConfig,UpdateStrategy
from vulcan.core.config.common import DBT_PROJECT_FILENAME
from vulcan.utils import AttributeDict
from vulcan.utils.conversions import ensure_bool,try_str_to_bool
from vulcan.utils.errors import ConfigError
from vulcan.utils.jinja import MacroReference
from vulcan.utils.pydantic import PydanticModel,field_validator
from vulcan.utils.yaml import load
T=t.TypeVar('T',bound='GeneralConfig')
PROJECT_FILENAME=DBT_PROJECT_FILENAME
RAW_CODE_KEY=_H if DBT_VERSION>=(1,3,0)else'raw_sql'
JINJA_ONLY={'adapter','api','exceptions','flags','load_result','modules','run_query','statement','store_result','target'}
def load_yaml(source:str|Path)->t.Dict:
	try:return load(source,render_jinja=_C,allow_duplicate_keys=_D,keep_last_duplicate_key=_D)
	except DuplicateKeyError as ex:raise ConfigError(f"{source}: {ex}"if isinstance(source,Path)else f"{ex}")
def parse_meta(v:t.Optional[t.Dict[str,t.Any]])->t.Dict[str,t.Any]:
	if v is _A:return{}
	for(key,value)in v.items():
		if isinstance(value,str):v[key]=try_str_to_bool(value)
	return v
class SqlStr(str):0
sql_str_validator=field_validator('sql',mode=_B,check_fields=_C)(lambda v:SqlStr(v)if isinstance(v,str)else v)
class DbtConfig(BaseConfig,extra='allow',validate_assignment=_D,frozen=_C):0
class GeneralConfig(DbtConfig):
	start:t.Optional[str]=_A;description:t.Optional[str]=_A;enabled:bool=_D;docs:t.Dict[str,t.Any]={'show':_D};persist_docs:t.Dict[str,t.Any]={};tags:t.List[str]=[];meta:t.Dict[str,t.Any]={}
	@field_validator('enabled',mode=_B)
	@classmethod
	def _validate_bool(cls,v:str)->bool:return ensure_bool(v)
	@field_validator(_F,mode=_B)
	@classmethod
	def _validate_dict(cls,v:t.Dict[str,t.Any])->t.Dict[str,t.Any]:
		for(key,value)in v.items():
			if isinstance(value,str):v[key]=try_str_to_bool(value)
		return v
	@field_validator(_G,mode=_B)
	@classmethod
	def _validate_persist_docs(cls,v:t.Dict[str,str])->t.Dict[str,bool]:return{key:bool(value)for(key,value)in v.items()}
	@field_validator('tags',mode=_B)
	@classmethod
	def _validate_list(cls,v:t.Union[str,t.List[str]])->t.List[str]:return ensure_list(v)
	@field_validator('meta',mode=_B)
	@classmethod
	def _validate_meta(cls,v:t.Optional[t.Dict[str,t.Union[str,t.Any]]])->t.Dict[str,t.Any]:return parse_meta(v)
	_FIELD_UPDATE_STRATEGY:t.ClassVar[t.Dict[str,UpdateStrategy]]={**BaseConfig._FIELD_UPDATE_STRATEGY,**{'tests':UpdateStrategy.KEY_UPDATE,_F:UpdateStrategy.KEY_UPDATE,_G:UpdateStrategy.KEY_UPDATE,'tags':UpdateStrategy.EXTEND,'meta':UpdateStrategy.KEY_UPDATE}};_SQL_FIELDS:t.ClassVar[t.List[str]]=[]
	@property
	def config_attribute_dict(self)->AttributeDict[str,t.Any]:return AttributeDict(self.dict(exclude=EXCLUDED_CONFIG_ATTRIBUTE_KEYS))
	def _get_field_value(self,field:str)->t.Optional[t.Any]:field_val=getattr(self,field,_A);return field_val if field_val is not _A else self.meta.get(field,_A)
	def replace(self,other:T)->_A:
		for field in other.fields_set:setattr(self,field,getattr(other,field))
	@property
	def vulcan_config_kwargs(self)->t.Dict[str,t.Any]:
		kwargs={}
		for field in self.vulcan_config_fields:
			field_val=self._get_field_value(field)
			if field_val is not _A:kwargs[field]=field_val
		return kwargs
	@property
	def vulcan_config_fields(self)->t.Set[str]:return set()
@dataclass
class ModelAttrs:attrs:t.Set[str];all_attrs:bool=_C
class Dependencies(PydanticModel):
	macros:t.List[MacroReference]=[];sources:t.Set[str]=set();refs:t.Set[str]=set();variables:t.Set[str]=set();model_attrs:ModelAttrs=ModelAttrs(attrs=set());has_dynamic_var_names:bool=_C
	def union(self,other:Dependencies)->Dependencies:return Dependencies(macros=list(set(self.macros)|set(other.macros)),sources=self.sources|other.sources,refs=self.refs|other.refs,variables=self.variables|other.variables,model_attrs=ModelAttrs(attrs=self.model_attrs.attrs|other.model_attrs.attrs,all_attrs=self.model_attrs.all_attrs or other.model_attrs.all_attrs),has_dynamic_var_names=self.has_dynamic_var_names or other.has_dynamic_var_names)
	@field_validator(_E,mode='after')
	@classmethod
	def _sort_macros(cls,v:t.List[MacroReference])->t.List[MacroReference]:return sorted(v,key=lambda x:(x.package or'',x.name))
	def dict(self,*args:t.Any,**kwargs:t.Any)->t.Dict[str,t.Any]:
		exclude=kwargs.pop('exclude',_A)or set();out=super().dict(*args,**kwargs,exclude={*exclude,_E})
		if _E not in exclude:out[_E]=[macro.dict()for macro in self.macros]
		return out
def extract_jinja_config(input:str)->t.Tuple[str,str]:
	def jinja_end(sql:str,start:int)->int:
		cursor=start;quote=_A
		while cursor<len(sql):
			if sql[cursor]in('"',"'"):
				if quote is _A:quote=sql[cursor]
				elif quote==sql[cursor]:quote=_A
			if sql[cursor:cursor+2]=='}}'and quote is _A:return cursor+2
			cursor+=1
		return cursor
	no_config=input;only_config='';matches=re.findall('{{\\s*config\\s*\\(',no_config)
	for match in matches:
		start=no_config.find(match)
		if start==-1:continue
		extracted=no_config[start:jinja_end(no_config,start)];only_config=SqlStr('\n'.join([only_config,extracted])if only_config else extracted);no_config=SqlStr(no_config.replace(extracted,'').strip())
	return no_config,only_config
EXCLUDED_CONFIG_ATTRIBUTE_KEYS={'config','config_call_dict','checksum','created_at','contract','depends_on','dependencies',_F,'metrics','original_file_path','packages','patch_path','path',_G,'post_hook','pre_hook',_H,'refs','resource_type','sources','sql','tests','unrendered_config'}