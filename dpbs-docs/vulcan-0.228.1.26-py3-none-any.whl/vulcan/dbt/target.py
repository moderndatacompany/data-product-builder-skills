from __future__ import annotations
_d='default'
_c='username'
_b='Either database or dbname must be set'
_a='merge'
_Z='delete+insert'
_Y='dataset'
_X='project'
_W='port'
_V='dbname'
_U='threads'
_T='append'
_S='clickhouse'
_R='sqlserver'
_Q='bigquery'
_P='snowflake'
_O='redshift'
_N='postgres'
_M='duckdb'
_L='databricks'
_K='host'
_J='user'
_I='athena'
_H='trino'
_G='password'
_F='before'
_E=True
_D='schema'
_C='database'
_B=False
_A=None
import abc,typing as t
from pathlib import Path
from dbt.adapters.base import BaseRelation,Column
from pydantic import Field,AliasChoices
from vulcan.core.console import get_console
from vulcan.core.config.connection import AthenaConnectionConfig,BigQueryConnectionConfig,BigQueryConnectionMethod,BigQueryPriority,ClickhouseConnectionConfig,ConnectionConfig,DatabricksConnectionConfig,DuckDBConnectionConfig,MSSQLConnectionConfig,PostgresConnectionConfig,RedshiftConnectionConfig,SnowflakeConnectionConfig,TrinoAuthenticationMethod,TrinoConnectionConfig
from vulcan.core.model import IncrementalByTimeRangeKind,IncrementalByUniqueKeyKind,IncrementalUnmanagedKind
from vulcan.core.schema_diff import NestedSupport
from vulcan.dbt.common import DbtConfig
from vulcan.dbt.relation import Policy
from vulcan.dbt.util import DBT_VERSION
from vulcan.utils import AttributeDict,classproperty
from vulcan.utils.errors import ConfigError
from vulcan.utils.pydantic import field_validator,model_validator
IncrementalKind=t.Union[t.Type[IncrementalByUniqueKeyKind],t.Type[IncrementalByTimeRangeKind],t.Type[IncrementalUnmanagedKind]]
SERIALIZABLE_FIELDS={'name','schema_','type',_U,_C,'warehouse',_J,'role','account',_V,_K,_W,_X,_Y}
SCHEMA_DIFFER_OVERRIDES={'schema_differ_overrides':{'treat_alter_data_type_as_destructive':_E,'nested_support':NestedSupport.IGNORE}}
def with_schema_differ_overrides(func:t.Callable[...,ConnectionConfig])->t.Callable[...,ConnectionConfig]:
	def wrapper(self:TargetConfig,**kwargs:t.Any)->ConnectionConfig:merged_kwargs={**SCHEMA_DIFFER_OVERRIDES,**kwargs};return func(self,**merged_kwargs)
	return wrapper
class TargetConfig(abc.ABC,DbtConfig):
	type:str='none';name:str;database:str;schema_:str=Field(alias=_D);threads:int=1;profile_name:t.Optional[str]=_A
	@classmethod
	def load(cls,data:t.Dict[str,t.Any])->TargetConfig:
		db_type=data['type']
		if db_type==_L:return DatabricksConfig(**data)
		if db_type==_M:return DuckDbConfig(**data)
		if db_type==_N:return PostgresConfig(**data)
		if db_type==_O:return RedshiftConfig(**data)
		if db_type==_P:return SnowflakeConfig(**data)
		if db_type==_Q:return BigQueryConfig(**data)
		if db_type==_R:return MSSQLConfig(**data)
		if db_type==_H:return TrinoConfig(**data)
		if db_type==_S:return ClickhouseConfig(**data)
		if db_type==_I:return AthenaConfig(**data)
		raise ConfigError(f"{db_type} not supported.")
	def default_incremental_strategy(self,kind:IncrementalKind)->str:raise NotImplementedError
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:raise NotImplementedError
	def attribute_dict(self)->AttributeDict:fields=self.dict(include=SERIALIZABLE_FIELDS).copy();fields['target_name']=self.name;return AttributeDict(fields)
	@classproperty
	def quote_policy(cls)->Policy:return Policy()
	@property
	def extra(self)->t.Set[str]:return self.extra_fields(set(self.dict()))
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:return BaseRelation
	@classproperty
	def column_class(cls)->t.Type[Column]:return Column
	@property
	def dialect(self)->str:return self.type
DUCKDB_IN_MEMORY=':memory:'
class DuckDbConfig(TargetConfig):
	type:t.Literal[_M]=_M;database:str='main';schema_:str=Field(default='main',alias=_D);path:str=DUCKDB_IN_MEMORY;extensions:t.Optional[t.List[str]]=_A;settings:t.Optional[t.Dict[str,t.Any]]=_A;secrets:t.Optional[t.List[t.Dict[str,t.Any]]]=_A;filesystems:t.Optional[t.List[t.Dict[str,t.Any]]]=_A
	@model_validator(mode=_F)
	def validate_authentication(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		if _C not in data and DBT_VERSION>=(1,5,0):path=data.get('path');data[_C]='memory'if path is _A or path==DUCKDB_IN_MEMORY else Path(t.cast(str,path)).stem
		if _U in data and t.cast(int,data[_U])>1:get_console().log_warning('DuckDB does not support concurrency - setting threads to 1.')
		return data
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return _Z
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:from dbt.adapters.duckdb.relation import DuckDBRelation;return DuckDBRelation
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:
		if self.extensions is not _A:kwargs['extensions']=self.extensions
		if self.settings is not _A:kwargs['connector_config']=self.settings
		if self.secrets is not _A:kwargs['secrets']=self.secrets
		if self.filesystems is not _A:kwargs['filesystems']=self.filesystems
		return DuckDBConnectionConfig(database=self.path,concurrent_tasks=1,**kwargs)
class SnowflakeConfig(TargetConfig):
	type:t.Literal[_P]=_P;account:str;user:str;password:t.Optional[str]=_A;authenticator:t.Optional[str]=_A;private_key:t.Optional[str]=_A;private_key_path:t.Optional[str]=_A;private_key_passphrase:t.Optional[str]=_A;token:t.Optional[str]=_A;warehouse:t.Optional[str]=_A;role:t.Optional[str]=_A;client_session_keep_alive:bool=_B;query_tag:t.Optional[str]=_A;connect_retries:int=0;connect_timeout:int=10;retry_on_database_errors:bool=_B;retry_all:bool=_B
	@model_validator(mode=_F)
	@classmethod
	def validate_authentication(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict)or(data.get(_G)or data.get('authenticator')or data.get('private_key')or data.get('private_key_path')):return data
		raise ConfigError('No supported Snowflake authentication method found in target profile.')
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return _a
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:from dbt.adapters.snowflake import SnowflakeRelation;return SnowflakeRelation
	@classproperty
	def column_class(cls)->t.Type[Column]:from dbt.adapters.snowflake import SnowflakeColumn;return SnowflakeColumn
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:return SnowflakeConnectionConfig(user=self.user,password=self.password,authenticator=self.authenticator,account=self.account,warehouse=self.warehouse,database=self.database,role=self.role,concurrent_tasks=self.threads,token=self.token,private_key=self.private_key,private_key_path=self.private_key_path,private_key_passphrase=self.private_key_passphrase,**kwargs)
	@classproperty
	def quote_policy(cls)->Policy:return Policy(database=_B,schema=_B,identifier=_B)
class PostgresConfig(TargetConfig):
	type:t.Literal[_N]=_N;host:str;user:str;password:str=Field(validation_alias=AliasChoices('pass',_G));port:int;dbname:str;keepalives_idle:t.Optional[int]=_A;connect_timeout:int=10;retries:int=1;search_path:t.Optional[str]=_A;role:t.Optional[str]=_A;sslmode:t.Optional[str]=_A
	@model_validator(mode=_F)
	@classmethod
	def validate_database(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		data[_C]=data.get(_C)or data.get(_V)
		if not data[_C]:raise ConfigError(_b)
		return data
	@field_validator(_W)
	@classmethod
	def _validate_port(cls,v:t.Union[int,str])->int:return int(v)
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return _Z if kind is IncrementalByUniqueKeyKind else _T
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:return PostgresConnectionConfig(host=self.host,user=self.user,password=self.password,port=self.port,database=self.dbname,keepalives_idle=self.keepalives_idle,concurrent_tasks=self.threads,connect_timeout=self.connect_timeout,role=self.role,sslmode=self.sslmode,**kwargs)
class RedshiftConfig(TargetConfig):
	type:t.Literal[_O]=_O;host:str;user:str;password:str=Field(validation_alias=AliasChoices('pass',_G));port:int;dbname:str;connect_timeout:t.Optional[int]=_A;ra3_node:bool=_E;search_path:t.Optional[str]=_A;sslmode:t.Optional[str]=_A
	@model_validator(mode=_F)
	@classmethod
	def validate_database(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		data[_C]=data.get(_C)or data.get(_V)
		if not data[_C]:raise ConfigError(_b)
		return data
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return _T
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:from dbt.adapters.redshift import RedshiftRelation;return RedshiftRelation
	@classproperty
	def column_class(cls)->t.Type[Column]:
		if DBT_VERSION<(1,6,0):from dbt.adapters.redshift import RedshiftColumn;return RedshiftColumn
		return super(RedshiftConfig,cls).column_class
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:return RedshiftConnectionConfig(user=self.user,password=self.password,database=self.database,host=self.host,port=self.port,sslmode=self.sslmode,timeout=self.connect_timeout,concurrent_tasks=self.threads,**kwargs)
class DatabricksConfig(TargetConfig):
	type:t.Literal[_L]=_L;host:str;http_path:str;token:t.Optional[str]=_A;database:t.Optional[str]=Field(alias='catalog');auth_type:t.Optional[str]=_A;client_id:t.Optional[str]=_A;client_secret:t.Optional[str]=_A
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return _a
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:from dbt.adapters.databricks.relation import DatabricksRelation;return DatabricksRelation
	@classproperty
	def column_class(cls)->t.Type[Column]:from dbt.adapters.databricks.column import DatabricksColumn;return DatabricksColumn
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:return DatabricksConnectionConfig(server_hostname=self.host,http_path=self.http_path,access_token=self.token,concurrent_tasks=self.threads,catalog=self.database,auth_type='databricks-oauth'if self.auth_type=='oauth'else self.auth_type,oauth_client_id=self.client_id,oauth_client_secret=self.client_secret,**kwargs)
class BigQueryConfig(TargetConfig):
	type:t.Literal[_Q]=_Q;method:t.Optional[str]=BigQueryConnectionMethod.OAUTH;dataset:t.Optional[str]=_A;project:t.Optional[str]=_A;execution_project:t.Optional[str]=_A;quota_project:t.Optional[str]=_A;location:t.Optional[str]=_A;keyfile:t.Optional[str]=_A;keyfile_json:t.Optional[t.Dict[str,t.Any]]=_A;token:t.Optional[str]=_A;refresh_token:t.Optional[str]=_A;client_id:t.Optional[str]=_A;client_secret:t.Optional[str]=_A;token_uri:t.Optional[str]=_A;scopes:t.Tuple[str,...]=('https://www.googleapis.com/auth/bigquery','https://www.googleapis.com/auth/cloud-platform','https://www.googleapis.com/auth/drive');impersonated_service_account:t.Optional[str]=_A;job_creation_timeout_seconds:t.Optional[int]=_A;job_execution_timeout_seconds:t.Optional[int]=_A;timeout_seconds:t.Optional[int]=_A;job_retries:t.Optional[int]=_A;retries:int=1;job_retry_deadline_seconds:t.Optional[int]=_A;priority:BigQueryPriority=BigQueryPriority.INTERACTIVE;maximum_bytes_billed:t.Optional[int]=_A
	@model_validator(mode=_F)
	@classmethod
	def validate_fields(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		schema=data.get(_D)or data.get(_Y)
		if not schema:raise ConfigError('Either schema or dataset must be set')
		data[_Y]=data[_D]=schema;database=data.get(_C)or data.get(_X)
		if not database:raise ConfigError('Either database or project must be set')
		data[_C]=data[_X]=database;return data
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return _a
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:from dbt.adapters.bigquery.relation import BigQueryRelation;return BigQueryRelation
	@classproperty
	def column_class(cls)->t.Type[Column]:from dbt.adapters.bigquery import BigQueryColumn;return BigQueryColumn
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:job_retries=self.job_retries if self.job_retries is not _A else self.retries;job_execution_timeout_seconds=self.job_execution_timeout_seconds if self.job_execution_timeout_seconds is not _A else self.timeout_seconds;return BigQueryConnectionConfig(method=self.method,project=self.database,execution_project=self.execution_project,quota_project=self.quota_project,location=self.location,concurrent_tasks=self.threads,keyfile=self.keyfile,keyfile_json=self.keyfile_json,token=self.token,refresh_token=self.refresh_token,client_id=self.client_id,client_secret=self.client_secret,token_uri=self.token_uri,scopes=self.scopes,impersonated_service_account=self.impersonated_service_account,job_creation_timeout_seconds=self.job_creation_timeout_seconds,job_execution_timeout_seconds=job_execution_timeout_seconds,job_retries=job_retries,job_retry_deadline_seconds=self.job_retry_deadline_seconds,priority=self.priority,maximum_bytes_billed=self.maximum_bytes_billed,**kwargs)
class MSSQLConfig(TargetConfig):
	type:t.Literal[_R]=_R;host:t.Optional[str]=_A;server:t.Optional[str]=_A;port:int=1433;database:str=Field(default='master');schema_:str=Field(default='dbo',alias=_D);user:t.Optional[str]=_A;username:t.Optional[str]=_A;UID:t.Optional[str]=_A;password:t.Optional[str]=_A;PWD:t.Optional[str]=_A;threads:int=4;login_timeout:t.Optional[int]=_A;query_timeout:t.Optional[int]=_A;authentication:t.Optional[str]='sql';schema_authorization:t.Optional[str]=_A;driver:t.Optional[str]=_A;encrypt:t.Optional[bool]=_A;trust_cert:t.Optional[bool]=_A;retries:t.Optional[int]=_A;windows_login:t.Optional[bool]=_A;tenant_id:t.Optional[str]=_A;client_id:t.Optional[str]=_A;client_secret:t.Optional[str]=_A
	@model_validator(mode=_F)
	@classmethod
	def validate_alias_fields(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		data[_K]=data.get(_K)or data.get('server')
		if not data[_K]:raise ConfigError('Either host or server must be set')
		data[_J]=data.get(_J)or data.get(_c)or data.get('UID')
		if not data[_J]:raise ConfigError('One of user, username, or UID must be set')
		data[_G]=data.get(_G)or data.get('PWD')
		if not data[_G]:raise ConfigError('Either password or PWD must be set')
		return data
	@field_validator('authentication')
	@classmethod
	def _validate_authentication(cls,v:str)->str:
		if v!='sql':raise ConfigError('Only SQL and Windows Authentication are supported for SQL Server')
		return v
	@field_validator(_W)
	@classmethod
	def _validate_port(cls,v:t.Union[int,str])->int:return int(v)
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return _Z if kind is IncrementalByUniqueKeyKind else _T
	@classproperty
	def column_class(cls)->t.Type[Column]:
		try:from dbt.adapters.sqlserver.sqlserver_column import SQLServerColumn
		except ImportError:from dbt.adapters.sqlserver.sql_server_column import SQLServerColumn
		return SQLServerColumn
	@property
	def dialect(self)->str:return'tsql'
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:return MSSQLConnectionConfig(host=self.host,user=self.user,password=self.password,port=self.port,database=self.database,timeout=self.query_timeout,login_timeout=self.login_timeout,concurrent_tasks=self.threads,**kwargs)
class TrinoConfig(TargetConfig):
	_method_to_auth_enum:t.ClassVar[t.Dict[str,TrinoAuthenticationMethod]]={'none':TrinoAuthenticationMethod.NO_AUTH,'ldap':TrinoAuthenticationMethod.LDAP,'kerberos':TrinoAuthenticationMethod.KERBEROS,'jwt':TrinoAuthenticationMethod.JWT,'certificate':TrinoAuthenticationMethod.CERTIFICATE,'oauth':TrinoAuthenticationMethod.OAUTH,'oauth_console':TrinoAuthenticationMethod.OAUTH};type:t.Literal[_H]=_H;host:str;database:str;schema_:str=Field(alias=_D);port:int=443;method:str;user:t.Optional[str]=_A;threads:int=1;roles:t.Optional[t.Dict[str,str]]=_A;session_properties:t.Optional[t.Dict[str,str]]=_A;retries:int=3;timezone:t.Optional[str]=_A;http_headers:t.Optional[t.Dict[str,str]]=_A;http_scheme:t.Optional[str]=_A;prepared_statements_enabled:bool=_E;password:t.Optional[str]=_A;impersonation_user:t.Optional[str]=_A;keytab:t.Optional[str]=_A;krb5_config:t.Optional[str]=_A;principal:t.Optional[str]=_A;service_name:str=_H;hostname_override:t.Optional[str]=_A;mutual_authentication:bool=_B;force_preemptive:bool=_B;sanitize_mutual_error_response:bool=_E;delegate:bool=_B;jwt_token:t.Optional[str]=_A;client_certificate:t.Optional[str]=_A;client_private_key:t.Optional[str]=_A;cert:t.Optional[str]=_A
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return _T
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:from dbt.adapters.trino.relation import TrinoRelation;return TrinoRelation
	@classproperty
	def column_class(cls)->t.Type[Column]:from dbt.adapters.trino.column import TrinoColumn;return TrinoColumn
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:return TrinoConnectionConfig(method=self._method_to_auth_enum[self.method],host=self.host,user=self.user,catalog=self.database,port=self.port,http_scheme=self.http_scheme,roles=self.roles,http_headers=self.http_headers,session_properties=self.session_properties,retries=self.retries,timezone=self.timezone,password=self.password,impersonation_user=self.impersonation_user,keytab=self.keytab,krb5_config=self.krb5_config,principal=self.principal,service_name=self.service_name,hostname_override=self.hostname_override,mutual_authentication=self.mutual_authentication,force_preemptive=self.force_preemptive,sanitize_mutual_error_response=self.sanitize_mutual_error_response,delegate=self.delegate,jwt_token=self.jwt_token,client_certificate=self.client_certificate,client_private_key=self.client_private_key,cert=self.cert,concurrent_tasks=self.threads,**kwargs)
class ClickhouseConfig(TargetConfig):
	host:str='localhost';user:str=Field(default=_d,alias=_c);password:str='';port:t.Optional[int]=_A;cluster:t.Optional[str]=_A;schema_:str=Field(default=_d,alias=_D);connect_timeout:int=10;send_receive_timeout:int=300;verify:bool=_E;compression:str='';custom_settings:t.Optional[t.Dict[str,t.Any]]=_A;driver:t.Optional[str]=_A;secure:bool=_B;retries:int=1;database_engine:t.Optional[str]=_A;cluster_mode:bool=_B;sync_request_timeout:int=5;compress_block_size:int=1048576;check_exchange:bool=_E;use_lw_deletes:bool=_B;allow_automatic_deduplication:bool=_B;tcp_keepalive:t.Union[bool,t.Tuple[int,...],t.List[int]]=_B;database:str='';local_suffix:str='local';local_db_prefix:str='';type:t.Literal[_S]=_S
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return'legacy'
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:from dbt.adapters.clickhouse.relation import ClickHouseRelation;return ClickHouseRelation
	@classproperty
	def column_class(cls)->t.Type[Column]:from dbt.adapters.clickhouse.column import ClickHouseColumn;return ClickHouseColumn
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:return ClickhouseConnectionConfig(host=self.host,username=self.user,password=self.password,port=self.port,cluster=self.cluster,connect_timeout=self.connect_timeout,send_receive_timeout=self.send_receive_timeout,verify=self.verify,compression_method=self.compression,connection_settings=self.custom_settings,**kwargs)
class AthenaConfig(TargetConfig):
	type:t.Literal[_I]=_I;threads:int=4;s3_staging_dir:t.Optional[str]=_A;s3_data_dir:t.Optional[str]=_A;s3_data_naming:t.Optional[str]=_A;s3_tmp_table_dir:t.Optional[str]=_A;poll_interval:t.Optional[int]=_A;debug_query_state:bool=_B;work_group:t.Optional[str]=_A;skip_workgroup_check:t.Optional[bool]=_A;spark_work_group:t.Optional[str]=_A;aws_access_key_id:t.Optional[str]=_A;aws_secret_access_key:t.Optional[str]=_A;aws_profile_name:t.Optional[str]=_A;region_name:t.Optional[str]=_A;num_retries:t.Optional[int]=_A;num_boto3_retries:t.Optional[int]=_A;num_iceberg_retries:t.Optional[int]=_A;seed_s3_upload_args:t.Dict[str,str]={};lf_tags_database:t.Dict[str,str]={}
	@classproperty
	def relation_class(cls)->t.Type[BaseRelation]:from dbt.adapters.athena.relation import AthenaRelation;return AthenaRelation
	@classproperty
	def column_class(cls)->t.Type[Column]:from dbt.adapters.athena.column import AthenaColumn;return AthenaColumn
	def default_incremental_strategy(self,kind:IncrementalKind)->str:return'insert_overwrite'
	@with_schema_differ_overrides
	def to_vulcan(self,**kwargs:t.Any)->ConnectionConfig:return AthenaConnectionConfig(type=_I,aws_access_key_id=self.aws_access_key_id,aws_secret_access_key=self.aws_secret_access_key,region_name=self.region_name,work_group=self.work_group,s3_staging_dir=self.s3_staging_dir,s3_warehouse_location=self.s3_data_dir,schema_name=self.schema_,catalog_name=self.database,concurrent_tasks=self.threads,**kwargs)
TARGET_TYPE_TO_CONFIG_CLASS:t.Dict[str,t.Type[TargetConfig]]={_L:DatabricksConfig,_M:DuckDbConfig,_N:PostgresConfig,_O:RedshiftConfig,_P:SnowflakeConfig,_Q:BigQueryConfig,_R:MSSQLConfig,'tsql':MSSQLConfig,_H:TrinoConfig,_I:AthenaConfig,_S:ClickhouseConfig}