from __future__ import annotations

import typing as t

from pydantic import Field, field_validator, model_validator

from schema import _PydanticModel
from schema.filters.operators import (
    FilterOperator,
    FilterValue,
    validate_operator_values,
    validate_qualified_member,
)


class RestUnaryFilter(_PydanticModel):
    member: str = Field(min_length=1)
    operator: FilterOperator
    values: list[FilterValue] | None = None

    @model_validator(mode="after")
    def _validate_shape(self) -> RestUnaryFilter:
        validate_operator_values(operator=self.operator, values=self.values)
        return self

    @field_validator("member")
    @classmethod
    def _validate_qualified(cls, value: str) -> str:
        return validate_qualified_member(value)


class RestLogicalFilter(_PydanticModel):
    and_: list["RestFilterExpression"] | None = Field(default=None, alias="and")
    or_: list["RestFilterExpression"] | None = Field(default=None, alias="or")

    @model_validator(mode="after")
    def _validate_group(self) -> RestLogicalFilter:
        if bool(self.and_) == bool(self.or_):
            raise ValueError("logical filter requires exactly one of 'and' or 'or'")
        children = self.and_ or self.or_ or []
        if not children:
            raise ValueError("'and'/'or' must contain at least one filter")
        return self


RestFilterExpression = t.Union[RestUnaryFilter, RestLogicalFilter]
