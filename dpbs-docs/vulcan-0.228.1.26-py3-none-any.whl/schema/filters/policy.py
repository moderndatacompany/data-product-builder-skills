from __future__ import annotations

import typing as t

from pydantic import Field, field_validator, model_validator
from typing_extensions import Literal

from schema import _PydanticModel
from schema.filters.operators import (
    POLICY_FILTER_OPERATORS,
    FilterOperator,
    FilterValue,
    validate_operator_values,
    validate_policy_field,
    validate_policy_group,
)


class PolicyUnaryFilter(_PydanticModel):
    member: str = Field(min_length=1)
    operator: FilterOperator
    values: list[FilterValue] | None = None

    @field_validator("operator")
    @classmethod
    def _reject_measure_filter(cls, value: FilterOperator) -> FilterOperator:
        if value not in POLICY_FILTER_OPERATORS:
            raise ValueError(
                f"operator '{value.value}' is not allowed in policy filters "
                "(row-level only; measureFilter is forbidden)"
            )
        return value

    @field_validator("member")
    @classmethod
    def _validate_short_field(cls, value: str) -> str:
        return validate_policy_field(value)

    @model_validator(mode="after")
    def _validate_shape(self) -> PolicyUnaryFilter:
        validate_operator_values(operator=self.operator, values=self.values)
        return self

    @property
    def field_name(self) -> str:
        return self.member


class PolicyLogicalFilter(_PydanticModel):
    and_: list["PolicyFilterExpression"] | None = Field(default=None, alias="and")
    or_: list["PolicyFilterExpression"] | None = Field(default=None, alias="or")

    @model_validator(mode="after")
    def _validate_group(self) -> PolicyLogicalFilter:
        if bool(self.and_) == bool(self.or_):
            raise ValueError("logical filter requires exactly one of 'and' or 'or'")
        children = self.and_ or self.or_ or []
        if not children:
            raise ValueError("'and'/'or' must contain at least one filter")
        return self


PolicyFilterExpression = t.Union[PolicyUnaryFilter, PolicyLogicalFilter]

PolicyMask = list[str] | Literal["*"]


class PolicyEntry(_PydanticModel):
    group: str
    filter: list[PolicyFilterExpression] | None = None
    mask: PolicyMask | None = None

    @field_validator("group")
    @classmethod
    def _validate_group_field(cls, value: str) -> str:
        return validate_policy_group(value)

    @field_validator("mask", mode="before")
    @classmethod
    def _reject_list_wildcard_mask(cls, value: t.Any) -> t.Any:
        if value == ["*"]:
            raise ValueError("mask must be scalar '*' not ['*']")
        return value
