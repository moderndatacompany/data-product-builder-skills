from __future__ import annotations

import typing as t

from pydantic import Field
from typing_extensions import Literal

from schema._base import PydanticModel as _PydanticModel
from schema.filters import PolicyFilterExpression
from schema.types import (
    JoinRelationshipValue,
    LogicalTypeValue,
    MeasureTypeValue,
    RollingWindowSpec,
    TimeGranularitySpec,
)


class CubeSqlMask(_PydanticModel):
    sql: str


CubeMaskScalar = t.Union[str, int, float, bool]
CubeMaskValue = t.Union[CubeMaskScalar, CubeSqlMask]

CubeAccessPolicyFilterExpression = PolicyFilterExpression


class CubeRowLevelFilters(_PydanticModel):
    filters: t.List[CubeAccessPolicyFilterExpression]


class CubeRowLevelAllowAll(_PydanticModel):
    allow_all: Literal[True]


CubeRowLevel = t.Union[CubeRowLevelFilters, CubeRowLevelAllowAll]


class CubeMemberLevelIncludesAll(_PydanticModel):
    includes: Literal["*"]


class CubeMemberLevelIncludesNone(_PydanticModel):
    includes: t.List[str] = Field(default_factory=list)


class CubeMemberLevelExcludes(_PydanticModel):
    excludes: t.List[str]


CubeMemberLevel = t.Union[
    CubeMemberLevelIncludesAll,
    CubeMemberLevelIncludesNone,
    CubeMemberLevelExcludes,
]


class CubeMemberMaskingIncludesAll(_PydanticModel):
    includes: Literal["*"]


class CubeMemberMaskingIncludes(_PydanticModel):
    includes: t.List[str]


CubeMemberMasking = t.Union[CubeMemberMaskingIncludesAll, CubeMemberMaskingIncludes]


class CubeAccessPolicyEntry(_PydanticModel):
    group: str
    row_level: CubeRowLevel
    member_level: CubeMemberLevel
    member_masking: CubeMemberMasking | None = None


class CubeMeasure(_PydanticModel):
    name: str
    type: MeasureTypeValue
    sql: t.Optional[str] = None
    filters: t.List[dict] = []
    rolling_window: t.Optional[RollingWindowSpec] = None
    public: bool = True
    mask: t.Optional[CubeMaskValue] = None


class CubeDimension(_PydanticModel):
    name: str
    sql: str
    type: LogicalTypeValue
    primary_key: bool = False
    public: bool = True
    format: t.Optional[str] = None
    granularities: t.Optional[t.List[TimeGranularitySpec]] = None
    mask: t.Optional[CubeMaskValue] = None


class CubeSegment(_PydanticModel):
    name: str
    sql: str
    public: bool = True


class CubeJoin(_PydanticModel):
    name: str
    relationship: JoinRelationshipValue
    sql: str


class Cube(_PydanticModel):
    name: str
    sql_table: str
    measures: t.List[CubeMeasure] = []
    dimensions: t.List[CubeDimension] = []
    segments: t.List[CubeSegment] = []
    joins: t.List[CubeJoin] = []
    access_policy: t.Optional[t.List[CubeAccessPolicyEntry]] = None


class Include(_PydanticModel):
    name: str
    alias: str


class CubeRef(_PydanticModel):
    join_path: str
    includes: t.List[t.Union[str, Include]]


class View(_PydanticModel):
    name: str
    cubes: t.List[CubeRef] = []
    access_policy: t.Optional[t.List[CubeAccessPolicyEntry]] = None


class CubeSchema(_PydanticModel):
    cubes: t.List[Cube] = []
    views: t.List[View] = []
