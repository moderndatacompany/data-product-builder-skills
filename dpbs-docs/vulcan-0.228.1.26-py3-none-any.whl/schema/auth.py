from __future__ import annotations

import re
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping

SecurityContextValue = str | int | bool

EXTRA_KEY_MAX_LENGTH = 32
EXTRA_KEY_PATTERN = re.compile(rf"^[a-z][a-z0-9_]{{0,{EXTRA_KEY_MAX_LENGTH - 1}}}$")

@dataclass(frozen=True)
class AuthExtensionContext:
    user_id: str
    user_tags: tuple[str, ...]
    request_headers: dict[str, str]

def _validate_extra(extra: Mapping[str, Any]) -> dict[str, SecurityContextValue]:
    validated: dict[str, SecurityContextValue] = {}
    for key, value in extra.items():
        if key == "group":
            raise ValueError("pass 'group' as a positional argument, not a keyword extra")
        if not EXTRA_KEY_PATTERN.fullmatch(key):
            raise ValueError(
                f"SecurityContext extra key {key!r} must be lowercase, start with a letter, "
                f"contain only letters, digits, or '_', and be at most {EXTRA_KEY_MAX_LENGTH} characters"
            )
        if not isinstance(value, (str, int, bool)):
            raise TypeError(
                f"SecurityContext field {key!r} must be str, int, or bool, got {type(value).__name__}"
            )
        validated[key] = value
    return validated


@dataclass(frozen=True)
class SecurityContext:
    group: str = field(default="")
    extra: Mapping[str, SecurityContextValue] = field(default_factory=dict)

    def __init__(self, group: str = "", **extra: SecurityContextValue) -> None:
        object.__setattr__(self, "group", group)
        object.__setattr__(self, "extra", MappingProxyType(_validate_extra(extra)))

    def to_dict(self) -> dict[str, SecurityContextValue]:
        return {"group": self.group, **dict(self.extra)}

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> SecurityContext:
        payload = dict(data)
        group = str(payload.pop("group", ""))
        return cls(group=group, **payload)

    @classmethod
    def from_pairs(cls, pairs: tuple[str, ...] | list[str]) -> SecurityContext:
        """
        Build a security context from ``key=value`` pairs.

        Values are stripped of surrounding whitespace. ``true``/``false`` (any
        case) become bool; integer strings become int; otherwise str.
        Key and value rules are enforced by ``from_dict``.
        """
        payload: dict[str, SecurityContextValue] = {}
        for pair in pairs:
            if "=" not in pair:
                raise ValueError(f"Invalid security context pair {pair!r}; expected key=value")
            key, _, raw_value = pair.partition("=")
            key = key.strip()
            if not key:
                raise ValueError(f"Invalid security context pair {pair!r}; key must not be empty")
            value_str = raw_value.strip()
            if value_str.lower() == "true":
                value = True  # bool literal
            elif value_str.lower() == "false":
                value = False  # bool literal
            elif value_str.isdigit() or (value_str.startswith("-") and value_str[1:].isdigit()):
                value = int(value_str)  # integer literal
            else:
                value = value_str  # everything else stays str
            payload[key] = value
        return cls.from_dict(payload)

    def to_headers(self) -> dict[str, str]:
        headers = {"X-User-Group": self.group}
        for key, value in self.extra.items():
            header_value = "true" if value is True else "false" if value is False else str(value)
            headers[f"X-User-{key}"] = header_value
        return headers
