"""
Shared wire vocabulary for ``schema.cube`` and ``schema.metadata``.

Depends only on pydantic and the stdlib so this package can be vendored into
minimal consumers (e.g. the transpiler container).
"""

from __future__ import annotations

import re
import typing as t
from enum import Enum

import pydantic
from pydantic import ConfigDict, Field, computed_field, field_validator, model_serializer, model_validator
from typing_extensions import Literal


_WIRE_CONFIG = ConfigDict(extra="forbid", protected_namespaces=())


LogicalTypeValue = Literal[
    "number", 
    "string", 
    "time", 
    "boolean"
]
JoinRelationshipValue = Literal[
    "one_to_one", 
    "one_to_many", 
    "many_to_one"
]
MeasureTypeValue = Literal[
    "count",
    "count_distinct",
    "count_distinct_approx",
    "sum",
    "avg",
    "min",
    "max",
    "number",
    "string",
    "time",
    "boolean",
]
MetricGranularityValue = Literal[
    "second",
    "minute",
    "hour",
    "day",
    "week",
    "month",
    "quarter",
    "year",
]
SemanticMeasureTypeValue = Literal[
    "simple",  # additive aggregation; safe across any dimension
    "flow",  # in-period total; additive across time
    "stock",  # point-in-time level; do not sum across time
    "ratio",  # numerator ÷ denominator at query grain
    "derived",  # composed from other measures
]
DimensionSemanticTypeValue = Literal[
    "categorical",  # slice/group dimension (plan, tier, channel)
    "identifier",  # primary key or filter-only ID
    "bucketing",  # numeric range buckets
    "ordinal",  # ordered categories (rank, tier level)
]
PeriodTreatmentValue = Literal[
    "last",  # snapshot at period end (ARR, headcount)
    "avg",  # average over the period (inventory, headcount)
    "first",  # snapshot at period start (opening balance)
]

# 1–64 chars: starts with letter or _; rest letters, digits, or _
VALID_NAME_PATTERN = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$")


class NamingError(ValueError):
    pass


def _validate_name(value: str, *, context: str = "name") -> str:
    if not value:
        raise NamingError(f"{context} must not be empty")
    if not VALID_NAME_PATTERN.match(value):
        raise NamingError(f"{context} must match {VALID_NAME_PATTERN.pattern}, got {value!r}")
    return value


AiContextExampleFormat = Literal["sql", "graphql", "rest"]


class AiContextExampleSpec(pydantic.BaseModel):
    model_config = _WIRE_CONFIG

    description: str
    format: AiContextExampleFormat = "sql"
    query: str

    @field_validator("description", "query")
    @classmethod
    def _strip_non_empty(cls, v: str) -> str:
        stripped = v.strip()
        if not stripped:
            raise ValueError("must not be empty")
        return stripped


class AiContextSpec(pydantic.BaseModel):
    model_config = _WIRE_CONFIG

    instructions: t.Optional[t.Union[str, t.List[str]]] = None
    synonyms: t.List[str] = Field(default_factory=list)
    caveats: t.List[str] = Field(default_factory=list)
    examples: t.List[AiContextExampleSpec] = Field(default_factory=list)


class MeasureBehaviorSpec(pydantic.BaseModel):
    """
    Measure ``behavior`` for YAML authoring and metadata export.

    ``type`` selects which optional fields apply. ``is_additive`` is derived: True for
    types safe to aggregate across any dimension with standard SQL; False otherwise.

    Types:
        simple: Standard additive measure (counts, sums). Safe to group and aggregate freely.
        flow: Events or amounts that occurred in the period (signups, orders). Additive like
            simple; marks inflow/event semantics rather than point-in-time levels.
        stock: Point-in-time snapshot (MRR, active customers, headcount). Do not sum across
            time; pin ``time_dimension`` to a boundary using ``period_treatment`` and
            ``period_grain``.
        ratio: Numerator divided by denominator. Query parts separately at the target grain,
            then divide; do not average pre-computed ratios. ``measure_refs`` is set automatically
            to ``[numerator, denominator]`` (any authored ``measure_refs`` are ignored).
        derived: Composed from other measures listed in ``measure_refs``; each ref resolves per
            its own type before composition.
    """

    model_config = _WIRE_CONFIG

    type: SemanticMeasureTypeValue
    time_dimension: str = ""
    period_treatment: t.Optional[PeriodTreatmentValue] = None
    period_grain: t.Optional[MetricGranularityValue] = None
    numerator: str = ""
    denominator: str = ""
    measure_refs: t.List[str] = Field(default_factory=list)

    @model_validator(mode="before")
    @classmethod
    def _strip_computed_is_additive(cls, data: t.Any) -> t.Any:
        """
        Drop authored or persisted ``is_additive`` before validation.

        ``is_additive`` is a computed field derived from ``type``. Serialized snapshots
        and legacy YAML may still include it; ignore the input so round-trips succeed.
        """
        if isinstance(data, dict) and "is_additive" in data:
            data = dict(data)
            data.pop("is_additive")
        return data

    def _is_set(self, field: str) -> bool:
        value = getattr(self, field)
        if isinstance(value, str):
            return bool(value.strip())
        if isinstance(value, list):
            return bool(value)
        return bool(value)

    def _require_fields(self, *fields: str) -> None:
        if missing := [f for f in fields if not self._is_set(f)]:
            raise ValueError(f"behavior type {self.type!r} requires {', '.join(missing)}.")

    def _forbid_fields(self, *fields: str) -> None:
        if extra := [f for f in fields if self._is_set(f)]:
            raise ValueError(f"behavior type {self.type!r} must not set {', '.join(extra)}.")

    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_additive(self) -> bool:
        return self.type in ("simple", "flow")

    @model_validator(mode="after")
    def validate_by_type(self) -> MeasureBehaviorSpec:
        if self.type in ("simple", "flow"):
            self._forbid_fields(
                "time_dimension",
                "period_treatment",
                "period_grain",
                "numerator",
                "denominator",
                "measure_refs",
            )
            return self

        if self.type == "stock":
            self._require_fields("time_dimension", "period_treatment", "period_grain")
            self._forbid_fields("numerator", "denominator", "measure_refs")
            return self

        if self.type == "ratio":
            self._require_fields("numerator", "denominator")
            self._forbid_fields("time_dimension", "period_treatment", "period_grain")
            return self.model_copy(
                update={
                    "measure_refs": [self.numerator.strip(), self.denominator.strip()],
                }
            )

        if self.type == "derived":
            self._require_fields("measure_refs")
            self._forbid_fields(
                "time_dimension",
                "period_treatment",
                "period_grain",
                "numerator",
                "denominator",
            )
            return self

        return self

    @model_serializer(mode="wrap")
    def _omit_empty_fields(
        self,
        handler: t.Callable[..., t.Dict[str, t.Any]],
    ) -> t.Dict[str, t.Any]:
        data = handler(self)
        return {
            key: value
            for key, value in data.items()
            if value not in ("", [], None) or key in ("type", "is_additive")
        }


class DimensionBehaviorSpec(pydantic.BaseModel):
    model_config = _WIRE_CONFIG

    type: DimensionSemanticTypeValue


ColumnBehavior = t.Union[MeasureBehaviorSpec, DimensionBehaviorSpec]


class RollingWindowSpec(pydantic.BaseModel):
    model_config = _WIRE_CONFIG

    _ROLLING_WINDOW_RE: t.ClassVar[re.Pattern[str]] = re.compile(
        r"^-?\d+\s+(minute|hour|day|week|month|year)s?$", re.IGNORECASE
    )

    trailing: t.Optional[str] = None
    leading: t.Optional[str] = None
    offset: str = "end"

    @field_validator("trailing", "leading")
    @classmethod
    def validate_window_size(cls, v: t.Optional[str]) -> t.Optional[str]:
        if v is None or str(v).lower() == "unbounded":
            return v
        if not cls._ROLLING_WINDOW_RE.match(str(v).strip()):
            raise ValueError(
                f"Invalid window size {v!r}. Use e.g. '1 day', '30 days', or 'unbounded'"
            )
        return str(v).strip()

    @field_validator("offset")
    @classmethod
    def validate_offset(cls, v: str) -> str:
        if v not in ("start", "end"):
            raise ValueError(f"offset must be 'start' or 'end', got {v!r}")
        return v


class TimeGranularitySpec(pydantic.BaseModel):
    model_config = _WIRE_CONFIG

    _INTERVAL_RE: t.ClassVar[re.Pattern[str]] = re.compile(
        r"^\d+\s+(minute|hour|day|week|month|year)s?$", re.IGNORECASE
    )

    name: str
    interval: str
    offset: t.Optional[str] = None
    origin: t.Optional[str] = None
    description: t.Optional[str] = None
    ai_context: t.Optional[AiContextSpec] = None

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        return _validate_name(v, context="granularity name")

    @field_validator("interval")
    @classmethod
    def validate_interval(cls, v: str) -> str:
        if not cls._INTERVAL_RE.match(v.strip()):
            raise ValueError(
                f"Invalid interval {v!r}. Use a positive duration like '1 day' or '15 minutes'"
            )
        return v.strip()


DQDimension = Literal[
    "accuracy",
    "completeness",
    "conformity",
    "consistency",
    "coverage",
    "timeliness",
    "validity",
    "uniqueness",
]


class IntervalUnit(str, Enum):
    YEAR = "year"
    MONTH = "month"
    DAY = "day"
    HOUR = "hour"
    HALF_HOUR = "half_hour"
    QUARTER_HOUR = "quarter_hour"
    FIVE_MINUTE = "five_minute"

    @property
    def is_date_granularity(self) -> bool:
        return self in (IntervalUnit.YEAR, IntervalUnit.MONTH, IntervalUnit.DAY)

    @property
    def is_year(self) -> bool:
        return self == IntervalUnit.YEAR

    @property
    def is_month(self) -> bool:
        return self == IntervalUnit.MONTH

    @property
    def is_day(self) -> bool:
        return self == IntervalUnit.DAY

    @property
    def is_hour(self) -> bool:
        return self == IntervalUnit.HOUR

    @property
    def is_minute(self) -> bool:
        return self in (
            IntervalUnit.FIVE_MINUTE,
            IntervalUnit.QUARTER_HOUR,
            IntervalUnit.HALF_HOUR,
        )
