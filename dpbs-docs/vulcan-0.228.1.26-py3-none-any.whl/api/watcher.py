from __future__ import annotations
_C='plan_id'
_B=True
_A=None
import asyncio,logging
from fastapi import FastAPI
from pgqueuer import QueueManager
from vulcan.core import constants as c
from api.context import EnvContextManager
from api.state.activity import AsyncActivityState
from api.worker.perspective_jobs import enqueue_perspective_refresh_sweep
logger=logging.getLogger(__name__)
async def _maybe_enqueue_hera_catalog_reconcile(manager:EnvContextManager,qm:QueueManager)->_A:
	from api.worker.hera.jobs import enqueue_hera_full_sync,should_sync_data_product;context=manager.context
	if not should_sync_data_product(context):logger.debug('Skipping Hera catalog reconcile; product not discoverable or no domain');return
	hera_cfg=context.config.hera
	if not hera_cfg or not hera_cfg.enabled:logger.debug('Skipping Hera catalog reconcile; Hera sync disabled');return
	env=c.PROD;env_ctx=manager.get_env_context(env);plan_id=getattr(env_ctx,_C,_A)
	if not plan_id:logger.warning('Skipping Hera catalog reconcile; no plan_id for env=%s',env);return
	result=await enqueue_hera_full_sync(qm,env,plan_id=plan_id,update_run_status=_B,trigger='reconcile');logger.info('hera catalog reconcile enqueued (env=%s): %s',env,result)
async def env_change_watcher_task(manager:EnvContextManager,activity:AsyncActivityState,app:FastAPI,sleep_seconds:int=5)->_A:
	A=False;last_ts=0;startup_reconciled=A;logger.info('Environment change watcher started (polling every %ds)',sleep_seconds)
	while _B:
		try:
			if not startup_reconciled and getattr(app.state,'worker_healthy',A):
				qm:QueueManager|_A=getattr(app.state,'qm',_A)
				if qm is not _A:
					try:await _maybe_enqueue_hera_catalog_reconcile(manager,qm);startup_reconciled=_B
					except Exception:logger.exception('Hera catalog reconcile enqueue failed; will retry on next poll')
			changes,max_ts_ns=await activity.fetch_plan_run_activity_since(last_ts);checkpoint_ts=last_ts;has_any_change=A
			for change in changes:
				env=change.environment;qm:QueueManager|_A=getattr(app.state,'qm',_A)
				if change.has_plan:
					logger.info("Plan changes detected for '%s'. Rebuilding environment...",env);await manager.on_plan_change(env)
					if env==c.PROD:
						from api.worker.hera.jobs import enqueue_hera_full_sync;env_ctx=manager.get_env_context(env);plan_id=getattr(env_ctx,_C,_A)
						if qm is not _A and plan_id:result=await enqueue_hera_full_sync(qm,env,plan_id=plan_id,update_run_status=bool(change.has_run));logger.info('hera_full_sync enqueued (env=%s): %s',env,result)
						elif qm is not _A:logger.warning('Skipping Hera full sync; no plan_id for env=%s',env)
						else:logger.debug('Skipping Hera full sync enqueue; no queue manager')
				if change.has_run:
					logger.info("Run changes detected for '%s'. Updating run cache...",env);await manager.on_run_change(env)
					if env==c.PROD and not change.has_plan:
						from api.worker.hera.jobs import enqueue_hera_run_status
						if qm is not _A:result=await enqueue_hera_run_status(qm,env);logger.info('hera_run_status enqueued (env=%s): %s',env,result)
						else:logger.debug('Skipping Hera run-status enqueue; no queue manager')
				if change.has_plan or change.has_run:
					has_any_change=_B;logger.info('Change detected: has_plan=%s, has_run=%s, last_ts=%s, max_ts_ns=%s',change.has_plan,change.has_run,last_ts,max_ts_ns)
					if checkpoint_ts!=0:
						if qm is not _A:logger.info('Enqueueing perspective_refresh_sweep (env=%s, since_ts_ms=%d)',env,checkpoint_ts//1000000);await enqueue_perspective_refresh_sweep(qm,environment=env,since_ts_ms=checkpoint_ts//1000000)
						else:logger.debug('Skipping perspective_refresh_sweep enqueue; no queue manager')
					else:logger.debug('Skipping perspective refresh on cold start (last_ts=0)')
			if has_any_change:last_ts=max_ts_ns;logger.debug('Updated checkpoint: last_ts=%s',last_ts)
		except Exception as exc:logger.error('Environment change watcher error: %s',exc,exc_info=_B)
		await asyncio.sleep(sleep_seconds)