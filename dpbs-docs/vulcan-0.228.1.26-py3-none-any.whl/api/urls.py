from __future__ import annotations
_C=False
_B='/'
_A=None
import os,typing as t
from fastapi import Query
from vulcan.utils import str_to_bool
API_V1_PREFIX='/api/v1'
_LOCALHOST_TRUTHY=frozenset({'1','true','yes'})
_DEFAULT_LOCAL_POSTMAN_HOST='127.0.0.1:8000'
def api_v1_path(relative:str)->str:
	if not relative.startswith(_B):relative=f"/{relative}"
	return f"{API_V1_PREFIX}{relative}"
def is_localhost()->bool:return os.environ.get('LOCALHOST','').strip().lower()in _LOCALHOST_TRUTHY
def openapi_server_url()->str:
	if is_localhost():return _B
	return ingress_base_url(include_scheme=True)
def postman_base_url(*,tenant:str|_A=_A,resource:str|_A=_A)->str:
	if is_localhost():return _DEFAULT_LOCAL_POSTMAN_HOST
	return ingress_base_url(include_scheme=_C,tenant=tenant,resource=resource)
def ingress_base_url(*,include_scheme:bool=_C,tenant:str|_A=_A,resource:str|_A=_A)->str:fqdn=os.environ.get('DATAOS_FQDN','').strip()or'<DATAOS_FQDN>';tenant_id=os.environ.get('DATAOS_TENANT_ID','').strip()or(tenant or'').strip()or'<DATAOS_TENANT_ID>';resource_name=os.environ.get('DATAOS_RESOURCE_NAME','').strip()or(resource or'').strip()or'<resource-name>';path=f"{fqdn}/vulcan/tenants/{tenant_id}/data-products/{tenant_id}-{resource_name}";return f"https://{path}"if include_scheme else path
class URLBuilder:
	def __init__(self,prefix:str=API_V1_PREFIX):self.prefix=prefix.rstrip(_B)
	def _url(self,path:str)->str:
		if not path.startswith(_B):path=f"/{path}"
		return f"{self.prefix}{path}"
	def query_statement_detail(self,statement_id:str)->str:return self._url(f"/query/statement/{statement_id}")
	def query_statement_result(self,statement_id:str)->str:return self._url(f"/query/statement/{statement_id}/result")
	def perspective_detail(self,slug:str)->str:return self._url(f"/perspectives/{slug}")
	def perspective_result(self,slug:str)->str:return self._url(f"/perspectives/{slug}/result")
	def perspective_refresh(self,slug:str)->str:return self._url(f"/perspectives/{slug}/refresh")
	def plans(self,model_names:t.Optional[str]=_A,success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:t.Optional[int]=_A,offset:t.Optional[int]=_A)->str:
		url=self._url('/activity/plans');params=[]
		if model_names:params.append(f"model_names={model_names}")
		if success is not _A:params.append(f"success={str(success).lower()}")
		if start_ts is not _A:params.append(f"start_ts={start_ts}")
		if end_ts is not _A:params.append(f"end_ts={end_ts}")
		if limit is not _A:params.append(f"limit={limit}")
		if offset is not _A:params.append(f"offset={offset}")
		if params:url=f"{url}?{'&'.join(params)}"
		return url
	def runs(self,model_names:t.Optional[str]=_A,success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:t.Optional[int]=_A,offset:t.Optional[int]=_A)->str:
		url=self._url('/activity/runs');params=[]
		if model_names:params.append(f"model_names={model_names}")
		if success is not _A:params.append(f"success={str(success).lower()}")
		if start_ts is not _A:params.append(f"start_ts={start_ts}")
		if end_ts is not _A:params.append(f"end_ts={end_ts}")
		if limit is not _A:params.append(f"limit={limit}")
		if offset is not _A:params.append(f"offset={offset}")
		if params:url=f"{url}?{'&'.join(params)}"
		return url
	def plan(self,plan_id:str)->str:return self._url(f"/activity/plans/{plan_id}")
	def plan_git_diff(self,plan_id:str)->str:return self._url(f"/activity/plans/{plan_id}/git-diff")
	def run(self,run_id:str)->str:return self._url(f"/activity/runs/{run_id}")
	def notifications(self,run_id:t.Optional[str]=_A,plan_id:t.Optional[str]=_A,events:t.Optional[t.Sequence[str]]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:t.Optional[int]=_A,offset:t.Optional[int]=_A)->str:
		url=self._url('/notifications');params=[]
		if run_id:params.append(f"run_id={run_id}")
		if plan_id:params.append(f"plan_id={plan_id}")
		if events:
			for event in events:params.append(f"events={event}")
		if start_ts is not _A:params.append(f"start_ts={start_ts}")
		if end_ts is not _A:params.append(f"end_ts={end_ts}")
		if limit is not _A:params.append(f"limit={limit}")
		if offset is not _A:params.append(f"offset={offset}")
		if params:url=f"{url}?{'&'.join(params)}"
		return url
	def dq_summary(self)->str:return self._url('/dq')
	def dq_rules(self,model:t.Optional[str]=_A,column:t.Optional[str]=_A,dimension:t.Optional[str]=_A)->str:
		url=self._url('/dq/rules');params=[]
		if model:params.append(f"model={model}")
		if column:params.append(f"column={column}")
		if dimension:params.append(f"dimension={dimension}")
		if params:url=f"{url}?{'&'.join(params)}"
		return url
	def dq_rule_runs(self,identity:str,model:t.Optional[str]=_A,limit:t.Optional[int]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A)->str:
		url=self._url(f"/dq/rules/{identity}");params=[]
		if model:params.append(f"model={model}")
		if limit:params.append(f"limit={limit}")
		if start_ts:params.append(f"start_ts={start_ts}")
		if end_ts:params.append(f"end_ts={end_ts}")
		if params:url=f"{url}?{'&'.join(params)}"
		return url
	def dq_rule_runs_by_name(self,model:str,dimension:str,name:str,limit:t.Optional[int]=_A,offset:t.Optional[int]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A)->str:
		from urllib.parse import quote;encoded_model=quote(model,safe=_B);encoded_dimension=quote(dimension,safe=_B);encoded_name=quote(name,safe=_B);url=self._url(f"/dq/rules/by-name/{encoded_model}/{encoded_dimension}/{encoded_name}");params=[]
		if limit:params.append(f"limit={limit}")
		if offset:params.append(f"offset={offset}")
		if start_ts:params.append(f"start_ts={start_ts}")
		if end_ts:params.append(f"end_ts={end_ts}")
		if params:url=f"{url}?{'&'.join(params)}"
		return url
urls=URLBuilder()
def parse_gateway_query(gateway:t.Optional[str]=Query(default=_A,include_in_schema=_C,description='Execution gateway (must match metadata gateway or gateways)'))->t.Optional[str]:return gateway
def parse_transpile_only_query(transpile_only:str=Query(default='false',description='Transpile semantic query to warehouse SQL without creating a statement. Truthy values (case-insensitive): true, 1, yes, on, t, y.'))->bool:return str_to_bool(transpile_only.strip())