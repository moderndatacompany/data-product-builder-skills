from __future__ import annotations
_E='message'
_D='error'
_C=True
_B=False
_A=None
import asyncio,logging,time,typing as t,pydantic
from fastapi import HTTPException
from pgqueuer import QueueManager
from schema.rest_query import RestQuery
from vulcan.core import constants as c
from vulcan.core.query.definitions import Perspective,QueryFingerprintResult,QueryRequest,QueryStatus,QueryStrategy,QueryType
from vulcan.utils import random_id
from vulcan.utils.errors import QueryValidationError
from api import prometheus
from api.context import EnvContext
from api.context import UnknownGatewayError
from api.exceptions import QueryExecutionError
from api.query.validator import QueryValidator
from api.schemas.common import Link
from api.schemas.query import QueryExecutionResult,StatementAccepted,StatementLinks
from api.state.query import AsyncQueryState
from api.utils.commons import timestamp_to_iso
from api.urls import urls
from api.worker.query_jobs import QueryJobPayload,enqueue_query_execution
logger=logging.getLogger(__name__)
def make_statement_links(*,request_id:str,primary_request_id:t.Optional[str]=_A,include_result:bool=_B)->StatementLinks:return StatementLinks(self=Link(href=urls.query_statement_detail(request_id)),primary=Link(href=urls.query_statement_detail(primary_request_id))if primary_request_id else _A,result=Link(href=urls.query_statement_result(request_id))if include_result else _A)
def build_statement_accepted(req:QueryRequest,exec_result:QueryExecutionResult)->StatementAccepted:
	from api.schemas.query import CacheInfo,PrimaryReq;current_ts=time.time();primary_req:t.Optional[PrimaryReq]=_A;cache_info:t.Optional[CacheInfo]=_A;primary_request_id:t.Optional[str]=_A;include_result=_B
	if exec_result.strategy==QueryStrategy.REUSE_RESULT:
		status=QueryStatus.SUCCESS;include_result=_C
		if exec_result.cache_metadata:cache_info=CacheInfo(cached_at=timestamp_to_iso(int(exec_result.cache_metadata.cached_at*1000)),age_seconds=exec_result.cache_metadata.age_seconds)
	elif exec_result.strategy==QueryStrategy.AWAIT_PRIMARY:
		primary_meta=exec_result.primary_metadata;status=primary_meta.status if primary_meta else QueryStatus.QUEUED
		if primary_meta:primary_req=PrimaryReq(request_id=primary_meta.request_id,status=primary_meta.status,submitted_at=timestamp_to_iso(int(primary_meta.submitted_at*1000)),submitted_by=primary_meta.submitted_by,started_at=timestamp_to_iso(int(primary_meta.started_at*1000))if primary_meta.started_at else _A,elapsed_ms=int((current_ts-primary_meta.submitted_at)*1000));primary_request_id=primary_meta.request_id
	else:status=QueryStatus.QUEUED
	return StatementAccepted(id=req.request_id,status=status,strategy=exec_result.strategy,fingerprint=exec_result.fingerprint,sql=req.sql_query,params=req.params,depends_on=req.depends_on,submitted_at=timestamp_to_iso(req.submitted_ts),meta=req.meta,query_type=req.query_type,job_id=exec_result.job_id,primary=primary_req,cache=cache_info,links=make_statement_links(request_id=req.request_id,primary_request_id=primary_request_id,include_result=include_result))
async def submit_sql_via_flow(*,sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],ttl:int=0,meta:t.Optional[t.Dict[str,t.Any]],gateway:str,qv:QueryValidator,qm:QueueManager,query_state:AsyncQueryState,env_context:EnvContext,retry_on_recent_failure:bool=_B,query_type:t.Optional[QueryType]=_A,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[RestQuery]=_A,graphql_query:t.Optional[str]=_A,perspective_id:t.Optional[str]=_A,submitted_by:t.Optional[str]=_A)->StatementAccepted:
	rest_query_wire:t.Optional[t.Dict[str,t.Any]]=rest_query.model_dump(exclude_none=_C,by_alias=_C)if rest_query is not _A else _A;exec_result=await _execute_or_reuse_query(sql=sql,params=params,gateway=gateway,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query_wire,graphql_query=graphql_query,perspective_id=perspective_id,qv=qv,query_state=query_state,qm=qm,env_context=env_context,submitted_by=submitted_by,retry_on_recent_failure=retry_on_recent_failure);req=await query_state.get_request_by_id(exec_result.request_id)
	if not req:raise HTTPException(500,'Failed to create statement')
	return build_statement_accepted(req,exec_result)
async def _execute_or_reuse_query(sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],gateway:str,ttl:int,meta:t.Optional[t.Dict],qv:QueryValidator,query_state:AsyncQueryState,qm:QueueManager,env_context:EnvContext,submitted_by:t.Optional[str]=_A,retry_on_recent_failure:bool=_B,query_type:t.Optional[QueryType]=_A,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[t.Dict[str,t.Any]]=_A,graphql_query:t.Optional[str]=_A,perspective_id:t.Optional[str]=_A)->QueryExecutionResult:
	B='on_cache_event failed: %s';A='query'
	try:validation=qv.validate_query(sql,params,query_type=query_type)
	except QueryValidationError as e:raise QueryExecutionError(status_code=400,detail={_D:e.error_type,_E:e.message})
	fingerprint=validation.fingerprint;normalized_sql=validation.normalized_sql;depends_on=validation.depends_on;fingerprint_result=await query_state.get_fingerprint_result(fingerprint)
	if fingerprint_result:
		depends_on=fingerprint_result.depends_on or[];result_ts=fingerprint_result.result_created_ts;is_stale=env_context.did_models_change_after(ts=result_ts,model_names=depends_on)
		if not is_stale:
			try:prometheus.registry.on_cache_event(api=A,hit=_C)
			except Exception as e:logger.debug(B,e)
			return await _handle_reuse_result(fingerprint_result=fingerprint_result,fingerprint=fingerprint,sql=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,perspective_id=perspective_id,query_state=query_state)
		logger.info('Fingerprint found but stale: fingerprint=%s...',fingerprint[:16])
	in_flight=await query_state.get_in_flight_request_by_fingerprint(fingerprint)
	if in_flight:return await _handle_in_flight(in_flight=in_flight,fingerprint=fingerprint,sql=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,perspective_id=perspective_id,query_state=query_state)
	await _check_recent_failures(fingerprint=fingerprint,retry_on_recent_failure=retry_on_recent_failure,query_state=query_state)
	try:prometheus.registry.on_cache_event(api=A,hit=_B)
	except Exception as e:logger.debug(B,e)
	return await _handle_new_execution(fingerprint=fingerprint,sql=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,perspective_id=perspective_id,query_state=query_state,qm=qm,env_context=env_context)
async def _handle_reuse_result(fingerprint_result:QueryFingerprintResult,fingerprint:str,sql:str,normalized_sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],gateway:str,submitted_by:t.Optional[str],depends_on:t.Optional[t.List[str]],ttl:int,meta:t.Optional[t.Dict],query_type:t.Optional[QueryType],semantic_query:t.Optional[str],rest_query:t.Optional[t.Dict[str,t.Any]],graphql_query:t.Optional[str],perspective_id:t.Optional[str],query_state:AsyncQueryState)->QueryExecutionResult:request_id=random_id();current_ts=time.time();await query_state.create_request(request_id=request_id,strategy=QueryStrategy.REUSE_RESULT,fingerprint=fingerprint,sql_query=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,perspective_id=perspective_id,cached_at_ts=fingerprint_result.cached_at_ts,result_id=fingerprint_result.result_id);logger.info('Fingerprint hit: fingerprint=%s..., request_id=%s...',fingerprint[:16],request_id[:16]);from api.schemas.query import CacheMetadata;return QueryExecutionResult(strategy=QueryStrategy.REUSE_RESULT,request_id=request_id,fingerprint=fingerprint,normalized_sql=normalized_sql,depends_on=depends_on,job_id=_A,cache_metadata=CacheMetadata(cached_at=fingerprint_result.cached_at_ts/1e3,age_seconds=int(current_ts-fingerprint_result.cached_at_ts/1e3)))
async def _handle_in_flight(in_flight:QueryRequest,fingerprint:str,sql:str,normalized_sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],gateway:str,submitted_by:t.Optional[str],depends_on:t.Optional[t.List[str]],ttl:int,meta:t.Optional[t.Dict],query_type:t.Optional[QueryType],semantic_query:t.Optional[str],rest_query:t.Optional[t.Dict[str,t.Any]],graphql_query:t.Optional[str],perspective_id:t.Optional[str],query_state:AsyncQueryState)->QueryExecutionResult:request_id=random_id();await query_state.create_request(request_id=request_id,strategy=QueryStrategy.AWAIT_PRIMARY,fingerprint=fingerprint,sql_query=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,perspective_id=perspective_id,primary_request_id=in_flight.request_id);logger.info('Request deduplicated: fingerprint=%s..., request_id=%s..., primary=%s...',fingerprint[:16],request_id[:16],in_flight.request_id[:16]);from api.schemas.query import PrimaryMetadata;return QueryExecutionResult(strategy=QueryStrategy.AWAIT_PRIMARY,request_id=request_id,fingerprint=fingerprint,normalized_sql=normalized_sql,depends_on=depends_on,job_id=_A,primary_metadata=PrimaryMetadata(request_id=in_flight.request_id,status=in_flight.execution_status,submitted_at=in_flight.submitted_ts/1e3,submitted_by=in_flight.submitted_by,started_at=in_flight.execution_start_ts/1e3 if in_flight.execution_start_ts else _A))
async def _check_recent_failures(fingerprint:str,retry_on_recent_failure:bool,query_state:AsyncQueryState)->_A:
	C='submitted_by';B='age_seconds';A='last_failed_at'
	if retry_on_recent_failure:return
	recent_failed=await query_state.get_recent_failed_execution_by_fingerprint(fingerprint,window_seconds=300)
	if not recent_failed:return
	current_ts=time.time();last_failed_at_ms=recent_failed.execution_end_ts;age_seconds=int(current_ts-last_failed_at_ms/1e3)if last_failed_at_ms is not _A else _A;error_message=recent_failed.error_message or'';logger.info('Recent failed execution for fingerprint=%s..., last_request_id=%s...',fingerprint[:16],recent_failed.request_id[:16]);_AUTH_PATTERNS='Authentication token has expired','authentication token has expired'
	if any(pat in error_message for pat in _AUTH_PATTERNS):raise QueryExecutionError(status_code=400,detail={_D:'AUTHENTICATION_EXPIRED',_E:error_message,A:last_failed_at_ms,B:age_seconds,C:recent_failed.submitted_by})
	raise QueryExecutionError(status_code=400,detail={_D:'RECENT_FAILURE',_E:'An identical query failed recently. Fix the error before retrying or set retry_on_recent_failure=true to override.',A:last_failed_at_ms,B:age_seconds,C:recent_failed.submitted_by,'last_error':error_message[:512]})
async def _handle_new_execution(fingerprint:str,sql:str,normalized_sql:str,params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]],gateway:str,submitted_by:t.Optional[str],depends_on:t.Optional[t.List[str]],ttl:int,meta:t.Optional[t.Dict],query_type:t.Optional[QueryType],semantic_query:t.Optional[str],rest_query:t.Optional[t.Dict[str,t.Any]],graphql_query:t.Optional[str],perspective_id:t.Optional[str],query_state:AsyncQueryState,qm:QueueManager,env_context:EnvContext)->QueryExecutionResult:
	request_id=random_id();await query_state.create_request(request_id=request_id,strategy=QueryStrategy.EXECUTE,fingerprint=fingerprint,sql_query=sql,normalized_sql=normalized_sql,params=params,gateway=gateway,submitted_by=submitted_by,depends_on=depends_on,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,perspective_id=perspective_id,execution_status=QueryStatus.ACCEPTED);payload=QueryJobPayload(request_id=request_id,fingerprint=fingerprint,gateway=gateway,sql=sql,params=params,ttl_minutes=ttl,depends_on=depends_on,environment=env_context.environment,perspective_id=perspective_id,submitted_by=submitted_by)
	try:job_id=await enqueue_query_execution(qm,payload);await query_state.mark_request_queued(request_id,job_id);logger.info('Query enqueued: request_id=%s..., job_id=%s',request_id[:16],job_id)
	except Exception as e:logger.exception('Failed to enqueue job');await query_state.mark_request_failed(request_id,f"Enqueue failed: {str(e)}");raise QueryExecutionError(status_code=500,detail='Failed to enqueue query for execution')
	return QueryExecutionResult(strategy=QueryStrategy.EXECUTE,request_id=request_id,fingerprint=fingerprint,normalized_sql=normalized_sql,depends_on=depends_on,job_id=job_id)
async def _fire_hera_perspective_sync(qm:QueueManager,perspective_id:str,environment:str)->_A:
	try:from api.worker.hera.jobs import enqueue_hera_perspective_sync;await enqueue_hera_perspective_sync(qm,environment,perspective_id)
	except Exception as exc:logger.warning('Hera perspective sync failed (id=%s): %s',perspective_id[:16],exc)
async def submit_perspective_refresh_by_id(perspective_id:str,env_context:EnvContext,query_state:AsyncQueryState,qm:QueueManager)->StatementAccepted:
	perspective=await query_state.get_perspective_by_id(perspective_id)
	if not perspective:raise QueryExecutionError(status_code=404,detail=f"Perspective '{perspective_id}' not found")
	return await submit_perspective_refresh(perspective=perspective,env_context=env_context,query_state=query_state,qm=qm)
async def submit_perspective_refresh(perspective:Perspective,env_context:EnvContext,query_state:AsyncQueryState,qm:QueueManager)->StatementAccepted:
	logger.info(f"Refreshing perspective: '{perspective.slug}'")
	if not perspective.sql_query:raise QueryExecutionError(status_code=400,detail='Perspective has no query definition')
	try:rest_query=RestQuery.from_storage(perspective.rest_query)
	except pydantic.ValidationError as e:raise QueryExecutionError(status_code=400,detail=f"Perspective '{perspective.slug}' has invalid stored rest_query: {e}")from e
	try:exec_gateway=env_context.resolve_gateway(perspective.gateway)
	except UnknownGatewayError as exc:raise QueryExecutionError(status_code=400,detail={_D:'UNKNOWN_GATEWAY',_E:f"Unknown gateway '{exc.requested}'.",'allowed':exc.allowed})from exc
	accepted=await submit_sql_via_flow(sql=perspective.sql_query,params=perspective.params,ttl=perspective.ttl,meta=perspective.meta,gateway=exec_gateway,qv=env_context.get_query_validator(exec_gateway),qm=qm,query_state=query_state,env_context=env_context,retry_on_recent_failure=_B,query_type=perspective.query_type,semantic_query=perspective.semantic_query,rest_query=rest_query,graphql_query=perspective.graphql_query,perspective_id=perspective.perspective_id)
	if accepted.strategy==QueryStrategy.REUSE_RESULT and perspective.perspective_id:
		try:
			await query_state.update_request_id_for_perspective(perspective_id=perspective.perspective_id,request_id=accepted.id)
			if env_context.environment==c.PROD:asyncio.create_task(_fire_hera_perspective_sync(qm,perspective.perspective_id,env_context.environment))
		except Exception as e:logger.warning(f"Failed to update perspective request_id: {e}",exc_info=_C)
	return accepted