from __future__ import annotations
_H='text/csv'
_G='application/yaml'
_F='csv'
_E='yaml'
_D='json'
_C='parquet'
_B=False
_A=None
import math,typing as t
from datetime import date,datetime
import pandas as pd,yaml
from fastapi import HTTPException
from fastapi.responses import Response
from vulcan.core.query.definitions import QueryRequest
from api.context import EnvContext
from api.schemas.common import Link
from api.schemas.query import StatementResult,StatementResultLinks
from api.state.query import AsyncQueryState
from api.urls import urls
ResultFormat=t.Literal[_C,_D,_E,_F]
def staleness_headers(is_stale:bool)->t.Dict[str,str]:
	if is_stale:return{'Is-Stale':'true'}
	return{}
async def is_request_stale(request_id:str,query_state:AsyncQueryState,env_context:EnvContext)->t.Tuple[bool,t.Optional[QueryRequest]]:
	query_request=await query_state.get_request_by_id(request_id)
	if not query_request:return _B,_A
	depends_on=query_request.depends_on or[];completed_ts=query_request.execution_end_ts or query_request.submitted_ts;is_stale=env_context.did_models_change_after(ts=completed_ts,model_names=depends_on);return is_stale,query_request
def resolve_format(format_param:t.Optional[str],accept_header:str)->ResultFormat:
	if format_param:
		valid_formats:t.List[ResultFormat]=[_C,_D,_E,_F];normalized=format_param.lower()
		if normalized not in valid_formats:raise HTTPException(406,f"Format '{format_param}' not supported. Use: {', '.join(valid_formats)}")
		return normalized
	if'application/json'in accept_header:return _D
	if _G in accept_header or'text/yaml'in accept_header:return _E
	if _H in accept_header:return _F
	return _C
def apply_filtering(df:pd.DataFrame,limit:t.Optional[int],offset:int,columns:t.Optional[str],schema:t.List[t.Dict[str,str]])->pd.DataFrame:
	if columns:
		requested_cols=[c.strip()for c in columns.split(',')if c.strip()];available_cols=[col['name']for col in schema];invalid_cols=[c for c in requested_cols if c not in available_cols]
		if invalid_cols:raise HTTPException(400,f"Invalid columns requested: {invalid_cols}. Available: {available_cols}")
		df=df[requested_cols]
	start=offset if offset is not _A else 0;end=_A if limit is _A else start+limit;return df.iloc[start:end]
def normalize_scalar_for_json(value:t.Any)->t.Any:
	import numpy as np
	if isinstance(value,np.generic):value=value.item()
	if value is _A:return
	if isinstance(value,(pd.Timestamp,datetime,np.datetime64)):
		if pd.isna(value):return
		return pd.to_datetime(value).strftime('%Y-%m-%dT%H:%M:%S.%fZ')
	if isinstance(value,date):return value.isoformat()
	if isinstance(value,float)and not math.isfinite(value):return
	is_na=pd.isna(value)
	if isinstance(is_na,(bool,np.bool_))and is_na:return
	return value
def to_json(df:t.Any,schema:t.List[t.Dict[str,str]],statement_id:str)->StatementResult:selected_cols=[str(c)for c in df.columns.tolist()];filtered_schema=[col for col in schema if col['name']in selected_cols];rows=[[normalize_scalar_for_json(value)for value in row]for row in df.itertuples(index=_B,name=_A)];result=StatementResult(cols=selected_cols,rows=rows,types=filtered_schema,row_count=len(df),size_bytes=int(df.memory_usage(deep=True).sum()),links=StatementResultLinks(self=Link(href=urls.query_statement_result(statement_id))));return result
def to_yaml(df:t.Any,is_stale:t.Optional[bool]=_A)->Response:data=df.to_dict(orient='records');yaml_content=yaml.dump(data,default_flow_style=_B,allow_unicode=True);return Response(content=yaml_content,media_type=_G,headers=staleness_headers(is_stale=is_stale or _B))
def to_csv(df:t.Any,is_stale:t.Optional[bool]=_A)->Response:csv_content=df.to_csv(index=_B);return Response(content=csv_content,media_type=_H,headers=staleness_headers(is_stale=is_stale or _B))