from __future__ import annotations
_D='Worker task cancelled'
_C=True
_B=False
_A=None
import asyncio,functools,logging
from fastapi import FastAPI
from pgqueuer import QueueManager
from vulcan import Context
from vulcan.core.config.pgq import PGQConfig
from vulcan.core.query import ObjectStoreClient
from vulcan.utils.errors import ConfigError
from api.context import EnvContextManager
from api.state.activity import AsyncActivityState
from api.state.query import AsyncQueryState
from api.utils.commons import parse_positive_float_env,parse_positive_int_env
from api.worker import start_worker
logger=logging.getLogger(__name__)
_WORKER_MAX_BACKOFF_S=parse_positive_float_env('VULCAN_WORKER_MAX_BACKOFF_S',default=3e1,floor=1.,ceiling=6e2)
_WORKER_MAX_CONSECUTIVE_FAILURES=parse_positive_int_env('VULCAN_WORKER_MAX_CONSECUTIVE_FAILURES',default=8,floor=1,ceiling=100)
_WORKER_STARTUP_GRACE_S=parse_positive_float_env('VULCAN_WORKER_STARTUP_GRACE_S',default=1e1,floor=1.,ceiling=3e2)
_WORKER_QUIET_WINDOW_S=parse_positive_float_env('VULCAN_WORKER_QUIET_WINDOW_S',default=3e2,floor=3e1,ceiling=36e2)
_WORKER_INITIAL_BACKOFF_S=1.
_NONRECOVERABLE_WORKER_ERRORS:tuple[type[BaseException],...]=(ImportError,SyntaxError,NameError,ConfigError)
async def _promote_worker_after_grace(app:FastAPI)->_A:await asyncio.sleep(_WORKER_STARTUP_GRACE_S);app.state.worker_healthy=_C;logger.info('Worker healthy after %.1fs startup grace window.',_WORKER_STARTUP_GRACE_S);await asyncio.sleep(_WORKER_QUIET_WINDOW_S)
async def supervised_worker(context:Context,queue_manager:QueueManager,query_state:AsyncQueryState,activity:AsyncActivityState,object_store:ObjectStoreClient|_A,pgq_config:PGQConfig,manager:EnvContextManager,app:FastAPI,*,dsn:str|_A=_A,schema:str|_A=_A)->_A:
	app.state.worker_healthy=_B;consecutive_failures=0;backoff=_WORKER_INITIAL_BACKOFF_S
	while _C:
		promote_task=asyncio.create_task(_promote_worker_after_grace(app),name='worker-promote-grace');clean_return=_B
		try:await start_worker(context,queue_manager,query_state,activity,object_store,pgq_config,manager,dsn=dsn,schema=schema);clean_return=_C
		except asyncio.CancelledError:promote_task.cancel();logger.info(_D);raise
		except _NONRECOVERABLE_WORKER_ERRORS as exc:promote_task.cancel();app.state.worker_healthy=_B;logger.critical('Worker hit non-recoverable error %s: %s; not retrying.',type(exc).__name__,exc,exc_info=_C);raise
		except Exception as exc:logger.error('Worker task failed (%s/%s): %s. Restarting in %.1fs',consecutive_failures+1,_WORKER_MAX_CONSECUTIVE_FAILURES,exc,backoff,exc_info=_C)
		finally:
			if not promote_task.done():promote_task.cancel()
		if clean_return:logger.error('start_worker returned cleanly; treating as unexpected failure.')
		if promote_task.done()and not promote_task.cancelled()and promote_task.exception()is _A:
			if consecutive_failures>0 or backoff>_WORKER_INITIAL_BACKOFF_S:logger.info('Sustained quiet window; resetting failure counter and backoff.')
			consecutive_failures=0;backoff=_WORKER_INITIAL_BACKOFF_S
		consecutive_failures+=1
		if consecutive_failures>=_WORKER_MAX_CONSECUTIVE_FAILURES:logger.critical('Worker task failed %s consecutive times; marking unhealthy.',consecutive_failures);app.state.worker_healthy=_B
		try:await asyncio.sleep(backoff)
		except asyncio.CancelledError:raise
		backoff=min(backoff*2.,_WORKER_MAX_BACKOFF_S)
def worker_done_callback(task:asyncio.Task[_A],*,app:FastAPI)->_A:
	try:task.result();logger.critical('Supervised worker exited cleanly; this should never happen. Flipping readiness off so Kubernetes restarts the pod.');app.state.worker_healthy=_B
	except asyncio.CancelledError:logger.info(_D)
	except Exception as exc:logger.critical('Supervised worker task terminated unexpectedly: %s',exc,exc_info=_C);app.state.worker_healthy=_B
def start_supervised_worker(app:FastAPI,*,context:Context,queue_manager:QueueManager,query_state:AsyncQueryState,activity:AsyncActivityState,object_store:ObjectStoreClient|_A,pgq_config:PGQConfig,manager:EnvContextManager,dsn:str,schema:str)->asyncio.Task[_A]:app.state.worker_healthy=_B;task=asyncio.create_task(supervised_worker(context,queue_manager,query_state,activity,object_store,pgq_config,manager,app,dsn=dsn,schema=schema));task.add_done_callback(functools.partial(worker_done_callback,app=app));return task