from __future__ import annotations
_J='reason'
_I='reconcile'
_H='plan'
_G='perspective_delete'
_F='perspective_sync'
_E='run_status'
_D='full_sync'
_C=True
_B=False
_A=None
import logging,typing as t
from datetime import timedelta
from pgqueuer.errors import DuplicateJobError
from pgqueuer.models import Job
from pydantic import BaseModel
from vulcan import Context
from vulcan.core import constants as c
from api.context import EnvContextManager
from api.pool import run_blocking_fast,run_blocking_heavy
from api.state.activity import AsyncActivityState
from api.state.query import AsyncQueryState
from api.worker import EnqueueQueueManager,WorkerQueueManager
logger=logging.getLogger(__name__)
HERA_SYNC_ENTRYPOINT='hera_sync'
_DEFAULT_DELAY=timedelta(seconds=5)
MAX_RETRIES=3
_dirty:dict[str,bool]={}
HeraSyncTrigger=t.Literal[_H,_I]
class HeraSyncPayload(BaseModel):kind:t.Literal[_D,_E,_F,_G];environment:str;plan_id:t.Optional[str]=_A;trigger:HeraSyncTrigger=_H;update_run_status:bool=_B;perspective_id:t.Optional[str]=_A;slug:t.Optional[str]=_A;retry_count:int=0
def _dirty_key(kind:str,environment:str)->str:return f"{kind}:{environment}"
def _is_prod(environment:str)->bool:return environment==c.PROD
def should_sync_data_product(context:Context)->bool:config=context.config;return bool(config.discoverable and config.domain)
def _data_product_exists(hera:t.Any,context:Context)->bool:from api.worker.hera.utils import _hera_generated_schema,data_product_name;hr=_hera_generated_schema();product_name=data_product_name(context.config.tenant,context.config.name);existing=hera.get_by_name(entity=hr.DataProduct,fqn=product_name);return bool(existing)
def _evaluate_full_sync_gate(context:Context,trigger:HeraSyncTrigger)->t.Optional[dict[str,t.Any]]:
	A='skipped'
	if trigger==_H:return
	if not should_sync_data_product(context):return{A:_C,_J:'not_discoverable'}
	hera_cfg=context.config.hera
	if not hera_cfg or not hera_cfg.enabled:return{A:_C,_J:'hera_disabled'}
	from api.worker.hera.utils import create_hera_client,data_product_name;hera=create_hera_client(url=hera_cfg.url,token=hera_cfg.token.get_secret_value(),verify_ssl=hera_cfg.verify_ssl)
	if _data_product_exists(hera,context):logger.info("Hera reconcile skipped: data product '%s' already present",data_product_name(context.config.tenant,context.config.name));return{A:_C,_J:'catalog_present'}
	logger.info("Hera reconcile proceeding: data product '%s' missing from catalog",data_product_name(context.config.tenant,context.config.name))
def _dedupe_key(payload:HeraSyncPayload)->str:
	parts=[HERA_SYNC_ENTRYPOINT,payload.kind,payload.environment]
	if payload.kind==_D:
		if payload.trigger==_I:parts.append(_I)
		else:parts.append(f"plan:{payload.plan_id or''}")
	else:parts.append(str(payload.retry_count))
	if payload.kind in{_F,_G}:parts.append(payload.perspective_id or payload.slug or'')
	return':'.join(parts)
async def _enqueue(qm:EnqueueQueueManager,payload:HeraSyncPayload,*,delay:timedelta,dirty_on_duplicate:bool)->t.Any:
	if not _is_prod(payload.environment):return
	try:return await qm.queries.enqueue([HERA_SYNC_ENTRYPOINT],[payload.model_dump_json().encode('utf-8')],execute_after=[delay],dedupe_key=[_dedupe_key(payload)])
	except DuplicateJobError:
		if dirty_on_duplicate:_dirty[_dirty_key(payload.kind,payload.environment)]=_C;logger.debug('Hera %s already pending/running for %s; dirty flag set',payload.kind,payload.environment)
		else:logger.debug('Hera %s already pending/running for %s; dropping duplicate',payload.kind,payload.environment)
		return
async def enqueue_hera_full_sync(qm:EnqueueQueueManager,environment:str,plan_id:str,delay:timedelta=_DEFAULT_DELAY,update_run_status:bool=_B,retry_count:int=0,trigger:HeraSyncTrigger=_H)->t.Any:return await _enqueue(qm,HeraSyncPayload(kind=_D,environment=environment,plan_id=plan_id,trigger=trigger,update_run_status=update_run_status,retry_count=retry_count),delay=delay,dirty_on_duplicate=_B)
async def enqueue_hera_run_status(qm:EnqueueQueueManager,environment:str,delay:timedelta=_DEFAULT_DELAY,retry_count:int=0)->t.Any:return await _enqueue(qm,HeraSyncPayload(kind=_E,environment=environment,retry_count=retry_count),delay=delay,dirty_on_duplicate=_C)
async def enqueue_hera_perspective_sync(qm:EnqueueQueueManager,environment:str,perspective_id:str,retry_count:int=0)->t.Any:return await _enqueue(qm,HeraSyncPayload(kind=_F,environment=environment,perspective_id=perspective_id,retry_count=retry_count),delay=timedelta(0),dirty_on_duplicate=_B)
async def enqueue_hera_perspective_delete(qm:EnqueueQueueManager,environment:str,slug:str,retry_count:int=0)->t.Any:return await _enqueue(qm,HeraSyncPayload(kind=_G,environment=environment,slug=slug,retry_count=retry_count),delay=timedelta(0),dirty_on_duplicate=_B)
def register_hera_entrypoints(qm:WorkerQueueManager,qm_enqueue:EnqueueQueueManager,context:Context,query_state:AsyncQueryState,activity:AsyncActivityState,manager:EnvContextManager)->_A:
	from api.worker.hera.sync import delete_perspective_from_hera,sync_latest_run_status,sync_perspective_by_id_to_hera,sync_to_hera
	@qm.entrypoint(HERA_SYNC_ENTRYPOINT,concurrency_limit=1)
	async def handle_hera_sync(job:Job):
		A='environment';payload=HeraSyncPayload.model_validate_json(job.payload.decode('utf-8'));env=payload.environment;kind=payload.kind;result:t.Any=_A;dispatch_error:Exception|_A=_A
		try:
			if kind==_D:
				env_ctx=manager._env_contexts.get(env)
				if env_ctx is _A:env_ctx=await run_blocking_heavy(manager.get_env_context,env)
				skip_result=await run_blocking_fast(_evaluate_full_sync_gate,context,payload.trigger)
				if skip_result is not _A:result=skip_result
				else:
					result=await sync_to_hera(context,env,metadata=env_ctx.metadata,query_state=query_state)
					if payload.update_run_status:
						run_status_result=await sync_latest_run_status(context,env,activity)
						if isinstance(result,dict)and isinstance(run_status_result,dict):result={**result,**run_status_result}
						elif run_status_result is not _A:result=run_status_result
			elif kind==_E:
				result=await sync_latest_run_status(context,env,activity)
				if isinstance(result,dict)and result.get(_J)=='data_product_missing'and should_sync_data_product(context):
					env_ctx=manager._env_contexts.get(env)
					if env_ctx is _A:env_ctx=await run_blocking_heavy(manager.get_env_context,env)
					plan_id=getattr(env_ctx,'plan_id',_A)
					if plan_id:await enqueue_hera_full_sync(qm_enqueue,env,plan_id,delay=timedelta(0),update_run_status=_C,trigger=_I)
			elif kind==_F:
				if not payload.perspective_id:logger.warning('Missing perspective_id for Hera perspective sync job');return
				await sync_perspective_by_id_to_hera(context,query_state,payload.perspective_id,env);result={A:env}
			elif kind==_G:
				if not payload.slug:logger.warning('Missing slug for Hera perspective delete job');return
				await run_blocking_fast(delete_perspective_from_hera,context,payload.slug,env);result={A:env}
			else:logger.warning('Unknown Hera job kind: %s',kind);return
		except Exception as exc:dispatch_error=exc
		if dispatch_error is not _A:
			if payload.retry_count<MAX_RETRIES:
				backoff=_DEFAULT_DELAY*2**payload.retry_count
				if kind==_D:
					if not payload.plan_id:logger.error('Hera full_sync retry skipped: missing plan_id');return
					await enqueue_hera_full_sync(qm_enqueue,env,payload.plan_id,delay=backoff,update_run_status=payload.update_run_status,retry_count=payload.retry_count+1,trigger=payload.trigger)
				elif kind==_E:await enqueue_hera_run_status(qm_enqueue,env,delay=backoff,retry_count=payload.retry_count+1)
				elif kind==_F:await enqueue_hera_perspective_sync(qm_enqueue,env,payload.perspective_id or'',retry_count=payload.retry_count+1)
				elif kind==_G:await enqueue_hera_perspective_delete(qm_enqueue,env,payload.slug or'',retry_count=payload.retry_count+1)
				logger.warning('Hera %s failed, retry %d scheduled: %s',kind,payload.retry_count+1,dispatch_error);return
			logger.error('Hera %s exhausted %d retries: %s',kind,MAX_RETRIES,dispatch_error);return
		if kind==_E and _dirty.pop(_dirty_key(kind,env),_B):await enqueue_hera_run_status(qm_enqueue,env,delay=timedelta(0),retry_count=payload.retry_count+1)