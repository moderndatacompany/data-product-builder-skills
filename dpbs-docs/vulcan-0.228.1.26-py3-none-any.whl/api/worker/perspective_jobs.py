from __future__ import annotations
_A=None
import asyncio,logging,typing as t
from datetime import timedelta
from pgqueuer.errors import DuplicateJobError
from pgqueuer.models import Job
from pydantic import BaseModel
from api.query.submit import submit_perspective_refresh
from api.context import EnvContextManager
from api.state.query import AsyncQueryState
from api.worker import EnqueueQueueManager,WorkerQueueManager
logger=logging.getLogger(__name__)
PERSPECTIVE_REFRESH_SWEEP_ENTRYPOINT='perspective_refresh_sweep'
_DEFAULT_DELAY=timedelta(seconds=5)
MAX_RETRIES=3
SWEEP_SUBMIT_CONCURRENCY:int=10
class PerspectiveRefreshSweepPayload(BaseModel):environment:str;since_ts_ms:int;retry_count:int=0
def _dedupe_key(payload:PerspectiveRefreshSweepPayload)->str:return f"{PERSPECTIVE_REFRESH_SWEEP_ENTRYPOINT}:{payload.environment}:{payload.since_ts_ms}:{payload.retry_count}"
async def enqueue_perspective_refresh_sweep(qm:EnqueueQueueManager,*,environment:str,since_ts_ms:int,retry_count:int=0)->t.Any:
	payload=PerspectiveRefreshSweepPayload(environment=environment,since_ts_ms=since_ts_ms,retry_count=retry_count)
	try:return await qm.queries.enqueue([PERSPECTIVE_REFRESH_SWEEP_ENTRYPOINT],[payload.model_dump_json().encode('utf-8')],execute_after=[timedelta(0)],dedupe_key=[_dedupe_key(payload)])
	except DuplicateJobError:logger.debug('perspective_refresh_sweep already pending for %s since_ts_ms=%d; dropping duplicate (dedupe_key=%s)',environment,since_ts_ms,_dedupe_key(payload));return
def register_perspective_entrypoints(qm:WorkerQueueManager,manager:EnvContextManager,query_state:AsyncQueryState,qm_enqueue:EnqueueQueueManager)->_A:
	@qm.entrypoint(PERSPECTIVE_REFRESH_SWEEP_ENTRYPOINT,concurrency_limit=1)
	async def handle_perspective_refresh_sweep(job:Job)->_A:
		A=True;payload=PerspectiveRefreshSweepPayload.model_validate_json(job.payload.decode('utf-8'));env=payload.environment;since_ts_ms=payload.since_ts_ms;dispatch_error:Exception|_A=_A;semaphore=asyncio.Semaphore(SWEEP_SUBMIT_CONCURRENCY);env_ctx=_A
		async def _submit_one(perspective:t.Any)->t.Any:
			async with semaphore:return await submit_perspective_refresh(perspective,env_ctx,query_state,qm_enqueue)
		try:
			env_ctx=manager.get_env_context(env);PAGE_SIZE=100;offset=0;total_refreshed=0
			while A:
				perspectives,has_more=await query_state.list_perspectives_to_refresh(since_ts_ms,limit=PAGE_SIZE,offset=offset)
				if not perspectives:logger.info('perspective_refresh_sweep: no perspectives to refresh (env=%s, since_ts_ms=%d, offset=%d)',env,since_ts_ms,offset);break
				logger.info('perspective_refresh_sweep: processing %d perspective(s) (env=%s, offset=%d, has_more=%s)',len(perspectives),env,offset,has_more);results=await asyncio.gather(*[_submit_one(p)for p in perspectives],return_exceptions=A);successful=sum(1 for r in results if not isinstance(r,Exception))
				for(perspective,result)in zip(perspectives,results):
					if isinstance(result,Exception):logger.error("perspective_refresh_sweep: failed to refresh '%s': %s",perspective.slug,result,exc_info=A)
				total_refreshed+=successful;logger.info('perspective_refresh_sweep: batch done %d/%d enqueued (env=%s, total=%d)',successful,len(perspectives),env,total_refreshed)
				if not has_more:break
				offset+=PAGE_SIZE
			logger.info('perspective_refresh_sweep: complete %d perspective(s) enqueued (env=%s, since_ts_ms=%d)',total_refreshed,env,since_ts_ms)
		except Exception as exc:dispatch_error=exc
		if dispatch_error is not _A:
			if payload.retry_count<MAX_RETRIES:backoff=_DEFAULT_DELAY*2**payload.retry_count;logger.warning('perspective_refresh_sweep failed (env=%s, retry %d/%d): %s; retrying in %.1fs',env,payload.retry_count+1,MAX_RETRIES,dispatch_error,backoff.total_seconds(),exc_info=dispatch_error);await enqueue_perspective_refresh_sweep(qm_enqueue,environment=env,since_ts_ms=since_ts_ms,retry_count=payload.retry_count+1);return
			logger.error('perspective_refresh_sweep exhausted %d retries (env=%s): %s',MAX_RETRIES,env,dispatch_error,exc_info=dispatch_error)