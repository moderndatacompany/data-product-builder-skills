from __future__ import annotations
_A=None
import contextlib,json,logging
from datetime import timedelta
import asyncpg
from vulcan import Context
from vulcan.core.config.pgq import PGQConfig
from vulcan.core.query import ObjectStoreClient
from api.context import EnvContextManager
from api.state.activity import AsyncActivityState
from api.state.query import AsyncQueryState
from api.worker import EnqueueQueueManager
logger=logging.getLogger(__name__)
async def start_worker(context:Context,qm:EnqueueQueueManager,query_state:AsyncQueryState,activity:AsyncActivityState,object_store:ObjectStoreClient|_A,pgq_config:PGQConfig,manager:EnvContextManager,*,dsn:str|_A=_A,schema:str|_A=_A)->_A:
	from pgqueuer import QueueManager;from pgqueuer.db import AsyncpgDriver;from api.worker.hera.jobs import register_hera_entrypoints;from api.worker.perspective_jobs import register_perspective_entrypoints;from api.worker.query_jobs import register_query_entrypoints;logger.info('Starting background worker...')
	if not dsn or not schema:raise RuntimeError('start_worker requires dsn and schema for dedicated worker connection')
	worker_conn:asyncpg.Connection=await asyncpg.connect(dsn,server_settings={'search_path':schema});await worker_conn.set_type_codec('jsonb',encoder=json.dumps,decoder=json.loads,schema='pg_catalog');channel_name=f"ch_pgqueuer_api_{schema}";qm_worker=QueueManager(AsyncpgDriver(worker_conn),channel=channel_name)
	try:register_query_entrypoints(qm_worker,qm_enqueue=qm,context=context,query_state=query_state,object_store=object_store,pgq_config=pgq_config);register_hera_entrypoints(qm_worker,qm_enqueue=qm,context=context,query_state=query_state,activity=activity,manager=manager);register_perspective_entrypoints(qm_worker,manager,query_state,qm);logger.info('Worker listening on queues: query_execution, hera_sync, perspective_refresh_sweep');await qm_worker.run(batch_size=pgq_config.batch_size,max_concurrent_tasks=pgq_config.max_concurrent_tasks,dequeue_timeout=timedelta(seconds=pgq_config.dequeue_timeout))
	finally:
		with contextlib.suppress(Exception):await worker_conn.close()