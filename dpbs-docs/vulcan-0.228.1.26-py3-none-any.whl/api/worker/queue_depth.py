from __future__ import annotations
import asyncio,logging,typing as t
logger=logging.getLogger(__name__)
async def start_queue_depth_poller(queue_manager:t.Any,interval:int=10)->None:
	from api import prometheus
	while True:
		try:
			eps=list(queue_manager.entrypoint_registry.keys())or['query_execution']
			for ep in eps:
				try:depth=await queue_manager.queries.queued_work([ep])
				except Exception:depth=0
				try:prometheus.registry.on_query_queue_depth(entrypoint=ep,depth=int(depth))
				except Exception:pass
		except Exception as e:logger.debug('Queue depth poll failed: %s',e)
		await asyncio.sleep(interval)