from __future__ import annotations
_A=True
import logging,typing as t,uuid
from fastapi import APIRouter,Depends,HTTPException,Query,Request,Response
from pgqueuer import QueueManager
from schema.auth import SecurityContext
from vulcan.core.query.transpiler import TranspilerClient,get_transpiler_params_from_snapshots
from vulcan.utils.errors import TranspilerError
from api.context import EnvContext
from api.exceptions import QueryExecutionError,SQLTranspilationError
from api.query.submit import submit_sql_via_flow
from api.query.transpile import convert_sql_dialect,get_filtered_request_headers,get_gateway_dialect,prepare_client_sql
from api.urls import parse_gateway_query
from api.schemas.query import QueryType,SqlQueryRequest,StatementAccepted
from api.state import AsyncStateClient
from api.dependencies import get_client_dialect,get_env_context,get_statestore_client,get_queue_manager,get_transpiler,get_user
from api.urls import urls
logger=logging.getLogger(__name__)
router=APIRouter()
@router.post('/semantic/sql',response_model=StatementAccepted,response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A,status_code=202,include_in_schema=False)
async def semantic_sql_for_mysql(request:Request,response:Response,sql_request:SqlQueryRequest,gateway:t.Optional[str]=Depends(parse_gateway_query),disable_post_processing:bool=Query(default=_A),retry_on_recent_failure:bool=Query(default=False),state:AsyncStateClient=Depends(get_statestore_client),ctx:EnvContext=Depends(get_env_context),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user),transpiler:TranspilerClient=Depends(get_transpiler),client_dialect:t.Optional[str]=Depends(get_client_dialect)):
	F='user_id';E='Authorization';D='request_id';C='client_dialect';B='message';A='error';exec_gateway,qv=ctx.resolve_query_gateway(gateway);fixed_sql=prepare_client_sql(sql_request.sql,client_dialect,ctx.metadata);sql_to_transpile=fixed_sql
	if client_dialect:
		target_dialect=get_gateway_dialect(exec_gateway)
		if client_dialect.lower()!=target_dialect:
			try:sql_to_transpile=convert_sql_dialect(fixed_sql,source=client_dialect,target=target_dialect);logger.info('Internal semantic SQL: transpiled %s → %s',client_dialect,target_dialect)
			except SQLTranspilationError as e:logger.error('SQL transpilation failed: %s',e.message);raise HTTPException(400,detail={A:'SQL_TRANSPILATION_ERROR',B:e.message,C:client_dialect,'target_dialect':target_dialect})
	dialect=ctx.get_dialect(exec_gateway);params=get_transpiler_params_from_snapshots(ctx.context,ctx.environment);params[D]=str(uuid.uuid4());auth_headers={E:auth}if(auth:=request.headers.get(E))else None
	try:transpiler_response=await transpiler.transpile(sql_to_transpile,user=user[F],security_context=SecurityContext.from_dict(user['security_context']),disable_post_processing=disable_post_processing,dialect=dialect,schema=params['schema'],tenant_id=params['tenant_id'],request_id=params[D],db_type=params['db_type'],name=params['name'],headers=auth_headers)
	except TranspilerError as e:
		logger.error('Transpiler error: %s',e)
		if e.is_connection_error:raise HTTPException(503,detail={A:'TRANSPILER_UNAVAILABLE',B:'Semantic query service is temporarily unavailable. Please try again.'})
		raise HTTPException(400,detail={A:'SEMANTIC_QUERY_ERROR',B:e.user_message,'hint':'Check your query syntax. Ensure all non-aggregated columns are in GROUP BY clause.'})
	generated_sql=transpiler_response.wrapped_sql_statement;sql_params=transpiler_response.sql_params;logger.info('Executing compiled SQL via statement flow');meta={'query_style':'internal_semantic_sql','semantic_sql':sql_request.model_dump(exclude_none=_A),C:client_dialect,'headers':get_filtered_request_headers(request)}
	try:accepted=await submit_sql_via_flow(sql=generated_sql,params=sql_params,ttl=0,meta=meta,gateway=exec_gateway,qv=qv,qm=qm,query_state=state.query,env_context=ctx,retry_on_recent_failure=retry_on_recent_failure,query_type=QueryType.SEMANTIC_SQL,submitted_by=user[F])
	except QueryExecutionError as e:raise HTTPException(e.status_code,e.detail)
	response.headers['Location']=urls.query_statement_detail(accepted.id);return accepted