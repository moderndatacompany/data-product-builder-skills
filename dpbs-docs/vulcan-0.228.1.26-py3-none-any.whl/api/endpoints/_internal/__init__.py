from fastapi import APIRouter
from api.endpoints._internal import query
router=APIRouter()
router.include_router(query.router,prefix='/query')