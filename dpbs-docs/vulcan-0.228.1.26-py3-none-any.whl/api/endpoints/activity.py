_R='Number of runs to return'
_Q='Filter runs <= this timestamp (Unix seconds)'
_P='Filter runs >= this timestamp (Unix seconds)'
_O='Plan not found'
_N='Plan ID (from the plans list response)'
_M='plan_abc123'
_L='Filter by success (true=successful, false=failed)'
_K='Plans'
_J='desc'
_I='start_ts'
_H='Pagination offset'
_G='my_product.my_model'
_F='Runs'
_E=False
_D='Internal server error'
_C='description'
_B=True
_A=None
import logging,typing as t
from fastapi import APIRouter,Depends,HTTPException,Path,Query,Request
from api.context import EnvContext
from api.schemas.common import Link,Pagination
from api.schemas.activity import GitCommitDetail,ModelLatestRun,ModelRunsResponse,ModelsLatestRunsResponse,Plan,PlanGitDiffLinks,PlanGitDiffResponse,PlanLinks,PlansListResponse,RunDetail,RunLinks,RunsListResponse
from api.exceptions import ApiException
from api.dependencies import get_env_context,get_statestore_client
from api.state import AsyncStateClient
from api.pool import run_blocking_fast
from api.urls import urls
from api.cache import cached,CachePolicy
from vulcan.core.activity import PlanActivity
from vulcan.utils.git import GitClient
logger=logging.getLogger(__name__)
MAX_GIT_DIFF_SIZE=512000
router=APIRouter()
def _build_plan_links(plan_row:PlanActivity)->PlanLinks:return PlanLinks(self_link=Link(href=urls.plan(plan_row.plan_id)),previous=Link(href=urls.plan(plan_row.prev_plan_id))if plan_row.prev_plan_id else _A,commit=Link(href=plan_row.git_commit_url)if plan_row.git_commit_url else _A,git_diff=Link(href=urls.plan_git_diff(plan_row.plan_id)))
def _build_plan_git_diff_links(plan_row:PlanActivity,previous_plan_id:t.Optional[str]=_A)->PlanGitDiffLinks:return PlanGitDiffLinks(self_link=Link(href=urls.plan_git_diff(plan_row.plan_id)),current_plan=Link(href=urls.plan(plan_row.plan_id)),previous_plan=Link(href=urls.plan(previous_plan_id))if previous_plan_id else _A)
def _build_run_links(run_id:str,plan_id:t.Optional[str]=_A)->RunLinks:return RunLinks(self_link=Link(href=urls.run(run_id)),plan=Link(href=urls.plan(plan_id))if plan_id else _A)
@router.get('/plans',summary='List Plans',tags=[_K],response_model=PlansListResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Plans returned successfully'},500:{_C:_D}})
@cached(policy=CachePolicy.PLAN_CHANGE)
async def list_plans(model_names:t.Optional[str]=Query(_A,examples=[_G],description='Comma-separated model names to filter plans that directly affected any of these models'),limit:int=Query(20,ge=1,le=100,description='Number of plans to return'),offset:int=Query(0,ge=0,description=_H),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description='Filter plans >= this timestamp (Unix seconds)'),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description='Filter plans <= this timestamp (Unix seconds)'),success:t.Optional[bool]=Query(_A,description=_L),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->PlansListResponse:
	models=[m.strip()for m in model_names.split(',')if m.strip()]if model_names else _A
	try:plans=await state.activity.list_plans(environment=ctx.environment,model_names=models,limit=limit,offset=offset,start_ts=start_ts,end_ts=end_ts,success=success);plans_with_links=[Plan.from_core(p,_build_plan_links(p))for p in plans];has_more=len(plans)==limit;pagination=Pagination(limit=limit,offset=offset,has_more=has_more,order_by=_I,order_direction=_J);return PlansListResponse(environment=ctx.environment,plans=plans_with_links,total=len(plans_with_links),pagination=pagination)
	except Exception as e:logger.error(f"Error fetching plans: {e}",exc_info=_B);raise ApiException(message=f"Failed to fetch plans: {e}",origin='API -> activity -> list_plans')
@router.get('/plans/{plan_id}',summary='Get Plan Detail',tags=[_K],response_model=Plan,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Plan returned successfully'},404:{_C:_O}})
@cached(policy=CachePolicy.PLAN_CHANGE)
async def get_plan(plan_id:str=Path(...,examples=[_M],description=_N),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A):
	plans=await state.activity.list_plans(plan_id=plan_id);plan_row=plans[0]if plans else _A
	if not plan_row:raise HTTPException(404,f"Plan '{plan_id}' not found")
	return Plan.from_core(plan_row,_build_plan_links(plan_row))
def _collect_git_diff_payload(git_client:GitClient,prev_sha:str,curr_sha:str)->t.Tuple[t.List[GitCommitDetail],t.Optional[str],bool,t.Optional[str]]:
	try:commits=[GitCommitDetail(sha=c.sha,message=c.message,author_name=c.author_name,author_email=c.author_email,authored_at=c.authored_at,commit_url=git_client.commit_url(c.sha))for c in git_client.list_commits(prev_sha,curr_sha)]
	except Exception as exc:return[],_A,_E,str(exc)
	try:git_diff=git_client.diff(prev_sha,curr_sha)
	except Exception as exc:return commits,_A,_E,str(exc)
	truncated=_E
	if len(git_diff)>MAX_GIT_DIFF_SIZE:git_diff=f"{git_diff[:MAX_GIT_DIFF_SIZE]}\n... (truncated)";truncated=_B
	return commits,git_diff,truncated,_A
@router.get('/plans/{plan_id}/git-diff',summary='Get Plan Git Diff',tags=[_K],response_model=PlanGitDiffResponse,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Git diff returned successfully'},404:{_C:_O},500:{_C:_D}})
@cached(policy=CachePolicy.PLAN_CHANGE)
async def get_plan_git_diff(plan_id:str=Path(...,examples=[_M],description=_N),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->PlanGitDiffResponse:
	try:
		plans=await state.activity.list_plans(plan_id=plan_id);current_plan_row=plans[0]if plans else _A
		if not current_plan_row:raise HTTPException(404,f"Plan '{plan_id}' not found")
		previous_plans=[]
		if current_plan_row.plan_seq>1:previous_plans=await state.activity.list_plans(environment=current_plan_row.environment,plan_seq=current_plan_row.plan_seq-1,limit=1)
		previous_plan_row=previous_plans[0]if previous_plans else _A
		if not previous_plan_row:return PlanGitDiffResponse(git_diff=_A,commits=[],message='no previous plan found',links=_build_plan_git_diff_links(current_plan_row))
		git_diff:t.Optional[str]=_A;commits:t.List[GitCommitDetail]=[];message:t.Optional[str]=_A;truncated=_E
		try:
			if not current_plan_row.git_commit_sha or not previous_plan_row.git_commit_sha:message='Git diff unavailable: missing commit SHA'
			else:
				commits,git_diff,truncated,diff_error=await run_blocking_fast(_collect_git_diff_payload,ctx.context.git_client,previous_plan_row.git_commit_sha,current_plan_row.git_commit_sha)
				if diff_error is not _A:logger.error(f"Error generating git diff for plan {plan_id}: {diff_error}");message=f"Git diff unavailable: {diff_error}"
				elif truncated:message='Git diff truncated'
		except Exception as e:logger.error(f"Error generating git diff for plan {plan_id}: {e}",exc_info=_B);message=f"Git diff unavailable: {e}"
		return PlanGitDiffResponse(git_diff=git_diff,commits=commits,message=message,truncated=truncated,links=_build_plan_git_diff_links(current_plan_row,previous_plan_row.plan_id))
	except HTTPException:raise
	except Exception as e:logger.error(f"Error fetching git diff for plan {plan_id}: {e}",exc_info=_B);raise ApiException(message=f"Failed to fetch git diff for plan {plan_id}: {e}",origin='API -> activity -> get_plan_git_diff')
@router.get('/runs',summary='List Runs',tags=[_F],response_model=RunsListResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Runs returned successfully'},500:{_C:_D}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_runs(model_names:t.Optional[str]=Query(_A,examples=[_G],description='Comma-separated model names to filter runs that executed any of these models'),success:t.Optional[bool]=Query(_A,description=_L),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description=_P),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description=_Q),limit:int=Query(20,ge=1,le=100,description=_R),offset:int=Query(0,ge=0,description=_H),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->RunsListResponse:
	models=[m.strip()for m in model_names.split(',')if m.strip()]if model_names else _A
	try:runs=await state.dq.list_runs(environment=ctx.environment,model_names=models,success=success,start_ts=start_ts,end_ts=end_ts,limit=limit,offset=offset);runs_with_links=[RunDetail(**run.model_dump(exclude_none=_B),links=_build_run_links(run.run_id,run.plan_id))for run in runs];has_more=len(runs)==limit;pagination=Pagination(limit=limit,offset=offset,has_more=has_more,order_by=_I,order_direction=_J);return RunsListResponse(environment=ctx.environment,runs=runs_with_links,total=len(runs_with_links),pagination=pagination)
	except Exception as e:logger.error(f"Error fetching runs: {e}",exc_info=_B);raise ApiException(message=f"Failed to fetch runs: {e}",origin='API -> activity -> list_runs')
@router.get('/runs/{run_id}',summary='Get Run Detail',tags=[_F],response_model=RunDetail,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Run returned successfully'},404:{_C:'Run not found'}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_run(run_id:str=Path(...,examples=['run_789'],description='Run ID (from the runs list response)'),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->RunDetail:
	runs=await state.dq.list_runs(run_id=run_id);run_activity_with_checks=runs[0]if runs else _A
	if not run_activity_with_checks:raise HTTPException(404,f"Run '{run_id}' not found")
	return RunDetail(**run_activity_with_checks.model_dump(exclude_none=_B),links=_build_run_links(run_activity_with_checks.run_id,run_activity_with_checks.plan_id))
@router.get('/models/{model_name}/runs',summary='List Model Runs',tags=[_F],response_model=ModelRunsResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Model runs returned successfully'},400:{_C:'Invalid query parameters'},404:{_C:'Model not found'},500:{_C:_D}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_model_runs(model_name:str=Path(...,examples=[_G],description='Fully qualified model name (e.g., my_product.my_model)'),limit:int=Query(20,ge=1,le=100,description=_R),offset:int=Query(0,ge=0,description=_H),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description=_P),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description=_Q),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A):
	model_entry=ctx.require_model_entry(model_name)
	try:runs=await state.dq.list_runs(environment=ctx.environment,model_names=[model_entry.name],limit=limit,offset=offset,start_ts=start_ts,end_ts=end_ts);runs_with_links=[RunDetail(**run.model_dump(exclude_none=_B),links=_build_run_links(run.run_id,run.plan_id))for run in runs];has_more=len(runs)==limit;pagination=Pagination(limit=limit,offset=offset,has_more=has_more,order_by=_I,order_direction=_J);return ModelRunsResponse(model_name=model_entry.name,environment=ctx.environment,runs=runs_with_links,total=len(runs_with_links),pagination=pagination)
	except ValueError as e:raise HTTPException(status_code=400,detail=str(e))
	except Exception as e:logger.error(f"Error fetching model runs: {e}",exc_info=_B);raise ApiException(message=f"Failed to fetch runs for model '{model_name}': {e}",origin='API -> activity -> list_model_runs')
@router.get('/models',summary='List Models (Latest Run)',tags=[_F],response_model=ModelsLatestRunsResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Models returned successfully'},500:{_C:_D}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_models_latest_runs(ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->ModelsLatestRunsResponse:
	all_models=sorted({m.name for m in ctx.metadata.models})
	try:
		latest_map=await state.dq.list_latest_runs_by_model(environment=ctx.environment,model_names=all_models);items:t.List[ModelLatestRun]=[]
		for model_name in all_models:run=latest_map.get(model_name);run_detail=RunDetail(**run.model_dump(exclude_none=_B),links=_build_run_links(run.run_id,run.plan_id))if run else _A;items.append(ModelLatestRun(model_name=model_name,run=run_detail))
		items.sort(key=lambda x:x.model_name);items.sort(key=lambda x:x.run.start_ts if x.run else-1,reverse=_B);return ModelsLatestRunsResponse(environment=ctx.environment,models=items)
	except Exception as e:logger.error(f"Error fetching latest runs by model: {e}",exc_info=_B);raise ApiException(message=f"Failed to fetch latest runs by model: {e}",origin='API -> activity -> list_models_latest_runs')