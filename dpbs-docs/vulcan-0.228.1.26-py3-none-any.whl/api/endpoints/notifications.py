from __future__ import annotations
_C='description'
_B=True
_A=None
import logging,typing as t
from fastapi import APIRouter,Depends,Query,Request
from api.context import EnvContext
from api.schemas.common import Pagination
from api.schemas.notifications import NotificationDetail,NotificationsListResponse
from api.exceptions import ApiException
from api.dependencies import get_env_context,get_statestore_client
from api.state import AsyncStateClient
from vulcan.core.notification import NotificationEvent
logger=logging.getLogger(__name__)
router=APIRouter()
@router.get('',summary='List Notifications',response_model=NotificationsListResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Notifications returned successfully'},500:{_C:'Internal server error'}})
async def list_notifications(run_id:t.Optional[str]=Query(_A,description='Filter by run id (wins over plan_id when both are set)'),plan_id:t.Optional[str]=Query(_A,description='Filter by plan id'),events:t.Optional[t.List[NotificationEvent]]=Query(_A,description='Filter by one or more event names (repeatable query param)'),start_ts:t.Optional[int]=Query(_A,description='Include notifications with created_ts >= this Unix timestamp (seconds)'),end_ts:t.Optional[int]=Query(_A,description='Include notifications with created_ts <= this Unix timestamp (seconds)'),limit:int=Query(50,ge=1,le=100,description='Number of notifications to return'),offset:int=Query(0,ge=0,description='Pagination offset'),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->NotificationsListResponse:
	kwargs:t.Dict[str,t.Any]={'start_ts':start_ts,'end_ts':end_ts,'events':events,'limit':limit,'offset':offset}
	if run_id is not _A:kwargs['run_id']=run_id
	elif plan_id is not _A:kwargs['plan_id']=plan_id
	else:kwargs['environment']=ctx.environment
	try:notifications,has_more=await state.notification.list_notifications(**kwargs);notifications_with_links=[NotificationDetail.from_core(notification)for notification in notifications];pagination=Pagination(limit=limit,offset=offset,has_more=has_more,order_by='created_ts',order_direction='desc');return NotificationsListResponse(environment=ctx.environment,notifications=notifications_with_links,total=len(notifications_with_links),pagination=pagination)
	except Exception as e:logger.error(f"Error fetching notifications: {e}",exc_info=_B);raise ApiException(message=f"Failed to fetch notifications: {e}",origin='API -> notifications -> list_notifications')