from __future__ import annotations
import copy,logging
from fastapi import APIRouter,Depends,HTTPException
from fastapi.responses import JSONResponse
from api.context import EnvContext
from api.dependencies import get_env_context
from api.openapi.examples import postman_catalog_context
from api.urls import postman_base_url
logger=logging.getLogger(__name__)
router=APIRouter()
@router.get('/postman',summary='Download Postman collection',response_class=JSONResponse,include_in_schema=False)
async def download_postman_collection(ctx:EnvContext=Depends(get_env_context)):
	A='vulcan'
	if not ctx.postman_spec:raise HTTPException(status_code=500,detail='Postman collection not available for this environment.')
	try:
		catalog_ctx=postman_catalog_context(ctx);base_url=postman_base_url(tenant=catalog_ctx.tenant,resource=catalog_ctx.product_name);collection=copy.deepcopy(ctx.postman_spec)
		for var in collection.get('variable',[]):
			if var.get('key')=='base_url':var['value']=base_url
	except Exception as exc:logger.exception('Failed to prepare Postman collection');raise HTTPException(status_code=500,detail=f"Postman collection preparation failed: {exc}")from exc
	product=getattr(ctx,'product',A)or A;return JSONResponse(content=collection,headers={'Content-Disposition':f'attachment; filename="vulcan_{product}.postman_collection.json"'})