from __future__ import annotations
_E='Follow state returned successfully'
_D='user_id'
_C='Internal server error'
_B=True
_A='description'
import logging,typing as t
from fastapi import APIRouter,Depends,HTTPException,Query
from api.context import EnvContext
from api.schemas.common import Pagination
from api.schemas.followers import FollowRequest,FollowersListResponse,FollowStatus,FollowerListItem
from api.exceptions import ApiException
from api.dependencies import get_env_context,get_statestore_client,get_user
from api.state import AsyncStateClient
from vulcan.core.follower import Follower,FollowerAnalytics,FollowerGranularity
from vulcan.core.state_sync.db.follower import MAX_ANALYTICS_LIMIT
logger=logging.getLogger(__name__)
router=APIRouter()
@router.post('',summary='Follow This Data Product',response_model=Follower,response_model_exclude_none=_B,responses={200:{_A:_E},500:{_A:_C}})
async def follow(body:FollowRequest=FollowRequest(),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),user:t.Dict[str,t.Any]=Depends(get_user))->Follower:
	user_id=user[_D]
	try:return await state.follower.follow(user_id,metadata=body.metadata)
	except Exception as e:logger.error('Error following data product for %r: %s',user_id,e,exc_info=_B);raise ApiException(message=f"Failed to follow data product: {e}",origin='API -> followers -> follow')
@router.delete('/me',summary='Unfollow This Data Product',response_model=Follower,response_model_exclude_none=_B,responses={200:{_A:'Unfollow state returned successfully'},404:{_A:'User has never followed this product'},500:{_A:_C}})
async def unfollow(ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),user:t.Dict[str,t.Any]=Depends(get_user))->Follower:
	user_id=user[_D]
	try:return await state.follower.unfollow(user_id)
	except ValueError as e:raise HTTPException(status_code=404,detail=str(e))
	except Exception as e:logger.error('Error unfollowing data product for %r: %s',user_id,e,exc_info=_B);raise ApiException(message=f"Failed to unfollow data product: {e}",origin='API -> followers -> unfollow')
@router.get('/me',summary='Get Follow Status',response_model=FollowStatus,response_model_exclude_none=_B,responses={200:{_A:_E},500:{_A:_C}})
async def get_my_follow_status(ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),user:t.Dict[str,t.Any]=Depends(get_user))->FollowStatus:
	user_id=user[_D]
	try:follower=await state.follower.get_follower(user_id)
	except Exception as e:logger.error('Error fetching follow state for %r: %s',user_id,e,exc_info=_B);raise ApiException(message=f"Failed to fetch follow state: {e}",origin='API -> followers -> get_my_follow_status')
	if follower is None:return FollowStatus(is_follower=False,user_id=user_id)
	return FollowStatus(is_follower=follower.active,user_id=follower.user_id,active=follower.active,followed_at=follower.followed_at,metadata=follower.metadata)
@router.get('/analytics',summary='Get Follower Analytics',response_model=FollowerAnalytics,response_model_exclude_none=_B,responses={200:{_A:'Analytics returned successfully'},400:{_A:'Invalid analytics parameters'},500:{_A:_C}})
async def analytics(granularity:t.Optional[FollowerGranularity]=Query(None,description='Bucket size for time series; omit for current active count only'),offset:int=Query(0,ge=0,description='Buckets to skip counting back from the present'),limit:int=Query(30,ge=1,le=MAX_ANALYTICS_LIMIT,description='Number of buckets to return when granularity is set'),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),user:t.Dict[str,t.Any]=Depends(get_user))->FollowerAnalytics:
	del user
	try:return await state.follower.get_follower_analytics(granularity=granularity,limit=limit,offset=offset)
	except ValueError as e:raise HTTPException(status_code=400,detail=str(e))
	except Exception as e:logger.error('Error fetching follower analytics: %s',e,exc_info=_B);raise ApiException(message=f"Failed to fetch follower analytics: {e}",origin='API -> followers -> analytics')
@router.get('',summary='List Active Followers',response_model=FollowersListResponse,responses={200:{_A:'Followers returned successfully'},500:{_A:_C}})
async def list_followers(limit:int=Query(50,ge=1,le=100,description='Number of followers to return'),offset:int=Query(0,ge=0,description='Pagination offset'),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),user:t.Dict[str,t.Any]=Depends(get_user))->FollowersListResponse:
	del user
	try:followers,has_more=await state.follower.list_followers(limit=limit,offset=offset)
	except Exception as e:logger.error('Error listing followers: %s',e,exc_info=_B);raise ApiException(message=f"Failed to list followers: {e}",origin='API -> followers -> list_followers')
	items=[FollowerListItem(user_id=follower.user_id,followed_at=follower.followed_at,metadata=follower.metadata)for follower in followers];return FollowersListResponse(followers=items,total=len(items),pagination=Pagination(limit=limit,offset=offset,has_more=has_more,order_by='followed_at',order_direction='desc'))