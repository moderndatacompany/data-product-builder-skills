from __future__ import annotations
_A=True
import os
from pathlib import Path
from fastapi import APIRouter,Depends,HTTPException,Request
from starlette.status import HTTP_404_NOT_FOUND
from vulcan.core import constants as c
from api.config import Settings,get_settings
from api.dependencies import get_env_context
from api.context import EnvContext
from api.schemas.files import Directory,File
from api.cache import cached,CachePolicy
router=APIRouter()
def validate_path(path:str,settings:Settings,ctx:EnvContext)->str:
	resolved_path=settings.project_path.resolve();full_path=(resolved_path/path).resolve()
	try:full_path.relative_to(resolved_path)
	except ValueError:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail='Path outside project directory')
	ignore_patterns=ctx.context.config.ignore_patterns if ctx.context.config else c.IGNORE_PATTERNS
	if any(full_path.match(pattern)for pattern in ignore_patterns):raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail='Path matches ignore patterns')
	return path
@router.get('',summary='List project files',response_model=Directory,response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
@cached(policy=CachePolicy.PLAN_CHANGE)
def get_files(settings:Settings=Depends(get_settings),ctx:EnvContext=Depends(get_env_context),request:Request=None)->Directory:return _get_directory(settings.project_path,settings,ctx)
@router.get('/{path:path}',summary='Get file contents',response_model=File,response_model_by_alias=_A,response_model_exclude_unset=_A,response_model_exclude_none=_A)
@cached(policy=CachePolicy.PLAN_CHANGE)
def get_file(path:str,settings:Settings=Depends(get_settings),ctx:EnvContext=Depends(get_env_context),request:Request=None)->File:
	validated_path=validate_path(path,settings,ctx)
	try:
		file_path=Path(validated_path);full_path=settings.project_path/file_path
		if full_path.is_dir():raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail='Path is a directory, use GET /files to list directories')
		file=_get_file_with_content(full_path,str(file_path))
	except FileNotFoundError:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail='File not found')
	return file
def _get_directory(path:str|Path,settings:Settings,ctx:EnvContext)->Directory:
	ignore_patterns=ctx.context.config.ignore_patterns if ctx.context.config else c.IGNORE_PATTERNS
	def walk_path(path:str|Path)->tuple[list[Directory],list[File]]:
		A=False;directories=[];files=[]
		with os.scandir(path)as entries:
			for entry in entries:
				entry_path=Path(entry.path)
				if entry.name=='__pycache__'or entry.name.startswith('.')or any(entry_path.match(pattern)for pattern in ignore_patterns):continue
				relative_path=entry_path.relative_to(settings.project_path)
				if entry.is_dir(follow_symlinks=A):_directories,_files=walk_path(entry.path);directories.append(Directory(name=entry.name,path=str(relative_path.as_posix()),directories=_directories,files=_files))
				elif entry.is_file(follow_symlinks=A):files.append(File(name=entry.name,path=str(relative_path.as_posix())))
		return sorted(directories,key=lambda x:x.name),sorted(files,key=lambda x:x.name)
	directories,files=walk_path(path);relative_path=str(Path(path).relative_to(settings.project_path));return Directory(name=os.path.basename(path),path=''if relative_path=='.'else relative_path,directories=directories,files=files)
def _get_file_with_content(file_path:Path,relative_path:str)->File:
	try:content=file_path.read_text(encoding='utf-8')
	except FileNotFoundError:raise
	except Exception:content=None
	return File(name=file_path.name,path=relative_path,content=content)