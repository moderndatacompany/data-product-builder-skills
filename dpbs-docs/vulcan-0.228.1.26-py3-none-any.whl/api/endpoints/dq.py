from __future__ import annotations
_L='Rule not found or has no runs'
_K='Rule runs returned successfully'
_J='Max runs to return'
_I='completeness'
_H='my_product.my_model'
_G='Invalid query parameters'
_F='Filter: rule evaluation start time <= this (Unix seconds)'
_E='Filter: rule evaluation start time >= this (Unix seconds)'
_D='Pagination offset'
_C='description'
_B=True
_A=None
import typing as t
from fastapi import APIRouter,Depends,HTTPException,Path,Query,Request
from api.context import EnvContext
from api.schemas.common import Link,SelfLink
from api.schemas.dq import RuleDef,RuleDefLinks,RuleDetailLinks,RuleDetailResponse,RuleRun,RuleRunLinks,RulesResponse
from api.dependencies import get_env_context,get_statestore_client
from api.state import AsyncStateClient
from api.cache import cached,CachePolicy
from api.urls import urls
from schema.types import DQDimension
from vulcan.core.soda3.spec import CheckRuns,CheckResultWithRunId as CoreCheckRun,ProductQualitySummary
router=APIRouter()
def _extract_run(core_check_run:CoreCheckRun)->RuleRun:return RuleRun(outcome=core_check_run.outcome,outcome_reasons=core_check_run.outcome_reasons,diagnostics=core_check_run.diagnostics,run_id=core_check_run.run_id,start_ts=core_check_run.start_ts,end_ts=core_check_run.end_ts,links=RuleRunLinks(run=Link(href=urls.run(core_check_run.run_id))))
def _rule_runs_to_def(check_runs:CheckRuns)->RuleDef:runs=[_extract_run(run)for run in check_runs.runs];return RuleDef(identity=check_runs.check_identity,name=check_runs.check_name,type=check_runs.check_type,column=check_runs.column_name,dimension=check_runs.dimension,definition=check_runs.definition,model=check_runs.model_name,runs=runs,links=RuleDefLinks(self_link=Link(href=urls.dq_rule_runs(check_runs.check_identity))))
@router.get('',summary='Get Data Quality Summary',response_model=ProductQualitySummary,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Data quality summary returned successfully'},404:{_C:'No data quality data for environment'}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_summary(as_of_ts:t.Optional[int]=Query(_A,description="Unix timestamp in seconds. When set, summary uses each rule's latest outcome with start_ts <= as_of_ts. Omit for the current summary."),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->ProductQualitySummary:
	environment=ctx.environment;summary=await state.dq.get_quality_summary(environment=environment,as_of_ts=as_of_ts)
	if not summary:raise HTTPException(status_code=404,detail=f"No data quality data found for environment '{environment}'")
	return summary
@router.get('/rules',summary='List Data Quality Rules',response_model=RulesResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Data quality rules returned successfully'},422:{_C:_G}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def list_rules(model:t.Optional[str]=Query(_A,examples=[_H],description='Comma-separated model names. Omit for all.'),column:t.Optional[str]=Query(_A,description='Filter by column. Omit for all.'),dimension:t.Optional[DQDimension]=Query(_A,examples=[_I],description='Filter by ODPS data quality dimension. Omit for all.'),runs_per_rule:int=Query(default=10,ge=1,le=100,description='Runs per rule (default 10)'),limit:int=Query(default=100,ge=1,le=1000,description='Max rules to return'),offset:int=Query(default=0,ge=0,description=_D),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description=_E),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description=_F),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->RulesResponse:
	model_names=_A
	if model:model_names=[m.strip()for m in model.split(',')if m.strip()]
	check_runs_list=await state.dq.list_checks(environment=ctx.environment,model_names=model_names,column_name=column,dimension=dimension,runs_per_check=runs_per_rule,limit=limit,offset=offset,start_ts=start_ts,end_ts=end_ts);check_runs_list=check_runs_list or[];rule_defs=[_rule_runs_to_def(cr)for cr in check_runs_list];query_params=[]
	if model:query_params.append(f"model={model}")
	if column:query_params.append(f"column={column}")
	if dimension:query_params.append(f"dimension={dimension}")
	if runs_per_rule!=10:query_params.append(f"runs_per_rule={runs_per_rule}")
	if limit!=100:query_params.append(f"limit={limit}")
	if offset:query_params.append(f"offset={offset}")
	if start_ts is not _A:query_params.append(f"start_ts={start_ts}")
	if end_ts is not _A:query_params.append(f"end_ts={end_ts}")
	query_string='&'.join(query_params)if query_params else'';return RulesResponse(rules=rule_defs,total=len(rule_defs),links=SelfLink(self_link=Link(href=f"{urls.dq_rules()}?{query_string}"if query_string else urls.dq_rules())))
@router.get('/rules/by-name/{model}/{dimension}/{name:path}',summary='Get Rule by Name',response_model=RuleDetailResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:_K},404:{_C:_L},422:{_C:_G}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_rule_by_name(model:str=Path(...,examples=[_H],description='Fully qualified model name (e.g., my_product.my_model)'),dimension:DQDimension=Path(...,examples=[_I],description='Quality dimension (e.g., completeness, accuracy, validity)'),name:str=Path(...,examples=['not_null_id'],description='Check name (supports slashes, e.g., not_null_email)'),limit:int=Query(default=20,ge=1,le=1000,description=_J),offset:int=Query(default=0,ge=0,description=_D),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description=_E),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description=_F),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->RuleDetailResponse:
	check_identity=await state.dq.get_check_identity_by_natural_key(environment=ctx.environment,model_name=model,dimension=dimension,check_name=name)
	if not check_identity:raise HTTPException(status_code=404,detail=f"Rule not found: {model}/{dimension}/{name} for environment '{ctx.environment}'")
	result=await state.dq.list_checks(environment=ctx.environment,check_identity=check_identity,limit=limit,offset=offset,start_ts=start_ts,end_ts=end_ts)
	if not result:raise HTTPException(status_code=404,detail=f"Rule '{name}' has no runs for environment '{ctx.environment}'")
	rule_def=_rule_runs_to_def(result[0]);links=RuleDetailLinks(self_link=Link(href=urls.dq_rule_runs_by_name(model=model,dimension=dimension,name=name,limit=limit if limit!=20 else _A,offset=offset or _A,start_ts=start_ts,end_ts=end_ts)),rules=Link(href=urls.dq_rules()));return RuleDetailResponse(rule=rule_def,links=links)
@router.get('/rules/{identity}',summary='Get Data Quality Rule',response_model=RuleDetailResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:_K},404:{_C:_L},422:{_C:_G}})
@cached(policy=CachePolicy.RUN_CHANGE)
async def get_rule(identity:str=Path(...,examples=['abc123def456'],description='Rule identity hash (from the rules list response)'),limit:int=Query(default=20,ge=1,le=1000,description=_J),offset:int=Query(default=0,ge=0,description=_D),start_ts:t.Optional[int]=Query(_A,examples=[1716076800],description=_E),end_ts:t.Optional[int]=Query(_A,examples=[1716163200],description=_F),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),request:Request=_A)->RuleDetailResponse:
	result=await state.dq.list_checks(environment=ctx.environment,check_identity=identity,limit=limit,offset=offset,start_ts=start_ts,end_ts=end_ts)
	if not result:raise HTTPException(status_code=404,detail=f"Rule '{identity}' not found or has no runs for environment '{ctx.environment}'")
	query_params=[]
	if limit!=20:query_params.append(f"limit={limit}")
	if offset:query_params.append(f"offset={offset}")
	if start_ts is not _A:query_params.append(f"start_ts={start_ts}")
	if end_ts is not _A:query_params.append(f"end_ts={end_ts}")
	query_string='&'.join(query_params)if query_params else'';rule_def=_rule_runs_to_def(result[0]);links=RuleDetailLinks(self_link=Link(href=f"{urls.dq_rule_runs(identity)}?{query_string}"if query_string else urls.dq_rule_runs(identity)),rules=Link(href=urls.dq_rules()));return RuleDetailResponse(rule=rule_def,links=links)