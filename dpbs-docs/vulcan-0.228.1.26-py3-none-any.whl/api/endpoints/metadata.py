_L='Artifact not found'
_K='description'
_J='content'
_I='Exports'
_H='expected_local_path'
_G='Metadata'
_F='application/zip'
_E='plan_id'
_D='environment'
_C='message'
_B='error'
_A=None
import logging,typing as t
from datetime import datetime,timezone
from pathlib import Path
from fastapi import APIRouter,Depends,HTTPException,Request
from fastapi.responses import FileResponse
from pydantic import Field
from starlette.status import HTTP_404_NOT_FOUND
from api.cache import CachePolicy,cached
from api.context import EnvContext
from api.dependencies import get_env_context
from schema import _PydanticModel
from schema.metadata import Metadata
from schema.semantic import SemanticSchema
from vulcan.core import constants as c
from vulcan.utils.date import now,to_datetime
logger=logging.getLogger(__name__)
router=APIRouter()
class ModelLag(_PydanticModel):model:str;as_of:datetime;nominal_prev:t.Optional[datetime]=_A;nominal_next:t.Optional[datetime]=_A;most_recent_run:t.Optional[datetime]=_A;is_pending:bool=False
class MetadataWithModelLag(Metadata):status:t.List[ModelLag]=Field(default_factory=list)
def build_model_lag(ctx:EnvContext)->t.List[ModelLag]:
	if not ctx.metadata.models:return[]
	current_time=now();freshness=ctx.model_freshness_ts;status:t.List[ModelLag]=[]
	for entry in ctx.metadata.models:
		model_name=entry.name;model=ctx.get_model(model_name)
		if not model:continue
		nominal_prev=to_datetime(model.cron_prev(value=current_time));nominal_next=to_datetime(model.cron_next(value=current_time));last_run_ts=freshness.get(model_name);most_recent_run=_A
		if last_run_ts:most_recent_run=datetime.fromtimestamp(last_run_ts/1000,tz=timezone.utc)
		is_pending=nominal_prev is not _A and current_time>=nominal_prev and(most_recent_run is _A or most_recent_run<nominal_prev)
		if model.kind.is_seed:is_pending=False
		status.append(ModelLag(model=model_name,as_of=current_time,nominal_prev=nominal_prev,nominal_next=nominal_next,most_recent_run=most_recent_run,is_pending=is_pending))
	return status
def metadata_with_model_lag(ctx:EnvContext)->MetadataWithModelLag:base=ctx.metadata;return MetadataWithModelLag.model_construct(**{k:getattr(base,k)for k in type(base).model_fields},status=build_model_lag(ctx))
@router.get('',summary='Get Metadata',tags=[_G],response_model=MetadataWithModelLag)
@cached(policy=CachePolicy.PLAN_CHANGE)
async def get_metadata(ctx:EnvContext=Depends(get_env_context),request:Request=_A)->MetadataWithModelLag:return metadata_with_model_lag(ctx)
@router.get('/semantic',summary='Get Semantic Schema',tags=[_G],response_model=SemanticSchema)
@cached(policy=CachePolicy.PLAN_CHANGE)
def get_semantic_schema(ctx:EnvContext=Depends(get_env_context),request:Request=_A)->SemanticSchema:return ctx.semantic_schema
@router.get('/exports/powerbi',summary='Download Power BI Artifact',tags=[_I],responses={200:{_J:{_F:{}}},404:{_K:_L}})
async def download_powerbi_artifact(ctx:EnvContext=Depends(get_env_context),request:Request=_A):
	A='POWERBI_ARTIFACT_NOT_FOUND'
	if ctx.metadata.env!=c.PROD:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_B:A,_C:'Power BI artifacts are only generated for prod.',_D:ctx.environment,_E:ctx.plan_id})
	path_raw=(ctx.export_artifacts.get('powerbi')or{}).get('path')
	if not path_raw:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_B:A,_C:'Power BI artifact path not available on EnvContext.',_D:ctx.environment,_E:ctx.plan_id})
	path=Path(path_raw)
	if path.exists():return FileResponse(path,media_type=_F,filename=path.name)
	raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_B:A,_C:'Power BI artifact not found at EnvContext path.',_H:str(path),_D:ctx.environment,_E:ctx.plan_id})
@router.get('/exports/tableau',summary='Download Tableau Artifact',tags=[_I],responses={200:{_J:{_F:{}}},404:{_K:_L}})
async def download_tableau_artifact(ctx:EnvContext=Depends(get_env_context),request:Request=_A):
	A='TABLEAU_ARTIFACT_NOT_FOUND'
	if ctx.metadata.env!=c.PROD:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_B:A,_C:'Tableau artifacts are only generated for prod.',_D:ctx.environment,_E:ctx.plan_id})
	path_raw=(ctx.export_artifacts.get('tableau')or{}).get('path')
	if not path_raw:raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_B:A,_C:'Tableau artifact path not available on EnvContext.',_D:ctx.environment,_E:ctx.plan_id})
	path=Path(path_raw)
	if path.exists():return FileResponse(path,media_type=_F,filename=path.name)
	raise HTTPException(status_code=HTTP_404_NOT_FOUND,detail={_B:A,_C:'Tableau artifact not found at EnvContext path.',_H:str(path),_D:ctx.environment,_E:ctx.plan_id})