from __future__ import annotations
_N='X-User'
_M='Transpiler unavailable'
_L='Transpiler error'
_K='Location'
_J='headers'
_I='security_context'
_H='Retry even if an identical query failed recently.'
_G='model'
_F='Authorization'
_E='user_id'
_D=False
_C=True
_B=None
_A='description'
import json,logging,time,typing as t
from typing import TYPE_CHECKING
import httpx
if TYPE_CHECKING:0
from urllib.parse import urljoin
from fastapi import APIRouter,Depends,HTTPException,Query,Request,Response,status
from pgqueuer import QueueManager
from api.context import EnvContext
from api.exceptions import QueryExecutionError
from api.query.submit import submit_sql_via_flow
from api.query.transpile import get_filtered_request_headers,transpile_or_http_error
from api.schemas.query import GraphQLRequest,QueryType,RestQueryRequest,SemanticQueryTranspiled,SqlQueryRequest,StatementAccepted,StatementRequest
from api.dependencies import get_env_context,get_graphql_client,get_queue_manager,get_statestore_client,get_transpiler,get_user
from api.state import AsyncStateClient
from api.utils.commons import timestamp_to_iso
from api.urls import parse_gateway_query,parse_transpile_only_query,urls
from schema.auth import SecurityContext
from vulcan.core.query.transpiler import TranspilerClient
from vulcan.utils.errors import VulcanError
logger=logging.getLogger(__name__)
router=APIRouter()
_ACCEPTED_202='Statement accepted for async execution.\n\nPoll `GET /query/statement/{id}` until status is SUCCESS or FAILED, then fetch\nresults via `GET /query/statement/{id}/result` (see **Query Result** endpoints).\n'
_TRANSPILED_200='Semantic query transpiled successfully.\n\nNo statement was created. Use the `sql` field in the response body as the\ncompiled warehouse SQL.\n'
@router.get('/usage-metrics',summary='Get Usage Metrics',tags=['Usage Metrics'],operation_id='get_usage_metrics',responses={200:{_A:'Usage metrics for the requested week'},400:{_A:'Invalid week_start parameter'}})
async def usage_metrics(week_start:str|_B=Query(default=_B,examples=['2025-05-19'],description='Monday of the week in UTC (YYYY-MM-DD). Default: current week.'),state:AsyncStateClient=Depends(get_statestore_client))->dict[str,t.Any]:
	from datetime import datetime,timezone;week_start_dt:datetime|_B
	if week_start is _B:week_start_dt=_B
	else:
		try:week_start_dt=datetime.strptime(week_start,'%Y-%m-%d').replace(tzinfo=timezone.utc)
		except ValueError:raise HTTPException(status_code=400,detail='week_start must be YYYY-MM-DD (e.g. 2025-02-10)')
	try:return await state.query.get_usage_metrics(week_start=week_start_dt)
	except VulcanError as e:raise HTTPException(status_code=501,detail=str(e))
@router.post('/semantic/rest',summary='Submit Semantic REST Query',tags=['Semantic REST'],operation_id='submit_semantic_rest_query',response_model=_B,response_model_by_alias=_C,response_model_exclude_unset=_C,response_model_exclude_none=_C,status_code=202,responses={200:{_A:_TRANSPILED_200,_G:SemanticQueryTranspiled},202:{_A:_ACCEPTED_202,_G:StatementAccepted},400:{_A:'Invalid REST semantic query or SQL generation failed'},502:{_A:_L},503:{_A:_M}})
async def semantic_rest(request:Request,response:Response,rest_request:RestQueryRequest,ctx:EnvContext=Depends(get_env_context),gateway:t.Optional[str]=Depends(parse_gateway_query),disable_post_processing:bool=Query(default=_C,include_in_schema=_D),transpile_only:bool=Depends(parse_transpile_only_query),retry_on_recent_failure:bool=Query(default=_D,examples=[_D],description=_H),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user),transpiler:TranspilerClient=Depends(get_transpiler))->t.Union[SemanticQueryTranspiled,StatementAccepted]:
	exec_gateway,qv=ctx.resolve_query_gateway(gateway);dialect=ctx.get_dialect(exec_gateway);auth_headers={_F:auth}if(auth:=request.headers.get(_F))else _B;transpiler_response=await transpile_or_http_error(rest_request.query,invalid_msg='Invalid REST semantic query',disable_post_processing=disable_post_processing,user=user[_E],security_context=SecurityContext.from_dict(user[_I]),transpiler=transpiler,dialect=dialect,ctx=ctx,auth_headers=auth_headers);generated_sql=transpiler_response.wrapped_sql_statement;sql_params=transpiler_response.sql_params
	if rest_request.graphql_body:query_type=QueryType.SEMANTIC_GRAPHQL;graphql_query=rest_request.graphql_body
	else:query_type=QueryType.SEMANTIC_REST;graphql_query=_B
	if transpile_only:response.status_code=status.HTTP_200_OK;return SemanticQueryTranspiled(sql=generated_sql,params=sql_params,cols_mapping=transpiler_response.alias_mapping or _B,query_type=query_type,meta=rest_request.meta,gateway=exec_gateway,dialect=dialect,transpiled_at=timestamp_to_iso(int(time.time()*1000)))
	logger.info('Executing generated SQL via statement flow');meta={**(rest_request.meta or{}),_J:get_filtered_request_headers(request)}
	try:accepted=await submit_sql_via_flow(sql=generated_sql,params=sql_params,ttl=0,meta=meta,gateway=exec_gateway,qv=qv,qm=qm,query_state=state.query,env_context=ctx,retry_on_recent_failure=retry_on_recent_failure,query_type=query_type,rest_query=rest_request.query,graphql_query=graphql_query,submitted_by=user[_E])
	except QueryExecutionError as e:raise HTTPException(e.status_code,e.detail)
	response.status_code=status.HTTP_202_ACCEPTED;response.headers[_K]=urls.query_statement_detail(accepted.id);return accepted
@router.post('/semantic/sql',summary='Submit Semantic SQL Query',tags=['Semantic SQL'],operation_id='submit_semantic_sql_query',response_model=_B,response_model_by_alias=_C,response_model_exclude_unset=_C,response_model_exclude_none=_C,status_code=202,responses={200:{_A:_TRANSPILED_200,_G:SemanticQueryTranspiled},202:{_A:_ACCEPTED_202,_G:StatementAccepted},400:{_A:'Invalid semantic SQL query or compilation failed'},502:{_A:_L},503:{_A:_M}})
async def semantic_sql(request:Request,response:Response,sql_request:SqlQueryRequest,ctx:EnvContext=Depends(get_env_context),gateway:t.Optional[str]=Depends(parse_gateway_query),disable_post_processing:bool=Query(default=_C,include_in_schema=_D),transpile_only:bool=Depends(parse_transpile_only_query),retry_on_recent_failure:bool=Query(default=_D,examples=[_D],description=_H),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user),transpiler:TranspilerClient=Depends(get_transpiler))->t.Union[SemanticQueryTranspiled,StatementAccepted]:
	exec_gateway,qv=ctx.resolve_query_gateway(gateway);dialect=ctx.get_dialect(exec_gateway);auth_headers={_F:auth}if(auth:=request.headers.get(_F))else _B;transpiler_response=await transpile_or_http_error(sql_request.sql,invalid_msg='Invalid semantic SQL query',disable_post_processing=disable_post_processing,user=user[_E],security_context=SecurityContext.from_dict(user[_I]),transpiler=transpiler,dialect=dialect,ctx=ctx,auth_headers=auth_headers);generated_sql=transpiler_response.wrapped_sql_statement;sql_params=transpiler_response.sql_params
	if transpile_only:response.status_code=status.HTTP_200_OK;return SemanticQueryTranspiled(sql=generated_sql,params=sql_params,cols_mapping=transpiler_response.alias_mapping or _B,query_type=QueryType.SEMANTIC_SQL,meta=sql_request.meta,gateway=exec_gateway,dialect=dialect,transpiled_at=timestamp_to_iso(int(time.time()*1000)))
	logger.info('Executing compiled SQL via statement flow');meta={**(sql_request.meta or{}),_J:get_filtered_request_headers(request)}
	try:accepted=await submit_sql_via_flow(sql=generated_sql,params=sql_params,ttl=0,meta=meta,gateway=exec_gateway,qv=qv,qm=qm,query_state=state.query,env_context=ctx,retry_on_recent_failure=retry_on_recent_failure,query_type=QueryType.SEMANTIC_SQL,semantic_query=sql_request.sql,submitted_by=user[_E])
	except QueryExecutionError as e:raise HTTPException(e.status_code,e.detail)
	response.status_code=status.HTTP_202_ACCEPTED;response.headers[_K]=urls.query_statement_detail(accepted.id);return accepted
@router.api_route('/semantic/graphql',methods=['POST'],summary='Execute Semantic GraphQL Query',tags=['Semantic GraphQL'],operation_id='execute_semantic_graphql',response_class=Response,openapi_extra={'parameters':[{'name':_N,'in':'header','required':_D,_A:'User identity passed to the GraphQL service. Injected automatically from the authenticated user context; clients do not need to set this header.','schema':{'type':'string'}}]},responses={200:{_A:'GraphQL JSON payload returned inline. GraphQL-level errors (invalid fields, resolver failures) appear as an `errors` array in the body rather than as HTTP 4xx responses.'},503:{_A:'The GraphQL service is unreachable (connection error or DNS failure). Body: `{"errors": [{"message": "GraphQL unavailable", "extensions": {"code": "SERVICE_UNAVAILABLE"}}]}`.'},504:{_A:'**Gateway Timeout** — the upstream GraphQL service did not respond within the configured timeout (default **30 s**). The underlying warehouse query is not aborted; resubmitting the same query is safe. See the **Semantic GraphQL** tag for deduplication and retry details.'},500:{_A:'Unexpected internal error processing the GraphQL request.'}})
async def graphql(body:GraphQLRequest,request:Request,ctx:EnvContext=Depends(get_env_context),user:t.Dict[str,t.Any]=Depends(get_user),client:httpx.AsyncClient=Depends(get_graphql_client))->Response:
	E='code';D='extensions';C='message';B='errors';A='application/json';base=ctx.context.config.graphql.base_url;base=base if base.endswith('/')else base+'/';graphql_endpoint=urljoin(base,'graphql')
	try:body_bytes=body.model_dump_json(exclude_none=_C).encode();headers=dict(request.headers);headers.pop('host',_B);headers.pop('accept-encoding',_B);headers['content-length']=str(len(body_bytes));headers[_N]=user[_E];response=await client.request(method=request.method,url=graphql_endpoint,content=body_bytes,headers=headers,params=request.query_params);_SAFE_FORWARD_HEADERS=frozenset({'retry-after'});forwarded_headers={k:v for(k,v)in response.headers.items()if k in _SAFE_FORWARD_HEADERS};return Response(content=response.content,status_code=response.status_code,headers=forwarded_headers,media_type=response.headers.get('content-type',A))
	except httpx.ConnectError as e:logger.error('Failed to connect to GraphQL service at %s: %s',graphql_endpoint,e);error_response={B:[{C:'GraphQL unavailable',D:{E:'SERVICE_UNAVAILABLE'}}]};return Response(content=json.dumps(error_response),status_code=status.HTTP_503_SERVICE_UNAVAILABLE,media_type=A)
	except httpx.TimeoutException as e:logger.error('GraphQL service request timed out: %s',e);error_response={B:[{C:'GraphQL service request timed out',D:{E:'GATEWAY_TIMEOUT'}}]};return Response(content=json.dumps(error_response),status_code=status.HTTP_504_GATEWAY_TIMEOUT,media_type=A)
	except Exception as e:logger.exception('Unexpected error in GraphQL proxy: %s',e);error_response={B:[{C:f"Internal proxy error: {str(e)}",D:{E:'INTERNAL_SERVER_ERROR'}}]};return Response(content=json.dumps(error_response),status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,media_type=A)