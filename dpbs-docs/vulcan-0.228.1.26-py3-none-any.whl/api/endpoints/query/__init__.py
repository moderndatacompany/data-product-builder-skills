from __future__ import annotations
from fastapi import APIRouter
from.metric import router as metric_router
from.query import router as query_router
from.statement import router as statement_router
router=APIRouter()
router.include_router(statement_router)
router.include_router(query_router)
router.include_router(metric_router,prefix='/metric')