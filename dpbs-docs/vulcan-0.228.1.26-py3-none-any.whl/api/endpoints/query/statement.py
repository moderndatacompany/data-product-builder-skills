from __future__ import annotations
_K='user_id'
_J='schema'
_I='Query Result'
_H='Primary request not found'
_G='Statement ID returned from any query submission'
_F='stmt_abc123'
_E='type'
_D='application/json'
_C='description'
_B=True
_A=None
import logging,time,typing as t
from datetime import datetime
from starlette.requests import Request
from fastapi import APIRouter,HTTPException,Path,Query,Header,Depends,Response
from fastapi.responses import RedirectResponse
from vulcan.core.query import ObjectStoreClient
from vulcan.core.query.definitions import QueryStatus,QueryRequest,QueryResult,QueryStrategy
from vulcan.utils.errors import ObjectStoreError
from api.context import EnvContext
from api.dependencies import get_env_context,get_object_store,get_statestore_client
from api.state import AsyncStateClient
from api.utils.commons import timestamp_to_iso
from api.pool import run_blocking_heavy
from api.query.results import apply_filtering,is_request_stale,resolve_format,staleness_headers,to_csv,to_json,to_yaml
from api.query.submit import make_statement_links
from api.schemas.query import CacheInfo,PrimaryReq,StatementDetail,StatementResult
logger=logging.getLogger(__name__)
router=APIRouter()
def _wrap_statement_detail_with_staleness(statement_detail:StatementDetail,ctx:EnvContext)->t.Union[StatementDetail,Response]:
	if statement_detail.status!=QueryStatus.SUCCESS or not statement_detail.completed_at:return statement_detail
	if not statement_detail.depends_on:return statement_detail
	try:completed_dt=datetime.fromisoformat(statement_detail.completed_at.replace('Z','+00:00'));ts_ms=int(completed_dt.timestamp()*1000)
	except(ValueError,AttributeError):return statement_detail
	is_stale=ctx.did_models_change_after(ts=ts_ms,model_names=statement_detail.depends_on)
	if is_stale:logger.info('Result marked as stale: request_id=%s..., depends_on=%s',statement_detail.id[:16],statement_detail.depends_on);return Response(content=statement_detail.model_dump_json(exclude_none=_B,by_alias=_B,exclude_unset=_B),media_type=_D,headers=staleness_headers(is_stale=_B))
	return statement_detail
def _build_statement_detail(req:QueryRequest,result:t.Optional[QueryResult]=_A,primary_req:t.Optional[QueryRequest]=_A)->StatementDetail:
	current_ts=time.time();primary_info:t.Optional[PrimaryReq]=_A;cache_info:t.Optional[CacheInfo]=_A
	if req.strategy==QueryStrategy.REUSE_RESULT:status=QueryStatus.SUCCESS;has_result=bool(req.result_id);cached_at_seconds=req.cached_at_ts/1e3;cache_info=CacheInfo(cached_at=timestamp_to_iso(req.cached_at_ts),age_seconds=int(current_ts-cached_at_seconds))
	elif req.strategy==QueryStrategy.AWAIT_PRIMARY:
		if not primary_req:raise ValueError('primary_req required for await_primary strategy')
		status=primary_req.execution_status;has_result=status==QueryStatus.SUCCESS;primary_info=PrimaryReq(request_id=primary_req.request_id,status=primary_req.execution_status,submitted_at=timestamp_to_iso(primary_req.submitted_ts),submitted_by=primary_req.submitted_by,started_at=timestamp_to_iso(primary_req.execution_start_ts)if primary_req.execution_start_ts else _A,elapsed_ms=int((current_ts-primary_req.submitted_ts/1e3)*1000))
	else:status=req.execution_status;has_result=status==QueryStatus.SUCCESS
	completed_at_ts=_A
	if result and result.created_ts:completed_at_ts=result.created_ts
	elif req.strategy==QueryStrategy.AWAIT_PRIMARY and primary_req and primary_req.execution_end_ts:completed_at_ts=primary_req.execution_end_ts
	elif req.execution_end_ts:completed_at_ts=req.execution_end_ts
	return StatementDetail(id=req.request_id,status=status,fingerprint=req.fingerprint,depends_on=req.depends_on,sql=req.sql_query,params=req.params,submitted_at=timestamp_to_iso(req.submitted_ts),started_at=timestamp_to_iso(req.execution_start_ts)if req.execution_start_ts else _A,completed_at=timestamp_to_iso(completed_at_ts)if completed_at_ts else _A,queue_wait_ms=req.queue_wait_time_ms,execution_duration_ms=req.execution_duration_ms,row_count=result.row_count if result else _A,size_bytes=result.size_bytes if result else _A,columns=result.columns if result else _A,references={col:[[model,field]for(model,field)in refs]for(col,refs)in result.references.items()}if result and result.references else _A,error=req.error_message,meta=req.meta,query_type=req.query_type,semantic_query=req.semantic_query,rest_query=req.rest_query,graphql_query=req.graphql_query,primary=primary_info,cache=cache_info,links=make_statement_links(request_id=req.request_id,primary_request_id=primary_req.request_id if primary_req else _A,include_result=has_result))
def _elapsed_ms(start:float)->int:return int((time.perf_counter()-start)*1000)
def _log_result_phase(*,statement_id:str,phase:str,elapsed_ms:int,result_id:t.Optional[str]=_A,resolved_format:t.Optional[str]=_A)->_A:logger.debug('statement_result phase=%s statement_id=%s result_id=%s format=%s elapsed_ms=%s',phase,statement_id,result_id,resolved_format,elapsed_ms)
def _classify_object_store_error(*,error:Exception,action:str,result_id:str)->HTTPException:
	message=str(error).lower();is_not_found=isinstance(error,FileNotFoundError)or'not found'in message or'no such file'in message;is_transient=any(token in message for token in('timeout','timed out','connection','temporarily unavailable','throttle','too many requests'))
	if is_not_found:return HTTPException(404,f"Result artifact not found for '{result_id}'")
	if is_transient:return HTTPException(503,f"Object store unavailable while {action}")
	if isinstance(error,ObjectStoreError):return HTTPException(502,f"Object store error while {action}")
	return HTTPException(500,f"Failed to {action}")
@router.get('/statement/{id}',summary='Get Statement Status',tags=[_I],operation_id='get_statement',response_model=StatementDetail,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_C:'Statement metadata and current status'},404:{_C:'Statement not found'}})
async def get_statement(id:str=Path(...,examples=[_F],description=_G),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client)):
	statement_ctx=await state.query.get_statement_context(id)
	if not statement_ctx:raise HTTPException(404,f"Statement {id} not found")
	stmt_req=statement_ctx.request;primary_req=statement_ctx.primary_request;result=statement_ctx.result
	if stmt_req.strategy==QueryStrategy.AWAIT_PRIMARY:
		if not primary_req:raise HTTPException(500,_H)
		statement_detail=_build_statement_detail(stmt_req,result=result,primary_req=primary_req)
	elif stmt_req.strategy==QueryStrategy.REUSE_RESULT:statement_detail=_build_statement_detail(stmt_req,result)
	else:statement_detail=_build_statement_detail(stmt_req,result)
	return _wrap_statement_detail_with_staleness(statement_detail,ctx)
@router.get('/statement/{id}/result',summary='Get Statement Result',tags=[_I],operation_id='get_statement_result',response_model=StatementResult,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={307:{_C:'Redirect to presigned Parquet URL (format=parquet)','headers':{'Location':{_J:{_E:'string'}}}},200:{_C:'Result in requested text format (json/yaml/csv)','content':{_D:{_J:StatementResult.model_json_schema(),'examples':{'json_result':{'summary':'JSON result with cols/rows/types','value':{'cols':[_K,'email'],'rows':[[1,'alice@example.com'],[2,'bob@example.com']],'types':[{'name':_K,_E:'INT'},{'name':'email',_E:'VARCHAR'}],'row_count':2,'_links':{'self':{'href':'/api/v1/query/statement/stmt_abc123/result'}}}}}}}},400:{_C:'Invalid columns requested'},404:{_C:'Result not available'},406:{_C:'Unsupported format'}})
async def get_statement_result(request:Request,id:str=Path(...,examples=[_F],description=_G),format:t.Optional[str]=Query(default=_A,examples=['json'],description="Response format: 'parquet' (default), 'json', 'yaml', or 'csv'"),limit:t.Optional[int]=Query(default=_A,ge=0,examples=[100],description='Max rows to return (text formats only)'),offset:t.Optional[int]=Query(default=0,ge=0,examples=[0],description='Skip first N rows (text formats only)'),columns:t.Optional[str]=Query(default=_A,examples=['col1,col2'],description='Comma-separated column names (text formats only)'),accept:str=Header(default='application/octet-stream'),ctx:EnvContext=Depends(get_env_context),object_store:ObjectStoreClient=Depends(get_object_store),state:AsyncStateClient=Depends(get_statestore_client)):
	A='request_id';phase_start=time.perf_counter();statement_ctx=await state.query.get_statement_context(id);_log_result_phase(statement_id=id,phase='request_lookup',elapsed_ms=_elapsed_ms(phase_start))
	if not statement_ctx:raise HTTPException(404,f"Statement {id} not found")
	stmt_req=statement_ctx.request;primary_req=statement_ctx.primary_request;result=statement_ctx.result;result_id:t.Optional[str]=_A;phase_start=time.perf_counter()
	if stmt_req.strategy==QueryStrategy.AWAIT_PRIMARY:
		if not primary_req:raise HTTPException(500,_H)
		if primary_req.execution_status!=QueryStatus.SUCCESS or not primary_req.result_id:raise HTTPException(404,f"Result not available. Primary status: {primary_req.execution_status}")
		result_id=primary_req.result_id
	elif stmt_req.strategy==QueryStrategy.REUSE_RESULT:
		if not stmt_req.result_id:raise HTTPException(500,'Cache result not found')
		result_id=stmt_req.result_id
	else:
		if stmt_req.execution_status!=QueryStatus.SUCCESS or not stmt_req.result_id:raise HTTPException(404,f"Result not available. Statement status: {stmt_req.execution_status}")
		result_id=stmt_req.result_id
	_log_result_phase(statement_id=id,phase='strategy_resolution',elapsed_ms=_elapsed_ms(phase_start),result_id=result_id);phase_start=time.perf_counter()
	if result is _A or result.result_id!=result_id:result=await state.query.get_result_by_id(result_id)
	_log_result_phase(statement_id=id,phase='result_metadata_lookup',elapsed_ms=_elapsed_ms(phase_start),result_id=result_id)
	if not result:raise HTTPException(404,'Result metadata not found')
	request_id_for_staleness=stmt_req.request_id
	if stmt_req.strategy==QueryStrategy.AWAIT_PRIMARY:request_id_for_staleness=stmt_req.primary_request_id
	phase_start=time.perf_counter();is_stale,_=await is_request_stale(request_id=request_id_for_staleness,query_state=state.query,env_context=ctx);_log_result_phase(statement_id=id,phase='staleness_check',elapsed_ms=_elapsed_ms(phase_start),result_id=result.result_id);resolved_format=resolve_format(format,accept)
	if resolved_format=='parquet':
		if limit or offset or columns:logger.warning('Filtering params ignored for Parquet format: limit=%s, offset=%s, columns=%s',limit,offset,columns,extra={A:id})
		phase_start=time.perf_counter()
		try:presigned_url=await run_blocking_heavy(object_store.generate_presigned_url,result_id=result.result_id,expiry_mins=60);_log_result_phase(statement_id=id,phase='presigned_url_generation',elapsed_ms=_elapsed_ms(phase_start),result_id=result.result_id,resolved_format=resolved_format)
		except Exception as e:http_error=_classify_object_store_error(error=e,action='generate presigned URL',result_id=result.result_id);logger.warning('Presigned URL generation failed: statement_id=%s result_id=%s status=%s error=%s',id,result.result_id,http_error.status_code,e,exc_info=http_error.status_code>=500);raise http_error
		return RedirectResponse(url=presigned_url,status_code=307,headers=staleness_headers(is_stale=is_stale))
	phase_start=time.perf_counter()
	try:df=await run_blocking_heavy(object_store.get_result,result_id);_log_result_phase(statement_id=id,phase='result_fetch',elapsed_ms=_elapsed_ms(phase_start),result_id=result.result_id,resolved_format=resolved_format)
	except Exception as e:http_error=_classify_object_store_error(error=e,action='read result from object store',result_id=result.result_id);logger.warning('Result fetch failed: statement_id=%s result_id=%s status=%s error=%s',id,result.result_id,http_error.status_code,e,exc_info=http_error.status_code>=500);raise http_error
	phase_start=time.perf_counter();filtered_df=await run_blocking_heavy(apply_filtering,df,limit,offset,columns,result.columns);_log_result_phase(statement_id=id,phase='filtering',elapsed_ms=_elapsed_ms(phase_start),result_id=result.result_id,resolved_format=resolved_format)
	if limit or offset or columns:logger.debug('Applied filters to %s result: limit=%s, offset=%s, columns=%s, original_rows=%s, filtered_rows=%s',resolved_format,limit,offset,columns,len(df),len(filtered_df),extra={A:id})
	phase_start=time.perf_counter()
	if resolved_format=='json':
		result_body=await run_blocking_heavy(to_json,filtered_df,result.columns,statement_id=id);_log_result_phase(statement_id=id,phase='serialize_json',elapsed_ms=_elapsed_ms(phase_start),result_id=result.result_id,resolved_format=resolved_format)
		if is_stale:return Response(content=result_body.model_dump_json(exclude_none=_B,by_alias=_B),media_type=_D,headers=staleness_headers(is_stale=_B))
		return result_body
	if resolved_format=='yaml':response=await run_blocking_heavy(to_yaml,filtered_df,is_stale=is_stale);_log_result_phase(statement_id=id,phase='serialize_yaml',elapsed_ms=_elapsed_ms(phase_start),result_id=result.result_id,resolved_format=resolved_format);return response
	if resolved_format=='csv':response=await run_blocking_heavy(to_csv,filtered_df,is_stale=is_stale);_log_result_phase(statement_id=id,phase='serialize_csv',elapsed_ms=_elapsed_ms(phase_start),result_id=result.result_id,resolved_format=resolved_format);return response
	raise HTTPException(500,f"Unexpected format: {resolved_format}")