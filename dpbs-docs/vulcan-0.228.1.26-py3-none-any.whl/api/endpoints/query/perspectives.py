from __future__ import annotations
_c='Perspective not found'
_b='Force refresh perspective (triggers refresh even if not stale or auto_refresh disabled)'
_a='User is not the owner'
_Z='Request body validation error'
_Y='default'
_X='summary'
_W='X-Perspective-Name'
_V='X-Perspective-Owner'
_U='X-Perspective-Id'
_T='Refresh request ID (present if refresh was triggered)'
_S='Query parameter validation error'
_R='Statement not found'
_Q='is_public'
_P='auto_refresh'
_O='name'
_N='Access denied'
_M='headers'
_L='/{slug}'
_K='X-Refresh-Statement-Id'
_J='Perspective slug (URL-friendly identifier)'
_I='my-perspective'
_H='user_id'
_G=False
_F='string'
_E='type'
_D='schema'
_C=None
_B=True
_A='description'
import asyncio,logging,re,time,typing as t
from typing import Annotated
from fastapi import APIRouter,Body,HTTPException,Path,Response,Query,Depends,Header
from fastapi.responses import JSONResponse
from pgqueuer import QueueManager
from starlette.requests import Request
from vulcan.core.query import ObjectStoreClient
from vulcan.core import constants as c
from vulcan.core.query.definitions import QueryStatus,Perspective,QueryRequest,QueryStrategy
from vulcan.utils import random_id
from api.context import EnvContext
from api.schemas.common import Link,Pagination
from api.schemas.query import PerspectiveCreateRequest,PerspectiveDetailView,PerspectiveLinks,PerspectiveListView,PerspectiveUpdateRequest,PerspectivesListResponse
from api.state import AsyncStateClient
from api.state.query import AsyncQueryState
from api.utils.commons import timestamp_to_iso
from api.query.results import is_request_stale
from api.query.submit import submit_perspective_refresh_by_id
from api.endpoints.query.statement import get_statement_result
from api.dependencies import get_env_context,get_object_store,get_statestore_client,get_queue_manager,get_user
from api.urls import urls
logger=logging.getLogger(__name__)
async def _fire_hera_perspective_delete(qm:QueueManager,slug:str,environment:str)->_C:
	try:from api.worker.hera.jobs import enqueue_hera_perspective_delete;await enqueue_hera_perspective_delete(qm,environment,slug)
	except Exception as exc:logger.warning('Hera perspective delete failed (slug=%s): %s',slug,exc)
router=APIRouter()
def _slugify(name:str)->str:slug=name.lower();slug=re.sub('[^a-z0-9]+','-',slug);slug=re.sub('^-+|-+$','',slug);slug=slug[:100];return slug or'perspective'
def _generate_slug_suggestions(base_slug:str,user_id:str)->t.List[str]:return[f"{base_slug}-{user_id[:8]}",f"{base_slug}-{random_id()[:8]}",f"{base_slug}-{int(time.time())}"]
def _make_perspective_links(slug:str,request_id:str,refresh_request_id:t.Optional[str]=_C)->PerspectiveLinks:
	links=PerspectiveLinks(self=Link(href=urls.perspective_detail(slug)),statement_detail=Link(href=urls.query_statement_detail(request_id)),result=Link(href=urls.perspective_result(slug)))
	if refresh_request_id:links.refresh_statement=Link(href=urls.query_statement_detail(refresh_request_id))
	return links
def _can_access_perspective(user_id:str,perspective:Perspective)->bool:
	if perspective.is_public:return _B
	if perspective.owner==user_id:return _B
	allowed_user_ids=perspective.allowed_user_ids or[]
	if user_id in allowed_user_ids:return _B
	return _G
async def _validate_and_resolve_result_id(statement_id:str,query_state:AsyncQueryState)->str:
	statement_ctx=await query_state.get_statement_context(statement_id)
	if not statement_ctx:raise HTTPException(status_code=404,detail=f"Statement '{statement_id}' not found")
	query_request=statement_ctx.request;primary_req=statement_ctx.primary_request
	if query_request.strategy==QueryStrategy.REUSE_RESULT:
		if not query_request.result_id:raise HTTPException(status_code=400,detail='Cache result not found')
		return query_request.result_id
	if query_request.strategy==QueryStrategy.AWAIT_PRIMARY:
		if not query_request.primary_request_id:raise HTTPException(status_code=400,detail='Primary request ID not found')
		if not primary_req:raise HTTPException(status_code=404,detail=f"Primary request '{query_request.primary_request_id}' not found")
		if primary_req.execution_status!=QueryStatus.SUCCESS:raise HTTPException(status_code=400,detail=f"Primary statement must be SUCCESS (current: {primary_req.execution_status})")
		if not primary_req.result_id:raise HTTPException(status_code=400,detail='Primary statement has no result')
		return primary_req.result_id
	if query_request.execution_status!=QueryStatus.SUCCESS:raise HTTPException(status_code=400,detail=f"Statement must be SUCCESS (current: {query_request.execution_status})")
	if not query_request.result_id:raise HTTPException(status_code=400,detail='Statement has no result')
	return query_request.result_id
async def _trigger_auto_refresh_if_needed(perspective:Perspective,query_state:AsyncQueryState,env_context:EnvContext,qm:QueueManager,force_refresh:bool=_G)->t.Optional[QueryRequest]:
	if not perspective.request_id:return
	is_stale,query_request=await is_request_stale(request_id=perspective.request_id,query_state=query_state,env_context=env_context)
	if not query_request:return
	should_refresh=is_stale and perspective.auto_refresh or force_refresh
	if should_refresh:accepted=await submit_perspective_refresh_by_id(perspective_id=perspective.perspective_id,env_context=env_context,query_state=query_state,qm=qm);return await query_state.get_request_by_id(accepted.id)
@router.head(_L,summary='Check Slug Availability',operation_id='check_perspective_availability',responses={200:{_A:'Slug exists (perspective metadata in X-Perspective-* headers)',_M:{_U:{_D:{_E:_F},_A:'Perspective ID'},_V:{_D:{_E:_F},_A:'Owner user ID'},_W:{_D:{_E:_F},_A:'Perspective name'}}},404:{_A:'Slug is available (not taken)'},422:{_A:'Slug format validation error'}})
async def check_perspective_availability(slug:str=Path(...,examples=[_I],description=_J),state:AsyncStateClient=Depends(get_statestore_client))->Response:
	perspective=await state.query.get_perspective_by_slug(slug)
	if perspective:return Response(status_code=200,headers={_U:perspective.perspective_id,_V:perspective.owner,_W:perspective.name})
	return Response(status_code=404)
@router.post('',summary='Create Perspective',operation_id='create_perspective',status_code=201,responses={201:{_A:'Perspective created successfully'},400:{_A:'Statement has no result or invalid status'},404:{_A:_R},409:{_A:'Slug already taken (includes alternative suggestions)'},422:{_A:_Z}})
async def create_perspective(body:Annotated[PerspectiveCreateRequest,Body(openapi_examples={'new_perspective':{_X:'Save a successful statement as a perspective','value':{_O:'<perspective_name>','statement_id':'{{statement_id}}','slug':'<url-friendly-slug>',_P:_B,_Q:_G}}})],ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user)):
	current_user_id=user[_H];slug=body.slug or _slugify(body.name);existing=await state.query.get_perspective_by_slug(slug)
	if existing:raise HTTPException(status_code=409,detail={'error':'SLUG_CONFLICT','message':f"Slug '{slug}' is already taken",'suggestions':_generate_slug_suggestions(slug,current_user_id)})
	statement=await state.query.get_request_by_id(body.statement_id)
	if not statement:raise HTTPException(status_code=404,detail=_R)
	await _validate_and_resolve_result_id(body.statement_id,state.query);sql_query=statement.sql_query;normalized_sql=statement.normalized_sql;params=statement.params;gateway=statement.gateway or _Y;ttl=statement.ttl;meta=statement.meta;query_type=statement.query_type;semantic_query=statement.semantic_query;rest_query=statement.rest_query;graphql_query=statement.graphql_query;depends_on=statement.depends_on;fingerprint=statement.fingerprint;perspective_id=random_id();await state.query.create_perspective(perspective_id=perspective_id,slug=slug,request_id=body.statement_id,fingerprint=fingerprint,sql_query=sql_query,normalized_sql=normalized_sql,params=params,gateway=gateway,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,depends_on=depends_on,name=body.name,description=body.description,tags=body.tags,terms=body.terms,owner=current_user_id,auto_refresh=body.auto_refresh,is_public=body.is_public,allowed_user_ids=body.allowed_user_ids if not body.is_public else[],created_by=current_user_id);await submit_perspective_refresh_by_id(perspective_id=perspective_id,env_context=ctx,query_state=state.query,qm=qm);return Response(status_code=201)
@router.put(_L,summary='Update Perspective',operation_id='update_perspective',status_code=201,responses={201:{_A:'Perspective updated successfully'},400:{_A:'New statement_id has no result or invalid status'},403:{_A:_a},404:{_A:'Perspective not found or statement not found'},422:{_A:_Z}})
async def update_perspective(slug:str=Path(...,examples=[_I],description=_J),body:Annotated[PerspectiveUpdateRequest,Body(openapi_examples={'update_metadata':{_X:'Update perspective metadata','value':{_O:'<updated_name>',_P:_B,_Q:_G}}})]=...,ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user)):
	A='allowed_user_ids';current_user_id=user[_H];perspective=await state.query.get_perspective_by_slug(slug)
	if not perspective:raise HTTPException(status_code=404,detail=f"Perspective '{slug}' not found")
	if perspective.owner!=current_user_id:raise HTTPException(status_code=403,detail='Only owner can update perspective')
	if body.statement_id:
		statement=await state.query.get_request_by_id(body.statement_id)
		if not statement:raise HTTPException(status_code=404,detail=_R)
		await _validate_and_resolve_result_id(body.statement_id,state.query);sql_query=statement.sql_query;normalized_sql=statement.normalized_sql;params=statement.params;gateway=statement.gateway or _Y;ttl=statement.ttl;meta=statement.meta;query_type=statement.query_type;semantic_query=statement.semantic_query;rest_query=statement.rest_query;graphql_query=statement.graphql_query;depends_on=statement.depends_on;fingerprint=statement.fingerprint;await state.query.update_perspective(perspective_id=perspective.perspective_id,fingerprint=fingerprint,sql_query=sql_query,normalized_sql=normalized_sql,params=params,gateway=gateway,ttl=ttl,meta=meta,query_type=query_type,semantic_query=semantic_query,rest_query=rest_query,graphql_query=graphql_query,depends_on=depends_on,updated_by=current_user_id);await submit_perspective_refresh_by_id(perspective_id=perspective.perspective_id,env_context=ctx,query_state=state.query,qm=qm)
	update_kwargs={}
	if body.name is not _C:update_kwargs[_O]=body.name
	if body.description is not _C:update_kwargs[_A]=body.description
	if body.tags is not _C:update_kwargs['tags']=body.tags
	if body.terms is not _C:update_kwargs['terms']=body.terms
	if body.auto_refresh is not _C:update_kwargs[_P]=body.auto_refresh
	if body.is_public is not _C:
		update_kwargs[_Q]=body.is_public
		if body.is_public and body.allowed_user_ids is not _C:update_kwargs[A]=[]
		elif body.allowed_user_ids is not _C:update_kwargs[A]=body.allowed_user_ids
	if update_kwargs:await state.query.update_perspective(perspective_id=perspective.perspective_id,updated_by=current_user_id,**update_kwargs)
	return Response(status_code=201)
@router.get('',summary='List Perspectives',operation_id='list_perspectives',response_model=PerspectivesListResponse,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_A:'Paginated list of accessible perspectives'},422:{_A:_S}})
async def list_perspectives(is_public:t.Optional[bool]=Query(default=_C,description='Filter by public/private'),limit:int=Query(default=50,ge=1,le=100,description='Maximum number of results'),offset:int=Query(default=0,ge=0,description='Offset for pagination'),state:AsyncStateClient=Depends(get_statestore_client),user:t.Dict[str,t.Any]=Depends(get_user)):
	current_user_id=user[_H];perspectives,has_more=await state.query.list_perspectives(current_user_id=current_user_id,is_public=is_public,limit=limit,offset=offset);items=[]
	for p in perspectives:items.append(PerspectiveListView.from_perspective(perspective=p,links=_make_perspective_links(slug=p.slug,request_id=p.request_id or'')))
	pagination=Pagination(limit=limit,offset=offset,has_more=has_more,order_by='updated_at',order_direction='desc');return PerspectivesListResponse(items=items,pagination=pagination)
@router.get(_L,summary='Get Perspective Detail',operation_id='get_perspective',response_model=PerspectiveDetailView,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_A:'Perspective details with HATEOAS links',_M:{_K:{_D:{_E:_F},_A:_T}}},403:{_A:_N},404:{_A:_c},422:{_A:_S}})
async def get_perspective(slug:str=Path(...,examples=[_I],description=_J),refresh:bool=Query(default=_G,description=_b),state:AsyncStateClient=Depends(get_statestore_client),env_context:EnvContext=Depends(get_env_context),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user)):
	current_user_id=user[_H];perspective=await state.query.get_perspective_by_slug(slug)
	if not perspective:raise HTTPException(status_code=404,detail=f"Perspective '{slug}' not found")
	if not _can_access_perspective(current_user_id,perspective):raise HTTPException(status_code=403,detail=_N)
	refresh_query_request=await _trigger_auto_refresh_if_needed(perspective=perspective,query_state=state.query,env_context=env_context,qm=qm,force_refresh=refresh);refresh_request_id=_C
	if refresh_query_request:refresh_request_id=refresh_query_request.request_id
	response_data=PerspectiveDetailView(id=perspective.perspective_id,slug=perspective.slug,name=perspective.name,description=perspective.description,tags=perspective.tags or[],terms=perspective.terms or[],owner=perspective.owner,request_id=perspective.request_id,auto_refresh=perspective.auto_refresh,is_public=perspective.is_public,allowed_user_ids=perspective.allowed_user_ids or[],created_at=timestamp_to_iso(perspective.created_at),updated_at=timestamp_to_iso(perspective.updated_at),created_by=perspective.created_by,updated_by=perspective.updated_by,sql_query=perspective.sql_query,normalized_sql=perspective.normalized_sql,params=perspective.params,depends_on=perspective.depends_on,gateway=perspective.gateway,query_type=perspective.query_type,semantic_query=perspective.semantic_query,rest_query=perspective.rest_query,graphql_query=perspective.graphql_query,meta=perspective.meta,links=_make_perspective_links(slug=perspective.slug,request_id=perspective.request_id,refresh_request_id=refresh_request_id));headers={}
	if refresh_request_id:headers[_K]=refresh_request_id
	return JSONResponse(content=response_data.model_dump(by_alias=_B,exclude_unset=_B,exclude_none=_B),headers=headers)
@router.get('/{slug}/result',summary='Get Perspective Result',operation_id='get_perspective_result',response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={200:{_A:'Result in requested text format (json/yaml/csv)',_M:{_K:{_D:{_E:_F},_A:_T},'Is-Stale':{_D:{_E:_F},_A:"Present if result is stale (value: 'true')"}}},307:{_A:'Redirect to presigned Parquet URL (format=parquet)',_M:{'Location':{_D:{_E:_F},_A:'Presigned URL for Parquet file'},_K:{_D:{_E:_F},_A:_T}}},400:{_A:'Perspective has no request_id or invalid columns requested'},403:{_A:_N},404:{_A:'Perspective not found, statement not found, or result not available'},406:{_A:'Unsupported format'},422:{_A:_S},500:{_A:'Internal server error (e.g., object store access failure)'}})
async def get_perspective_result(request:Request,slug:str=Path(...,examples=[_I],description=_J),refresh:bool=Query(default=_G,description=_b),format:t.Optional[str]=Query(default=_C,examples=['json'],description='Result format: json, yaml, csv, parquet'),limit:t.Optional[int]=Query(default=_C,ge=1,examples=[100],description='Maximum rows to return'),offset:t.Optional[int]=Query(default=_C,ge=0,description='Row offset'),columns:t.Optional[str]=Query(default=_C,examples=['col1,col2'],description='Comma-separated column names'),accept:str=Header(default='application/octet-stream'),state:AsyncStateClient=Depends(get_statestore_client),ctx:EnvContext=Depends(get_env_context),object_store:ObjectStoreClient=Depends(get_object_store),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user)):
	current_user_id=user[_H];perspective=await state.query.get_perspective_by_slug(slug)
	if not perspective:raise HTTPException(status_code=404,detail=f"Perspective '{slug}' not found")
	if not _can_access_perspective(current_user_id,perspective):raise HTTPException(status_code=403,detail=_N)
	if not perspective.request_id:raise HTTPException(status_code=400,detail='Perspective has no request_id')
	refresh_query_request=await _trigger_auto_refresh_if_needed(perspective=perspective,query_state=state.query,env_context=ctx,qm=qm,force_refresh=refresh);result_response=await get_statement_result(id=perspective.request_id,format=format,limit=limit,offset=offset,columns=columns,accept=accept,ctx=ctx,object_store=object_store,state=state,request=request)
	if refresh_query_request:result_response.headers[_K]=refresh_query_request.request_id
	return result_response
@router.delete(_L,summary='Delete Perspective',operation_id='delete_perspective',status_code=204,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,responses={204:{_A:'Perspective deleted successfully'},403:{_A:_a},404:{_A:_c},422:{_A:'Path parameter validation error'}})
async def delete_perspective(slug:str=Path(...,examples=[_I],description=_J),ctx:EnvContext=Depends(get_env_context),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user)):
	current_user_id=user[_H];perspective=await state.query.get_perspective_by_slug(slug)
	if not perspective:raise HTTPException(status_code=404,detail=f"Perspective '{slug}' not found")
	if perspective.owner!=current_user_id:raise HTTPException(status_code=403,detail='Only owner can delete perspective')
	await state.query.delete_perspective(perspective.perspective_id)
	if ctx.environment==c.PROD:asyncio.create_task(_fire_hera_perspective_delete(qm,perspective.slug,ctx.environment))
	return Response(status_code=204)