from __future__ import annotations
_M='Transpiler error'
_L='Metric not found'
_K='Invalid metric query or SQL generation failed'
_J='Statement accepted. Poll `GET /query/statement/{id}`, then `GET /query/statement/{id}/result`.'
_I='Semantic Metrics'
_H='/{metric_name}'
_G='Metric name (from catalog metadata)'
_F='monthly_active_users'
_E='dimension'
_D='UTC'
_C='description'
_B=True
_A=None
from dataclasses import dataclass
import logging,typing as t
from fastapi import APIRouter,Depends,HTTPException,Path,Query,Request,Response
from pgqueuer import QueueManager
from schema.filters import RestFilterExpression
from schema.rest_query import RestQuery
from vulcan.core.query.transpiler import TranspilerClient
from schema.types import MetricGranularityValue
from schema.metadata import ModelEntry as MetadataModelEntry
from schema.auth import SecurityContext
from api.context import EnvContext
from api.state import AsyncStateClient
from api.query.submit import submit_sql_via_flow
from api.query.transpile import get_filtered_request_headers,transpile_or_http_error
from api.urls import parse_gateway_query
from api.schemas.metric import MetricQueryRequest
from api.schemas.query import QueryType,StatementAccepted
from api.dependencies import get_env_context,get_statestore_client,get_queue_manager,get_transpiler,get_user
from api.urls import urls
logger=logging.getLogger(__name__)
router=APIRouter()
@dataclass(frozen=_B,slots=_B)
class MetricQueryPlan:
	metric_name:str;measure_ref:str;time_ref:str;dimension_map:dict[str,str];segments:t.Optional[t.List[str]];default_granularity:MetricGranularityValue
	@classmethod
	def from_metadata(cls,entry:MetadataModelEntry)->'MetricQueryPlan':
		measure_ref:t.Optional[str]=_A;time_ref:t.Optional[str]=_A;dimension_map:dict[str,str]={};segments:t.List[str]=[]
		for col in entry.columns or[]:
			ref=f"{entry.name}.{col.name}"
			if col.name=='measure':measure_ref=ref
			elif col.name=='ts':time_ref=ref
			elif col.kind==_E:dimension_map[col.name]=ref
			elif col.kind=='segment':segments.append(ref)
		if not measure_ref or not time_ref:raise HTTPException(status_code=500,detail=f"Metric '{entry.name}' missing measure/ts in metadata export")
		if entry.default_granularity is _A:raise HTTPException(status_code=500,detail=f"Metric '{entry.name}' missing default_granularity in metadata export")
		return cls(metric_name=entry.name,measure_ref=measure_ref,time_ref=time_ref,dimension_map=dimension_map,segments=segments or _A,default_granularity=entry.default_granularity)
def _metric_from_context(ctx:EnvContext,metric_name:str)->t.Optional[MetadataModelEntry]:return ctx.metrics_by_name.get(metric_name)
def _effective_metric_granularity(metric_default:MetricGranularityValue,requested:t.Optional[MetricGranularityValue])->MetricGranularityValue:return requested if requested is not _A else metric_default
def build_rest_query(plan:MetricQueryPlan,*,granularity:MetricGranularityValue,dimensions:t.Optional[t.List[str]]=_A,filters:t.Optional[t.List[RestFilterExpression]]=_A,timezone:str=_D,timezone_name:t.Optional[str]=_A,limit:int=10000,offset:int=0)->RestQuery:
	if timezone_name is not _A:timezone=timezone_name
	measure=plan.measure_ref;ts=plan.time_ref;alias_map=plan.dimension_map;segments=plan.segments;resolved_dimensions:t.Optional[t.List[str]]=_A
	if dimensions:
		requested=[d.strip()for d in dimensions if isinstance(d,str)and d.strip()];requested=list(dict.fromkeys(requested));available=set(alias_map.keys());unknown=sorted(set(requested)-available)
		if unknown:raise HTTPException(status_code=400,detail=f"Unknown dimension(s) for metric '{plan.metric_name}': {unknown}. Available dimensions: {sorted(available)}")
		resolved_dimensions=[alias_map[d]for d in requested]or _A
	time_dimensions=[{_E:ts,'granularity':granularity}];kwargs:dict[str,t.Any]=dict(measures=[measure],dimensions=resolved_dimensions,segments=segments,timeDimensions=time_dimensions,filters=filters,limit=limit,offset=offset);kwargs['timezone']=timezone;return RestQuery(**kwargs)
async def _transpile_and_submit(*,metric_name:str,rest_query:RestQuery,request:Request,response:Response,ctx:EnvContext,transpiler:TranspilerClient,qv,state:AsyncStateClient,qm:QueueManager,exec_gateway:str,user:t.Dict[str,t.Any])->StatementAccepted:B='user_id';A='Authorization';dialect=ctx.get_dialect(exec_gateway);auth_headers={A:auth}if(auth:=request.headers.get(A))else _A;transpiler_response=await transpile_or_http_error(rest_query,invalid_msg='Invalid metric query',disable_post_processing=_B,user=user.get(B),security_context=SecurityContext.from_dict(user.get('security_context')or{}),transpiler=transpiler,dialect=dialect,ctx=ctx,auth_headers=auth_headers);meta={'metric_name':metric_name,'headers':get_filtered_request_headers(request)};accepted=await submit_sql_via_flow(sql=transpiler_response.wrapped_sql_statement,params=transpiler_response.sql_params,ttl=0,meta=meta,gateway=exec_gateway,qv=qv,qm=qm,query_state=state.query,env_context=ctx,query_type=QueryType.SEMANTIC_METRIC,rest_query=rest_query,submitted_by=user.get(B,''));response.headers['Location']=urls.query_statement_detail(accepted.id);return accepted
@router.get(_H,summary='Submit Metric Query',tags=[_I],response_model=StatementAccepted,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,status_code=202,responses={202:{_C:_J},400:{_C:_K},404:{_C:_L},502:{_C:_M}})
async def get_metric(request:Request,response:Response,metric_name:str=Path(...,examples=[_F],description=_G),dimensions:t.Optional[str]=Query(default=_A,examples=['plan_type'],description='Comma-separated dimension names (aliases defined on the metric)'),granularity:t.Optional[MetricGranularityValue]=Query(default=_A,examples=['month'],description='Time-series granularity (second, minute, hour, day, week, month, quarter, year)'),timezone:t.Optional[str]=Query(default=_A,examples=['America/New_York'],description='Timezone for time dimensions'),limit:int=Query(default=10000,ge=1,le=50000,description='Max rows'),offset:int=Query(default=0,ge=0,description='Rows to skip'),gateway:t.Optional[str]=Depends(parse_gateway_query),ctx:EnvContext=Depends(get_env_context),transpiler:TranspilerClient=Depends(get_transpiler),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user))->StatementAccepted:
	metric=_metric_from_context(ctx,metric_name)
	if not metric:raise HTTPException(status_code=404,detail=f"Metric '{metric_name}' not found")
	plan=MetricQueryPlan.from_metadata(metric);effective_granularity=_effective_metric_granularity(plan.default_granularity,granularity);dimensions_list=[d.strip()for d in dimensions.split(',')if d.strip()]if dimensions else _A;rest_query=build_rest_query(plan,dimensions=dimensions_list,granularity=effective_granularity,timezone=timezone or _D,limit=limit,offset=offset);exec_gateway,qv=ctx.resolve_query_gateway(gateway);return await _transpile_and_submit(metric_name=metric_name,rest_query=rest_query,request=request,response=response,ctx=ctx,transpiler=transpiler,qv=qv,state=state,qm=qm,exec_gateway=exec_gateway,user=user)
@router.post(_H,summary='Submit Metric Query with Filters',tags=[_I],operation_id='submit_metric_query',response_model=StatementAccepted,response_model_by_alias=_B,response_model_exclude_unset=_B,response_model_exclude_none=_B,status_code=202,responses={202:{_C:_J},400:{_C:_K},404:{_C:_L},502:{_C:_M}})
async def post_metric(request:Request,response:Response,metric_name:str=Path(...,examples=[_F],description=_G),body:MetricQueryRequest=...,gateway:t.Optional[str]=Depends(parse_gateway_query),ctx:EnvContext=Depends(get_env_context),transpiler:TranspilerClient=Depends(get_transpiler),state:AsyncStateClient=Depends(get_statestore_client),qm:QueueManager=Depends(get_queue_manager),user:t.Dict[str,t.Any]=Depends(get_user))->StatementAccepted:
	metric=_metric_from_context(ctx,metric_name)
	if not metric:raise HTTPException(status_code=404,detail=f"Metric '{metric_name}' not found")
	plan=MetricQueryPlan.from_metadata(metric);effective_granularity=_effective_metric_granularity(plan.default_granularity,body.granularity);rest_query=build_rest_query(plan,dimensions=body.dimensions,granularity=effective_granularity,filters=body.filters,timezone=body.timezone or _D,limit=body.limit,offset=body.offset);exec_gateway,qv=ctx.resolve_query_gateway(gateway);return await _transpile_and_submit(metric_name=metric_name,rest_query=rest_query,request=request,response=response,ctx=ctx,transpiler=transpiler,qv=qv,state=state,qm=qm,exec_gateway=exec_gateway,user=user)