from __future__ import annotations
_A=None
import logging
from typing import List,Optional
import httpx
from pydantic import BaseModel,Field,ValidationError
from api.utils.commons import parse_optional_positive_int_env,parse_positive_float_env
logger=logging.getLogger(__name__)
class AuthorizeResult(BaseModel):id:str=Field(...,description='User identifier');tags:List[str]=Field(default_factory=list,description='User roles and permissions')
class AuthorizeError(BaseModel):status:int=Field(...,description='Error status code');message:str=Field(...,description='Error message')
class AuthorizeResponse(BaseModel):
	allow:bool=Field(...,description='Whether the operation is allowed');valid:bool=Field(...,description='Whether the token is valid');result:Optional[AuthorizeResult]=Field(_A,description='User identity on success');error:Optional[AuthorizeError]=Field(_A,description='Error details on failure');heimdall_status:Optional[int]=Field(_A,description='HTTP status from Heimdall')
	@property
	def user_id(self)->Optional[str]:return self.result.id if self.result else _A
	@property
	def user_tags(self)->List[str]:return self.result.tags if self.result else[]
	@property
	def error_message(self)->Optional[str]:return self.error.message if self.error else _A
def extract_bearer_token(authorization:str)->str:
	if authorization.lower().startswith('bearer '):return authorization[7:]
	return authorization
class HeimdallException(Exception):
	def __init__(self,*,status_code:int=503,error_code:str='AUTH_SERVICE_UNAVAILABLE',msg:str='Authorization service unavailable',details:dict|_A=_A)->_A:self.status_code=status_code;self.error_code=error_code;self.msg=msg;self.details=details or{};super().__init__(msg)
class HeimdallClient:
	def __init__(self,base_url:str,timeout:float=1e1)->_A:self.base_url=base_url.rstrip('/');self.timeout=timeout;(self._client):Optional[httpx.AsyncClient]=_A
	async def __aenter__(self)->HeimdallClient:max_connections=parse_optional_positive_int_env('VULCAN_HEIMDALL_POOL_MAX',default=_A,floor=10,ceiling=1000);max_keepalive=parse_optional_positive_int_env('VULCAN_HEIMDALL_POOL_KEEPALIVE',default=_A,floor=1,ceiling=500);keepalive_expiry=parse_positive_float_env('VULCAN_HEIMDALL_POOL_KEEPALIVE_EXPIRY_S',default=5.,floor=1.,ceiling=3e2);self._client=httpx.AsyncClient(timeout=httpx.Timeout(self.timeout),limits=httpx.Limits(max_connections=max_connections,max_keepalive_connections=max_keepalive,keepalive_expiry=keepalive_expiry),headers={'Content-Type':'application/json'});return self
	async def __aexit__(self,exc_type,exc_val,exc_tb)->_A:
		if self._client:await self._client.aclose();self._client=_A
	async def authorize(self,authorization:str)->AuthorizeResponse:
		D='exception_type';C='heimdall';B='url';A='service'
		if not self._client:raise RuntimeError('Client not initialized. Use async context manager.')
		token=extract_bearer_token(authorization);url=f"{self.base_url}/api/v1/authorize";payload={'token':token};logger.debug('Authorizing token via Heimdall: %s',url)
		try:
			response=await self._client.post(url,json=payload);auth_response=AuthorizeResponse.model_validate(response.json());auth_response.heimdall_status=response.status_code
			if auth_response.valid and auth_response.allow:logger.debug('Authorization successful for user: %s',auth_response.user_id)
			else:logger.debug('Authorization failed (Heimdall HTTP %d): valid=%s, allow=%s, error=%s',auth_response.heimdall_status,auth_response.valid,auth_response.allow,auth_response.error_message)
			return auth_response
		except httpx.TimeoutException as e:raise HeimdallException(error_code='AUTH_HEIMDALL_TIMEOUT',msg='Authorization service timed out',details={A:C,B:url,'timeout_seconds':self.timeout})from e
		except httpx.RequestError as e:raise HeimdallException(error_code='AUTH_HEIMDALL_REQUEST_ERROR',msg='Authorization service request failed',details={A:C,B:url,D:type(e).__name__})from e
		except ValidationError as e:raise HeimdallException(error_code='AUTH_HEIMDALL_INVALID_RESPONSE',msg='Authorization service returned unexpected response',details={A:C,B:url})from e
		except ValueError as e:raise HeimdallException(error_code='AUTH_HEIMDALL_INVALID_JSON',msg='Authorization service returned invalid JSON',details={A:C,B:url})from e
		except Exception as e:raise HeimdallException(error_code='AUTH_HEIMDALL_ERROR',msg='Authorization service error',details={A:C,B:url,D:type(e).__name__})from e