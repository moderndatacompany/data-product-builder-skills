from __future__ import annotations
_D='message'
_C='code'
_B='error'
_A=None
import logging,sys,traceback,typing as t
from fastapi import FastAPI,HTTPException,Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.status import HTTP_422_UNPROCESSABLE_CONTENT,HTTP_500_INTERNAL_SERVER_ERROR
from vulcan.utils import debug_mode_enabled
from vulcan.utils.date import now_timestamp
from vulcan.utils.errors import TranspilerError
from vulcan.utils.pydantic import PydanticModel
logger=logging.getLogger(__name__)
COMMON_AUTH_MISSING_BEARER='COMMON.AUTH.MISSING_BEARER'
COMMON_AUTH_BEARER_MALFORMED='COMMON.AUTH.BEARER_MALFORMED'
COMMON_AUTH_INVALID_TOKEN='COMMON.AUTH.INVALID_TOKEN'
COMMON_AUTH_CLIENT_HEADERS_NOT_ALLOWED='COMMON.AUTH.CLIENT_HEADERS_NOT_ALLOWED'
COMMON_AUTH_AUTH_BACKEND_UNAVAILABLE='COMMON.AUTH.AUTH_BACKEND_UNAVAILABLE'
COMMON_AUTH_FORBIDDEN='COMMON.AUTH.FORBIDDEN'
COMMON_AUTH_TIMEOUT='COMMON.AUTH.TIMEOUT'
COMMON_AUTH_EXT_HOOK_INVALID_RESPONSE='COMMON.AUTH.EXT_HOOK_INVALID_RESPONSE'
COMMON_AUTH_EXT_HOOK_FAILED='COMMON.AUTH.EXT_HOOK_FAILED'
COMMON_AUTH_HEIMDALL_UNAVAILABLE='COMMON.AUTH.HEIMDALL_UNAVAILABLE'
COMMON_VALIDATION_INVALID='COMMON.VALIDATION.INVALID'
QUERY_EXECUTION_FAILED='QUERY.EXECUTION.FAILED'
API_INVALID_REQUEST='API.REQUEST.INVALID'
API_FORBIDDEN='API.FORBIDDEN'
API_NOT_FOUND='API.NOT.FOUND'
API_VALIDATION_INVALID='API.VALIDATION.INVALID'
API_INTERNAL_ERROR='API.INTERNAL.ERROR'
API_UNEXPECTED_ERROR='API.UNEXPECTED.ERROR'
API_DATA_STRUCTURE_ERROR='API.DATA.STRUCTURE_INVALID'
API_SERIALIZATION_ERROR='API.SERIALIZATION.FAILED'
TRANSPILER_QUERY_INVALID='TRANSPILER.QUERY.INVALID'
TRANSPILER_SERVICE_UNAVAILABLE='TRANSPILER.SERVICE.UNAVAILABLE'
TRANSPILER_UPSTREAM_ERROR='TRANSPILER.UPSTREAM.ERROR'
TRANSPILER_UNKNOWN='TRANSPILER.UNKNOWN'
_DEFAULT_STATUS_CODES:dict[int,str]={400:API_INVALID_REQUEST,403:API_FORBIDDEN,404:API_NOT_FOUND,422:API_VALIDATION_INVALID,500:API_INTERNAL_ERROR,503:API_INTERNAL_ERROR}
def default_error_code(status_code:int)->str:return _DEFAULT_STATUS_CODES.get(status_code,API_UNEXPECTED_ERROR)
def error_envelope(status_code:int,code:str,message:str,*,debug:dict[str,object]|_A=_A)->dict[str,object]:
	body:dict[str,object]={'status':status_code,_B:{_C:code,_D:message}}
	if debug:body['debug']=debug
	return body
def json_error_response(status_code:int,code:str,message:str,*,debug:dict[str,object]|_A=_A)->JSONResponse:return JSONResponse(status_code=status_code,content=error_envelope(status_code,code,message,debug=debug))
class QueryExecutionError(Exception):
	def __init__(self,status_code:int,detail:t.Union[str,t.Dict[str,t.Any]]):self.status_code=status_code;self.detail=detail;super().__init__(str(detail))
class SQLTranspilationError(Exception):
	def __init__(self,message:str,original_error:t.Optional[Exception]=_A):self.message=message;self.original_error=original_error;super().__init__(self.message)
class ApiExceptionPayload(PydanticModel):timestamp:int;message:str;origin:str;status:t.Optional[int]=_A;trigger:t.Optional[str]=_A;type:t.Optional[str]=_A;description:t.Optional[str]=_A;traceback:t.Optional[str]=_A;stack:t.Optional[t.List[str]]=_A
class ApiException(HTTPException):
	def __init__(self,origin:str,message:str,status_code:int=HTTP_422_UNPROCESSABLE_CONTENT,trigger:t.Optional[str]=_A,include_traceback:t.Optional[bool]=_A,code:t.Optional[str]=_A):super().__init__(status_code);error_type,error_value,error_traceback=sys.exc_info();self.message=message;self.timestamp=now_timestamp();self.origin=origin;self.trigger=trigger;self.code=code;self._traceback_str=traceback.format_exc()if error_traceback else _A;self._error_type=str(error_type)if error_type else _A;self._error_value=str(error_value)if error_value else _A;self._stack=traceback.format_tb(error_traceback)if error_traceback else _A;self._include_traceback=include_traceback if include_traceback is not _A else debug_mode_enabled()
	def __str__(self)->str:return f"Summary: {self.message}\n{self._error_value}\n{self._traceback_str}"
	def to_dict(self)->t.Dict[str,t.Union[str,int,t.List[str]]]:
		payload=ApiExceptionPayload(status=self.status_code,timestamp=self.timestamp,message=self.message,origin=self.origin,trigger=self.trigger,type=self._error_type,description=self._error_value)
		if self._include_traceback:payload.traceback=self._traceback_str;payload.stack=self._stack
		return payload.dict()
	def to_error_envelope(self)->t.Dict[str,t.Any]:
		debug:t.Optional[t.Dict[str,t.Any]]=_A
		if self._include_traceback:debug={'origin':self.origin,'trigger':self.trigger,'timestamp':self.timestamp,'type':self._error_type,'description':self._error_value,'traceback':self._traceback_str,'stack':self._stack}
		return error_envelope(self.status_code,self.code or default_error_code(self.status_code),self.message,debug=debug)
def _detail_message(detail:t.Any)->str:
	if isinstance(detail,str):return detail
	if isinstance(detail,dict):
		for key in(_D,'detail',_B):
			value=detail.get(key)
			if isinstance(value,str):return value
		return str(detail)
	if isinstance(detail,list):return'; '.join(_detail_message(item)for item in detail)
	return str(detail)
def _detail_code(detail:t.Any,status_code:int)->str:
	if isinstance(detail,dict):
		code=detail.get(_C)
		if isinstance(code,str):return code
	return default_error_code(status_code)
def _format_validation_errors(exc:RequestValidationError)->str:
	parts:list[str]=[]
	for err in exc.errors():
		loc='.'.join(str(part)for part in err.get('loc',()));msg=err.get('msg','')
		if loc:parts.append(f"{loc}: {msg}")
		else:parts.append(str(msg))
	return'; '.join(parts)or'Validation error'
def register_exception_handlers(app:FastAPI)->_A:
	A=True
	@app.exception_handler(RequestValidationError)
	async def handle_validation_error(request:Request,exc:RequestValidationError)->JSONResponse:message=_format_validation_errors(exc);logger.info('Validation error on %s %s: %s',request.method,request.url.path,message);debug={'errors':exc.errors()}if debug_mode_enabled()else _A;return json_error_response(HTTP_422_UNPROCESSABLE_CONTENT,COMMON_VALIDATION_INVALID,message,debug=debug)
	@app.exception_handler(TranspilerError)
	async def handle_transpiler_error(request:Request,exc:TranspilerError)->JSONResponse:
		logger.error('Transpiler error: %s (code=%d)',str(exc),exc.code);response_data=exc.response_data;transpiler_code:t.Optional[str]=_A
		if isinstance(response_data,dict):
			err=response_data.get(_B)
			if isinstance(err,dict):
				code=err.get(_C)
				if isinstance(code,str):transpiler_code=code
		if 400<=exc.code<500:status,error_code=exc.code,transpiler_code or TRANSPILER_QUERY_INVALID
		elif exc.is_connection_error:status,error_code=503,transpiler_code or TRANSPILER_SERVICE_UNAVAILABLE
		elif 500<=exc.code<600:status,error_code=502,transpiler_code or TRANSPILER_UPSTREAM_ERROR
		else:status,error_code=502,TRANSPILER_UNKNOWN
		return json_error_response(status,error_code,exc.user_message)
	@app.exception_handler(QueryExecutionError)
	async def handle_query_execution_error(request:Request,exc:QueryExecutionError)->JSONResponse:
		logger.error('Query execution error on %s %s: %s',request.method,request.url.path,exc.detail)
		if isinstance(exc.detail,dict):message=_detail_message(exc.detail);code=_detail_code(exc.detail,exc.status_code)
		else:message=str(exc.detail);code=QUERY_EXECUTION_FAILED
		return json_error_response(exc.status_code,code,message)
	@app.exception_handler(ApiException)
	async def handle_api_exception(request:Request,exc:ApiException)->JSONResponse:
		B='API exception: %s (status=%d, origin=%s)'
		if exc.status_code>=500:logger.error(B,exc.message,exc.status_code,exc.origin,exc_info=A)
		else:logger.warning(B,exc.message,exc.status_code,exc.origin)
		return JSONResponse(status_code=exc.status_code,content=exc.to_error_envelope())
	@app.exception_handler(HTTPException)
	async def handle_http_exception(request:Request,exc:HTTPException)->JSONResponse:
		A='HTTP exception on %s %s: %s (status=%d)';message=_detail_message(exc.detail);code=_detail_code(exc.detail,exc.status_code)
		if exc.status_code>=500:logger.error(A,request.method,request.url.path,message,exc.status_code)
		else:logger.info(A,request.method,request.url.path,message,exc.status_code)
		return json_error_response(exc.status_code,code,message)
	@app.exception_handler(Exception)
	async def handle_uncaught_exception(request:Request,exc:Exception)->JSONResponse:
		logger.error('Uncaught exception in API endpoint: %s %s',request.method,request.url.path,exc_info=A);error_type_name=type(exc).__name__
		if isinstance(exc,(ValueError,TypeError,AttributeError)):user_message=f"Invalid request: {exc}";status_code=HTTP_422_UNPROCESSABLE_CONTENT;error_code=API_INVALID_REQUEST
		elif isinstance(exc,(KeyError,IndexError)):user_message='Invalid data structure encountered';status_code=HTTP_422_UNPROCESSABLE_CONTENT;error_code=API_DATA_STRUCTURE_ERROR
		elif'yaml'in error_type_name.lower()or'serialization'in str(exc).lower():user_message='Failed to serialize data. Please check your semantic model definitions.';status_code=HTTP_500_INTERNAL_SERVER_ERROR;error_code=API_SERIALIZATION_ERROR
		else:user_message='An unexpected error occurred while processing your request.';status_code=HTTP_500_INTERNAL_SERVER_ERROR;error_code=API_UNEXPECTED_ERROR
		debug=_A
		if debug_mode_enabled():api_exception=ApiException(origin=f"API -> exceptions -> {error_type_name}",message=user_message,status_code=status_code,include_traceback=A);debug=t.cast(dict[str,object],api_exception.to_error_envelope().get('debug'))
		return json_error_response(status_code,error_code,user_message,debug=debug)