from __future__ import annotations
from typing import Callable
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from vulcan.utils import debug_mode_enabled
HEADER_CACHE_STATE='X-Cache-State'
HEADER_CACHE_EXPIRY_POLICY='X-Cache-Expiry-Policy'
HEADER_CACHE_KEY='X-Cache-Key'
class CacheHeadersMiddleware(BaseHTTPMiddleware):
	async def dispatch(self,request:Request,call_next:Callable)->Response:
		A=None;response=await call_next(request);cache_status=getattr(request.state,'cache_status',A)
		if cache_status is not A:response.headers[HEADER_CACHE_STATE]=cache_status
		cache_policy=getattr(request.state,'cache_policy',A)
		if cache_policy is not A:response.headers[HEADER_CACHE_EXPIRY_POLICY]=cache_policy
		if debug_mode_enabled():
			cache_key=getattr(request.state,'cache_key',A)
			if cache_key is not A:response.headers[HEADER_CACHE_KEY]=cache_key
		return response