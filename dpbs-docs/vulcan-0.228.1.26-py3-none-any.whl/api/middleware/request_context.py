from __future__ import annotations
_A=None
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp
from api.state.log_context import bind_request_label,reset_request_label
class RequestContextMiddleware(BaseHTTPMiddleware):
	def __init__(self,app:ASGIApp)->_A:super().__init__(app)
	async def dispatch(self,request:Request,call_next)->Response:
		user_id=getattr(request.state,'user_id',_A);token=bind_request_label(request.method,request.url.path,user_id=str(user_id)if user_id is not _A else _A)
		try:return await call_next(request)
		finally:reset_request_label(token)