from __future__ import annotations
from typing import Callable
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
_DOC_PATHS=frozenset({'/redoc','/scalar'})
_DOC_CONTENT_SECURITY_POLICY="default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob: https://cdn.jsdelivr.net; worker-src 'self' blob:; style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; img-src 'self' data: https:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'"
class DocSecurityHeadersMiddleware(BaseHTTPMiddleware):
	async def dispatch(self,request:Request,call_next:Callable)->Response:
		response=await call_next(request)
		if request.url.path not in _DOC_PATHS:return response
		response.headers['X-Content-Type-Options']='nosniff';response.headers['X-Frame-Options']='DENY';response.headers['Content-Security-Policy']=_DOC_CONTENT_SECURITY_POLICY;response.headers['Referrer-Policy']='no-referrer';return response