from __future__ import annotations
_D='heimdall'
_C=False
_B=True
_A=None
import asyncio,hashlib,importlib,logging,sys,time,typing as t
from pathlib import Path
from typing import Protocol,Set
from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from starlette.types import ASGIApp
from api.heimdall import AuthorizeResponse,HeimdallException,extract_bearer_token
from api.cache import LRUCacheStorage,_MISSING
from api.exceptions import COMMON_AUTH_BEARER_MALFORMED,COMMON_AUTH_CLIENT_HEADERS_NOT_ALLOWED,COMMON_AUTH_EXT_HOOK_FAILED,COMMON_AUTH_EXT_HOOK_INVALID_RESPONSE,COMMON_AUTH_TIMEOUT,COMMON_AUTH_HEIMDALL_UNAVAILABLE,COMMON_AUTH_MISSING_BEARER,COMMON_AUTH_FORBIDDEN,COMMON_AUTH_INVALID_TOKEN,COMMON_AUTH_AUTH_BACKEND_UNAVAILABLE,json_error_response
from schema.auth import AuthExtensionContext,SecurityContext
from api import prometheus
from vulcan.core.config.heimdall import HeimdallConfig
logger=logging.getLogger(__name__)
HeimdallCacheStatus=t.Literal['hit','miss']
_HIT:HeimdallCacheStatus='hit'
_MISS:HeimdallCacheStatus='miss'
def _on_policy_evaluated(duration_s:float,*,cached:bool=_C,denied:bool=_C,reason:str='')->_A:
	try:prometheus.registry.on_policy_evaluated(policy_type=_D,duration_s=duration_s,cached=cached,denied=denied,subject_type='user',reason=reason)
	except Exception as e:logger.debug('on_policy_evaluated failed: %s',e)
def _heimdall_cache_status(request:Request)->t.Optional[HeimdallCacheStatus]:
	value=getattr(request.state,'heimdall_cache',_A)
	if value is _A:return
	return t.cast(HeimdallCacheStatus,value)
def _heimdall_cache_hit(request:Request)->bool:return _heimdall_cache_status(request)==_HIT
DEFAULT_EXCLUDED_PATHS:Set[str]={'/livez','/readyz','/metrics','/docs','/redoc','/scalar','/openapi.json','/postman'}
DEFAULT_EXCLUDED_PREFIXES:Set[str]={'/api/v1/queue','/api/v1/files','/openapi/diagrams'}
FORBIDDEN_INBOUND_HEADERS:frozenset[str]=frozenset(('x-user',))
_HEIMDALL_AUTH_CACHE_MAXSIZE=5000
def _is_forbidden_inbound_header(name:str)->bool:
	lower=name.lower()
	if lower in FORBIDDEN_INBOUND_HEADERS:return _B
	return lower.startswith('x-user-')
class AuthExtensionHook(Protocol):
	async def __call__(self,ctx:AuthExtensionContext)->SecurityContext:...
def _load_auth_extension_hook(project_path:Path,hook_spec:t.Optional[str])->t.Optional[AuthExtensionHook]:
	trimmed=(hook_spec or'').strip()
	if not trimmed:return
	module_qualname,separator,callable_name=trimmed.partition(':')
	if separator!=':'or not module_qualname.strip()or not callable_name.strip():raise ValueError(f"Invalid hook spec {trimmed!r}; expected 'module.path:callable'")
	project_root=project_path.expanduser().resolve();project_root_str=str(project_root)
	if project_root_str not in sys.path:sys.path.insert(0,project_root_str)
	module_name=module_qualname.strip();attribute_name=callable_name.strip()
	try:hook_module=importlib.import_module(module_name)
	except ImportError:logger.exception('Failed to import heimdall.after_authorize hook module %r',module_name);raise
	hook_callable=getattr(hook_module,attribute_name,_A)
	if hook_callable is _A:raise AttributeError(f"Module {module_name!r} has no attribute {attribute_name!r}")
	if not callable(hook_callable):raise TypeError(f"after_authorize hook {trimmed!r} is not callable")
	return t.cast(AuthExtensionHook,hook_callable)
def _attach_auth_response_headers(request:Request,response:Response)->_A:
	cache_status=_heimdall_cache_status(request)
	if cache_status is not _A:response.headers['X-Heimdall-Cache']=cache_status
	user_id=getattr(request.state,'user_id',_A)
	if user_id is _A:return
	response.headers['X-User']=str(user_id);tags=getattr(request.state,'user_tags',());response.headers['X-User-Tags']=','.join(tags);security_context=getattr(request.state,'security_context',_A)or SecurityContext()
	for(header_name,header_value)in security_context.to_headers().items():response.headers[header_name]=header_value
class AuthorizationMiddleware(BaseHTTPMiddleware):
	def __init__(self,app:ASGIApp,heimdall_config:HeimdallConfig,*,project_path:Path):
		super().__init__(app);self.heimdall_config=heimdall_config;self.enabled=heimdall_config.enabled;self.auth_extension_hook=_load_auth_extension_hook(project_path,heimdall_config.after_authorize);self.timeout=heimdall_config.timeout;self.cache_timeout=heimdall_config.cache_timeout;self._heimdall_auth_cache=LRUCacheStorage(maxsize=_HEIMDALL_AUTH_CACHE_MAXSIZE)if self.cache_timeout>0 else _A;self.excluded_paths=DEFAULT_EXCLUDED_PATHS.copy();self.excluded_prefixes=DEFAULT_EXCLUDED_PREFIXES.copy()
		if self.enabled:logger.info('Authorization middleware enabled (excluded paths: %s, excluded prefixes: %s)',self.excluded_paths,self.excluded_prefixes)
		else:logger.warning('Authorization middleware DISABLED (HEIMDALL_ENABLED=false) - all requests allowed without authentication')
	async def _maybe_after_authorize_hook(self,request:Request,auth_response:AuthorizeResponse)->tuple[t.Optional[SecurityContext],t.Optional[JSONResponse]]:
		hook=self.auth_extension_hook
		if not auth_response.valid or not auth_response.allow or hook is _A:return _A,_A
		ctx=AuthExtensionContext(user_id=auth_response.user_id,user_tags=tuple(auth_response.user_tags),request_headers={k.lower():v for(k,v)in request.headers.items()})
		try:
			raw=await hook(ctx)
			if isinstance(raw,SecurityContext):return raw,_A
			if raw is not _A:return _A,_auth_extension_misconfigured(request,type(raw).__name__)
			return SecurityContext(),_A
		except Exception:return _A,_auth_extension_failed(request)
	async def _heimdall_authorize_cached(self,request:Request,client:t.Any,authorization_header:str)->tuple[float,AuthorizeResponse]:
		async def _heimdall()->tuple[float,AuthorizeResponse]:t0=time.perf_counter();auth_response=await client.authorize(authorization_header);return time.perf_counter()-t0,auth_response
		if self._heimdall_auth_cache is _A:request.state.heimdall_cache=_MISS;prometheus.registry.on_cache_event(api=_D,hit=_C);return await _heimdall()
		token=extract_bearer_token(authorization_header);cache_key=f"heimdall:auth:{hashlib.sha256(token.encode('utf-8')).hexdigest()}";cached=self._heimdall_auth_cache.get(cache_key,ttl=self.cache_timeout)
		if cached is not _MISSING:request.state.heimdall_cache=_HIT;logger.debug('Heimdall auth cache HIT key=%s',cache_key);prometheus.registry.on_cache_event(api=_D,hit=_B);return .0,t.cast(AuthorizeResponse,cached)
		request.state.heimdall_cache=_MISS;logger.debug('Heimdall auth cache MISS key=%s',cache_key);prometheus.registry.on_cache_event(api=_D,hit=_C);auth_duration,auth_response=await _heimdall()
		if auth_response.valid and auth_response.allow:self._heimdall_auth_cache.set(cache_key,auth_response,ttl=self.cache_timeout)
		return auth_duration,auth_response
	async def _authorize(self,request:Request,client:t.Any,authorization_header:str)->tuple[float,float,AuthorizeResponse,t.Optional[SecurityContext],t.Optional[JSONResponse]]:auth_duration,auth_response=await self._heimdall_authorize_cached(request,client,authorization_header);hook_start=time.perf_counter();hook_result,hook_err=await self._maybe_after_authorize_hook(request,auth_response);hook_duration=time.perf_counter()-hook_start;return auth_duration,hook_duration,auth_response,hook_result,hook_err
	async def dispatch(self,request:Request,call_next):
		if not self.enabled:return await call_next(request)
		if request.url.path in self.excluded_paths:return await call_next(request)
		for prefix in self.excluded_prefixes:
			if request.url.path.startswith(prefix):return await call_next(request)
		auth_header=request.headers.get('Authorization')
		if not auth_header:return _missing_authorization(request)
		if not auth_header.lower().startswith('bearer '):return _invalid_authorization_format(request)
		forbidden_present=sorted({name.lower()for name in request.headers if _is_forbidden_inbound_header(name)})
		if forbidden_present:names=', '.join(forbidden_present);return _forbidden_inbound_headers(request,names)
		client=getattr(request.app.state,'heimdall_client',_A)
		if client is _A:return _heimdall_client_missing(request)
		_start=time.perf_counter()
		try:auth_duration,hook_duration,auth_response,hook_result,hook_err=await asyncio.wait_for(self._authorize(request,client,auth_header),timeout=self.timeout)
		except asyncio.TimeoutError:return _auth_timeout(request,self.timeout)
		except HeimdallException as e:_on_policy_evaluated(time.perf_counter()-_start,cached=_heimdall_cache_hit(request),denied=_B,reason=e.error_code);return _heimdall_exception(request,e)
		if not auth_response.valid:_on_policy_evaluated(auth_duration,cached=_heimdall_cache_hit(request),denied=_B,reason='invalid_token');return _invalid_token(request,auth_response.error_message)
		if not auth_response.allow:_on_policy_evaluated(auth_duration,cached=_heimdall_cache_hit(request),denied=_B,reason='access_denied');return _access_denied(request,auth_response.user_id)
		if hook_err is not _A:return hook_err
		_on_policy_evaluated(auth_duration,cached=_heimdall_cache_hit(request));security_context=SecurityContext()if hook_result is _A else hook_result;logger.info('Authorized user %s for %s %s (heimdall=%.3fs, hook=%.3fs)',auth_response.user_id,request.method,request.url.path,auth_duration,hook_duration);request.state.user_id=auth_response.user_id;request.state.user_tags=auth_response.user_tags;request.state.security_context=security_context;response=await call_next(request);_attach_auth_response_headers(request,response);return response
def _missing_authorization(request:Request)->JSONResponse:logger.debug('Missing Authorization header for %s %s',request.method,request.url.path);return json_error_response(401,COMMON_AUTH_MISSING_BEARER,'Authentication required; send Authorization: Bearer <token>.')
def _invalid_authorization_format(request:Request)->JSONResponse:logger.error('Invalid Authorization format for %s %s',request.method,request.url.path);return json_error_response(401,COMMON_AUTH_BEARER_MALFORMED,'Invalid Authorization format. Expected: Bearer <token>')
def _invalid_token(request:Request,detail:t.Optional[str])->JSONResponse:logger.error('Token rejected for %s %s: %s',request.method,request.url.path,detail);return json_error_response(401,COMMON_AUTH_INVALID_TOKEN,'The access token is invalid or expired.')
def _forbidden_inbound_headers(request:Request,header_names:str)->JSONResponse:logger.error('Disallowed inbound request header(s) for %s %s: %s',request.method,request.url.path,header_names);return json_error_response(400,COMMON_AUTH_CLIENT_HEADERS_NOT_ALLOWED,f"These headers must not be sent by clients: {header_names}")
def _heimdall_client_missing(request:Request)->JSONResponse:logger.critical('Heimdall client missing from app.state while authorization is enabled; refusing %s %s',request.method,request.url.path);return json_error_response(503,COMMON_AUTH_AUTH_BACKEND_UNAVAILABLE,'Authentication is temporarily unavailable.')
def _access_denied(request:Request,user_id:str)->JSONResponse:logger.error('Access denied for user %s on %s %s',user_id,request.method,request.url.path);return json_error_response(403,COMMON_AUTH_FORBIDDEN,'Access denied')
def _auth_timeout(request:Request,timeout_s:float)->JSONResponse:logger.error('Heimdall authorize + enrichment hook exceeded heimdall.timeout=%.3fs for %s %s',timeout_s,request.method,request.url.path);return json_error_response(503,COMMON_AUTH_TIMEOUT,'Authorization exceeded heimdall.timeout (Heimdall + optional enrichment hook); increase timeout or shorten work per request.')
def _auth_extension_misconfigured(request:Request,got_kind:str)->JSONResponse:logger.error('Auth extension hook returned %s, expected SecurityContext for %s %s',got_kind,request.method,request.url.path);return json_error_response(503,COMMON_AUTH_EXT_HOOK_INVALID_RESPONSE,'Authorization extension misconfigured')
def _auth_extension_failed(request:Request)->JSONResponse:logger.exception('Auth extension hook failed for %s %s',request.method,request.url.path);return json_error_response(503,COMMON_AUTH_EXT_HOOK_FAILED,'Authorization extension failed')
def _heimdall_exception(request:Request,exc:HeimdallException)->JSONResponse:logger.error('Heimdall authorization failed for %s %s: %s',request.method,request.url.path,exc,exc_info=_B);return json_error_response(exc.status_code,COMMON_AUTH_HEIMDALL_UNAVAILABLE,'Authentication service temporarily unavailable.')