from __future__ import annotations
_F='/openapi.json'
_E='/scalar'
_D='/redoc'
_C='/metrics'
_B='/readyz'
_A='/livez'
import logging,re,time
from typing import Callable
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from starlette.types import ASGIApp
from api import prometheus
from api.middleware.auth import DEFAULT_EXCLUDED_PATHS
logger=logging.getLogger(__name__)
_QUERY_PATH_PREFIXES='/api/v1/query','/api/v1/perspectives'
_UUID_HEX=re.compile('^[0-9a-f]{32}$',re.IGNORECASE)
_NUMERIC=re.compile('^\\d+$')
_EXACT_PATHS:dict[str,str]={_A:_A,_B:_B,_C:_C,'/docs':'/docs',_D:_D,_E:_E,_F:_F}
_PREFIX_TEMPLATES:tuple[tuple[re.Pattern[str],str],...]=((re.compile('^/api/v1/query/statement/[^/]+/result$'),'/api/v1/query/statement/{id}/result'),(re.compile('^/api/v1/query/statement/[^/]+$'),'/api/v1/query/statement/{id}'),(re.compile('^/api/v1/perspectives/[^/]+/result$'),'/api/v1/perspectives/{slug}/result'),(re.compile('^/api/v1/perspectives/[^/]+$'),'/api/v1/perspectives/{slug}'),(re.compile('^/api/v1/activity/plans/[^/]+/git-diff$'),'/api/v1/activity/plans/{id}/git-diff'),(re.compile('^/api/v1/activity/plans/[^/]+$'),'/api/v1/activity/plans/{id}'),(re.compile('^/api/v1/activity/runs/[^/]+$'),'/api/v1/activity/runs/{id}'),(re.compile('^/api/v1/activity/models/[^/]+/runs$'),'/api/v1/activity/models/{model}/runs'),(re.compile('^/api/v1/activity/models/[^/]+/latest$'),'/api/v1/activity/models/{model}/latest'),(re.compile('^/api/v1/dq/rules/[^/]+$'),'/api/v1/dq/rules/{identity}'),(re.compile('^/api/v1/query/metric/[^/]+$'),'/api/v1/query/metric/{name}'),(re.compile('^/api/v1/queue/jobs/[^/]+/history$'),'/api/v1/queue/jobs/{job_id}/history'),(re.compile('^/api/v1/queue/jobs/[^/]+$'),'/api/v1/queue/jobs/{job_id}'))
def normalize_metrics_path(path:str)->str:
	A='/';normalized=path.split('?')[0].rstrip(A)or A
	if normalized in _EXACT_PATHS:return normalized
	for(pattern,template)in _PREFIX_TEMPLATES:
		if pattern.match(normalized):return template
	parts=normalized.split(A);collapsed:list[str]=[]
	for part in parts:
		if not part:collapsed.append(part);continue
		if _UUID_HEX.match(part)or _NUMERIC.match(part)or len(part)>=24:collapsed.append('{id}')
		else:collapsed.append(part)
	return A.join(collapsed)or A
class VulcanMetricsMiddleware(BaseHTTPMiddleware):
	def __init__(self,app:ASGIApp,tenant:str,data_product:str):super().__init__(app);self._tenant=tenant;self._data_product=data_product
	async def dispatch(self,request:Request,call_next:Callable)->Response:
		A='on_cache_event failed: %s';path=request.url.path;normalized=normalize_metrics_path(path);start=time.perf_counter();response=await call_next(request);elapsed=time.perf_counter()-start;status=str(response.status_code)
		if normalized not in DEFAULT_EXCLUDED_PATHS:
			try:prometheus.registry.on_api_http_request(method=request.method,path=normalized,status=status,duration_s=elapsed)
			except Exception as e:logger.debug('on_api_http_request failed: %s',e)
		is_query=any(path.startswith(p)for p in _QUERY_PATH_PREFIXES)
		if is_query:
			api='graphql'if'/graphql'in path else'rest';cache_status=getattr(request.state,'cache_status',None)
			if cache_status=='HIT':
				try:prometheus.registry.on_cache_event(api=api,hit=True)
				except Exception as e:logger.debug(A,e)
			elif cache_status=='MISS':
				try:prometheus.registry.on_cache_event(api=api,hit=False)
				except Exception as e:logger.debug(A,e)
		return response