from __future__ import annotations
_B=False
_A=None
import asyncio
from functools import cached_property
import logging,threading,typing as t
from fastapi import HTTPException
from vulcan.core.context import Context
from vulcan.core import constants as c
from vulcan.core.model import Model
from vulcan.core.export.bi_artifacts import build_export_artifacts
from schema.metadata import ModelEntry as MetadataModelEntry
logger=logging.getLogger(__name__)
class UnknownGatewayError(Exception):
	def __init__(self,requested:str,allowed:t.List[str])->_A:self.requested=requested;self.allowed=allowed;super().__init__(f"Unknown gateway '{requested}'")
class EnvContext:
	def __init__(self,context:Context,environment:str='prod',model_freshness_ts:t.Optional[t.Dict[str,int]]=_A):
		self.context=context;self.environment=environment;env=context.state_sync.get_environment(environment)
		if not env:available=[e.name for e in context.state_sync.get_environments()];raise ValueError(f"Environment '{environment}' not found. Available: {', '.join(available)}")
		self.plan_id=getattr(env,'plan_id',_A);self.snapshots=context.state_sync.get_snapshots(env.finalized_or_current_snapshots);(self.model_freshness_ts):t.Dict[str,int]=model_freshness_ts or{};(self.export_artifacts):t.Dict[str,t.Dict[str,str]]={};(self.openapi_spec):t.Dict[str,t.Any]={};(self.postman_spec):t.Dict[str,t.Any]={};self.product=context.config.project;self.tenant=context.config.tenant;(self._query_validators):t.Dict[str,t.Any]={};self._load(skip_freshness=model_freshness_ts is not _A)
	def get_query_validator(self,gateway:str):
		from api.query.validator import QueryValidator
		if gateway not in self._query_validators:self._query_validators[gateway]=QueryValidator(self,gateway=gateway)
		return self._query_validators[gateway]
	def resolve_gateway(self,requested:t.Optional[str])->str:
		if not requested:return self.metadata.gateway.name
		gateways=[self.metadata.gateway,*(self.metadata.gateways or[])];key=requested.lower();match=next((g.name for g in gateways if g.name.lower()==key),_A)
		if match is _A:raise UnknownGatewayError(requested,sorted(g.name for g in gateways))
		return match
	def resolve_query_gateway(self,requested:t.Optional[str])->t.Tuple[str,t.Any]:
		try:gateway=self.resolve_gateway(requested)
		except UnknownGatewayError as exc:raise HTTPException(status_code=400,detail={'error':'UNKNOWN_GATEWAY','message':f"Unknown gateway '{exc.requested}'.",'allowed':exc.allowed})from exc
		return gateway,self.get_query_validator(gateway)
	def get_dialect(self,gateway:str)->t.Optional[str]:
		try:
			connection=self.context.config.get_connection(gateway);dialect=getattr(connection,'DIALECT',_A)
			if dialect:logger.debug("Extracted dialect '%s' from gateway '%s'",dialect,gateway)
			else:logger.warning("No DIALECT attribute found on connection for gateway '%s' (type: %s)",gateway,type(connection).__name__)
			return dialect
		except Exception as e:logger.warning('Failed to extract dialect from context: gateway=%s, error=%s',gateway,e);return
	def load_model_freshness_ts(self)->_A:self.model_freshness_ts=self.context.state_sync.get_last_successful_run_end_ts_by_model(environment=self.environment)
	def did_models_change_after(self,ts:int,model_names:t.Optional[t.List[str]])->bool:
		if not model_names or not ts:return _B
		for model_name in model_names:
			model_last_run_ts=self.model_freshness_ts.get(model_name)
			if model_last_run_ts and model_last_run_ts>ts:return True
		return _B
	def get_model(self,model_name:str)->t.Optional[Model]:
		for snapshot in self.snapshots.values():
			if snapshot.is_model and snapshot.model.name==model_name:return snapshot.model
	@cached_property
	def models_by_name(self)->dict[str,MetadataModelEntry]:return{entry.name:entry for entry in self.metadata.models or[]}
	@cached_property
	def metrics_by_name(self)->dict[str,MetadataModelEntry]:return{name:entry for(name,entry)in self.models_by_name.items()if entry.kind=='METRIC'}
	def require_model_entry(self,model_name:str)->MetadataModelEntry:
		entry=self.models_by_name.get(model_name)
		if entry is not _A:return entry
		raise HTTPException(status_code=404,detail=f"Model '{model_name}' not found")
	def _load(self,*,skip_freshness:bool=_B)->_A:
		self.metadata=self.context.metadata_for_environment(self.environment);from vulcan.core.export.semantic import build_semantic_schema;self.semantic_schema=build_semantic_schema(self.metadata);self._generate_export_artifacts_from_metadata();self._generate_api_spec_artifacts()
		if not skip_freshness:self.load_model_freshness_ts()
	def _generate_export_artifacts_from_metadata(self)->_A:
		if self.metadata.env!=c.PROD:return
		try:artifacts=build_export_artifacts(self.metadata);self.export_artifacts={name:{'path':str(artifact.path)}for(name,artifact)in artifacts.items()}
		except Exception as e:logger.error('Export artifact pre-generation failed during EnvContext load (env=%s): %s',self.environment,e,exc_info=True)
	def _generate_api_spec_artifacts(self)->_A:
		try:from api.openapi.postman import openapi_to_postman;from api.openapi.schema import build_env_openapi_spec,get_route_openapi_base;get_route_openapi_base();self.openapi_spec=build_env_openapi_spec(self.metadata);self.postman_spec=openapi_to_postman(self.openapi_spec,env_ctx=self)
		except Exception as e:logger.error('API spec artifact generation failed during EnvContext load (env=%s): %s',self.environment,e,exc_info=True);self.openapi_spec={};self.postman_spec={}
class EnvContextManager:
	def __init__(self,context:Context):self.context=context;(self._env_contexts):t.Dict[str,EnvContext]={};self._lock=asyncio.Lock();self._build_lock=threading.Lock();(self.plan_version):t.Dict[str,int]={};(self.run_version):t.Dict[str,int]={};self.qm=_A;self._activity=_A
	def get_env_context(self,environment:str)->EnvContext:
		ctx=self._env_contexts.get(environment)
		if ctx is not _A:return ctx
		with self._build_lock:
			ctx=self._env_contexts.get(environment)
			if ctx is not _A:return ctx
			env_obj=self.context.state_sync.get_environment(environment)
			if env_obj is _A:available_envs=[e.name for e in self.context.state_sync.get_environments_summary()];raise ValueError(f"Environment '{environment}' not found. Available environments: {', '.join(available_envs)if available_envs else'none'}")
			built=EnvContext(self.context,environment);self._env_contexts[environment]=built;return built
	def get_plan_version(self,environment:str)->int:return self.plan_version.get(environment,0)
	def get_run_version(self,environment:str)->int:return self.run_version.get(environment,0)
	async def on_plan_change(self,environment:str)->_A:
		from api.cache import CachePolicy,get_cache_storage;from api.pool import run_blocking_heavy;freshness:t.Optional[t.Dict[str,int]]=_A
		if self._activity is not _A:
			try:freshness=await self._activity.get_last_successful_run_end_ts_by_model(environment)
			except Exception as exc:logger.warning("Failed to pre-fetch model freshness for '%s': %s; falling back to sync load",environment,exc)
		if freshness is not _A:new_ctx=await run_blocking_heavy(EnvContext,self.context,environment,model_freshness_ts=freshness)
		else:new_ctx=await run_blocking_heavy(EnvContext,self.context,environment)
		async with self._lock:self._env_contexts[environment]=new_ctx;self.plan_version[environment]=self.plan_version.get(environment,0)+1
		cache=get_cache_storage();plan_invalidated=cache.invalidate_pattern(f"cache:v1:{CachePolicy.PLAN_CHANGE.value}:{environment}:");run_invalidated=cache.invalidate_pattern(f"cache:v1:{CachePolicy.RUN_CHANGE.value}:{environment}:");ttl_invalidated=cache.invalidate_pattern(f"cache:v1:{CachePolicy.TTL.value}:{environment}:");logger.info(f"Plan change for '{environment}' (v{self.plan_version[environment]}): invalidated {plan_invalidated} plan caches, {run_invalidated} run caches, {ttl_invalidated} ttl caches")
	async def on_run_change(self,environment:str,model_names:t.Optional[t.Sequence[str]]=_A)->_A:
		from api.cache import CachePolicy,get_cache_storage;freshness:t.Optional[t.Dict[str,int]]=_A
		if self._activity is not _A:
			try:freshness=await self._activity.get_last_successful_run_end_ts_by_model(environment)
			except Exception as exc:logger.warning("Failed to async-fetch model freshness for '%s': %s; falling back to sync load",environment,exc)
		async with self._lock:
			if environment in self._env_contexts:
				env_ctx=self._env_contexts[environment]
				if freshness is not _A:env_ctx.model_freshness_ts=freshness
				else:env_ctx.load_model_freshness_ts()
				logger.info("Reloaded model_freshness_ts for '%s' (%d models)",environment,len(env_ctx.model_freshness_ts))
			self.run_version[environment]=self.run_version.get(environment,0)+1
		cache=get_cache_storage();run_invalidated=cache.invalidate_pattern(f"cache:v1:{CachePolicy.RUN_CHANGE.value}:{environment}:");logger.info(f"Run change for '{environment}' (v{self.run_version[environment]}): invalidated {run_invalidated} run caches")