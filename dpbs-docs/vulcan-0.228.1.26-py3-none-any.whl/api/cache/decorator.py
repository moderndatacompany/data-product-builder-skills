from __future__ import annotations
_C='request'
_B='asyncio.Future[t.Any]'
_A=None
import asyncio,functools,hashlib,inspect,json,logging,typing as t
from enum import Enum
from fastapi import Request
from api.cache.storage import LRUCacheStorage,_MISSING,_cache_storage
from api.dependencies import get_env_context_manager,get_environment
logger=logging.getLogger(__name__)
_inflight:t.Dict[str,_B]={}
_inflight_lock:t.Optional[asyncio.Lock]=_A
def _get_inflight_lock()->asyncio.Lock:
	global _inflight_lock
	if _inflight_lock is _A:_inflight_lock=asyncio.Lock()
	return _inflight_lock
class CachePolicy(str,Enum):PLAN_CHANGE='plan_change';RUN_CHANGE='run_change';TTL='ttl'
def _make_cache_key(policy:CachePolicy,endpoint_path:str,environment:str|_A,plan_version:int|_A,run_version:int|_A,params:t.Dict[str,t.Any])->str:
	A='default';params_str=json.dumps(params,sort_keys=True,default=str);params_hash=hashlib.md5(params_str.encode()).hexdigest()[:8];parts=['cache','v1',policy.value]
	if policy==CachePolicy.PLAN_CHANGE:parts.extend([environment or A,str(plan_version or 0),endpoint_path,params_hash])
	elif policy==CachePolicy.RUN_CHANGE:parts.extend([environment or A,str(run_version or 0),endpoint_path,params_hash])
	elif policy==CachePolicy.TTL:parts.extend([environment or A,endpoint_path,params_hash])
	return':'.join(parts)
def _extract_request(*args,**kwargs)->Request|_A:
	request:Request|_A=kwargs.get(_C)
	if not request:
		for arg in args:
			if isinstance(arg,Request):return arg
	return request
def _build_cache_key_and_check(request:Request,policy:CachePolicy,key_params:t.List[str]|_A,kwargs:dict,func_name:str,ttl:t.Optional[float]=_A)->tuple[str,t.Any]|_A:
	try:manager=get_env_context_manager(request);environment=get_environment(request)
	except Exception as e:logger.warning(f"Cache decorator on {func_name} failed to get manager/environment: {e}, skipping cache");return
	plan_version=manager.get_plan_version(environment)if policy==CachePolicy.PLAN_CHANGE else _A;run_version=manager.get_run_version(environment)if policy==CachePolicy.RUN_CHANGE else _A;cache_params={}
	if key_params:
		for param_name in key_params:
			if param_name in kwargs:cache_params[param_name]=kwargs[param_name]
	else:cache_params={k:v for(k,v)in kwargs.items()if k!=_C and not isinstance(v,Request)}
	endpoint_path=request.url.path;cache_key=_make_cache_key(policy=policy,endpoint_path=endpoint_path,environment=environment,plan_version=plan_version,run_version=run_version,params=cache_params);cached_value=_cache_storage.get(cache_key,ttl=ttl);return cache_key,cached_value
def cached(policy:CachePolicy=CachePolicy.PLAN_CHANGE,key_params:t.List[str]|_A=_A,ttl:t.Optional[float]=_A):
	if policy==CachePolicy.TTL and ttl is _A:raise ValueError('ttl parameter is required when policy=CachePolicy.TTL')
	def decorator(func):
		def _execute_with_cache(*args,**kwargs):
			request=_extract_request(*args,**kwargs)
			if not request:logger.warning(f"Cache decorator on {func.__name__} but no Request found, skipping cache");return _A,_A,_A
			cache_result=_build_cache_key_and_check(request=request,policy=policy,key_params=key_params,kwargs=kwargs,func_name=func.__name__,ttl=ttl)
			if cache_result is _A:return _A,_A,_A
			cache_key,cached_value=cache_result;is_hit=cached_value is not _MISSING;cache_status='HIT'if is_hit else'MISS';request.state.cache_policy=policy.value.upper();request.state.cache_key=cache_key;request.state.cache_status=cache_status;logger.info(f"Cache: {cache_status} - {cache_key}");return request,cache_key,cached_value
		@functools.wraps(func)
		async def async_wrapper(*args,**kwargs):
			request,cache_key,cached_value=_execute_with_cache(*args,**kwargs)
			if request is _A:return await func(*args,**kwargs)
			if cached_value is not _MISSING:return cached_value
			loop=asyncio.get_running_loop();lock=_get_inflight_lock()
			async with lock:
				pending=_inflight.get(cache_key)
				if pending is _A:future:_B=loop.create_future();_inflight[cache_key]=future;is_primary=True
				else:future=pending;is_primary=False
			if not is_primary:return await future
			try:result=await func(*args,**kwargs)
			except BaseException as exc:
				async with lock:_inflight.pop(cache_key,_A)
				if not future.done():future.set_exception(exc)
				raise
			else:
				_cache_storage.set(cache_key,result,ttl=ttl)
				async with lock:_inflight.pop(cache_key,_A)
				if not future.done():future.set_result(result)
				return result
		@functools.wraps(func)
		def sync_wrapper(*args,**kwargs):
			request,cache_key,cached_value=_execute_with_cache(*args,**kwargs)
			if request is _A:return func(*args,**kwargs)
			if cached_value is not _MISSING:return cached_value
			result=func(*args,**kwargs);_cache_storage.set(cache_key,result,ttl=ttl);return result
		if inspect.iscoroutinefunction(func):return async_wrapper
		return sync_wrapper
	return decorator
def get_cache_storage()->LRUCacheStorage:return _cache_storage