from __future__ import annotations
_E='security'
_D='x-tagGroups'
_C='info'
_B='description'
_A=None
import copy,re,typing as t
from fastapi import FastAPI
from api.urls import ingress_base_url,is_localhost,openapi_server_url
from api.middleware.auth import DEFAULT_EXCLUDED_PATHS
from api.openapi.fragments import AUTH_GUIDE,ERROR_ENVELOPE,HTTP_STATUS_CODES,OPENAPI_TAG_DESCRIPTIONS,OPENAPI_TAG_GROUPS
if t.TYPE_CHECKING:from api.context import EnvContextManager
from schema.metadata import Metadata
from api.openapi.examples import apply_metadata_examples_to_openapi,apply_metadata_parameter_examples_to_openapi
OPENAPI_TITLE='Vulcan API'
OPENAPI_DESCRIPTION=f"""
{AUTH_GUIDE}

{ERROR_ENVELOPE}

{HTTP_STATUS_CODES}
""".strip()
_route_openapi_base:t.Optional[dict]=_A
def set_route_openapi_base(schema:dict)->_A:global _route_openapi_base;_route_openapi_base=copy.deepcopy(schema)
def get_route_openapi_base()->dict:
	if _route_openapi_base is _A:raise RuntimeError('Route OpenAPI base not initialized; call set_route_openapi_base first')
	return copy.deepcopy(_route_openapi_base)
def get_openapi_version()->str:
	try:from vulcan import __version__;return __version__
	except ImportError:return'0.0.0'
def build_openapi_tags()->t.List[t.Dict[str,str]]:return[{'name':name,_B:desc}for(name,desc)in OPENAPI_TAG_DESCRIPTIONS]
def build_product_intro(metadata:Metadata|_A)->str:
	if metadata is _A:return''
	product=metadata.product;description:t.Optional[str]=product.description;tags:list[str]=product.tags;users=product.users;tenant:t.Optional[str]=metadata.tenant;domain:t.Optional[str]=product.domain;version:str=metadata.version;owner_names=[u.username for u in users if u.username];segments:list[str]=[]
	if domain:segments.append(f"**Domain** {domain}")
	if tenant:segments.append(f"**Tenant** {tenant}")
	if owner_names:segments.append(f"**Users** {', '.join(owner_names[:5])}")
	if tags:segments.append(f"**Tags** {', '.join(tags)}")
	if version and version!='0.0.0':segments.append(f"**Version** `{version}`")
	lines:list[str]=[]
	if description:lines.append(description)
	if segments:lines.append(' · '.join(segments))
	return'\n\n'.join(lines)
def _build_servers()->t.List[t.Dict[str,str]]:
	A='url'
	if is_localhost():return[{A:openapi_server_url(),_B:'Local'}]
	return[{A:openapi_server_url(),_B:'DataOS data product ingress'}]
_DIAGRAM_MARKDOWN_RE=re.compile('\\]\\(/openapi/diagrams/')
def _absolutize_diagram_urls(text:str,ingress:str)->str:
	if not text or'/openapi/diagrams/'not in text:return text
	return _DIAGRAM_MARKDOWN_RE.sub(f"]({ingress}/openapi/diagrams/",text)
def _absolutize_openapi_diagram_urls(schema:dict,metadata:t.Optional[Metadata]=_A)->_A:
	tenant=metadata.tenant if metadata is not _A else _A;resource=metadata.name if metadata is not _A else _A;ingress=ingress_base_url(include_scheme=True,tenant=tenant,resource=resource)
	for items in(schema.get('tags',[]),schema.get(_D,[])):
		for item in items:
			if isinstance(item,dict)and _B in item:item[_B]=_absolutize_diagram_urls(item[_B],ingress)
	info=schema.get(_C,{})
	if isinstance(info,dict)and _B in info:info[_B]=_absolutize_diagram_urls(info[_B],ingress)
def _clear_security_for_excluded_paths(schema:dict)->_A:
	paths=schema.get('paths',{})
	for(path,path_item)in paths.items():
		if path not in DEFAULT_EXCLUDED_PATHS:continue
		for method_data in path_item.values():
			if isinstance(method_data,dict):method_data[_E]=[]
def build_env_openapi_spec(metadata:Metadata)->dict:schema=get_route_openapi_base();return patch_openapi_schema(schema,metadata=metadata)
def patch_openapi_schema(schema:dict,metadata:t.Optional[Metadata]=_A)->dict:
	C='BearerAuth';B='securitySchemes';A='components';schema.setdefault(_D,OPENAPI_TAG_GROUPS);schema.setdefault(A,{});schema[A].setdefault(B,{});schema[A][B][C]={'type':'http','scheme':'bearer',_B:'DataOS API Bearer token.'};schema[_E]=[{C:[]}];_clear_security_for_excluded_paths(schema);schema['servers']=_build_servers()
	if metadata is not _A:
		product_intro=build_product_intro(metadata)
		if product_intro:base_description=schema.get(_C,{}).get(_B,OPENAPI_DESCRIPTION);schema.setdefault(_C,{})[_B]=f"{product_intro}\n\n{base_description}"
		display_name=metadata.product.display_name
		if display_name:schema.setdefault(_C,{})['title']=f"{display_name} API"
		apply_metadata_examples_to_openapi(schema,metadata);apply_metadata_parameter_examples_to_openapi(schema,metadata)
	if not is_localhost():_absolutize_openapi_diagram_urls(schema,metadata=metadata)
	return schema
def install_openapi_extensions(app:FastAPI,manager:EnvContextManager,default_env:str)->_A:
	generate_openapi=app.openapi;set_route_openapi_base(generate_openapi())
	def openapi_with_env()->dict:ctx=manager.get_env_context(default_env);return ctx.openapi_spec
	app.openapi=openapi_with_env