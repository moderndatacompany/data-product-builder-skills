from __future__ import annotations
_X='variable'
_W='parameters'
_V='Content-Type'
_U='header'
_T='examples'
_S='content'
_R='{{statement_id}}'
_Q='tags'
_P='type'
_O='url'
_N='request'
_M='disabled'
_L='raw'
_K='application/json'
_J=False
_I='json'
_H='post'
_G='item'
_F='query'
_E='key'
_D=None
_C='value'
_B='name'
_A='description'
import json,re,typing as t
from api.urls import API_V1_PREFIX,api_v1_path as v1,postman_base_url
from api.openapi.examples import PostmanCatalogContext,parameter_example,postman_catalog_context
from api.openapi.fragments import AUTH_GUIDE,HTTP_STATUS_CODES,OPENAPI_TAG_GROUPS
if t.TYPE_CHECKING:from api.context import EnvContext
from schema.metadata import Metadata
MetadataOrContext=t.Union[Metadata,'EnvContext']
POSTMAN_SCHEMA='https://schema.getpostman.com/json/collection/v2.1.0/collection.json'
_HTTP_STATUS_TEXT:dict[int,str]={200:'OK',201:'Created',202:'Accepted',400:'Bad Request',401:'Unauthorized',403:'Forbidden',404:'Not Found',409:'Conflict',422:'Unprocessable Entity',500:'Internal Server Error',503:'Service Unavailable'}
class _PathBehavior(t.NamedTuple):collection_var_refs:dict[str,str];statement_id_methods:frozenset[str];split_result:bool=_J
_POSTMAN_PATH_BEHAVIORS:dict[str,_PathBehavior]={v1('/query/statement/{id}'):_PathBehavior(collection_var_refs={'id':_R},statement_id_methods=frozenset()),v1('/query/statement/{id}/result'):_PathBehavior(collection_var_refs={'id':_R},statement_id_methods=frozenset(),split_result=True),v1('/query/semantic/rest'):_PathBehavior(collection_var_refs={},statement_id_methods=frozenset({_H})),v1('/query/semantic/sql'):_PathBehavior(collection_var_refs={},statement_id_methods=frozenset({_H})),v1('/query/metric/{metric_name}'):_PathBehavior(collection_var_refs={},statement_id_methods=frozenset({_H}))}
PATH_VAR_COLLECTION_REFS:dict[tuple[str,str],str]={(path,param):ref for(path,cfg)in _POSTMAN_PATH_BEHAVIORS.items()for(param,ref)in cfg.collection_var_refs.items()}
STATEMENT_ID_TEST_PATHS:set[tuple[str,str]]={(path,method)for(path,cfg)in _POSTMAN_PATH_BEHAVIORS.items()for method in cfg.statement_id_methods}
_SPLIT_RESULT_PATHS:set[str]={path for(path,cfg)in _POSTMAN_PATH_BEHAVIORS.items()if cfg.split_result}
_GRAPHQL_PATH=v1('/query/semantic/graphql')
_STATEMENT_ID_TEST_SCRIPT='var res = pm.response.json();\nif (res && res.id) {\n    pm.collectionVariables.set("statement_id", res.id);\n    console.log("statement_id set:", res.id);\n}'
def _saved_responses_from_spec(operation:dict,original_request:dict)->list:
	result=[]
	for(status_str,response_obj)in(operation.get('responses')or{}).items():
		try:code=int(status_str)
		except(ValueError,TypeError):continue
		examples=(response_obj.get(_S)or{}).get(_K,{}).get(_T)or{}
		for(name,ex)in examples.items():
			value=ex.get(_C)
			if value is _D:continue
			result.append({_B:name,'originalRequest':original_request,'status':_HTTP_STATUS_TEXT.get(code,str(code)),'code':code,_U:[{_E:_V,_C:_K}],'_postman_previewlanguage':_I,'body':json.dumps(value)})
	return result
def _openapi_path_to_postman_url(path:str)->dict:postman_path=re.sub('\\{(\\w+)\\}',':\\1',path);segments=[s for s in postman_path.split('/')if s];return{_L:f"https://{{{{base_url}}}}{postman_path}",'protocol':'https','host':['{{base_url}}'],'path':segments}
def _path_vars(path:str,operation:dict)->list:return[{_E:p[_B],_C:PATH_VAR_COLLECTION_REFS.get((path,p[_B]))or str(parameter_example(p)or''),_A:p.get(_A,'')}for p in operation.get(_W,[])if p.get('in')=='path']
def _query_params(operation:dict)->list:return[{_E:p[_B],_C:str(ex)if(ex:=parameter_example(p))is not _D else'',_A:p.get(_A,''),_M:not p.get('required',_J)}for p in operation.get(_W,[])if p.get('in')==_F]
def _apply_result_format_query(split_item:dict,path:str,operation:dict,fmt:str)->_D:
	A='format'
	if fmt==_I:
		qp=_query_params(operation)
		for param in qp:
			if param[_E]==A:param[_C]=_I;param[_M]=_J
		split_item[_N][_O][_F]=qp;return
	split_item[_N][_O][_F]=[{_E:A,_C:fmt,_A:'Response format',_M:_J}]
def _example_value_from_operation(operation:dict)->t.Optional[t.Any]:
	A='example';rb=operation.get('requestBody',{});aj=rb.get(_S,{}).get(_K,{});examples=aj.get(_T,{})
	if examples:first=next(iter(examples.values()));return first.get(_C)
	if A in aj:return aj[A]
def _body_for(operation:dict)->t.Optional[dict]:
	val=_example_value_from_operation(operation)
	if val is _D:return
	return{'mode':_L,_L:json.dumps(val,indent=2),'options':{_L:{'language':_I}}}
def _graphql_body_for(operation:dict)->t.Optional[dict]:
	A='graphql';val=_example_value_from_operation(operation)
	if val is _D:return
	query=val.get(_F,'')if isinstance(val,dict)else str(val);return{'mode':A,A:{_F:query,'variables':'{}'}}
def _build_item(path:str,method:str,operation:dict)->dict:
	A='summary';url=_openapi_path_to_postman_url(path);qp=_query_params(operation)
	if qp:url[_F]=qp
	pv=_path_vars(path,operation)
	if pv:url[_X]=pv
	headers=[];body=_D
	if method in(_H,'put','patch'):headers=[{_E:_V,_C:_K}];body=_graphql_body_for(operation)if path==_GRAPHQL_PATH else _body_for(operation)
	description=operation.get(_A)or operation.get(A,'');request:dict={'method':method.upper(),_U:headers,_O:url,_A:description}
	if body:request['body']=body
	item:dict={_B:operation.get(A,f"{method.upper()} {path}"),_N:request,'response':_saved_responses_from_spec(operation,request)}
	if(path,method)in STATEMENT_ID_TEST_PATHS:item['event']=[{'listen':'test','script':{_P:'text/javascript','exec':_STATEMENT_ID_TEST_SCRIPT.splitlines()}}]
	return item
def build_postman_collection_description(*,dataos_url:str)->str:return f"""
## Base URL

Every data product is accessible at a unique URL:

```
https://<DATAOS_FQDN>/vulcan/tenants/<DATAOS_TENANT_ID>/data-products/<DATAOS_TENANT_ID>-<resource-name>{API_V1_PREFIX}
```

Set the `base_url` collection variable to your data product's root URL (without `{API_V1_PREFIX}`): `{dataos_url}`.

{AUTH_GUIDE}

Set the `apikey` collection variable to your DataOS API token
— all requests will use it automatically.

{HTTP_STATUS_CODES}
""".strip()
def _folders_from_tag_groups(spec:dict,grouped:dict[str,list],tag_desc:dict[str,str])->list:
	folders:list=[];emitted_tags:set[str]=set();tag_groups=spec.get('x-tagGroups')or OPENAPI_TAG_GROUPS
	for group in tag_groups:
		group_name=group.get(_B,'');child_folders:list=[]
		for tag in group.get(_Q,[]):
			if tag not in grouped:continue
			emitted_tags.add(tag);child_folders.append({_B:tag,_A:tag_desc.get(tag,''),_G:grouped[tag]})
		if not child_folders:continue
		group_desc=group.get(_A,'')
		if len(child_folders)==1 and child_folders[0][_B]==group_name:folder=child_folders[0];folders.append({_B:group_name,_A:group_desc or folder[_A],_G:folder[_G]});continue
		folders.append({_B:group_name,_A:group_desc,_G:child_folders})
	for(tag,items)in grouped.items():
		if tag in emitted_tags:continue
		folders.append({_B:tag,_A:tag_desc.get(tag,''),_G:items})
	return folders
def openapi_to_postman(spec:dict,env_ctx:t.Optional[MetadataOrContext]=_D)->dict:
	C='bearer';B='get';A='vulcan';ctx:t.Optional[PostmanCatalogContext]=postman_catalog_context(env_ctx)if env_ctx is not _D else _D;dataos_url=postman_base_url(tenant=ctx.tenant if ctx else _D,resource=ctx.product_name if ctx else _D);display_name=ctx.display_name or ctx.product_name or A if ctx else A;collection_name=f"Vulcan API — {display_name}";collection_description=build_postman_collection_description(dataos_url=dataos_url);tag_desc={t[_B]:t.get(_A,'')for t in spec.get(_Q,[])};grouped:dict[str,list]={}
	for(path,path_item)in spec.get('paths',{}).items():
		for(method,op)in path_item.items():
			if method not in(B,_H,'put','delete','patch','head'):continue
			if not isinstance(op,dict):continue
			tag=(op.get(_Q)or['Other'])[0]
			if path in _SPLIT_RESULT_PATHS and method==B:
				for(fmt,suffix)in[(_I,'JSON'),('parquet','Parquet')]:split_item=_build_item(path,method,dict(op,summary=f"Get Statement Result ({suffix})"));_apply_result_format_query(split_item,path,op,fmt);grouped.setdefault(tag,[]).append(split_item)
				continue
			grouped.setdefault(tag,[]).append(_build_item(path,method,op))
	folders=_folders_from_tag_groups(spec,grouped,tag_desc);product=ctx.product_name or A if ctx else A;return{'info':{_B:collection_name,_A:collection_description,'_postman_id':f"vulcan-api-{product}",'schema':POSTMAN_SCHEMA},_X:[{_E:'base_url',_C:dataos_url,_A:f"Data product ingress URL (without {API_V1_PREFIX})"},{_E:'apikey',_C:'',_A:'DataOS apikey'},{_E:'statement_id',_C:'',_A:'Auto-set by Tests on async query POST endpoints'}],'auth':{_P:C,C:[{_E:'token',_C:'{{apikey}}',_P:'string'}]},_G:folders}