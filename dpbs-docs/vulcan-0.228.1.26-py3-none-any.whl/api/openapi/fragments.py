from __future__ import annotations
_J='GraphQL'
_I='Health'
_H='Engagement'
_G='Perspectives'
_F='Discover'
_E='Quality & Activity'
_D='Query'
_C='group'
_B='description'
_A='name'
import typing as t
from api.urls import API_V1_PREFIX,api_v1_path as v1
AUTH_GUIDE='\n## Authentication\n\nPass your DataOS API token as a Bearer token:\n\n```\nAuthorization: Bearer <your-dataos-access-token>\n```\n'.strip()
ERROR_ENVELOPE='\n## Error Envelope\n\nStructured errors use:\n\n```json\n{\n  "status": 400,\n  "error": {\n    "code": "DOMAIN.SUBDOMAIN.REASON",\n    "message": "Human-readable explanation"\n  }\n}\n```\n\nResponses may include HATEOAS navigation under `_links`.\n'.strip()
HTTP_STATUS_CODES='\n## HTTP Status Codes\n\n- **400** — Invalid request (bad SQL, invalid parameters)\n- **401** — Missing or malformed Bearer token\n- **403** — Authenticated but not authorized\n- **404** — Resource not found\n- **406** — Unsupported format\n- **409** — Conflict (e.g. slug already taken)\n- **422** — Validation error\n- **429** — Rate limited\n- **502** — Upstream transpiler or gateway error\n- **503** — Service unavailable (worker unhealthy, auth backend down)\n'.strip()
HEALTH_ENDPOINTS=f"""
## Health Endpoints

- `/livez` — Liveness probe. Returns `200` when the process is alive.
- `/readyz` — Readiness probe. Returns `200` when ready, `503` when worker not ready.
- `/metrics` — Prometheus scrape endpoint. Returns `200` ok, `500` on metrics failure.

**These endpoints are mounted at the root path** (`/`) and are not versioned under `{API_V1_PREFIX}`.
No authentication is required.
""".strip()
HEALTH_TAG_DESCRIPTION='Service health endpoints used by orchestrators and monitoring tools to determine\nwhether the data product API is alive and ready to serve traffic.\n\n'+HEALTH_ENDPOINTS
QUERY_LIFECYCLE_DIAGRAM='![Query lifecycle sequence diagram](/openapi/diagrams/query-lifecycle.svg)'
QUERY_STRATEGIES_DIAGRAM='![Query deduplication strategies diagram](/openapi/diagrams/query-strategies.svg)'
QUERY_GRAPHQL_TIMEOUT_DIAGRAM='![GraphQL 504 timeout and resubmit diagram](/openapi/diagrams/graphql-timeout-resubmit.svg)'
QUERY_COMMON_PARAMS='\n## Common Query Parameters\n\n- `transpile_only` — transpile semantic REST/SQL to warehouse SQL without creating a statement (`200`)\n- `retry_on_recent_failure` — allow resubmit when an identical query failed in the last 5 minutes\n- Environment — `?env=` query param or `X-Environment` header (default: `prod`)\n'.strip()
QUERY_STATUS_VALUES='\n## Statement Statuses\n\n- **ACCEPTED** — Received, not yet queued\n- **QUEUED** — In the execution queue\n- **IN_PROGRESS** — Worker executing\n- **SUCCESS** — Result available at `/result`\n- **FAILED** — See `error` field; no result artifact exists\n'.strip()
QUERY_STRATEGIES='\n## Execution Strategies\n\n- **EXECUTE** — Fresh execution queued — poll until `SUCCESS` or `FAILED`\n- **AWAIT_PRIMARY** — Identical query already running — deduplicated, poll normally\n- **REUSE_RESULT** — Prior successful result available — `status` is already `SUCCESS`, fetch immediately\n'.strip()
QUERY_TRANSPILE_CALLOUT='\n> **transpile_only mode** — Pass `?transpile_only=true` to convert semantic REST or SQL to\n> warehouse SQL without creating a statement. Returns `200` with the transpiled SQL; no polling needed.\n'.strip()
RESULT_FORMATS='\n## Result Formats\n\n- **parquet** (default) — `307` redirect to a presigned download URL; the full result file is\n  downloaded directly from object storage. The `limit`, `offset`, and `columns` parameters are\n  ignored for parquet.\n- **json** — Inline response with `cols`, `rows`, and `types` arrays.\n- **csv** — Inline CSV text.\n- **yaml** — Inline YAML.\n\nFor `json`, `csv`, and `yaml`, use the `limit`, `offset`, and `columns` query parameters to\npaginate or subset results before they are serialized inline.\n'.strip()
QUERY_GRAPHQL_CALLOUT=f'''
**Synchronous endpoint** — submit a GraphQL query and receive the full JSON response in a single
HTTP request. No statement is created; do not poll `/query/statement`.

- `POST /query/semantic/graphql` with `{{"query": "{{ ... }}"}}` and a Bearer token.
- The `X-User` header is derived from the authenticated user context; do not set it manually.
- Returns HTTP `200` with the GraphQL JSON payload inline. GraphQL-level errors
  (invalid fields, resolver failures) surface as an `errors` array in the body, not as HTTP 4xx.

## Errors

- **503** — The GraphQL service is unreachable (connection error or DNS failure).
- **504 Gateway Timeout** — The upstream GraphQL service did not respond within the configured
  timeout (default **30 s**). Body: `{{"errors": [{{"message": "GraphQL service request timed out",
 "extensions": {{"code": "GATEWAY_TIMEOUT"}}}}]}}`.

## 504 timeout and resubmit

A 504 does not abort the underlying warehouse query — it continues running in the background
regardless of the timeout. Resubmitting the same GraphQL query after back-off is safe:

- If the original warehouse query is still running — it is deduplicated (`AWAIT_PRIMARY`).
  The resubmit waits for the original result; the warehouse query does not execute twice.
- If it already completed — the prior result is served immediately (`REUSE_RESULT`).

No statement ID is needed to resubmit.

{QUERY_GRAPHQL_TIMEOUT_DIAGRAM}

If timeouts recur despite retries, simplify the query (fewer fields, narrower time ranges)
or contact the data product owner.
'''.strip()
METADATA_TAG_DESCRIPTION=f"""
Retrieve data product metadata — model definitions, semantic schema, and lineage graph.

**Base path:** `{v1("/metadata")}`

**Cache policy:** Responses are cached and invalidated on plan changes (new deployment).

- **Metadata** includes model list, data product info, gateway config, and a model-lag status array showing freshness
- **Semantic Schema** is the minimal representation consumed by GraphQL, MySQL wire protocol, and catalog UIs

See the **Exports** tag for BI tool artifact downloads (Power BI, Tableau).
""".strip()
EXPORTS_TAG_DESCRIPTION='Download BI tool integration artifacts (Power BI, Tableau) generated during prod deployment.'
DATA_QUALITY_TAG_DESCRIPTION='Canonical data quality API: product summary and DQ rules with execution history.'
PLANS_TAG_DESCRIPTION='Plan history and git diffs for each deployment of the data product.'
RUNS_TAG_DESCRIPTION='Run history and per-model execution details for each scheduled or triggered execution.'
NOTIFICATIONS_TAG_DESCRIPTION='Notification feed for the data product.'
QUERY_RESULT_TAG_DESCRIPTION=f"""
Poll statement status and retrieve results after any async query submission.

## Query Lifecycle

{QUERY_LIFECYCLE_DIAGRAM}

## Deduplication Strategies

{QUERY_STRATEGIES_DIAGRAM}

{QUERY_STATUS_VALUES}

{QUERY_STRATEGIES}

{RESULT_FORMATS}
""".strip()
DATA_MODEL_QUERY_TAG_DESCRIPTION=''
SEMANTIC_REST_TAG_DESCRIPTION=f"""
Submit semantic REST queries (measures, dimensions, filters,
`POST /query/semantic/rest`).

See **Query Result** tag for submit, poll, and fetch.

{QUERY_COMMON_PARAMS}

{QUERY_TRANSPILE_CALLOUT}
""".strip()
SEMANTIC_SQL_TAG_DESCRIPTION=f"""
Submit SQL that references semantic measures and dimensions
(`POST /query/semantic/sql`).

See **Query Result** tag for submit, poll, and fetch.

{QUERY_COMMON_PARAMS}

{QUERY_TRANSPILE_CALLOUT}
""".strip()
SEMANTIC_GRAPHQL_TAG_DESCRIPTION=f"\nQuery the semantic layer using GraphQL (`POST /query/semantic/graphql`).\n\n{QUERY_GRAPHQL_CALLOUT}\n".strip()
SEMANTIC_METRICS_TAG_DESCRIPTION='\nShorthand for named metric queries (`GET/POST /query/metric/{name}`).\nTranslates to semantic REST internally.\n\nSee **Query Result** tag for submit, poll, and fetch.\n'.strip()
USAGE_METRICS_TAG_DESCRIPTION='\nQuery API usage analytics for the data product (`GET /query/usage-metrics`).\nNot part of the async statement execution flow.\n'.strip()
PERSPECTIVES_TAG_DESCRIPTION=f"""
Saved queries (perspectives) — create, manage, and access cached query results for the data product.

**Base path:** `{v1("/perspectives")}`

A perspective is a saved query with a human-readable slug URL. Perspectives support:

- **Auto-refresh** — re-executes when underlying model data changes
- **Access control** — public (anyone) or private (owner + allowed users)
- **Result caching** — direct access to cached results without re-execution

Execute a query via any `/query/*` endpoint, wait for `SUCCESS`, then `POST /perspectives`
with the statement ID. Share results via `GET /perspectives/{{slug}}/result`.
""".strip()
FOLLOWERS_TAG_DESCRIPTION=f"\nManage followers of a data product — subscribe, unsubscribe, and list followers.\n\n**Base path:** `{v1('/followers')}`\n".strip()
GROUP_DESCRIPTIONS:dict[str,str]={_F:'Metadata and export artifacts for the data product.',_D:'Submit queries and fetch results (async poll-and-fetch).',_J:'Semantic GraphQL; synchronous JSON responses.',_G:'Saved query perspectives.',_H:'Followers and notifications.',_E:'Data quality rules, deployment plans, and runs.',_I:'Liveness and readiness checks.'}
OPENAPI_TAGS:t.List[t.Dict[str,str]]=[{_A:'Metadata',_B:METADATA_TAG_DESCRIPTION,_C:_F},{_A:'Exports',_B:EXPORTS_TAG_DESCRIPTION,_C:_F},{_A:'Query Result',_B:QUERY_RESULT_TAG_DESCRIPTION,_C:_D},{_A:'Semantic REST',_B:SEMANTIC_REST_TAG_DESCRIPTION,_C:_D},{_A:'Semantic SQL',_B:SEMANTIC_SQL_TAG_DESCRIPTION,_C:_D},{_A:'Semantic Metrics',_B:SEMANTIC_METRICS_TAG_DESCRIPTION,_C:_D},{_A:'Usage Metrics',_B:USAGE_METRICS_TAG_DESCRIPTION,_C:_D},{_A:'Semantic GraphQL',_B:SEMANTIC_GRAPHQL_TAG_DESCRIPTION,_C:_J},{_A:_G,_B:PERSPECTIVES_TAG_DESCRIPTION,_C:_G},{_A:'Followers',_B:FOLLOWERS_TAG_DESCRIPTION,_C:_H},{_A:'Notifications',_B:NOTIFICATIONS_TAG_DESCRIPTION,_C:_H},{_A:'Data Quality',_B:DATA_QUALITY_TAG_DESCRIPTION,_C:_E},{_A:'Plans',_B:PLANS_TAG_DESCRIPTION,_C:_E},{_A:'Runs',_B:RUNS_TAG_DESCRIPTION,_C:_E},{_A:_I,_B:HEALTH_TAG_DESCRIPTION,_C:_I}]
def _build_tag_groups()->t.List[t.Dict[str,t.Any]]:
	groups:dict[str,list[str]]={}
	for tag in OPENAPI_TAGS:groups.setdefault(tag[_C],[]).append(tag[_A])
	return[{_A:group_name,_B:GROUP_DESCRIPTIONS[group_name],'tags':tags}for(group_name,tags)in groups.items()]
OPENAPI_TAG_GROUPS:t.List[t.Dict[str,t.Any]]=_build_tag_groups()
OPENAPI_TAG_DESCRIPTIONS:list[tuple[str,str]]=[(tag[_A],tag[_B])for tag in OPENAPI_TAGS]