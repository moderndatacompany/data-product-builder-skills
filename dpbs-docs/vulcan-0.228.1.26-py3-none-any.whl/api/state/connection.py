from __future__ import annotations
_E='fetchval'
_D='execute'
_C='fetch_rows'
_B='fetch_row'
_A=None
import logging,os
from contextlib import asynccontextmanager
from collections.abc import AsyncIterator
import typing as t,asyncpg
from api.state.log_context import get_request_label
logger=logging.getLogger(__name__)
_MAX_SQL_CHARS=500
_MAX_ARG_REPR=200
def _configured_log_level()->int:raw=os.getenv('LOG_LEVEL','INFO').upper();return logging._nameToLevel.get(raw,logging.INFO)
def _truncate_sql(sql:str)->str:
	compact=' '.join(sql.split())
	if len(compact)<=_MAX_SQL_CHARS:return compact
	return f"{compact[:_MAX_SQL_CHARS]}..."
def _repr_sql_args(args:tuple[t.Any,...])->str:
	if not args:return''
	parts:list[str]=[]
	for value in args:
		text=repr(value)
		if len(text)>_MAX_ARG_REPR:text=f"{text[:_MAX_ARG_REPR]}..."
		parts.append(text)
	return f" (args={', '.join(parts)})"
def _log_sql(op:str,sql:str,*args:t.Any)->_A:
	if not logger.isEnabledFor(logging.DEBUG):return
	label=get_request_label();truncated=_truncate_sql(sql);arg_repr=_repr_sql_args(args)
	if label:message='%s SQL (%s): %s%s';message_args:tuple[t.Any,...]=(label,op,truncated,arg_repr)
	else:message='SQL (%s): %s%s';message_args=op,truncated,arg_repr
	logger.log(_configured_log_level(),message,*message_args)
class _ConnContext:
	def __init__(self,conn:asyncpg.Connection,schema:str)->_A:self._conn=conn;self.schema=schema
	async def fetch_row(self,sql:str,*args:t.Any)->t.Optional[t.Dict[str,t.Any]]:_log_sql(_B,sql,*args);row=await self._conn.fetchrow(sql,*args);return dict(row)if row is not _A else _A
	async def fetch_rows(self,sql:str,*args:t.Any)->t.List[t.Dict[str,t.Any]]:_log_sql(_C,sql,*args);rows=await self._conn.fetch(sql,*args);return[dict(row)for row in rows]
	async def execute(self,sql:str,*args:t.Any)->str:_log_sql(_D,sql,*args);return await self._conn.execute(sql,*args)
	async def fetchval(self,sql:str,*args:t.Any)->t.Any:_log_sql(_E,sql,*args);return await self._conn.fetchval(sql,*args)
class StateConnection:
	def __init__(self,pool:asyncpg.Pool,schema:str)->_A:self.pool=pool;self.schema=schema
	async def fetch_row(self,sql:str,*args:t.Any)->t.Optional[t.Dict[str,t.Any]]:
		_log_sql(_B,sql,*args)
		async with self.pool.acquire()as conn:row=await conn.fetchrow(sql,*args)
		return dict(row)if row is not _A else _A
	async def fetch_rows(self,sql:str,*args:t.Any)->t.List[t.Dict[str,t.Any]]:
		_log_sql(_C,sql,*args)
		async with self.pool.acquire()as conn:rows=await conn.fetch(sql,*args)
		return[dict(row)for row in rows]
	async def execute(self,sql:str,*args:t.Any)->str:
		_log_sql(_D,sql,*args)
		async with self.pool.acquire()as conn:return await conn.execute(sql,*args)
	async def fetchval(self,sql:str,*args:t.Any)->t.Any:
		_log_sql(_E,sql,*args)
		async with self.pool.acquire()as conn:return await conn.fetchval(sql,*args)
	@asynccontextmanager
	async def transaction(self)->AsyncIterator[_ConnContext]:
		async with self.pool.acquire()as conn:
			async with conn.transaction():yield _ConnContext(conn,self.schema)