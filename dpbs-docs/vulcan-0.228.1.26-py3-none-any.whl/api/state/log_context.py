from __future__ import annotations
_A=None
from contextvars import ContextVar,Token
_REQUEST_LABEL:ContextVar[str|_A]=ContextVar('api_state_request_label',default=_A)
def bind_request_label(method:str,path:str,*,user_id:str|_A=_A)->Token[str|_A]:
	label=f"{method} {path}"
	if user_id is not _A:label=f"{label} [{user_id}]"
	return _REQUEST_LABEL.set(label)
def reset_request_label(token:Token[str|_A])->_A:_REQUEST_LABEL.reset(token)
def get_request_label()->str|_A:return _REQUEST_LABEL.get()