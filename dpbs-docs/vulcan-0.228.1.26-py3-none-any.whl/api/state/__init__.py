from __future__ import annotations
_A=None
import typing as t
from sqlglot import exp
_PG='postgres'
def _pg(expr:exp.Expression)->str:return expr.sql(dialect=_PG)
def _table(name:str,schema:str)->exp.Table:return exp.table_(name,db=schema)
def _tbl_ident(schema:str,name:str)->str:return f'"{schema}"."{name}"'
def _table_sql(name:str,schema:str)->str:return _table(name,schema).sql(dialect=_PG,identify=True)
def _param(index:int)->exp.Var:return exp.Var(this=f"${index}")
def _lit(value:t.Any)->exp.Expression:
	if isinstance(value,bool):return exp.true()if value else exp.false()
	if isinstance(value,int):return exp.Literal.number(value)
	if value is _A:return exp.null()
	return exp.Literal.string(str(value))
def _col_eq(column:str,value:t.Any,table:t.Optional[str]=_A)->exp.EQ:col=exp.column(column,table)if table else exp.column(column);return col.eq(_lit(value))
class ParamBinder:
	def __init__(self,start:int=1)->_A:(self.values):t.List[t.Any]=[];self._start=start
	def add(self,value:t.Any)->exp.Var:idx=self._start+len(self.values);self.values.append(value);return _param(idx)
	def add_all(self,values:t.Iterable[t.Any])->t.List[exp.Var]:return[self.add(v)for v in values]
def _col_eq_param(column:str,value:t.Any,binder:ParamBinder,table:t.Optional[str]=_A)->exp.EQ:col=exp.column(column,table)if table else exp.column(column);return col.eq(binder.add(value))
from api.state.client import AsyncStateClient
from api.state.connection import StateConnection