from __future__ import annotations
_A4='updated_by'
_A3='created_at'
_A2='description'
_A1='cached_at_ts'
_A0='pgq_job_id'
_z='submitted_ts'
_y='invalidated_by_run_id'
_x='size_bytes'
_w='row_count'
_v='object_store_path'
_u='auto_refresh'
_t='graphql_query'
_s='semantic_query'
_r='query_type'
_q='ttl'
_p='gateway'
_o='normalized_sql'
_n='sql_query'
_m='primary_request_id'
_l='terms'
_k='tags'
_j='pct_savings_wow_pct'
_i='pct_savings'
_h='median_query_time_wow_pct'
_g='median_query_time_ms'
_f='queries_wow_pct'
_e='queries'
_d='repeat_users_wow_pct'
_c='repeat_users'
_b='new_users_wow_pct'
_a='new_users'
_Z='active_users_wow_pct'
_Y='active_users'
_X='is_public'
_W='error_message'
_V='execution_start_ts'
_U='invalidated_ts'
_T='expires_ts'
_S='created_ts'
_R='allowed_user_ids'
_Q='updated_at'
_P='strategy'
_O='rest_query'
_N='meta'
_M='params'
_L='execution_end_ts'
_K='execution_status'
_J='depends_on'
_I=True
_H='references'
_G='result_id'
_F='columns'
_E='perspective_id'
_D='fingerprint'
_C='c'
_B='request_id'
_A=None
import json,logging,typing as t
from datetime import datetime,timedelta,timezone
from decimal import Decimal
import pandas as pd
from sqlglot import exp
from vulcan.core.query.definitions import Perspective,QueryFingerprintResult,QueryRequest,QueryResult,QueryStatus,QueryStrategy,QueryType,ACTIVE_STATUSES,TERMINAL_STATUSES
from vulcan.utils.date import to_timestamp
from api.state import ParamBinder,_PG,_col_eq,_col_eq_param,_lit,_pg,_table
from api.state.connection import StateConnection,_ConnContext
logger=logging.getLogger(__name__)
_Conn=t.Union[StateConnection,_ConnContext]
_USAGE_METRICS_SQL=f"""
WITH base AS (
  SELECT
    COALESCE(submitted_by, 'anonymous') AS submitted_by,
    strategy,
    execution_start_ts,
    execution_end_ts,
    (submitted_ts >= :week_start_ms AND submitted_ts < :week_end_ms) AS is_this_week,
    (submitted_ts >= :prev_week_start_ms AND submitted_ts < :week_start_ms) AS is_prev_week,
    (submitted_ts >= :prev_prev_week_start_ms AND submitted_ts < :prev_week_start_ms) AS is_prev_prev_week
  FROM {{schema}}._query_requests
  WHERE submitted_ts >= :prev_prev_week_start_ms
    AND submitted_ts < :week_end_ms
),
user_flags AS (
  SELECT
    submitted_by,
    BOOL_OR(is_this_week) AS in_this_week,
    BOOL_OR(is_prev_week) AS in_prev_week,
    BOOL_OR(is_prev_prev_week) AS in_prev_prev_week
  FROM base
  GROUP BY submitted_by
),
agg AS (
  SELECT
    COUNT(*) FILTER (WHERE is_this_week) AS total_requests,
    COUNT(*) FILTER (WHERE is_this_week AND strategy = '{QueryStrategy.REUSE_RESULT.value}') AS cache_requests,
    COUNT(DISTINCT submitted_by) FILTER (WHERE is_this_week) AS active_users,
    percentile_cont(0.5) WITHIN GROUP (
      ORDER BY (execution_end_ts - execution_start_ts)
    ) FILTER (
      WHERE is_this_week
        AND execution_start_ts IS NOT NULL
        AND execution_end_ts IS NOT NULL
    ) AS median_ms,
    COUNT(*) FILTER (WHERE is_prev_week) AS total_requests_prev,
    COUNT(*) FILTER (WHERE is_prev_week AND strategy = '{QueryStrategy.REUSE_RESULT.value}') AS cache_requests_prev,
    COUNT(DISTINCT submitted_by) FILTER (WHERE is_prev_week) AS active_users_prev,
    percentile_cont(0.5) WITHIN GROUP (
      ORDER BY (execution_end_ts - execution_start_ts)
    ) FILTER (
      WHERE is_prev_week
        AND execution_start_ts IS NOT NULL
        AND execution_end_ts IS NOT NULL
    ) AS median_ms_prev
  FROM base
),
new_user_count AS (
  SELECT COUNT(*) AS n
  FROM user_flags
  WHERE in_this_week AND NOT in_prev_week
),
new_user_count_prev AS (
  SELECT COUNT(*) AS n
  FROM user_flags
  WHERE in_prev_week AND NOT in_prev_prev_week
),
curr AS (
  SELECT
    a.active_users,
    n.n AS new_users,
    (a.active_users - n.n) AS repeat_users,
    a.total_requests AS queries,
    a.median_ms AS median_query_time_ms,
    (a.cache_requests * 100.0 / NULLIF(a.total_requests, 0)) AS pct_savings
  FROM agg a
  CROSS JOIN new_user_count n
),
prev AS (
  SELECT
    a.active_users_prev,
    np.n AS new_users_prev,
    (a.active_users_prev - np.n) AS repeat_users_prev,
    a.total_requests_prev AS queries_prev,
    a.median_ms_prev AS median_query_time_ms_prev,
    (a.cache_requests_prev * 100.0 / NULLIF(a.total_requests_prev, 0)) AS pct_savings_prev
  FROM agg a
  CROSS JOIN new_user_count_prev np
)
SELECT
  c.active_users,
  c.new_users,
  c.repeat_users,
  c.queries,
  c.median_query_time_ms,
  c.pct_savings,
  ((c.active_users - COALESCE(p.active_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.active_users_prev, 0), 0)) AS active_users_wow_pct,
  ((c.new_users - COALESCE(p.new_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.new_users_prev, 0), 0)) AS new_users_wow_pct,
  ((c.repeat_users - COALESCE(p.repeat_users_prev, 0)) * 100.0 / NULLIF(COALESCE(p.repeat_users_prev, 0), 0)) AS repeat_users_wow_pct,
  ((c.queries - COALESCE(p.queries_prev, 0)) * 100.0 / NULLIF(COALESCE(p.queries_prev, 0), 0)) AS queries_wow_pct,
  ((c.median_query_time_ms - COALESCE(p.median_query_time_ms_prev, 0)) * 100.0 / NULLIF(COALESCE(p.median_query_time_ms_prev, 0), 0)) AS median_query_time_wow_pct,
  (c.pct_savings - COALESCE(p.pct_savings_prev, 0)) AS pct_savings_wow_pct
FROM curr c
CROSS JOIN prev p
"""
def _week_bounds_ms(week_start:datetime|_A=_A)->tuple[int,int,int,int]:
	if week_start is _A:now=datetime.now(timezone.utc);week_start=now.replace(hour=0,minute=0,second=0,microsecond=0)-timedelta(days=now.weekday())
	if week_start.tzinfo is _A:week_start=week_start.replace(tzinfo=timezone.utc)
	else:week_start=week_start.astimezone(timezone.utc)
	week_start_ms=int(week_start.timestamp()*1000);week_end_ms=int((week_start+timedelta(days=7)).timestamp()*1000);prev_week_start_ms=week_start_ms-604800000;prev_prev_week_start_ms=prev_week_start_ms-604800000;return week_start_ms,week_end_ms,prev_week_start_ms,prev_prev_week_start_ms
def _json_safe_number(x:t.Any)->int|float|_A:
	if x is _A:return
	try:
		if pd.isna(x):return
	except Exception:pass
	if hasattr(x,'item'):
		try:x=x.item()
		except Exception:pass
	if isinstance(x,bool):return int(x)
	if isinstance(x,Decimal):return float(x)
	if isinstance(x,(int,float)):return x
def _usage_metrics_defaults()->dict[str,t.Any]:return{_Y:0,_Z:_A,_a:0,_b:_A,_c:0,_d:_A,_e:0,_f:_A,_g:_A,_h:_A,_i:_A,_j:_A}
def _build_asyncpg_sql_and_params(schema:str,week_start_ms:int,week_end_ms:int,prev_week_start_ms:int,prev_prev_week_start_ms:int)->tuple[str,list[t.Any]]:
	sql_template=_USAGE_METRICS_SQL.replace('{schema}',schema);replacements={'week_start_ms':week_start_ms,'week_end_ms':week_end_ms,'prev_week_start_ms':prev_week_start_ms,'prev_prev_week_start_ms':prev_prev_week_start_ms};param_values:list[t.Any]=[];sql=sql_template;idx=1
	for(name,value)in replacements.items():
		placeholder=f":{name}"
		while placeholder in sql:sql=sql.replace(placeholder,f"${idx}",1);param_values.append(value);idx+=1
	return sql,param_values
def _build_usage_metrics_result(row:dict[str,t.Any])->dict[str,t.Any]:
	def _int(key:str)->int:v=_json_safe_number(row.get(key));return int(v or 0)
	def _num(key:str)->int|float|_A:return _json_safe_number(row.get(key))
	return{_Y:_int(_Y),_Z:_num(_Z),_a:_int(_a),_b:_num(_b),_c:_int(_c),_d:_num(_d),_e:_int(_e),_f:_num(_f),_g:_num(_g),_h:_num(_h),_i:_num(_i),_j:_num(_j)}
class StatementContext(t.NamedTuple):request:QueryRequest;primary_request:t.Optional[QueryRequest];result:t.Optional[QueryResult]
def _param_insert(table:exp.Table,columns:t.Sequence[str],values:t.Sequence[t.Any])->t.Tuple[str,t.List[t.Any]]:binder=ParamBinder();insert_stmt=exp.Insert(this=exp.Schema(this=table,expressions=[exp.to_identifier(c)for c in columns]),expression=exp.Values(expressions=[exp.Tuple(expressions=binder.add_all(values))]));return insert_stmt.sql(dialect=_PG,identify=_I),binder.values
def _param_update(table:exp.Table,updates:t.Dict[str,t.Any],where:exp.Expression)->t.Tuple[str,t.List[t.Any]]:binder=ParamBinder();update_stmt=exp.update(table,{col:binder.add(val)for(col,val)in updates.items()},where=where);return update_stmt.sql(dialect=_PG,identify=_I),binder.values
def _parse_request_row(row:t.Dict[str,t.Any])->QueryRequest:
	parsed=dict(row)
	for field in(_M,_N,_O):
		if parsed.get(field)and isinstance(parsed[field],str):
			try:parsed[field]=json.loads(parsed[field])
			except(json.JSONDecodeError,TypeError):logger.warning('Failed to parse %s for request %s',field,str(parsed.get(_B,''))[:16]);parsed[field]=_A
	return QueryRequest(**parsed)
def _parse_result_row(row:t.Dict[str,t.Any])->QueryResult:
	parsed=dict(row)
	if parsed.get(_F)and isinstance(parsed[_F],str):
		try:parsed[_F]=json.loads(parsed[_F])
		except(json.JSONDecodeError,TypeError):logger.warning('Failed to parse columns for result %s',str(parsed.get(_G,''))[:16]);parsed[_F]=[]
	if parsed.get(_H):
		if isinstance(parsed[_H],str):
			try:refs_dict=json.loads(parsed[_H]);parsed[_H]={col:[(r[0],r[1])for r in refs]for(col,refs)in refs_dict.items()}
			except(json.JSONDecodeError,TypeError,IndexError):logger.warning('Failed to parse references for result %s',str(parsed.get(_G,''))[:16]);parsed[_H]=_A
		elif isinstance(parsed[_H],dict):parsed[_H]={col:[(r[0],r[1])if isinstance(r,list)else r for r in refs]for(col,refs)in parsed[_H].items()}
	return QueryResult(**parsed)
def _parse_perspective_row(row:t.Dict[str,t.Any])->Perspective:
	parsed=dict(row)
	for field in(_M,_N,_O):
		if parsed.get(field)and isinstance(parsed[field],str):
			try:parsed[field]=json.loads(parsed[field])
			except(json.JSONDecodeError,TypeError):logger.warning('Failed to parse %s for perspective',field);parsed[field]=_A
	for field in(_J,_k,_l,_R):
		if parsed.get(field)is _A:parsed[field]=[]
	parsed.pop('original_request_id',_A);return Perspective(**parsed)
_RESULT_COLS=[_G,_v,_w,_x,_F,'sql',_H,_S]
_FINGERPRINT_COLS=[_D,_G,_J,_S,_T,_y,_U]
_REQUEST_COLS=[_B,_P,_K,_m,_D,_n,_o,_M,_J,_p,'submitted_by',_z,_q,_N,_r,_s,_O,_t,_E,_A0,_V,_L,_A1,_G,_W]
_PERSPECTIVE_COLS=[_E,'slug','name',_A2,_k,_l,'owner',_B,_D,_n,_o,_M,_p,_q,_N,_r,_s,_O,_t,_J,_u,_X,_R,_A3,_Q,'created_by',_A4]
class AsyncQueryState:
	def __init__(self,conn:StateConnection)->_A:self._conn=conn;schema=conn.schema;self._results_table=_table('_query_results',schema);self._fingerprints_table=_table('_query_fingerprints',schema);self._requests_table=_table('_query_requests',schema);self._perspectives_table=_table('_query_perspective',schema)
	def _request_select(self)->exp.Select:return exp.select(*[exp.column(exp.to_identifier(c,quoted=_I))for c in _REQUEST_COLS]).from_(self._requests_table)
	def _result_select(self)->exp.Select:return exp.select(*[exp.column(exp.to_identifier(c,quoted=_I))for c in _RESULT_COLS]).from_(self._results_table)
	def _perspective_select(self)->exp.Select:return exp.select(*[exp.column(exp.to_identifier(c,quoted=_I))for c in _PERSPECTIVE_COLS]).from_(self._perspectives_table)
	async def get_result_by_id(self,result_id:str)->t.Optional[QueryResult]:
		sql=_pg(self._result_select().where(_col_eq(_G,result_id)));row=await self._conn.fetch_row(sql)
		if row is _A:return
		return _parse_result_row(row)
	async def get_fingerprint_result(self,fingerprint:str)->t.Optional[QueryFingerprintResult]:
		A='r';now_ts=to_timestamp(datetime.now(timezone.utc));query=exp.select(exp.column(_D,_C),exp.column(_G,_C),exp.column(_J,_C),exp.column(_S,_C).as_(_A1),exp.column(_T,_C),exp.column(_y,_C),exp.column(_U,_C),exp.column(_v,A),exp.column(_w,A),exp.column(_x,A),exp.column(_F,A),exp.column(_S,A).as_('result_created_ts')).from_(self._fingerprints_table.as_(_C)).join(self._results_table.as_(A),on=exp.column(_G,_C).eq(exp.column(_G,A))).where(exp.column(_D,_C).eq(_lit(fingerprint))).where(exp.or_(exp.column(_T,_C).is_(exp.null()),exp.column(_T,_C)>_lit(now_ts)));row=await self._conn.fetch_row(_pg(query))
		if row is _A:return
		parsed=dict(row)
		if parsed.get(_F)and isinstance(parsed[_F],str):
			try:parsed[_F]=json.loads(parsed[_F])
			except(json.JSONDecodeError,TypeError):logger.warning('Failed to parse columns for fingerprint %s',str(fingerprint)[:16]);parsed[_F]=[]
		return QueryFingerprintResult(**parsed)
	async def get_request_by_id(self,request_id:str)->t.Optional[QueryRequest]:
		sql=_pg(self._request_select().where(_col_eq(_B,request_id)));row=await self._conn.fetch_row(sql)
		if row is _A:return
		return _parse_request_row(row)
	async def get_statement_context(self,request_id:str)->t.Optional[StatementContext]:
		stmt_req=await self.get_request_by_id(request_id)
		if stmt_req is _A:return
		primary_req:t.Optional[QueryRequest]=_A;result:t.Optional[QueryResult]=_A
		if stmt_req.strategy==QueryStrategy.AWAIT_PRIMARY:
			if stmt_req.primary_request_id:primary_req=await self.get_request_by_id(stmt_req.primary_request_id)
			if primary_req and primary_req.execution_status==QueryStatus.SUCCESS and primary_req.result_id:result=await self.get_result_by_id(primary_req.result_id)
		elif stmt_req.strategy==QueryStrategy.REUSE_RESULT:
			if stmt_req.result_id:result=await self.get_result_by_id(stmt_req.result_id)
		elif stmt_req.execution_status==QueryStatus.SUCCESS and stmt_req.result_id:result=await self.get_result_by_id(stmt_req.result_id)
		return StatementContext(request=stmt_req,primary_request=primary_req,result=result)
	async def get_in_flight_request_by_fingerprint(self,fingerprint:str)->t.Optional[QueryRequest]:
		sql=_pg(self._request_select().where(_col_eq(_D,fingerprint)).where(_col_eq(_P,QueryStrategy.EXECUTE.value)).where(exp.column(_K).isin(*[_lit(s.value)for s in ACTIVE_STATUSES])).order_by(exp.column(_z)).limit(1));row=await self._conn.fetch_row(sql)
		if row is _A:return
		return _parse_request_row(row)
	async def get_recent_failed_execution_by_fingerprint(self,fingerprint:str,window_seconds:int=300)->t.Optional[QueryRequest]:
		cutoff_ts=to_timestamp(datetime.now(timezone.utc)-timedelta(seconds=window_seconds));sql=_pg(self._request_select().where(_col_eq(_D,fingerprint)).where(_col_eq(_P,QueryStrategy.EXECUTE.value)).where(_col_eq(_K,QueryStatus.FAILED.value)).where(exp.column(_L)>_lit(cutoff_ts)).order_by(exp.column(_L).desc()).limit(1));row=await self._conn.fetch_row(sql)
		if row is _A:return
		return _parse_request_row(row)
	async def get_perspective_by_slug(self,slug:str)->t.Optional[Perspective]:
		sql=_pg(self._perspective_select().where(_col_eq('slug',slug)));row=await self._conn.fetch_row(sql)
		if row is _A:return
		return _parse_perspective_row(row)
	async def get_perspective_by_id(self,perspective_id:str)->t.Optional[Perspective]:
		sql=_pg(self._perspective_select().where(_col_eq(_E,perspective_id)));row=await self._conn.fetch_row(sql)
		if row is _A:return
		return _parse_perspective_row(row)
	async def list_perspectives(self,current_user_id:str,is_public:t.Optional[bool]=_A,limit:int=50,offset:int=0)->t.Tuple[t.List[Perspective],bool]:
		A='_user_id';query=self._perspective_select();conditions:t.List[exp.Expression]=[];access_condition=exp.or_(exp.column(_X).eq(exp.true()),exp.column('owner').eq(_lit(current_user_id)),exp.Exists(this=exp.select(exp.Literal.number(1)).from_(exp.Unnest(expressions=[exp.column(_R)],alias=exp.TableAlias(this=exp.to_identifier(A)))).where(exp.column(A).eq(_lit(current_user_id)))));conditions.append(access_condition)
		if is_public is not _A:conditions.append(exp.column(_X).eq(exp.true()if is_public else exp.false()))
		query=query.where(exp.and_(*conditions));query=query.order_by(exp.column(_Q).desc());query=query.limit(limit+1).offset(offset);rows=await self._conn.fetch_rows(_pg(query));has_more=len(rows)>limit
		if has_more:rows=rows[:limit]
		return[_parse_perspective_row(r)for r in rows],has_more
	async def list_perspectives_to_refresh(self,since_ts_ms:int,limit:int=100,offset:int=0)->t.Tuple[t.List[Perspective],bool]:A='p';query=exp.select(*[exp.column(c,A)for c in _PERSPECTIVE_COLS]).from_(self._perspectives_table.as_(A)).join(self._fingerprints_table.as_(_C),on=exp.column(_D,A).eq(exp.column(_D,_C)),join_type='INNER').where(exp.and_(exp.column(_U,_C).is_(exp.null()).not_(),exp.column(_U,_C)>_lit(since_ts_ms),exp.column(_u,A).eq(exp.true()))).distinct().order_by(exp.column(_A3,A),exp.column(_E,A)).limit(limit).offset(offset);rows=await self._conn.fetch_rows(_pg(query));has_more=len(rows)==limit;return[_parse_perspective_row(r)for r in rows],has_more
	async def get_usage_metrics(self,week_start:t.Optional[datetime]=_A)->t.Dict[str,t.Any]:
		week_start_ms,week_end_ms,prev_week_start_ms,prev_prev_week_start_ms=_week_bounds_ms(week_start);sql,param_values=_build_asyncpg_sql_and_params(self._conn.schema,week_start_ms,week_end_ms,prev_week_start_ms,prev_prev_week_start_ms);row=await self._conn.fetch_row(sql,*param_values)
		if row is _A:return _usage_metrics_defaults()
		return _build_usage_metrics_result(dict(row))
	async def create_request(self,request_id:str,strategy:QueryStrategy,fingerprint:str,sql_query:str,normalized_sql:str,params:t.Optional[t.Union[t.Dict,t.List]],gateway:str,submitted_by:t.Optional[str]=_A,depends_on:t.Optional[t.List[str]]=_A,ttl:int=0,meta:t.Optional[t.Dict]=_A,query_type:t.Optional[QueryType]=_A,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[t.Dict]=_A,graphql_query:t.Optional[str]=_A,perspective_id:t.Optional[str]=_A,execution_status:t.Optional[QueryStatus]=_A,primary_request_id:t.Optional[str]=_A,cached_at_ts:t.Optional[int]=_A,result_id:t.Optional[str]=_A)->_A:
		if strategy==QueryStrategy.AWAIT_PRIMARY and not primary_request_id:raise ValueError(f"primary_request_id is required for strategy={QueryStrategy.AWAIT_PRIMARY.value!r}. Request {request_id} cannot be created without a primary request ID.")
		execution_start_ts_value:t.Optional[int]=_A;execution_end_ts_value:t.Optional[int]=_A;primary_request_id_value=primary_request_id
		if strategy==QueryStrategy.REUSE_RESULT and result_id:
			original=await self.get_request_by_id(result_id)
			if not original:raise ValueError(f"Original request not found for cached result: result_id={result_id}.")
			primary_request_id_value=original.primary_request_id or result_id;execution_start_ts_value=original.execution_start_ts;execution_end_ts_value=original.execution_end_ts
		now_ts=to_timestamp(datetime.now(timezone.utc));sql,params=_param_insert(self._requests_table,_REQUEST_COLS,[request_id,strategy.value,execution_status.value if execution_status is not _A else _A,primary_request_id_value,fingerprint,sql_query,normalized_sql,params if params is not _A else _A,depends_on if depends_on else _A,gateway,submitted_by,now_ts,ttl,meta if meta is not _A else _A,query_type.value if query_type is not _A else _A,semantic_query,rest_query if rest_query is not _A else _A,graphql_query,perspective_id,_A,execution_start_ts_value,execution_end_ts_value,cached_at_ts,result_id,_A]);await self._conn.execute(sql,*params)
	async def mark_request_queued(self,request_id:str,pgq_job_id:int)->_A:await self._update_request(request_id,execution_status=QueryStatus.QUEUED,pgq_job_id=pgq_job_id)
	async def mark_request_in_progress(self,request_id:str)->_A:await self._update_request(request_id,execution_status=QueryStatus.IN_PROGRESS,execution_start_ts=to_timestamp(datetime.now(timezone.utc)))
	async def mark_request_failed(self,request_id:str,error_message:str)->_A:await self._update_request(request_id,execution_status=QueryStatus.FAILED,error_message=error_message,execution_end_ts=to_timestamp(datetime.now(timezone.utc)))
	async def mark_request_completed(self,request_id:str,result_id:str,object_store_path:str,row_count:int,size_bytes:int,columns:t.List[t.Dict[str,str]],fingerprint:str,depends_on:t.Optional[t.List[str]]=_A,ttl_minutes:int=0,sql:t.Optional[str]=_A,references:t.Optional[t.Dict[str,t.List[t.Tuple[str,str]]]]=_A)->_A:
		now_ts=to_timestamp(datetime.now(timezone.utc))
		async with self._conn.transaction()as txn:
			await self._store_result_metadata_tx(txn,result_id,object_store_path,row_count,size_bytes,columns,now_ts,sql,references);await self._store_fingerprint_entry_tx(txn,fingerprint,result_id,depends_on,ttl_minutes,now_ts);primary_request=await _get_request_by_id_tx(txn,request_id,self._requests_table);await _update_request_tx(txn,request_id,self._requests_table,execution_status=QueryStatus.SUCCESS,result_id=result_id,execution_end_ts=now_ts);await self._propagate_terminal_status_tx(txn,request_id,QueryStatus.SUCCESS,execution_start_ts=primary_request.execution_start_ts if primary_request else _A,execution_end_ts=now_ts,result_id=result_id)
			if primary_request and primary_request.perspective_id:await self._update_request_id_for_perspective_tx(txn,primary_request.perspective_id,request_id)
		logger.info('Request %s completed successfully (async transactional)',request_id)
	async def create_perspective(self,perspective_id:str,slug:str,request_id:str,fingerprint:str,sql_query:str,name:str,owner:str,normalized_sql:t.Optional[str]=_A,params:t.Optional[t.Union[t.Dict,t.List]]=_A,gateway:t.Optional[str]=_A,ttl:int=0,meta:t.Optional[t.Dict]=_A,query_type:t.Optional[QueryType]=_A,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[t.Dict]=_A,graphql_query:t.Optional[str]=_A,depends_on:t.Optional[t.List[str]]=_A,description:t.Optional[str]=_A,tags:t.Optional[t.List[str]]=_A,terms:t.Optional[t.List[str]]=_A,auto_refresh:bool=_I,is_public:bool=False,allowed_user_ids:t.Optional[t.List[str]]=_A,created_by:t.Optional[str]=_A)->_A:now_ts=to_timestamp(datetime.now(timezone.utc));sql,params=_param_insert(self._perspectives_table,_PERSPECTIVE_COLS,[perspective_id,slug,name,description,tags if tags else _A,terms if terms else _A,owner,request_id,fingerprint,sql_query,normalized_sql,params if params is not _A else _A,gateway,ttl,meta if meta is not _A else _A,query_type.value if query_type is not _A else _A,semantic_query,rest_query if rest_query is not _A else _A,graphql_query,depends_on if depends_on else _A,auto_refresh,is_public,allowed_user_ids if allowed_user_ids else _A,now_ts,now_ts,created_by or owner,created_by or owner]);await self._conn.execute(sql,*params);logger.info('Created perspective %s (slug=%s)',perspective_id,slug)
	async def update_perspective(self,perspective_id:str,request_id:t.Optional[str]=_A,fingerprint:t.Optional[str]=_A,sql_query:t.Optional[str]=_A,normalized_sql:t.Optional[str]=_A,params:t.Optional[t.Union[t.Dict,t.List]]=_A,gateway:t.Optional[str]=_A,ttl:t.Optional[int]=_A,meta:t.Optional[t.Dict]=_A,query_type:t.Optional[QueryType]=_A,semantic_query:t.Optional[str]=_A,rest_query:t.Optional[t.Dict]=_A,graphql_query:t.Optional[str]=_A,depends_on:t.Optional[t.List[str]]=_A,updated_by:t.Optional[str]=_A,**kwargs:t.Any)->_A:
		now_ts=to_timestamp(datetime.now(timezone.utc));updates:t.Dict[str,t.Any]={_Q:now_ts};has_query_fields=any(v is not _A for v in[sql_query,normalized_sql,params,gateway,ttl,meta,query_type.value if query_type is not _A else _A,semantic_query,rest_query,graphql_query,depends_on])
		if has_query_fields and fingerprint is _A:raise ValueError('fingerprint must be provided when updating query definition fields')
		if fingerprint is not _A:updates[_D]=fingerprint
		if sql_query is not _A:updates[_n]=sql_query
		if normalized_sql is not _A:updates[_o]=normalized_sql
		if params is not _A:updates[_M]=params
		if gateway is not _A:updates[_p]=gateway
		if ttl is not _A:updates[_q]=ttl
		if meta is not _A:updates[_N]=meta
		if query_type is not _A:updates[_r]=query_type.value
		if semantic_query is not _A:updates[_s]=semantic_query
		if rest_query is not _A:updates[_O]=rest_query
		if graphql_query is not _A:updates[_t]=graphql_query
		if depends_on is not _A:updates[_J]=depends_on if depends_on else _A
		if request_id is not _A:updates[_B]=request_id
		if updated_by is not _A:updates[_A4]=updated_by
		for kw_field in('name',_A2,_k,_l,_u,_X,_R):
			if kw_field in kwargs:updates[kw_field]=kwargs[kw_field]
		if len(updates)==1:logger.warning('No fields to update for perspective %s',perspective_id);return
		sql,params=_param_update(self._perspectives_table,updates,exp.column(_E).eq(_lit(perspective_id)));await self._conn.execute(sql,*params)
	async def delete_perspective(self,perspective_id:str)->_A:binder=ParamBinder();delete_stmt=exp.delete(self._perspectives_table,where=_col_eq_param(_E,perspective_id,binder));await self._conn.execute(_pg(delete_stmt),*binder.values);logger.info('Deleted perspective %s',perspective_id)
	async def update_request_id_for_perspective(self,perspective_id:str,request_id:str)->_A:
		new_request=await self.get_request_by_id(request_id)
		if not new_request:logger.warning('Request %s not found, skipping perspective update',request_id);return
		now_ts=to_timestamp(datetime.now(timezone.utc));binder=ParamBinder();update_stmt=exp.update(self._perspectives_table,{_B:binder.add(request_id),_Q:binder.add(now_ts)},where=exp.and_(_col_eq_param(_E,perspective_id,binder),_col_eq_param(_D,new_request.fingerprint,binder)));await self._conn.execute(_pg(update_stmt),*binder.values)
	async def _update_request(self,request_id:str,execution_status:t.Optional[QueryStatus]=_A,pgq_job_id:t.Optional[int]=_A,execution_start_ts:t.Optional[int]=_A,execution_end_ts:t.Optional[int]=_A,result_id:t.Optional[str]=_A,error_message:t.Optional[str]=_A)->_A:
		updates:t.Dict[str,t.Any]={}
		if execution_status is not _A:updates[_K]=execution_status.value
		if pgq_job_id is not _A:updates[_A0]=pgq_job_id
		if execution_start_ts is not _A:updates[_V]=execution_start_ts
		if execution_end_ts is not _A:updates[_L]=execution_end_ts
		if result_id is not _A:updates[_G]=result_id
		if error_message is not _A:updates[_W]=error_message
		if not updates:logger.warning('No properties to update for request %s',request_id);return
		sql,params=_param_update(self._requests_table,updates,exp.column(_B).eq(_lit(request_id)));await self._conn.execute(sql,*params);terminal_statuses=TERMINAL_STATUSES
		if execution_status in terminal_statuses:
			request=await self.get_request_by_id(request_id)
			if request:await self._propagate_terminal_status(request_id,execution_status=execution_status,execution_start_ts=request.execution_start_ts or execution_start_ts,execution_end_ts=execution_end_ts or to_timestamp(datetime.now(timezone.utc)),result_id=result_id,error_message=error_message or('Failed because primary request failed'if execution_status==QueryStatus.FAILED else _A))
	async def _propagate_terminal_status(self,primary_request_id:str,execution_status:QueryStatus,execution_start_ts:t.Optional[int],execution_end_ts:int,result_id:t.Optional[str]=_A,error_message:t.Optional[str]=_A)->_A:
		binder=ParamBinder();awaiting_query=exp.select(exp.column(_B),exp.column(_E)).from_(self._requests_table).where(exp.and_(_col_eq_param(_P,QueryStrategy.AWAIT_PRIMARY.value,binder),_col_eq_param(_m,primary_request_id,binder)));awaiting=await self._conn.fetch_rows(_pg(awaiting_query),*binder.values)
		if not awaiting:return
		awaiting_ids=[r[_B]for r in awaiting];updates:t.Dict[str,t.Any]={_K:execution_status.value,_V:execution_start_ts,_L:execution_end_ts}
		if execution_status==QueryStatus.SUCCESS and result_id:updates[_G]=result_id
		if execution_status==QueryStatus.FAILED and error_message:updates[_W]=error_message
		batch_binder=ParamBinder();set_exprs={col:batch_binder.add(val)for(col,val)in updates.items()};id_placeholders=batch_binder.add_all(awaiting_ids);batch_sql=_pg(exp.update(self._requests_table,set_exprs,where=exp.column(_B).isin(*id_placeholders)));await self._conn.execute(batch_sql,*batch_binder.values);logger.info('Updated %d awaiting request(s) to %s (primary=%s)',len(awaiting_ids),execution_status.lower(),primary_request_id)
		for row in awaiting:
			if row.get(_E):await self.update_request_id_for_perspective(row[_E],row[_B])
	async def _store_result_metadata_tx(self,txn:_ConnContext,result_id:str,object_store_path:str,row_count:int,size_bytes:int,columns:t.List[t.Dict[str,str]],created_ts:int,sql:t.Optional[str],references:t.Optional[t.Dict[str,t.List[t.Tuple[str,str]]]])->_A:
		references_obj=_A
		if references:references_obj={col:[[m,f]for(m,f)in refs]for(col,refs)in references.items()}
		insert_sql,params=_param_insert(self._results_table,_RESULT_COLS,[result_id,object_store_path,row_count,size_bytes,columns,sql,references_obj,created_ts]);await txn.execute(insert_sql,*params)
	async def _store_fingerprint_entry_tx(self,txn:_ConnContext,fingerprint:str,result_id:str,depends_on:t.Optional[t.List[str]],ttl_minutes:t.Optional[int],created_ts:int)->_A:
		binder=ParamBinder();delete_stmt=exp.delete(self._fingerprints_table,where=_col_eq_param(_D,fingerprint,binder));await txn.execute(_pg(delete_stmt),*binder.values);expires_ts=_A
		if ttl_minutes:expires_dt=datetime.now(timezone.utc)+timedelta(minutes=ttl_minutes);expires_ts=to_timestamp(expires_dt)
		insert_sql,params=_param_insert(self._fingerprints_table,_FINGERPRINT_COLS,[fingerprint,result_id,depends_on if depends_on else _A,created_ts,expires_ts,_A,_A]);await txn.execute(insert_sql,*params)
	async def _propagate_terminal_status_tx(self,txn:_ConnContext,primary_request_id:str,execution_status:QueryStatus,execution_start_ts:t.Optional[int],execution_end_ts:int,result_id:t.Optional[str]=_A,error_message:t.Optional[str]=_A)->_A:
		binder=ParamBinder();awaiting_query=exp.select(exp.column(_B),exp.column(_E)).from_(self._requests_table).where(exp.and_(_col_eq_param(_P,QueryStrategy.AWAIT_PRIMARY.value,binder),_col_eq_param(_m,primary_request_id,binder)));awaiting=await txn.fetch_rows(_pg(awaiting_query),*binder.values)
		if not awaiting:return
		awaiting_ids=[r[_B]for r in awaiting];updates:t.Dict[str,t.Any]={_K:execution_status.value,_V:execution_start_ts,_L:execution_end_ts}
		if execution_status==QueryStatus.SUCCESS and result_id:updates[_G]=result_id
		if execution_status==QueryStatus.FAILED and error_message:updates[_W]=error_message
		batch_binder=ParamBinder();set_exprs={col:batch_binder.add(val)for(col,val)in updates.items()};id_placeholders=batch_binder.add_all(awaiting_ids);batch_sql=_pg(exp.update(self._requests_table,set_exprs,where=exp.column(_B).isin(*id_placeholders)));await txn.execute(batch_sql,*batch_binder.values)
		for row in awaiting:
			if row.get(_E):await self._update_request_id_for_perspective_tx(txn,row[_E],row[_B])
	async def _update_request_id_for_perspective_tx(self,txn:_ConnContext,perspective_id:str,request_id:str)->_A:
		binder=ParamBinder();fingerprint_query=exp.select(exp.column(_D)).from_(self._requests_table).where(_col_eq_param(_B,request_id,binder));row=await txn.fetch_row(_pg(fingerprint_query),*binder.values)
		if not row:logger.warning('Request %s not found, skipping perspective update in tx',request_id);return
		now_ts=to_timestamp(datetime.now(timezone.utc));update_binder=ParamBinder();update_stmt=exp.update(self._perspectives_table,{_B:update_binder.add(request_id),_Q:update_binder.add(now_ts)},where=exp.and_(_col_eq_param(_E,perspective_id,update_binder),_col_eq_param(_D,row[_D],update_binder)));await txn.execute(_pg(update_stmt),*update_binder.values)
async def _get_request_by_id_tx(txn:_ConnContext,request_id:str,requests_table:exp.Table)->t.Optional[QueryRequest]:
	binder=ParamBinder();query=exp.select(*[exp.column(c)for c in _REQUEST_COLS]).from_(requests_table).where(_col_eq_param(_B,request_id,binder));row=await txn.fetch_row(_pg(query),*binder.values)
	if row is _A:return
	return _parse_request_row(row)
async def _update_request_tx(txn:_ConnContext,request_id:str,requests_table:exp.Table,**updates:t.Any)->_A:sql,params=_param_update(requests_table,updates,exp.column(_B).eq(_lit(request_id)));await txn.execute(sql,*params)