from __future__ import annotations
_E='success'
_D=True
_C='start_ts'
_B='environment'
_A=None
import logging,typing as t
from sqlglot import exp
from vulcan.core.activity import EnvironmentChange,PlanActivity
from api.state import ParamBinder,_col_eq_param,_pg,_table,_table_sql
from api.state.connection import StateConnection
logger=logging.getLogger(__name__)
class AsyncActivityState:
	def __init__(self,conn:StateConnection)->_A:self._conn=conn;self._schema=conn.schema;self._plans_table=_table('_plans',self._schema);self._runs_table=_table('_runs',self._schema)
	async def list_plans(self,plan_id:t.Optional[str]=_A,environment:t.Optional[str]=_A,plan_seq:t.Optional[int]=_A,model_names:t.Optional[t.List[str]]=_A,success:t.Optional[bool]=_A,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A,limit:int=20,offset:int=0)->t.List[PlanActivity]:
		B='plan_diff';A='plan_seq';order=exp.Ordered(this=exp.column(_C),desc=_D);binder=ParamBinder()
		if plan_id:query=exp.select(exp.column(B),exp.column(A)).from_(self._plans_table).where(_col_eq_param('plan_id',plan_id,binder)).order_by(order)
		else:
			if environment is _A:return[]
			conditions:t.List[exp.Expression]=[_col_eq_param(_B,environment,binder)]
			if plan_seq is not _A:conditions.append(_col_eq_param(A,plan_seq,binder))
			if model_names:conditions.append(exp.ArrayOverlaps(this=exp.column('models_affected_directly'),expression=binder.add(model_names)))
			if success is not _A:conditions.append(exp.column(_E).eq(exp.true()if success else exp.false()))
			start_ms=start_ts*1000 if start_ts is not _A else _A;end_ms=end_ts*1000 if end_ts is not _A else _A
			if start_ms is not _A:conditions.append(exp.GTE(this=exp.column(_C),expression=binder.add(start_ms)))
			if end_ms is not _A:conditions.append(exp.LTE(this=exp.column(_C),expression=binder.add(end_ms)))
			query=exp.select(exp.column(B),exp.column(A)).from_(self._plans_table).where(exp.and_(*conditions)).order_by(order).limit(binder.add(limit)).offset(binder.add(offset))
		rows=await self._conn.fetch_rows(_pg(query),*binder.values);plans:t.List[PlanActivity]=[]
		for row in rows:
			plan_diff_json=row.get(B);plan_seq_val=row.get(A)
			if not plan_diff_json:continue
			if isinstance(plan_diff_json,str):plan_activity=PlanActivity.parse_raw(plan_diff_json)
			else:plan_activity=PlanActivity.model_validate(plan_diff_json)
			plans.append(plan_activity.model_copy(update={A:plan_seq_val}))
		return plans
	async def fetch_plan_run_activity_since(self,since_ts_ns:int=0)->t.Tuple[t.List[EnvironmentChange],int]:
		B='action_type';A='created_ts_ns';binder=ParamBinder();watermark=binder.add(since_ts_ns);plans_query=exp.select(_B,exp.Literal.string('plan').as_(B),A).from_(self._plans_table).where(exp.GT(this=exp.column(A),expression=watermark));runs_query=exp.select(_B,exp.Literal.string('run').as_(B),A).from_(self._runs_table).where(exp.GT(this=exp.column(A),expression=watermark));combined_query=exp.union(plans_query,runs_query,distinct=False);combined_query=combined_query.order_by(exp.Ordered(this=exp.column(A),desc=_D));rows=await self._conn.fetch_rows(_pg(combined_query),*binder.values)
		if not rows:return[],since_ts_ns
		changes_dict:t.Dict[str,EnvironmentChange]={};max_ts_ns=since_ts_ns
		for row in rows:
			env_name=row[_B];action_type=row[B];ts=row[A];change=changes_dict.setdefault(env_name,EnvironmentChange(environment=env_name));setattr(change,f"has_{action_type}",_D)
			if ts>max_ts_ns:max_ts_ns=ts
		return list(changes_dict.values()),max_ts_ns
	async def get_last_successful_run_end_ts_by_model(self,environment:str)->t.Dict[str,int]:runs_table_str=_table_sql('_runs',self._schema);sql=f"""
            SELECT
                model_name,
                MAX(end_ts) AS ts
            FROM {runs_table_str} r
            CROSS JOIN LATERAL unnest(r.models_affected) AS model_name
            WHERE r.environment = $1
                AND r.success = true
                AND r.models_affected IS NOT NULL
            GROUP BY model_name
        """;rows=await self._conn.fetch_rows(sql,environment);return{row['model_name']:row['ts']for row in rows}
	async def get_latest_run_for_environment(self,environment:str)->t.Optional[t.Tuple[bool,t.Optional[int]]]:
		A='end_ts';binder=ParamBinder();query=exp.select(exp.column(_E),exp.column(A)).from_(self._runs_table).where(_col_eq_param(_B,environment,binder)).order_by(exp.Ordered(this=exp.column(_C),desc=_D)).limit(1);row=await self._conn.fetch_row(_pg(query),*binder.values)
		if row is _A:return
		success_raw=row.get(_E)
		if success_raw is _A:return
		end_ts_raw=row.get(A);return bool(success_raw),end_ts_raw