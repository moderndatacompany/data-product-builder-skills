import logging
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_redoc_html
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from scalar_fastapi import Layout,Theme,get_scalar_api_reference
from starlette.middleware.gzip import GZipMiddleware
from api.urls import API_V1_PREFIX
from api.endpoints import api_router,root_router
from api.exceptions import register_exception_handlers
from api.main import lifespan
from api.config import cors_allow_headers,cors_allow_methods,get_settings
from api.middleware import AuthorizationMiddleware,CacheHeadersMiddleware,DocSecurityHeadersMiddleware,RequestContextMiddleware,VulcanMetricsMiddleware
from api.openapi import OPENAPI_DESCRIPTION,OPENAPI_TITLE,build_openapi_tags,get_openapi_version,install_openapi_extensions
from api.startup import get_env_context_manager
logger=logging.getLogger(__name__)
def create_app()->FastAPI:
	A=False;settings=get_settings();manager=get_env_context_manager(str(settings.project_path),settings.config);default_env=manager.context.config.default_target_environment;tenant=manager.context.config.tenant;product=manager.context.config.project;heimdall_config=manager.context.config.heimdall;app=FastAPI(title=OPENAPI_TITLE,version=get_openapi_version(),description=OPENAPI_DESCRIPTION,lifespan=lifespan,openapi_tags=build_openapi_tags(),redoc_url=None,swagger_ui_parameters={'syntaxHighlight.theme':'monokai'},redirect_slashes=A);app.add_middleware(RequestContextMiddleware);app.add_middleware(AuthorizationMiddleware,heimdall_config=heimdall_config,project_path=Path(settings.project_path));app.add_middleware(VulcanMetricsMiddleware,tenant=tenant,data_product=product);app.add_middleware(GZipMiddleware,minimum_size=1024);app.add_middleware(CacheHeadersMiddleware);app.add_middleware(CORSMiddleware,allow_origins=settings.cors_allow_origins,allow_credentials=True,allow_methods=cors_allow_methods(),allow_headers=cors_allow_headers());app.add_middleware(DocSecurityHeadersMiddleware)
	@app.get('/redoc',include_in_schema=A)
	async def custom_redoc_html()->HTMLResponse:return get_redoc_html(openapi_url=app.openapi_url,title=f"{app.title} - ReDoc",redoc_js_url='https://cdn.jsdelivr.net/npm/redoc@2.1.3/bundles/redoc.standalone.js')
	@app.get('/scalar',include_in_schema=A)
	async def scalar_html()->HTMLResponse:return get_scalar_api_reference(openapi_url=app.openapi_url,title=f"{app.title} - Scalar",layout=Layout.MODERN,theme=Theme.NONE,persist_auth=True,show_developer_tools='always')
	app.include_router(root_router);app.include_router(api_router,prefix=API_V1_PREFIX);_diagrams_dir=Path(__file__).parent/'openapi'/'diagrams';app.mount('/openapi/diagrams',StaticFiles(directory=str(_diagrams_dir)),name='openapi-diagrams');register_exception_handlers(app);install_openapi_extensions(app,manager,default_env);return app
app=create_app()