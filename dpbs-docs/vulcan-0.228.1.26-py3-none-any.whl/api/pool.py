from __future__ import annotations
_C=False
_B=True
_A=None
import asyncio,contextvars,enum,logging,typing as t
from concurrent.futures import Future,ThreadPoolExecutor
from concurrent.futures import wait as futures_wait
from threading import Lock
from api.utils.commons import parse_positive_float_env,parse_positive_int_env
logger=logging.getLogger(__name__)
T=t.TypeVar('T')
_executors:t.Dict['Pool',ThreadPoolExecutor]={}
_executor_lock=Lock()
_shutdown_requested=_C
_pools_boot_configured=_C
_anyio_configured=_C
_pending_futures:t.Set[Future]=set()
_pending_lock=Lock()
class Pool(enum.Enum):FAST='fast';HEAVY='heavy';ANYIO='anyio'
_POOL_SIZES:t.Dict[Pool,int]={Pool.FAST:parse_positive_int_env('VULCAN_FAST_IO_WORKERS',default=8,floor=1,ceiling=64),Pool.HEAVY:parse_positive_int_env('VULCAN_HEAVY_IO_WORKERS',default=24,floor=1,ceiling=512),Pool.ANYIO:parse_positive_int_env('VULCAN_ANY_IO_THREADS',default=40,floor=40,ceiling=1000)}
_EXECUTOR_POOLS:frozenset[Pool]=frozenset({Pool.FAST,Pool.HEAVY})
_THREAD_PREFIX:t.Dict[Pool,str]={Pool.FAST:'VulcanFastIO',Pool.HEAVY:'VulcanHeavyIO'}
_SHUTDOWN_DRAIN_TIMEOUT_S=parse_positive_float_env('VULCAN_THREAD_POOL_SHUTDOWN_DRAIN_S',default=1e1,floor=.0,ceiling=6e1)
def _boot_size_snapshot()->t.Dict[str,int]:return{pool.value:_POOL_SIZES[pool]for pool in Pool}
def _configure_anyio_limiter()->int:
	global _anyio_configured;import anyio.to_thread;workers=_POOL_SIZES[Pool.ANYIO];limiter=anyio.to_thread.current_default_thread_limiter()
	try:limiter.total_tokens=workers;_anyio_configured=_B;return workers
	except Exception as exc:
		logger.warning('Failed to configure anyio thread limiter: %s',exc)
		try:limiter.total_tokens=_POOL_SIZES[Pool.ANYIO];_anyio_configured=_B
		except Exception:_anyio_configured=_C
		return _POOL_SIZES[Pool.ANYIO]
def configure_thread_pools()->t.Dict[str,int]:
	global _pools_boot_configured
	if _pools_boot_configured:return _boot_size_snapshot()
	try:asyncio.get_running_loop();_configure_anyio_limiter()
	except RuntimeError:logger.warning('configure_thread_pools: no running event loop; anyio limiter not configured (call from lifespan)')
	_init_executor(Pool.FAST);_init_executor(Pool.HEAVY);_pools_boot_configured=_B;sizes=_boot_size_snapshot();logger.info('Thread pools configured: anyio=%d, fast=%d, heavy=%d',sizes['anyio'],sizes['fast'],sizes['heavy']);return sizes
def _init_executor(pool:Pool)->ThreadPoolExecutor:
	if pool not in _EXECUTOR_POOLS:raise ValueError(f"{pool!r} is not a ThreadPoolExecutor pool (use ANYIO limiter only)")
	global _executors
	with _executor_lock:
		if _shutdown_requested:raise RuntimeError(f"Vulcan thread pool shut down (requested pool: {pool.value})")
		executor=_executors.get(pool)
		if executor is not _A:return executor
		size=_POOL_SIZES[pool];prefix=_THREAD_PREFIX[pool];executor=ThreadPoolExecutor(max_workers=size,thread_name_prefix=prefix);_executors[pool]=executor;logger.info('Initialized %s thread pool (pool=%s, max_workers=%d)',prefix,pool.value,size);return executor
def _track_future(fut:Future)->Future:
	with _pending_lock:_pending_futures.add(fut)
	fut.add_done_callback(_untrack_future);return fut
def _untrack_future(fut:Future)->_A:
	with _pending_lock:_pending_futures.discard(fut)
def shutdown_thread_pools()->_A:
	global _executors,_shutdown_requested
	with _executor_lock:
		if _shutdown_requested:return
		_shutdown_requested=_B;executors_snapshot,_executors=dict(_executors),{}
	if not executors_snapshot:return
	with _pending_lock:pending_snapshot=set(_pending_futures)
	for(pool_enum,executor)in executors_snapshot.items():
		try:executor.shutdown(wait=_C,cancel_futures=_B)
		except Exception:logger.warning('%s executor shutdown raised',_THREAD_PREFIX[pool_enum],exc_info=_B)
	if not pending_snapshot:return
	if _SHUTDOWN_DRAIN_TIMEOUT_S<=0:logger.info('Thread pool drain skipped (timeout=0); %d task(s) left in-flight',len(pending_snapshot));return
	_,not_done=futures_wait(pending_snapshot,timeout=_SHUTDOWN_DRAIN_TIMEOUT_S)
	if not_done:logger.warning('Thread pool drain: %d task(s) still running after %.1fs',len(not_done),_SHUTDOWN_DRAIN_TIMEOUT_S)
async def _run_on_pool(pool:Pool,func:t.Callable[...,T],args:tuple[t.Any,...],kwargs:dict[str,t.Any],timeout:float|_A)->T:
	executor=_init_executor(pool);loop=asyncio.get_running_loop();ctx=contextvars.copy_context()
	def _invoke()->T:return ctx.run(func,*args,**kwargs)
	cfut=executor.submit(_invoke);_track_future(cfut);afut=asyncio.wrap_future(cfut,loop=loop)
	if timeout is _A:return await afut
	try:return await asyncio.wait_for(afut,timeout=timeout)
	except asyncio.TimeoutError:logger.warning('%s(%s, pool=%s) exceeded %.2fs; worker thread continues','run_blocking_fast'if pool is Pool.FAST else'run_blocking_heavy',getattr(func,'__qualname__',repr(func)),pool.value,timeout);raise
async def run_blocking_fast(func:t.Callable[...,T],*args:t.Any,timeout:float|_A=_A,**kwargs:t.Any)->T:return await _run_on_pool(Pool.FAST,func,args,kwargs,timeout)
async def run_blocking_heavy(func:t.Callable[...,T],*args:t.Any,timeout:float|_A=_A,**kwargs:t.Any)->T:return await _run_on_pool(Pool.HEAVY,func,args,kwargs,timeout)
def get_executor_stats()->dict[str,t.Any]:
	B='initialized';A='max_workers';pools_stats:dict[str,t.Any]={}
	for pool in Pool:
		if pool is Pool.ANYIO:pools_stats[pool.value]={'configured':_anyio_configured,A:_POOL_SIZES[pool]};continue
		executor=_executors.get(pool)
		if executor is _A:pools_stats[pool.value]={B:_C,A:_POOL_SIZES[pool]}
		else:pools_stats[pool.value]={B:_B,A:executor._max_workers,'threads':len(executor._threads),'pending':executor._work_queue.qsize()}
	return{'boot_configured':_pools_boot_configured,'pools':pools_stats,'tracked_inflight':len(_pending_futures),'shutdown':_shutdown_requested}