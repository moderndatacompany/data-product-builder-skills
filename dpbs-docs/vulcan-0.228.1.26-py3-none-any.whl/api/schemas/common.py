from __future__ import annotations
_B=None
_A=True
import typing as t
from pydantic import ConfigDict,Field as PydanticField
from vulcan.utils.pydantic import PydanticModel
class Link(PydanticModel):model_config=ConfigDict(populate_by_name=_A,exclude_none=_A);href:str;method:t.Optional[str]=_B;type:t.Optional[str]=_B;title:t.Optional[str]=_B;templated:t.Optional[bool]=_B
class SelfLink(PydanticModel):
	model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias='self',serialization_alias='self')
	@classmethod
	def from_href(cls,href:str)->'SelfLink':return cls.model_construct(self_link=Link(href=href))
class Pagination(PydanticModel):model_config=ConfigDict(populate_by_name=_A);limit:int;offset:int;has_more:bool;order_by:str;order_direction:str