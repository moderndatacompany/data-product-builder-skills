from __future__ import annotations
_F='HATEOAS links to related resources'
_E='Self reference link'
_D='_links'
_C='self'
_B=None
_A=True
import typing as t
from pydantic import ConfigDict,Field as PydanticField
from api.schemas.common import Link,Pagination
from vulcan.core.activity import PlanActivity,RunActivityWithChecksAndProfile
from vulcan.utils.pydantic import PydanticModel
class PlanLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias=_C,serialization_alias=_C,description=_E);previous:t.Optional[Link]=PydanticField(default=_B,description='Link to previous plan');commit:t.Optional[Link]=PydanticField(default=_B,description='Link to the plan commit');git_diff:t.Optional[Link]=PydanticField(default=_B,description='Link to the plan git diff')
class PlanGitDiffLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias=_C,serialization_alias=_C,description=_E);current_plan:Link=PydanticField(description='Link to the current plan');previous_plan:t.Optional[Link]=PydanticField(default=_B,description='Link to the previous plan')
class GitCommitDetail(PydanticModel):model_config=ConfigDict(populate_by_name=_A);sha:str;message:str;author_name:str;author_email:str;authored_at:str;commit_url:t.Optional[str]=_B
class Plan(PlanActivity):
	model_config=ConfigDict(populate_by_name=_A);links:PlanLinks=PydanticField(alias=_D,serialization_alias=_D,description=_F)
	@classmethod
	def from_core(cls,plan_activity:PlanActivity,links:PlanLinks)->'Plan':return cls(**plan_activity.model_dump(exclude_none=_A),links=links)
class PlanGitDiffResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);git_diff:t.Optional[str]=_B;commits:t.List[GitCommitDetail]=PydanticField(default_factory=list);message:t.Optional[str]=_B;truncated:bool=PydanticField(default=False,description='True when ``git_diff`` was trimmed to ``MAX_GIT_DIFF_SIZE`` bytes. Clients should treat ``git_diff`` as a best-effort prefix and fetch the commit range directly for the full diff.');links:PlanGitDiffLinks=PydanticField(alias=_D,serialization_alias=_D,description=_F)
class RunLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_A);self_link:Link=PydanticField(alias=_C,serialization_alias=_C,description=_E);plan:t.Optional[Link]=PydanticField(default=_B,description='Link to associated plan')
class RunDetail(RunActivityWithChecksAndProfile):model_config=ConfigDict(populate_by_name=_A);links:RunLinks=PydanticField(alias=_D,serialization_alias=_D,description=_F)
class ModelRunsResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);model_name:str;environment:str;runs:t.List[RunDetail];total:int;pagination:Pagination
class RunsListResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);environment:str;runs:t.List[RunDetail];total:int;pagination:Pagination
class ModelLatestRun(PydanticModel):model_config=ConfigDict(populate_by_name=_A);model_name:str;run:t.Optional[RunDetail]=_B
class ModelsLatestRunsResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);environment:str;models:t.List[ModelLatestRun]
class PlansListResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_A);environment:str;plans:t.List[Plan];total:int;pagination:Pagination