from __future__ import annotations
_I='Number of jobs with this status/priority'
_H='Number of aggregated log entries'
_G="Exception traceback if status is 'exception'"
_F='ISO timestamp when log entry was created'
_E='Job ID'
_D='Job status'
_C='Job priority'
_B='Entrypoint name'
_A=None
import typing as t
from pydantic import BaseModel,Field
class JobStatusResponse(BaseModel):job_id:int=Field(...,description=_E);status:str=Field(...,description='Current job status (queued, picked, successful, canceled, exception)')
class JobLogEntry(BaseModel):created:t.Optional[str]=Field(_A,description=_F);status:str=Field(...,description='Job status at this log entry');priority:int=Field(...,description=_C);entrypoint:str=Field(...,description=_B);traceback:t.Optional[dict]=Field(_A,description=_G);aggregated:t.Optional[int]=Field(_A,description=_H)
class JobHistoryResponse(BaseModel):job_id:int=Field(...,description=_E);logs:t.List[JobLogEntry]=Field(...,description='List of log entries for this job');count:int=Field(...,description='Total number of log entries')
class QueueStatistic(BaseModel):entrypoint:str=Field(...,description=_B);status:str=Field(...,description=_D);priority:int=Field(...,description=_C);count:int=Field(...,description=_I)
class QueueLogEntry(BaseModel):job_id:int=Field(...,description='PGQ job ID');created:t.Optional[str]=Field(_A,description=_F);status:str=Field(...,description=_D);priority:int=Field(...,description=_C);entrypoint:str=Field(...,description=_B);traceback:t.Optional[dict]=Field(_A,description=_G);aggregated:t.Optional[int]=Field(_A,description=_H)
class LogStatistic(BaseModel):created:t.Optional[str]=Field(_A,description='ISO timestamp when statistic was created');entrypoint:str=Field(...,description=_B);status:str=Field(...,description=_D);priority:int=Field(...,description=_C);count:int=Field(...,description=_I)
class EntrypointInfo(BaseModel):name:str=Field(...,description=_B);concurrency_limit:int=Field(...,description='Maximum concurrent jobs allowed');requests_per_second:float=Field(...,description='Maximum requests per second');retry_timer_seconds:t.Optional[float]=Field(_A,description='Retry timer in seconds (only set if configured)')