from __future__ import annotations
_I='Query parameters (dict for named params or list for positional params)'
_H='SHA-256 hash of normalized SQL + params'
_G='HATEOAS links'
_F='ignore'
_E='extra'
_D='populate_by_name'
_C='_links'
_B=True
_A=None
import typing as t
from dataclasses import dataclass
from typing import TYPE_CHECKING
from pydantic import Field as PydanticField
from api.schemas.common import Link,Pagination
from api.utils.commons import timestamp_to_iso
from schema.rest_query import RestQuery
from vulcan.core.query.definitions import QueryStatus,QueryStrategy,QueryType
from vulcan.core.types import Tag,Term
from vulcan.utils.pydantic import PydanticModel
if TYPE_CHECKING:from vulcan.core.query.definitions import Perspective,QueryRequest
@dataclass
class PrimaryMetadata:request_id:str;status:QueryStatus;submitted_at:float;submitted_by:t.Optional[str];started_at:t.Optional[float]
@dataclass
class CacheMetadata:cached_at:float;age_seconds:int
@dataclass
class QueryExecutionResult:strategy:QueryStrategy;request_id:str;fingerprint:str;normalized_sql:str;depends_on:t.List[str];job_id:t.Optional[int]=_A;primary_metadata:t.Optional[PrimaryMetadata]=_A;cache_metadata:t.Optional[CacheMetadata]=_A
class PrimaryReq(PydanticModel):request_id:str;status:QueryStatus;submitted_at:str;submitted_by:t.Optional[str]=_A;started_at:t.Optional[str]=_A;elapsed_ms:int
class CacheInfo(PydanticModel):cached_at:str;age_seconds:int
class StatementLinks(PydanticModel):self:Link;primary:t.Optional[Link]=_A;result:t.Optional[Link]=_A
class StatementAccepted(PydanticModel):id:str;status:QueryStatus;strategy:QueryStrategy=PydanticField(description='Execution strategy (REUSE_RESULT, AWAIT_PRIMARY, EXECUTE)');fingerprint:str=PydanticField(description=_H);sql:str;params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=PydanticField(default=_A,description=_I);depends_on:t.Optional[t.List[str]]=_A;submitted_at:str;meta:t.Optional[t.Dict[str,t.Any]]=_A;cols_mapping:t.Optional[t.Dict[str,str]]=PydanticField(default=_A,description='Optional map of result column names to semantic roles (e.g. measure vs time dimension).');query_type:t.Optional[QueryType]=_A;job_id:t.Optional[int]=_A;primary:t.Optional[PrimaryReq]=_A;cache:t.Optional[CacheInfo]=_A;links:StatementLinks=PydanticField(alias=_C,serialization_alias=_C,description=_G);model_config={_D:_B}
class SemanticQueryTranspiled(PydanticModel):sql:str;params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=_A;cols_mapping:t.Optional[t.Dict[str,str]]=_A;query_type:QueryType;meta:t.Optional[t.Dict[str,t.Any]]=_A;gateway:str;dialect:t.Optional[str]=_A;transpiled_at:str
class StatementDetail(PydanticModel):id:str;status:QueryStatus;fingerprint:t.Optional[str]=PydanticField(default=_A,description=_H);sql:t.Optional[str]=_A;params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=PydanticField(default=_A,description=_I);depends_on:t.Optional[t.List[str]]=_A;submitted_at:str;started_at:t.Optional[str]=_A;completed_at:t.Optional[str]=_A;queue_wait_ms:t.Optional[int]=_A;execution_duration_ms:t.Optional[int]=_A;row_count:t.Optional[int]=_A;size_bytes:t.Optional[int]=_A;columns:t.Optional[t.List[t.Dict[str,str]]]=_A;references:t.Optional[t.Dict[str,t.List[t.List[str]]]]=PydanticField(default=_A,description='Field lineage mapping {column_name: [[model_name, field_name], ...]}');error:t.Optional[str]=_A;meta:t.Optional[t.Dict[str,t.Any]]=_A;query_type:t.Optional[QueryType]=_A;semantic_query:t.Optional[str]=_A;rest_query:t.Optional[t.Dict[str,t.Any]]=_A;graphql_query:t.Optional[str]=_A;primary:t.Optional[PrimaryReq]=_A;cache:t.Optional[CacheInfo]=_A;links:StatementLinks=PydanticField(alias=_C,serialization_alias=_C,description=_G);model_config={_D:_B}
class StatementResultLinks(PydanticModel):self:Link
class StatementResult(PydanticModel):cols:t.List[str];rows:t.List[t.List[t.Any]];types:t.List[t.Dict[str,str]];row_count:int;size_bytes:int;links:StatementResultLinks=PydanticField(alias=_C,serialization_alias=_C,description=_G);model_config={_D:_B,'exclude_none':_B}
class PerspectiveCreateRequest(PydanticModel):name:str=PydanticField(...,description='Human-readable perspective name.');description:t.Optional[str]=PydanticField(default=_A,description='Optional description shown in catalog views.');tags:t.List[Tag]=PydanticField(default_factory=list,description='Searchable tags.');terms:t.List[Term]=PydanticField(default_factory=list,description='Business terms associated with the perspective.');statement_id:str=PydanticField(...,description='Statement ID to save from (must be in SUCCESS status).');slug:t.Optional[str]=PydanticField(default=_A,description='URL-safe slug; auto-generated from name when omitted.');auto_refresh:bool=PydanticField(default=_B,description='Whether background refresh is enabled when upstream data changes.');is_public:bool=PydanticField(default=False,description='Whether the perspective is visible to all users.');allowed_user_ids:t.List[str]=PydanticField(default_factory=list,description='Explicit user allow-list (ignored when is_public is True).');model_config={_E:_F}
class PerspectiveUpdateRequest(PydanticModel):name:t.Optional[str]=PydanticField(default=_A,description='Updated perspective name.');description:t.Optional[str]=PydanticField(default=_A,description='Updated description.');tags:t.Optional[t.List[Tag]]=PydanticField(default=_A,description='Updated searchable tags.');terms:t.Optional[t.List[Term]]=PydanticField(default=_A,description='Updated business terms.');statement_id:t.Optional[str]=PydanticField(default=_A,description='New source statement ID (must be SUCCESS) to change the underlying query.');auto_refresh:t.Optional[bool]=PydanticField(default=_A,description='Updated auto-refresh setting.');is_public:t.Optional[bool]=PydanticField(default=_A,description='Updated visibility setting.');allowed_user_ids:t.Optional[t.List[str]]=PydanticField(default=_A,description='Updated user allow-list (ignored when is_public is True).');model_config={_E:_F}
class PerspectiveLinks(PydanticModel):self:Link;statement_detail:t.Optional[Link]=_A;result:t.Optional[Link]=_A;refresh_statement:t.Optional[Link]=_A
class QueryInfo(PydanticModel):
	sql_query:str;normalized_sql:t.Optional[str]=_A;params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=_A;depends_on:t.Optional[t.List[str]]=_A;gateway:t.Optional[str]=_A;query_type:t.Optional[QueryType]=_A;semantic_query:t.Optional[str]=_A;rest_query:t.Optional[t.Dict[str,t.Any]]=_A;graphql_query:t.Optional[str]=_A;meta:t.Optional[t.Dict[str,t.Any]]=_A;model_config={_D:_B}
	@classmethod
	def from_request(cls,request:t.Union['QueryRequest',t.Any])->'QueryInfo':return cls(sql_query=request.sql_query,normalized_sql=request.normalized_sql,params=request.params,depends_on=request.depends_on,gateway=request.gateway,query_type=request.query_type,semantic_query=request.semantic_query,rest_query=request.rest_query,graphql_query=request.graphql_query,meta=request.meta)
class PerspectiveDetailView(PydanticModel):id:str;slug:str;name:str;description:t.Optional[str]=_A;tags:t.List[str]=PydanticField(default_factory=list);terms:t.List[str]=PydanticField(default_factory=list);owner:str;request_id:t.Optional[str]=_A;auto_refresh:bool=_B;is_public:bool=False;allowed_user_ids:t.List[str]=PydanticField(default_factory=list);created_at:str;updated_at:str;created_by:t.Optional[str]=_A;updated_by:t.Optional[str]=_A;sql_query:str;normalized_sql:t.Optional[str]=_A;params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=_A;depends_on:t.Optional[t.List[str]]=_A;gateway:t.Optional[str]=_A;query_type:t.Optional[QueryType]=_A;semantic_query:t.Optional[str]=_A;rest_query:t.Optional[t.Dict[str,t.Any]]=_A;graphql_query:t.Optional[str]=_A;meta:t.Optional[t.Dict[str,t.Any]]=_A;links:PerspectiveLinks=PydanticField(alias=_C,serialization_alias=_C,description=_G);model_config={_D:_B}
class PerspectiveListView(PydanticModel):
	id:str=PydanticField(alias='perspective_id');slug:str;name:str;description:t.Optional[str]=_A;tags:t.List[Tag]=PydanticField(default_factory=list);terms:t.List[Term]=PydanticField(default_factory=list);owner:str;request_id:t.Optional[str]=_A;auto_refresh:bool=_B;is_public:bool;allowed_user_ids:t.List[str]=PydanticField(default_factory=list);created_at:str;updated_at:str;created_by:t.Optional[str]=_A;updated_by:t.Optional[str]=_A;links:PerspectiveLinks=PydanticField(alias=_C,serialization_alias=_C,description=_G);model_config={_D:_B}
	@classmethod
	def from_perspective(cls,perspective:'Perspective',links:PerspectiveLinks)->'PerspectiveListView':return cls(perspective_id=perspective.perspective_id,slug=perspective.slug,name=perspective.name,description=perspective.description,tags=perspective.tags,terms=perspective.terms,owner=perspective.owner,request_id=perspective.request_id,auto_refresh=perspective.auto_refresh,is_public=perspective.is_public,allowed_user_ids=perspective.allowed_user_ids,created_at=timestamp_to_iso(perspective.created_at),updated_at=timestamp_to_iso(perspective.updated_at),created_by=perspective.created_by,updated_by=perspective.updated_by,links=links)
class PerspectivesListResponse(PydanticModel):items:t.List[PerspectiveListView];pagination:Pagination;model_config={_D:_B}
class GraphQLRequest(PydanticModel):query:str=PydanticField(...,min_length=1,description='GraphQL query string');variables:t.Optional[t.Dict[str,t.Any]]=PydanticField(default=_A,description='Variable bindings for the query');operationName:t.Optional[str]=PydanticField(default=_A,description='Operation name (required when document has multiple operations)');model_config={_E:_F}
class StatementRequest(PydanticModel):sql:str=PydanticField(...);params:t.Optional[t.Union[t.Dict[str,t.Any],t.List[t.Any]]]=_A;meta:t.Optional[t.Dict[str,t.Any]]=_A;model_config={_E:_F}
class RestQueryRequest(PydanticModel):query:RestQuery=PydanticField(...);graphql_body:t.Optional[str]=_A;meta:t.Optional[t.Dict[str,t.Any]]=_A;model_config={_E:_F}
class SqlQueryRequest(PydanticModel):sql:str=PydanticField(...,min_length=1);meta:t.Optional[t.Dict[str,t.Any]]=_A;model_config={_E:_F}