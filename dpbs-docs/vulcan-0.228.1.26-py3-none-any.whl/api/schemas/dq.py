from __future__ import annotations
_E='self'
_D='HATEOAS links'
_C=None
_B=True
_A='_links'
import typing as t
from pydantic import ConfigDict,Field as PydanticField
from api.schemas.common import Link,SelfLink
from schema.types import DQDimension
from vulcan.core.soda3.spec import CheckOutcome
from vulcan.utils.pydantic import PydanticModel
class RuleRunLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_B);run:Link
class RuleRun(PydanticModel):model_config=ConfigDict(populate_by_name=_B);outcome:CheckOutcome;outcome_reasons:t.Optional[t.Dict[str,t.Any]]=_C;diagnostics:t.Dict[str,t.Any]=PydanticField(default_factory=dict);run_id:str;start_ts:int;end_ts:t.Optional[int]=_C;links:RuleRunLinks=PydanticField(alias=_A,serialization_alias=_A,description=_D)
class RuleDefLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_B);self_link:Link=PydanticField(alias=_E,serialization_alias=_E,description='Link to rule detail page')
class RuleDef(PydanticModel):model_config=ConfigDict(populate_by_name=_B,protected_namespaces=());identity:str;name:t.Optional[str]=_C;type:t.Optional[str]=_C;column:t.Optional[str]=_C;dimension:DQDimension;definition:t.Optional[str]=_C;model:t.Optional[str]=_C;runs:t.List[RuleRun]=PydanticField(default_factory=list);links:RuleDefLinks=PydanticField(alias=_A,serialization_alias=_A,description=_D)
class RulesResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_B);rules:t.List[RuleDef];total:int;links:SelfLink=PydanticField(alias=_A,serialization_alias=_A,description=_D)
class RuleDetailLinks(PydanticModel):model_config=ConfigDict(populate_by_name=_B);self_link:Link=PydanticField(alias=_E,serialization_alias=_E,description='Self reference link');rules:Link
class RuleDetailResponse(PydanticModel):model_config=ConfigDict(populate_by_name=_B);rule:RuleDef;links:RuleDetailLinks=PydanticField(alias=_A,serialization_alias=_A,description=_D)