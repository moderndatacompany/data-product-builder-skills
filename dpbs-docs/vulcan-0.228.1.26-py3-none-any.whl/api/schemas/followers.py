from __future__ import annotations
_A=None
import typing as t
from pydantic import Field as PydanticField
from api.schemas.common import Pagination
from vulcan.utils.pydantic import PydanticModel
class FollowRequest(PydanticModel):metadata:t.Optional[t.Dict[str,t.Any]]=_A
class FollowStatus(PydanticModel):is_follower:bool;user_id:str;active:t.Optional[bool]=_A;followed_at:t.Optional[int]=_A;metadata:t.Optional[t.Dict[str,t.Any]]=_A
class FollowerListItem(PydanticModel):user_id:str;followed_at:int;metadata:t.Dict[str,t.Any]=PydanticField(default_factory=dict)
class FollowersListResponse(PydanticModel):followers:t.List[FollowerListItem];total:int;pagination:Pagination