from __future__ import annotations
_B='_links'
_A=None
import typing as t
from pydantic import ConfigDict,Field as PydanticField
from api.schemas.common import Link,Pagination
from api.urls import urls
from vulcan.core.notification import Notification
from vulcan.utils.pydantic import PydanticModel
class NotificationLinks(PydanticModel):model_config=ConfigDict(populate_by_name=True);run:t.Optional[Link]=PydanticField(default=_A,description='Link to associated run activity');plan:t.Optional[Link]=PydanticField(default=_A,description='Link to associated plan activity')
class NotificationDetail(Notification):
	model_config=ConfigDict(populate_by_name=True);links:NotificationLinks=PydanticField(alias=_B,serialization_alias=_B,description='HATEOAS links to related resources')
	@classmethod
	def from_core(cls,notification:Notification)->'NotificationDetail':return cls(**notification.model_dump(),links=NotificationLinks(run=Link(href=urls.run(notification.run_id))if notification.run_id else _A,plan=Link(href=urls.plan(notification.plan_id))if notification.plan_id else _A))
class NotificationsListResponse(PydanticModel):model_config=ConfigDict(populate_by_name=True);environment:str;notifications:t.List[NotificationDetail];total:int;pagination:Pagination