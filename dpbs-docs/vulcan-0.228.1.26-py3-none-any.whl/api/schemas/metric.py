from __future__ import annotations
_A=None
import typing as t
from pydantic import Field as PydanticField
from schema.filters import RestFilterExpression
from schema.types import MetricGranularityValue
from vulcan.utils.pydantic import PydanticModel
class MetricQueryRequest(PydanticModel):dimensions:t.Optional[t.List[str]]=PydanticField(default=_A,description='Metric dimension aliases to include in the result.');granularity:t.Optional[MetricGranularityValue]=PydanticField(default=_A,description='Time granularity override for the metric time dimension.');timezone:t.Optional[str]=PydanticField(default=_A,description='Timezone used when bucketing time values (default: UTC).');filters:t.Optional[t.List[RestFilterExpression]]=PydanticField(default=_A,description='Ad-hoc REST filter expressions applied to the query.');limit:int=PydanticField(default=10000,ge=1,le=50000,description='Maximum number of rows to return.');offset:int=PydanticField(default=0,ge=0,description='Number of rows to skip before returning results.');model_config={'extra':'ignore'}