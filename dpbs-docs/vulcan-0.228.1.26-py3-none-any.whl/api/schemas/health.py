from __future__ import annotations
import typing as t
from pydantic import Field as PydanticField
from vulcan.utils.pydantic import PydanticModel
class Meta(PydanticModel):version:str=PydanticField(description='API version');project:str=PydanticField(description='Project name');environments:t.Optional[t.List[str]]=PydanticField(default=None,description='List of available environments');db_types:t.Optional[t.Dict[str,str]]=PydanticField(default=None,description='Mapping of gateway names to database types')