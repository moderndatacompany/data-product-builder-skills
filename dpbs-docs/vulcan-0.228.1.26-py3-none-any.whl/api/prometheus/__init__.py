from __future__ import annotations
import logging
from api.prometheus.registry import ApiPromRegistry
logger=logging.getLogger(__name__)
registry=ApiPromRegistry(tenant='',data_product='',version='')
def init(*,tenant:str,data_product:str,version:str,dataplane_name:str='',dataplane_network_type:str='',dataplane_type:str='',dataos_fqdn:str='',resource_id:str='',resource_type:str='',instance_name:str='',user_name:str='')->ApiPromRegistry:global registry;shutdown();active=ApiPromRegistry(tenant=tenant,data_product=data_product or'',version=version or'',dataplane_name=dataplane_name,dataplane_network_type=dataplane_network_type,dataplane_type=dataplane_type,dataos_fqdn=dataos_fqdn,resource_id=resource_id,resource_type=resource_type,instance_name=instance_name,user_name=user_name);registry=active;logger.info('API Prometheus enabled (tenant=%s, data_product=%s, version=%s, dataplane=%s, scrape=/metrics)',tenant,data_product,version,dataplane_name);return registry
def shutdown()->None:global registry;registry=ApiPromRegistry(tenant='',data_product='',version='')