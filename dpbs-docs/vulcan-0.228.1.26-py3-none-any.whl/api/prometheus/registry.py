from __future__ import annotations
_l='semantic_compilation_duration'
_k='query_queue_wait'
_j='policy_evaluation_duration'
_i='gateway_query_duration'
_h='http_request_duration'
_g='user_name'
_f='instance_name'
_e='resource_type'
_d='resource_id'
_c='dataos_fqdn'
_b='dataplane_type'
_a='dataplane_network_type'
_Z='dataplane_name'
_Y='version'
_X='data_product'
_W='tenant'
_V='bad_request'
_U='connection_error'
_T=False
_S='status'
_R='path'
_Q='method'
_P='semantic_transpiler_errors_total'
_O='semantic_compilation_total'
_N='query_queue_depth'
_M='policy_denial_total'
_L='gateway_errors_total'
_K='http_requests_total'
_J='cache_miss_total'
_I='cache_hit_total'
_H='database'
_G='operational'
_F='auth'
_E='connection'
_D='timeout'
_C='api'
_B='unknown'
_A=None
import logging,typing as t
from prometheus_client import CollectorRegistry,Counter,Gauge,Histogram
logger=logging.getLogger(__name__)
GatewayErrorType=t.Literal[_D,_E,_F,_G,_H,_B]
TranspilerErrorClass=t.Literal[_U,'503',_V,_B]
CompilationStatus=t.Literal['success','error']
PolicyType=t.Literal['heimdall']
SubjectType=t.Literal['user']
_FAST_DURATION_BUCKETS:t.Tuple[float,...]=(.05,.1,.25,.5,1,2.5,5,10,30,60)
_BASE_LABELS:t.Tuple[str,...]=(_W,_X,_Y,_Z,_a,_b,_c,_d,_e,_f,_g)
class ApiPromRegistry:
	METRIC_PREFIX='vulcan_api_'
	@classmethod
	def _metric_name(cls,suffix:str)->str:return f"{cls.METRIC_PREFIX}{suffix}"
	def __init__(self,*,tenant:str,data_product:str,version:str,dataplane_name:str='',dataplane_network_type:str='',dataplane_type:str='',dataos_fqdn:str='',resource_id:str='',resource_type:str='',instance_name:str='',user_name:str='')->_A:self._tenant=tenant;self._data_product=data_product;self._version=version;self._dataplane_name=dataplane_name;self._dataplane_network_type=dataplane_network_type;self._dataplane_type=dataplane_type;self._dataos_fqdn=dataos_fqdn;self._resource_id=resource_id;self._resource_type=resource_type;self._instance_name=instance_name;self._user_name=user_name;self._registry=CollectorRegistry();self._metrics=self._declare_metrics()
	@property
	def registry(self)->t.Any:return self._registry
	def _base_labels(self)->t.Dict[str,str]:return{_W:self._tenant,_X:self._data_product,_Y:self._version,_Z:self._dataplane_name,_a:self._dataplane_network_type,_b:self._dataplane_type,_c:self._dataos_fqdn,_d:self._resource_id,_e:self._resource_type,_f:self._instance_name,_g:self._user_name}
	def _declare_metrics(self)->t.Dict[str,t.Any]:C='entrypoint';B='gateway';A='engine';r=self._registry;name=self._metric_name;return{_I:Counter(name(_I),'Cache hits.',list(_BASE_LABELS)+[_C],registry=r),_J:Counter(name(_J),'Cache misses.',list(_BASE_LABELS)+[_C],registry=r),_K:Counter(name(_K),'Total HTTP requests to the Vulcan API.',[_Q,_R,_S],registry=r),_h:Histogram(name('http_request_duration_seconds'),'HTTP request duration in seconds.',[_Q,_R],buckets=_FAST_DURATION_BUCKETS,registry=r),_i:Histogram(name('gateway_query_duration_seconds'),'Engine query duration.',list(_BASE_LABELS)+[B,A],buckets=_FAST_DURATION_BUCKETS,registry=r),_L:Counter(name(_L),'Engine connection/query errors.',list(_BASE_LABELS)+[B,'error_type'],registry=r),_j:Histogram(name('policy_evaluation_duration_seconds'),'Heimdall policy evaluation duration.',list(_BASE_LABELS)+['policy_type','cached'],buckets=_FAST_DURATION_BUCKETS,registry=r),_M:Counter(name(_M),'Policy denials.',list(_BASE_LABELS)+['subject_type','reason'],registry=r),_N:Gauge(name(_N),'Queries waiting in the execution queue.',list(_BASE_LABELS)+[C],registry=r),_k:Histogram(name('query_queue_wait_seconds'),'Time a query spent waiting in the queue before execution.',list(_BASE_LABELS)+[C],buckets=_FAST_DURATION_BUCKETS,registry=r),_O:Counter(name(_O),'Semantic-layer SQL compilations by status.',list(_BASE_LABELS)+[A,_S],registry=r),_l:Histogram(name('semantic_compilation_duration_seconds'),'Semantic compilation duration.',list(_BASE_LABELS)+[A],buckets=_FAST_DURATION_BUCKETS,registry=r),_P:Counter(name(_P),'Transpiler service/transport errors by class.',list(_BASE_LABELS)+[A,_C,'error_class'],registry=r)}
	def on_api_http_request(self,*,method:str,path:str,status:str,duration_s:float)->_A:
		try:labels={_Q:method,_R:path,_S:status};self._metrics[_K].labels(**labels).inc();self._metrics[_h].labels(method=method,path=path).observe(duration_s)
		except Exception as e:logger.debug('on_api_http_request failed: %s',e)
	def on_cache_event(self,*,api:str,hit:bool)->_A:
		try:base={**self._base_labels(),_C:api};key=_I if hit else _J;self._metrics[key].labels(**base).inc()
		except Exception as e:logger.debug('on_cache_event failed: %s',e)
	def on_gateway_query(self,*,gateway:str,engine:str,duration_s:float)->_A:
		try:self._metrics[_i].labels(**self._base_labels(),gateway=gateway,engine=engine).observe(duration_s)
		except Exception as e:logger.debug('on_gateway_query failed: %s',e)
	def on_gateway_error(self,*,gateway:str,error:Exception)->_A:
		try:
			error_name=type(error).__name__.lower()
			if _D in error_name:error_type:GatewayErrorType=_D
			elif _E in error_name:error_type=_E
			elif'permission'in error_name or _F in error_name:error_type=_F
			elif _G in error_name:error_type=_G
			elif _H in error_name or'sql'in error_name:error_type=_H
			else:error_type=_B
			self._metrics[_L].labels(**self._base_labels(),gateway=gateway,error_type=error_type).inc()
		except Exception as e:logger.debug('on_gateway_error failed: %s',e)
	def on_policy_evaluated(self,*,policy_type:PolicyType,duration_s:float,cached:bool=_T,denied:bool=_T,subject_type:SubjectType='user',reason:str='')->_A:
		try:
			base=self._base_labels();self._metrics[_j].labels(**base,policy_type=policy_type,cached='true'if cached else'false').observe(duration_s)
			if denied:self._metrics[_M].labels(**base,subject_type=subject_type,reason=reason).inc()
		except Exception as e:logger.debug('on_policy_evaluated failed: %s',e)
	def on_queue_wait(self,*,entrypoint:str,wait_seconds:float)->_A:
		try:self._metrics[_k].labels(**self._base_labels(),entrypoint=entrypoint).observe(wait_seconds)
		except Exception as e:logger.debug('on_queue_wait failed: %s',e)
	def on_query_queue_depth(self,*,entrypoint:str,depth:int)->_A:
		try:self._metrics[_N].labels(**self._base_labels(),entrypoint=entrypoint).set(float(depth))
		except Exception as e:logger.debug('on_query_queue_depth failed: %s',e)
	def on_semantic_compilation(self,*,engine:str,status:CompilationStatus,duration_s:float)->_A:
		try:base=self._base_labels();self._metrics[_O].labels(**base,engine=engine,status=status).inc();self._metrics[_l].labels(**base,engine=engine).observe(duration_s)
		except Exception as e:logger.debug('on_semantic_compilation failed: %s',e)
	def on_transpiler_error(self,*,engine:str,api:str,error:Exception)->_A:
		A='code'
		try:
			if getattr(error,'is_connection_error',_T):error_class:TranspilerErrorClass=_U
			elif getattr(error,A,0)==503:error_class='503'
			elif 400<=getattr(error,A,0)<500:error_class=_V
			else:error_class=_B
			self._metrics[_P].labels(**self._base_labels(),engine=engine,api=api,error_class=error_class).inc()
		except Exception as e:logger.debug('on_transpiler_error failed: %s',e)