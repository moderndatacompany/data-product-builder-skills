from __future__ import annotations
_A=None
import os
from datetime import datetime
_NO_CAP=frozenset({'none','null','unbounded'})
def _read_env(name:str)->str|_A:
	raw=os.getenv(name)
	if raw is _A:return
	text=raw.strip();return text or _A
def _clamp_float(value:float,floor:float,ceiling:float)->float:return max(floor,min(ceiling,value))
def _clamp_int(value:int,floor:int,ceiling:int)->int:return max(floor,min(ceiling,value))
def parse_positive_float_env(name:str,*,default:float,floor:float,ceiling:float)->float:
	raw=_read_env(name)
	if raw is _A:return default
	try:return _clamp_float(float(raw),floor,ceiling)
	except ValueError:return default
def parse_positive_int_env(name:str,*,default:int,floor:int,ceiling:int)->int:
	raw=_read_env(name)
	if raw is _A:return default
	try:return _clamp_int(int(raw),floor,ceiling)
	except ValueError:return default
def parse_optional_positive_int_env(name:str,*,default:int|_A,floor:int,ceiling:int)->int|_A:
	raw=_read_env(name)
	if raw is _A:return default
	if raw.lower()in _NO_CAP:return
	try:return _clamp_int(int(raw),floor,ceiling)
	except ValueError:return default
def timestamp_to_iso(ts:int)->str:return datetime.fromtimestamp(ts/1000).isoformat()