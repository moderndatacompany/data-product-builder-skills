from __future__ import annotations
_H='EngineAdapter'
_G='_VulcanConnectionProxy'
_F='dialect'
_E=True
_D=False
_C='_vulcan_table_fqn'
_B='_vulcan_engine_adapter'
_A=None
import contextlib,logging,typing as t
if t.TYPE_CHECKING:from vulcan.core.engine_adapter.base import EngineAdapter
logger=logging.getLogger(__name__)
_MISSING=object()
class GxResultRow:
	def __init__(self,values:t.Sequence[t.Any],columns:t.Sequence[str])->_A:self._values=tuple(values);self._columns=tuple(columns);self._values_by_column=dict(zip(self._columns,self._values));self._values_by_casefolded_column={str(column).casefold():value for(column,value)in zip(self._columns,self._values)}
	def __iter__(self)->t.Iterator[t.Any]:return iter(self._values)
	def __getitem__(self,index:t.Union[int,slice])->t.Any:return self._values[index]
	def __len__(self)->int:return len(self._values)
	def __repr__(self)->str:return repr(self._values)
	def _asdict(self)->t.Dict[str,t.Any]:return dict(self._values_by_column)
	@property
	def _mapping(self)->t.Mapping[str,t.Any]:return self._values_by_column
	def __getattr__(self,name:str)->t.Any:
		try:return self._values_by_column[name]
		except KeyError:
			try:return self._values_by_casefolded_column[name.casefold()]
			except KeyError as exc:available=', '.join(str(column)for column in self._columns);raise AttributeError(f"{name} (available columns: {available})")from exc
class _GxQueryMappings:
	def __init__(self,rows:t.Sequence[GxResultRow],columns:t.Sequence[str])->_A:self._rows=rows;self._columns=columns
	def all(self)->t.List[t.Dict[str,t.Any]]:return[row._asdict()for row in self._rows]
	def first(self)->t.Optional[t.Dict[str,t.Any]]:rows=self.all();return rows[0]if rows else _A
class GxQueryResult:
	def __init__(self,rows:t.Sequence[t.Sequence[t.Any]],columns:t.Sequence[str])->_A:self._columns=tuple(columns);self._rows=tuple(GxResultRow(row,self._columns)for row in rows);self._index=0
	def fetchall(self)->t.List[GxResultRow]:
		if self._index>=len(self._rows):return[]
		rows=list(self._rows[self._index:]);self._index=len(self._rows);return rows
	def fetchone(self)->t.Optional[GxResultRow]:
		if self._index>=len(self._rows):return
		row=self._rows[self._index];self._index+=1;return row
	def fetchmany(self,size:t.Optional[int]=_A)->t.List[GxResultRow]:
		if self._index>=len(self._rows):return[]
		fetch_size=1 if size is _A else max(int(size),0)
		if fetch_size==0:return[]
		end=min(len(self._rows),self._index+fetch_size);rows=list(self._rows[self._index:end]);self._index=end;return rows
	def all(self)->t.List[GxResultRow]:return self.fetchall()
	def first(self)->t.Optional[GxResultRow]:return self.fetchone()
	def keys(self)->t.Tuple[str,...]:return self._columns
	def mappings(self)->_GxQueryMappings:return _GxQueryMappings(self._rows,self._columns)
	def scalar(self)->t.Any:row=self.fetchone();return _A if row is _A else row[0]
	def scalar_one(self)->t.Any:
		row=self.fetchone()
		if row is _A:raise IndexError('No rows returned')
		return row[0]
	def close(self)->_A:0
	def __iter__(self)->t.Iterator[GxResultRow]:return iter(self._rows)
class _VulcanConnectionProxy:
	def __init__(self,execution_engine:t.Any)->_A:self._execution_engine=execution_engine;self.closed=_D
	def execute(self,query:t.Any,*args:t.Any,**kwargs:t.Any)->GxQueryResult:return _execute_with_vulcan_adapter(self._execution_engine,query)
	def begin(self)->_G:return self
	def commit(self)->_A:0
	def in_transaction(self)->bool:return _D
	def __enter__(self)->_G:return self
	def __exit__(self,*args:t.Any)->_A:0
def _compile_gx_query(query:t.Any,execution_engine:t.Any)->t.Tuple[str,t.Optional[t.Any]]:
	compile_fn=getattr(query,'compile',_A)
	if compile_fn is _A:return str(query),_A
	dialect=getattr(getattr(execution_engine,'engine',_A),_F,_A);compile_kwargs={'render_postcompile':_E,'literal_binds':_E}
	try:compiled=query.compile(dialect=dialect,compile_kwargs=compile_kwargs)
	except Exception:
		try:compiled=query.compile(compile_kwargs=compile_kwargs)
		except Exception:logger.debug('[gx] Could not compile GX query, falling back to string form',exc_info=_E);return str(query),_A
	sql=str(compiled);params=getattr(compiled,'params',_A)or _A;return sql,params
def _execute_with_vulcan_adapter(execution_engine:t.Any,query:t.Any)->GxQueryResult:
	adapter=getattr(execution_engine,_B);sql,params=_compile_gx_query(query,execution_engine)
	if params:df=adapter.fetchdf_with_params(sql,params)
	else:df=adapter.fetchdf(sql)
	columns=tuple(str(column)for column in getattr(df,'columns',()));selected_columns=getattr(query,'selected_columns',_A)
	if selected_columns is not _A:
		expected_columns=tuple(str(getattr(column,'key',_A)or getattr(column,'name',''))for column in selected_columns)
		if len(expected_columns)==len(columns)and expected_columns and all(expected_columns):columns=expected_columns
	rows=tuple(tuple(row)for row in getattr(df,'itertuples')(index=_D,name=_A));return GxQueryResult(rows,columns)
def _sql_server_unexpected_count_with_vulcan(cls:t.Any,execution_engine:t.Any,metric_domain_kwargs:t.Dict[str,t.Any],metric_value_kwargs:t.Dict[str,t.Any],metrics:t.Dict[str,t.Any],**kwargs:t.Any)->int:
	import sqlalchemy as sa;from great_expectations.expectations.metrics.map_metric_provider.is_sqlalchemy_metric_selectable import _is_sqlalchemy_metric_selectable;from great_expectations.util import get_sqlalchemy_selectable;unexpected_condition,compute_domain_kwargs,accessor_domain_kwargs=metrics['unexpected_condition'];domain_kwargs={**compute_domain_kwargs,**accessor_domain_kwargs};selectable=execution_engine.get_domain_records(domain_kwargs=domain_kwargs);condition=sa.case((unexpected_condition,sa.cast(1,sa.Numeric)),else_=sa.cast(0,sa.Numeric)).label('condition');condition_query=sa.select(condition)
	if not _is_sqlalchemy_metric_selectable(map_metric_provider=cls):condition_query=condition_query.select_from(get_sqlalchemy_selectable(selectable))
	unexpected_rows=condition_query.cte('gx_unexpected_rows');unexpected_count_query=sa.select(sa.func.coalesce(sa.func.sum(unexpected_rows.c.condition),0).label('unexpected_count'));unexpected_count=execution_engine.execute_query(unexpected_count_query).scalar()
	try:return int(unexpected_count)
	except TypeError:return 0
def _mssql_quantile_values_with_vulcan(cls:t.Any,execution_engine:t.Any,metric_domain_kwargs:t.Dict[str,t.Any],metric_value_kwargs:t.Dict[str,t.Any],metrics:t.Dict[str,t.Any],runtime_configuration:t.Dict[str,t.Any])->t.List[t.Any]:import sqlalchemy as sa;from great_expectations.core.metric_domain_types import MetricDomainTypes;selectable,_,accessor_domain_kwargs=execution_engine.get_compute_domain(metric_domain_kwargs,domain_type=MetricDomainTypes.COLUMN);column=sa.column(accessor_domain_kwargs['column']);quantiles=list(metric_value_kwargs['quantiles']);percentile_expressions=[sa.func.percentile_cont(float(quantile)).within_group(column.asc()).over()for quantile in quantiles];query=sa.select(*percentile_expressions).select_from(selectable);row=execution_engine.execute_query(query).fetchone();return[_A]*len(quantiles)if row is _A else list(row)
def _fabric_regex_provider(original_provider:t.Any,*,positive:bool)->t.Any:
	import inspect,sqlalchemy as sa;from great_expectations.execution_engine import SqlAlchemyExecutionEngine;from great_expectations.expectations.metrics.map_metric_provider import column_condition_partial;original_condition=inspect.unwrap(original_provider)
	@column_condition_partial(engine=SqlAlchemyExecutionEngine)
	def _sqlalchemy(cls:t.Any,column:t.Any,regex:str,_dialect:t.Any,_execution_engine:t.Any,**kwargs:t.Any)->t.Any:
		adapter=getattr(_execution_engine,_B,_A)
		if getattr(adapter,_F,_A)!='fabric':return original_condition(cls,column,regex,_dialect=_dialect,_execution_engine=_execution_engine,**kwargs)
		predicate=sa.func.REGEXP_LIKE(column,sa.literal(regex));return predicate if positive else sa.not_(predicate)
	return _sqlalchemy
@contextlib.contextmanager
def use_vulcan_execution_adapter()->t.Iterator[_A]:
	B='providers';A='SqlAlchemyExecutionEngine'
	try:from great_expectations.execution_engine.sqlalchemy_execution_engine import SqlAlchemyExecutionEngine
	except Exception:yield;return
	original_execute_query=SqlAlchemyExecutionEngine.execute_query;original_execute_query_in_transaction=getattr(SqlAlchemyExecutionEngine,'execute_query_in_transaction',_A);original_get_connection=SqlAlchemyExecutionEngine.get_connection
	try:from great_expectations.expectations.metrics.table_metrics import table_column_types
	except Exception:table_column_types=_A
	original_column_metadata=table_column_types._get_sqlalchemy_column_metadata if table_column_types is not _A else _A
	try:from great_expectations.execution_engine.sqlalchemy_dialect import GXSqlDialect;from great_expectations.expectations import registry as gx_registry;from great_expectations.expectations.metrics.map_metric_provider import map_metric_provider as gx_map_metric_provider;original_unexpected_count_provider=gx_map_metric_provider._sqlalchemy_map_condition_unexpected_count_value
	except Exception:GXSqlDialect=_A;gx_registry=_A;gx_map_metric_provider=_A;original_unexpected_count_provider=_A
	replaced_metric_providers:t.List[t.Tuple[t.Dict[str,t.Any],t.Any]]=[];replaced_regex_providers:t.List[t.Tuple[t.Dict[str,t.Any],t.Any]]=[];quantile_providers=_A;original_quantile_provider_entry=_A
	if gx_registry is not _A:
		quantile_definition=gx_registry._registered_metrics.get('column.quantile_values')
		if quantile_definition is not _A:quantile_providers=quantile_definition.get(B,{});original_quantile_provider_entry=quantile_providers.get(A)
	def _unexpected_count_provider(cls:t.Any,execution_engine:t.Any,metric_domain_kwargs:t.Dict[str,t.Any],metric_value_kwargs:t.Dict[str,t.Any],metrics:t.Dict[str,t.Any],**kwargs:t.Any)->t.Any:
		adapter=getattr(execution_engine,_B,_A);dialect_name=getattr(execution_engine,'dialect_name',_A)
		if adapter is not _A and GXSqlDialect is not _A and dialect_name==GXSqlDialect.SQL_SERVER:return _sql_server_unexpected_count_with_vulcan(cls,execution_engine,metric_domain_kwargs,metric_value_kwargs,metrics,**kwargs)
		if original_unexpected_count_provider is _A:raise RuntimeError('GX SQLAlchemy unexpected-count provider is unavailable')
		return original_unexpected_count_provider(cls,execution_engine,metric_domain_kwargs,metric_value_kwargs,metrics,**kwargs)
	def _quantile_values_provider(cls:t.Any,execution_engine:t.Any,metric_domain_kwargs:t.Dict[str,t.Any],metric_value_kwargs:t.Dict[str,t.Any],metrics:t.Dict[str,t.Any],runtime_configuration:t.Dict[str,t.Any])->t.Any:
		adapter=getattr(execution_engine,_B,_A)
		if adapter is not _A and getattr(adapter,_F,_A)=='tsql':return _mssql_quantile_values_with_vulcan(cls,execution_engine,metric_domain_kwargs,metric_value_kwargs,metrics,runtime_configuration)
		if original_quantile_provider_entry is _A:raise RuntimeError('GX SQLAlchemy quantile provider is unavailable')
		return original_quantile_provider_entry[1](cls,execution_engine,metric_domain_kwargs,metric_value_kwargs,metrics,runtime_configuration)
	def _execute_query(self:t.Any,query:t.Any,*args:t.Any,**kwargs:t.Any)->t.Any:
		adapter=getattr(self,_B,_A)
		if adapter is _A:return original_execute_query(self,query,*args,**kwargs)
		return _execute_with_vulcan_adapter(self,query)
	def _execute_query_in_transaction(self:t.Any,query:t.Any,*args:t.Any,**kwargs:t.Any)->t.Any:
		adapter=getattr(self,_B,_A)
		if adapter is _A or original_execute_query_in_transaction is _A:
			if original_execute_query_in_transaction is _A:return original_execute_query(self,query,*args,**kwargs)
			return original_execute_query_in_transaction(self,query,*args,**kwargs)
		return _execute_with_vulcan_adapter(self,query)
	@contextlib.contextmanager
	def _get_connection(self:t.Any)->t.Iterator[_VulcanConnectionProxy]:
		adapter=getattr(self,_B,_A)
		if adapter is _A:
			with original_get_connection(self)as connection:yield connection
			return
		yield _VulcanConnectionProxy(self)
	def _get_column_metadata(execution_engine:t.Any,batch_data:t.Any)->t.List[t.Dict[str,t.Any]]:
		adapter=getattr(execution_engine,_B,_A);table_fqn=getattr(execution_engine,_C,_A)
		if adapter is _A or not table_fqn:
			if original_column_metadata is _A:raise RuntimeError('GX column reflection is not available')
			return original_column_metadata(execution_engine,batch_data)
		return[{'name':name,'type':str(data_type)}for(name,data_type)in adapter.columns(table_fqn).items()]
	SqlAlchemyExecutionEngine.execute_query=_execute_query;SqlAlchemyExecutionEngine.get_connection=_get_connection
	if original_execute_query_in_transaction is not _A:SqlAlchemyExecutionEngine.execute_query_in_transaction=_execute_query_in_transaction
	if table_column_types is not _A:table_column_types._get_sqlalchemy_column_metadata=_get_column_metadata
	if gx_map_metric_provider is not _A:gx_map_metric_provider._sqlalchemy_map_condition_unexpected_count_value=_unexpected_count_provider
	if gx_registry is not _A and original_unexpected_count_provider is not _A:
		for metric_definition in gx_registry._registered_metrics.values():
			providers=metric_definition.get(B,{});provider_entry=providers.get(A)
			if provider_entry is _A:continue
			metric_class,metric_provider=provider_entry
			if metric_provider is not original_unexpected_count_provider:continue
			replaced_metric_providers.append((providers,provider_entry));providers[A]=metric_class,_unexpected_count_provider
	if quantile_providers is not _A and original_quantile_provider_entry is not _A:quantile_providers[A]=original_quantile_provider_entry[0],_quantile_values_provider
	if gx_registry is not _A:
		for(metric_name,positive)in(('column_values.match_regex.condition',_E),('column_values.not_match_regex.condition',_D)):
			definition=gx_registry._registered_metrics.get(metric_name)
			if definition is _A:continue
			providers=definition.get(B,{});original_entry=providers.get(A)
			if original_entry is _A:continue
			providers[A]=original_entry[0],_fabric_regex_provider(original_entry[1],positive=positive);replaced_regex_providers.append((providers,original_entry))
	try:yield
	finally:
		SqlAlchemyExecutionEngine.execute_query=original_execute_query;SqlAlchemyExecutionEngine.get_connection=original_get_connection
		if original_execute_query_in_transaction is not _A:SqlAlchemyExecutionEngine.execute_query_in_transaction=original_execute_query_in_transaction
		if table_column_types is not _A and original_column_metadata is not _A:table_column_types._get_sqlalchemy_column_metadata=original_column_metadata
		for(providers,provider_entry)in replaced_metric_providers:providers[A]=provider_entry
		for(providers,provider_entry)in replaced_regex_providers:providers[A]=provider_entry
		if quantile_providers is not _A and original_quantile_provider_entry is not _A:quantile_providers[A]=original_quantile_provider_entry
		if gx_map_metric_provider is not _A and original_unexpected_count_provider is not _A:gx_map_metric_provider._sqlalchemy_map_condition_unexpected_count_value=original_unexpected_count_provider
@contextlib.contextmanager
def bind_vulcan_execution_engine(execution_engine:t.Any,execution_adapter:_H,*,table_fqn:t.Optional[str]=_A)->t.Iterator[_A]:
	if execution_engine is _A:yield;return
	previous=getattr(execution_engine,_B,_MISSING);previous_table_fqn=getattr(execution_engine,_C,_MISSING);setattr(execution_engine,_B,execution_adapter)
	if table_fqn is not _A:setattr(execution_engine,_C,table_fqn)
	try:
		with use_vulcan_execution_adapter():yield
	finally:
		if previous is _MISSING:
			try:delattr(execution_engine,_B)
			except Exception:0
		else:setattr(execution_engine,_B,previous)
		if previous_table_fqn is _MISSING:
			try:delattr(execution_engine,_C)
			except Exception:0
		else:setattr(execution_engine,_C,previous_table_fqn)
@contextlib.contextmanager
def bind_vulcan_execution_adapter(validator:t.Any,execution_adapter:_H)->t.Iterator[_A]:
	execution_engine=getattr(validator,'execution_engine',_A)
	with bind_vulcan_execution_engine(execution_engine,execution_adapter):yield