from __future__ import annotations
_V='frequencies'
_U='histogram'
_T='stddev'
_S='variance'
_R='sum'
_Q='avg'
_P='SUM'
_O='freq'
_N='max'
_M='min'
_L='agg'
_K='max_length'
_J='min_length'
_I='avg_length'
_H='distinct'
_G='maxs'
_F='mins'
_E='missing_count'
_D='text'
_C='frequent_values'
_B='numeric'
_A=None
import enum,logging,typing as t
from sqlglot import exp
if t.TYPE_CHECKING:from vulcan.core.engine_adapter.base import EngineAdapter
logger=logging.getLogger(__name__)
_LIMIT_FREQUENT_VALUES=5
_LIMIT_MINS_MAXS=5
_MAX_N_BINS=20
class MetricFamily(str,enum.Enum):AGGREGATES='aggregates';FREQUENCIES=_V;HISTOGRAMS='histograms'
_UNSUPPORTED:t.Dict[str,t.FrozenSet[MetricFamily]]={}
def _classify_dtype(dtype:exp.DataType)->t.Optional[t.Literal[_B,_D]]:
	if dtype.is_type(*exp.DataType.NUMERIC_TYPES):return _B
	if dtype.is_type(*exp.DataType.TEXT_TYPES):return _D
def unprofilable_columns(columns:t.Dict[str,exp.DataType])->t.Dict[str,str]:return{name:dtype.sql()for(name,dtype)in columns.items()if _classify_dtype(dtype)is _A}
def _null_count_expr(col:exp.Expression)->exp.Expression:return exp.func(_P,exp.Case(ifs=[exp.If(this=exp.Is(this=col,expression=exp.null()),true=exp.Literal.number(1))],default=exp.Literal.number(0)))
def _build_row_count_query(table_expr:exp.Table)->exp.Select:return exp.select(exp.alias_(exp.func('COUNT',exp.Star()),'_row_count')).from_(table_expr)
def _build_column_profile_query(table_expr:exp.Table,col_name:str,kind:t.Literal[_B,_D],unsupported:t.FrozenSet[MetricFamily]=frozenset(),limit_mins_maxs:int=_LIMIT_MINS_MAXS,limit_frequent:int=_LIMIT_FREQUENT_VALUES,dialect:str='')->exp.Expression:
	U='hist_bins';T='sum_freq';S='raw_freq';R='INT';Q='AVG';P='MAX';O='MIN';N='fabric';M='tsql';L='DOUBLE';K=False;J='distinct_count';I=True;H='bin_idx';G='max_val';F='min_val';E='value_frequencies';D='metric_';C='kind_';B='frequency_';A='value_';col=exp.column(col_name,quoted=I);val=exp.column(A);freq=exp.column(B)
	def _as_text(x:exp.Expression)->exp.Expression:return exp.Cast(this=x,to=exp.DataType.build('TEXT'))
	def _null_freq_cast()->exp.Expression:return exp.Cast(this=exp.Null(),to=exp.DataType.build('BIGINT'))
	agg_selects:t.List[exp.Expression]=[exp.alias_(_null_count_expr(col),_E),exp.alias_(exp.Count(this=exp.Distinct(expressions=[col])),J)];agg_col_map:t.List[t.Tuple[str,str]]=[(_E,_E),(J,_H)]
	if kind==_B:
		tsql_aggregates=dialect in(M,N)
		for(func_name,col_alias,metric_name)in((O,F,_M),(P,G,_N),(Q,'avg_val',_Q),(_P,'sum_val',_R),('VAR'if tsql_aggregates else'VAR_SAMP','variance_val',_S),('STDEV'if tsql_aggregates else'STDDEV_SAMP','stddev_val',_T)):agg_selects.append(exp.alias_(exp.func(func_name,col),col_alias));agg_col_map.append((col_alias,metric_name))
	else:
		len_col=exp.func('LENGTH',col)
		for(func_name,col_alias,metric_name)in((Q,_I,_I),(O,_J,_J),(P,_K,_K)):agg_selects.append(exp.alias_(exp.func(func_name,len_col),col_alias));agg_col_map.append((col_alias,metric_name))
	agg_body=exp.select(*agg_selects).from_(table_expr);vf_body=exp.select(exp.alias_(col,A),exp.alias_(exp.func('COUNT',exp.Star()),B)).from_(table_expr).where(exp.Not(this=exp.Is(this=col,expression=exp.null()))).group_by(col);fv_body=exp.select(val,freq).from_(E).order_by(exp.Ordered(this=freq,desc=I)).limit(limit_frequent);union_parts:t.List[exp.Select]=[];extra_ctes:t.List[t.Tuple[str,exp.Expression]]=[]
	if MetricFamily.AGGREGATES not in unsupported:
		for(col_alias,metric_name)in agg_col_map:union_parts.append(exp.select(exp.alias_(exp.Literal.string(_L),C),exp.alias_(exp.Literal.string(metric_name),D),exp.alias_(_as_text(exp.column(col_alias)),A),exp.alias_(_null_freq_cast(),B)).from_(_L))
	if MetricFamily.FREQUENCIES not in unsupported:
		if kind==_B:mins_body=exp.select(val,freq).from_(E).where(exp.Not(this=exp.Is(this=val,expression=exp.null()))).order_by(exp.Ordered(this=val,desc=K)).limit(limit_mins_maxs);maxs_body=exp.select(val,freq).from_(E).where(exp.Not(this=exp.Is(this=val,expression=exp.null()))).order_by(exp.Ordered(this=val,desc=I)).limit(limit_mins_maxs);extra_ctes.append((_F,mins_body));extra_ctes.append((_G,maxs_body));union_parts.append(exp.select(exp.alias_(exp.Literal.string(_O),C),exp.alias_(exp.Literal.string(_F),D),exp.alias_(_as_text(val),A),exp.alias_(freq,B)).from_(_F));union_parts.append(exp.select(exp.alias_(exp.Literal.string(_O),C),exp.alias_(exp.Literal.string(_G),D),exp.alias_(_as_text(val),A),exp.alias_(freq,B)).from_(_G))
		union_parts.append(exp.select(exp.alias_(exp.Literal.string(_O),C),exp.alias_(exp.Literal.string(_C),D),exp.alias_(_as_text(val),A),exp.alias_(freq,B)).from_(_C))
	if kind==_B and MetricFamily.HISTOGRAMS not in unsupported:
		def _clamp_expr(value:exp.Expression,lower:exp.Expression,upper:exp.Expression)->exp.Expression:
			if dialect in(M,N):return exp.Case().when(exp.LT(this=value.copy(),expression=lower.copy()),lower.copy()).when(exp.GT(this=value.copy(),expression=upper.copy()),upper.copy()).else_(value.copy())
			return exp.func('LEAST',exp.func('GREATEST',value,lower),upper)
		def _n_bins_expr()->exp.Expression:return _clamp_expr(exp.Cast(this=exp.column(J),to=exp.DataType.build(R)),exp.Literal.number(1),exp.Literal.number(_MAX_N_BINS))
		def _cast_dbl(name:str)->exp.Expression:return exp.Cast(this=exp.column(name),to=exp.DataType.build(L))
		n_intervals=exp.Sub(this=_n_bins_expr(),expression=exp.Literal.number(1));n_intervals_dbl=exp.Cast(this=n_intervals,to=exp.DataType.build(L));value_dbl=exp.Cast(this=val,to=exp.DataType.build(L));range_expr=exp.paren(exp.Sub(this=_cast_dbl(G),expression=_cast_dbl(F)));delta_expr=exp.paren(exp.Sub(this=value_dbl,expression=_cast_dbl(F)));floor_expr=exp.func('FLOOR',exp.Div(this=exp.Mul(this=delta_expr,expression=n_intervals_dbl),expression=range_expr));last_bin=exp.Sub(this=_n_bins_expr(),expression=exp.Literal.number(1));bin_idx_expr=exp.If(this=exp.GTE(this=value_dbl,expression=_cast_dbl(G)),true=last_bin,false=_clamp_expr(exp.Cast(this=floor_expr,to=exp.DataType.build(R)),exp.Literal.number(0),last_bin));hist_where=exp.And(this=exp.LT(this=_cast_dbl(F),expression=_cast_dbl(G)),expression=exp.GT(this=n_intervals,expression=exp.Literal.number(0)));inner_bins=exp.select(exp.alias_(bin_idx_expr,H),exp.alias_(freq,S)).from_(E).join(_L,join_type='CROSS').where(hist_where).subquery('_bins');hist_bins_body=exp.select(exp.column(H),exp.alias_(exp.func(_P,exp.column(S)),T)).from_(inner_bins).group_by(exp.column(H));extra_ctes.append((U,hist_bins_body));union_parts.append(exp.select(exp.alias_(exp.Literal.string('hist'),C),exp.alias_(exp.Literal.string('bin'),D),exp.alias_(_as_text(exp.column(H)),A),exp.alias_(exp.column(T),B)).from_(U))
	if not union_parts:return exp.select(exp.alias_(_as_text(exp.Null()),C),exp.alias_(_as_text(exp.Null()),D),exp.alias_(_as_text(exp.Null()),A),exp.alias_(_null_freq_cast(),B)).where(exp.Boolean(this=K))
	union:exp.Expression=union_parts[0]
	for part in union_parts[1:]:union=union.union(part,distinct=K)
	need_vf=MetricFamily.FREQUENCIES not in unsupported or kind==_B and MetricFamily.HISTOGRAMS not in unsupported;union=union.with_(_L,as_=agg_body)
	if need_vf:union=union.with_(E,as_=vf_body)
	for(cte_name,cte_body)in extra_ctes:union=union.with_(cte_name,as_=cte_body)
	if MetricFamily.FREQUENCIES not in unsupported:union=union.with_(_C,as_=fv_body)
	return union
def _parse_column_profile_rows(rows:t.List[t.Tuple],kind:t.Literal[_B,_D])->t.Tuple[t.Dict[str,t.Any],t.Dict[str,t.Any]]:
	agg_dict:t.Dict[str,t.Any]={};freq_dict:t.Dict[str,t.Any]={};bin_counts:t.Dict[int,int]={}
	for row in rows:
		row_kind,metric_,value_,frequency_=row[0],row[1],row[2],row[3]
		if row_kind==_L and value_ is not _A:
			if metric_ in(_E,_H):
				try:agg_dict[metric_]=int(float(value_))
				except(TypeError,ValueError):0
			elif metric_ in(_M,_N,_Q,_R,_S,_T):
				try:agg_dict[metric_]=float(value_)
				except(TypeError,ValueError):0
			elif metric_ in(_J,_K):
				try:agg_dict[metric_]=int(float(value_))
				except(TypeError,ValueError):0
			elif metric_==_I:
				try:agg_dict[metric_]=float(value_)
				except(TypeError,ValueError):0
		elif row_kind==_O and value_ is not _A:
			if metric_ in(_F,_G):
				try:freq_dict.setdefault(metric_,[]).append(float(value_))
				except(TypeError,ValueError):0
			elif metric_==_C and frequency_ is not _A:freq_dict.setdefault(_C,[]).append({'value':str(value_),'frequency':int(frequency_)})
		elif row_kind=='hist'and value_ is not _A and frequency_ is not _A:
			try:bin_idx=int(value_);bin_counts[bin_idx]=bin_counts.get(bin_idx,0)+int(frequency_)
			except(TypeError,ValueError):0
	if bin_counts and kind==_B:
		min_raw=agg_dict.get(_M);max_raw=agg_dict.get(_N);distinct_raw=agg_dict.get(_H)
		if min_raw is not _A and max_raw is not _A and distinct_raw is not _A:
			try:
				n_bins,bins_list,_=_compute_histogram_bins(float(min_raw),float(max_raw),int(distinct_raw))
				if n_bins>0 and bins_list:frequencies=[bin_counts.get(i,0)for i in range(n_bins)];agg_dict[_U]={'boundaries':bins_list,_V:frequencies}
			except(TypeError,ValueError):0
	return agg_dict,freq_dict
def _compute_histogram_bins(min_val:float,max_val:float,n_distinct:int)->t.Tuple[int,t.List[float],float]:
	n_bins=max(1,min(n_distinct,_MAX_N_BINS));n_intervals=n_bins-1
	if min_val>=max_val or n_intervals==0:return 0,[],.0
	bin_width=(max_val-min_val)/n_intervals;bins_list=[round(min_val+i*bin_width,2)for i in range(n_bins)];bins_list[-1]=max_val;return n_bins,bins_list,bin_width
def _assemble_profile(agg:t.Dict[str,t.Any],freq:t.Dict[str,t.Any],kind:t.Literal[_B,_D],row_count:t.Optional[int])->t.Dict[str,t.Any]:
	A='null_percent';profile:t.Dict[str,t.Any]={};empty_table=row_count==0;missing_count_raw=agg.get(_E);missing_count:t.Optional[int]=int(missing_count_raw)if missing_count_raw is not _A else _A
	if missing_count is _A and empty_table:missing_count=0
	if missing_count is not _A:profile[_E]=missing_count
	if empty_table:
		if missing_count is not _A:profile[A]=.0
	elif missing_count is not _A and row_count is not _A and row_count>0:profile[A]=round(1e2*missing_count/row_count,6)
	elif missing_count==0:profile[A]=.0
	distinct_raw=agg.get(_H)
	if distinct_raw is _A and empty_table:distinct_raw=0
	if distinct_raw is not _A:profile[_H]=int(distinct_raw)
	if kind==_B:
		for metric in(_M,_N,_Q,_R,_T,_S):
			val=agg.get(metric)
			if val is not _A:
				try:profile[metric]=float(val)
				except(TypeError,ValueError):profile[metric]=val
		mins_list=freq.get(_F)
		if mins_list:profile[_F]=mins_list
		maxs_list=freq.get(_G)
		if maxs_list:profile[_G]=maxs_list
		histogram=agg.get(_U)
		if histogram:profile[_U]=histogram
	else:
		avg_len=agg.get(_I);min_len=agg.get(_J);max_len=agg.get(_K)
		if avg_len is not _A:profile[_I]=float(avg_len)
		if min_len is not _A:profile[_J]=int(min_len)
		if max_len is not _A:profile[_K]=int(max_len)
	fv=freq.get(_C)
	if fv:profile[_C]=fv
	return profile
def profile_model(adapter:'EngineAdapter',*,model_name:str,table:str,columns:t.Dict[str,exp.DataType])->t.Dict[str,t.Any]:
	C='columnProfiles';B='rowCount';A='table';dialect=adapter.dialect;unsupported=_UNSUPPORTED.get(dialect,frozenset());classified:t.List[t.Tuple[str,t.Literal[_B,_D]]]=[]
	for(col_name,dtype)in columns.items():
		kind=_classify_dtype(dtype)
		if kind is not _A:classified.append((col_name,kind))
	table_expr=exp.to_table(table);row_count:t.Optional[int]=_A
	try:
		rc_rows=adapter.fetchall(_build_row_count_query(table_expr))
		if rc_rows:raw_rc=rc_rows[0][0];row_count=int(raw_rc)if raw_rc is not _A else 0
	except Exception as exc:logger.warning('[gx/profile] row_count query failed for %s: %s',model_name,exc)
	if not classified:logger.debug('[gx/profile] No numeric/text columns to profile for %s',model_name);return{A:model_name,B:row_count,C:[]}
	col_agg:t.Dict[str,t.Dict[str,t.Any]]={};col_freq:t.Dict[str,t.Dict[str,t.Any]]={}
	for(col_name,kind)in classified:
		try:query=_build_column_profile_query(table_expr,col_name,kind,unsupported=unsupported,dialect=dialect);rows=adapter.fetchall(query);agg,freq=_parse_column_profile_rows(rows,kind);col_agg[col_name]=agg;col_freq[col_name]=freq
		except Exception as exc:logger.warning('[gx/profile] Column profile query failed for %r in %s: %s',col_name,model_name,exc)
	column_profiles=[]
	for(col_name,kind)in classified:
		agg=col_agg.get(col_name,{});freq=col_freq.get(col_name,{});profile=_assemble_profile(agg,freq,kind,row_count)
		if profile:column_profiles.append({'columnName':col_name,'profile':profile})
	return{A:model_name,B:row_count,C:column_profiles}