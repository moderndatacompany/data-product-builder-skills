from __future__ import annotations
import typing as t
def resolve_column_name(name:str,columns:t.Iterable[str])->t.Optional[str]:
	candidates=tuple(columns)
	if name in candidates:return name
	matches=[candidate for candidate in candidates if candidate.casefold()==name.casefold()];return matches[0]if len(matches)==1 else None