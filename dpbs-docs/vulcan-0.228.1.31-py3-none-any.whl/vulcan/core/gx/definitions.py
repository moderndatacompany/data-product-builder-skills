from __future__ import annotations
_b='Distinct value count'
_a='dimensions'
_Z='forbid'
_Y='not_evaluated'
_X='warned'
_W='failed'
_V='passed'
_U='filter'
_T='profiles'
_S='before'
_R='depends_on'
_Q='DataQualitySpec'
_P='expectation'
_O='allow'
_N='dim'
_M='rules'
_L='dimension'
_K='uniqueness'
_J='yellow'
_I=False
_H='completeness'
_G='red'
_F='name'
_E='expectations'
_D='validity'
_C=True
_B='accuracy'
_A=None
import json,logging,re,typing as t
from dataclasses import dataclass,field
from pathlib import Path
from typing import TYPE_CHECKING
import pydantic
from pydantic import ConfigDict,Field,PrivateAttr,field_serializer,field_validator,model_validator
from sqlglot import exp
from vulcan.core.config.dq import DqConfig
from vulcan.core.dq_types import CheckOutcome
from vulcan.core.gx.naming import check_name_for
from vulcan.core.types import RunDqCounts
from vulcan.utils.hashing import hash_data
from vulcan.utils.pydantic import PydanticModel
from schema.types import DQDimension
if TYPE_CHECKING:from rich.tree import Tree
logger=logging.getLogger(__name__)
_SIMPLE_EXTRA_KEY=re.compile('^[a-zA-Z_][a-zA-Z0-9_]*$')
_FALLBACK_DIMENSION:DQDimension=_D
_METRIC_DEFAULTS:t.Dict[str,DQDimension]={'row_count':_H,'missing_count':_H,'missing_percent':_H,'duplicate_count':_K,'duplicate_percent':_K,'invalid_count':_D,'invalid_percent':_D,'valid_count':_D,'avg':_B,'min':_B,'max':_B,'sum':_B,'min_length':_B,'max_length':_B,'avg_length':_B,'stddev':_B}
_LEADING_METRIC_RE=re.compile('^([a-z][a-z0-9_]*)\\s*(?:\\(|(?=\\s*[<>=!]))',re.IGNORECASE)
_EXPECTATION_TYPE_DIMENSION:t.Dict[str,DQDimension]={'expect_column_values_to_not_be_null':_H,'expect_column_values_to_be_unique':_K,'expect_table_row_count_to_be_between':_H,'unexpected_rows_expectation':_D,'expect_column_values_to_be_in_set':_D,'expect_column_values_to_not_be_in_set':_D,'expect_column_values_to_match_regex':_D,'expect_column_values_to_be_between':_B,'expect_column_mean_to_be_between':_B,'expect_column_min_to_be_between':_B,'expect_column_max_to_be_between':_B,'expect_column_sum_to_be_between':_B,'expect_column_stdev_to_be_between':_B,'expect_column_quantile_values_to_be_between':_B,'expect_compound_columns_to_be_unique':_K,'expect_column_to_exist':_D,'expect_table_columns_to_match_set':_D,'expect_column_values_to_be_of_type':_D}
def _stable_hash(obj:t.Any)->str:return hash_data([json.dumps(obj,sort_keys=_C,default=str)])
def _dq_text(s:str)->exp.Expression:return exp.Identifier(this=s,quoted=_C)
def _dq_extra_key_exp(key:str)->exp.Expression:
	if _SIMPLE_EXTRA_KEY.match(key):return exp.to_identifier(key)
	return exp.Identifier(this=key,quoted=_C)
def _dq_extra_value_to_exp(val:t.Any)->exp.Expression:
	if val is _A:return exp.null()
	if isinstance(val,bool):return exp.true()if val else exp.false()
	if isinstance(val,(int,float)):return exp.Literal.number(val)
	if isinstance(val,str):return _dq_text(val)
	if isinstance(val,dict):
		parts:t.List[exp.Expression]=[]
		for k in sorted(val.keys()):parts.append(exp.Kwarg(this=_dq_extra_key_exp(str(k)),value=_dq_extra_value_to_exp(val[k])))
		return exp.Tuple(expressions=parts)
	if isinstance(val,(list,tuple)):return exp.Tuple(expressions=[_dq_extra_value_to_exp(x)for x in val])
	return _dq_text(str(val))
def _infer_dq_dimension(expression:str)->DQDimension:
	expr=expression.strip()
	if not expr:return _FALLBACK_DIMENSION
	metric_match=_LEADING_METRIC_RE.match(expr)
	if metric_match:
		metric_name=metric_match.group(1).lower()
		if metric_name in _METRIC_DEFAULTS:return _METRIC_DEFAULTS[metric_name]
	return _FALLBACK_DIMENSION
def _infer_dimension_from_expectation_type(expectation_type:str)->DQDimension:return _EXPECTATION_TYPE_DIMENSION.get(expectation_type,_FALLBACK_DIMENSION)
class DqExpectationMeta(pydantic.BaseModel):model_config=ConfigDict(extra=_Z);name:t.Optional[str]=_A;dimension:DQDimension=_FALLBACK_DIMENSION;description:t.Optional[str]=_A
class DqReferentialSpec(pydantic.BaseModel):
	model_config=ConfigDict(extra=_Z);source_columns:t.List[str];target_table:str;target_columns:t.List[str];source_columns_quoted:t.List[bool]=pydantic.Field(default_factory=list);target_columns_quoted:t.List[bool]=pydantic.Field(default_factory=list)
	@model_validator(mode='after')
	def _validate_columns(self)->'DqReferentialSpec':
		if not self.source_columns or len(self.source_columns)!=len(self.target_columns):raise ValueError('referential check requires the same non-empty number of source and target columns')
		if self.source_columns_quoted and len(self.source_columns_quoted)!=len(self.source_columns):raise ValueError('source column quote metadata must match source columns')
		if self.target_columns_quoted and len(self.target_columns_quoted)!=len(self.target_columns):raise ValueError('target column quote metadata must match target columns')
		return self
class DqExpectation(pydantic.BaseModel):
	model_config=ConfigDict(extra=_O);expectation:str;meta:DqExpectationMeta;vulcan_referential:t.Optional[DqReferentialSpec]=_A
	def gx_kwargs(self)->t.Dict[str,t.Any]:return dict(self.__pydantic_extra__ or{})
	@property
	def check_name(self)->str:return self.meta.name or self.expectation
	def to_gx_tuple(self)->t.Tuple[str,t.Dict[str,t.Any],t.Dict[str,t.Any]]:return self.expectation,self.gx_kwargs(),self.meta.model_dump(exclude_none=_C)
def _dq_expectation_data_hash(e:DqExpectation)->str:
	raw={_P:e.expectation,'kwargs':e.gx_kwargs(),_L:str(e.meta.dimension)}
	if e.vulcan_referential is not _A:raw['vulcan_referential']=e.vulcan_referential.model_dump()
	return _stable_hash(raw)
def _dq_expectation_metadata_hash(e:DqExpectation)->str:raw={_F:e.meta.name,'description':e.meta.description};return _stable_hash(raw)
def normalize_expectations(raw_items:t.List[t.Any])->t.List[DqExpectation]:
	out:t.List[DqExpectation]=[]
	for(i,item)in enumerate(raw_items):
		label=f"expectations[{i}]"
		if isinstance(item,DqExpectation):out.append(item);continue
		if isinstance(item,str):
			expectation_type=item.strip()
			if not expectation_type:raise ValueError(f"{label}: expectation type cannot be empty string")
			dimension=_infer_dimension_from_expectation_type(expectation_type);name=check_name_for(expectation_type,{});out.append(DqExpectation(expectation=expectation_type,meta=DqExpectationMeta(name=name,dimension=dimension)));continue
		if not isinstance(item,dict):raise ValueError(f'{label}: each expectation must be a string or a flat mapping with an "expectation" key (e.g. {{{{expectation: expect_foo, column: id, meta: {{{{...}}}}}}}})')
		item=dict(item)
		if _P not in item:
			if len(item)==1:old_key=next(iter(item));raise ValueError(f"{label}: typed-key format is not supported. Rewrite as flat form: {{expectation: {old_key!r}, ...kwargs..., meta: {{dimension: ...}}}}")
			raise ValueError(f'{label}: flat expectation dict must have an "expectation" key')
		expectation_type=str(item.pop(_P)).strip()
		if not expectation_type:raise ValueError(f"{label}: expectation cannot be empty")
		meta_raw=item.pop('meta',_A)or{}
		if not isinstance(meta_raw,dict):raise ValueError(f"{label}: 'meta' must be a mapping, got {type(meta_raw).__name__!r}")
		meta_raw=dict(meta_raw)
		if _L not in meta_raw:meta_raw[_L]=_infer_dimension_from_expectation_type(expectation_type)
		if not meta_raw.get(_F):meta_raw[_F]=check_name_for(expectation_type,item)
		try:meta=DqExpectationMeta(**meta_raw)
		except pydantic.ValidationError as e:raise ValueError(f"{label}: invalid meta: {e}")from e
		out.append(DqExpectation(expectation=expectation_type,meta=meta,**item))
	return out
def finalize_dq_spec(spec:_Q,*,model_name:t.Optional[str]=_A,path:t.Optional[str]=_A)->_Q:
	if spec.rules:from vulcan.core.gx.translator import translate_rules_to_expectations;translated=translate_rules_to_expectations(spec.rules,model_name=model_name or spec.depends_on,path=path);expectations=normalize_expectations(translated[_E]);return spec.model_copy(update={_E:expectations,_M:[]})
	if spec.expectations:
		normalized=normalize_expectations([e.model_dump()if isinstance(e,DqExpectation)else e for e in spec.expectations]);updates:t.Dict[str,t.Any]={_E:normalized}
		if spec.rules:updates[_M]=[]
		return spec.model_copy(update=updates)
	return spec.model_copy(update={_M:[]})if spec.rules else spec
class DataQualitySpec(PydanticModel):
	kind:t.Literal['dq']='dq';name:t.Optional[str]=_A;depends_on:str=Field(min_length=1);filter:t.Optional[str]=_A;profiles:t.List[str]=Field(default_factory=list);rules:t.List[t.Any]=Field(default_factory=list,deprecated=_C,description='Legacy input only. Cleared after load; use ``expectations``.');expectations:t.List[DqExpectation]=Field(default_factory=list);_path:t.Optional[Path]=PrivateAttr(default=_A);_rel_path:t.Optional[Path]=PrivateAttr(default=_A)
	@field_serializer(_E,when_used='json')
	def _serialize_expectations(self,expectations:t.List[DqExpectation])->t.List[t.Dict[str,t.Any]]:return[expectation.model_dump(mode='json',exclude_none=_I)for expectation in expectations]
	@field_validator(_R,mode=_S)
	@classmethod
	def _strip_depends(cls,v:t.Any)->str:
		s=str(v).strip()
		if not s:raise ValueError('depends_on cannot be empty')
		return s
	@field_validator(_E,mode=_S)
	@classmethod
	def _normalize_expectations_input(cls,v:t.Any)->t.List[DqExpectation]:
		if not v:return[]
		if not isinstance(v,list):raise ValueError("'expectations' must be a list")
		return normalize_expectations(v)
	@model_validator(mode=_S)
	@classmethod
	def _validate_xor_and_content(cls,data:t.Any)->t.Any:
		if not isinstance(data,dict):return data
		rules=data.get(_M)or[];expectations=data.get(_E)or[]
		if rules and expectations:raise ValueError("'rules' and 'expectations' cannot both be non-empty. Use 'expectations' for native GX YAML or 'rules' for legacy format.")
		profiles=data.get(_T)or[]
		if not rules and not expectations and not profiles:raise ValueError("At least one of 'rules', 'expectations', or 'profiles' must be non-empty.")
		return data
	@model_validator(mode='wrap')
	@classmethod
	def _finalize(cls,values:t.Any,handler:t.Any)->_Q:spec=handler(values);return finalize_dq_spec(spec,model_name=spec.depends_on)
	def data_hash(self)->str:items=[_dq_expectation_data_hash(e)for e in sorted(self.expectations,key=lambda e:(e.expectation,e.check_name))];payload:t.Dict[str,t.Any]={'kind':self.kind,_R:self.depends_on,_U:self.filter,_T:sorted(self.profiles),_E:items};return _stable_hash(payload)
	def metadata_hash(self)->str:items=[_dq_expectation_metadata_hash(e)for e in sorted(self.expectations,key=lambda e:(e.expectation,e.check_name))];payload:t.Dict[str,t.Any]={_F:self.name,_E:items};return _stable_hash(payload)
	def fingerprint(self)->str:return _stable_hash({'data':self.data_hash(),'metadata':self.metadata_hash()})
	def render_exp(self)->exp.Expression:
		inner:t.List[exp.Expression]=[exp.Property(this=exp.to_identifier('kind'),value=exp.to_identifier(self.kind)),exp.Property(this=exp.to_identifier(_R),value=_dq_text(self.depends_on))]
		if self.name is not _A:inner.append(exp.Property(this=exp.to_identifier(_F),value=_dq_text(self.name)))
		if self.filter is not _A:inner.append(exp.Property(this=exp.to_identifier(_U),value=_dq_text(self.filter)))
		if self.profiles:inner.append(exp.Property(this=exp.to_identifier(_T),value=exp.Tuple(expressions=[_dq_text(p)for p in sorted(self.profiles)])))
		if self.expectations:exp_sorted=sorted(self.expectations,key=lambda e:(e.expectation,e.check_name));inner.append(exp.Property(this=exp.to_identifier(_E),value=exp.Tuple(expressions=[exp.EQ(this=exp.Identifier(this=e.expectation,quoted=_C),expression=exp.Tuple(expressions=[exp.Property(this=exp.to_identifier(_F),value=_dq_text(e.check_name)),exp.Property(this=exp.to_identifier(_L),value=_dq_text(str(e.meta.dimension)))]))for e in exp_sorted])))
		return exp.Tuple(expressions=inner)
class CheckExecutionSummary(PydanticModel):
	results:t.Dict[str,t.Dict[str,t.Any]]=Field(default_factory=dict)
	def format_tree(self,verbosity:int=0)->'Tree':
		B='warned_checks';A='failed_checks';from rich.markup import escape;from rich.tree import Tree;model_count=len(self.results);tree=Tree(f"[bold]Check Executions[/bold] ({model_count} Models)")
		for(model_name,model_data)in sorted(self.results.items()):
			filter_expr=model_data.get(_U);model_label=f"[bold]{escape(model_name)}[/bold]"
			if filter_expr:model_label+=f" (filter: {escape(str(filter_expr))})"
			model_branch=tree.add(model_label);dimensions=model_data.get(_a,{})
			for(dimension,stats)in sorted(dimensions.items()):
				passed=stats[_V];failed=stats[_W];warned=stats[_X];not_evaluated=stats[_Y];total=passed+failed+warned+not_evaluated
				if not_evaluated==total:symbol='~';style=_N
				elif failed>0 or warned>0:symbol='✗';style=_G
				else:symbol='✓';style='green'
				label=f"[bold]{dimension}[/bold] ({passed}/{total})";details=[]
				if failed>0:details.append(f"{failed} failed")
				if warned>0:details.append(f"{warned} warned")
				if not_evaluated>0:details.append(f"{not_evaluated} not evaluated")
				if details:label+=f" - {', '.join(details)}"
				dimension_branch=model_branch.add(f"[{style}]{symbol}[/{style}] {label}");has_issues=failed>0 or warned>0
				if verbosity==1 and has_issues:
					for check in stats.get(A,[]):self._add_check_to_tree(dimension_branch,check,_G,show_sql=_I)
					for check in stats.get(B,[]):self._add_check_to_tree(dimension_branch,check,_J,show_sql=_I)
				elif verbosity>=2:
					for check in stats.get(A,[]):self._add_check_to_tree(dimension_branch,check,_G,show_sql=_C)
					for check in stats.get(B,[]):self._add_check_to_tree(dimension_branch,check,_J,show_sql=_C)
					for check in stats.get('not_evaluated_checks',[]):self._add_check_to_tree(dimension_branch,check,_N,show_sql=_I)
					if passed>0:dimension_branch.add(f"[dim]+ {passed} passed checks[/dim]")
		return tree
	def _add_check_to_tree(self,parent_branch:'Tree',check:t.Dict[str,t.Any],status_style:str,show_sql:bool=_I)->_A:
		A='definition';from rich.markup import escape;symbols={_G:'✗',_J:'⚠',_N:'~'};status_symbol=symbols.get(status_style,'✓');check_name=check.get(_F,'unnamed');check_branch=parent_branch.add(f"[{status_style}]{status_symbol} {escape(str(check_name))}[/{status_style}]");reasons=check.get('outcome_reasons',[])
		if reasons:reason=reasons[0]if isinstance(reasons,list)else reasons;msg=reason.get('message',str(reason))if isinstance(reason,dict)else str(reason)
		else:msgs={_G:f"Check failed: {check.get(A,check_name)}",_J:f"Check warning: {check.get(A,check_name)}",_N:'Check could not be evaluated'};msg=msgs.get(status_style)
		if msg:check_branch.add(f"[{status_style}]→ {escape(str(msg))}[/{status_style}]")
		if(value:=check.get('value'))is not _A:check_branch.add(f"[dim]Measured: {escape(str(value))}[/dim]")
		if show_sql and(query:=check.get('query')):
			query_branch=check_branch.add('[dim]Query:[/dim]');query_lines=query.strip().split('\n')
			for line in query_lines[:10]:query_branch.add(f"[dim cyan]{escape(line)}[/dim cyan]")
			if len(query_lines)>10:query_branch.add(f"[dim]... ({len(query_lines)-10} more lines)[/dim]")
	def quality_counts(self)->RunDqCounts:
		total=passed=failed=warned=not_evaluated=0
		for model_data in self.results.values():
			for stats in model_data.get(_a,{}).values():total+=stats[_V]+stats[_W]+stats[_X]+stats[_Y];passed+=stats[_V];failed+=stats[_W];warned+=stats[_X];not_evaluated+=stats[_Y]
		return RunDqCounts(total,passed,failed,warned,not_evaluated)
	def summarize(self)->str:
		counts=self.quality_counts();summary=f"\n[bold]Quality Summary:[/bold] [green]{counts.passed} passed[/green] | [red]{counts.failed} failed[/red]"
		if counts.warned>0:summary+=f" | [yellow]{counts.warned} warned[/yellow]"
		if counts.not_evaluated>0:summary+=f" | [dim]{counts.not_evaluated} not evaluated[/dim]"
		summary+=f" ({counts.total} total)";pass_rate=counts.passed/counts.total*1e2 if counts.total>0 else 1e2;score_style='green'if pass_rate>=90 else _J if pass_rate>=70 else _G;summary+=f"\n[bold]Score:[/bold] [{score_style}]{pass_rate:.1f}%[/{score_style}]\n";return summary
class ProfileExecutionSummary(PydanticModel):
	run_id:str;environment:str;model_profiles:t.Dict[str,t.List[str]];prefix_stats:t.Dict[str,t.Any]
	def summarize(self,verbosity:int=0)->str:
		model_count=len(self.model_profiles);total_columns=sum(len(cols)for cols in self.model_profiles.values());lines=[f"\n[bold]Profiled {model_count} model{'s'if model_count!=1 else''}[/bold] ({total_columns} columns):"]
		for model_name in sorted(self.model_profiles.keys()):
			columns=self.model_profiles[model_name];col_count=len(columns)
			if verbosity>=1:
				sorted_columns=sorted(columns)
				if len(sorted_columns)<=5:col_list=', '.join(sorted_columns)
				else:col_list=', '.join(sorted_columns[:5]);col_list+=f", ... (+{len(sorted_columns)-5} more)"
				lines.append(f"  ✓ [bold]{model_name}[/bold]: {col_list}")
			else:lines.append(f"  ✓ [bold]{model_name}[/bold]: {col_count} columns")
		return'\n'.join(lines)
@dataclass(frozen=_C)
class GxRunOptions:
	capture_failed_row_samples:bool=_C;max_items:int=20;naive_timestamp_timezone:str='UTC'
	@classmethod
	def from_config(cls,dq:DqConfig)->'GxRunOptions':return cls(capture_failed_row_samples=dq.capture_failed_row_samples,max_items=dq.max_items,naive_timestamp_timezone=dq.naive_timestamp_timezone)
@dataclass(frozen=_C)
class GxExceptionDetail:message:str;traceback:t.Optional[str]=_A;metric_id:t.Optional[str]=_A
@dataclass(frozen=_C)
class GxRuleResult:check_name:str;outcome:CheckOutcome;observed_value:object=_A;failed_rows_sample:t.Tuple[t.Dict[str,object],...]=field(default_factory=tuple);reproduce_query:t.Optional[str]=_A;total_failing_rows:t.Optional[int]=_A;exception:t.Optional[GxExceptionDetail]=_A;gx_result:t.Optional[t.Dict[str,object]]=_A
class FieldStatistics(PydanticModel):model_config=ConfigDict(extra=_O,populate_by_name=_C);min:t.Optional[t.Union[float,int]]=Field(default=_A,description='Minimum value');max:t.Optional[t.Union[float,int]]=Field(default=_A,description='Maximum value');avg:t.Optional[float]=Field(default=_A,description='Average value');sum:t.Optional[t.Union[float,int]]=Field(default=_A,description='Sum of values');stddev:t.Optional[float]=Field(default=_A,description='Standard deviation');variance:t.Optional[float]=Field(default=_A,description='Variance');distinct:t.Optional[int]=Field(default=_A,alias='distinct_count',description=_b);distinct_count:t.Optional[int]=Field(default=_A,description=_b);missing_count:t.Optional[int]=Field(default=_A,description='Missing value count');null_count:t.Optional[int]=Field(default=_A,description='Null value count');duplicate_count:t.Optional[int]=Field(default=_A,description='Duplicate value count');min_length:t.Optional[int]=Field(default=_A,description='Minimum string length');max_length:t.Optional[int]=Field(default=_A,description='Maximum string length');avg_length:t.Optional[float]=Field(default=_A,description='Average string length');stddev_length:t.Optional[float]=Field(default=_A,description='String length std dev');frequent_values:t.Optional[t.List[t.Dict[str,t.Any]]]=Field(default=_A,description='Most frequent values');histogram:t.Optional[t.Dict[str,t.Any]]=Field(default=_A,description='Value histogram');quantiles:t.Optional[t.Dict[str,t.Any]]=Field(default=_A,description='Value quantiles')
class ModelProfile(PydanticModel):model_config=ConfigDict(extra=_O);model_name:str=Field(description='Profiled model name');profiled_at:t.Optional[int]=Field(default=_A,description='Profile time (Unix ms)');row_count:t.Optional[int]=Field(default=_A,description='Row count');columns:t.Dict[str,FieldStatistics]=Field(default_factory=dict,description='Per-column statistics')