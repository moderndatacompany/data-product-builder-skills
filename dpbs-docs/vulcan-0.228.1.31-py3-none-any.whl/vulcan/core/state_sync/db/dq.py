from __future__ import annotations
_A4='metadata_json'
_A3='feedback_category'
_A2='feedback_type'
_A1='partition_name'
_A0='metric_name'
_z='outcome_reasons'
_y='start_ts'
_x='inner'
_w='measurementId'
_v='testResultId'
_u='runId'
_t='json'
_s='feedback_text'
_r='skip_measurements'
_q='seasonality_reason'
_p='is_anomaly'
_o='is_correctly_classified'
_n='profiled_at'
_m='profile_type'
_l='measured_at'
_k='archetype'
_j='metrics'
_i='group_by'
_h='location'
_g='resource_attributes'
_f='number'
_e='measurement_id'
_d='metric_identity'
_c='filter'
_b='definition'
_a='diagnostics'
_Z='outcome'
_Y='end_ts'
_X='value_type'
_W='value_json'
_V='value_text'
_U='updated_ts'
_T='check_type'
_S='check_id'
_R='dimension'
_Q='check_name'
_P='value_number'
_O='dataTime'
_N='column_name'
_M='bigint'
_L='run_id'
_K='model_name'
_J=False
_I='created_ts'
_H='c'
_G='m'
_F='check_identity'
_E='environment'
_D='id'
_C='text'
_B=True
_A=None
import json,typing as t,logging
from dataclasses import replace
from itertools import product
from decimal import Decimal
from datetime import date,datetime,timezone
import pandas as pd
from sqlglot import exp
from vulcan.core.engine_adapter import EngineAdapter
from vulcan.utils.migration import ColumnSpec,TableSpec
from vulcan.core.state_sync.db.utils import fetchall,json_to_dict
from vulcan.utils import JobType,get_executor,sortable_id,to_snake_case_keys
from vulcan.utils.date import now_timestamp
from vulcan.core.dq_types import CheckOutcome,DqCheckWrite,DqMetricWrite,DqProfileTableWrite,DqQueryWrite,DqScanWrite,validate_dq_dimension
from vulcan.core.query.history import QueryHistoryRecord,QueryHistoryStatus,duration_to_ms
from vulcan.core.state_sync.db.query_history import QUERY_HISTORY,records_to_dataframe
logger=logging.getLogger(__name__)
DQ_RESULTS=TableSpec(name='_dq_results',primary_key=(_D,),columns=(ColumnSpec(_D,indexed=_B),ColumnSpec(_L,indexed=_B),ColumnSpec(_E,indexed=_B),ColumnSpec(_y,_M),ColumnSpec(_Y,_M),ColumnSpec(_F,indexed=_B),ColumnSpec(_Z,_C),ColumnSpec(_z,_C),ColumnSpec(_a,_C),ColumnSpec(_I,_M)))
DQ_DEFINITIONS=TableSpec(name='_dq_definitions',primary_key=(_F,_E),columns=(ColumnSpec(_F,indexed=_B),ColumnSpec(_E,indexed=_B),ColumnSpec(_Q,_C),ColumnSpec(_T,_C),ColumnSpec(_N,_C),ColumnSpec(_R,_C),ColumnSpec(_b,_C),ColumnSpec(_K,indexed=_B),ColumnSpec(_g,_C),ColumnSpec(_h,_C),ColumnSpec(_i,_C),ColumnSpec(_c,_C),ColumnSpec(_j,_C),ColumnSpec(_k,_C),ColumnSpec(_U,_M)))
DQ_METRICS=TableSpec(name='_dq_metrics',primary_key=(_D,),columns=(ColumnSpec(_D,indexed=_B),ColumnSpec(_L,indexed=_B),ColumnSpec(_E,indexed=_B),ColumnSpec(_S,indexed=_B),ColumnSpec(_F,indexed=_B),ColumnSpec(_d,indexed=_B),ColumnSpec(_A0,indexed=_B),ColumnSpec(_K,indexed=_B),ColumnSpec(_N,_C),ColumnSpec(_A1,_C),ColumnSpec(_V,_C),ColumnSpec(_P,'numeric'),ColumnSpec(_W,_C),ColumnSpec(_X,_C),ColumnSpec(_l,_M),ColumnSpec(_I,_M)))
DQ_PROFILES=TableSpec(name='_dq_profiles',primary_key=(_D,),columns=(ColumnSpec(_D,indexed=_B),ColumnSpec(_L,indexed=_B),ColumnSpec(_E,indexed=_B),ColumnSpec(_K,indexed=_B),ColumnSpec(_N,_C),ColumnSpec(_m,_C),ColumnSpec(_V,_C),ColumnSpec(_P,'numeric'),ColumnSpec(_W,_C),ColumnSpec(_X,_C),ColumnSpec(_n,_M),ColumnSpec(_I,_M)))
DQ_FEEDBACKS=TableSpec(name='_dq_feedbacks',primary_key=(_D,),columns=(ColumnSpec(_D,indexed=_B),ColumnSpec(_L,indexed=_B),ColumnSpec(_S,indexed=_B),ColumnSpec(_F,indexed=_B),ColumnSpec(_e,indexed=_B),ColumnSpec(_A2,_C),ColumnSpec(_A3,_C),ColumnSpec(_o,'boolean'),ColumnSpec(_p,'boolean'),ColumnSpec(_q,_C),ColumnSpec(_r,_C),ColumnSpec(_s,_C),ColumnSpec(_A4,_C),ColumnSpec('user_id',_C),ColumnSpec(_I,_M),ColumnSpec(_U,_M)))
def format_data_time(value:t.Any)->str:
	B='Z';A='+00:00'
	if isinstance(value,int):dt=datetime.fromtimestamp(value/1000,tz=timezone.utc);return dt.isoformat().replace(A,B)
	if isinstance(value,datetime):dt=value if value.tzinfo is not _A else value.replace(tzinfo=timezone.utc);dt=dt.astimezone(timezone.utc);return dt.isoformat().replace(A,B)
	if isinstance(value,date):dt=datetime(value.year,value.month,value.day,tzinfo=timezone.utc);return dt.isoformat().replace(A,B)
	if isinstance(value,str):return value
	raise ValueError(f"Unsupported type for dataTime: {type(value)}")
def convert_value(value:t.Any,column_name:t.Optional[str]=_A)->t.Any:
	if isinstance(value,Decimal):return float(value)
	if column_name==_O:return format_data_time(value)
	return value
def _sanitize_for_json(value:t.Any)->t.Any:
	if value is pd.NaT:return
	if value is _A or isinstance(value,(bool,int,float,str)):return value
	if isinstance(value,Decimal):return float(value)
	if isinstance(value,datetime):return format_data_time(value)
	if isinstance(value,date):return format_data_time(value)
	if isinstance(value,dict):return{str(k):_sanitize_for_json(v)for(k,v)in value.items()}
	if isinstance(value,(list,tuple)):return[_sanitize_for_json(v)for v in value]
	return str(value)
def _json_dumps_dq(value:t.Any)->str:return json.dumps(_sanitize_for_json(value))
def _parse_diagnostics(raw:t.Any)->t.Dict[str,t.Any]:return json_to_dict(raw)
def _equivalent_gx_null_bounds(stored:t.Optional[str],stored_identity:str,check:DqCheckWrite)->bool:
	A='expectation'
	if stored is _A or check.definition is _A:return _J
	try:definitions=[json.loads(value)for value in(stored,check.definition)]
	except(TypeError,ValueError):return _J
	if any(not isinstance(d,dict)or d.get(A)!=check.check_type for d in definitions):return _J
	for definition in definitions:definition.pop('meta',_A)
	from great_expectations.exceptions import ExpectationNotFoundError;from great_expectations.expectations.registry import get_expectation_impl;from vulcan.core.gx.persistence import _gx_check_identity
	try:implementation=get_expectation_impl(check.check_type)
	except ExpectationNotFoundError:return _J
	if not implementation.__module__.startswith('great_expectations.expectations.core.'):return _J
	fields=getattr(implementation,'model_fields',_A)or implementation.__fields__;bounds=[b for b in('min_value','max_value')if b in fields and fields[b].default is _A]
	for definition in definitions:
		for bound in bounds:
			if definition.get(bound)is _A:definition.pop(bound,_A)
	if json.dumps(definitions[0],sort_keys=_B)!=json.dumps(definitions[1],sort_keys=_B):return _J
	kwargs={k:v for(k,v)in definitions[1].items()if k!=A};missing=[bound for bound in bounds if bound not in kwargs];identities=set()
	for included in product((_J,_B),repeat=len(missing)):variant={**kwargs,**{b:_A for(b,include)in zip(missing,included)if include}};identities.add(_gx_check_identity(check.model_name,check.check_name,check.check_type,json.dumps(variant,sort_keys=_B,default=str)))
	return stored_identity in identities and check.check_identity in identities
_DERIVED_QUERY_SUFFIXES='.reproduce_sql','.failing_sql','.passing_sql'
class QualityState:
	def __init__(self,engine_adapter:EngineAdapter,schema:t.Optional[str]=_A):self.engine_adapter=engine_adapter;self.schema=schema;dialect=engine_adapter.dialect;self.check_results_table=exp.table_(DQ_RESULTS.name,db=schema);self.checks_definitions_table=exp.table_(DQ_DEFINITIONS.name,db=schema);self.check_metrics_table=exp.table_(DQ_METRICS.name,db=schema);self.profiles_table=exp.table_(DQ_PROFILES.name,db=schema);self.check_feedback_table=exp.table_(DQ_FEEDBACKS.name,db=schema);self.runs_table=exp.table_('_runs',db=schema);self._check_results_columns_to_types=DQ_RESULTS.columns_to_types(dialect);self._checks_definitions_columns_to_types=DQ_DEFINITIONS.columns_to_types(dialect);self._check_metrics_columns_to_types=DQ_METRICS.columns_to_types(dialect);self._profiles_columns_to_types=DQ_PROFILES.columns_to_types(dialect);self._check_feedback_columns_to_types=DQ_FEEDBACKS.columns_to_types(dialect);self.query_history_table=exp.table_(QUERY_HISTORY.name,db=schema);self._query_history_columns_to_types=QUERY_HISTORY.columns_to_types(dialect)
	def store_scan(self,scan:DqScanWrite,*,run_id:str,environment:str,job_type:t.Optional[JobType]=_A,dialect:t.Optional[str]=_A)->str:
		scan_id=scan.scan_id
		try:
			with self.engine_adapter.transaction():
				scan=self._reconcile_gx_check_identities(scan,environment);checks_df,check_id_map=self._prepare_checks_dataframe(scan,run_id,environment);metrics_df=self._prepare_metrics_dataframe(scan,run_id,environment,check_id_map);profiles_df=self._prepare_profiles_dataframe(scan,run_id,environment);query_history_df=pd.DataFrame()
				if job_type in(JobType.PLAN,JobType.RUN)and dialect:query_history_df=self._prepare_scan_query_history_dataframe(scan,run_id=run_id,job_type=job_type,dialect=dialect)
				if not checks_df.empty:self._write_checks_batch(checks_df);self._upsert_checks_definitions(checks_df)
				if not metrics_df.empty:self._write_metrics_batch(metrics_df)
				if not profiles_df.empty:self._write_profiles_batch(profiles_df)
				if not query_history_df.empty:query_history_df=query_history_df[QUERY_HISTORY.column_names()];self.engine_adapter.insert_append(self.query_history_table,query_history_df,target_columns_to_types=self._query_history_columns_to_types,track_rows_processed=_J)
			logger.info('Stored DQ scan %s, run %s: %d checks, %d metrics, %d profile metrics',scan_id,run_id,len(checks_df),len(metrics_df),len(profiles_df));return scan_id
		except Exception as e:logger.error('Failed to store DQ scan %s: %s',scan_id,e,exc_info=_B);raise
	def _reconcile_gx_check_identities(self,scan:DqScanWrite,environment:str)->DqScanWrite:
		if not scan.checks:return scan
		query=exp.select(_K,_R,_Q,_F,_T,_b,_N,_c).from_(self.checks_definitions_table).where(exp.column(_E).eq(environment),exp.column(_K).isin(*sorted({c.model_name for c in scan.checks})),exp.column(_Q).isin(*sorted({c.check_name for c in scan.checks}))).order_by(_K,_R,_Q)
		if self.engine_adapter.dialect=='postgres':query=query.lock()
		existing={}
		for(model,dimension,name,*definition)in fetchall(self.engine_adapter,query):
			key=model,dimension,name
			if key in existing:raise ValueError(f"Ambiguous DQ definitions for {environment}: {key}")
			existing[key]=definition
		checks=[]
		for check in scan.checks:
			stored=existing.get((check.model_name,check.dimension,check.check_name))
			if stored:
				identity,check_type,definition,column,filter_sql=stored
				if identity!=check.check_identity and check_type==check.check_type and column==check.column_name and filter_sql==check.filter and _equivalent_gx_null_bounds(definition,identity,check):check=replace(check,check_identity=identity)
			checks.append(check)
		return replace(scan,checks=tuple(checks))
	def _prepare_scan_query_history_dataframe(self,scan:DqScanWrite,*,run_id:str,job_type:JobType,dialect:str)->pd.DataFrame:
		request_id=_A;records:t.List[QueryHistoryRecord]=[]
		for dq_query in scan.queries:
			record=self._query_history_record_from_dq_query(dq_query,run_id=run_id,request_id=request_id,job_type=job_type,dialect=dialect)
			if record is not _A:records.append(record)
		if not records:return pd.DataFrame()
		return records_to_dataframe(records)
	@staticmethod
	def _query_history_record_from_dq_query(dq_query:DqQueryWrite,*,run_id:str,request_id:t.Optional[str],job_type:JobType,dialect:str)->t.Optional[QueryHistoryRecord]:
		duration=dq_query.duration_ms
		if duration is _A:return
		name=dq_query.name or''
		if any(name.endswith(suffix)for suffix in _DERIVED_QUERY_SUFFIXES):return
		sql_text=dq_query.sql or''
		if not sql_text.strip():return
		exception=dq_query.exception;status:QueryHistoryStatus='FAILED'if exception else'SUCCESS';duration_ms=duration_to_ms(duration);error_message=str(exception)if exception else _A;return QueryHistoryRecord.from_execution(sql_text=sql_text,dialect=dialect,status=status,job_type=job_type,run_id=run_id,executor=get_executor(),request_id=request_id,component='DQ',duration_ms=duration_ms,error_message=error_message)
	def _prepare_checks_dataframe(self,scan:DqScanWrite,run_id:str,environment:str)->t.Tuple[pd.DataFrame,t.Dict[str,t.Tuple[str,str]]]:
		A='failed_rows_sample'
		if not scan.checks:return pd.DataFrame(),{}
		rows=[];check_id_map:t.Dict[str,t.Tuple[str,str]]={};metric_owner_priorities:t.Dict[str,int]={};created_ts=now_timestamp()
		for check in scan.checks:
			check_id=sortable_id();dimension=validate_dq_dimension(check.dimension);owner_priority={'vulcan_anomaly_detection':0,'vulcan_change_over_time':1}.get(check.check_type,2)
			for metric_id in check.metric_identities:
				existing_priority=metric_owner_priorities.get(metric_id)
				if existing_priority is _A or owner_priority<existing_priority:check_id_map[metric_id]=check_id,check.check_identity;metric_owner_priorities[metric_id]=owner_priority
			diagnostics_json=_A
			if check.diagnostics:
				diagnostics=to_snake_case_keys(check.diagnostics)
				if A in diagnostics:
					samples=diagnostics.pop(A)
					try:samples=_sanitize_for_json(samples);json.dumps(samples,allow_nan=_J)
					except Exception as exc:logger.warning('[dq] Omitted failed-row samples for check %s (%s): %s',check.check_name,check.check_identity,type(exc).__name__)
					else:diagnostics[A]=samples
				diagnostics_json=_json_dumps_dq(diagnostics)
			rows.append({_D:check_id,_L:run_id,_E:environment,_K:check.model_name,_y:scan.start_ts,_Y:scan.end_ts,_F:check.check_identity,_Q:check.check_name,_T:check.check_type,_b:check.definition,_R:dimension,_g:json.dumps({_R:dimension,'name':check.check_name}),_h:_A,_i:_A,_N:check.column_name,_c:check.filter,_j:json.dumps(list(check.metric_identities))if check.metric_identities else _A,_Z:check.outcome or CheckOutcome.NOT_EVALUATED.value,_z:json.dumps(check.outcome_reasons)if check.outcome_reasons else _A,_k:_A,_a:diagnostics_json,_I:created_ts})
		return pd.DataFrame(rows),check_id_map
	def _prepare_metrics_dataframe(self,scan:DqScanWrite,run_id:str,environment:str,check_id_map:t.Dict[str,t.Tuple[str,str]])->pd.DataFrame:
		if not scan.metrics:return pd.DataFrame()
		rows=[];created_ts=now_timestamp();persisted_metric_identities:t.Set[str]=set()
		for metric in scan.metrics:
			if metric.metric_identity in persisted_metric_identities:logger.warning('Skipping duplicate DQ metric %s in run %s',metric.metric_identity,run_id);continue
			persisted_metric_identities.add(metric.metric_identity);metric_id=sortable_id();check_mapping=check_id_map.get(metric.metric_identity);check_id=check_mapping[0]if check_mapping else _A;check_identity=check_mapping[1]if check_mapping else _A;value=metric.value;value_text,value_number,value_json,value_type=_A,_A,_A,_A
			if value is not _A:
				if isinstance(value,(int,float)):value_number=float(value);value_type=_f
				elif isinstance(value,str):value_text=value;value_type=_C
				elif isinstance(value,(dict,list)):value_json=_json_dumps_dq(value);value_type=_t
				else:value_json=_json_dumps_dq(value);value_type=_t
			rows.append({_D:metric_id,_L:run_id,_E:environment,_S:check_id,_F:check_identity or'',_d:metric.metric_identity,_A0:metric.metric_name,_K:metric.model_name,_N:metric.column_name,_A1:_A,_V:value_text,_P:value_number,_W:value_json,_X:value_type,_l:metric.measured_at if metric.measured_at is not _A else scan.end_ts,_I:created_ts})
		return pd.DataFrame(rows)
	def _prepare_profiles_dataframe(self,scan:DqScanWrite,run_id:str,environment:str)->pd.DataFrame:
		if not scan.profiles:return pd.DataFrame()
		rows=[];current_ts=now_timestamp();profiled_at=scan.start_ts
		for profile_table in scan.profiles:
			model_name=profile_table.model_name
			if not model_name:continue
			if profile_table.row_count is not _A:rows.append({_D:sortable_id(),_L:run_id,_E:environment,_K:model_name,_N:_A,_m:'row_count',_V:_A,_P:float(profile_table.row_count),_W:_A,_X:_f,_n:profiled_at,_I:current_ts})
			for col_profile in profile_table.column_profiles:
				column_name=col_profile.get(_N);profile_data=col_profile.get('profile',{})
				if not column_name or not profile_data:continue
				for(metric_name,metric_value)in profile_data.items():
					if metric_value is _A:continue
					value_text=_A;value_number=_A;value_json=_A;value_type=_A
					if isinstance(metric_value,(int,float)):value_number=float(metric_value);value_type=_f
					elif isinstance(metric_value,str):
						try:value_number=float(metric_value);value_type=_f
						except(ValueError,TypeError):value_text=metric_value;value_type=_C
					elif isinstance(metric_value,(dict,list)):value_json=_json_dumps_dq(metric_value);value_type=_t
					else:value_text=str(metric_value);value_type=_C
					rows.append({_D:sortable_id(),_L:run_id,_E:environment,_K:model_name,_N:column_name,_m:metric_name,_V:value_text,_P:value_number,_W:value_json,_X:value_type,_n:profiled_at,_I:current_ts})
		if not rows:return pd.DataFrame()
		return pd.DataFrame(rows)
	def _write_checks_batch(self,df:pd.DataFrame)->_A:df_to_insert=df[DQ_RESULTS.column_names()].copy();self.engine_adapter.insert_append(self.check_results_table,df_to_insert,target_columns_to_types=self._check_results_columns_to_types,track_rows_processed=_J)
	def _upsert_checks_definitions(self,df:pd.DataFrame)->_A:
		if df.empty:return
		distinct=df.drop_duplicates(subset=[_F,_E],keep='last')[[_F,_E,_Q,_T,_N,_R,_b,_K,_g,_h,_i,_c,_j,_k,_Y]].copy();distinct=distinct.rename(columns={_Y:_U});self.engine_adapter.merge(self.checks_definitions_table,distinct,target_columns_to_types=self._checks_definitions_columns_to_types,unique_key=(exp.column(_F),exp.column(_E)))
	def _write_metrics_batch(self,df:pd.DataFrame)->_A:self.engine_adapter.insert_append(self.check_metrics_table,df[DQ_METRICS.column_names()],target_columns_to_types=self._check_metrics_columns_to_types,track_rows_processed=_J)
	def _write_profiles_batch(self,df:pd.DataFrame)->_A:df=df[DQ_PROFILES.column_names()];self.engine_adapter.insert_append(self.profiles_table,df,target_columns_to_types=self._profiles_columns_to_types,track_rows_processed=_J)
	def _get_historic_measurements(self,metric_identity:str,environment:t.Optional[str]=_A,limit:int=100,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A)->t.List[t.Dict[str,t.Any]]:
		B='identity';A='value'
		try:
			metrics=exp.to_table(self.check_metrics_table).as_(_G);data_time=exp.func('COALESCE',exp.column(_l,table=_G),exp.column(_I,table=_G));conditions=[exp.EQ(this=exp.column(_d,table=_G),expression=exp.Literal.string(metric_identity)),exp.Is(this=exp.column(_P,table=_G),expression=exp.Null()).not_()]
			if environment:conditions.append(exp.EQ(this=exp.column(_E,table=_G),expression=exp.Literal.string(environment)))
			if start_ts is not _A:conditions.append(exp.GTE(this=data_time.copy(),expression=exp.Literal.number(start_ts)))
			if end_ts is not _A:conditions.append(exp.LT(this=data_time.copy(),expression=exp.Literal.number(end_ts)))
			query=exp.select(exp.column(_D,table=_G),exp.column(_d,table=_G).as_(B),exp.column(_L,table=_G).as_(_u),exp.column(_P,table=_G).as_(A),data_time.as_(_O)).from_(metrics).where(exp.and_(*conditions)).order_by(data_time,desc=_B).limit(max(limit*10,limit));rows=fetchall(self.engine_adapter,query);results:t.List[t.Dict[str,t.Any]]=[]
			for row in rows:id_,identity,run_id,value_number,measured_at=row;value=convert_value(value_number,A);data_time_value=convert_value(measured_at,_O);results.append({_D:id_,B:identity,_u:run_id,A:value,_O:data_time_value})
			logger.debug("Fetched %d historic measurements for metric '%s'",len(results),metric_identity);return results
		except Exception as e:logger.error("Failed to fetch historic measurements for '%s': %s",metric_identity,e,exc_info=_B);return[]
	def _get_historic_check_results(self,check_identity:str,environment:t.Optional[str]=_A,limit:int=100)->t.List[t.Dict[str,t.Any]]:
		B='type';A='cd'
		try:
			c=exp.to_table(self.check_results_table).as_(_H);m=exp.to_table(self.check_metrics_table).as_(_G);cd=exp.to_table(self.checks_definitions_table).as_(A);select_exprs=[exp.column(_T,table=A).as_(B),exp.column(_D,table=_H).as_(_v),exp.column(_Z,table=_H),exp.column(_I,table=_H).as_(_O),exp.column(_a,table=_H),exp.column(_D,table=_G).as_(_w)];conditions=[exp.EQ(this=exp.column(_F,table=_H),expression=exp.Literal.string(check_identity))]
			if environment:conditions.append(exp.EQ(this=exp.column(_E,table=_H),expression=exp.Literal.string(environment)))
			query=exp.select(*select_exprs).from_(c).join(cd,on=exp.and_(exp.EQ(this=exp.column(_F,table=_H),expression=exp.column(_F,table=A)),exp.EQ(this=exp.column(_E,table=_H),expression=exp.column(_E,table=A))),join_type=_x).join(m,on=exp.EQ(this=exp.column(_D,table=_H),expression=exp.column(_S,table=_G)),join_type='left').where(exp.and_(*conditions)).order_by(exp.Ordered(this=exp.column(_I,table=_H),desc=_B)).limit(limit);rows=fetchall(self.engine_adapter,query);results:t.List[t.Dict[str,t.Any]]=[]
			for row in rows:type,test_result_id,outcome,created_ts,diagnostics_raw,measurement_id=row;data_time=convert_value(created_ts,_O);diagnostics=_parse_diagnostics(diagnostics_raw);results.append({B:type,_v:test_result_id,_Z:outcome,_O:data_time,_a:diagnostics,_w:measurement_id})
			logger.debug("Fetched %d historic check results for check '%s'",len(results),check_identity);return results
		except Exception as e:logger.error("Failed to fetch historic check results for '%s': %s",check_identity,e,exc_info=_B);return[]
	def get_metric_history(self,*,metric_identities:t.Sequence[str],environment:str,limit:int=1000,start_ts:t.Optional[int]=_A,end_ts:t.Optional[int]=_A)->t.List[t.Dict[str,t.Any]]:
		measurements_by_run:t.Dict[str,t.Dict[str,t.Any]]={}
		for metric_identity in metric_identities:
			for measurement in self._get_historic_measurements(metric_identity,environment=environment,limit=limit,start_ts=start_ts,end_ts=end_ts):run_key=str(measurement.get(_u)or measurement.get(_O));measurements_by_run.setdefault(run_key,measurement)
		return sorted(measurements_by_run.values(),key=lambda item:str(item.get(_O,'')),reverse=_B)[:limit]
	def get_anomaly_history(self,*,metric_identities:t.Sequence[str],check_identities:t.Sequence[str],environment:str,limit:int=1000)->t.Dict[str,t.Any]:
		A='f';measurements=self.get_metric_history(metric_identities=metric_identities,environment=environment,limit=limit);check_results_by_id:t.Dict[str,t.Dict[str,t.Any]]={}
		for check_identity in check_identities:
			for result in self._get_historic_check_results(check_identity,environment=environment,limit=limit):check_results_by_id[str(result[_v])]=result
		check_results=sorted(check_results_by_id.values(),key=lambda item:str(item.get(_O,'')),reverse=_B)[:limit];feedback_table=exp.to_table(self.check_feedback_table).as_(A);metrics_table=exp.to_table(self.check_metrics_table).as_(_G);results_table=exp.to_table(self.check_results_table).as_(_H);feedback_query=exp.select(exp.column(_e,table=A),exp.column(_o,table=A),exp.column(_p,table=A),exp.column(_q,table=A),exp.column(_r,table=A),exp.column(_s,table=A)).from_(feedback_table).join(metrics_table,on=exp.EQ(this=exp.column(_e,table=A),expression=exp.column(_D,table=_G)),join_type=_x).join(results_table,on=exp.EQ(this=exp.column(_S,table=_G),expression=exp.column(_D,table=_H)),join_type=_x).where(exp.and_(exp.column(_F,table=A).isin(*[exp.Literal.string(identity)for identity in check_identities]),exp.EQ(this=exp.column(_E,table=_H),expression=exp.Literal.string(environment)))).order_by(exp.column(_U,table=A),desc=_B).limit(limit)
		try:feedback=[{_w:row[0],'isCorrectlyClassified':row[1],'isAnomaly':row[2],'reason':row[3],'skipMeasurements':row[4],'freeTextReason':row[5]}for row in fetchall(self.engine_adapter,feedback_query)]
		except Exception:logger.warning('Failed to fetch anomaly feedback for check identities %s',check_identities,exc_info=_B);feedback=[]
		return{'measurements':measurements,'check_results':check_results,'feedback':feedback}
	def store_anomaly_feedback(self,*,check_identity:str,measurement_id:str,check_id:str='',run_id:str='',feedback_id:t.Optional[str]=_A,is_correctly_classified:t.Optional[bool]=_A,is_anomaly:t.Optional[bool]=_A,seasonality_reason:t.Optional[str]=_A,skip_measurements:t.Optional[str]=_A,feedback_text:t.Optional[str]=_A,user_id:t.Optional[str]=_A,metadata:t.Optional[t.Mapping[str,t.Any]]=_A)->str:
		if skip_measurements not in{_A,'this','previous','previousAndThis'}:raise ValueError('invalid skip_measurements value')
		if seasonality_reason not in{_A,'expectedWeeklySeasonality','expectedMonthlySeasonality','expectedYearlySeasonality'}:raise ValueError('invalid seasonality_reason value')
		timestamp=now_timestamp();identity=feedback_id or sortable_id();frame=pd.DataFrame([{_D:identity,_L:run_id,_S:check_id,_F:check_identity,_e:measurement_id,_A2:'anomaly_classification',_A3:'ml_training',_o:is_correctly_classified,_p:is_anomaly,_q:seasonality_reason,_r:skip_measurements,_s:feedback_text,_A4:json.dumps(metadata or{},sort_keys=_B),'user_id':user_id,_I:timestamp,_U:timestamp}]);self.engine_adapter.merge(self.check_feedback_table,frame,target_columns_to_types=self._check_feedback_columns_to_types,unique_key=(exp.column(_D),));return identity